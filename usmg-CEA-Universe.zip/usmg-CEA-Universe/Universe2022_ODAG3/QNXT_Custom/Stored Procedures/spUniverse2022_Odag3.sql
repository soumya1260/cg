Create PROCEDURE [dbo].[spUniverse2022_Odag3]
AS
		
/************************************************************************************************************************************************
 * TITLE:			dbo.spUniverse2022_Odag3.sql
 * BUSINESS OWNER:	QNXT Development
 * CREATED BY:		Sandie
 * CREATE DATE:		06/17/2021
 * 
 * DESCRIPTION:		
 *
 * Modification History: 
 *	SDE #:		Developer:		Date:		Desc:
 * CHG0146103	Sandie Nantz	06/16/2021	US460219:Universe - CMS Universe 2022 Protocols - Odag3
 *								06/06/2022	GDTG-210 - odag4 not in final table
 * CHG0350228	Sandie Nantz	08/01/2022	GDTG-352 Universe - 2022 ODAG 3 DMR Column_O-Paid Date format
 *								08/02/2022	GDTG-393 Universe - 2022 ODAG3 Column T Logic
 *								09/09/2022  GDTG-538 - System Messages (remits)
 * CHG0439519	Ratna Kumari	02/14/2023	GDTG-1284 - Universe - Latest Changes from Previous branch2023
 * CHG0487157	Ratna Kumari	04/17/2023	GDTG-1693 - Universe - ODAG3 - System Message Logic Remit/EOBs for Providerand DMR
 * CHG0660469	Ratna Kumari	12/12/2023	GDTG-2713 - IF column L equals a value of "OD" AND claim record is in status of DENIED,
                                                            Then populate column U with an "None" value for all OD samples.
 * CHG0705519	Ratna Kumari	03/01/2024	GDTG-3021 - Universe _ODAG3 _Excluding from Column _T_Non_Compliant Phrases
                                03/04/2024      GDTG-3056 - Universe - ODAG3 Partially Denied DMR IDN Mail Date 
 * CHG0709823	Ratna Kumari	03/07/2024	GDTG-3078 -Universe - ODAG3 Approved Claim Zero Pay
 * CHG0709823	Williams Travis	03/08/2024	GDTG-3076 -Universe - update to existing ODAG3 Universe logic to ensure erroneous 
                                                       denial system messages no longer populate column T for Approved claim records.                              
***************************************************************************************************************************************************/
	BEGIN TRY
		BEGIN TRANSACTION;
		

		------------------------------------------------------------------------
		-- Truncate Staging Table
		------------------------------------------------------------------------
		TRUNCATE TABLE QNXT_Custom.dbo.Universe2022_Odag3;


		------------------------------------------------------------------------
		-- Merge All Tables together
		------------------------------------------------------------------------
		INSERT QNXT_Custom.dbo.Universe2022_Odag3
		SELECT *
		FROM QNXT_Custom.dbo.Universe2022_Odag3Prov;


		INSERT QNXT_Custom.dbo.Universe2022_Odag3
		SELECT *
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR
		WHERE Universe2022_Odag3DMR.deletedRsn NOT LIKE 'Dismissed - Claim will be in as a Dismissal%'
			  AND Universe2022_Odag3DMR.G_Claimid NOT IN 
					(SELECT a.G_Claimid
							  FROM QNXT_Custom.dbo.Universe2022_Odag3Dismiss a);


		INSERT QNXT_Custom.dbo.Universe2022_Odag3
		SELECT *
		FROM QNXT_Custom.dbo.Universe2022_Odag3Dismiss;


		------------------------------------------------------------------------
		-- MBI - 
		------------------------------------------------------------------------
		UPDATE s
		SET s.C_EnrolleeID = ma.thevalue
		FROM QNXT_Custom.dbo.Universe2022_Odag3 s
		JOIN Plandata_Prod.dbo.memberattribute ma (NOLOCK) ON s.QMemid = ma.memid
					AND ma.attributeid IN ('C00251792', 'C00303603')
					AND s.QDateStart BETWEEN ma.effdate AND ma.termdate
		WHERE LEN(s.C_EnrolleeID) <> 11
			  AND LEN(ma.thevalue) = 11;


		--if blank, use latest enroll record with carriermemid 11 bytes
		UPDATE s
		SET s.C_EnrolleeID = ek.carriermemid
		FROM QNXT_Custom.dbo.Universe2022_Odag3 s
		CROSS APPLY (SELECT TOP 1 ek.carriermemid
					 FROM Plandata_Prod.dbo.enrollkeys ek (NOLOCK)
					 WHERE s.qmemid = ek.memid ---or memid
						   AND LEN(ek.carriermemid) = 11
					 ORDER BY ek.effdate DESC) ek
		WHERE LEN(s.C_EnrolleeID) <> 11;


		--IF still blank use 11 byte attribute in ('C00251792','C00303603') 
		UPDATE s
		SET s.C_EnrolleeID = ma.thevalue
		FROM QNXT_Custom.dbo.Universe2022_Odag3 s
		CROSS APPLY (SELECT TOP 1 ma.thevalue
					 FROM Plandata_Prod.dbo.memberattribute ma (NOLOCK)
					 WHERE s.QMemid = ma.memid
						   AND ma.attributeid IN ('C00251792', 'C00303603')
						   AND LEN(ma.thevalue) = 11
					 ORDER BY ma.effdate DESC) ma
		WHERE LEN(s.C_EnrolleeID) <> 11;


		------------------------------------------------------------------------
		-- Update F_FDR
		------------------------------------------------------------------------
		UPDATE stg
		SET stg.F_FDR = CONVERT(VARCHAR(70), ISNULL(ISNULL(tIpa.fullname, topIpa.fullname), 'None'))
		FROM QNXT_Custom.dbo.Universe2022_Odag3 stg
		INNER JOIN Plandata_Prod.dbo.memberpcp mpcp WITH (NOLOCK) ON (stg.QEnrollid = mpcp.enrollid)
							AND (stg.QDateStart BETWEEN mpcp.effdate AND mpcp.termdate)
		INNER JOIN Plandata_Prod.dbo.affiliation mpAf WITH (NOLOCK) ON (mpcp.affiliationid = mpAf.affiliationid)
		INNER JOIN Plandata_Prod.dbo.affiliation afPcp WITH (NOLOCK) ON (mpAf.provid = afPcp.provid)
							AND (afPcp.affiltype = 'HS Incentive')
							AND (afPcp.hospaffiltype = 'POD')
							AND (stg.QDateStart BETWEEN afPcp.effdate AND afPcp.termdate)
		INNER JOIN Plandata_Prod.dbo.providerattribute patr WITH (NOLOCK) ON (afPcp.affiliateid = patr.provid)
							AND (patr.attributeid = 'C50416577')
							AND (stg.QDateStart BETWEEN patr.effdate AND patr.termdate)
		INNER JOIN Plandata_Prod.dbo.planprovinfo ppi WITH (NOLOCK) ON (patr.thevalue = ppi.planprovid)
							AND (stg.QDateStart BETWEEN ppi.effdate AND ppi.termdate)
							AND (stg.QProgramid = ppi.programid)
		INNER JOIN Plandata_Prod.dbo.provider topIpa WITH (NOLOCK) ON (ppi.provid = topIpa.provid)
		LEFT JOIN Plandata_Prod.dbo.affiliation tiAf WITH (NOLOCK) ON (ppi.provid = tiAf.provid)
							AND (tiAf.affiltype = 'Management')
							AND (stg.QDateStart BETWEEN tiAf.effdate AND tiAf.termdate)
		LEFT JOIN Plandata_Prod.dbo.provider tIpa WITH (NOLOCK) ON (tiAf.affiliateid = tIpa.provid)
		WHERE (EXISTS (SELECT ipaAtr.provid
					   FROM Plandata_Prod.dbo.providerattribute ipaAtr WITH (NOLOCK)
					   WHERE (afPcp.affiliateid = ipaAtr.provid)
							 AND (ipaAtr.attributeid = 'C54650026')
							 AND (ipaAtr.thevalue = 'IPA')
							 AND (stg.QDateStart BETWEEN ipaAtr.effdate AND ipaAtr.termdate)));


		------------------------------------------------------------------------
		-- Update T_IssueDescTypeOfService
		------------------------------------------------------------------------
		UPDATE stg
		SET stg.T_IssueDescTypeOfService = CONVERT(VARCHAR(2000)
					, ISNULL(rc.descr, '') + CASE
								WHEN (rc.descr IS NOT NULL)
										AND (sc.descr IS NOT NULL)
										THEN ','
								ELSE ''
							END + ISNULL(sc.descr, ''))
		FROM QNXT_Custom.dbo.Universe2022_Odag3 stg
		CROSS APPLY (SELECT STUFF((SELECT DISTINCT ',' + CAST(RTRIM(rc.description) AS VARCHAR(60)) + ''
					FROM Plandata_Prod.dbo.claimdetail cdtl WITH (NOLOCK)
					INNER JOIN Plandata_Prod.dbo.revcode rc WITH (NOLOCK) ON (cdtl.revcode = rc.codeid)
					WHERE (cdtl.claimid = stg.G_Claimid)
							AND (cdtl.revcode <> '')
					FOR XML PATH(''))
					, 1
					, LEN(',')
					, '')) rc(descr)
		CROSS APPLY (SELECT STUFF((SELECT DISTINCT ',' + CAST(RTRIM(sc.description) AS VARCHAR(60)) + ''
					FROM Plandata_Prod.dbo.claimdetail cdtl WITH (NOLOCK)
					INNER JOIN Plandata_Prod.dbo.svccode sc WITH (NOLOCK) ON (cdtl.servcode = sc.codeid)
					WHERE (cdtl.claimid = stg.G_Claimid)
							AND (cdtl.servcode <> '')
					FOR XML PATH(''))
					, 1
					, LEN(',')
					, '')) sc(descr);

	
		------------------------------------------------------------------------
		-- Create #clmLevel Temp Table
		------------------------------------------------------------------------
		IF OBJECT_ID('tempdb..#clmLevel') IS NOT NULL
			DROP TABLE #clmLevel;


		CREATE TABLE #clmLevel
		(
			recordID INT IDENTITY(1, 1) PRIMARY KEY
			, claimID CHAR(15)
			, reportText VARCHAR(MAX)
			, recordRank INT
			, recordType VARCHAR(10)
			, reason VARCHAR(15)
			, ruleID VARCHAR(15)
			, excluded VARCHAR(1)
			, OldProtocolTable VARCHAR(7)
		);


		------------------------------------------------------------------------
		-- Populate #clmLevel Temp Table
		------------------------------------------------------------------------
		INSERT INTO #clmLevel
		SELECT ce.claimid
			   , RTRIM(ce.remitoverridemessage) AS reportText
			   , 1 AS recordRank
			   , 'CE_RO' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		WHERE (ce.status = 'DENY')
			  AND (ce.claimline = 0)
			  AND (ISNULL(ce.remitoverridemessage, '') > '')
		ORDER BY ce.claimid
				 , ce.claimline;


		INSERT INTO #clmLevel
		SELECT ce.claimid
			   , RTRIM(cem.overridemessage) AS reportText
			   , 2 AS recordRank
			   , 'CEM_REMIT' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		INNER JOIN Plandata_Prod.dbo.claimeditmessage cem WITH (NOLOCK) ON (ce.claimid = cem.claimid)
																		   AND (ce.claimline = cem.claimline) --ousted 052020 AND (ce.reason = cem.messageid)
		WHERE (cem.messagetype = 'REMIT')
			  AND (ce.status = 'DENY')
			  AND (ce.claimline = 0)
			  AND (ISNULL(cem.overridemessage, '') > '')
			  AND cem.messageid NOT IN (SELECT ex.ExCode --06112020-even though they ousted the messageid, they don't want these
										FROM QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK)
										WHERE (ex.UniverseName = tmp.OldProtocolTable))
		ORDER BY ce.claimid
				 , ce.claimline;


		INSERT INTO #clmLevel
		SELECT ce.claimid
			   , RTRIM(q.description) AS reportText
			   , 3 AS recordRank
			   , 'CRule' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		INNER JOIN Plandata_Prod.dbo.qrule q WITH (NOLOCK) ON (ce.ruleid = q.ruleid)
		WHERE (ce.ruleid <> '913'
			   AND q.description <> 'Manual Pend Of Claim') --05192021
			  AND (ce.status = 'DENY')
			  AND (ce.claimline = 0)
			  AND (ISNULL(ce.eoboverridemessage, '') = '')
			  AND (NOT EXISTS (SELECT 1
							   FROM Plandata_Prod.dbo.claimeditmessage cem WITH (NOLOCK)
							   WHERE (cem.messagetype = 'remit')
									 AND (cem.claimid = ce.claimid)
									 AND (cem.ruleid = ce.ruleid)
									 AND (cem.claimline = ce.claimline)
									 AND (cem.messageid = ce.reason)
									 AND (ce.reason > '')))
			  AND (RTRIM(q.description) IS NOT NULL)
		ORDER BY ce.claimid
				 , ce.claimline;


		INSERT INTO #clmLevel
		SELECT ce.claimid
			   , RTRIM(ce.eoboverridemessage) AS reportText
			   , 4 AS recordRank
			   , 'C_EO' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		WHERE (ce.status = 'DENY')
			  AND (ce.claimline = 0)
			  AND (ISNULL(ce.eoboverridemessage, '') > '')
		ORDER BY ce.claimid
				 , ce.claimline;


		INSERT INTO #clmLevel
		SELECT ce.claimid
			   , RTRIM(cem.overridemessage) AS reportText
			   , 5 AS recordRank
			   , 'CEM_EOB' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		INNER JOIN Plandata_Prod.dbo.claimeditmessage cem WITH (NOLOCK) ON (ce.claimid = cem.claimid)
																		   AND (ce.claimline = cem.claimline)
																		   AND (ce.ruleid = cem.ruleid)
		WHERE (cem.messagetype = 'EOB')
			  AND (ce.status = 'DENY')
			  AND (ce.claimline = 0)
			  AND (ISNULL(cem.overridemessage, '') > '')
		ORDER BY ce.claimid
				 , ce.claimline;

--System Messages:REMIT

	INSERT INTO #clmLevel
		SELECT   cr.claimid
			   , cr.overridemessage AS reportText
			   , 6 AS recordRank
			   , 'SysRemit' AS recordType
			   , cr.msgnumber AS reason
			   , cr.msgnumber
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimremit cr WITH (NOLOCK) ON (cr.claimid = tmp.G_Claimid)
		WHERE (cr.claimline = 0)
			  AND cr.overridemessage is NOT null
		ORDER BY cr.claimid;

--System Messages: EOB

INSERT INTO #clmLevel
		SELECT   cr.claimid
			   , cr.overridemessage AS reportText
			   , 6 AS recordRank
			   , 'EOBRemit' AS recordType
			   , cr.msgnumber AS reason
			   , cr.msgnumber
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimeob cr WITH (NOLOCK) ON (cr.claimid = tmp.G_Claimid)
		WHERE (cr.claimline = 0)
			  AND cr.overridemessage is NOT null
		ORDER BY cr.claimid;




		UPDATE c
		SET c.excluded = 'Y'
		FROM #clmLevel c
		WHERE ((c.reason IN (SELECT ex.ExCode
							 FROM QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK)
							 WHERE (ex.ExType IN ('EOB', 'REMIT'))
								   AND (ex.UniverseName = c.oldprotocoltable)))
			   OR (c.ruleID IN (SELECT ex.ExCode
								FROM QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK)
								WHERE (ex.ExType = 'rules')
									  AND (ex.UniverseName = c.oldprotocoltable))));


		UPDATE c --Only for Providers in Odag3
		SET c.excluded = 'Y'
		FROM #clmLevel c
		WHERE c.ruleID IN ('158', '204', '238', '256', '289', '290', '291', '292', '301', '304', '308', '309', '312', '315', '318', '329', '330', '400', '401', '403', '404', '405', '406', '407', '422', '424', '503', '504', '505', '508', '511', '512', '514', '515', '521', '550', '635', '639', '642', '643', '658', '659', '700', '701', '702', '703', '704', '708', '713', '827', '901', '902', '911', '912', '970', '984', '1001', '1149', '1155', '1156', '1164', '1165', '1170', '1171', '1172', '6043', '6118', '6125', '6126', '6141', '6257', '8019', '9021', '9025', '9027', '9028', '9031', '9032', '9036', '9051', '9056', '9058', '9060', '9073', '9126', '9127', '9128', '9130', '9131', '9132', '9133', '9134', '9135', '9136', '9138', '9148', '9149', '9150', '9151', '9152', '9164', '9166', '9170', '9171', '9172', '9192', '9193', '9195', '9205', '9208', '9214', '9221', '9224', '9232', '9469', '9473', '9474', '9500', '9502', '9503', '9504', '9508', '9510', '9511', '9512', '9513', '9514', '9515')
			  AND c.reason = ''
			  AND c.excluded <> 'Y'
			  AND c.OldProtocolTable = 'ODAG3';


		------------------------------------------------------------------------
		-- IF ALL Header codes ON UniverseExtractExcludeCodes, do NOT INCLUDE it ON the universe - error it out
		------------------------------------------------------------------------
		UPDATE s
		SET s.deletedRsn = LEFT(s.deletedRsn + 'All Header Edits on table', 350)
		FROM #clmLevel c
		JOIN QNXT_Custom.dbo.Universe2022_Odag3 s ON s.G_Claimid = c.claimID
		WHERE (c.excluded = 'Y')
			  AND c.claimID NOT IN (SELECT DISTINCT cl.claimID FROM #clmLevel cl WHERE cl.excluded = 'N');


		--remove dups
		DELETE t
		FROM #clmLevel t
		INNER JOIN (SELECT #clmLevel.recordID
						   , ROW_NUMBER() OVER (PARTITION BY #clmLevel.claimID
															 , #clmLevel.reportText
												ORDER BY #clmLevel.recordRank
														 , #clmLevel.recordID) AS changeRank
					FROM #clmLevel) s ON (s.recordID = t.recordID)
										 AND (s.changeRank > 1);


		------------------------------------------------------------------------
		-- Create #lineLevel Temp Table
		------------------------------------------------------------------------
		IF (OBJECT_ID('tempdb..#lineLevel') IS NOT NULL)
			DROP TABLE #lineLevel;


		CREATE TABLE #lineLevel
		(
			recordID INT IDENTITY(1, 1) PRIMARY KEY
			, claimID CHAR(15)
			, reportText VARCHAR(MAX)
			, recordRank INT
			, recordType VARCHAR(10)
			, reason VARCHAR(15)
			, ruleID VARCHAR(15)
			, messageID VARCHAR(15)
			, messageType VARCHAR(15)
			, excluded VARCHAR(1)
			, OldProtocoltable VARCHAR(15)
		);


		------------------------------------------------------------------------
		-- Populate #lineLevel Temp Table
		--added  ce.ruleid = '116' because some of them are ODAY or WARNs
		------------------------------------------------------------------------
		INSERT INTO #lineLevel
		SELECT ce.claimid
			   , RTRIM(ce.remitoverridemessage) AS reportText
			   , 1 AS recordRank
			   , 'CLE_RO' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , NULL AS messageid
			   , NULL AS messagetype
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		WHERE ((ce.status = 'DENY')
			   OR (ce.ruleid = '116'
				   AND ce.status <> 'OKAY'))
			  AND (ce.claimline > 0)
			  AND (ISNULL(ce.remitoverridemessage, '') > '')
		ORDER BY ce.claimid
				 , ce.claimline;


		INSERT INTO #lineLevel
		SELECT ce.claimid
			   , RTRIM(cem.overridemessage) AS reportText
			   , 2 AS recordRank
			   , 'CLEM_REMIT' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , cem.messageid
			   , cem.messagetype
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		INNER JOIN Plandata_Prod.dbo.claimeditmessage cem WITH (NOLOCK) ON (ce.claimid = cem.claimid)
												AND (ce.claimline = cem.claimline) --ousted 052020 AND (ce.reason = cem.messageid)
		WHERE (cem.messagetype = 'REMIT')
			  AND ((ce.status = 'DENY')
				   OR (ce.ruleid = '116'
					   AND ce.status <> 'OKAY'))
			  AND (ce.claimline > 0)
			  AND (ISNULL(cem.overridemessage, '') > '')
			  AND cem.messageid NOT IN (SELECT ex.ExCode --06112020-even though they ousted the messageid, they don't want these
										FROM QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK)
										WHERE (ex.UniverseName = tmp.OldProtocolTable))
		ORDER BY ce.claimid
				 , ce.claimline;


		INSERT INTO #lineLevel
		SELECT ce.claimid
			   , RTRIM(q.description) AS reportText
			   , 3 AS recordRank
			   , 'CLrule' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , NULL AS messageid
			   , NULL AS messagetype
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		INNER JOIN Plandata_Prod.dbo.qrule q WITH (NOLOCK) ON (ce.ruleid = q.ruleid)
		WHERE (ce.ruleid <> '913'
			   AND q.description <> 'Manual Pend Of Claim') --05192021
			  AND ((ce.status = 'DENY')
				   OR (ce.ruleid = '116'
					   AND ce.status <> 'OKAY'))
			  AND (ce.claimline > 0)
			  AND (ISNULL(ce.eoboverridemessage, '') = '')
			  AND (NOT EXISTS (SELECT 1
							   FROM Plandata_Prod.dbo.claimeditmessage cem (NOLOCK)
							   WHERE (cem.messagetype = 'remit')
									 AND (cem.claimid = ce.claimid)
									 AND (cem.ruleid = ce.ruleid)
									 AND (cem.claimline = ce.claimline)
									 AND (cem.messageid = ce.reason)
									 AND (ce.reason > '')))
			  AND (ISNULL(q.description, '') > '')
		ORDER BY ce.claimid
				 , ce.claimline;


		INSERT INTO #lineLevel
		SELECT ce.claimid
			   , RTRIM(ce.eoboverridemessage) AS reportText
			   , 4 AS recordRank
			   , 'CL_EO' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , NULL AS messageid
			   , NULL AS messagetype
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		WHERE ((ce.status = 'DENY')
			   OR (ce.ruleid = '116'
				   AND ce.status <> 'OKAY'))
			  AND (ce.claimline > 0)
			  AND (ISNULL(ce.eoboverridemessage, '') > '')
		ORDER BY ce.claimid
				 , ce.claimline;


		INSERT INTO #lineLevel
		SELECT ce.claimid
			   , RTRIM(cem.overridemessage) AS reportText
			   , 5 AS recordRank
			   , 'CLEM_EOB' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , cem.messageid
			   , cem.messagetype
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		INNER JOIN Plandata_Prod.dbo.claimeditmessage cem WITH (NOLOCK) ON (ce.claimid = cem.claimid)
																		   AND (ce.claimline = cem.claimline)
																		   AND (ce.ruleid = cem.ruleid)
		WHERE ((ce.status = 'DENY')
			   OR (ce.ruleid = '116'
				   AND ce.status <> 'OKAY'))
			  AND (ce.claimline > 0)
			  AND (cem.messagetype = 'EOB')
			  AND (ISNULL(cem.overridemessage, '') > '')
		ORDER BY ce.claimid
				 , ce.claimline;


		INSERT INTO #lineLevel
		SELECT ce.claimid
			   , RTRIM(rrsn.reporttext) AS reportText
			   , 6 AS recordRank
			   , 'REMITRule' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , NULL AS messageid
			   , NULL AS messagetype
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		INNER JOIN Plandata_Prod.dbo.rulereason rrsn WITH (NOLOCK) ON (ce.reason = rrsn.reasonid)
																	  AND (rrsn.reasontype = 'REMIT')
																	  AND (ce.reason <> '')
		WHERE (ce.reason <> '')
			  AND ((ce.status = 'DENY')
				   OR (ce.ruleid = '116'
					   AND ce.status <> 'OKAY'))
			  AND (ISNULL(rrsn.reporttext, '') > '')
			  AND (NOT EXISTS (SELECT 1
							   FROM #lineLevel t
							   WHERE (tmp.G_Claimid = t.claimID)
									 AND (t.reportText <> 'Claim has been manually Denied')))
		ORDER BY ce.claimid
				 , ce.claimline;


		INSERT INTO #lineLevel
		SELECT ce.claimid
			   , RTRIM(rrsn.reporttext) AS reportText
			   , 7 AS recordRank
			   , 'EOBRule' AS recordType
			   , ce.reason
			   , ce.ruleid
			   , NULL AS messageid
			   , NULL AS messagetype
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = tmp.G_Claimid)
		INNER JOIN Plandata_Prod.dbo.rulereason rrsn WITH (NOLOCK) ON (ce.eobid <> '')
																	  AND (ce.eobid = rrsn.reasonid)
																	  AND (rrsn.reasontype = 'EOB')
		WHERE ((ce.status = 'DENY')
			   OR (ce.ruleid = '116'
				   AND ce.status <> 'OKAY'))
			  AND (RTRIM(rrsn.reporttext) IS NOT NULL)
			  AND (ISNULL(rrsn.reporttext, '') > '')
			  AND (NOT EXISTS (SELECT 1
							   FROM #lineLevel t
							   WHERE (tmp.G_Claimid = t.claimID)
									 AND (t.reportText <> 'Claim has been manually Denied')))
		ORDER BY ce.claimid
				 , ce.claimline;

--system messages :- REMIT
		INSERT INTO #lineLevel
		SELECT  cr.claimid
			   , cr.overridemessage AS reportText
			   , 8 AS recordRank
			   , 'SysRemit' AS recordType
			   , cr.msgnumber AS reason
			   , cr.msgnumber AS ruleid
			   , cr.msgnumber AS messageid
			   , NULL AS messagetype
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimremit cr WITH (NOLOCK) ON (cr.claimid = tmp.G_Claimid)
		WHERE (cr.claimline > 0)
			  AND cr.overridemessage is NOT NULL;

--system messages:- EOB
		INSERT INTO #lineLevel
		SELECT  cr.claimid
			   , cr.overridemessage AS reportText
			   , 8 AS recordRank
			   , 'EOBRemit' AS recordType
			   , cr.msgnumber AS reason
			   , cr.msgnumber AS ruleid
			   , cr.msgnumber AS messageid
			   , NULL AS messagetype
			   , 'N' AS excluded
			   , tmp.OldProtocolTable
		FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimeob cr WITH (NOLOCK) ON (cr.claimid = tmp.G_Claimid)
		WHERE (cr.claimline > 0)
			  AND cr.overridemessage is NOT NULL;

                ------------------------------------------------------------------------
		-- Begining of GDTG-3076 - Universe - Universe - ODAG3 Approved Claims Column T - DEV
		------------------------------------------------------------------------

		DELETE t FROM #clmLevel t JOIN QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK) ON tmp.G_Claimid = t.claimID AND tmp.M_RequestDisposition = 'Approved';
		DELETE t FROM #lineLevel  t JOIN QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK) ON tmp.G_Claimid = t.claimID AND tmp.M_RequestDisposition = 'Approved';
		------------------------------------------------------------------------
		-- End of GDTG-3076 - Universe - Universe - ODAG3 Approved Claims Column T - DEV
		------------------------------------------------------------------------
		
		
		DELETE FROM #clmLevel WHERE #clmLevel.reportText IN ('Claim Line Submission Window Exceeded','Claim has been manually denied','iHT Deny','iHT Warn','eviCore Claim Return','Non-covered item or service') 
		DELETE FROM #lineLevel WHERE #lineLevel.reportText IN ('Claim Line Submission Window Exceeded','Claim has been manually denied','iHT Deny','iHT Warn','eviCore Claim Return','Non-covered item or service') 

                 ---------------------------------------------------------------------------------------------
		-- Begining of GDTG-3021 - Universe - Exclude ODAG3 Column T NonCompliant Phrases
		----------------------------------------------------------------------------------------------
		DELETE FROM #clmLevel WHERE #clmLevel.reportText like '%A deductible of % has been applied%'
		DELETE FROM #clmLevel WHERE #clmLevel.reportText like 'Paid at % of contract amount.'

		DELETE FROM #clmLevel WHERE #clmLevel.reportText IN 
		--SELECT distinct reportText FROM #clmLevel WHERE #clmLevel.reportText IN 
		(	'Maximum out of Pocket has been reached. Eligible Amounts have been paid at 100%.',
			'Paid at 70.00% of contract amount.',
			'Paid at 80.00% of contract amount.',
			'Paid at 50.00% of contract amount.',
			'Excluded Contract Term for Service',			
			'Paid at 90.00% of contract amount.',
			'Paid at 60.00% of contract amount.',
			'Paid at 65.00% of contract amount.',			
			'Inpatient Claim Submission Window Exceeded (claim Thru date)',
			'No contract term found for service',
			'Default FFS Percent Not Defined',
			'Paid at 85.00% of contract amount.',
			'Paid at 75.00% of contract amount.',
			'Paid at 55.00% of contract amount.',
			'Provider is Non-Par - Point of Service benefit applied',
			'Repricing Finished - No Savings Found - Zelis',
			'Maximum copay per diem has been satisfied for this benefit period.  No copay per diem applied.',
			'This claim exceeds the dollar limit allowed for this benefit.'
		)
					
	 
		DELETE FROM #lineLevel WHERE #lineLevel.reportText like '%A deductible of % has been applied%'
		DELETE FROM #lineLevel WHERE #lineLevel.reportText like 'Paid at % of contract amount.'

		DELETE FROM #lineLevel WHERE #lineLevel.reportText IN 
		--SELECT distinct reportText FROM #lineLevel WHERE #lineLevel.reportText IN 
		(	'Maximum out of Pocket has been reached. Eligible Amounts have been paid at 100%.',
			'Paid at 70.00% of contract amount.',
			'Paid at 80.00% of contract amount.',
			'Paid at 50.00% of contract amount.',
			'Excluded Contract Term for Service',			
			'Paid at 90.00% of contract amount.',
			'Paid at 60.00% of contract amount.',
			'Paid at 65.00% of contract amount.',			
			'Inpatient Claim Submission Window Exceeded (claim Thru date)',
			'No contract term found for service',
			'Default FFS Percent Not Defined',
			'Paid at 85.00% of contract amount.',
			'Paid at 75.00% of contract amount.',
			'Paid at 55.00% of contract amount.',
			'Provider is Non-Par - Point of Service benefit applied',
			'Repricing Finished - No Savings Found - Zelis',
			'Maximum copay per diem has been satisfied for this benefit period.  No copay per diem applied.',
			'This claim exceeds the dollar limit allowed for this benefit.'
		)

		----------------------------------------------------------------------------------------------------------------
		-- End of GDTG-3021 - Universe - Exclude ODAG3 Column T NonCompliant Phrases
		-----------------------------------------------------------------------------------------------------------------

		




		UPDATE l
		SET l.excluded = 'Y'
		FROM #lineLevel l
		WHERE ((l.reason IN (SELECT ex.ExCode
							 FROM QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK)
							 WHERE (ex.ExType IN ('EOB', 'REMIT'))
								   AND (ex.UniverseName = l.OldProtocolTable)))
			   OR (l.ruleID IN (SELECT ex.ExCode
								FROM QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK)
								WHERE (ex.ExType IN ('Rules'))
									  AND (ex.UniverseName = l.OldProtocolTable)))
			   OR (l.messageID IN (SELECT ex.ExCode
								   FROM QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK)
								   WHERE (ex.ExType = l.messagetype)
										 AND (ex.UniverseName = l.OldProtocolTable))));


		UPDATE l										---only in ODAG3Provider
		SET l.excluded = 'Y'
		FROM #lineLevel l
		WHERE l.ruleID IN ('158', '204', '238', '256', '289', '290', '291', '292', '301', '304', '308', '309', '312', '315', '318', '329', '330', '400', '401', '403', '404', '405', '406', '407', '422', '424', '503', '504', '505', '508', '511', '512', '514', '515', '521', '550', '635', '639', '642', '643', '658', '659', '700', '701', '702', '703', '704', '708', '713', '827', '901', '902', '911', '912', '970', '984', '1001', '1149', '1155', '1156', '1164', '1165', '1170', '1171', '1172', '6043', '6118', '6125', '6126', '6141', '6257', '8019', '9021', '9025', '9027', '9028', '9031', '9032', '9036', '9051', '9056', '9058', '9060', '9073', '9126', '9127', '9128', '9130', '9131', '9132', '9133', '9134', '9135', '9136', '9138', '9148', '9149', '9150', '9151', '9152', '9164', '9166', '9170', '9171', '9172', '9192', '9193', '9195', '9205', '9208', '9214', '9221', '9224', '9232', '9469', '9473', '9474', '9500', '9502', '9503', '9504', '9508', '9510', '9511', '9512', '9513', '9514', '9515')
			  AND l.reason = ''
			  AND l.excluded <> 'Y'
			  AND l.OldProtocoltable = 'ODAG3';


		------------------------------------------------------------------------		
		---remove CLAIM HAS BEEN MANUALLY Denied **IF** there is another edit that isn't excluded --01/29/2021
		------------------------------------------------------------------------
		UPDATE l
		SET l.excluded = 'Y'
		FROM #lineLevel l
		WHERE l.excluded <> 'Y'
			  AND l.reportText = 'Claim has been manually Denied'
			  AND l.claimID IN (SELECT s.claimID
								FROM #lineLevel s
								WHERE s.reportText <> 'Claim has been manually Denied'
									  AND s.excluded = 'N');

		--If any edit on the header, do not look at service lines to determine if the claim should be excluded. 
		--If the claim has header edits, Include/Exclude shoud be determine ONLY based on those edits
		UPDATE l
		SET l.excluded = 'N'
		FROM #lineLevel l
		JOIN #clmLevel c ON c.claimID = l.claimID
		WHERE c.excluded = 'N';


		------------------------------------------------------------------------
		-- -- IF ALL LINE codes ON UniverseExtractExcludeCodes, do NOT INCLUDE it ON the universe - error it out
		------------------------------------------------------------------------
		UPDATE s
		SET s.deletedRsn = LEFT(s.deletedRsn + 'All Line Edits on table', 350)
		FROM #lineLevel l
		JOIN QNXT_Custom.dbo.Universe2022_Odag3 s ON s.G_Claimid = l.claimID
		WHERE (l.excluded = 'Y')
			  AND l.claimID NOT IN (SELECT DISTINCT cl.claimID FROM #lineLevel cl WHERE cl.excluded = 'N');


		--remove dups
		DELETE t
		FROM #lineLevel t
		INNER JOIN (SELECT #lineLevel.recordID
						   , ROW_NUMBER() OVER (PARTITION BY #lineLevel.claimID
															 , #lineLevel.reportText
												ORDER BY #lineLevel.recordRank
														 , #lineLevel.recordID) AS changeRank
					FROM #lineLevel) s ON (s.recordID = t.recordID)
										  AND (s.changeRank > 1);


		------------------------------------------------------------------------
		-- Create #results Temp Table
		------------------------------------------------------------------------
		IF (OBJECT_ID('tempdb..#results') IS NOT NULL)
			DROP TABLE #results;


		CREATE TABLE #results
		(
			recordID INT IDENTITY(1, 1) PRIMARY KEY
			, claimID CHAR(15)
			, clmLevel VARCHAR(MAX)
			, lineLevel VARCHAR(MAX)
		);


		------------------------------------------------------------------------
		-- Populate #results Temp Table for codes NOT in Excluded table
		------------------------------------------------------------------------
		MERGE #results AS Target
		USING (SELECT tmp.G_Claimid
					  , ISNULL(clmlevel.reporttext, '') AS clmlevel
			   FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
			   OUTER APPLY (SELECT STUFF((SELECT ', ' + RTRIM(b.reportText)
										  FROM #clmLevel b
										  WHERE (tmp.G_Claimid = b.claimID)
												AND b.excluded = 'N'
										  ORDER BY b.recordRank
										 FOR XML PATH(''))
										 , 1
										 , LEN(',')
										 , '')) clmlevel(reporttext)
			   WHERE (clmlevel.reporttext IS NOT NULL)) AS SOURCE
		ON (Target.claimID = SOURCE.G_Claimid)
		WHEN MATCHED
		THEN UPDATE SET Target.clmLevel = SOURCE.clmlevel
		WHEN NOT MATCHED BY TARGET
		THEN INSERT (claimID
					 , clmLevel)
			 VALUES
			 (SOURCE.G_Claimid, SOURCE.clmlevel);


		MERGE #results AS Target
		USING (SELECT tmp.G_Claimid
					  , ISNULL(linelevel.reporttext, '') AS linelevel
			   FROM QNXT_Custom.dbo.Universe2022_Odag3 tmp WITH (NOLOCK)
			   OUTER APPLY (SELECT STUFF((SELECT ', ' + RTRIM(b.reportText)
										  FROM #lineLevel b
										  WHERE (tmp.G_Claimid = b.claimID)
												AND b.excluded = 'N'
										  ORDER BY b.recordRank
										 FOR XML PATH(''))
										 , 1
										 , LEN(',')
										 , '')) linelevel(reporttext)
			   WHERE (linelevel.reporttext IS NOT NULL)) AS SOURCE
		ON (Target.claimID = SOURCE.G_Claimid)
		WHEN MATCHED
		THEN UPDATE SET Target.lineLevel = SOURCE.linelevel
		WHEN NOT MATCHED BY TARGET
		THEN INSERT (claimID
					 , lineLevel)
			 VALUES
			 (SOURCE.G_Claimid, SOURCE.linelevel);


		------------------------------------------------------------------------
		-- Update T_IssueDescTypeOfService
		------------------------------------------------------------------------
		UPDATE stg
		SET stg.T_IssueDescTypeOfService = CASE
					   WHEN (RTRIM(LTRIM(stg.T_IssueDescTypeOfService)) <> '')
							THEN CONVERT(VARCHAR(2000)
									 , RTRIM(stg.T_IssueDescTypeOfService) + ',' + CASE
													   WHEN (LTRIM(RTRIM(clmlevel)) > '')
															THEN clmLevel
													   ELSE linelevel
													   END)
							  ELSE CONVERT(VARCHAR(2000)
										, RTRIM(stg.T_IssueDescTypeOfService) + CASE
											WHEN (LTRIM(RTRIM(clmlevel)) > '')
												 THEN clmlevel
											ELSE linelevel
											END)
						   END
		FROM QNXT_Custom.dbo.Universe2022_Odag3 stg WITH (NOLOCK)
		INNER JOIN #results t ON (t.claimID = stg.G_Claimid);
								 --AND stg.OldProtocolTable <> 'Odag13';

 /*------------------------------------------------------------------------------------
	           Begining of GDTG-3078 -Universe - ODAG3 Approved Claim Zero Pay

        ---------------------------------------------------------------------------------------*/

		IF (OBJECT_ID('tempdb..#ZeroPayClaims') IS NOT NULL)
		DROP TABLE #ZeroPayClaims;

		
		Select c.G_Claimid,M_RequestDisposition,
		[Total Charged Amount] = cd.totalchargedamt
		,[Total Eligible Amount] = cd.totalcontractpaid
		,[Total Allowed Amount] =  cd.totalbenefitamt 			
		,[Total Paid Amount] = cd.totalamountpaid
		INTO #ZeroPayClaims
		FROM QNXT_Custom.dbo.Universe2022_Odag3 c		
		Inner Join (Select cdl.claimid, SUM(claimamt) totalchargedamt
					,SUM(contractpaid) totalcontractpaid								
					,SUM(benefitamt) totalbenefitamt	
					,SUM(amountpaid) totalamountpaid
				FROM Plandata_Prod.dbo.claimdetail cdl (NoLock)					
				JOIN QNXT_Custom.dbo.Universe2022_Odag3 stg ON stg.G_Claimid = cdl.claimid				
				Group by cdl.claimid) cd On c.G_Claimid = cd.claimid
		WHERE c.M_RequestDisposition = 'Approved'


		UPDATE s
		SET s.deletedRsn = RTRIM(s.deletedRsn) + 'APPROVED claim with $0 payment'
		FROM #ZeroPayClaims zpc
		JOIN QNXT_Custom.dbo.Universe2022_Odag3 s ON zpc.G_Claimid = s.G_Claimid
		WHERE s.M_RequestDisposition = 'Approved'
		AND zpc.[Total Charged Amount] > 0 
		AND zpc.[Total Eligible Amount] = 0 
		AND zpc.[Total Allowed Amount] = 0 
		AND zpc.[Total Paid Amount] = 0 
	


		/*------------------------------------------------------------------------------------
	           End of GDTG-3078 -Universe - ODAG3 Approved Claim Zero Pay
          ------------------------------------------------------------------------------------*/
       
        ------------------------------------------------------------------------
		-- Begining of GDTG-2774 - Universe - ODAG3 Column U - DEV
		------------------------------------------------------------------------
		UPDATE  stg
		SET stg.U_DeniedMedicalNecessity = 'None'
		FROM QNXT_Custom.dbo.Universe2022_Odag3 stg
		WHERE stg.L_ODorRecon = 'OD' AND stg.M_RequestDisposition = 'Denied'

		------------------------------------------------------------------------
		-- End of GDTG-2774 - Universe - ODAG3 Column U - DEV
		------------------------------------------------------------------------



		----------------------------------------------------------------------
		 --DROP all Temp Tables
		----------------------------------------------------------------------
		IF OBJECT_ID('tempdb..#clmLevel') IS NOT NULL
			DROP TABLE #clmLevel;


		IF OBJECT_ID('tempdb..#lineLevel') IS NOT NULL
			DROP TABLE #lineLevel;


		IF OBJECT_ID('tempdb..#results') IS NOT NULL
			DROP TABLE #results;


		------------------------------------------------------------------------
		-- Housekeeping
		------------------------------------------------------------------------
		UPDATE stg
		SET stg.H_DateReceived = 
						CASE WHEN (ISDATE(stg.H_DateReceived) = 1)
							 THEN REPLACE(CONVERT(VARCHAR(10), stg.H_DateReceived, 102), '-', '/')
							ELSE stg.H_DateReceived
						END
			, stg.O_DatePaid = 
						CASE WHEN (ISDATE(stg.O_DatePaid) = 1)
							THEN REPLACE(CONVERT(VARCHAR(10), stg.O_DatePaid, 102), '-', '/')
							ELSE stg.O_DatePaid
						END
			, stg.P_DateNotifyMember = 
						CASE WHEN (ISDATE(stg.P_DateNotifyMember) = 1)
							THEN REPLACE(CONVERT(VARCHAR(10), stg.P_DateNotifyMember, 102), '-', '/')
							ELSE stg.P_DateNotifyMember
						END
			, stg.Q_DateNotifyProvider = 
						CASE WHEN (ISDATE(stg.Q_DateNotifyProvider) = 1)
							THEN REPLACE(CONVERT(VARCHAR(10), stg.Q_DateNotifyProvider, 102), '-', '/')
							ELSE stg.Q_DateNotifyProvider
						END
			, stg.R_DateIRE = 
						CASE WHEN (ISDATE(stg.R_DateIRE) = 1)
							THEN REPLACE(CONVERT(VARCHAR(10), stg.R_DateIRE, 102), '-', '/')
							ELSE stg.R_DateIRE
						END
			, stg.IDNrequired = 
						CASE WHEN stg.IDNrequired = 'C'
							THEN 'Y'
							ELSE stg.IDNrequired 
						END
			, stg.T_IssueDescTypeOfService = REPLACE(REPLACE(REPLACE(stg.T_IssueDescTypeOfService, '&lt;', '<'), '&gt;', '>'), '&amp;', '&')
		FROM QNXT_Custom.dbo.Universe2022_Odag3 stg;


		UPDATE  stg
		SET stg.IDNrequired = 'Y'
		FROM QNXT_Custom.dbo.Universe2022_Odag3 stg
		WHERE stg.IDNrequired = 'C'


		---------------------------------------------------------------------------------------------------
		--Begining of GDTG-3056 Universe - Exclude ODAG3 Partially Denied DMR IDN Mail Date
                ----------------------------------------------------------------------------------------------------
		UPDATE  stg
		SET stg.deletedRsn = RTRIM(stg.deletedRsn) + 'IDN mail date does NOT exist so DMR is not included in universe - GDTG-3056'
		FROM QNXT_Custom.dbo.Universe2022_Odag3 stg
		WHERE stg.OldProtocolTable = 'ODAG4' AND stg.M_RequestDisposition = 'Denied' 
	        AND stg.IDN IS NULL 
	        -----------------------------------------------------------------------------------------------------
		--End of GDTG-3056 Universe - Exclude ODAG3 Partially Denied DMR IDN Mail Date
                ------------------------------------------------------------------------------------------------------

		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT > 0)
			ROLLBACK TRANSACTION;


		THROW;
	END CATCH;
