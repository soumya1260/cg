﻿CREATE PROCEDURE [dbo].[spUniverse2022_Odag3DMR]
(
	@batchid VARCHAR(255)
	, @startDate DATE
	, @endDate DATE
)
AS
/*************************************************************************************************************
 * TITLE:			dbo.spUniverse2022_Odag3DMR.sql
 * BUSINESS OWNER:	QNXT Development
 * CREATED BY:		Sandie Nantz
 * CREATE DATE:		06/17/2021
 * 
 * DESCRIPTION:		
 *
 * Modification History: 
 	SDE #:		Developer:		Date:		Desc:
   CHG0146103	Sandie Nantz	06/16/2021	US460219:Universe - CMS Universe 2022 Protocols - Odag3
								11/10/2021  Pull Logic:
									 Approved >$0 submitted by enrollee (E) or enrollee rep (ER) – PeopleSoft check date (column O)
									 Approved = $0 submitted by enrollee (E) – DMR Approval Letter attribute date (column P)
									 Approved = $0 submitted by enrollee rep (ER) – BR AOR Disposition Letter attribute date (column P)
									 Denied submitted by enrollee (E) – IDN mail date (column P)
									 Denied submitted by enrollee rep (ER) – BR AOR Disposition Letter attribute date (column P)
 * CHG				Sandie Nantz	06/14/2022	GDTG-234  P_DateNotifyMember
 * CHG0341591		Sandie Nantz	07/14/2022	GDTG-303-If edits on header - don't look at detail for include/exclude Logic (2017b-GDtG57)
 * CHG0350228		Sandie Nantz	08/08/2022	GDTG-395 Check System Messages for exclusions with EOPs & Remits
 * CHG0310634		Sandie Nantz	08/08/2022	GDTG-500 Universe - ODAG3 DMRs - IDN Flag 
 * CHG0439519		Ratna Kumari	02/14/2023	GDTG-1284 Universe - Latest Changes from Previous branch2023
 * CHG0522611	    Ratna Kumari	04/17/2023	GDTG-1545 - Universe - 2022 ODAG3 Unclean DMR 
 * CHG0550121	    Ratna Kumari	07/07/2023	GDTG-1672 - Universe - ODAG3 IDN Grid Denials
 * CHG0705519	    Ratna Kumari	03/05/2024	GDTG-3065 - Hard code to exclude DMR 24043000008 -No check sent to the member. 
                                                            Voided before it was sent. Should come out of the universe.
 * CHG0709823	    Ratna Kumari	03/07/2024	GDTG-3080 - Universe - ODAG3 DMR PeopleSoft Check Mail Date. 
 * CHG0713188	    Travis Williams	03/12/2024	GDTG-3128 - DMR Update for IDN Flag ... specific member
 **************************************************************************************************************/
BEGIN TRY
		BEGIN TRANSACTION;


		------------------------------------------------------------------------
		-- Truncate QNXT_Custom Table
		------------------------------------------------------------------------
		TRUNCATE TABLE QNXT_Custom.dbo.Universe2022_Odag3DMR;


		------------------------------------------------------------------------
		-- Populate QNXT_Custom Table
		------------------------------------------------------------------------
		INSERT INTO QNXT_Custom.dbo.Universe2022_Odag3DMR
		(
			A_FirstName
			, B_LastName
			, C_EnrolleeID
			, D_ContractID
			, E_Planid
			, F_FDR
			, G_Claimid
			, H_DateReceived
			, I_DateAORReceipt
			, J_DateWOL
			, K_CleanClaim
			, L_ODorRecon
			, M_RequestDisposition
			, N_DateDetermination
			, O_DatePaid
			, P_DateNotifyMember
			, Q_DateNotifyProvider
			, R_DateIRE
			, S_WhoMadeRequest
			, T_IssueDescTypeOfService
			, U_DeniedMedicalNecessity
			, OldProtocolTable
			, QProgramid
			, QClmStatus
			, QDateDue
			, QContracted
			, QDateCreate
			, QDateUpdate
			, QDatePaid
			, PeoplesoftDate
			, QDateStart
			, QDateClean
			, QEnrollid
			, QEdit
			, QMemid
			, QWhoMadeRequest
			, QTotPaid
			, startdate
			, enddate
			, dispositionLetter
			, deletedRsn
			, QBillMax
			, QBRAorMailDate
			, EOB
			, EOP
			, IDN
			, IDNrequired
			, BatchId
			, Rundate
		)
		SELECT DISTINCT ment.firstname AS A_FirstName
						, CONVERT(VARCHAR(50), ment.lastname) AS B_LastName
						, CASE
							  WHEN (LEN(RTRIM(LTRIM(enr.carriermemid)))) = 11
								   THEN enr.carriermemid
							  ELSE ''
						  END AS C_EnrolleeID
						, LEFT(pln.upid, 5) AS D_ContractID
						, SUBSTRING(pln.upid, 6, 3) AS E_Planid
						, 'None' AS F_FDR
						, clm.claimid AS G_Claimid
						, REPLACE(CONVERT(DATE, ISNULL(ClrAttr.effdate, clm.cleandate)), '-', '/') AS H_DateReceived
						, CONVERT(VARCHAR(10)
								  , CASE
										WHEN (AORAttr.thevalue IS NULL)
											 THEN 'None'
										ELSE REPLACE(CONVERT(VARCHAR(10), CONVERT(DATE, AORAttr.thevalue), 102), '.', '/')
									END) AS I_DateAORReceipt
						, 'None' AS J_DateWOL
						, 'Y' AS K_CleanClaim
						, 'OD' AS L_ODorRecon
						, CASE
							  WHEN (cd.denyline = 1)
								   THEN 'Denied'
							  WHEN (clm.status = 'PAID')
								   THEN 'Approved'
							  ELSE 'Denied'
						  END AS M_RequestDisposition
						, ISNULL(REPLACE(CONVERT(DATE, clm.paiddate), '-', '/'), 'None') AS N_DateDetermination
						, 'None' AS O_DatePaid
						, 'None' AS P_DateNotifyMember
						, 'None' AS Q_DateNotifyProvider
						, 'None' AS R_DateIRE
						, CASE pwmtr.PersonWhoMadeTheRequest
							  WHEN 'B'
								   THEN 'E'
							  WHEN 'BR'
								   THEN 'ER'
						  END AS S_WhoMadeRequest --pwmtr.PersonWhoMadeTheRequest 
						, '' AS T_IssueDescTypeOfService
						, 'None' AS U_DeniedMedicalNecessity
						, 'ODAG4' AS OldProtocolTable
						, enr.programid AS QProgramid
						, clm.status AS QClmStatus
						, '' AS QDateDue
						, CASE
							  WHEN (YContract.ruleid = '6035')
								   THEN 'Y'
							  WHEN (YContract.ruleid = '6036')
								   THEN 'N'
							  ELSE ' '
						  END AS QContracted
						, clm.createdate AS QDateCreate
						, clm.lastupdate AS QDateUpdate
						, clm.paiddate AS QDatePaid
						, REPLACE(CONVERT(VARCHAR(10), pplsft.checkdate, 120), '-', '/') AS PeoplesoftDate
						, clm.startdate AS QDateStart
						, ISNULL(ClrAttr.effdate, clm.cleandate) AS QDateClean
						, clm.enrollid AS QenrollId
						, YContract.ruleid AS qEdit
						, mbr.memid AS qmemid
						, pwmtr.PersonWhoMadeTheRequest AS QWhoMadeRequest
						, clm.totalpaid AS QTotPaid
						, @startDate AS startdate
						, @endDate AS enddate
						, dmrApp.thevalue AS dispositionLetter					
						, '' AS deletedRsn
						, '' AS QBillMax --will be using this field for the greatest billed amount
						, adisp.thevalue AS qBRAORMailDate
						, EOB.thevalue
						, eop.thevalue
						, idn.thevalue
						, 'N' AS IDNRequired
						, @batchid
						, GETDATE()
		FROM Plandata_Prod.dbo.claim clm WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.member mbr WITH (NOLOCK) ON (clm.memid = mbr.memid)
		INNER JOIN Plandata_Prod.dbo.entity ment WITH (NOLOCK) ON (mbr.entityid = ment.entid)
		INNER JOIN Plandata_Prod.dbo.enrollkeys enr WITH (NOLOCK) ON (clm.enrollid = enr.enrollid)
		INNER JOIN Plandata_Prod.dbo.benefitplan pln WITH (NOLOCK) ON (enr.planid = pln.planid)
		OUTER APPLY (SELECT TOP 1 1
					 FROM Plandata_Prod.dbo.claimdetail cdtl WITH (NOLOCK)
					 WHERE (cdtl.claimid = clm.claimid)
						   AND (cdtl.status = 'DENY')) cd(denyline)
		LEFT JOIN Plandata_Prod.dbo.claimedit YContract WITH (NOLOCK) ON (YContract.claimid = clm.claimid)
																		 AND (YContract.ruleid IN ('6036', '6035'))
																		 AND (YContract.claimline = 0)
																		 AND (YContract.status = 'WARN')
		JOIN Plandata_Prod.dbo.qattribute QA1 WITH (NOLOCK) ON QA1.description = 'EOB Mail Date' --IN ('EOB Mail Date', 'IDN Mail Date', 'EOP Delivery Date')
		LEFT JOIN Plandata_Prod.dbo.claimattribute eob WITH (NOLOCK) ON eob.claimid = clm.claimid
																		AND eob.attributeid = QA1.attributeid
		JOIN Plandata_Prod.dbo.qattribute QA2 WITH (NOLOCK) ON QA2.description = 'EOP Delivery Date' --IN ('EOB Mail Date', 'IDN Mail Date', 'EOP Delivery Date')
		LEFT JOIN Plandata_Prod.dbo.claimattribute eop WITH (NOLOCK) ON eop.claimid = clm.claimid
																		AND QA2.attributeid = eop.attributeid
		JOIN Plandata_Prod.dbo.qattribute QA3 WITH (NOLOCK) ON QA3.description = 'IDN Mail Date' --IN ('EOB Mail Date', 'IDN Mail Date', 'EOP Delivery Date')
		LEFT JOIN Plandata_Prod.dbo.claimattribute idn WITH (NOLOCK) ON idn.claimid = clm.claimid
																		AND QA3.attributeid = idn.attributeid
		INNER JOIN Plandata_Prod.dbo.qattribute ratr WITH (NOLOCK) ON (ratr.description = 'Clearinghouse Received Date')
		LEFT JOIN Plandata_Prod.dbo.claimattribute ClrAttr WITH (NOLOCK) ON (ratr.attributeid = ClrAttr.attributeid)
																			AND (clm.claimid = ClrAttr.claimid)
		LEFT JOIN Plandata_Prod.dbo.qattribute atr WITH (NOLOCK) ON (atr.description = 'AOR form Receive Date')
		OUTER APPLY (SELECT FIRST_VALUE(aor.thevalue) OVER (ORDER BY aor.thevalue DESC)
					 FROM Plandata_Prod.dbo.claimattribute aor WITH (NOLOCK)
					 WHERE clm.claimid = aor.claimid
						   AND atr.attributeid = aor.attributeid) AORAttr(thevalue)
		LEFT JOIN Plandata_Prod.dbo.billclass bc WITH (NOLOCK) ON (clm.billclasscode <> '')
																  AND (clm.billclasscode = bc.billclasscode)
																  AND (clm.facilitycode = bc.facilitycode)
		LEFT JOIN Plandata_Prod.dbo.claimpendhistory cph WITH (NOLOCK) ON (cph.pendreasonid = 'AORDEV')
																		  AND (cph.claimid = clm.claimid)
		LEFT JOIN Plandata_Prod.dbo.claimedit cedtAOR WITH (NOLOCK) ON (cedtAOR.eobid = 'AOR')
																	   AND (clm.claimid = cedtAOR.claimid)
		CROSS APPLY (SELECT CASE
								WHEN (AORAttr.thevalue IS NOT NULL)
									 THEN 'BR'
								ELSE 'B'
							END PersonWhoMadeTheRequest) pwmtr(PersonWhoMadeTheRequest)
		OUTER APPLY (SELECT ps.QNXT_ChkNbr
							, ps.MemID
							, FIRST_VALUE(ps.PeopleSoft_AttDate) OVER (ORDER BY ps.Filedate DESC)
					 FROM Plandata_Prod.dbo.payvoucher pv WITH (NOLOCK)
					 INNER JOIN Plandata_Prod.dbo.paycheck pc WITH (NOLOCK) ON (pv.paymentid = pc.paymentid)
					 INNER JOIN QNXT_Custom.dbo.PeopleSoft_DMR_CheckDate ps WITH (NOLOCK) ON (pc.checknbr = ps.QNXT_ChkNbr)
																							 AND (ps.MemID = clm.memid)
					 WHERE (clm.claimid = pv.claimid)) pplsft(a, b, checkdate)
		LEFT JOIN Plandata_Prod.dbo.qattribute disp WITH (NOLOCK) ON (disp.description = 'BR AOR Disposition Letter Mail Date')
		OUTER APPLY (SELECT FIRST_VALUE(adsp.thevalue) OVER (ORDER BY adsp.thevalue DESC)
					 FROM Plandata_Prod.dbo.claimattribute adsp WITH (NOLOCK)
					 WHERE clm.claimid = adsp.claimid
						   AND disp.attributeid = adsp.attributeid) adisp(thevalue)
		LEFT JOIN Plandata_Prod.dbo.qattribute admr WITH (NOLOCK) ON (admr.description = 'DMR Approval Letter Sent')
		OUTER APPLY (SELECT FIRST_VALUE(cdmr.thevalue) OVER (ORDER BY cdmr.thevalue DESC)
					 FROM Plandata_Prod.dbo.claimattribute cdmr WITH (NOLOCK)
					 WHERE clm.claimid = cdmr.claimid
						   AND admr.attributeid = cdmr.attributeid) dmrApp(thevalue)
		WHERE ((CONVERT(DATE, pplsft.checkdate) BETWEEN @startDate AND @endDate)
			   OR (CONVERT(DATE, adisp.thevalue) BETWEEN @startDate AND @endDate) --BR AOR Disposition Letter Mail Date'
			   --GDTG-3080 - Commented 'DMR Approval Letter Sent' attribute
			   --OR (CONVERT(DATE, dmrApp.thevalue) BETWEEN @startDate AND @endDate) --DMR Approval Letter Sent
			   OR (CONVERT(DATE, idn.thevalue) BETWEEN @startDate AND @endDate))
			  AND (clm.status IN ('Denied', 'DENY', 'WAITDENY', 'ADJUCATED', 'OPEN', 'PEND', 'PAY', 'WAITPAY', 'PAID'))
			  AND (clm.planid NOT IN ('QMXBP2187', 'QMXBP2038', 'QMXBP1913', 'UQBP000266', 'UQBP000285', 'QMXBP2365', 'UQBP000260'))
			  AND pln.upid NOT LIKE ('S%')
			  AND (clm.reimbursemember = 'Y')
			  AND (clm.claimid NOT LIKE '%A%')
			  AND (clm.claimid NOT LIKE '%R%')
			  AND (clm.enrollid <> '')
			  AND clm.claimid NOT IN ('24043000008');

	    ------------------------------------------------------------------------
		-- Set UnClean Claim Indicator
		------------------------------------------------------------------------
		UPDATE stg
		SET K_CleanClaim = 'N'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		JOIN Plandata_Prod.dbo.claimattribute ca (NOLOCK)  ON ca.claimid = stg.G_Claimid
		JOIN Plandata_Prod.dbo.qattribute q ON q.attributeclass = 'claim' AND  q.attributeid = ca.attributeid
		WHERE ((description LIKE 'Yes%' AND (description LIKE '%Call Made' OR description LIKE '%Urgent Call%'))
				OR description = 'Call Made'
				OR description LIKE 'Member DMR Outreach Attempt Call%');

		------------------------------------------------------------------------
		-- Apply Pull Logic rules
		------------------------------------------------------------------------
		UPDATE stg
		SET stg.TheNewDecisionDate = 
				CASE
						WHEN stg.QTotPaid > 0
							THEN CONVERT(DATE, stg.PeoplesoftDate)
						WHEN stg.QTotPaid = 0
							AND stg.S_WhoMadeRequest = 'E'
							THEN CONVERT(DATE, stg.dispositionLetter) --attribute 'DMR Approval Letter Sent'
						WHEN stg.QTotPaid = 0
							AND stg.S_WhoMadeRequest = 'ER'
							THEN CONVERT(DATE, stg.QBRAorMailDate) --attribute: 'BR AOR Disposition Letter Mail Date'
					END
		FROM  QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE (stg.M_RequestDisposition = 'Approved');


		UPDATE stg
		SET stg.TheNewDecisionDate = 
				CASE
					WHEN stg.S_WhoMadeRequest = 'E'
						THEN CONVERT(DATE, stg.IDN)
					WHEN stg.S_WhoMadeRequest = 'ER'
						THEN CONVERT(DATE, stg.QBRAorMailDate) --attribute: 'BR AOR Disposition Letter Mail Date'
				END
 		FROM  QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE (stg.M_RequestDisposition <> 'Approved');


		UPDATE stg
		SET stg.deletedRsn = 'Not within date parms'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE stg.TheNewDecisionDate NOT BETWEEN stg.startdate AND stg.enddate;

------------------------------------------------------------------------------------------------------------
     	--Begining of GDTG-3080
		--We want to update existing OGAG3 logic to ensure Claims do not populate the Universe without PeopleSoft check mail date.

		--Approved DMR: 
		--•    Pull into universe based on the Peoplesoft check mail date only. 
		--     •    IF the Peoplesoft check mail date is NOT within the universe period THEN claim should not be included.  
		--     •    IF Peoplesoft check mail date NOT present THEN do not populate Universe.

        --Denied DMR:

		--Enrollee submitted criteria s as follows:

		--IF Enrollee submitted THEN brought in by IDN Mail Date.
		--IF IDN mail date value NOT present THEN DMR is NOT pulled into Universe until IDN Mail Date value is present.
		--IF BR AOR Disposition Letter Mail Date attribute
 

		--Enrollee Representative submitted criteria s as follows:

		--AOR Receipt Date attribute value is present.
		--BR AOR Disposition Letter Mail Date attribute NOT present THEN DMR is NOT pulled into Universe until IDN Mail Date value is present.
	   -------------------------------------------------------------------------------------------------------------
		UPDATE  stg
		SET stg.deletedRsn = RTRIM(stg.deletedRsn) +  'Peoplesoft check mail date is NOT within the universe period'
        FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE stg.M_RequestDisposition = 'Approved'
		AND NOT((CONVERT(DATE,PeoplesoftDate) BETWEEN @startDate AND @endDate))
	 
		UPDATE  stg
		SET stg.deletedRsn = RTRIM(stg.deletedRsn) + 'Peoplesoft check mail date is NOT present'
        FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE stg.M_RequestDisposition = 'Approved' AND stg.PeoplesoftDate IS NULL


		UPDATE  stg
		SET stg.deletedRsn = RTRIM(stg.deletedRsn) + 'IDN mail date is NOT within the universe period'
        FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE stg.M_RequestDisposition = 'Denied' 
				AND stg.S_WhoMadeRequest = 'E'
				AND NOT((CONVERT(DATE,IDN) BETWEEN @startDate AND @endDate))
		
		UPDATE  stg
		SET stg.deletedRsn = RTRIM(stg.deletedRsn) + 'IDN mail date is NOT present'
        FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE stg.M_RequestDisposition = 'Denied' 
				AND stg.S_WhoMadeRequest = 'E'
				AND stg.IDN IS NULL
						

		UPDATE  stg
		SET stg.deletedRsn = RTRIM(stg.deletedRsn) + 'AOR Receipt Date is NOT within the universe period'
        FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE stg.M_RequestDisposition = 'Denied' 
				AND stg.S_WhoMadeRequest = 'ER'
				AND NOT((CONVERT(DATE,I_DateAORReceipt) BETWEEN @startDate AND @endDate))
		
		UPDATE  stg
		SET stg.deletedRsn = RTRIM(stg.deletedRsn) + 'AOR Receipt Date is NOT present'
        FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE stg.M_RequestDisposition = 'Denied' 
				AND stg.S_WhoMadeRequest = 'ER'
				AND stg.I_DateAORReceipt IS NULL

	   -------------------------------------------------------------------------------------------------------------
			--End  of GDTG-3080
            -------------------------------------------------------------------------------------------------------------


		------------------------------------------------------------------------
		-- Update PAR/NON PAR - 
		------------------------------------------------------------------------
		UPDATE stg --using PCP contract
		SET stg.QEdit = CASE
							WHEN (c2.contracted = 'Y')
								 THEN '6035'
							ELSE '6036'
						END
			, stg.QContracted = c2.contracted
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
		JOIN Plandata_Prod.dbo.memberpcp AS m (NOLOCK) ON m.enrollid = stg.QEnrollid
		JOIN Plandata_Prod.dbo.affiliation AS a (NOLOCK) ON m.paytoaffilid = a.affiliationid
		JOIN Plandata_Prod.dbo.contractinfo AS c2 (NOLOCK) ON c2.affiliationid = a.affiliationid
															  AND stg.QProgramid = c2.programid
															  AND (m.networkid = c2.networkid
																   OR c2.networkid = '')
															  AND c.startdate BETWEEN c2.effdate AND c2.termdate
															  AND c.contractid = c2.contractid
		WHERE c.claimbypcp IN ('1', '-1')
			  AND ISNULL(stg.QEdit, '') = '';


		UPDATE stg --use payto
		SET stg.QEdit = CASE
							WHEN (c2.contracted = 'Y')
								 THEN '6035'
							ELSE '6036'
						END
			, stg.QContracted = c2.contracted
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
		JOIN Plandata_Prod.dbo.memberpcp AS m (NOLOCK) ON m.enrollid = stg.QEnrollid
		JOIN Plandata_Prod.dbo.affiliation AS a (NOLOCK) ON a.affiliationid = c.affiliationid
		JOIN Plandata_Prod.dbo.contractinfo AS c2 (NOLOCK) ON c2.affiliationid = a.affiliationid
															  AND stg.QProgramid = c2.programid
															  AND (m.networkid = c2.networkid
																   OR c2.networkid = '')
															  AND c.startdate BETWEEN c2.effdate AND c2.termdate
															  AND c.contractid = c2.contractid
		WHERE c.claimbypcp NOT IN ('1', '-1')
			  AND ISNULL(stg.QEdit, '') = '';


		UPDATE stg
		SET stg.QEdit = '6036'
			, stg.QContracted = 'N'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
		WHERE ISNULL(stg.QEdit, '') = '';


		------------------------------------------------------------------------
		-- Remove claim if attribute exists
		------------------------------------------------------------------------	
		UPDATE s
		SET s.deletedRsn = s.deletedRsn + 'Removal Attribute'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR s
		JOIN Plandata_Prod.dbo.claimattribute ca (NOLOCK) ON ca.claimid = s.G_Claimid
		JOIN Plandata_Prod.dbo.qattribute qa WITH (NOLOCK) ON qa.attributeid = ca.attributeid
		WHERE qa.description = 'Paid Incorrectly -  Processor Error';


		------------------------------------------------------------------------
		-- Remove claim if attribute exists
		------------------------------------------------------------------------	
		UPDATE s
		SET s.deletedRsn = s.deletedRsn + 'Dismissed - Claim will be in as a Dismissal-Not a DMR'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR s
		JOIN Plandata_Prod.dbo.claimattribute ca (NOLOCK) ON ca.claimid = s.G_Claimid
		JOIN Plandata_Prod.dbo.qattribute qa WITH (NOLOCK) ON qa.attributeid = ca.attributeid
		WHERE qa.description = 'AOR Dismissal Mail Date';


		------------------------------------------------------------------------
		-- Update deletedRsn
		------------------------------------------------------------------------
		UPDATE stg
		SET stg.deletedRsn = stg.deletedRsn + 'Remove Dismissals (Claim Edit)-'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		INNER JOIN Plandata_Prod.dbo.claimedit cedt WITH (NOLOCK) ON (stg.G_Claimid = cedt.claimid)
																	 AND (cedt.eobid = 'AOR');


		UPDATE stg
		SET stg.deletedRsn = stg.deletedRsn + 'Remove Dismissals (Form Not Received)-'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		INNER JOIN Plandata_Prod.dbo.qattribute ratr WITH (NOLOCK) ON (ratr.description = 'AOR Form not Received')
		INNER JOIN Plandata_Prod.dbo.claimattribute ClrAttr WITH (NOLOCK) ON (ratr.attributeid = ClrAttr.attributeid)
																			 AND (stg.G_Claimid = ClrAttr.claimid);


		UPDATE stg
		SET stg.deletedRsn = stg.deletedRsn + 'Remove Dismissals (Dismissal Attribute)-'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		INNER JOIN Plandata_Prod.dbo.qattribute ratr WITH (NOLOCK) ON (ratr.description = 'AOR Dismissal Mail Date')
		INNER JOIN Plandata_Prod.dbo.claimattribute ClrAttr WITH (NOLOCK) ON (ratr.attributeid = ClrAttr.attributeid)
																			 AND (stg.G_Claimid = ClrAttr.claimid);


		UPDATE stg
		SET stg.deletedRsn = stg.deletedRsn + 'Remove NonDMRs-'
		FROM  QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE (stg.G_Claimid LIKE '%E%');


		UPDATE stg
		SET stg.deletedRsn = stg.deletedRsn + 'Edit 913/Pend = AORDEV & attribute not populated-'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg WITH (NOLOCK)
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (stg.G_Claimid = ce.claimid)
		INNER JOIN Plandata_Prod.dbo.claimpendhistory p WITH (NOLOCK) ON (p.claimid = ce.claimid)
		LEFT JOIN Plandata_Prod.dbo.qattribute atr WITH (NOLOCK) ON (atr.description = 'AOR form Receive Date')
		LEFT JOIN Plandata_Prod.dbo.claimattribute AORAttr WITH (NOLOCK) ON (atr.attributeid = AORAttr.attributeid)
																			AND (ce.claimid = AORAttr.claimid)
		WHERE (ce.ruleid = '913')
			  AND (p.pendreasonid = 'AORDEV')
			  AND (AORAttr.thevalue IS NULL)
			  AND (stg.QDatePaid IS NULL);

		UPDATE stg
		SET stg.deletedRsn = stg.deletedRsn + 'Misdirected Claims-'		
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = stg.G_Claimid)
		WHERE (ce.reason IN ('SUBMT09', 'SUBMT10', '.0001', '.2059', 'IPA', 'WNI', 'DENT102', '.831','2060','.841ASH','.842Eye','SUBMIT11','SUBMIT12','.2066','.3056','D64',
		'HEAR101','HEAR102' ));


		------------------------------------------------------------------------
		-- O_DatePaid
		------------------------------------------------------------------------
		UPDATE stg
		SET stg.O_DatePaid = CONVERT(DATE, stg.PeoplesoftDate) ---REPLACE(CONVERT(VARCHAR(10), peoplesoftDate, 102), '.', '/') )
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE stg.M_RequestDisposition = 'Approved'
			  AND stg.QTotPaid > 0
			  AND ISDATE(stg.PeoplesoftDate) = 1;


		------------------------------------------------------------------------
		-- Create and Populate #t Temp Table
		------------------------------------------------------------------------
		IF OBJECT_ID('tempdb..#t') IS NOT NULL
			DROP TABLE #t;


		SELECT s.M_RequestDisposition AS RequestDisposition
			   , s.G_Claimid AS claimid
			   , ce.status
			   , ce.ruleid
			   , ce.reason
			   , ce.claimline
			   , '        ' AS onEXList
   				   , '   ' AS ExcludeMe	
				   , s.OldProtocolTable
			INTO #t
			FROM QNXT_Custom.dbo.Universe2022_Odag3DMR s WITH (NOLOCK)
			INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = s.G_Claimid)
			WHERE (ce.status = 'DENY')
				  AND (s.M_RequestDisposition = 'Denied')
				  AND (ce.reason > '')			--06/22/2021
			

			INSERT #t (RequestDisposition,claimid, status, ruleid, reason, claimline, onexlist, ExcludeMe, oldProtocolTable)	--06/22/2021
			SELECT s.M_RequestDisposition  AS RequestDisposition
					, s.G_Claimid AS claimid
					, ce.status
					, ce.ruleid
					, cem.messageid 
					, ce.claimline
					, '        ' as onEXList				
					,'   '
					,'Odag4'

			FROM QNXT_Custom.dbo.Universe2022_Odag3DMR s WITH (NOLOCK)  
			INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = s.G_Claimid)
			INNER JOIN Plandata_Prod.dbo.claimeditmessage cem WITH (NOLOCK) ON (ce.claimid = cem.claimid) 
					AND (ce.claimline = cem.claimline) --ousted 052021 AND (ce.reason = cem.messageid)
			WHERE  (s.M_RequestDisposition = 'DENIED')
							AND (ce.status ='DENY') 
							AND (ce.reason = '' AND cem.messageid > ''); --06/22/2021

			INSERT #t (RequestDisposition,claimid, status, ruleid, reason, claimline, onexlist, ExcludeMe,OldProtocolTable)	
			SELECT s.M_RequestDisposition  AS RequestDisposition
					, s.G_Claimid AS claimid
					, ce.status
					, ce.ruleid
					, cer.msgnumber 
					, ce.claimline
					, '        ' as onEXList				
					,'   '
					,s.OldProtocolTable
			FROM QNXT_Custom.dbo.Universe2022_Odag3DMR s WITH (NOLOCK)  
			INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = s.G_Claimid)
			INNER JOIN Plandata_Prod.dbo.claimremit cer WITH (NOLOCK) ON (cer.claimid = s.G_Claimid AND ce.claimline = cer.claimline)
			WHERE  (s.M_RequestDisposition = 'DENIED')
							AND (ce.status ='DENY') ;
			------------------------------------------------------------------------
			-- If claim has Header Deny Edits, get rid of service line edits
			------------------------------------------------------------------------
			DELETE FROM #t 
			WHERE claimline > 0 AND claimid IN (SELECT t2.claimid FROM #t t2 WHERE t2.claimline = 0)

			------------------------------------------------------------------------
			-- PROV-Update onExList in Temp Table - This will put something in extype column if the edit IS to be excluded
			------------------------------------------------------------------------
			UPDATE temp
			SET temp.onEXList = ex.ExType
			FROM #t temp
			INNER JOIN QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK) ON (ex.ExCode = temp.ruleid)
									AND (ex.UniverseName = temp.OldProtocolTable)
			WHERE (ex.ExType = 'rules');


			UPDATE temp
			SET temp.onEXList = ex.ExType
			FROM #t temp
			INNER JOIN QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK) ON (ex.ExCode = temp.reason)
										AND (ex.UniverseName = temp.OldProtocolTable)
			WHERE (ex.ExType IN ('EOB', 'REMIT'));

				------------------------------------------------------------------------
			-- If the service line has Dup Edit ('.1004','.1005','.1019','.1036','.1037','.1041','.1046','.1101','817','826','.CC19','D71','DUP1002','Z110','Z111','Z46','Z47')  
			-- That whole SERVICE LINE should be considered as EXCLUDED  
			------------------------------------------------------------------------
			UPDATE  #t 
			SET #t.onEXList = 'New'
			FROM #t t
			WHERE t.claimline > 0 
					AND (CONCAT(t.claimid, t.claimline)) IN (SELECT DISTINCT CONCAT(t2.claimid,t2.claimline)
								FROM #t t2  
								WHERE t2.claimline > 0
								AND t2.reason IN  ('.1004','.1005','.1019','.1036','.1037','.1041','.1046','.1101','817','826','.CC19','D71','DUP1002','Z110','Z111','Z46','Z47') 
								AND t2.onEXlist = 'REMIT')
					AND onExlist = ''

			------------------------------------------------------------------------
			-- If all edits on the header are on the excluded table, 
			--             EXCLUDE that claim from the universe
			------------------------------------------------------------------------

			UPDATE #t
			SET #t.ExcludeMe = 'Yes'
			WHERE (claimid IN (SELECT DISTINCT claimid
				 FROM #t
				 WHERE claimline = 0
				 GROUP BY claimid
				 HAVING MIN(onEXList) > ''
						AND MAX(onEXList) > ''));

			------------------------------------------------------------------------
			-- If all edits on the header are on the excluded table, 
			--             EXCLUDE that claim from the universe
			------------------------------------------------------------------------

			UPDATE  #t 
			SET #t.excludeme = 'Yes'
			FROM #t 
			WHERE 	(claimid IN (SELECT DISTINCT claimid 
								FROM #t  
								WHERE claimline > 0
								GROUP BY claimid 
							HAVING MIN(onExList) > '' AND  max(onExList) > '') );


			------------------------------------------------------------------------
			-- Update deletedRsn - If left on the table, it should NOT be in the universe
			------------------------------------------------------------------------
			UPDATE stg
			SET deletedRsn = LEFT(deletedRsn + 'All edits on Excluded list-', 350)
			FROM QNXT_Custom.dbo.Universe2022_ODAG3DMR stg (NOLOCK)
			INNER JOIN #t temp ON (temp.claimid = stg.G_Claimid) AND (temp.ExcludeMe = 'Yes')
			WHERE (temp.RequestDisposition = 'DENIED');



		------------------------------------------------------------------------
		-- Drop #t Temp Table
		------------------------------------------------------------------------
		IF OBJECT_ID('tempdb..#t') IS NOT NULL
			DROP TABLE #t;

		------------------------------------------------------------------------
		-- Update IDNrequired
		--1. If there is a denial reason at the header level that is designated on the IDN grid to require an IDN, the IDN flag should be moved to "Y" and logic stops.
		--2. If there is a denial reason at the header level that is designated on the IDN grid to NOT require an IDN or if the denial reason is not on the IDN grid at all, the IDN flag should be moved to "N" and the logic stops.
		--3. If there is NO denial reason at the header level, the logic should move to the line level and make the "Y"/"N" IDN flag determination.
		------------------------------------------------------------------------
		UPDATE stg 
		SET stg.IDNrequired = 'C'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		INNER JOIN Plandata_Prod.dbo.claim c WITH (NOLOCK) ON (c.claimid = stg.G_Claimid)
								AND (c.totalamt > 0)
								AND (c.status IN ('DENY', 'Denied', 'WAITDENY'))
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = stg.G_Claimid)
								AND (ce.status = 'DENY')
								AND (ce.claimline = 0)
		INNER JOIN QNXT_Custom.dbo.Universe_IDN_Reasons dl WITH (NOLOCK) ON (ce.reason = dl.MessageID)
								AND (dl.Status = 'DENY')								
	    WHERE dl.DMR ='Y'


		UPDATE stg
		SET stg.IDNrequired = 'Y'
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = stg.G_Claimid)
								AND (ce.status = 'DENY')
		INNER JOIN Plandata_Prod.dbo.claimdetail cd WITH (NOLOCK) ON (cd.claimid = stg.G_Claimid)
								AND (cd.claimline = ce.claimline)
								AND (cd.claimamt > 0)
								AND (cd.status = 'DENY')
		INNER JOIN QNXT_Custom.dbo.Universe_IDN_Reasons dl WITH (NOLOCK) ON (ce.reason = dl.MessageID)
								AND (dl.Status = 'DENY')								
	    WHERE dl.DMR ='Y'
					AND stg.G_Claimid NOT IN (SELECT cc.claimid
											FROM Plandata_Prod.dbo.claimedit cc WITH (NOLOCK)
											WHERE (cc.claimline = 0)
													AND (cc.status = 'DENY')
													AND (cc.claimid = stg.G_Claimid));


		------------------------------------------------------------------------
		-- Update qBRAORMailDate
		------------------------------------------------------------------------
		UPDATE stg
		SET stg.QBRAorMailDate = REPLACE(CONVERT(VARCHAR(10), CONVERT(DATE, stg.dispositionLetter), 102), '.', '/')
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR  stg
		WHERE (stg.S_WhoMadeRequest = 'E')
			  AND ISDATE(stg.dispositionLetter) = 1;

		------------------------------------------------------------------------
		-- Update P_DateNotifyMember
		--		IF requestor is an 'ER' (Approved & Denied)
		--			Populate BRAOR Disposition Letter mail date value. (adisp=qBRAORMailDate)
		--			
		--		IF requestor is an 'E' 
		--			All Lines are Approved - populate DMR Approval Letter mail date value. (dmrApp-Disposition)
		--			Denied & Approved lines - 
		--					Billed amt > 0 & IDN required is Y = IDN Date
		--					Billed amt > 0 & IDN required is N = EOB Date
		------------------------------------------------------------------------
		
		--  *************************************************
        	--    GDTG-3128
		--    2024 CMS Audit found an issues with  G_Claimid = '23332000015'
        	--    it IDN mail date is not set correctly for this claim. We are going to update this per incident ticket INC9874444.
        	--
        	
		UPDATE stg SET stg.IDNrequired = 'Y' FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg WHERE stg.G_Claimid = '23332000015'
    		
		--  *************************************************
		
		UPDATE stg
		SET stg.P_DateNotifyMember = REPLACE(CONVERT(VARCHAR(10), CONVERT(DATE, stg.QBRAorMailDate), 102), '.', '/')
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE (stg.S_WhoMadeRequest = 'ER')
			  AND (ISDATE(stg.QBRAorMailDate) = 1);

		--all lines paid
		UPDATE stg
		SET stg.P_DateNotifyMember = REPLACE(CONVERT(VARCHAR(10), CONVERT(DATE, stg.dispositionLetter), 102), '.', '/')
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE (stg.S_WhoMadeRequest = 'E')
			  AND (stg.M_RequestDisposition = 'Approved')
			  AND (ISDATE(stg.dispositionLetter) = 1);

		--IDN Required on a deny Service LINE with billed > 0
		UPDATE stg
		SET stg.P_DateNotifyMember = REPLACE(CONVERT(VARCHAR(10), CONVERT(DATE, stg.IDN), 102), '.', '/')
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE (stg.S_WhoMadeRequest = 'E')
			  AND (stg.M_RequestDisposition = 'Denied')
			  AND (ISDATE(stg.IDN) = 1)
		      AND (stg.IDNrequired IN ('C','Y'))

		--IDN NOT Required, a Denied line billed > 0 with IDN = "N"
  		UPDATE stg
		SET stg.P_DateNotifyMember = REPLACE(CONVERT(DATE, stg.EOB), '-', '/')
		FROM QNXT_Custom.dbo.Universe2022_Odag3DMR stg
		WHERE (stg.M_RequestDisposition = 'Denied')
		AND (stg.IDNrequired IN ('N'))
				  AND (ISDATE(stg.EOB) = 1);

		COMMIT TRANSACTION;
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT > 0)
			ROLLBACK TRANSACTION;


		THROW;
	END CATCH;
