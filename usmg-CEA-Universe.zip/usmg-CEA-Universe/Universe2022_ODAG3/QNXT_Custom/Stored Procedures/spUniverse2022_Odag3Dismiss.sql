CREATE PROCEDURE dbo.spUniverse2022_Odag3Dismiss
(
	@batchid VARCHAR(255)
	, @startDate DATE
	, @endDate DATE
)
AS

	/*************************************************************************************************************
 * TITLE:			spUniverse2022_Odag3Dismiss.sql
 * BUSINESS OWNER:	QNXT Development
 * CREATED BY:		Sandie Nantz
 * CREATE DATE:		07/13/2021
 * 
 * DESCRIPTION:		Table 3: Universe Table 3: Payment Organization Determinations and Reconsiderations (PYMT_C) Record Layout
 *								� Include all payment organization determinations and payment reconsiderations the Sponsoring organization Approved, Denied or dismissed from non-contract providers, enrollees, and non-contract pharmacies during the universe request period.
 *										Submit payment organization determinations (claims) based on the date the claim was paid (Column O) or notification of the denial to the provider (if provider submitted the claim - Column Q) or enrollee (if the enrollee submitted the claim � Column P). Submit payment reconsiderations based on the date the overturned reconsideration was paid or, for upheld reconsiderations, submit based on the date the case was forwarded to the IRE. Submit dismissed requests based on the date of the decision to dismiss (Column N).
 *								� Include all payment requests for Part B drugs if applicable.
 *								� Include all payment requests for supplemental services that meet the criteria defined at 42 CFR � 422.100(c)(2).
 *								� If a payment organization determination or reconsideration includes more than one service, include all of the request�s line items in a single row and enter the multiple line items as a single organization determination or reconsideration request.
 *									o Enter any request Denied in whole or in part as Denied.
 *									Enter all fields for a single case in the same time zone. For example, if the Sponsoring organization has systems in EST and CST, all data in a single line item must be in a single time zone.
 *								� Exclude all payment requests processed as:
 *									o duplicate claims,
 *									o payment adjustments,
 *									o reopenings,
 *									o withdrawals, and
 *									o retrospective reviews.
 *								� Exclude all requests for Value Added Items and Services.
 *								� Exclude any payment requests that were Denied due to:
 *									o invalid billing codes,
 *									o eligibility (i.e., enrollees who were not enrolled on the date of service, providers not accepting assignment), or
 *									o recoupment of payment, including pending determination of other primary insurance such as automobile, worker�s compensation, etc.
 *								
 * Modification History: 
 *   SDE #:			Developer:		Date:		Desc:
 *   CHG0146103		Sandie Nantz	06/16/2021	US460219:Universe - CMS Universe 2022 Protocols - Odag3
 *   CHG0341591		Sandie Nantz	06/15/2022	GDTG-304 - K_CleanClaim logic
 *   CHG0350228		Sandie Nantz	08/01/2022	GDTG-351 -Universe - 2017B ODAG13 Logic Column G
 *   CHG0439519		Ratna Kumari	02/14/2023	GDTG-1284 Universe - Latest Changes from Previous branch2023
   **************************************************************************************************************/
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION;


			------------------------------------------------------------------------
			-- Truncate Staging Table
			------------------------------------------------------------------------
			TRUNCATE TABLE QNXT_Custom.dbo.Universe2022_Odag3Dismiss;


			------------------------------------------------------------------------
			-- Insert QNXT Records
			------------------------------------------------------------------------
			INSERT INTO QNXT_Custom.dbo.Universe2022_Odag3Dismiss
			(
				A_FirstName
				, B_LastName
				, C_EnrolleeID
				, D_ContractID
				, E_Planid
				, F_FDR
				, G_Claimid
				, H_DateReceived
				, I_DateAORReceipt
				, J_DateWOL
				, K_CleanClaim
				, L_ODorRecon
				, M_RequestDisposition
				, N_DateDetermination
				, O_DatePaid
				, P_DateNotifyMember
				, Q_DateNotifyProvider
				, R_DateIRE
				, S_WhoMadeRequest
				, T_IssueDescTypeOfService
				, U_DeniedMedicalNecessity
				, OldProtocolTable
				, QProgramid
				, QClmStatus
				, QContracted
				, QDateClean
				, QDateCreate
				, QDateUpdate
				, QDatePaid
				, QDateStart
				, QEnrollid
				, QEdit
				, QMemid
				, QWhoMadeRequest
				, EOB
				, EOP
				, IDN
				, IDNrequired
				, startdate
				, enddate
				, deletedRsn
				, BatchId
				, Rundate
			)
			SELECT ment.firstname AS A_FirstName
				   , CONVERT(VARCHAR(50), ment.lastname) AS B_LastName
				   , CASE
						 WHEN (LEN(RTRIM(LTRIM(enr.carriermemid)))) = 11
							  THEN enr.carriermemid
						 ELSE ''
					 END AS C_EnrolleeID
				   , LEFT(bp.upid, 5) AS D_ContractID
				   , SUBSTRING(bp.upid, 6, 3) AS E_PlanID
				   , 'None' AS F_FDR
				   , clm.claimid AS G_Claimid
				   , FORMAT(ISNULL(catr.effdate, clm.cleandate), 'yyyy/MM/dd') AS H_DateReceived
				   , 'None' AS I_DateAORReceipt
				   , 'None' AS J_DateWOL
				   , 'None' AS K_CleanClaim
				   , 'OD' AS L_ODorRecon
				   , 'Dismissed' AS M_RequestDisposition
				   , FORMAT(TRY_CONVERT(DATE, ClrAttr.thevalue), 'yyyy/MM/dd') AS N_DateDetermination
				   , 'None' AS O_DatePaid
				   , FORMAT(TRY_CONVERT(DATE, ClrAttr.thevalue), 'yyyy/MM/dd') AS P_DateNotifyMember
				   , 'None' AS Q_DateNotifyProvider
				   , 'None' AS R_DateIRE
				   , 'ER' AS S_WhoMadeRequest
				   , 'No AOR Form' AS T_IssueDescTypeOfService
				   , 'None' AS U_DeniedMedicalNecessity
				   , 'ODAG13' AS OldProtocolTable
				   , enr.programid AS QProgamId
				   , clm.status AS QClmStatus
				   , ' ' AS QContracted
				   , ISNULL(ClrAttr.effdate, clm.cleandate) AS QDateClean
				   , clm.createdate AS QDateCreate
				   , clm.lastupdate AS QDateUpdate
				   , clm.paiddate AS QDatePaid
				   , clm.startdate AS QDateStart
				   , clm.enrollid AS QenrollId
				   , '' AS qEdit
				   , mbr.memid AS QMemId
				   , 'ER' AS QWhoMadeRequest
				   , ' ' AS eob
				   , ' ' AS eop
				   , ' ' AS idn
				   , 'N' AS IDNRequired
				   , @startDate AS startdate
				   , @endDate AS enddate
				   , '' AS deletedRsn
				   , @batchid
				   , GETDATE()
			FROM Plandata_Prod.dbo.claim clm WITH (NOLOCK)
			INNER JOIN Plandata_Prod.dbo.claimedit cedt WITH (NOLOCK) ON (clm.claimid = cedt.claimid)
																		 AND (cedt.eobid = 'AOR')
			INNER JOIN Plandata_Prod.dbo.claimattribute ClrAttr WITH (NOLOCK) ON (clm.claimid = ClrAttr.claimid)
			INNER JOIN Plandata_Prod.dbo.qattribute qatr WITH (NOLOCK) ON (qatr.attributeid = ClrAttr.attributeid)
																		  AND (qatr.description = 'AOR Dismissal Mail Date')
			INNER JOIN Plandata_Prod.dbo.enrollkeys enr WITH (NOLOCK) ON (clm.enrollid = enr.enrollid)
																		 AND (clm.enrollid <> '')
			INNER JOIN Plandata_Prod.dbo.member mbr WITH (NOLOCK) ON (clm.memid = mbr.memid)
			INNER JOIN Plandata_Prod.dbo.entity ment WITH (NOLOCK) ON (mbr.entityid = ment.entid)
			INNER JOIN Plandata_Prod.dbo.benefitplan bp WITH (NOLOCK) ON (enr.planid = bp.planid)
			INNER JOIN Plandata_Prod.dbo.affiliation af WITH (NOLOCK) ON (clm.affiliationid = af.affiliationid)
			INNER JOIN Plandata_Prod.dbo.qattribute ratr WITH (NOLOCK) ON (ratr.description = 'Clearinghouse Received Date')
			LEFT JOIN Plandata_Prod.dbo.claimattribute catr WITH (NOLOCK) ON (ratr.attributeid = catr.attributeid)
																			 AND (clm.claimid = catr.claimid)
			OUTER APPLY (SELECT TOP 1 ma.thevalue --new MBI code
						 FROM Plandata_Prod.dbo.memberattribute ma (NOLOCK)
						 WHERE ma.attributeid IN ('C00251792', 'C00303603')
							   AND ma.memid = clm.memid
							   AND clm.startdate BETWEEN ma.effdate AND ma.termdate
							   AND LEN(ma.thevalue) = 11
						 ORDER BY ma.effdate DESC) matr
			WHERE (FORMAT(TRY_CONVERT(DATE, ClrAttr.thevalue), 'yyyy/MM/dd') BETWEEN @startDate AND @endDate)
				  AND (clm.status = 'Denied')
				  AND (clm.reimbursemember = 'Y')
				  AND (bp.upid NOT IN ('TX001', 'TX002', 'TX003', 'IL001', 'IL002', 'IL003', 'H6751001', 'H8423001')) --AND (clm.planid NOT IN ('QMXBP2187','QMXBP2038','QMXBP1913','UQBP000266','UQBP000285'))
				  AND bp.upid NOT LIKE ('S%')
				  AND (clm.claimid NOT LIKE '%A%')
				  AND (clm.claimid NOT LIKE '%R%')
				  AND (clm.paiddate IS NOT NULL);


			------------------------------------------------------------------------
			-- Update PAR/NON PAR
			------------------------------------------------------------------------
			UPDATE stg
			SET stg.QContracted = CASE
									  WHEN (YContract.ruleid = '6035')
										   THEN 'Y'
									  WHEN (YContract.ruleid = '6036') --ELSE 'NCP'
										   THEN 'N'
								  END
				, stg.QEdit = YContract.ruleid
			FROM QNXT_Custom.dbo.Universe2022_Odag3Dismiss stg
			INNER JOIN Plandata_Prod.dbo.claimedit YContract WITH (NOLOCK) ON (YContract.claimid = stg.G_Claimid)
																			  AND (YContract.ruleid IN ('6035', '6036'))
																			  AND (YContract.claimline = 0)
																			  AND (YContract.status = 'WARN');


			------------------------------------------------------------------------
			-- Update PAR/NON PAR - only if I_ProviderType = '' (no 6035/6036 edit)
			------------------------------------------------------------------------
			UPDATE stg --using PCP contract
			SET stg.QEdit = CASE
								WHEN c2.contracted = 'Y'
									 THEN '6035'
								ELSE '6036'
							END
				, stg.QContracted = c2.contracted
			FROM QNXT_Custom.dbo.Universe2022_Odag3Dismiss stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
			JOIN Plandata_Prod.dbo.memberpcp AS m (NOLOCK) ON m.enrollid = stg.QEnrollid
			JOIN Plandata_Prod.dbo.affiliation AS a (NOLOCK) ON m.paytoaffilid = a.affiliationid
			JOIN Plandata_Prod.dbo.contractinfo AS c2 (NOLOCK) ON c2.affiliationid = a.affiliationid
																  AND stg.QProgramid = c2.programid
																  AND (m.networkid = c2.networkid
																	   OR c2.networkid = '')
																  AND c.startdate BETWEEN c2.effdate AND c2.termdate
																  AND c.contractid = c2.contractid
			WHERE c.claimbypcp IN ('1', '-1')
				  AND ISNULL(stg.QEdit, '') = '';


			UPDATE stg --using payto
			SET stg.QEdit = CASE
								WHEN c2.contracted = 'Y'
									 THEN '6035'
								ELSE '6036'
							END
				, stg.QContracted = c2.contracted
			FROM QNXT_Custom.dbo.Universe2022_Odag3Dismiss stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
			JOIN Plandata_Prod.dbo.memberpcp AS m (NOLOCK) ON m.enrollid = stg.QEnrollid
			JOIN Plandata_Prod.dbo.affiliation AS a (NOLOCK) ON a.affiliationid = c.affiliationid
			JOIN Plandata_Prod.dbo.contractinfo AS c2 (NOLOCK) ON c2.affiliationid = a.affiliationid
																  AND stg.QProgramid = c2.programid
																  AND (m.networkid = c2.networkid
																	   OR c2.networkid = '')
																  AND c.startdate BETWEEN c2.effdate AND c2.termdate
																  AND c.contractid = c2.contractid
			WHERE c.claimbypcp NOT IN ('1', '-1')
				  AND ISNULL(stg.QEdit, '') = '';


			--Now try to find without the claim contractID
			UPDATE stg --using PCP contract
			SET stg.QEdit = CASE
								WHEN c2.contracted = 'Y'
									 THEN '6035'
								ELSE '6036'
							END
				, stg.QContracted = c2.contracted
			FROM QNXT_Custom.dbo.Universe2022_Odag3Dismiss stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
			JOIN Plandata_Prod.dbo.memberpcp AS m (NOLOCK) ON m.enrollid = stg.QEnrollid
			JOIN Plandata_Prod.dbo.affiliation AS a (NOLOCK) ON m.paytoaffilid = a.affiliationid
			JOIN Plandata_Prod.dbo.contractinfo AS c2 (NOLOCK) ON c2.affiliationid = a.affiliationid
																  AND stg.QProgramid = c2.programid
																  AND (m.networkid = c2.networkid
																	   OR c2.networkid = '')
																  AND c.startdate BETWEEN c2.effdate AND c2.termdate
			--			AND		c.contractid = c2.contractid
			WHERE c.claimbypcp IN ('1', '-1')
				  AND ISNULL(stg.QEdit, '') = '';


			UPDATE stg --using payto
			SET stg.QEdit = CASE
								WHEN c2.contracted = 'Y'
									 THEN '6035'
								ELSE '6036'
							END
				, stg.QContracted = c2.contracted
			FROM QNXT_Custom.dbo.Universe2022_Odag3Dismiss stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
			JOIN Plandata_Prod.dbo.memberpcp AS m (NOLOCK) ON m.enrollid = stg.QEnrollid
			JOIN Plandata_Prod.dbo.affiliation AS a (NOLOCK) ON a.affiliationid = c.affiliationid
			JOIN Plandata_Prod.dbo.contractinfo AS c2 (NOLOCK) ON c2.affiliationid = a.affiliationid
																  AND stg.QProgramid = c2.programid
																  AND (m.networkid = c2.networkid
																	   OR c2.networkid = '')
																  AND c.startdate BETWEEN c2.effdate AND c2.termdate
			--		AND		c.contractid = c2.contractid
			WHERE c.claimbypcp NOT IN ('1', '-1')
				  AND ISNULL(stg.QEdit, '') = '';


			UPDATE stg
			SET stg.QEdit = '6036'
				, stg.QContracted = 'N'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Dismiss stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
			WHERE ISNULL(stg.QEdit, '') = '';


			UPDATE stg
			SET stg.K_CleanClaim = 'N'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Dismiss stg
			WHERE stg.L_ODorRecon = 'OD' AND M_RequestDisposition = 'Dismissed';

			COMMIT TRANSACTION;
		END TRY
		BEGIN CATCH
			IF (@@TRANCOUNT > 0)
				ROLLBACK TRANSACTION;


			THROW;
		END CATCH;
	END;
GO