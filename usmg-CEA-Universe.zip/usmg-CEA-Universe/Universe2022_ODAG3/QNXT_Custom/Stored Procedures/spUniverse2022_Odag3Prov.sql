﻿CREATE PROCEDURE [dbo].[spUniverse2022_Odag3Prov]
(
	@batchid VARCHAR(255)
	, @startDate DATE
	, @endDate DATE
)
AS

/*************************************************************************************************************
 * TITLE:			spUniverse2022_Odag3Prov.sql
 * BUSINESS OWNER:	QNXT Development
 * CREATED BY:		Sandie Nantz
 * CREATE DATE:		06/16/2021
 * 
 * DESCRIPTION:		Table 3: Universe Table 3: Payment Organization Determinations and Reconsiderations (PYMT_C) Record Layout
 *								• Include all payment organization determinations and payment reconsiderations the Sponsoring organization Approved, Denied or dismissed from non-contract providers, enrollees, and non-contract pharmacies during the universe request period.
 *										Submit payment organization determinations (claims) based on the date the claim was paid (Column O) or notification of the denial to the provider (if provider submitted the claim - Column Q) or enrollee (if the enrollee submitted the claim – Column P). Submit payment reconsiderations based on the date the overturned reconsideration was paid or, for upheld reconsiderations, submit based on the date the case was forwarded to the IRE. Submit dismissed requests based on the date of the decision to dismiss (Column N).
 *								• Include all payment requests for Part B drugs if applicable.
 *								• Include all payment requests for supplemental services that meet the criteria defined at 42 CFR § 422.100(c)(2).
 *								• If a payment organization determination or reconsideration includes more than one service, include all of the request’s line items in a single row and enter the multiple line items as a single organization determination or reconsideration request.
 *									o Enter any request Denied in whole or in part as Denied.
 *									Enter all fields for a single case in the same time zone. For example, if the Sponsoring organization has systems in EST and CST, all data in a single line item must be in a single time zone.
 *								• Exclude all payment requests processed as:
 *									o duplicate claims,
 *									o payment adjustments,
 *									o reopenings,
 *									o withdrawals, and
 *									o retrospective reviews.
 *								• Exclude all requests for Value Added Items and Services.
 *								• Exclude any payment requests that were Denied due to:
 *									o invalid billing codes,
 *									o eligibility (i.e., enrollees who were not enrolled on the date of service, providers not accepting assignment), or
 *									o recoupment of payment, including pending determination of other primary insurance such as automobile, worker’s compensation, etc.
 *								
 * Modification History: 
 *   SDE #:			Developer:		Date:		Desc:
 *   CHG0146103		Sandie Nantz	06/16/2021	US460219:Universe - CMS Universe 2022 Protocols - Odag3
									11/09/2021  Prov Claims - Column Q – EOP mail date (regardless of payment) or “None”
															  Column O – Use EOP date if payment on claim > $0—“NONE” for all others
									1/25/2022	Prov Claim - P_DateNotifyMember =  move eob regardless of requestdisposition
 * CHG0341591		Sandie Nantz	07/12/2022	GDTG-302-New List for Medicare Reclamation Providers
 * CHG0341591		Sandie Nantz	07/14/2022	GDTG-303-If edits on header - don't look at detail for include/exclude Logic (2017b-GDtG57)
 * CHG0350228		Sandie Nantz	08/08/2022	GDTG-395 Check System Messages for exclusions with EOPs & Remits
 							this relese includes these tickets: GDTG-352 ODAG 3 DMR Column_O-Paid Date format
                                                                                            GDTG-393 Universe - 2022 ODAG3 Column T Logic
                                                                                            GDTG-395 Universe - ODAG3 - System Message Logic Remit/EOBs
                                                                                            GDTG-351 -Universe - 2017B ODAG13 Logic Column G
*  CHG0439519		Ratna Kumari	02/14/2023	GDTG-1284 Universe - Latest Changes from Previous branch2023
*  CHG0709823		Travis Williams	03/07/2023	GDTG-3079 2024-Audit-Business excluded provider
*  GDTG-3172        Travis Williams    03/15/2023    GDTG-3172 2024-Audit-Business fix for specific claim number
   **************************************************************************************************************/
	BEGIN
		BEGIN TRY
			SET XACT_ABORT ON;


			BEGIN TRANSACTION;
			

			------------------------------------------------------------------------
			-- Truncate Staging Table
			------------------------------------------------------------------------
			TRUNCATE TABLE QNXT_Custom.dbo.Universe2022_Odag3Prov;


			------------------------------------------------------------------------
			-- Insert QNXT Records
			------------------------------------------------------------------------
			INSERT INTO QNXT_Custom.dbo.Universe2022_Odag3Prov
			(
				A_FirstName
				, B_LastName
				, C_EnrolleeID
				, D_ContractID
				, E_Planid
				, F_FDR
				, G_Claimid
				, H_DateReceived
				, I_DateAORReceipt
				, J_DateWOL
				, K_CleanClaim
				, L_ODorRecon
				, M_RequestDisposition
				, N_DateDetermination
				, O_DatePaid
				, P_DateNotifyMember
				, Q_DateNotifyProvider
				, R_DateIRE
				, S_WhoMadeRequest
				, T_IssueDescTypeOfService
				, U_DeniedMedicalNecessity
				, OldProtocolTable
				, QProgramid
				, QClmStatus
				, QContracted
				, QDateClean
				, QDateCreate
				, QDateUpdate
				, QDatePaid
				, QTotPaid
				, TheNewDecisionDate
				, QDateStart
				, QEnrollid
				, QEdit
				, QMemid
				, QWhoMadeRequest
				, EOB
				, EOP
				, IDN
				, IDNrequired
				, startdate
				, enddate
				, deletedRsn
				, BatchId
				, Rundate
			)
			SELECT DISTINCT ment.firstname AS A_FirstName
							, CONVERT(VARCHAR(50), ment.lastname) AS B_LastName
							, CASE
								  WHEN (LEN(RTRIM(LTRIM(enr.carriermemid)))) = 11
									   THEN enr.carriermemid
								  ELSE ''
							  END AS C_EnrolleeId
							, LEFT(bp.upid, 5) AS D_ContractID
							, SUBSTRING(bp.upid, 6, 3) AS E_PlanID
							, 'None' AS F_FDR
							, clm.claimid AS G_Claimid
							, REPLACE(CONVERT(DATE, ISNULL(ClrAttr.effdate, clm.cleandate)), '-', '/') AS H_DateReceived
							, 'None' AS I_DateAORReceipt
							, 'None' AS J_DateWOL
							, 'Y' AS K_CleanClaim
							, 'OD' AS L_ODorRecon
							, CASE
								  WHEN (cd.denyline = 1)
									   THEN 'Denied'
								  WHEN (clm.status = 'PAID')
									   THEN 'Approved'
								  ELSE 'Denied'
							  END AS M_RequestDisposition
							, ISNULL(REPLACE(CONVERT(DATE, clm.paiddate), '-', '/'), 'None') AS N_DateDetermination
							, 'None' AS O_DatePaid
							, 'None' AS P_DateNotifyMember
							, ISNULL(REPLACE(CONVERT(DATE, eop.thevalue), '-', '/'), 'None') AS Q_DateNotifyProvider
							, 'None' AS R_DateIRE
							, '' AS S_WhoMadeRequest
							, '' AS T_IssueDescTypeOfService
							, 'None' AS U_DeniedMedicalNecessity
							, 'ODAG3' AS OldProtocolTable
							, enr.programid AS QProgamId
							, clm.status AS QClmStatus
							, CASE
								  WHEN (YContract.ruleid = '6035')
									   THEN 'Y'
								  WHEN (YContract.ruleid = '6036') --ELSE 'NCP'
									   THEN 'N'
								  ELSE ' '
							  END AS QContracted
							, ISNULL(ClrAttr.effdate, clm.cleandate) AS QDateClean
							, clm.createdate AS QDateCreate
							, clm.lastupdate AS QDateUpdate
							, clm.paiddate AS QDatePaid
							, clm.totalpaid
							, eop.thevalue
							, clm.startdate AS QDateStart
							, clm.enrollid AS QenrollId
							, CASE
								  WHEN YContract.ruleid IS NOT NULL
									   THEN YContract.ruleid
								  ELSE ' '
							  END AS qEdit
							, mbr.memid AS QMemId
							, '' AS QWhoMadeRequest
							, EOB.thevalue
							, eop.thevalue
							, idn.thevalue
							, 'N' AS IDNRequired
							, @startDate AS startdate
							, @endDate AS enddate
							, '' AS deletedRsn
							, @batchid
							, GETDATE()
			FROM Plandata_Prod.dbo.claim clm WITH (NOLOCK)
			INNER JOIN Plandata_Prod.dbo.enrollkeys enr WITH (NOLOCK) ON (clm.enrollid = enr.enrollid)
			INNER JOIN Plandata_Prod.dbo.member mbr WITH (NOLOCK) ON (clm.memid = mbr.memid)
			INNER JOIN Plandata_Prod.dbo.entity ment WITH (NOLOCK) ON (mbr.entityid = ment.entid)
			INNER JOIN Plandata_Prod.dbo.benefitplan bp WITH (NOLOCK) ON (enr.planid = bp.planid)
			OUTER APPLY (SELECT TOP 1 1
						 FROM Plandata_Prod.dbo.claimdetail cdtl WITH (NOLOCK)
						 WHERE (cdtl.claimid = clm.claimid)
							   AND (cdtl.status = 'DENY')) cd(denyline)
			INNER JOIN Plandata_Prod.dbo.qattribute ratr WITH (NOLOCK) ON (ratr.description = 'Clearinghouse Received Date')
			LEFT JOIN Plandata_Prod.dbo.claimattribute ClrAttr WITH (NOLOCK) ON (ratr.attributeid = ClrAttr.attributeid)
																				AND (clm.claimid = ClrAttr.claimid)
			LEFT JOIN Plandata_Prod.dbo.billclass bc WITH (NOLOCK) ON (clm.formtype <> '1500')
																	  AND (clm.billclasscode <> '')
																	  AND (clm.billclasscode = bc.billclasscode)
																	  AND (clm.facilitycode = bc.facilitycode)
			JOIN Plandata_Prod.dbo.qattribute QA1 WITH (NOLOCK) ON QA1.description = 'EOB Mail Date' --IN ('EOB Mail Date', 'IDN Mail Date', 'EOP Delivery Date')
			LEFT JOIN Plandata_Prod.dbo.claimattribute eob WITH (NOLOCK) ON eob.claimid = clm.claimid
																			AND eob.attributeid = QA1.attributeid
			JOIN Plandata_Prod.dbo.qattribute QA2 WITH (NOLOCK) ON QA2.description = 'EOP Delivery Date' --IN ('EOB Mail Date', 'IDN Mail Date', 'EOP Delivery Date')
			LEFT JOIN Plandata_Prod.dbo.claimattribute eop WITH (NOLOCK) ON eop.claimid = clm.claimid
																			AND QA2.attributeid = eop.attributeid
			JOIN Plandata_Prod.dbo.qattribute QA3 WITH (NOLOCK) ON QA3.description = 'IDN Mail Date' --IN ('EOB Mail Date', 'IDN Mail Date', 'EOP Delivery Date')
			LEFT JOIN Plandata_Prod.dbo.claimattribute idn WITH (NOLOCK) ON idn.claimid = clm.claimid
																			AND QA3.attributeid = idn.attributeid
			LEFT JOIN Plandata_Prod.dbo.claimedit YContract WITH (NOLOCK) ON (YContract.claimid = clm.claimid)
																			 AND (YContract.ruleid IN ('6036', '6035'))
																			 AND (YContract.claimline = 0)
																			 AND (YContract.status = 'WARN')
			LEFT JOIN Plandata_Prod.dbo.qattribute atr WITH (NOLOCK) ON (atr.description = 'AOR form Receive Date')
			OUTER APPLY (SELECT FIRST_VALUE(aor.thevalue) OVER (ORDER BY aor.thevalue DESC)
						 FROM Plandata_Prod.dbo.claimattribute aor WITH (NOLOCK)
						 WHERE clm.claimid = aor.claimid
							   AND atr.attributeid = aor.attributeid) AORAttr(thevalue)
			WHERE ((CONVERT(DATE, eop.thevalue) BETWEEN @startDate AND @endDate))
				  AND (bp.upid NOT IN ('TX001', 'TX002', 'TX003', 'IL001', 'IL002', 'IL003', 'H6751001', 'H8423001'))
				  AND bp.upid NOT LIKE ('S%')
				  AND (clm.reimbursemember = 'N')
				  AND (clm.claimid NOT LIKE '%R%')
				  AND (clm.claimid NOT LIKE '%A%')
				  AND (clm.enrollid <> '')
				  AND (mbr.memid NOT IN ('QMXM00034912630'))
				  AND (clm.status IN ('Denied', 'DENY', 'WAITDENY', 'ADJUCATED', 'OPEN', 'PEND', 'PAY', 'WAITPAY', 'PAID'))
				  AND (clm.provid NOT IN ('QMP000004241806', 'QMP000005226745', 'HSVEN0000033767', 'QMP000004681051'
							  , 'QMP000004394821', 'QMP000004326247', 'QMP000004337898', 'QMP000004502076'
							  , 'HSVEN0000030704', 'QMP000004248827', 'QMP000004457187', 'QMP000004310657'
							  , 'QMP000004309407', 'QMP000005230206', 'QMP000004592602', 'QMP000004407633'
							  , 'QMP000004250262', 'QMP000004296390', 'QMP000004410526', 'QMP000004710348'
							  , 'QMP000004385982', 'QMP000004766734', 'QMP000004326456', 'QMP000004298549'
							  , 'QMP000004600639', 'QMP000004696002', 'QMP000005152835', 'QMP000004362976'
							  , 'QMP000004681228', 'QMP000004788690', 'QMP000005084791', 'QMP000004308520'
							  , 'QMP000004385991', 'QMP000004708382', 'QMP000005100805', 'QMP000004288104'
							  , 'QMP000004394888', 'QMP000004344231', 'QMP000004749771', 'QMP000004840344'
							  , 'QMP000004385022', 'QMP000004322306', 'QMP000004691146', 'QMP000004450141'
							  , 'QMP000004304957', 'QMP000004457186', 'QMP000004256438', 'QMP000004385026'
							  , 'QMP000004679964', 'QMP000004346394', 'QMP000005227491', 'QMP000004646760'
							  , 'QMP000005084782', 'QMP000004449241', 'QMP000004488057', 'QMP000004315232'
							  , 'QMP000004309400', 'QMP000004188264', 'QMP000005058247', 'QMP000003855289'
							  , 'QMP000005067008', 'QMP000004323885', 'QMP000004288534', 'QMP000004394453'
							  , 'HSFAC0000002375', 'QMP000004470752', 'QMP000004310675', 'QMP000004766763'
							  , 'QMP000005067084', 'QMP000004360670', 'QMP000004722319', 'QMP000004313779'
							  , 'QMP000005191518', 'HSSPC0000002850', 'QMP000004406429', 'QMP000004305357'
							  , 'HSANC0000004454', 'QMP000004313782', 'QMP000004385975', 'QMP000004312184'
							  , 'QMP000004408020', 'QMP000004309401', 'QMP000004403801', 'QMP000004382068'
							  , 'HSVEN0000033791', 'QMP000004386904', 'QMP000004385007', 'QMP000004309274'
							  , 'QMP000004310613', 'QMP000004294503', 'QMP000005084764', 'QMP000004323864'
							  , 'QMP000004385959', 'QMP000005161128', 'QMP000005122726', 'QMP000005135856'
							  , 'QMP000004469383', 'QMP000004443002', 'QMP000004323909', 'QMP000004453854'
							  , 'QMP000004679445', 'QMP000004630486', 'QMP000004310379', 'QMP000004418932'
							  , 'QMP000004624028', 'QMP000004840302', 'QMP000004407637', 'QMP000004705869'
							  , 'QMP000004538128'));

            ----------------------------------------------------------------------------------------------------------------------------------
            -- Beging of-GDTG-307 92024-Audit-Business excluded provider'
            -----------------------------------------------------------------------------------------------------------------------------------

            UPDATE stg
            SET deletedrsn = '2024-Audit-GDTG-3079-Business excluded provider'
            FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
            JOIN Plandata_Prod.dbo.claim c (NOLOCK) ON c.claimid = stg.G_Claimid
            JOIN plandata_prod.dbo.affiliation a (NOLOCK) ON c.affiliationid = a.affiliationid
            JOIN Plandata_Prod.dbo.provider payto (NOLOCK) ON payto.provid = a.affiliateid   
            WHERE payto.provid IN ('QMP000005134684','QMP000005924832','QMP000004339505','QMP000004395298','QMP000004844642',
			                       'QMP000003705663','QMP000004867074','QMP000005476957','QMP000003761505','QMP000005216138',
								   'QMP000005606020','QMP000004521708','QMP000004419371','QMP000004458731','QMP000005781084',
								   'QMP000005588819','QMP000005476958','QMP000004400109','QMP000004413295','HSVEN0000003295',
								   'QMP000004027620','QMP000005455717')

								   

            --------------------------------------------------------------------------------------------------------------------------------
            -- End of-GDTG-30792024-Audit-Business excluded provider'
            ---------------------------------------------------------------------------------------------------------------------------------

			------------------------------------------------------------------------
			-- Change Request Disposition to “Denied”
			--When the request disposition is “Approved” and 
			-- Edit 116 is present on the claim --NOT 'OKAY'
			-- IDN mail date exists (ODAG 3 only)
			------------------------------------------------------------------------
			UPDATE stg
			SET stg.M_RequestDisposition = 'Denied'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON ce.claimid = stg.G_Claimid
																 AND ce.ruleid = '116'
																 AND ce.status <> 'OKAY'
			JOIN Plandata_Prod.dbo.qattribute QA WITH (NOLOCK) ON QA.description = 'IDN Mail Date'
			JOIN Plandata_Prod.dbo.claimattribute CA WITH (NOLOCK) ON CA.claimid = stg.G_Claimid
																	  AND QA.attributeid = CA.attributeid
			WHERE stg.M_RequestDisposition = 'Approved';


			------------------------------------------------------------------------
			-- Update PAR/NON PAR - only if  stg.QEdit = ' ' (no 6035/6036 edit)
			------------------------------------------------------------------------
			UPDATE stg --using PCP contract
			SET stg.QEdit = CASE
								WHEN (c2.contracted = 'Y')
									 THEN '6035'
								ELSE '6036'
							END
				, stg.QContracted = c2.contracted
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
			JOIN Plandata_Prod.dbo.memberpcp AS m (NOLOCK) ON m.enrollid = stg.QEnrollid
			JOIN Plandata_Prod.dbo.affiliation AS a (NOLOCK) ON m.paytoaffilid = a.affiliationid
			JOIN Plandata_Prod.dbo.contractinfo AS c2 (NOLOCK) ON c2.affiliationid = a.affiliationid
																  AND stg.QProgramid = c2.programid
																  AND (m.networkid = c2.networkid
																	   OR c2.networkid = '')
																  AND c.startdate BETWEEN c2.effdate AND c2.termdate
																  AND c.contractid = c2.contractid
			WHERE c.claimbypcp IN ('1', '-1')
				  AND stg.QEdit = ' ';


			UPDATE stg --using payto
			SET stg.QEdit = CASE
								WHEN (c2.contracted = 'Y')
									 THEN '6035'
								ELSE '6036'
							END
				, stg.QContracted = c2.contracted
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
			JOIN Plandata_Prod.dbo.memberpcp AS m (NOLOCK) ON m.enrollid = stg.QEnrollid
			JOIN Plandata_Prod.dbo.affiliation AS a (NOLOCK) ON a.affiliationid = c.affiliationid
			JOIN Plandata_Prod.dbo.contractinfo AS c2 (NOLOCK) ON c2.affiliationid = a.affiliationid
																  AND stg.QProgramid = c2.programid
																  AND (m.networkid = c2.networkid
																	   OR c2.networkid = '')
																  AND c.startdate BETWEEN c2.effdate AND c2.termdate
																  AND c.contractid = c2.contractid
			WHERE c.claimbypcp NOT IN ('1', '-1')
				  AND stg.QEdit = ' ';


			--Now try to find without the claim contractID
			UPDATE stg --using PCP contract
			SET stg.QEdit = CASE
								WHEN (c2.contracted = 'Y')
									 THEN '6035'
								ELSE '6036'
							END
				, stg.QContracted = c2.contracted
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
			JOIN Plandata_Prod.dbo.memberpcp AS m (NOLOCK) ON m.enrollid = stg.QEnrollid
			JOIN Plandata_Prod.dbo.affiliation AS a (NOLOCK) ON m.paytoaffilid = a.affiliationid
			JOIN Plandata_Prod.dbo.contractinfo AS c2 (NOLOCK) ON c2.affiliationid = a.affiliationid
																  AND stg.QProgramid = c2.programid
																  AND (m.networkid = c2.networkid
																	   OR c2.networkid = '')
																  AND c.startdate BETWEEN c2.effdate AND c2.termdate
			--			AND		c.contractid = c2.contractid
			WHERE c.claimbypcp IN ('1', '-1')
				  AND stg.QEdit = ' ';


			UPDATE stg --using payto
			SET stg.QEdit = CASE
								WHEN (c2.contracted = 'Y')
									 THEN '6035'
								ELSE '6036'
							END
				, stg.QContracted = c2.contracted
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
			JOIN Plandata_Prod.dbo.memberpcp AS m (NOLOCK) ON m.enrollid = stg.QEnrollid
			JOIN Plandata_Prod.dbo.affiliation AS a (NOLOCK) ON a.affiliationid = c.affiliationid
			JOIN Plandata_Prod.dbo.contractinfo AS c2 (NOLOCK) ON c2.affiliationid = a.affiliationid
																  AND stg.QProgramid = c2.programid
																  AND (m.networkid = c2.networkid
																	   OR c2.networkid = '')
																  AND c.startdate BETWEEN c2.effdate AND c2.termdate
			--		AND		c.contractid = c2.contractid
			WHERE c.claimbypcp NOT IN ('1', '-1')
				  AND stg.QEdit = ' ';


			UPDATE stg
			SET stg.QEdit = '6036'
				, stg.QContracted = 'N'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid
			WHERE stg.QEdit = ' ';


			UPDATE stg
			SET stg.S_WhoMadeRequest = CASE
										   WHEN stg.QEdit = '6036'
												THEN 'NCP'
										   ELSE 'CP'
									   END
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			JOIN Plandata_Prod.dbo.claim AS c (NOLOCK) ON c.claimid = stg.G_Claimid;


			------------------------------------------------------------------------
			-- Update deletedRsn
			------------------------------------------------------------------------
			UPDATE stg
			SET stg.deletedRsn = stg.deletedRsn + 'Provider Contracted-'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			WHERE (stg.QEdit <> '6036');


			UPDATE stg
			SET stg.deletedRsn = stg.deletedRsn + 'BillingCode-'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = stg.G_Claimid)
			WHERE (ce.reason IN ('.004', '.013', '.017', '.018', '.1001', '.1002', '.1003', '.1006', '.1011', '.1013', '.1014', '.1015', '.1022', '.1023', '.1054', '.1062', '.1078', '.1079', '.1099', '.1113', '.1114', '.1183', '.1185', '.1189', '.2006', '.2017', '.42', '.CC20', 'D26', 'D27', 'D29', 'D56', 'D63', 'D83', 'D84', 'INVALID01', 'INVALID02', 'INVALID03', 'INVALID04', 'INVALID05', 'INVALID06', 'INVALID07', 'M0026', 'M0027', 'M0031', 'M0032', 'M0033', 'M0034', 'M0035', 'M0041', 'M0042', 'M0043', 'M0045', 'M0046', 'M0047', 'M0075', 'M0076', 'MISS101', 'MISS102', 'MISS103', 'MISS104', 'MISS105', 'MISS106', 'MISS107', 'NDC1012', 'R321', 'R322', 'R323', 'R324', 'R325', 'Z103', 'Z111', 'Z113', 'Z116', 'Z123', 'Z43', 'Z67', 'Z77'))
				  OR (ce.eobid IN ('D26', 'D27', 'D29', 'D56', 'D63', 'D83', 'D84', 'M0026', 'M0027', 'M0031', 'M0032', 'M0033', 'M0034', 'M0035', 'M0041', 'M0042', 'M0043', 'M0045', 'M0046', 'M0047'));


			UPDATE stg
			SET stg.deletedRsn = stg.deletedRsn + 'Misdirected Claims-'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = stg.G_Claimid)
			WHERE (ce.reason IN ('SUBMT09', 'SUBMT10', '.0001', '.2059', 'IPA', 'WNI', 'DENT102', '.831','2060','.841ASH','.842Eye','SUBMIT11','SUBMIT12','.2066','.3056','D64',
			'HEAR101','HEAR102' ));


			------------------------------------------------------------------------
			-- Update K_CleanClaim
			------------------------------------------------------------------------
			UPDATE stg
			SET stg.K_CleanClaim = 'N'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			INNER JOIN Plandata_Prod.dbo.qattribute atr WITH (NOLOCK) ON (atr.description = 'Unclean–Letter Sent Correctly')
			INNER JOIN Plandata_Prod.dbo.claimattribute ca WITH (NOLOCK) ON (ca.attributeid = atr.attributeid)
																			AND (stg.G_Claimid = ca.claimid)
			INNER JOIN Plandata_Prod.dbo.attributegroup ag WITH (NOLOCK) ON (ag.attributeid = atr.attributeid)
			INNER JOIN Plandata_Prod.dbo.attributegrouphdr agh (NOLOCK) ON (ag.attributegroupid = agh.attributegroupid)
																		   AND (agh.description = 'Dev Outreach 1');


			UPDATE stg
			SET stg.K_CleanClaim = 'N'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			INNER JOIN Plandata_Prod.dbo.qattribute atr WITH (NOLOCK) ON (atr.description LIKE '%Yes%')
																		 AND (atr.attributeclass = 'CLAIM')
			INNER JOIN Plandata_Prod.dbo.claimattribute ca WITH (NOLOCK) ON (ca.attributeid = atr.attributeid)
																			AND (stg.G_Claimid = ca.claimid)
			INNER JOIN Plandata_Prod.dbo.attributegroup ag WITH (NOLOCK) ON (ag.attributeid = atr.attributeid)
			INNER JOIN Plandata_Prod.dbo.attributegrouphdr agh (NOLOCK) ON (ag.attributegroupid = agh.attributegroupid)
																		   AND (agh.description LIKE '%Dev Outreach%')
			WHERE stg.K_CleanClaim = 'Y';


			UPDATE stg
			SET stg.K_CleanClaim = 'NA'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			WHERE (stg.K_CleanClaim = 'Y')
				  AND (stg.QDatePaid IS NULL);


			UPDATE stg
			SET stg.K_CleanClaim = 'Y'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			INNER JOIN Plandata_Prod.dbo.qattribute atr WITH (NOLOCK) ON (atr.description = 'Clean-Letter Sent Unnecessarily')
			INNER JOIN Plandata_Prod.dbo.claimattribute ca WITH (NOLOCK) ON (ca.attributeid = atr.attributeid)
																			AND (stg.G_Claimid = ca.claimid)
			WHERE (stg.K_CleanClaim = 'N');


			------------------------------------------------------------------------
			-- Update IDNrequired
			--1. If there is a denial reason at the header level that is designated on the IDN grid to require an IDN, the IDN flag should be moved to "Y" and logic stops.
			--2. If there is a denial reason at the header level that is designated on the IDN grid to NOT require an IDN or if the denial reason is not on the IDN grid at all, the IDN flag should be moved to "N" and the logic stops.
			--3. If there is NO denial reason at the header level, the logic should move to the line level and make the "Y"/"N" IDN flag determination.
			------------------------------------------------------------------------
			UPDATE stg 
			SET stg.IDNrequired = 'Y'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			INNER JOIN Plandata_Prod.dbo.claim c WITH (NOLOCK) ON (c.claimid = stg.G_Claimid)
									AND (c.totalamt > 0)
									AND (c.status IN ('DENY', 'Denied', 'WAITDENY'))
			INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = stg.G_Claimid)
									AND (ce.status = 'DENY')
									AND (ce.claimline = 0)
			INNER JOIN QNXT_Custom.dbo.Universe_IDN_Reasons dl WITH (NOLOCK) ON (ce.reason = dl.MessageID)
									AND (dl.Status = 'DENY')
			WHERE (stg.QContracted = 'Y'
				   AND dl.Par = 'Y')
				  OR (stg.QContracted = 'N'
					  AND dl.NonPar = 'Y');


			UPDATE stg
			SET stg.IDNrequired = 'Y'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = stg.G_Claimid)
									AND (ce.status = 'DENY')
			INNER JOIN Plandata_Prod.dbo.claimdetail cd WITH (NOLOCK) ON (cd.claimid = stg.G_Claimid)
									AND (cd.claimline = ce.claimline)
									AND (cd.claimamt > 0)
									AND (cd.status = 'DENY')
			INNER JOIN QNXT_Custom.dbo.Universe_IDN_Reasons dl WITH (NOLOCK) ON (ce.reason = dl.MessageID)
																				AND (dl.Status = 'DENY')
			WHERE (stg.QContracted = 'Y'
				   AND dl.Par = 'Y')
				  OR (stg.QContracted = 'N'
					  AND dl.NonPar = 'Y')
					 AND stg.G_Claimid NOT IN (SELECT cc.claimid
											   FROM Plandata_Prod.dbo.claimedit cc WITH (NOLOCK)
											   WHERE (cc.claimline = 0)
													 AND (cc.status = 'DENY')
													 AND (cc.claimid = stg.G_Claimid));

			------------------------------------------------------------------------
			-- Update qDateDue and WorQSource
			------------------------------------------------------------------------
			UPDATE stg
			SET stg.QDateDue = CASE
								   WHEN (stg.K_CleanClaim = 'N')
										THEN DATEADD(DAY, 60, stg.QDateClean)
								   ELSE CASE
											WHEN (stg.QEdit = '6035')
												 THEN DATEADD(DAY, 60, CONVERT(VARCHAR(10), stg.QDateClean, 102))
											ELSE DATEADD(DAY, 30, CONVERT(VARCHAR(10), stg.QDateClean, 102))
										END
							   END
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg;


			------------------------------------------------------------------------
			-- Create and Populate #t Temp Table
			------------------------------------------------------------------------
			IF OBJECT_ID('tempdb..#t') IS NOT NULL
				DROP TABLE #t;


			SELECT s.M_RequestDisposition AS RequestDisposition
				   , s.G_Claimid AS claimid
				   , ce.status
				   , ce.ruleid
				   , ce.reason
				   , ce.claimline
				   , '        ' AS onEXList
   				   , '   ' AS ExcludeMe	
				   , s.OldProtocolTable
			INTO #t
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov s WITH (NOLOCK)
			INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = s.G_Claimid)
			WHERE (ce.status = 'DENY')
				  AND (s.M_RequestDisposition = 'Denied')
				  AND (ce.reason > '')			--06/22/2021
   				  AND s.deletedRsn = '';
			

			INSERT #t (RequestDisposition,claimid, status, ruleid, reason, claimline, onexlist, ExcludeMe,OldProtocolTable)	--06/22/2021
			SELECT s.M_RequestDisposition  AS RequestDisposition
					, s.G_Claimid AS claimid
					, ce.status
					, ce.ruleid
					, cem.messageid 
					, ce.claimline
					, '        ' as onEXList				
					,'   '
					,s.OldProtocolTable
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov s WITH (NOLOCK)  
			INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = s.G_Claimid)
			INNER JOIN Plandata_Prod.dbo.claimeditmessage cem WITH (NOLOCK) ON (ce.claimid = cem.claimid) 
					AND (ce.claimline = cem.claimline) --ousted 052021 AND (ce.reason = cem.messageid)
			WHERE  (s.M_RequestDisposition = 'DENIED')
							AND (ce.status ='DENY') 
							AND s.deletedRsn = ''
							AND (ce.reason = '' AND cem.messageid > ''); --06/22/2021

			INSERT #t (RequestDisposition,claimid, status, ruleid, reason, claimline, onexlist, ExcludeMe,OldProtocolTable)		--06/22/2021
			SELECT s.M_RequestDisposition  AS RequestDisposition
					, s.G_Claimid AS claimid
					, ce.status
					, ce.ruleid
					, cer.msgnumber
					, ce.claimline
					, '        ' as onEXList				
					,'   '
					,s.OldProtocolTable
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov s WITH (NOLOCK)  
			INNER JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON (ce.claimid = s.G_Claimid)
			INNER JOIN Plandata_Prod.dbo.claimremit cer WITH (NOLOCK) ON (ce.claimid = cer.Claimid AND ce.claimline = cer.claimline)
			WHERE  (s.M_RequestDisposition = 'DENIED')
							AND (ce.status ='DENY')
							AND s.deletedRsn = '';

			------------------------------------------------------------------------
			-- If claim has Header Deny Edits, get rid of service line edits
			------------------------------------------------------------------------
			DELETE FROM #t 
			WHERE claimline > 0 AND claimid IN (SELECT t2.claimid FROM #t t2 WHERE t2.claimline = 0)

			------------------------------------------------------------------------
			-- PROV-Update onExList in Temp Table - This will put something in extype column if the edit IS to be excluded
			------------------------------------------------------------------------
			UPDATE temp
			SET temp.onEXList = ex.ExType
			FROM #t temp
			INNER JOIN QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK) ON (ex.ExCode = temp.ruleid)
									AND (ex.UniverseName = temp.OldProtocolTable)
			WHERE (ex.ExType = 'rules');


			UPDATE temp
			SET temp.onEXList = ex.ExType
			FROM #t temp
			INNER JOIN QNXT_Custom.dbo.UniverseExtractExcludeCodes ex WITH (NOLOCK) ON (ex.ExCode = temp.reason)
										AND (ex.UniverseName = temp.OldProtocolTable)
			WHERE (ex.ExType IN ('EOB', 'REMIT'));

			-----------------------------------------------------------------------
			-- If the service line has Dup Edit ('.1004','.1005','.1019','.1036','.1037','.1041','.1046','.1101','817','826','.CC19','D71','DUP1002','Z110','Z111','Z46','Z47')  
			-- That whole SERVICE LINE should be considered as EXCLUDED  
			------------------------------------------------------------------------
			UPDATE  #t 
			SET #t.onEXList = 'New'
			FROM #t t
			WHERE t.claimline > 0 
					AND (CONCAT(t.claimid, t.claimline)) IN (SELECT DISTINCT CONCAT(t2.claimid,t2.claimline)
								FROM #t t2  
								WHERE t2.claimline > 0
								AND t2.reason IN  ('.1004','.1005','.1019','.1036','.1037','.1041','.1046','.1101','817','826','.CC19','D71','DUP1002','Z110','Z111','Z46','Z47') 
								AND t2.onEXlist = 'REMIT')
					AND onExlist = ''

			------------------------------------------------------------------------
			-- If all edits on the header are on the excluded table, 
			--             EXCLUDE that claim from the universe
			------------------------------------------------------------------------

			UPDATE #t
			SET #t.ExcludeMe = 'Yes'
			WHERE (claimid IN (SELECT DISTINCT claimid
				 FROM #t
				 WHERE claimline = 0
				 GROUP BY claimid
				 HAVING MIN(onEXList) > ''
						AND MAX(onEXList) > ''));

			------------------------------------------------------------------------
			-- If all edits on the header are on the excluded table, 
			--             EXCLUDE that claim from the universe
			------------------------------------------------------------------------

			UPDATE  #t 
			SET #t.excludeme = 'Yes'
			FROM #t 
			WHERE 	(claimid IN (SELECT DISTINCT claimid 
								FROM #t  
								WHERE claimline > 0
								GROUP BY claimid 
							HAVING MIN(onExList) > '' AND  max(onExList) > '') );


			------------------------------------------------------------------------
			-- Update deletedRsn - If left on the table, it should NOT be in the universe
			------------------------------------------------------------------------
			UPDATE stg
			SET deletedRsn = LEFT(deletedRsn + 'All edits on Excluded list-', 350)
			FROM QNXT_Custom.dbo.Universe2022_ODAG3Prov stg (NOLOCK)
			INNER JOIN #t temp ON (temp.claimid = stg.G_Claimid) AND (temp.ExcludeMe = 'Yes')
			WHERE (temp.RequestDisposition = 'DENIED');

			------------------------------------------------------------------------
			-- Drop #t Temp Table
			------------------------------------------------------------------------
			IF OBJECT_ID('tempdb..#t') IS NOT NULL
				DROP TABLE #t;


			------------------------------------------------------------------------
			-- Update O_DatePaid - Currently ''
			------------------------------------------------------------------------			
			UPDATE stg
			SET stg.O_DatePaid = REPLACE(CONVERT(DATE, stg.EOP), '-', '/')
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			WHERE stg.QTotPaid > 0
				  AND stg.M_RequestDisposition = 'Approved'
				  AND ISDATE(stg.EOP) = 1; -- Added for check if stg.EOP is valid date


			------------------------------------------------------------------------
			-- Update P_DateNotifyMember
			------------------------------------------------------------------------
			UPDATE stg
			SET stg.P_DateNotifyMember = REPLACE(CONVERT(DATE, stg.EOB), '-', '/')
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			WHERE --(M_RequestDisposition = 'Approved') AND				this should be for all claims, to just APPROVED
				ISDATE(stg.EOB) = 1;


			UPDATE stg
			SET stg.P_DateNotifyMember = REPLACE(CONVERT(DATE, stg.IDN), '-', '/')
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			WHERE (stg.M_RequestDisposition = 'Denied')
				  AND (stg.IDNrequired = 'Y')
				  AND (ISDATE(stg.IDN) = 1);


			------------------------------------------------------------------------
			-- Update U_DeniedMedicalNecessity OLD LOGIC: “NA” – ALL Approved
			--											“No” OPEN and Untimely - past due (open claims should only be brought into the universe when they are past due)
			--											“N” Finalized - Denied without above edits
			--											“Y” Finalized - Denied with edits .cc24, MP016, Z135, c10, MP016CAID
			--										•	“Open” is defined as a non-finalized claim (no paid date in QNXT)
			------------------------------------------------------------------------
			UPDATE stg
			SET stg.U_DeniedMedicalNecessity = 'N'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			WHERE ((stg.QDatePaid IS NULL)
				   OR ((stg.M_RequestDisposition = 'Denied')
					   AND (stg.QDatePaid IS NOT NULL)));


			UPDATE stg
			SET stg.U_DeniedMedicalNecessity = 'Y'
			FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
			JOIN Plandata_Prod.dbo.claimedit ce WITH (NOLOCK) ON ce.claimid = stg.G_Claimid
			WHERE (stg.M_RequestDisposition = 'Denied')
				  AND (stg.QDatePaid IS NOT NULL)
				  AND (ce.reason IN ('.cc24', 'MP016', 'Z135', 'C10'));
				  
            ------------------------------------------------------------------------
            --  INC9913623   CMS Audit fix for specific claim number.  
            --      GDTG-3172  Travis Williams
            ------------------------------------------------------------------------            
            UPDATE stg SET P_DateNotifyMember = '2024/01/17'
            FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
            WHERE G_Claimid in ('23326E001291','23326E008736','23353E020063','24009E022261','23343E004821','23326E038998','23325E031397','23319E053951','23338E000982','23312E028996','23322E015913','24004000024')

            UPDATE stg SET P_DateNotifyMember = '2024/01/19'
            FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
            WHERE G_Claimid in ('23332E030766')
            
            UPDATE stg SET P_DateNotifyMember = '2024/01/22'
            FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
            WHERE G_Claimid in ('23333E048623','23332E028439','23331E003076','23332E002979','23333E017883')

            UPDATE stg SET P_DateNotifyMember = '2024/01/23'
            FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
            WHERE G_Claimid in ('23361E007924','23335E001048','23336E001847','23336E049200','23335E008257','23333E012076','23335E022033','23334E000775','23334E013220')

            UPDATE stg SET P_DateNotifyMember = '2024/01/24'
            FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
            WHERE G_Claimid in ('23348E002823','23350E029057','23354E029981')

            UPDATE stg SET P_DateNotifyMember = '2024/01/25'
            FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
            WHERE G_Claimid in ('23342E057457')

            UPDATE stg SET P_DateNotifyMember = '2024/01/27'
            FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
            WHERE G_Claimid in ('23340E016511','23336E008955','23335E037685')

            UPDATE stg SET P_DateNotifyMember = '2024/01/30'
            FROM QNXT_Custom.dbo.Universe2022_Odag3Prov stg
            WHERE G_Claimid in ('23342E010891','23342E051141','23342E023769','23343E031949')
            ------------------------------------------------------------------------
            --  INC9913623   CMS Audit fix for specific claim number.  
            --      GDTG-3172  Travis Williams   END Additions
            ------------------------------------------------------------------------   				  


			COMMIT TRANSACTION;
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
				ROLLBACK TRANSACTION;


			THROW;
		END CATCH;
	END;
