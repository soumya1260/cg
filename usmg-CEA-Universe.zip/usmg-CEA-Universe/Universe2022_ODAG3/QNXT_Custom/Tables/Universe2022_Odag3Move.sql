USE [QNXT_Custom]
GO

/****** Object:  StoredProcedure [dbo].[spUniverse2022_Odag3Move]    Script Date: 9/30/2021 8:56:58 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [dbo].[spUniverse2022_Odag3Move] 
 AS

 /*************************************************************************************************************
 * TITLE:			dbo.spUniverse2022_Odag3.sql
 * BUSINESS OWNER:	QNXT Development
 * CREATED BY:		Sandie Nantz
 * CREATE DATE:		06/17/2021
 * 
 * DESCRIPTION:		
 *
 * Modification History: 
 *	SDE #:		Developer:		Date:		Desc:
 *  CHG0146103	Sandie Nantz	06/16/2021	US460219:Universe - CMS Universe 2022 Protocols - Odag3
**************************************************************************************************************/


SELECT [A_FirstName]
      ,[B_LastName]
      ,[C_EnrolleeID]
      ,[D_ContractID]
      ,[E_Planid]
      ,[F_FDR]
      ,[G_Claimid]
      ,[H_DateReceived]
      ,[I_DateAORReceipt]
      ,[J_DateWOL]
      ,[K_CleanClaim]
      ,[L_ODorRecon]
      ,[M_RequestDisposition]
      ,[N_DateDetermination]
      ,[O_DatePaid]
      ,[P_DateNotifyMember]
      ,[Q_DateNotifyProvider]
      ,[R_DateIRE]
      ,[S_WhoMadeRequest]
      ,[T_IssueDescTypeOfService]
      ,[U_DeniedMedicalNecessity]
      ,[OldProtocolTable]
      ,[QProgramid]
      ,[QClmStatus]
      ,[QContracted]
      ,[QDateClean]
      ,[QDateCreate]
      ,[QDateDue]
      ,[QDateUpdate]
      ,[QDatePaid]
      ,[QDateStart]
      ,[QBillMax]
      ,[QWhoMadeRequest]
      ,[QEnrollid]
      ,[QEdit]
      ,[QMemid]
      ,[QTotPaid]
      ,[QBRAorMailDate]
      ,[dispositionLetter]
      ,[PeoplesoftDate]
      ,[TheNewDecisionDate]
      ,[EOB]
      ,[EOP]
      ,[IDN]
      ,[IDNrequired]
      ,[startdate]
      ,[enddate]
      ,[deletedRsn]
      ,[BatchId]
      ,[Rundate]
	  , '10' AS source
	  , '2200' AS version
	  , G_Claimid as claimid
  FROM [QNXT_Custom].[dbo].[Universe2022_Odag3] (NOLOCK)
		WHERE(deletedRsn='');




GO

