CREATE TABLE dbo.Universe2022_Odag3Prov
(
	A_FirstName CHAR(50) NOT NULL
	, B_LastName CHAR(50) NOT NULL
	, C_EnrolleeID CHAR(11) NOT NULL
	, D_ContractID CHAR(5) NOT NULL
	, E_Planid CHAR(3) NOT NULL
	, F_FDR CHAR(70) NOT NULL
	, G_Claimid CHAR(40) NOT NULL
	, H_DateReceived CHAR(10) NOT NULL
	, I_DateAORReceipt CHAR(10) NOT NULL
	, J_DateWOL CHAR(10) NOT NULL
	, K_CleanClaim CHAR(4) NOT NULL
	, L_ODorRecon CHAR(5) NOT NULL
	, M_RequestDisposition CHAR(9) NOT NULL
	, N_DateDetermination CHAR(10) NOT NULL
	, O_DatePaid CHAR(10) NOT NULL
	, P_DateNotifyMember CHAR(10) NOT NULL
	, Q_DateNotifyProvider CHAR(10) NOT NULL
	, R_DateIRE CHAR(10) NOT NULL
	, S_WhoMadeRequest CHAR(3) NOT NULL
	, T_IssueDescTypeOfService CHAR(2000) NOT NULL
	, U_DeniedMedicalNecessity CHAR(4) NOT NULL
	, OldProtocolTable CHAR(7) NOT NULL
	, QProgramid CHAR(15) NULL
	, QClmStatus VARCHAR(10) NULL
	, QContracted CHAR(1) NULL
	, QDateClean SMALLDATETIME NULL
	, QDateCreate SMALLDATETIME NULL
	, QDateDue SMALLDATETIME NULL
	, QDateUpdate SMALLDATETIME NULL
	, QDatePaid SMALLDATETIME NULL
	, QDateStart SMALLDATETIME NULL
	, QBillMax VARCHAR(10) NULL
	, QWhoMadeRequest VARCHAR(2) NULL
	, QEnrollid VARCHAR(15) NULL
	, QEdit VARCHAR(10) NULL
	, QMemid VARCHAR(15) NULL
	, QTotPaid Money
	, QBRAorMailDate CHAR(10) NULL
	, dispositionLetter SMALLDATETIME NULL
	, PeoplesoftDate SMALLDATETIME NULL
	, TheNewDecisionDate CHAR(10) NULL
	, EOB CHAR(10) NULL
	, EOP CHAR(10) NULL
	, IDN CHAR(10) NULL
	, IDNrequired CHAR(1) NULL
	, startdate DATE NULL
	, enddate DATE NULL
	, deletedRsn VARCHAR(MAX) NULL
	, BatchId VARCHAR(255) NULL
	, Rundate DATETIME NULL
	, CONSTRAINT pkUniverse2022_Odag3Prov
		  PRIMARY KEY CLUSTERED (G_Claimid ASC)
		  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 85) ON [PRIMARY]
) ON [PRIMARY];
GO