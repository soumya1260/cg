---
name: Meeting Notes
about: Capture meeting minutes.
labels: meeting notes
---

# Meeting Name and Date go here

## Open issues
- Issue    
- Issue    
- Issue    

## Future plans
- Plan    
- Plan    
- Plan    

## Follow up
- Was there anything you didn't accomplish last week?
- Do you need help with anything?
