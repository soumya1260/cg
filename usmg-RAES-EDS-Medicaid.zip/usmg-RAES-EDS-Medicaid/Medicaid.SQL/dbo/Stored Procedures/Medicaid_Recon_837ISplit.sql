﻿
CREATE PROCEDURE [dbo].[Medicaid_Recon_837ISplit]
(		@segsep varchar(1) = '~',
		@elmsep varchar(1) = '*'
)
AS
/***************************************************************************************************
** CREATE DATE: 06/2012
**
** AUTHOR: Henry faust
**
** DESCRIPTION: 
**              
**              
**               
**
**
**/
			DECLARE
			
			@TOTAL_RECORDS INT


declare @numseg int,
        @i int =0, @j int = 0, @cnt int = 1,
		--@segsep varchar(1) = '~',
		--@elmsep varchar(1) = '*',
		@teststr varchar(max) = ''
		,@segments int = 0

--select * from staging.RawX12;
--SELECT LEN(REPLACE(ComFile, '~', ' ')) from staging.RawX12
--select len(ComFile) - len(replace(ComFile, '~', ''))  from staging.RawX12 --number of Segments
--set @numseg = (select len(ComFile) - len(replace(ComFile, '~', ''))  from staging.RawX12) +1
set @segments = ( select count(*)  from staging.Raw837IX12 )
select @segments
if @segments =1 
  Begin
		set @numseg = (select len(ComFile) - len(replace(ComFile, @segsep, ''))  from staging.Raw837IX12) +1


		set @teststr = (select comfile from staging.Raw837IX12)
		--select @numseg


		while @cnt < @numseg 
		begin		

			 set @i = CHARINDEX( @segsep,  @teststr)
					 select 'SUB', @i,@j, SUBSTRING(@teststr,0, @i +1)

		insert into staging.Raw837ISegments select SUBSTRING(@teststr,0, @i +1)
		select SUBSTRING(@teststr,0, @i +1)

			--select 'charindex' ,  CHARINDEX( @segsep,  @teststr),  len(@teststr)  
					 ----

			set @teststr = substring(@teststr , @i +1, len(@teststr) )

	
			set @cnt = @cnt +1
		end
  end --if segments =1
else
	begin	
	   insert into Medicaid.staging.Raw837ISegments
	     ( segment)
       select comfile from Medicaid.staging.Raw837IX12
--       select left(comfile,256) from Medicaid.staging.Raw837X12
	end




















GO


