﻿CREATE PROCEDURE [dbo].[pr_MEDICAID_PROF_CSV_100P_150P_20P_310P_Header]
( @LOB CHAR(10),
@LOBCODE VARCHAR(15),
@JOBID INT
)
AS

/***************************************************************************************************
** CREATE DATE: 02/18/2020
**
** AUTHOR: Aaron Ridley 
**
** DESCRIPTION: PROCEDURE WILL POPULATE CSV HEADER TABLE (100P,150P,310P,20P)
**              UTILIZING THE OUTB_PROF_HEADER AS SOURCE
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
02/18/20		Aaron Ridley	Version 1
08/25/2020      Aaron Ridley    TETDM-2337 Added logic to accommodate MMP file naming convention
09/29/2020      Aaron Ridley    Added logic remediate the population of the Rendering Provider Last Name 
02/24/2020      Aaron Ridley    TETDM-2350 Added logic to accommodate adjustment required previous claim id
04/13/2023		Aaron Ridley	Medicaid update to use Configuration tables as we incorporate FL/PA 
*****************************************************************************************************/	
--DECLARE VARIABLES

			DECLARE
			
			@TOTAL_RECORDS INT,
			@SenderID varchar(50), 
			@ReceiverID varchar(50), 
			@IsAdjustment varchar(50),
			@ContractID varchar(50),
			@DestinationID varchar(50),
			@ClaimIDPrefix varchar(50); 
		
			BEGIN TRANSACTION 
					INSERT INTO MEDICAID.dbo.EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_MEDICAID_PROF_CSV_100P_150P_20P_310P_Header'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					if @@ERROR <> 0
							begin
								rollback 
							end
				commit
			
/* Set Variables  */ 

SET @RECEIVERID = (SELECT [Receiver_ID] FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID); 
SET @SenderID = (SELECT [Sender_ID] FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID); 
SET @IsAdjustment = (SELECT [IsAdjustmentFlag] FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID); 
SET @ContractID = (SELECT [ContractID] FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID); 
SET @DestinationID = (SELECT [DestinationID] FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID);
SET @ClaimIDPrefix = (SELECT [ClaimIDprefix] FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID);

/*---------------------------------------------------------------------*/
/* POPULATE 100 TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_100P_Rec_Header_Archive 
SELECT *, getdate()  FROM dbo.EE_CSV_100P_Rec_Header

TRUNCATE TABLE dbo.EE_CSV_100P_Rec_Header

INSERT INTO EE_CSV_100P_Rec_Header
 SELECT 
      oph.claim_id    --    ClaimID
     ,oph.SOURCEDATAKEY --@SourceDataKey   --    SourceDataKey
      ,oph.SYSTEM_SOURCE   --    SourceDesc
      ,getdate()   --    CreateDate
    ,''     --    ClaimStatus
    ,oph.CLAIM_TYPE     --    ClaimType
	,@SenderID -- SenderID
	--,CASE WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN 'CHSMMPCARECLP'
	--      WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN 'CHSMMPCAIDCLP'
	-- ELSE 'CHSMAOCLP'    
	 --END --    SenderID
	,@RECEIVERID -- ReceiverID
  --  ,CASE WHEN @LOBCODE  = 'C54581391' THEN 'DTXT11'
	 --     ELSE 'ENC0159' 
	 --END    --    ReceiverID
    ,''     --    OriginatorID
    ,@ContractID --    ContractID
    ,@DestinationID     --    DestinationID
    ,''     --    HistoricalIndicator
    ,''     --    HistoricalDispositionStatus
    ,CASE WHEN @IsAdjustment = 'TRUE' THEN PAYER_CLAIM_CNTRL_NUM  ELSE '' END     --    HistoricalEncounterICN
    ,''     --    HistoricalEncounterID
    ,CASE WHEN oph.OPTIONAL_REPORTING_IND  ='PAPER' THEN 'PAPER' ELSE '' END   --    Paper
    ,CASE WHEN oph.CLAIM_TYPE = 'E' THEN 'TRUE' ELSE 'FALSE' END    --  AARON  DME 
    ,''     --    AdministrativeDenial
    ,''     --    ChartReviewData
    ,oph.SOURCEDATAKEY     --    Source
    ,CASE WHEN @JOBID IN ('6002','6003','6006','6007') THEN 'Y' ELSE 'N' END		--	  Filler
    ,''     --    TraceNumber
    ,''     --    NM1010A_SubmitterEntityRole
    ,''     --    NM1020A_SubmitterPersonIndicator
    ,''     --    NM1030A_SubmitterLastName
    ,''     --    NM1080A_SubmitterIdentifierQualifier
    ,''     --    NM1090A_SubmitterIdentifier
    ,''     --    PER010A_01_SubmitterContactIdentifier
    ,''     --    PER020A_01_SubmitterContactName
    ,''     --    PER030A_01_SubmitterContactQualifier1 TE,EM,FX
    ,''     --    PER040A_01_SubmitterContact1
    ,''     --    PER050A_01_SubmitterContacQualifier2 TE,EM,FX, EX
    ,''     --    PER060A_01_SubmitterContact2
    ,''     --    NM1010B_ReceiverEntityRole
    ,''     --    NM1020B_PersonIndicator
    ,''     --    NM1030B_ReceiverName
    ,''     --    NM1080B_ReceiverIdentifierQualifier
    ,''     --    NM1090B_ReceiverIdentifier
    ,''     --    PRV01A_BillingProviderCode
    ,''     --    PRV02A_BillingProviderCodeQualifier
    ,oph.BILL_PROV_TAXONOMY_CD    --    PRV03A_BillingProviderTaxonomy 
    ,''     --    NM101AA_BillingProviderRole
    ,''     --    NM102AA_BillingPersonIndicator
    ,CASE WHEN oph.BILL_PROV_FNAME =''  and [BILL_PROV_ORG_NAME] <> ''THEN [BILL_PROV_ORG_NAME] 
		  WHEN 	oph.BILL_PROV_FNAME ='' and [BILL_PROV_ORG_NAME] ='' THEN 	oph.BILL_PROV_LNAME		
				ELSE oph.BILL_PROV_LNAME  END   --    NM103AA_BillingOrg_LastName
    ,oph.BILL_PROV_FNAME     --    NM104AA_BillingFirstName
    ,''     --    NM105AA_BillingMiddleName
    ,''     --    NM107AA_BillingSuffix
    ,''     --    NM108AA_BillingProviderIdentifierQualifier
    ,CASE WHEN BILL_PROV_NPI <>'' THEN  BILL_PROV_NPI ELSE BILL_PROV_GRP_NPI  END --    NM109AA_BillingProviderIdentifier - Aaron (Set to blank for atypical providers) 
    ,oph.BILL_PROV_ADDR1     --    N301AA_BillingAddressLine1
    ,oph.BILL_PROV_ADDR2     --    N302AA_BillingAddressLine2
    ,oph.BILL_PROV_CITY     --    N401AA_BillingCity
    ,oph.BILL_PROV_STATE     --    N402AA_BillingState
    ,oph.BILL_PROV_ZIP + oph.BILL_PROV_ZIP4   --    N403AA_BillingPostalCode
    ,''     --    N404AA_BillingCountry
    ,''     --    REF01AA_BillingProviderIdentifierQualifier01
    ,oph.BILL_PROV_TAX_ID     --    REF02AA_BillingProviderIdentifier01 --Aaron (Set to blank for Atypical providers) 
    ,''     --    REF01AA_BillingProviderIdentifierQualifier02
    ,''     --    REF02AA_BillingProviderIdentifier02
    ,''     --    BillingProviderSpecialityAA
    ,''     --    BillingProviderTypeAA
    ,''     --    PER0AA1_BillingProviderContactFunction_1
    ,''     --    PER02AA_BillingProviderContactName_1
    ,''     --    PER03AA_BillingProviderCommunicationNumberQualifier_1
    ,''     --    PER04AA_BillingProviderCommunicationNumber_1
    ,''     --    PER05AA_BillingProviderCommunicatioNumberQualifier_1
    ,''     --    PER06AA_BillingProviderCommunicationNumber_1
    ,''     --    PER07AA_BillingProviderCommunicatioNumberQualifier_1
    ,''     --    PER08AA_BillingProviderCommunicationNumber_1
    ,''     --    PER01AA_BillingProviderContactFunction_2
    ,''     --    PER02AA_BillingProviderContactName_2
    ,''     --    PER03AA_CommunicatioNumberQualifier_2
    ,''     --    PER04AA_BillingProviderCommunicationNumber_2
    ,''     --    PER05AA_BillingProviderCommunicatioNumberQualifier_2
    ,''     --    PER06AA_BillingProviderCommunicationNumber_2
    ,''     --    PER07AA_BillingProviderCommunicatioNumberQualifier_2
    ,''     --    PER08AA_BillingProviderCommunicationNumber_2
    ,''     --    NM101AB_PayToProviderRole
    ,''     --    NM102AB_PayToPersonIndicator
    ,''     --    N301AB_PayToAddressLine1
    ,''     --    N302AB_PayToAddressLine2
    ,''     --    N401AB_PayToCity
    ,''     --    N402AB_PayToState
    ,''     --    N403AB_PayToPostalCode
    ,''     --    N404AB_PayToCountry
    ,''     --    NM101AC_PayToPlanOrganizationRole
    ,''     --    NM102AC_PayToPlanPersonIndicator
    ,''     --    NM103AC_PayToPlanName
    ,''     --    NM108AC_PayToPlanOrganizationIDQualifier
    ,''     --    NM109AC_PayToPlanOrganizationIdentifier
    ,''     --    N301AC_PayToPlanAddressLine1
    ,''     --    N302AC_PayToPlanAddressLine2
    ,''     --    N401AC_PayToPlanCity
    ,''     --    N402AC_PayToPlanState
    ,''     --    N403AC_PayToPlanPostalCode
    ,''     --    N404AC_PayToPlanCountry
    ,''     --    REF01AC_OrganizationIDQualifier_1
    ,''     --    REF02AC_OrganizationIdentifier_1
    ,''     --    REF01AC_OrganizationIDQualifier_2
    ,''     --    REF02AC_OrganizationIdentifier_2
    ,''     --    ClaimEncounterCleanup
    ,''     --    AtypicalProviderFlag  -- Update (Need criteria to identify default NPI - NPI or TaxID) 'Y' DDRC (048/052) 19999
    ,''     --    SupplementalInterimFlag
    ,''     --    InterimLateChargeFlag
    ,''     --    IssuerIdentifier
    ,''     --    Filler05
    ,''     --    R_MonetaryAmountChangeFlag
    ,''     --    NM1040ASubmitterFirstName
    ,''     --    BillingCountyCode
    ,''     --    Filler06
    ,''     --    ClaimInputMethod
    ,''     --    RehabFlag
    ,''     --    PSCustomField01
    ,''     --    VoidReason
    ,''     --    PSCustomField02
    ,''     --    Filler12
    ,''     --    Filler13
    ,CASE WHEN SYSTEM_SOURCE IN ('50','30') THEN '' ELSE SYSTEM_SOURCE END     --    Filler14
    ,''     --    Filler15		
	,CASE WHEN @IsAdjustment = 'TRUE' THEN 'TRUE' ELSE 'FALSE' END     --    Filler16
	,CASE WHEN @IsAdjustment = 'TRUE' THEN  @ClaimIDPrefix + PAYER_CLAIM_CNTRL_NUM ELSE '' END     --    Filler17
	FROM MEDICAID.dbo.OUTB_PROF_HEADER oph

/*---------------------------------------------------------------------*/
/* POPULATE 150 TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_150P_Rec_Header_Archive 
SELECT *, getdate()  FROM dbo.EE_CSV_150P_Rec_Header

TRUNCATE TABLE dbo.EE_CSV_150P_Rec_Header

INSERT INTO dbo.EE_CSV_150P_Rec_Header
SELECT 
    oph.claim_id,        -- ClaimID - varchar(20)
    SOURCEDATAKEY,         -- SourceDataKey - int
    oph.SYSTEM_SOURCE,        -- SourceDesc - varchar(60)
    GETDATE(), -- CreateDate - datetime
    '',        -- SBR01BSubscriberPayerResponsibilitySequence - varchar(100)
    '',        -- SBR02BSubscriberRelationship - varchar(100)
    '',        -- SBR03BSubscriberPolicyNumber - varchar(100)
    '',        -- SBR04BInsuredGroupName - varchar(100)
    oph.CLM_FIL_INDCD1,        -- SBR09BClaimFilingIndicator - varchar(100)
    '',        -- NM101BASubscriberPersonRole - varchar(100)
    '',        -- NM102BASubscriberPersonIndicator - varchar(100)
    oph.MEMBER_LAST_NAME,        -- NM103BASubscriberLastName - varchar(100)
    oph.MEMBER_FIRST_NAME,        -- NM104BASubscriberFirstName - varchar(100)
    oph.MEMBER_MID_INIT,        -- NM105BASubscriberMiddleName - varchar(100)
    oph.MEMBER_SFX,        -- NM107BASubscriberSuffix - varchar(100)
    '',        -- NM108BASubscriberIdentifierQualifer - varchar(100)
    oph.MEMBER_ID,        -- NM109BASubscriberIdentifier - varchar(100)
    '',        -- REF01BASubscriberSSNQualifier - varchar(100)
   oph.MEMBER_SSN,        -- REF02BASubscriberIdentifierSSN - varchar(100) 
    '',        -- REF01BAPropertyandCasualtyQualifier - varchar(100)
    '',        -- REF02BAPropertyandCasualtyIdentifier - varchar(100)
    oph.MEMBER_ADDR1,        -- N301BASubscriberAddressLine1 - varchar(100)
    oph.MEMBER_ADDR2,        -- N302BASubscriberAddressLine2 - varchar(100)
    oph.MEMBER_CITY,        -- N401BASubscriberCity - varchar(100)
    oph.MEMBER_STATE,        -- N402BASubscriberState - varchar(100)
    oph.MEMBER_ZIP + oph.MEMBER_ZIP4,        -- N403BASubscriberPostalCode - varchar(100) 
	 '',        -- N404BASubscriberCountry - varchar(100)
    '',        -- DMG01BADateQualifer - varchar(100)
    oph.MEMBER_DOB,        -- DMG02BADateOfBirth - varchar(100)
    oph.MEMBER_GENDER,        -- DMG03BAGender - varchar(100)
    '',        -- REF01BASubscriberIdentifierQualifier01 - varchar(100)
    '',        -- REF02BASubscriberIdentifier01 - varchar(100)
    '',        -- REF01BASubscriberIdentifierQualifer02 - varchar(100)
    oph.HICN_NUM,        -- REF02BASubscriberIdentifier02 - varchar(100)
    '',        -- NM101BBPayerOrganizationRole - varchar(100)
    '',        -- NM102BBPayerPersonIndicator - varchar(100)
    '', -- Commented out EDS-2185 oph.OTH_PAYER1_NAME,        -- NM103BBPayerName - varchar(100)
    '',        -- NM108BBPayerOrganizationIDQualifier - varchar(100)
    '',        -- NM109BBPayerOrganizationIdentifier - varchar(100)
    oph.PAYTO_ADDR1,        -- N301BBPayerAddressLine1 - varchar(100)
    oph.PAYTO_ADDR2,        -- N302BBPayerAddressLine2 - varchar(100)
    oph.PAYTO_CITY,        --[2010BB_N401_PayerCity]  [VARCHAR] (100)   Default '',
    oph.PAYTO_STATE,        -- N401BBPayerState - varchar(100)
    oph.PAYTO_ZIP,        -- N403BBPayerPostalCode - varchar(100)
    '',        -- N404BBPayerCountry - varchar(100)
    '',        -- REF01BBPayerOrganizationIDQualifier01 - varchar(100)
    '',        -- REF02BBPayerOrganizationIdentifier01 - varchar(100)
    '',        -- REF01BBProviderIDQualifier01 - varchar(100)
    '',        -- REF02BBBillingProviderIdentifier01 - varchar(100)
    '',        -- REF01BBBillingProviderIDQualifier02 - varchar(100)
    '',        -- REF02BBBillingProviderIdentifier02 - varchar(100)
    '',        -- REF01BBBillingProviderIDQualifier03 - varchar(100)
    '',        -- REF02BBProviderIdentifier03 - varchar(100)
    '',        -- REF01BBBillingProviderIDQualifier04 - varchar(100)
    '',        -- REF02BBBillingProviderIdentifier04 - varchar(100)
    '',        -- PatientLastName - varchar(100)
    '',        -- PatientFirstName - varchar(100)
    '',        -- PatientMiddleName - varchar(100)
    '',        -- PatientSSN - varchar(100)
    '',        -- PatientMemberID - varchar(100)
    '',        -- PatientGender - varchar(100)
    '',        -- PatientDOB - varchar(100)
    '',        -- PatientAddressLine1 - varchar(100)
    '',        -- PatientAddressLine2 - varchar(100)
    '',        -- PatientAddressCity - varchar(100)
    '',        -- PatientAddressState - varchar(100)
    '',        -- PatientAddressZip - varchar(100)
    '',        -- PCPIDQual - varchar(100)
    '',        -- PCPID - varchar(100)
    '',        -- PCPGroupIdentifier - varchar(100)
    '',        -- PDPIPAPMGType - varchar(100)
    '',        -- PDPIPAPMGID - varchar(100)
    '',        -- PCPOpenIndic - varchar(100)
    '',        -- PCPEligibilityInd - varchar(100)
    '',        -- COS - varchar(100)
    '',        -- ServiceCategoryType - varchar(100)
    '',        -- RenderingProvEffDate - varchar(100)
    '',        -- RenderingProvTermDate - varchar(100)
    '',        -- RenderingProvDEAID - varchar(100)
    '',        -- RenderingProvGender - varchar(100)
    '',        -- ProviderParNonPar - varchar(100)
    '',        -- CarePlanOptionIndicator - varchar(100)
    '',        -- GroupIndicator - varchar(100)
    '',        -- CareTypeCode - varchar(100)
    '',        -- FinancialArrangementCode - varchar(100)
    '',        -- Filler05 - varchar(100) -- Aaron -- Utilize for Member Reimbursement Flag (only for Professional)  Y -SDK=30 only
    oph.OTH_INSR_TYPECD1,        -- SBR05BIsuranceTypeCode - varchar(100)
    '',        -- PAT09BPregnancyIndicator - varchar(100)
    '',        -- Filler06 - varchar(100)
    '',        -- Filler07 - varchar(100)
    '',        -- Filler08 - varchar(100)
    '',        -- Filler09 - varchar(100)
    '',        -- Filler10 - varchar(100)
    '',        -- Filler11 - varchar(100)
    '',        -- Filler12 - varchar(100)
    '',        -- Filler13 - varchar(100)
    '',        -- Filler14 - varchar(100)
    '',        -- Filler15 - varchar(100)
    '',        -- PAT06BPatientDeathDate - varchar(100)
    '',        -- PAT01CPatientRelationship - varchar(100)
    '',        -- PAT06CPatientDeathDate - varchar(100)
    '',        -- PAT08CPatientWeight - varchar(100)
    '',        -- PAT09CPregnancyIndicator - varchar(100)
    '',        -- SubscriberRegionCode - varchar(100)
    '',        -- SubscriberOtherInsuranceCoverage - varchar(100)
    '',        -- PurchasedIndicator - varchar(100)
    ''         -- BehavioralHealthCOS - varchar(100)
FROM MEDICAID.dbo.OUTB_PROF_HEADER oph

/*---------------------------------------------------------------------*/
/* POPULATE 20 REC TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_20P_Rec_Header_Archive 
SELECT *, getdate()  FROM dbo.EE_CSV_20P_Rec_Header

TRUNCATE TABLE dbo.EE_CSV_20P_Rec_Header

INSERT INTO dbo.EE_CSV_20P_Rec_Header	   
	   ([ClaimID]
      ,[SourceDataKey]
      ,[SourceDesc]
      ,[CreateDate]
      ,[2300P_CLM01_ClaimNumber]
      ,[2300P_CLM02_TotalClaimCharge]
      ,[2300P_CLM05-01_PlaceOfService]
      ,[2300P_CLM05-02_BillTypeQualifier]
      ,[2300P_CLM05-03_ClaimFrequencyCode]
      ,[2300P_CLM06_ProviderSignature]
      ,[2300P_CLM07_MedicareAssignment]
      ,[2300P_CLM08_BenefitAssignmentIndicator]
      ,[2300P_CLM09_ReleaseOfInformation]
      ,[2300P_CLM10_PatientSignatureSource]
      ,[2300P_CLM11-01_RelatedCausesCode]
      ,[2300P_CLM11-02_RelatedCausesCode]
      ,[2300P_CLM11-04_AccidentState]
      ,[2300P_CLM11-05_AccidentCountry]
      ,[2300P_CLM12_SpecialProgramIndicator]
      ,[2300P_CLM20_DelayReason]
      ,[2300P_DTP01_DateTimeQualifier_1]
      ,[2300P_DTP02_FormatQualifier_1]
      ,[2300P_DTP03_DateTime_1]
      ,[2300P_DTP01_DateTimeQualifier_2]
      ,[2300P_DTP02_FormatQualifier_2]
      ,[2300P_DTP03_DateTime_2]
      ,[2300P_DTP01_DateTimeQualifier_3]
      ,[2300P_DTP02_FormatQualifier_3]
      ,[2300P_DTP03_DateTime_3]
      ,[2300P_DTP01_DateTimeQualifier_4]
      ,[2300P_DTP02_FormatQualifier_4]
      ,[2300P_DTP03_DateTime_4]
      ,[2300P_DTP01_DateTimeQualifier_5]
      ,[2300P_DTP02_FormatQualifier_5]
      ,[2300P_DTP03_DateTime_5]
      ,[2300P_DTP01_DateTimeQualifier_6]
      ,[2300P_DTP02_FormatQualifier_6]
      ,[2300P_DTP03_DateTime_6]
      ,[2300P_DTP01_DateTimeQualifier_7]
      ,[2300P_DTP02_FormatQualifier_7]
      ,[2300P_DTP03_DateTime_7]
      ,[2300P_CN101_ContractTypeCode]
      ,[2300P_CN102_MonetaryAmount]
      ,[2300P_CN103_ContractPercentage]
      ,[2300P_CN104_ContractCode]
      ,[2300P_CN105_TermsDiscountPercent]
      ,[2300P_CN106_ContractVersionIdentifier]
      ,[2300P_AMT01_AmountQualifier]
      ,[2300P_AMT02_PatientAmountPaid]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_1]
      ,[2300P_REF02_ClaimReferenceNumber_1]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_2]
      ,[2300P_REF02_ClaimReferenceNumber_2]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_3]
      ,[2300P_REF02_ClaimReferenceNumber_3]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_4]
      ,[2300P_REF02_ClaimReferenceNumber_4]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_5]
      ,[2300P_REF02_ClaimReferenceNumber_5]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_6]
      ,[2300P_REF02_ClaimReferenceNumber_6]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_7]
      ,[2300P_REF02_ClaimReferenceNumber_7]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_8]
      ,[2300P_REF02_ClaimReferenceNumber_8]
      ,[2300P_NTE01_ClaimNoteType]
      ,[2300P_NTE02_ClaimNote]
      ,[20P_Ambulance_Transport_Count]
      ,[2300P_CR101_AmbPatientWeightQualifier]
      ,[2300P_CR102_AmbulancePatientWeight]
      ,[2300P_CR104_AmbulanceTransportReason]
      ,[2300P_CR105_AmbulanceMeasure]
      ,[2300P_CR106_AmbulanceDistance]
      ,[2300P_CR109_AmbulanceRoundTripDesc]
      ,[2300P_CR110_StretcherPurposeDescription]
      ,[2300P_CRC01_ServiceCertificationCategory]
      ,[2300P_CRC02_ServiceCertificationIndicator]
      ,[2300P_CRC03_ConditionIndicatorCode]
      ,[2300P_CRC04_ConditionIndicatorCode]
      ,[2300P_CRC05_ConditionIndicatorCode]
      ,[2300P_CRC06_ConditionIndicatorCode]
      ,[2300P_CRC07_ConditionIndicatorCode]
      ,[2300P_HI01-01_DXType_1]
      ,[2300P_HI01-02_DXCode_1]
      ,[2300P_HI02-01_DXType_1]
      ,[2300P_HI02-02_DXCode_1]
      ,[2300P_HI03-01_DXType_1]
      ,[2300P_HI03-02_DXCode_1]
      ,[2300P_HI04-01_DXType_1]
      ,[2300P_HI04-02_DXCode_1]
      ,[2300P_HI05-01_DXType_1]
      ,[2300P_HI05-02_DXCode_1]
      ,[2300P_HI06-01_DXType_1]
      ,[2300P_HI06-02_DXCode_1]
      ,[2300P_HI07-01_DXType_1]
      ,[2300P_HI07-02_DXCode_1]
      ,[2300P_HI08-01_DXType_1]
      ,[2300P_HI08-02_DXCode_1]
      ,[2300P_HI09-01_DXType_1]
      ,[2300P_HI09-02_DXCode_1]
      ,[2300P_HI10-01_DXType_1]
      ,[2300P_HI10-02_DXCode_1]
      ,[2300P_HI11-01_DXType_1]
      ,[2300P_HI11-02_DXCode_1]
      ,[2300P_HI12-01_DXType_1]
      ,[2300P_HI12-02_DXCode_1]
      ,[2310AP_NM101_ProviderRole]
      ,[2310AP_NM102_PersonIndicator]
      ,[2310AP_NM103_LastName]
      ,[2310AP_NM104_FirstName]
      ,[2310AP_NM105_MiddleName]
      ,[2310AP_NM107_Suffix]
      ,[2310AP_NM108_ProviderIdentifierQualifer]
      ,[2310AP_NM109_ProviderIdentifier]
      ,[2310AP_REF01_ProviderIdentifierQualifer]
      ,[2310AP_REF02_ProviderIdentifier]
      ,[2310AP_REF01_ProviderIdentifierQualifer_02]
      ,[2310AP_REF02_ProviderIdentifier_02]
      ,[2310BP_NM101_ProviderRole]
      ,[2310BP_NM102_PersonIndicator]
      ,[2310BP_NM103_LastName]
      ,[2310BP_NM104_FirstName]
      ,[2310BP_NM105_MiddleName]
      ,[2310BP_NM107_Suffix]
      ,[2310BP_NM108_ProviderIdentifierQualifer]
      ,[2310BP_NM109_ProviderIdentifier]
      ,[2310BP_PRV01_ProviderCode]
      ,[2310BP_PRV02_ProviderCodeQualifer]
      ,[2310BP_PRV03_ProviderTaxonomy]
      ,[2310BP_REF01_ProviderIdentifierQualifer_1]
      ,[2310BP_REF02_ProviderIdentifier_1]
      ,[2310BP_REF01_ProviderIdentifierQualifer_2]
      ,[2310BP_REF02_ProviderIdentifier_2]
      ,[20P_RenderingProviderAddress1]
      ,[20P_RenderingProviderAddress2]
      ,[20P_RenderingProviderCity]
      ,[20P_RenderingProviderState]
      ,[20P_RenderingProviderZip]
      ,[2310CP_NM101_ProviderRole]
      ,[2310CP_NM102_PersonIndicator]
      ,[2310CP_NM103_LastName]
      ,[2310CP_NM108_ProviderIdentifierQualifer]
      ,[2310CP_NM109_ProviderIdentifier]
      ,[2310CP_N301_AddressLine1]
      ,[2310CP_N302_AddressLine2]
      ,[2310CP_N401_City]
      ,[2310CP_N402_State]
      ,[2310CP_N403_PostalCode]
      ,[2310CP_N404_Country]
      ,[2310CP_REF01_ProviderIdentifierQualifer]
      ,[2310CP_REF02_ProviderIdentifier]
      ,[2310DP_NM101_ProviderRole]
      ,[2310DP_NM102_PersonIndicator]
      ,[2310DP_NM103_LastName]
      ,[2310DP_NM104_FirstName]
      ,[2310DP_NM105_MiddleName]
      ,[2310DP_NM107_Suffix]
      ,[2310DP_NM108_ProviderIdentifierQualifer]
      ,[2310DP_NM109_ProviderIdentifier]
      ,[2310DP_REF01_ProviderIdentifierQualifer]
      ,[2310DP_REF02_ProviderIdentifier]
      ,[2310EP_NM101_ProviderRole]
      ,[2310EP_NM102_PersonIndicator]
      ,[2310EP_N301_AddressLine1]
      ,[2310EP_N302_AddressLine2]
      ,[2310EP_N401_City]
      ,[2310EP_N402_State]
      ,[2310EP_N403_PostalCode]
      ,[2310EP_N404_Country]
      ,[2310EP_REF01_ProviderIdentifierQualifer]
      ,[2310EP_REF02_ProviderIdentifier]
      ,[2310FP_NM101_ProviderRole]
      ,[2310FP_NM102_PersonIndicator]
      ,[2310FP_NM103_ORG_LastName]
      ,[2310FP_N301_AddressLine1]
      ,[2310FP_N302_AddressLine2]
      ,[2310FP_N401_City]
      ,[2310FP_N402_State]
      ,[2310FP_N403_PostalCode]
      ,[2310FP_N404_Country]
      ,[2310FP_REF01_ProviderIdentifierQualifer]
      ,[2310FP_REF02_ProviderIdentifier]
      ,[2300P_PWK01_AttachmentReportType]
      ,[2300P_PWK02_AttachmentTransmissionCode]
      ,[2300P_PWK06_AttachmentControlNumber]
      ,[2300P_REF01_InvestigationalDeviceExemptionNumber_Qualifier]
      ,[2300P_REF02_InvestigationalDeviceExemptionNumber]
      ,[2300P_REF01_ServiceAuthorizationExceptionCode_Qualifier]
      ,[2300P_REF02_ServiceAuthorizationExceptionCode]
      ,[2300P_REF01_MammographyCertificationNumber_Qualifier]
      ,[2300P_REF01_MammographyCertificationNumber]
      ,[2300P_CR208_PatientConditionCode]
      ,[2300P_CR210_PatientDescription]
      ,[2300P_CR211_PatientDescription]
      ,[2300P_HI101-2_AnesthesiaRelatedSurgicalProcedure]
      ,[2300P_HI102-2_AnesthesiaRelatedSurgicalProcedure]
      ,[2300P_DTP01_DateTimeQualifier_7_02]
      ,[2300P_DTP02_FormatQualifier_7_02]
      ,[2300P_DTP03_DateTime_7_02]
      ,[2300P_DTP01_DateTimeQualifier_8]
      ,[2300P_DTP02_FormatQualifier_8]
      ,[2300P_DTP03_DateTime_8]
      ,[2300P_DTP01_DateTimeQualifier_9]
      ,[2300P_DTP02_FormatQualifier_9]
      ,[2300P_DTP03_DateTime_9]
      ,[2300P_DTP01_DateTimeQualifier_10]
      ,[2300P_DTP02_FormatQualifier_10]
      ,[2300P_DTP03_DateTime_10]
      ,[2300P_DTP01_DateTimeQualifier_11]
      ,[2300P_DTP02_FormatQualifier_11]
      ,[2300P_DTP03_DateTime_11]
      ,[2300P_DTP01_DateTimeQualifier_12]
      ,[2300P_DTP02_FormatQualifier_12]
      ,[2300P_DTP03_DateTime_12]
      ,[2300P_DTP01_DateTimeQualifier_13]
      ,[2300P_DTP02_FormatQualifier_13]
      ,[2300P_DTP03_DateTime_13]
      ,[2300P_DTP01_DateTimeQualifier_14]
      ,[2300P_DTP02_FormatQualifier_14]
      ,[2300P_DTP03_DateTime_14]
      ,[2300P_DTP01_DateTimeQualifier_15]
      ,[2300P_DTP02_FormatQualifier_15]
      ,[2300P_DTP03_DateTime_15]
      ,[2300P_DTP01_DateTimeQualifier_16]
      ,[2300P_DTP02_FormatQualifier_16]
      ,[2300P_DTP03_DateTime_16]
      ,[2300P_HCP01_PricingMethodology]
      ,[2300P_HCP02_RepricedAllowedAmount]
      ,[2300P_HCP03_RepricedSavingAmount]
      ,[2300P_HCP04_RepricingOrganizationIdentifier]
      ,[2300P_HCP05_RepricingPerDiemAmount]
      ,[2300P_HCP06_RepricedApprovedAmbulatoryPatientGroupCode]
      ,[2300P_HCP07_RepricedApprovedAmbulatoryPatientGroupAmount]
      ,[2300P_HCP13_RejectReasonCode]
      ,[2300P_HCP14_PolicyComplianceCode]
      ,[2300P_HCP15_ExceptionCode]
      ,[2300P_HI01-01_ConditionCodeQualifier]
      ,[2300P_HI01-02_ConditionCode ]
      ,[2300P_HI02-01_ConditionCodeQualifier]
      ,[2300P_HI02-02_ConditionCode ]
      ,[2300P_HI03-01_ConditionCodeQualifier]
      ,[2300P_HI03-02_ConditionCode ]
      ,[2300P_HI04-01_ConditionCodeQualifier]
      ,[2300P_HI04-02_ConditionCode ]
      ,[2300P_HI05-01_ConditionCodeQualifier]
      ,[2300P_HI05-02_ConditionCode ]
      ,[2300P_HI06-01_ConditionCodeQualifier]
      ,[2300P_HI06-02_ConditionCode ]
      ,[2300P_HI07-01_ConditionCodeQualifier]
      ,[2300P_HI07-02_ConditionCode ]
      ,[2300P_HI08-01_ConditionCodeQualifier]
      ,[2300P_HI08-02_ConditionCode ]
      ,[2300P_HI09-01_ConditionCodeQualifier]
      ,[2300P_HI09-02_ConditionCode ]
      ,[2300P_HI10-01_ConditionCodeQualifier]
      ,[2300P_HI10-02_ConditionCode ]
      ,[2300P_HI11-01_ConditionCodeQualifier]
      ,[2300P_HI11-02_ConditionCode ]
      ,[2300P_HI12-01_ConditionCodeQualifier]
      ,[2300P_HI12-02_ConditionCode ]
      ,[2300P_REF01_FileInformation_Qualifier]
      ,[2300P_REF01_FileInformation]
      ,[Claim Processor Receiver Date]
      ,[InNetworkIndicator ]
      ,[PatientControlNumber]
      ,[20P-Filler 04]
      ,[20P-Filler 05]
      ,[20P-Filler 06]
      ,[20P-Filler 07]
      ,[20P-Filler 08]
      ,[20P-Filler 09]
      ,[20P-Filler 10]
      ,[20P-Filler 11]
      ,[20P-Filler 12]
      ,[20P-Filler 13]
      ,[20P-Filler 14]
      ,[20P-Filler 15]
      ,[2300P_HI13-01_ConditionCodeQualifier]
      ,[2300P_HI13-02_ConditionCode ]
      ,[2300P_HI14-01_ConditionCodeQualifier]
      ,[2300P_HI14-02_ConditionCode ]
      ,[2300P_HI15-01_ConditionCodeQualifier]
      ,[2300P_HI15-02_ConditionCode ]
      ,[2300P_HI16-01_ConditionCodeQualifier]
      ,[2300P_HI16-02_ConditionCode ]
      ,[2300P_HI17-01_ConditionCodeQualifier]
      ,[2300P_HI17-02_ConditionCode ]
      ,[2300P_HI18-01_ConditionCodeQualifier]
      ,[2300P_HI18-02_ConditionCode ]
      ,[2300P_HI19-01_ConditionCodeQualifier]
      ,[2300P_HI19-02_ConditionCode ]
      ,[2300P_HI20-01_ConditionCodeQualifier]
      ,[2300P_HI20-02_ConditionCode ]
      ,[2300P_HI21-01_ConditionCodeQualifier]
      ,[2300P_HI21-02_ConditionCode ]
      ,[2300P_HI22-01_ConditionCodeQualifier]
      ,[2300P_HI22-02_ConditionCode ]
      ,[2300P_HI23-01_ConditionCodeQualifier]
      ,[2300P_HI23-02_ConditionCode ]
      ,[2300P_HI24-01_ConditionCodeQualifier]
      ,[2300P_HI24-02_ConditionCode ]
      ,[2300P_REF01_FileInformation2]
      ,[2300P_REF01_FileInformation3]
      ,[2300P_REF01_FileInformation4]
      ,[2300P_REF01_FileInformation5]
      ,[2300P_REF01_FileInformation6]
      ,[2300P_REF01_FileInformation7]
      ,[2300P_REF01_FileInformation8]
      ,[2300P_REF01_FileInformation9]
      ,[2300P_REF01_FileInformation10]
      ,[RenderingProviderSpecialty]
	  )
SELECT	
		CLAIM_ID,
		SOURCEDATAKEY,
		CASE WHEN SYSTEM_SOURCE IN ('50','30') THEN '' ELSE SYSTEM_SOURCE END,-- SourceDesc,
		GETDATE(), -- CreateDate 
		@ClaimIDPrefix + CLAIM_ID, -- 2300P_CLM01_ClaimNumber
		--CASE WHEN SOURCEDATAKEY IN ('50','30') AND @LOBCODE <> 'C54581391' THEN CAST(SOURCEDATAKEY AS VARCHAR) + CLAIM_ID
  --    		 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLAIM_ID
		--	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLAIM_ID	
		--	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLAIM_ID	
		--	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLAIM_ID -- 2300P_CLM01_ClaimNumber
		--	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'MMAI' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLAIM_ID
		--	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'CAID' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLAIM_ID
		--	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'MMAI' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLAIM_ID
		--	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'CAID' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLAIM_ID
	 --   	 WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN '51' + CLAIM_ID
	 --        WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN '52' + CLAIM_ID
	 --    END, -- 2300P_CLM01_ClaimNumber
		TOT_CHRG_AMT,					-- 2300P_CLM02_TotalClaimCharge
		POS,							-- 2300P_CLM05-01_PlaceOfService
		'',								-- 2300P_CLM05-02_BillTypeQualifier
		CLM_IND,						-- 2300P_CLM05-03_ClaimFrequencyCode
		PROV_SIGNATURE_FLAG,			-- 2300P_CLM06_ProviderSignature
		'A',							-- 2300P_CLM07_MedicareAssignment
		ASSIGN_BEN_IND1,				-- 2300P_CLM08_BenefitAssignmentIndicator
		REL_OF_INFO_FLAG,								--[2300P_CLM09_ReleaseOfInformation]
		'',								--[2300P_CLM10_PatientSignatureSource]
		'',								--[2300P_CLM11-01_RelatedCausesCode]
		'',								--[2300P_CLM11-02_RelatedCausesCode]
		'',								--[2300P_CLM11-04_AccidentState]
		'',								--[2300P_CLM11-05_AccidentCountry]
		'',								--[2300P_CLM12_SpecialProgramIndicator]
		'',								--[2300P_CLM20_DelayReason]
		'',								-- 2300P_DTP01_DateTimeQualifier_1
		'',								-- 2300P_DTP02_FormatQualifier_1
		'',								-- 2300P_DTP03_DateTime_1
		'',								-- 2300P_DTP01_DateTimeQualifier_2
		'',								-- 2300P_DTP02_FormatQualifier_2
		'',								-- 2300P_DTP03_DateTime_2
		'',								-- 2300P_DTP01_DateTimeQualifier_3
		'',								-- 2300P_DTP02_FormatQualifier_3
		'',								-- 2300P_DTP03_DateTime_3
		'',								-- 2300P_DTP01_DateTimeQualifier_4]
		'',								-- 2300P_DTP02_FormatQualifier_4
		'',								-- 2300P_DTP03_DateTime_4
		'',								-- 2300P_DTP01_DateTimeQualifier_5
		'',								-- 2300P_DTP02_FormatQualifier_5
		ADM_DT,							-- 2300P_DTP03_DateTime_5
		'',								-- 2300P_DTP01_DateTimeQualifier_6
		'',								-- 2300P_DTP02_FormatQualifier_6
		DISCHRG_DT,						-- 2300P_DTP03_DateTime_6
		'',								-- 2300P_DTP01_DateTimeQualifier_7
		'',								-- 2300P_DTP02_FormatQualifier_7
		'',								-- 2300P_DTP03_DateTime_7
		'',								-- 2300P_CN101_ContractTypeCode
	    '',                               -- [2300P_CN102_MonetaryAmount]
        '',                               -- [2300P_CN103_ContractPercentage]
        '',                               -- [2300P_CN104_ContractCode]
        '',                               -- [2300P_CN105_TermsDiscountPercent]
        '',                               -- [2300P_CN106_ContractVersionIdentifier]
        '',                               -- [2300P_AMT01_AmountQualifier]
        '',                               -- [2300P_AMT02_PatientAmountPaid]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_1]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_1]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_2]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_2]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_3]
		CASE 
		     WHEN PAYER_CLAIM_CNTRL_NUM = '' OR PAYER_CLAIM_CNTRL_NUM IS NULL THEN ''
			 WHEN @IsAdjustment = 'TRUE' THEN @ClaimIDPrefix + PAYER_CLAIM_CNTRL_NUM END,-- [2300P_REF02_ClaimReferenceNumber_3]
			 --WHEN SOURCEDATAKEY IN ('50','30') AND @LOBCODE <> 'C54581391' THEN CAST(SOURCEDATAKEY AS VARCHAR) + PAYER_CLAIM_CNTRL_NUM
    --  		 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + PAYER_CLAIM_CNTRL_NUM
			 --WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + PAYER_CLAIM_CNTRL_NUM	
			 --WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + PAYER_CLAIM_CNTRL_NUM	
			 --WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + PAYER_CLAIM_CNTRL_NUM -- 2300P_CLM01_ClaimNumber
	   -- 	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'MMAI' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + PAYER_CLAIM_CNTRL_NUM
			 --WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'CAID' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + PAYER_CLAIM_CNTRL_NUM
			 --WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'MMAI' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + PAYER_CLAIM_CNTRL_NUM
			 --WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'CAID' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + PAYER_CLAIM_CNTRL_NUM
			 --WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN '51' + PAYER_CLAIM_CNTRL_NUM
	   --      WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN '52' + PAYER_CLAIM_CNTRL_NUM
	   --  END,                             -- [2300P_REF02_ClaimReferenceNumber_3]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_4]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_4]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_5]
        PAT_CNTRL_NO,                      -- [2300P_REF02_ClaimReferenceNumber_5]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_6]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_6]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_7]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_7]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_8]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_8]
        '',                               -- [2300P_NTE01_ClaimNoteType]
        '',                               -- [2300P_NTE02_ClaimNote]
        '',                               -- [20P_Ambulance_Transport_Count]
        '',                               -- [2300P_CR101_AmbPatientWeightQualifier]
        '',                               -- [2300P_CR102_AmbulancePatientWeight]
        '',                               -- [2300P_CR104_AmbulanceTransportReason]
        '',                               -- [2300P_CR105_AmbulanceMeasure]
        '',                               -- [2300P_CR106_AmbulanceDistance]
        '',                               -- [2300P_CR109_AmbulanceRoundTripDesc]
        '',                               -- [2300P_CR110_StretcherPurposeDescription]
        '',                               -- [2300P_CRC01_ServiceCertificationCategory]
        '',                               -- [2300P_CRC02_ServiceCertificationIndicator]
        '',                               -- [2300P_CRC03_ConditionIndicatorCode]
        '',                               -- [2300P_CRC04_ConditionIndicatorCode]
        '',                               -- [2300P_CRC05_ConditionIndicatorCode]
        '',                               -- [2300P_CRC06_ConditionIndicatorCode]
        '',                               -- [2300P_CRC07_ConditionIndicatorCode]
        PRINCIPAL_DIAG_QUAL,                               -- [2300P_HI01-01_DXType_1]
        INST_PRINCIPAL_DIAG_CD,                               -- [2300P_HI01-02_DXCode_1]
        DIAG_CD_QUAL2,                               -- [2300P_HI02-01_DXType_1]
        DIAG_CD2,                               -- [2300P_HI02-02_DXCode_1]
        DIAG_CD_QUAL3,                               -- [2300P_HI03-01_DXType_1]
        DIAG_CD3,                               -- [2300P_HI03-02_DXCode_1]
        DIAG_CD_QUAL4,                               -- [2300P_HI04-01_DXType_1]
        DIAG_CD4,                               -- [2300P_HI04-02_DXCode_1]
        DIAG_CD_QUAL5,                               -- [2300P_HI05-01_DXType_1]
        DIAG_CD5,                               -- [2300P_HI05-02_DXCode_1]
        DIAG_CD_QUAL6,                               -- [2300P_HI06-01_DXType_1]
        DIAG_CD6,                               -- [2300P_HI06-02_DXCode_1]
        DIAG_CD_QUAL7,                               -- [2300P_HI07-01_DXType_1]
        DIAG_CD7,                               -- [2300P_HI07-02_DXCode_1]
        DIAG_CD_QUAL8,                               -- [2300P_HI08-01_DXType_1]
        DIAG_CD8,                               -- [2300P_HI08-02_DXCode_1]
        DIAG_CD_QUAL9,                               -- [2300P_HI09-01_DXType_1]
        DIAG_CD9,                               -- [2300P_HI09-02_DXCode_1]
        DIAG_CD_QUAL10,                               -- [2300P_HI10-01_DXType_1]
        DIAG_CD10,                               -- [2300P_HI10-02_DXCode_1]
        DIAG_CD_QUAL11,                               -- [2300P_HI11-01_DXType_1]
        DIAG_CD11,                               -- [2300P_HI11-02_DXCode_1]
        DIAG_CD_QUAL12,                               -- [2300P_HI12-01_DXType_1]
        DIAG_CD12,                               -- [2300P_HI12-02_DXCode_1]
        '',                               -- [2310AP_NM101_ProviderRole]
        '',                               -- [2310AP_NM102_PersonIndicator]
        REF_PROV_LNAME,                               -- [2310AP_NM103_LastName]
        REF_PROV_FNAME,                               -- [2310AP_NM104_FirstName]
        REF_PROV_MID_INIT,                               -- [2310AP_NM105_MiddleName]
        REF_PROV_SFX,                               -- [2310AP_NM107_Suffix]
        '',                               -- [2310AP_NM108_ProviderIdentifierQualifer]
        REF_PROV_NPI,                               -- [2310AP_NM109_ProviderIdentifier]
        '',                               -- [2310AP_REF01_ProviderIdentifierQualifer]
        REF_PROV_LICENSE_NO,                               -- [2310AP_REF02_ProviderIdentifier]
        '',                               -- [2310AP_REF01_ProviderIdentifierQualifer_02]
        REF_PROV_ID,                               -- [2310AP_REF02_ProviderIdentifier_02]
        '',                               -- [2310BP_NM101_ProviderRole]
        '',                               -- [2310BP_NM102_PersonIndicator]
        CASE WHEN RENDERING_PROV_FIRST_NAME =''  and RENDERING_PROV_ORG_NAME <> '' THEN RENDERING_PROV_ORG_NAME 
		     WHEN RENDERING_PROV_FIRST_NAME ='' and RENDERING_PROV_ORG_NAME ='' THEN RENDERING_PROV_LAST_NAME		
				ELSE RENDERING_PROV_LAST_NAME  END,   --    [2310BP_NM103_LastName]
        RENDERING_PROV_FIRST_NAME,                               -- [2310BP_NM104_FirstName]
        RENDERING_PROV_MID_INIT,                               -- [2310BP_NM105_MiddleName]
        RENDERING_PROV_SFX,                               -- [2310BP_NM107_Suffix]
        '',                               -- [2310BP_NM108_ProviderIdentifierQualifer]
        RENDERING_PROV_NPI,                               -- [2310BP_NM109_ProviderIdentifier]
        '',                               -- [2310BP_PRV01_ProviderCode]
        '',                               -- [2310BP_PRV02_ProviderCodeQualifer]
        RENDERING_PROV_TAXONOMY,                               -- [2310BP_PRV03_ProviderTaxonomy]
        '',                               -- [2310BP_REF01_ProviderIdentifierQualifer_1]
        RENDERING_PROV_ID,                               -- [2310BP_REF02_ProviderIdentifier_1]
        '',                               -- [2310BP_REF01_ProviderIdentifierQualifer_2]
        '',                               -- [2310BP_REF02_ProviderIdentifier_2]
        '',                               -- [20P_RenderingProviderAddress1]
        '',                               -- [20P_RenderingProviderAddress2]
        '',                               -- [20P_RenderingProviderCity]
        '',                               -- [20P_RenderingProviderState]
        '',                               -- [20P_RenderingProviderZip]
        '',                               -- [2310CP_NM101_ProviderRole]
        '',                               -- [2310CP_NM102_PersonIndicator]
        '',                               -- [2310CP_NM103_LastName]
        '',                               -- [2310CP_NM108_ProviderIdentifierQualifer]
        '',                               -- [2310CP_NM109_ProviderIdentifier]
        '',                               -- [2310CP_N301_AddressLine1]
        '',                               -- [2310CP_N302_AddressLine2]
        '',                               -- [2310CP_N401_City]
        '',                               -- [2310CP_N402_State]
        '',                               -- [2310CP_N403_PostalCode]
        '',                               -- [2310CP_N404_Country]
        '',                               -- [2310CP_REF01_ProviderIdentifierQualifer]
        '',                               -- [2310CP_REF02_ProviderIdentifier]
        '',                               -- [2310DP_NM101_ProviderRole]
        '',                               -- [2310DP_NM102_PersonIndicator]
        '',                               -- [2310DP_NM103_LastName]
        '',                               -- [2310DP_NM104_FirstName]
        '',                               -- [2310DP_NM105_MiddleName]
        '',                               -- [2310DP_NM107_Suffix]
        '',                               -- [2310DP_NM108_ProviderIdentifierQualifer]
        '',                               -- [2310DP_NM109_ProviderIdentifier]
        '',                               -- [2310DP_REF01_ProviderIdentifierQualifer]
        '',                               -- [2310DP_REF02_ProviderIdentifier]
        '',                               -- [2310EP_NM101_ProviderRole]
        '',                               -- [2310EP_NM102_PersonIndicator]
       TRANS_PICKUP_ADDR1,                               -- [2310EP_N301_AddressLine1]
        '',                               -- [2310EP_N302_AddressLine2]
        TRANS_PICKUP_CITY,                               -- [2310EP_N401_City]
        TRANS_PICKUP_STATE,                               -- [2310EP_N402_State]
        TRANS_PICKUP_ZIP + TRANS_PICKUP_ZIP4,             -- [2310EP_N403_PostalCode]
        '',                               -- [2310EP_N404_Country]
        '',                               -- [2310EP_REF01_ProviderIdentifierQualifer]
        '',                               -- [2310EP_REF02_ProviderIdentifier]
        '',                               -- [2310FP_NM101_ProviderRole]
        '',                               -- [2310FP_NM102_PersonIndicator]
        '',                               -- [2310FP_NM103_ORG_LastName]
        TRANS_DROPOFF_ADDR1,                               -- [2310FP_N301_AddressLine1]
        '',                               -- [2310FP_N302_AddressLine2]
        TRANS_DROPOFF_CITY,                               -- [2310FP_N401_City]
        TRANS_DROPOFF_STATE,                               -- [2310FP_N402_State]
        TRANS_DROPOFF_ZIP + TRANS_DROPOFF_ZIP4,           -- [2310FP_N403_PostalCode]
        '',                               -- [2310FP_N404_Country]
        '',                               -- [2310FP_REF01_ProviderIdentifierQualifer]
        '',                               -- [2310FP_REF02_ProviderIdentifier]
        '',                               -- [2300P_PWK01_AttachmentReportType]
        '',                               -- [2300P_PWK02_AttachmentTransmissionCode]
        '',                               -- [2300P_PWK06_AttachmentControlNumber]
        '',                               -- [2300P_REF01_InvestigationalDeviceExemptionNumber_Qualifier]
        '',                               -- [2300P_REF02_InvestigationalDeviceExemptionNumber]
        '',                               -- [2300P_REF01_ServiceAuthorizationExceptionCode_Qualifier]
        '',                               -- [2300P_REF02_ServiceAuthorizationExceptionCode]
        '',                               -- [2300P_REF01_MammographyCertificationNumber_Qualifier]
        '',                               -- [2300P_REF01_MammographyCertificationNumber]
        '',                               -- [2300P_CR208_PatientConditionCode]
        '',                               -- [2300P_CR210_PatientDescription]
        '',                               -- [2300P_CR211_PatientDescription]
        '',                               -- [2300P_HI101-2_AnesthesiaRelatedSurgicalProcedure]
        '',                               -- [2300P_HI102-2_AnesthesiaRelatedSurgicalProcedure]
        '',                               -- [2300P_DTP01_DateTimeQualifier_7_02]
        '',                               -- [2300P_DTP02_FormatQualifier_7_02]
        '',                               -- [2300P_DTP03_DateTime_7_02]
        '',                               -- [2300P_DTP01_DateTimeQualifier_8]
        '',                               -- [2300P_DTP02_FormatQualifier_8]
        '',                               -- [2300P_DTP03_DateTime_8]
        '',                               -- [2300P_DTP01_DateTimeQualifier_9]
        '',                               -- [2300P_DTP02_FormatQualifier_9]
        '',                               -- [2300P_DTP03_DateTime_9]
        '',                               -- [2300P_DTP01_DateTimeQualifier_10]
        '',                               -- [2300P_DTP02_FormatQualifier_10]
        '',                               -- [2300P_DTP03_DateTime_10]
        '',                               -- [2300P_DTP01_DateTimeQualifier_11]
        '',                               -- [2300P_DTP02_FormatQualifier_11]
        '',                               -- [2300P_DTP03_DateTime_11]
        '',                               -- [2300P_DTP01_DateTimeQualifier_12]
        '',                               -- [2300P_DTP02_FormatQualifier_12]
        '',                               -- [2300P_DTP03_DateTime_12]
        '',                               -- [2300P_DTP01_DateTimeQualifier_13]
        '',                               -- [2300P_DTP02_FormatQualifier_13]
        '',                               -- [2300P_DTP03_DateTime_13]
        '',                               -- [2300P_DTP01_DateTimeQualifier_14]
        '',                               -- [2300P_DTP02_FormatQualifier_14]
        '',                               -- [2300P_DTP03_DateTime_14]
        '',                               -- [2300P_DTP01_DateTimeQualifier_15]
        '',                               -- [2300P_DTP02_FormatQualifier_15]
        '',                               -- [2300P_DTP03_DateTime_15]
        '',                               -- [2300P_DTP01_DateTimeQualifier_16]
        '',                               -- [2300P_DTP02_FormatQualifier_16]
        '',                               -- [2300P_DTP03_DateTime_16]
        '',                               -- [2300P_HCP01_PricingMethodology]
        '',                               -- [2300P_HCP02_RepricedAllowedAmount]
        '',                               -- [2300P_HCP03_RepricedSavingAmount]
        '',                               -- [2300P_HCP04_RepricingOrganizationIdentifier]
        '',                               -- [2300P_HCP05_RepricingPerDiemAmount]
        '',                               -- [2300P_HCP06_RepricedApprovedAmbulatoryPatientGroupCode]
        '',                               -- [2300P_HCP07_RepricedApprovedAmbulatoryPatientGroupAmount]
        '',                               -- [2300P_HCP13_RejectReasonCode]
        '',                               -- [2300P_HCP14_PolicyComplianceCode]
        '',                               -- [2300P_HCP15_ExceptionCode]
        '',                               -- [2300P_HI01-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI01-02_ConditionCode ]
        '',                               -- [2300P_HI02-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI02-02_ConditionCode ]
        '',                               -- [2300P_HI03-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI03-02_ConditionCode ]
        '',                               -- [2300P_HI04-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI04-02_ConditionCode ]
        '',                               -- [2300P_HI05-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI05-02_ConditionCode ]
        '',                               -- [2300P_HI06-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI06-02_ConditionCode ]
        '',                               -- [2300P_HI07-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI07-02_ConditionCode ]
        '',                               -- [2300P_HI08-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI08-02_ConditionCode ]
        '',                               -- [2300P_HI09-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI09-02_ConditionCode ]
        '',                               -- [2300P_HI10-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI10-02_ConditionCode ]
        '',                               -- [2300P_HI11-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI11-02_ConditionCode ]
        '',                               -- [2300P_HI12-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI12-02_ConditionCode ]
        '',                               -- [2300P_REF01_FileInformation_Qualifier]
        '',                               -- [2300P_REF01_FileInformation]
        '',                               -- [Claim Processor Receiver Date]
        '',                               -- [InNetworkIndicator ]
        '',                               -- [PatientControlNumber]
        '',                               -- [20P-Filler 04]
        '',                               -- [20P-Filler 05]
        '',                               -- [20P-Filler 06]
        '',                               -- [20P-Filler 07]
        '',                               -- [20P-Filler 08]
        '',                               -- [20P-Filler 09]
        '',                               -- [20P-Filler 10]
        '',                               -- [20P-Filler 11]
        '',                               -- [20P-Filler 12]
        '',                               -- [20P-Filler 13]
        '',                               -- [20P-Filler 14]
        '',                               -- [20P-Filler 15]
        '',                               -- [2300P_HI13-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI13-02_ConditionCode ]
        '',                               -- [2300P_HI14-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI14-02_ConditionCode ]
        '',                               -- [2300P_HI15-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI15-02_ConditionCode ]
        '',                               -- [2300P_HI16-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI16-02_ConditionCode ]
        '',                               -- [2300P_HI17-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI17-02_ConditionCode ]
        '',                               -- [2300P_HI18-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI18-02_ConditionCode ]
        '',                               -- [2300P_HI19-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI19-02_ConditionCode ]
        '',                               -- [2300P_HI20-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI20-02_ConditionCode ]
        '',                               -- [2300P_HI21-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI21-02_ConditionCode ]
        '',                               -- [2300P_HI22-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI22-02_ConditionCode ]
        '',                               -- [2300P_HI23-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI23-02_ConditionCode ]
        '',                               -- [2300P_HI24-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI24-02_ConditionCode ]
        '',                               -- [2300P_REF01_FileInformation2]
        '',                               -- [2300P_REF01_FileInformation3]
        '',                               -- [2300P_REF01_FileInformation4]
        '',                               -- [2300P_REF01_FileInformation5]
        '',                               -- [2300P_REF01_FileInformation6]
        '',                               -- [2300P_REF01_FileInformation7]
        '',                               -- [2300P_REF01_FileInformation8]
        '',                               -- [2300P_REF01_FileInformation9]
        '',                               -- [2300P_REF01_FileInformation10]
        ''	                              -- [RenderingProviderSpecialty]
FROM	MEDICAID.dbo.OUTB_PROF_HEADER


/*---------------------------------------------------------------------*/
/* POPULATE 310 REC TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_310P_Rec_Header_Archive 
SELECT *, getdate()  FROM EE_CSV_310P_Rec_Header

TRUNCATE TABLE [dbo].[EE_CSV_310P_Rec_Header]

INSERT INTO [dbo].[EE_CSV_310P_Rec_Header] (
[ClaimID],
[SourceDataKey],
[SourceDesc],
[CreateDate],
[2320_SBR01_PayerResponsibilitySequence],
[2320_SBR02_SubscriberRelationship],
[2320_SBR09_ClaimFilingIndicator],
[2320_AMT02_COBAmount_1],
[2320_OI03_AssignBenefitsIndicator],
[2330A_NM103_LastName],
[2330A_NM104_FirstName],
[2330A_N301_AddressLine1],
[2330A_N302_AddressLine2],
[2330A_N401_City],
[2330A_N402_State],
[2330A_N403_PostalCode],
[2330B_NM103_Name],
[2330B_NM109_OrganizationIdentifier],
[2330B_N301_AddressLine1],
[2330B_N302_AddressLine2],
[2330B_N401_City],
[2330B_N402_State],
[2330B_N403_PostalCode]
)
SELECT 
claim_id,        -- ClaimID - varchar(20)
SOURCEDATAKEY,         -- SourceDataKey - int
SYSTEM_SOURCE,        -- SourceDesc - varchar(60)
GETDATE(), -- CreateDate - datetime
PAYER_RESP, -- PayerResponsibilityCode
REL_CD1, --RelationshipCode
CLM_FIL_INDCD1,
AMOUNT_PAID,
ASSIGN_BEN_IND1,
MEMBER_LAST_NAME,
MEMBER_FIRST_NAME,
MEMBER_ADDR1,
MEMBER_ADDR2, 
MEMBER_CITY,
MEMBER_STATE,
MEMBER_ZIP + MEMBER_ZIP4,
OTH_PAYER1_NAME,
OTH_PAYER1_PLANID,
OTH_PAYER1_ADDRESS1,
OTH_PAYER1_ADDRESS2,
OTH_PAYER1_CITY,
OTH_PAYER1_STATE,
[OTH_PAYER1_ZIP] + [OTH_PAYER1_ZIP4]
FROM	MEDICAID.dbo.OUTB_PROF_HEADER

/*---------------------------------------------------------------------*/
/* UPDATE SYSLOG                                                       */
/*---------------------------------------------------------------------*/

SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM MEDICAID.dbo.OUTB_PROF_HEADER)
									
				BEGIN TRANSACTION
						UPDATE MEDICAID.dbo.EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_MEDICAID_PROF_CSV_100P_150P_20P_310P_Header'
										and END_DT is null
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
