﻿



/*********************************************************************************************************************************
Procedure:		MedicaidPennsyvaniaCGUpdates

Author:			Aaron Ridley

Date:			03/31/2023

Purpose:		Populate Pennsyvania Companion Guide Specific Updates. This script will overrite the specified records in the associated CSV tables 

Job:            EDIFECS Pennsyvania Medicaid (Executed in File sprocs) 

History:		Date	  Author  HPSM    		Action									

    

Test Script:	


*********************************************************************************************************************************/
--/*

CREATE PROCEDURE [dbo].[MedicaidPennsyvaniaCGUpdates] 

    @CLAIM_TYPE varchar(2),
    @JobID int

AS
/*********************************************************************************************************************************/


/* Start Process  */ 


INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('dbo.MedicaidPennsylvaniaCGUpdates' + '-'  + rtrim(@CLAIM_TYPE)
				,'1'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)


/*---------------------------------------------------------------------------------

	TABLE CLEANUP - EXECUTION PREPARATION 
-----------------------------------------------------------------------------------*/

IF OBJECT_ID('tempdb.dbo.##CLAIMSPA') IS NOT NULL
			DROP TABLE ##CLAIMSPA;


CREATE TABLE ##CLAIMSPA (
	CLAIMID VARCHAR(20) NULL,
	MEMBERID VARCHAR(25) NULL, 
	PBPCODE VARCHAR(25) NULL, 
	PRODUCTTYPE VARCHAR(50) NULL, 
	REGULATORYMARKET VARCHAR(25),
	CMS_ICN VARCHAR(25),
	DMEFLAG VARCHAR(10), 
	LOBCODE VARCHAR(25) 
	) 

/*---------------------------------------------------------------------------------

	IDENTIFY THE MEMBER PBPCODE UTILIZING MONTHLYMEMBERSHIPDIM  
-----------------------------------------------------------------------------------*/
			
		IF @CLAIM_TYPE = 'I'
		BEGIN 
		INSERT INTO ##CLAIMSPA (CLAIMID, MEMBERID, PBPCODE, PRODUCTTYPE, REGULATORYMARKET, LOBCODE)
		SELECT
			DISTINCT 
				CLMAgg.ClaimID, -- CLAIM_ID
				CLMAgg.MemberID,
				MMD.PBPCODE,
				MMD.PRODUCTTYPE	,
				MMD.REGULATORYMARKET,
				CLMAgg.LOBCODE 			
		FROM dbo.EE_CSV_150I_Rec_Header CSVHeader
		INNER JOIN dbo.ClaimAgg CLMAgg on CSVHEADER.ClaimID = CLMAgg.ClaimID
		INNER JOIN dbo.MonthlyMembershipDim MMD ON MMD.MemberID = CLMAgg.Memberid  
												AND LEFT(CLMAgg.BEGINSERVICEDATEKEY,4) = LEFT(MMD.REPORTDATEKEY,4) 
												AND MMD.REGULATORYMARKET = 'PA'											
		
		END;
	
		IF @CLAIM_TYPE = 'P'
		BEGIN 
		INSERT INTO ##CLAIMSPA (CLAIMID, MEMBERID, PBPCODE, PRODUCTTYPE, REGULATORYMARKET, DMEFLAG, LOBCODE)
		SELECT
				DISTINCT 
				CLMAgg.ClaimID, -- CLAIM_ID
				CLMAgg.MemberID,
				MMD.PBPCODE,
				MMD.PRODUCTTYPE	,
				MMD.REGULATORYMARKET,
				CASE WHEN CMSTaxonomy.NPI IS NULL THEN 'FALSE' ELSE 'TRUE' END AS DMEFLAG,
				CLMAgg.LOBCODE
		FROM dbo.EE_CSV_150P_Rec_Header CSVHeader
		INNER JOIN dbo.ClaimAgg CLMAgg ON CLMAgg.CLAIMID = CSVHeader.CLAIMID 
		INNER JOIN dbo.MonthlyMembershipDim MMD ON MMD.MemberID = CLMAgg.Memberid  
												AND LEFT(CLMAgg.BEGINSERVICEDATEKEY,4) = LEFT(MMD.REPORTDATEKEY,4) 
												AND MMD.REGULATORYMARKET = 'PA'
		LEFT JOIN EDPS_DATA.[IDQ].[CMSTaxonomy] CMSTaxonomy  on CLMAgg.PROVIDERNPI  = CMSTaxonomy.NPI 
												AND healthcareprovidertaxonomycode IN ('332B00000X','332BC3200X','332BD1200X','332BN1400X','332BX2000X')
		END;

/*---------------------------------------------------------------------------------

	IDENTIFY THE CMS_ICN FOR CLAIMS ACCEPTED AT THE MAO02 LEVEL 
-----------------------------------------------------------------------------------*/
		
		UPDATE CLMS
		SET CMS_ICN = OBCS.CMS_ICN
		FROM ##CLAIMSPA CLMS
		LEFT JOIN WIPRO.dbo.OUTB_CLAIM_STATUS OBCS ON CLMS.ClaimID = OBCS.CLAIM_ID 
		WHERE OBCS.CLMSTAT_STATUS IN ('A-ICN','MAO-004');

/*---------------------------------------------------------------------------------

	UPDATE THE RESPECTIVE CSV TABLES WITH THE IDENTIFIED OVERLAY VALUES
-----------------------------------------------------------------------------------*/

		IF @CLAIM_TYPE = 'I'
		BEGIN 

		UPDATE CSV100
		SET Contract_ID = RTRIM(LOBDIM.HCFACode),
			DestinationID = 'EDSCMS'
		FROM dbo.EE_CSV_100I_Rec_Header CSV100
		INNER JOIN ##CLAIMSPA CLMS ON CSV100.ClaimID = CLMS.ClaimID
		JOIN MDQOLIB.dbo.LineofBusinessDim LOBDIM ON CLMS.LOBCODE = LOBDIM.LOBCODE;

		UPDATE CSV150
		SET [2000B_SBR03_SubscriberPolicyNumber] = CLMS.PBPCODE
		FROM dbo.EE_CSV_150I_Rec_Header CSV150
		INNER JOIN ##CLAIMSPA CLMS ON CSV150.ClaimID = CLMS.ClaimID; 

		UPDATE CSV310
		SET [2330B_REF01_OrganizationIdQualifier_5] = 'F8'
			,[2330B_REF01_OrganizationIdentifier_5] = CLMS.CMS_ICN 
		FROM dbo.EE_CSV_310I_Rec_Header CSV310
		INNER JOIN ##CLAIMSPA CLMS ON CSV310.ClaimID = CLMS.ClaimID
		END; 

		IF @CLAIM_TYPE = 'P'
		BEGIN 

		UPDATE CSV100
		SET DME = CLMS.DMEFLAG,
			Contract_ID = RTRIM(LOBDIM.HCFACode),
			DestinationID = 'EDSCMS'
		FROM [dbo].[EE_CSV_100P_Rec_Header] CSV100 
		INNER JOIN ##CLAIMSPA CLMS ON CSV100.ClaimID = CLMS.ClaimID
		JOIN MDQOLIB.dbo.LineofBusinessDim LOBDIM ON CLMS.LOBCODE = LOBDIM.LOBCODE;

		UPDATE CSV150
		SET [2000B_SBR03_SubscriberPolicyNumber] = CLMS.PBPCODE
		FROM dbo.EE_CSV_150P_Rec_Header CSV150
		INNER JOIN ##CLAIMSPA CLMS ON CSV150.ClaimID = CLMS.ClaimID;
		
		UPDATE CSV310
		SET [2330B_REF01_OrganizationIdQualifier_5] = 'F8'
			,[2330B_REF01_OrganizationIdentifier_5] = CLMS.CMS_ICN 
		FROM dbo.EE_CSV_310P_Rec_Header CSV310
		INNER JOIN ##CLAIMSPA CLMS ON CSV310.ClaimID = CLMS.ClaimID
		
		END; 


/*    SYSLOG UPDATES - END OF PROCESS 
----------------------------------------------------------------------------------------------------------*/ 
						
						UPDATE dbo.EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = (SELECT COUNT(DISTINCT(CLAIMID)) FROM ##CLAIMSPA)
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'dbo.MedicaidPennsylvaniaCGUpdates' + '-'  + rtrim(@CLAIM_TYPE)
										and END_DT is null