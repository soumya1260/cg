﻿CREATE PROCEDURE [dbo].[pr_MEDICAID_INST_CSV_40I_431I_Detail]
AS
/***************************************************************************************************
** CREATE DATE: 02/18/2020
**
** AUTHOR: Aaron Ridley 
**
** DESCRIPTION: PROCEDURE WILL POPULATE CSV DETAIL TABLES (40I,431I)
**              UTILIZING THE OUTB_INST_DETAIL AS SOURCE
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
02/18/20		Aaron Ridley	Version 1
05/15/21		Subhash Acharya	TETDM-2460 Service Line Duplicates resubmission - Updating Modifiers for claims populated 
								in the Service Line Dupe table 

*****************************************************************************************************/	

--DECLARE VARIABLES

			DECLARE
			
			@TOTAL_RECORDS INT
		
			BEGIN TRANSACTION 
					INSERT INTO MEDICAID.dbo.EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_MEDICAID_INST_CSV_40I_431I_Detail'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					if @@ERROR <> 0
							begin
								rollback 
							end
				commit

/*---------------------------------------------------------------------*/
/* POPULATE 40I TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_40I_Rec_Detail_Archive 
SELECT *, getdate()  FROM dbo.EE_CSV_40I_Rec_Detail

TRUNCATE TABLE dbo.EE_CSV_40I_Rec_Detail

INSERT INTO dbo.EE_CSV_40I_Rec_Detail
SELECT DISTINCT
 b.Claim_ID AS ClaimID 
,b.SourceDataKey 
,'' AS SourceDesc 
,GETDATE() AS CreateDate 
,CLAIM_LINE_NO			AS ClaimLineNumber
,CLAIM_LINE_NO											AS [2400I_LX01_LineCounter]
,REV_CD1												AS [2400I_SV201_RevenueCode]
,CASE WHEN PROC_CD = '' THEN '' 
      ELSE SERV_ID_QUAL END                             AS [2400I_SV202-01_ServiceCodeType]
,PROC_CD												AS [2400I_SV202-02_ServiceCode]


,PROC_MOD1												AS [2400I_SV202-03_ServiceModifier1]
,PROC_MOD2												AS [2400I_SV202-04_ServiceModifier2]
,PROC_MOD3												AS [2400I_SV202-05_ServiceModifier3]
,PROC_MOD4												AS [2400I_SV202-06_ServiceModifier4]
,Medicaid.dbo.fn_edi_parse(PROC_DESC) 					AS [2400I_SV202-07_ServiceCodeDescription]
,TOTAL_CHRG_AMT											AS [2400I_SV203_LineCharge]
, 'UN' /*CASE WHEN ISNULL(PROC_CD,'') <> '' THEN 'UN'ELSE '' END  [2400I_SV204_ServiceUnitMeasure]V */
,QTY_UNITS												AS [2400I_SV205_Quantity]
,''						AS [2400I_SV207_NonCoveredCharge]
,''									AS [2400I_PWK01_ReportType]
,''									AS [2400I_PWK02_TransmissionCode]
,''									AS [2400I_PWK05_CodeQualifier]
,''									AS [2400I_PWK06_ControlNumber]
,''									AS [2400I_DTP01_DateTimeQualifier]
,''									AS [2400I_DTP02_FormatQualifier]
,CASE WHEN SERV_START_DT = SERV_END_DT THEN SERV_START_DT 			
	  WHEN ISNULL(SERV_END_DT,'') = '' THEN SERV_START_DT		
	  ELSE concat (SERV_START_DT, '-',SERV_END_DT) END									
														AS [2400I_DTP03_Date]
--,SERV_END_DT											AS [2400I_DTP03_Date]
,''			AS [2400I_REF01_ServiceRefNumberQualifier]
,CLAIM_LINE_NO											AS [2400I_REF02_ServiceRefNumber]
,''									AS [2410I_LIN02_DrugCodeType]
,''									AS [2410I_LIN03_NationalDrugCode]
,''									AS [2410I_CTP04_Quantity]
,''									AS [2410I_CTP05-01_Units]
,''									AS [2410I_REF01_ReferenceIDQualifier]
,''									AS [2410I_REF02_ReferenceIdentifier]
,''									AS [2400I_REF01_RepricedLineItemReference_Qualifier]
,''									AS [2400I_REF02_RepricedLineItemReferenceNumber]
,''									AS [2400I_REF01_AdjustedRepricedLineItemReference_Qualifier]
,''									AS [2400I_REF02_AdjustedRepricedLineItemReferenceNumber]
,''									AS [2400I_HCP01_PricingMethodology]
,''									AS [2400I_HCP02_RepricedAllowedAmt]
,''									AS [2400I_HCP03_RepricedSavingAmt]
,''									AS [2400I_HCP04_RepricingOrganziationIdentifier]
,''									AS [2400I_HCP05_RepricingPerDiem]
,''									AS [2400I_HCP06_APGPricingCode]
,''									AS [2400I_HCP07_APGPricingAmt]
,''									AS [2400I_HCP09_ServiceType]
,''									AS [2400I_HCP10_ApprovedServiceCode]
,''									AS [2400I_HCP11_RepricingUnits]
,''									AS [2400I_HCP12_RepricingQuantity]
,''									AS [2400I_HCP13_RejectReasonCode]
,''									AS [2400I_HCP14_PolicyComplianceCode]
,''									AS [2400I_HCP15_ExceptionCode]
,''									AS [2410I_REF01_ReferenceIDQualifier_2]
,''									AS [2410I_REF02_ReferenceIdentifier_2]
,''									AS [40-IFiller 01]
--,(SELECT TOP 1 CASE WHEN C.CAPITATEDLINEFLAG = 'Y' THEN '05'ELSE '' END 
--		FROM EDPS_DATA.DBO.CLAIMDETAILDIM C
--		WHERE O.SOURCEDATAKEY = C.SOURCEDATAKEY AND C.CLAIMID = O.CLAIM_ID AND C.CLAIMLINEID = O.CLAIM_LINE_NO )
,''									AS [40I-Filler 02]
,''									AS [40I-Filler 03]
,''									AS [40I-Filler 04]
,''									AS [40I-Filler 05]
,''									AS [2420AI_NM101_ProviderRole]
,''									AS [2420AI_NM102_PersonIndicator]
,''									AS [2420AI_NM103_LastName]
,''									AS [2420AI_NM104_FirstName]
,''									AS [2420AI_NM105_MiddleName]
,''									AS [2420AI_NM107_Suffix]
,''									AS [2420AI_NM108_ProviderIdentifierQualifer]
,''									AS [2420AI_NM109_ProviderIdentifier]
,''									AS [2420AI_REF01_ProviderIdentifierQualifer_1]
,''									AS [2420AI_REF02_ProviderIdentifier_1]
,''									AS [2420AI_REF01_ProviderIdentifierQualifer_2]
,''									AS [2420AI_REF02_ProviderIdentifier_2]
,''									AS [2420AI_REF01_ProviderIdentifierQualifer_3]
,''									AS [2420AI_REF02_ProviderIdentifier_3]
,''									AS [2420BI_NM101_ProviderRole]
,''									AS [2420BI_NM102_PersonIndicator]
,''									AS [2420BI_NM103_LastName]
,''									AS [2420BI_NM104_FirstName]
,''									AS [2420BI_NM105_MiddleName]
,''									AS [2420BI_NM107_Suffix]
,''									AS [2420BI_NM108_ProviderIdentifierQualifer]
,''									AS [2420BI_NM109_ProviderIdentifier]
,''									AS [2420BI_REF01_ProviderIdentifierQualifer_1]
,''									AS [2420BI_REF02_ProviderIdentifier_1]
,''									AS [2420BI_REF01_ProviderIdentifierQualifer_2]
,''									AS [2420BI_REF02_ProviderIdentifier_2]
,''									AS [2420BI_REF01_ProviderIdentifierQualifer_3]
,''									AS [2420BI_REF02_ProviderIdentifier_3]
,''									AS [2420CI_NM101_ProviderRole]
,''									AS [2420CI_NM102_PersonIndicator]
,''									AS [2420CI_NM103_LastName]
,''									AS [2420CI_NM104_FirstName]
,''									AS [2420CI_NM105_MiddleName]
,''									AS [2420CI_NM107_Suffix]
,''									AS [2420CI_NM108_ProviderIdentifierQualifer]
,''									AS [2420CI_NM109_ProviderIdentifier]
,''									AS [2420CI_REF01_ProviderIdentifierQualifer_1]
,''									AS [2420CI_REF02_ProviderIdentifier_1]
,''									AS [2420CI_REF01_ProviderIdentifierQualifer_2]
,''									AS [2420CI_REF02_ProviderIdentifier_2]
,''									AS [2420CI_REF01_ProviderIdentifierQualifer_3]
,''									AS [2420CI_REF02_ProviderIdentifier_3]
,''									AS [2420DI_NM101_ProviderRole]
,''									AS [2420DI_NM102_PersonIndicator]
,''									AS [2420DI_NM103_LastName]
,''									AS [2420DI_NM104_FirstName]
,''									AS [2420DI_NM105_MiddleName]
,''									AS [2420DI_NM107_Suffix]
,''									AS [2420DI_NM108_ProviderIdentifierQualifer]
,''									AS [2420DI_NM109_ProviderIdentifier]
,''									AS [2420DI_REF01_ProviderIdentifierQualifer_1]
,''									AS [2420DI_REF02_ProviderIdentifier_1]
,''									AS [2420DI_REF01_ProviderIdentifierQualifer_2]
,''									AS [2420DI_REF02_ProviderIdentifier_2]
,''									AS [InNetworkIndicator]
,''									AS [ServiceLineContractID]
,''									AS [TPLPaidAmount]
,''									AS [2400I_NTE02_ServiceNote]
,''									AS [AccommodationCode]
,''									AS [40I-IFiller 11]
,''									AS [40I-IFiller 12]
,''									AS [40I-IFiller 13]
,''									AS [40I-IFiller 14]
,''									AS [40I-IFiller 15]
,''									AS [ServiceHealthPlan]
,''									AS [ServiceBenefitPlan]
,''									AS [ServiceAdministrativeCounty]
,''									AS [ServiceResidenceCounty]
,''									AS [ServiceEligibilityCode]
,''									AS [ServiceSubProgram1]
,''									AS [ServiceSubProgram2]
,''									AS [ServiceSubProgram3]
,''									AS [ServiceSubProgram4]
,''									AS [ServiceArrangementCode]
,''									AS [ServiceTribalCode]
,''									AS [FamilyPlanningService]
,''									AS [40I_MediaType]
,''									AS [Beneficiary Cost Sharing Status]
,''									AS [Out of Pocket Maximum]
,''									AS [Beneficiary Lock-In STATUS]
FROM MEDICAID..OUTB_INST_DETAIL b



/*---------------------------------------------------------------------*/
/* POPULATE 431I TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_431I_Rec_Detail_Archive 
SELECT *, getdate()  FROM dbo.EE_CSV_431I_Rec_Detail

TRUNCATE TABLE dbo.EE_CSV_431I_Rec_Detail

INSERT INTO [dbo].EE_CSV_431I_Rec_Detail
	(
		[ClaimID]
		,[SourceDataKey]
		,[SourceDesc]
		,[CreateDate]
		,ClaimLineNumber

		,[2430_SVD01_COBPrimaryPayerID]
		,[2430_SVD02_COBServicePaidAmount]
		,[431_ClaimLineDisposition]
		,[2430_SVD03_01_ServiceCodeType]
		,[2430_SVD03_02_ServiceCode]
		,[2430_SVD03_03_ServiceModifier1]
		,[2430_SVD03_04_ServiceModifier2]
		,[2430_SVD03_05_ServiceModifier3]
		,[2430_SVD03_06_ServiceModifier4]
		,[2430_SVD03_07_ServiceCodeDescription]
		,[2430_SVD04_RevenueCode]
		,[2430_SVD05_Quantity]
		,[2430_SVD06_BundledLineNumber]
		,[2430_LineLevelDenial_1]
		,[2430_LineLevelDenial_2]
		,[2430_LineLevelDenial_3]
		,[2430_LineLevelDenial_4]
		,[2430_LineLevelDenial_5]
		,[2430_LineLevelDenial_6]
		,[2430_LineLevelDenial_7]
		,[2430_LineLevelDenial_8]
		,[2430_LineLevelDenial_9]
		,[2430_LineLevelDenial_10]
		,[2430_CAS01_ClaimAdjustmentGroup_1]
		,[2430_CAS02_ClaimAdjustmentReason_1]
		,[2430_CAS03_ClaimAdjustmentAmount_1]
		,[2430_CAS04_ClaimAdjustmentquantity_1]
		,[2430_CAS05_ClaimAdjustmentReason_1]
		,[2430_CAS06_ClaimAdjustmentAmount_1]
		,[2430_CAS07_ClaimAdjustmentquantity_1]
		,[2430_CAS08_ClaimAdjustmentReason_1]
		,[2430_CAS09_ClaimAdjustmentAmount_1]
		,[2430_CAS10_ClaimAdjustmentquantity_1]
		,[2430_CAS11_ClaimAdjustmentReason_1]
		,[2430_CAS12_ClaimAdjustmentAmount_1]
		,[2430_CAS13_ClaimAdjustmentquantity_1]
		,[2430_CAS14_ClaimAdjustmentReason_1]
		,[2430_CAS15_ClaimAdjustmentAmount_1]
		,[2430_CAS16_ClaimAdjustmentquantity_1]
		,[2430_CAS17_ClaimAdjustmentReason_1]
		,[2430_CAS18_ClaimAdjustmentAmount_1]
		,[2430_CAS19_ClaimAdjustmentquantity_1]
		,[2430_CAS01_ClaimAdjustmentGroup_2]
		,[2430_CAS02_ClaimAdjustmentReason_2]
		,[2430_CAS03_ClaimAdjustmentAmount_2]
		,[2430_CAS04_ClaimAdjustmentquantity_2]
		,[2430_CAS05_ClaimAdjustmentReason_2]
		,[2430_CAS06_ClaimAdjustmentAmount_2]
		,[2430_CAS07_ClaimAdjustmentquantity_2]
		,[2430_CAS08_ClaimAdjustmentReason_2]
		,[2430_CAS09_ClaimAdjustmentAmount_2]
		,[2430_CAS10_ClaimAdjustmentquantity_2]
		,[2430_CAS11_ClaimAdjustmentReason_2]
		,[2430_CAS12_ClaimAdjustmentAmount_2]
		,[2430_CAS13_ClaimAdjustmentquantity_2]
		,[2430_CAS14_ClaimAdjustmentReason_2]
		,[2430_CAS15_ClaimAdjustmentAmount_2]
		,[2430_CAS16_ClaimAdjustmentquantity_2]
		,[2430_CAS17_ClaimAdjustmentReason_2]
		,[2430_CAS18_ClaimAdjustmentAmount_2]
		,[2430_CAS19_ClaimAdjustmentquantity_2]
		,[2430_CAS01_ClaimAdjustmentGroup_3]
		,[2430_CAS02_ClaimAdjustmentReason_3]
		,[2430_CAS03_ClaimAdjustmentAmount_3]
		,[2430_CAS04_ClaimAdjustmentquantity_3]
		,[2430_CAS05_ClaimAdjustmentReason_3]
		,[2430_CAS06_ClaimAdjustmentAmount_3]
		,[2430_CAS07_ClaimAdjustmentquantity_3]
		,[2430_CAS08_ClaimAdjustmentReason_3]
		,[2430_CAS09_ClaimAdjustmentAmount_3]
		,[2430_CAS10_ClaimAdjustmentquantity_3]
		,[2430_CAS11_ClaimAdjustmentReason_3]
		,[2430_CAS12_ClaimAdjustmentAmount_3]
		,[2430_CAS13_ClaimAdjustmentquantity_3]
		,[2430_CAS14_ClaimAdjustmentReason_3]
		,[2430_CAS15_ClaimAdjustmentAmount_3]
		,[2430_CAS16_ClaimAdjustmentquantity_3]
		,[2430_CAS17_ClaimAdjustmentReason_3]
		,[2430_CAS18_ClaimAdjustmentAmount_3]
		,[2430_CAS19_ClaimAdjustmentquantity_3]
		,[2430_CAS01_ClaimAdjustmentGroup_4]
		,[2430_CAS02_ClaimAdjustmentReason_4]
		,[2430_CAS03_ClaimAdjustmentAmount_4]
		,[2430_CAS04_ClaimAdjustmentquantity_4]
		,[2430_CAS05_ClaimAdjustmentReason_4]
		,[2430_CAS06_ClaimAdjustmentAmount_4]
		,[2430_CAS07_ClaimAdjustmentquantity_4]
		,[2430_CAS08_ClaimAdjustmentReason_4]
		,[2430_CAS09_ClaimAdjustmentAmount_4]
		,[2430_CAS10_ClaimAdjustmentquantity_4]
		,[2430_CAS11_ClaimAdjustmentReason_4]
		,[2430_CAS12_ClaimAdjustmentAmount_4]
		,[2430_CAS13_ClaimAdjustmentquantity_4]
		,[2430_CAS14_ClaimAdjustmentReason_4]
		,[2430_CAS15_ClaimAdjustmentAmount_4]
		,[2430_CAS16_ClaimAdjustmentquantity_4]
		,[2430_CAS17_ClaimAdjustmentReason_4]
		,[2430_CAS18_ClaimAdjustmentAmount_4]
		,[2430_CAS19_ClaimAdjustmentquantity_4]
		,[2430_CAS01_ClaimAdjustmentGroup_5]
		,[2430_CAS02_ClaimAdjustmentReason_5]
		,[2430_CAS03_ClaimAdjustmentAmount_5]
		,[2430_CAS04_ClaimAdjustmentquantity_5]
		,[2430_CAS05_ClaimAdjustmentReason_5]
		,[2430_CAS06_ClaimAdjustmentAmount_5]
		,[2430_CAS07_ClaimAdjustmentquantity_5]
		,[2430_CAS08_ClaimAdjustmentReason_5]
		,[2430_CAS09_ClaimAdjustmentAmount_5]
		,[2430_CAS10_ClaimAdjustmentquantity_5]
		,[2430_CAS11_ClaimAdjustmentReason_5]
		,[2430_CAS12_ClaimAdjustmentAmount_5]
		,[2430_CAS13_ClaimAdjustmentquantity_5]
		,[2430_CAS14_ClaimAdjustmentReason_5]
		,[2430_CAS15_ClaimAdjustmentAmount_5]
		,[2430_CAS16_ClaimAdjustmentquantity_5]
		,[2430_CAS17_ClaimAdjustmentReason_5]
		,[2430_CAS18_ClaimAdjustmentAmount_5]
		,[2430_CAS19_ClaimAdjustmentquantity_5]
		,[2430_DTP01_DateTimeQualifier]
		,[2430_DTP02_DateTimeFormat]
		,[2430_DTP03_ServicePaidDate]
		,[2430_AMT01_AmountQualifier]
		,[2430_AMT02_PatientLiabilityAmount]
		,[431_Allowed_Amount]
		,[EOB_CODE]
		,[AccommodationCode]
		,[431_Filler_03]
		,[431_Filler_04]
		,[431_Filler_05]
		,[431_Filler_06]
		,[431_Filler_07]
		,[431_Filler_08]
		,[431_Filler_09]
		,[431_Filler_10]
		,[431_Filler_11]
		,[431_Filler_12]
		,[431_Filler_13]
		,[431_Filler_14]
		,[431_Filler_15]
		,[431_RecipientAidCategory]
	)
	SELECT 
		DISTINCT
		A.CLAIM_ID					--[ClaimID]
		,A.SOURCEDATAKEY			--[SourceDataKey]
		,'' 						--SourceDesc
		,GETDATE()					--[CreateDate]
		,CLAIM_LINE_NO AS ClaimLineNumber --ClaimLineNumber	

		,A.OTH_PAYER1_PRIMEID		-- 2430_SVD01_COBPrimaryPayerID  
		,A.OTH_PAYER1_PAID_AMT		-- 2430_SVD02_COBServicePaidAmount

		,CASE						--431_ClaimLineDisposition
			WHEN 1 = 1 THEN '1'		--Processed as Primary
			WHEN 1 = 1 THEN '2'		--Processed as Secondar
			WHEN 1 = 1 THEN '3'		--Processed as Tertiary
			WHEN 1 = 1 THEN '4'		--Denied
			WHEN 1 = 1 THEN '19'	--Processed as Primary, forwarded to additional Payers
			WHEN 1 = 1 THEN '20'	--Processed as Secondary, forwarded to additional Payers
			WHEN 1 = 1 THEN '21'	--Processed as Tertiary, forwarded to additional Payers
			WHEN 1 = 1 THEN '22'	--Processed as Reversal of Previous Payment
			WHEN 1 = 1 THEN '23'	--Not our claim, forwarded to additional Payers
			WHEN 1 = 1 THEN '25'	--Predetermination Pricing Only - No Payment
		END

		,CASE WHEN PROC_CD = '' THEN '' 
               ELSE SERV_ID_QUAL END SERV_ID_QUAL -- Updated EDS-2188 'HC'	--2430_SVD03_01_ServiceCodeType
		,A.PROC_CD					--2430_SVD03_02_ServiceCode
		,A.PROC_MOD1				--2430_SVD03_03_ServiceModifier1
		,A.PROC_MOD2				--2430_SVD03_04_ServiceModifier2
		,A.PROC_MOD3				--2430_SVD03_05_ServiceModifier3
		,A.PROC_MOD4				--2430_SVD03_06_ServiceModifier4
		,Medicaid.dbo.fn_edi_parse(A.PROC_DESC)				--2430_SVD03_07_ServiceCodeDescription
		,REV_CD1					--2430_SVD04_RevenueCode (Yes on Institutional side and not on INSTessional) 
		,A.OTH_PAYER1_PAID_QTY		--2430_SVD05_Quantity
		,A.OTH_PAYER1_ADJ_BUNDLE	--2430_SVD06_BundledLineNumber
		,''							--2430_LineLevelDenial_1
		,''							--2430_LineLevelDenial_2
		,''							--2430_LineLevelDenial_3
		,''							--2430_LineLevelDenial_4
		,''							--2430_LineLevelDenial_5
		,''							--2430_LineLevelDenial_6
		,''							--2430_LineLevelDenial_7
		,''							--2430_LineLevelDenial_8
		,''							--2430_LineLevelDenial_9
		,''							--2430_LineLevelDenial_10
		,A.CLM_ADJ_GRP111			--2430_CAS01_ClaimAdjustmentGroup_1
		,A.CLM_ADJ_REASON111		--2430_CAS02_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT111			--2430_CAS03_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY111			--2430_CAS04_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_REASON112		--2430_CAS05_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT112			--2430_CAS06_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY112			--2430_CAS07_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_REASON113		--2430_CAS08_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT113			--2430_CAS09_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY113			--2430_CAS10_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_REASON114		--2430_CAS11_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT114			--2430_CAS12_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY114			--2430_CAS13_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_REASON115		--2430_CAS14_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT115			--2430_CAS15_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY115			--2430_CAS16_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_REASON116		--2430_CAS17_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT116			--2430_CAS18_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY116			--2430_CAS19_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_GRP12			--2430_CAS01_ClaimAdjustmentGroup_2
		,A.CLM_ADJ_REASON121		--2430_CAS02_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT121			--2430_CAS03_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY121			--2430_CAS04_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_REASON122		--2430_CAS05_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT122			--2430_CAS06_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY122			--2430_CAS07_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_REASON123		--2430_CAS08_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT123			--2430_CAS09_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY123			--2430_CAS10_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_REASON124		--2430_CAS11_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT124			--2430_CAS12_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY124			--2430_CAS13_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_REASON125		--2430_CAS14_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT125			--2430_CAS15_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY125			--2430_CAS16_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_REASON126		--2430_CAS17_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT126			--2430_CAS18_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY126			--2430_CAS19_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_GRP13			--2430_CAS01_ClaimAdjustmentGroup_3
		,A.CLM_ADJ_REASON131		--2430_CAS02_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT131			--2430_CAS03_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY131			--2430_CAS04_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_REASON132		--2430_CAS05_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT132			--2430_CAS06_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY132			--2430_CAS07_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_REASON133		--2430_CAS08_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT133			--2430_CAS09_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY133			--2430_CAS10_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_REASON134		--2430_CAS11_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT134			--2430_CAS12_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY134			--2430_CAS13_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_REASON135		--2430_CAS14_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT135			--2430_CAS15_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY135			--2430_CAS16_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_REASON136		--2430_CAS17_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT136			--2430_CAS18_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY136			--2430_CAS19_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_GRP14			--2430_CAS01_ClaimAdjustmentGroup_4
		,A.CLM_ADJ_REASON141		--2430_CAS02_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT141			--2430_CAS03_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY141			--2430_CAS04_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_REASON142		--2430_CAS05_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT142			--2430_CAS06_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY142			--2430_CAS07_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_REASON143		--2430_CAS08_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT143			--2430_CAS09_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY143			--2430_CAS10_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_REASON144		--2430_CAS11_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT144			--2430_CAS12_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY144			--2430_CAS13_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_REASON145		--2430_CAS14_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT145			--2430_CAS15_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY145			--2430_CAS16_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_REASON146		--2430_CAS17_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT146			--2430_CAS18_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY146			--2430_CAS19_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_GRP15			--2430_CAS01_ClaimAdjustmentGroup_5
		,A.CLM_ADJ_REASON151		--2430_CAS02_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT151			--2430_CAS03_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY151			--2430_CAS04_ClaimAdjustmentquantity_5
		,A.CLM_ADJ_REASON152		--2430_CAS05_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT152			--2430_CAS06_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY152			--2430_CAS07_ClaimAdjustmentquantity_5
		,A.CLM_ADJ_REASON153		--2430_CAS08_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT153			--2430_CAS09_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY153			--2430_CAS10_ClaimAdjustmentquantity_5
		,A.CLM_ADJ_REASON154		--2430_CAS11_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT154			--2430_CAS12_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY154			--2430_CAS13_ClaimAdjustmentquantity_5
		,A.CLM_ADJ_REASON155		--2430_CAS14_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT155			--2430_CAS15_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY155			--2430_CAS16_ClaimAdjustmentquantity_5
		,A.CLM_ADJ_REASON156		--2430_CAS17_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT156			--2430_CAS18_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY156			--2430_CAS19_ClaimAdjustmentquantity_5
		,''						--2430_DTP01_DateTimeQualifier
		,''						--2430_DTP02_DateTimeFormat
		,A.OTH_PAYER1_ADJ_DT						--2430_DTP03_ServicePaidDate  ONLY FOR INSTESSIONAL CLAIMS - Removed paid date mapping
		,''						--2430_AMT01_AmountQualifier
		,B.PATIENT_EST_AMT_DUE		--2430_AMT02_PatientLiabilityAmount  ONLY FOR INSTESSIONAL CLAIMS
		,'' 						--431_Allowed_Amount
		,''							--EOB_CODE
		,''							--AccommodationCode
		,''							--431_Filler_03
		,''							--431_Filler_04
		,''							--431_Filler_05
		,''							--431_Filler_06
		,''							--431_Filler_07
		,''							--431_Filler_08
		,''							--431_Filler_09
		,''							--431_Filler_10
		,''							--431_Filler_11
		,''							--431_Filler_12
		,''							--431_Filler_13
		,''							--431_Filler_14
		,''							--431_Filler_15
		,''							--431_RecipientAidCategory
	FROM MEDICAID.DBO.OUTB_INST_DETAIL A
	JOIN MEDICAID.DBO.OUTB_INST_HEADER B
		ON B.SOURCEDATAKEY = A.SOURCEDATAKEY
		AND B.CLAIM_ID = A.CLAIM_ID


/*---------------------------------------------------------------------*/
/* UPDATE SYSLOG                                                       */
/*---------------------------------------------------------------------*/

SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM MEDICAID.dbo.OUTB_INST_HEADER)
									
				BEGIN TRANSACTION
						UPDATE  MEDICAID.dbo.EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_MEDICAID_INST_CSV_40I_431I_Detail'
										and END_DT is null
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT

