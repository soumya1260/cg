﻿create  PROCEDURE [dbo].[Medicaid_Recon_837I_Load]
--(
 @FILENAME CHAR(256) = 'test.txt'
--,@elesep char(1) = '*'
--,@segsep char(1) = '~')--
AS
/***************************************************************************************************
** CREATE DATE: 05/2024
**
** AUTHOR: Henry faust
**
** DESCRIPTION: 
**              
**              
**               
**
**
**/


  
declare @hlloop int = 0
declare @lxloop int = 0
declare @hlflag varchar(5) = 'no';
declare @lxflag  varchar(5)= 'no';
declare @cascount int = 0;

DECLARE @CursorTestID INT = 1;
DECLARE @RunningTotal BIGINT = 0;
DECLARE @RowCnt BIGINT = 0;
declare @Seg varchar(1000);
--declare @datetoday  datetime = GETDATE()
declare @isa13 varchar(20) = '',
        @refD9 varchar(10) = '',
        @ref9A varchar(10) = '',
        @prv01 varchar(10) = '',
        @nm1MI09 varchar(10) = '',
        @ref01 varchar(10) = '',
        @dtp01 varchar(10) = '',
        @cn101 varchar(10) = '',
        @hi01 varchar(10) = '',
        @amt01 varchar(10) = '',
        @sbr01 varchar(10) = '',
		@cas02 varchar(10),
		@hl01 varchar(10) = null,
		@lx01 varchar(10) = null,
		@hl03 varchar(10),
		@enum int,
		@ele varchar(100),
		@subenum int,
--		@subenum int,
		@subele varchar(100),
@elesep char(1) = '*',
@subelesep char(1) = ':',
@segsep char(1) = '~',

		@x int, @y int , @z int,
		@subx int, @suby int , @subz int,
		@part1 varchar(20) = '',
		@part2 varchar(20) ='',
		@clm01 varchar(20) =  '',		
--		@FILENAME CHAR(256) = 'test.txt',
--       Header Variables ---------------------------------
		@IsaSenderID	varchar(20),
		@IsaReceiverId	varchar(20),
		@IsaControlId	varchar(20),
		@GsSenderId	varchar(20),
		@GsReceiverId	varchar(20),
		@GSControlId	varchar(20),
		@STControlId	varchar(20),
		@SEControlNum	varchar(20),
		@GEControlNum	varchar(20),
		@IEAControlNum	varchar(20),
		@TradingPartnerID	varchar(60),
		@TransTypeCode	varchar(10),
		@BatchID	varchar(10),
        @nm101 varchar(10),
		@TPName	varchar(60),
		@TPEINId	varchar(80),
		@MedicaidName	varchar(60),
		@MedicaidNumber	varchar(80),
		@TaxonomyCode	varchar(10),
		@BillingProvName	varchar(60),
		@BillingProvNPI	varchar(80),
		@BillingProvAddress	varchar(60),
		@BillingProvCity	varchar(60),
		@BillingProvState	varchar(60),
		@BillingProvZip	varchar(9),
		@BillingProvEIN	varchar(20),
		@MemberLastName	varchar(60),
		@MemberFirstName	varchar(60),
		@MemberMedicaidID	varchar(80),
		@PrimaryPayerName	varchar(60),
		@PrimaryPayerID	varchar(60),
		@SeconaryPayerName	varchar(60),
		@SecondaryPayerID	varchar(60),
		@ClaimId	varchar(20),
		@ClaimAmt	varchar(10),
		@FacilityType	varchar(10),
		@ClaimFrequencyType	varchar(20),
		@StatementDate	varchar(20),
		@StatementDateQual	varchar(20),
		@StatementDateBegin	varchar(20),
		@StatementDateEnd	varchar(20),
		@ContractAmt	varchar(10),
		@MediPassRefNum9A	varchar(20),
		@OriginalRefNumD9	varchar(20),
		@RefClaimNum	varchar(20),
		@MCOReceiptDate	varchar(8),
		@PrimaryDiagCode	varchar(10),
		@ReasonForVisit	varchar(10),
		@AttendingProvTaxonomyCode	varchar(20),
		@PayerAmtPaid	varchar(10),
		@AttProviderFirstName	varchar(60),
		@AttProviderLastName	varchar(60),
		@AttProcviderCode	varchar(60),
        @ProviderCode  varchar(20),
        @ClaimPaidDateCode	varchar(10),
		@ClaimPaidDate 	varchar(8),
		@ServiceLineRevenueCode	varchar(10),
		@PayerPrimaryID	varchar(10),
		@PaymentSystem	varchar(20),
		@DaysInHospital	varchar(10),
		@DateOfService	varchar(10),
		@ProviderControlNumber	varchar(20),
		@svdcode	varchar(10),
		@ServiceLinePaidAmount	varchar(20),  
		@ServiceLineChrgAmount	varchar(20),
		@ProcCodeQual  varchar(10),
		@ProcDesc  varchar(30),
		@svdhcdode	varchar(10),
        @ProcCodeMod1 varchar(10),
        @ProcCodeMod2 varchar(10),
        @ProcCodeMod3 varchar(80),
        @ProcCode1 varchar(10),
        @ProcCode2 varchar(10),
        @ProcCode3 varchar(10),
@SrvProcCode  varchar(10),
@SrvPRODQual varchar(10),
@SrvProdID  varchar(10),
@ProdMod1  varchar(10),
@ProdMod2  varchar(10),
@ProdMod3  varchar(10),
@ProdMod4 varchar(10),
@SrvDescription varchar(80),
        @svd04	varchar(10),
		@svd05	varchar(10),
	@SV2_01	varchar(10),
    @SV2_02_01 varchar(10),
    @SV2_02_02 varchar(10),
    @SV2_02_03 varchar(80),
    @SV2_02_04 varchar(10),
    @SV2_02_05 varchar(10),
    @SV2_02_06 varchar(10),
    @SV2_02_07 varchar(80),
        @SrvLineRevCode varchar(10),
        @PaidServQty varchar(10),
		@cas01	varchar(10),
		@MedicareDeductible	varchar(10),
		@MedicareCoinsurance	varchar(10),
		@MedicareBloodDeductible	varchar(10),
		@MCODeniedLineAmt	varchar(10),
		@ClmAdjGroupCode1	varchar(5),
		@ClmAdjReasonCode1	varchar(5),
		@ClmAdjAmount1	varchar(20),
		@ClmAdjGroupCode2	varchar(5),
		@ClmAdjReasonCode2	varchar(5),
		@ClmAdjAmount2	varchar(20),
		@ClmAdjGroupCode3	varchar(5),
		@ClmAdjReasonCode3	varchar(5),
		@ClmAdjAmount3	varchar(20),
		@ClmAdjGroupCode4	varchar(5),
		@ClmAdjReasonCode4	varchar(5),
		@ClmAdjAmount4	varchar(20),
		@ClmAdjGroupCode5	varchar(5),
		@ClmAdjReasonCode5	varchar(5),
		@ClmAdjAmount5	varchar(20),
		@ClmAdjGroupCode6	varchar(5),
		@ClmAdjReasonCode6	varchar(5),
		@ClmAdjAmount6	varchar(20),
	@DateofServiceQual	varchar(20),
	@DateofServiceBegin	varchar(20),
	@DateofServiceEnd	varchar(20),
	@PaidDateQual	varchar(20),
	@PaidDateBegin	varchar(20),
	@PaidDateEnd	varchar(20),
	@BatchNum	varchar(20),
	--@StatementDateQual	varchar(20),
	--@StatementDateBegin	varchar(20),
	--@StatementDateEnd	varchar(20),
		@LoadDate datetime = GETDATE()

--,@elesep char(1) = '*'
--,@segsep char(1) = '~')
--declare @FILENAME CHAR(256) = 'test.txt'

-- get a count of total rows to process 
--select @RowCnt = COUNT(0) FROM staging.Raw837Segments;
-- set @Seg = (select left(segment,10) from staging.RawSegments where segnum = 1)
 ----------------------------SProcs-------------------------------------------------------------------------------
 
 ----------------------------end SOrocs-------------------------------------------------------------------------------
DECLARE cur CURSOR FAST_FORWARD READ_ONLY LOCAL FOR
	SELECT segnum,segment
	FROM staging.Raw837ISegments

OPEN cur

FETCH NEXT FROM cur INTO @CursorTestID,@Seg

WHILE @@FETCH_STATUS = 0 BEGIN

if @RowCnt <> 0 
 
 set @seg = ltrim(@seg)


set @RowCnt = @RowCnt +1

--select 	 @CursorTestID as cur,@Seg
----------------------------------------------------------------------------------
----------------------------------------------------------------------------------
   if left(@Seg,4) = 'ISA*'
	   begin
--select 'isa*'
		set @IsaControlId = substring(@Seg, 91,9)
		set @IsaSenderID = substring(@Seg, 36,15)
		set @IsaReceiverId = substring(@Seg, 55,15)
		--select @isa13 
		--select @isa13 
		if @IsaReceiverId = '77027'  set @TradingPartnerID = 'STATE OF FLORIDA MEDICAID' 
		if @IsaReceiverId = '626001445TC' set @TradingPartnerID = 'TENNCARE' 
		if @IsaReceiverId = 'OLTL'  set @TradingPartnerID = 'STATE OF PENNSYLVANIA MEDICAID' 
--select  @IsaSenderID, @IsaReceiverId, @IsaControlId 
	   end
-----------------------------------------------------------------------------------------
--select substring(@Seg,1,3) as trim3
--select @Seg as seg2
  if left(@Seg,3) = 'GS*'  or substring(@Seg,2,3) = 'GS*'
--  if left(@Seg,3) = 'GS*'
	   begin
--select 'gs*'
		set @GSControlId = substring(@Seg, 91,9)
		set @GsSenderId = substring(@Seg, 36,15)
		set @GsReceiverId = substring(@Seg, 55,15)
		--select @isa13 
	  set @x = 0
	  set @y = 0

	   begin  --GS segment
	   set @enum = 0
	   set @Seg = @Seg + @elesep
	    while @enum < 7
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = substring(@Seg,@x+1, @y-@x-1)
  		          if @enum = 1 set @GsSenderId  = @ele;
  		          if @enum = 2 set  @GsReceiverId  = @ele;
  		          if @enum = 5 set @GSControlId  = @ele;
		          --if @enum = 11 set @HICN = @ele;
		          --if @enum = 19 set @PlanClmNum = @ele;

--select @enum,@x, @y, @ele
--select 'gs' , @enum, @ele
				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end
		--select @isa13 
	   end
---------------------------------ST--------------------------------------------------------

   if left(@Seg,3) =  'ST*' or substring(@Seg,2,3) = 'ST*'

	   begin
--select 'st*'			set @part1 = ''; set @part2 = ''; 
--	   end
--	   begin  --SRsegment
	   set @enum = 0
	   set @Seg = @Seg --+ @elesep + @elesep + @elesep
	    while @enum < 3
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
--				 set @ele = replace(@Seg,'~','')
  		          if @enum = 2 set @STControlId  = @ele;

--select 'STw' , @Seg, @enum,@x as x , @y as y , @ele as ele
--select left(@seg,20), @stcontrolid as STcontrol ,@enum as enum, @ele as eie, @ClaimId as clm, substring(@Seg,@x+1, @y-@x-1)
				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
--select 'ST' , @Seg, @enum
          -- set @hlloop =0 ; set @hlloop = Null; set @hl03 = '' -- reset for next set of claims
		  end --if ST
		--select @isa13 
---------------------------end ST---------------------------------------------------------------------
-----------------------------Begin BHT-------------------------------------------------------------------------

   if left(@Seg,4) = 'BHT*'  or substring(@Seg,2,4) = 'BHT*'

	   begin
--select 'bht*'		   

	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 3
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = substring(@Seg,@x+1, @y-@x-1)
  		          if @enum = 0 set @TransTypeCode  = @ele;
  		          if @enum = 0 set @BatchID  = @ele;

--select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele
				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END BHT-------------------------------------------------------------------------
-----------------------------Begin SBR-------------------------------------------------------------------------

   if left(@Seg,4) = 'SBR*' or substring(@Seg,2,4) = 'SBR*'

	   begin
--select 'sbr****************************************************************************************'			   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 3
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = substring(@Seg,@x+1, @y-@x-1)
  		          if @enum = 0 set @sbr01  = @ele;

--select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele
				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END SBR-------------------------------------------------------------------------
-----------------------------Begin NM1------------------------------------------------------------------------
   if left(@Seg,4) = 'NM1*' or substring(@Seg,2,4) = 'NM1*'

	   begin
--select 'nm1*'			   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 9
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0 set @nm101  = @ele;
				 if @enum = 2  and	 @nm101 = '41' set @TPName = @ele
				 if @enum = 8  and	 @nm101 = '41' set @TPEINId = @ele
				 if @enum = 2  and	 @nm101 = '40' set @MedicaidName = @ele
				 if @enum = 8  and	 @nm101 = '40' set @MedicaidNumber = @ele
				 if @enum = 2  and	 @nm101 = '85' set @BillingProvName = @ele
				 if @enum = 8  and	 @nm101 = '85' set @BillingProvNPI  = @ele
				 if @enum = 2  and	 @nm101 = 'IL' set @MemberLastName = @ele
				 if @enum = 3  and	 @nm101 = 'IL' set @MemberFirstName  = @ele
				 if @enum = 8  and	 @nm101 = 'IL' set @MemberMedicaidID  = @ele
				 if @enum = 2  and	 @nm101 = 'PR' and @sbr01 = 'P' set @PrimaryPayerName = @ele
				 if @enum = 8  and	 @nm101 = 'PR' and @sbr01 = 'P' set @PrimaryPayerID  = @ele
				 if @enum = 2  and	 @nm101 = 'PR' and @sbr01 = 'S' set @SeconaryPayerName = @ele
				 if @enum = 8  and	 @nm101 = 'PR' and @sbr01 = 'S' set @SecondaryPayerID  = @ele
				 if @enum = 2  and	 @nm101 = '71'  set @AttProviderFirstName = @ele
				 if @enum = 3  and	 @nm101 = '71'  set @AttProviderLastName  = @ele
				 if @enum = 8  and	 @nm101 = '71'  set @AttProcviderCode  = @ele

----select @enum,@x, @y, @ele
--select left(@seg,20) as seg, @enum, @ele, @nm101 as nm101,@sbr01 as sbr01, @PrimaryPayerID as priId , @PrimaryPayerName as pripay 

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END NM1-------------------------------------------------------------------------
-----------------------------Begin N3------------------------------------------------------------------------
   if left(@Seg,3) = 'N3*' or substring(@Seg,2,3) = 'N3*'

	   begin
		   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 1
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0  and  @nm101 = '85' set @BillingProvAddress  = @ele;
---select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END N3-------------------------------------------------------------------------
-----------------------------Begin N4------------------------------------------------------------------------
   if left(@Seg,3) = 'N4*'  or substring(@Seg,2,3) = 'N4*'

	   begin
		   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 3
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0  and  @nm101 = '85' set @BillingProvCity = @ele;
				 if @enum = 1  and  @nm101 = '85' set @BillingProvState = @ele;
				 if @enum = 2  and  @nm101 = '85' set @BillingProvZip = @ele;
---select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END N4-------------------------------------------------------------------------
 -----------------------------Begin HL------------------------------------------------------------------------
   if left(@Seg,3) = 'HL*' or substring(@Seg,2,3) = 'HL*'

	   begin
--------------------------------------------------------------------------------------------------------------------------------------------------
---       if @lxloop >0 and @lxloop is not Null
		-- begin --insert the last LX loop
--select 'Insert Detail  yes 22' , @hlflag as hlflag , @hl03 as  hl03

		if @hlflag = 'yes' and @hl03 = '22'
		   begin
--select 'Insert Detail HL **************'
				insert into Medicaid.staging.Medicaid_Recon_837I_Detail
					(    IsaSenderID , IsaControlId 
						-- , DateOfService  
					   --, ServiceLineRevenueCode
					   ,PayerPrimaryID
					   , DaysInHospital  
					  , ProviderControlNumber  ,  ServiceLinePaidAmount  --,  DaysInHospital  
					   --, ProcCodeQual  , ProcrCode  , PaidServQty  
					   --, ProcCodeMod1  , ProcCodeMod2  , ProcCodeMod3    
					   --, MedicareDeductible  , MedicareCoinsurance  , MedicareBloodDeductible  ,  MCODeniedLineAmt  
					   --, SEControlNum  , GEControlNum , IEAControlNum  
					   , LineItemNumber
					   , ClaimId
					   ,LoadDate
				     ,ClmAdjGroupCode1, ClmAdjReasonCode1, ClmAdjAmount1, ClmAdjGroupCode2, ClmAdjReasonCode2, ClmAdjAmount2
                     ,ClmAdjGroupCode3, ClmAdjReasonCode3, ClmAdjAmount3, ClmAdjGroupCode4, ClmAdjReasonCode4, ClmAdjAmount4
                     ,ClmAdjGroupCode5, ClmAdjReasonCode5, ClmAdjAmount5, ClmAdjGroupCode6, ClmAdjReasonCode6, ClmAdjAmount6
					   --,svdcode
					   ,TradingPartnerID
					   ,DateofServiceQual,DateofServiceBegin,DateofServiceEnd,PaidDateQual,PaidDateBegin ,PaidDateEnd
					--   ,ProcCode1  , ProcCode2  , ProcCode3 
					--,SrvProcCode
					,SrvPRODQual ,ProdMod1  ,ProdMod2  ,ProdMod3  ,ProdMod4  ,SrvDescription , SrvProdID
					--, PaidServQty 
					,ServiceLineChrgAmount
					,SrvLineRevCode
				   )
				  select   @IsaSenderID , @IsaControlId 
						 --, @DateOfService as DtOfSrv
					   --, @ServiceLineRevenueCode as SerLnRevCode
					   ,@PayerPrimaryID
					   , @DaysInHospital as DaysInHos
					   , @ProviderControlNumber as PrvrCtlNum,  @ServiceLinePaidAmount as Svdamt--,  @DaysInHospital as DysInHosp
					   --, @ProcCodeQual as ProdCodeQual , @ProviderCode as ProcCode, @PaidServQty as PdSrvQty
					   --, @ProcCodeMod1 as PCM1, @ProcCodeMod2 as PCM2, @ProcCodeMod3 as PCM3   
					   --, @MedicareDeductible as MedDeduct, @MedicareCoinsurance as MedCoIns, @MedicareBloodDeductible as MediBlood,  @MCODeniedLineAmt as MCODenied
					   --, @SEControlNum as sectlnum, @GEControlNum as GECtl, @IEAControlNum as IEACtlNum
					   , @lx01 as linenum
					   , @ClaimId as Clmid
					   , @LoadDate
					   , @ClmAdjGroupCode1 ,@ClmAdjReasonCode1 ,@ClmAdjAmount1 ,@ClmAdjGroupCode2 ,@ClmAdjReasonCode2 ,@ClmAdjAmount2 
					   , @ClmAdjGroupCode3 ,@ClmAdjReasonCode3 ,@ClmAdjAmount3 ,@ClmAdjGroupCode4 ,@ClmAdjReasonCode4 ,@ClmAdjAmount4 
					   , @ClmAdjGroupCode5 ,@ClmAdjReasonCode5 ,@ClmAdjAmount5 ,@ClmAdjGroupCode6 ,@ClmAdjReasonCode6 ,@ClmAdjAmount6 
					  -- ,@svdcode
					  , @TradingPartnerID
					  ,@DateofServiceQual,@DateofServiceBegin,@DateofServiceEnd,@PaidDateQual,@PaidDateBegin,@PaidDateEnd
					--  ,@ProcCode1  , @ProcCode2  , @ProcCode3 
						--,@SrvProcCode
						,@SrvPRODQual ,@ProdMod1  ,@ProdMod2  ,@ProdMod3  ,@ProdMod4  ,@SrvDescription , @SrvProdID
						--, @PaidServQty 
						,@ServiceLineChrgAmount
                       ,@SrvLineRevCode
						
---------- clear codes
				   set @ClmAdjGroupCode1 = NULL ;set @ClmAdjReasonCode1 = NULL ;set @ClmAdjAmount1 = NULL ;set @ClmAdjGroupCode2 = NULL ;set @ClmAdjReasonCode2 = NULL ;set @ClmAdjAmount2 = NULL ;
                   set @ClmAdjGroupCode3 = NULL ;set @ClmAdjReasonCode3 = NULL ;set @ClmAdjAmount3 = NULL ;set @ClmAdjGroupCode4 = NULL ;set @ClmAdjReasonCode4 = NULL ;set @ClmAdjAmount4 = NULL ;
                   set @ClmAdjGroupCode5  = NULL;set @ClmAdjReasonCode5 = NULL ;set @ClmAdjAmount5 = NULL ;set @ClmAdjGroupCode6 = NULL ;set @ClmAdjReasonCode6 = NULL ;set @ClmAdjAmount6 = NULL ;
				   		  set @SrvProcCode = NULL; set @SrvPRODQual = NULL; set @SrvProdID = NULL;
		  set @ProdMod1 = NULL; set @ProdMod2 = NULL; set @ProdMod3 = NULL; set @ProdMod4 = NULL; 
		  set @SrvDescription = NULL; set @SrvLineRevCode = Null ;-- set @ServiceLineChrgAmount = Null;
--select 'after detail line written A HL',@ClaimId as clmidf ,@ServiceLineChrgAmount

--select 'HL insert detail ',@STControlId, @lx01 as lx01,@hlloop as hlloop,@lxloop as lxloop, @ClaimId as clmid,@hlflag as hlflag, @hl03
               end-- hlflage = 20 and hl03 = 20 

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 3
		    begin 
				-- set @hlloop = null;
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 02   set @hl03 = @ele;
				 if @enum = 01   set @hl01 = @ele;

---select @enum,@x, @y, @ele
--select 'HL' ,left(@seg,20), @lxflag as lxflag   --@enum, @ele, @hlloop,@hl03

				 set @enum = @enum +1
				 set @x = @y
---------------Clean out variables if HL loop is 20 Startof Clm

---------------END Clean out variables if HL loop is 20 Startof Clm

			end --loop through elements
--       if @hlloop >0 and @hlloop is not Null and @hl03 = '22'
       if  @hl03 = '22'
		 --begin --insert the last LX loop
		   begin



--------------------Clear out variables for next run

				   --set @TaxonomyCode = NULL; set @BillingProvEIN = NULL  ; set @MediPassRefNum = NULL ; 
				   set  @OriginalRefNumD9 = NULL ; 
				   set @ClaimAmt = NULL ; set @FacilityType  = NULL; set @ClaimFrequencyType  = NULL  ;
				   set @StatementDate = NULL; set  @ContractAmt = NULL ;set @MCOReceiptDate = NULL; set  @PrimaryDiagCode = NULL; set @ReasonForVisit = NULL ;
				   set @AttendingProvTaxonomyCode  = NULL; set  @PayerAmtPaid  = NULL  ;set @RefClaimNum  = NULL ;
				   --set @ClaimPaidDateCode = NULL ; set  @ClaimPaidDate = NULL ; 
				   set @AttProviderFirstName = NULL; set @AttProviderLastName = NULL; set @AttProcviderCode = NULL;
				   
				   set @ClmAdjGroupCode1 = NULL ;set @ClmAdjReasonCode1 = NULL ;set @ClmAdjAmount1 = NULL ;set @ClmAdjGroupCode2 = NULL ;set @ClmAdjReasonCode2 = NULL ;set @ClmAdjAmount2 = NULL ;
                   set @ClmAdjGroupCode3 = NULL ;set @ClmAdjReasonCode3 = NULL ;set @ClmAdjAmount3 = NULL ;set @ClmAdjGroupCode4 = NULL ;set @ClmAdjReasonCode4 = NULL ;set @ClmAdjAmount4 = NULL ;
                   set @ClmAdjGroupCode5  = NULL;set @ClmAdjReasonCode5 = NULL ;set @ClmAdjAmount5 = NULL ;set @ClmAdjGroupCode6 = NULL ;set @ClmAdjReasonCode6 = NULL ;set @ClmAdjAmount6 = NULL ;
-------------------end clear out variables-------------------------------------------------------------------------------------------
           end --if hlloop		   
--  --          set @hlloop = @hlloop + 1
			if @hl03 = '22' set @hlloop = @hlloop + 1
		--select 'hlloop + 1',@hlloop as hlloop, @ClaimId,@lx01
--select 'HL  detail ', @lx01 as lx01,@hlloop as hlloop,@lxloop as lxloop, @ClaimId as clmid,@hlflag as hlflag, @hl03
           if @hl03 = '22' begin set @hlflag = 'yes'; set @lxflag = 'NO'; end
--select 'HL' ,left(@seg,20), @lxflag as lxflag   --@enum, @ele, @hlloop,@hl03
		  end --if HL
		--select @isa13 
		
----------------------------END HL-------------------------------------------------------------------------
 -----------------------------Begin PRV------------------------------------------------------------------------
  if left(@Seg,4) = 'PRV*' or substring(@Seg,2,4) = 'PRV*'

	   begin
		   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 3
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0   set @prv01 = @ele;
				 if @enum = 2 and @prv01 = 'BI'  set @TaxonomyCode = @ele;
				 if @enum = 2 and @prv01 = 'AT'  set @AttendingProvTaxonomyCode = @ele;

---select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele,@TaxonomyCode,@prv01

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if prv
		--select @isa13 
-----------------------------END PRV-------------------------------------------------------------------------
-----------------------------Begin REF------------------------------------------------------------------------
  if left(@Seg,4) = 'REF*' or substring(@Seg,2,4) = 'REF*'

	   begin
		   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 2
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0   set @ref01 = @ele;
				 if @enum = 1   and @ref01 = 'EI' set @BillingProvEIN = @ele;
				 if @enum = 1   and @ref01 = '9A' set @MediPassRefNum9A =  @ele;
				 if @enum = 1   and @ref01 = 'D9' set @OriginalRefNumD9 =  @ele;;
				 if @enum = 1   and @ref01 = '6R' set @ProviderControlNumber = @ele;
				 if @enum = 1   and @ref01 = 'F8' set @ProviderControlNumber = @ele;
 				 if @enum = 1   and @ref01 = 'D9' set @RefClaimNum = @ele;


---select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele, @MediPassRefNum as MPRN --, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END REF-------------------------------------------------------------------------
-----------------------------Begin CLM------------------------------------------------------------------------
  if left(@Seg,4) = 'CLM*'  or substring(@Seg,2,4) = 'CLM*'

	   begin
		   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 5
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0  set @ClaimId = @ele;
				 if @enum = 1  set @ClaimAmt = @ele;
				 if @enum = 4  begin
								   set @FacilityType = substring(@ele,1,2)
								   set @ClaimFrequencyType = SUBSTRING(@ele,6,1)
				               end 
							  

if @enum = 0 select 'CLM' ,@enum, @ele as ele, @claimid
--select left(@seg,20), @enum, @ele

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END CLM-------------------------------------------------------------------------
-----------------------------Begin DTP------------------------------------------------------------------------
  if left(@Seg,4) = 'DTP*' or substring(@Seg,2,4) = 'DTP*'

	   begin
		   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 3
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0   set @dtp01 = @ele;
--				 if @enum = 2   and @dtp01 = '434' set @StatementDate = @ele;
				 if @enum = 2   and @dtp01 = '472' set @DateOfService = @ele;
				 if @enum = 2   and @dtp01 = '573' set @ClaimPaidDateCode = '573';
				 if @enum = 2   and @dtp01 = '573' set @ClaimPaidDate = @ele; 
--				 if @enum = 2   and @dtp01 = '573' set @PaidDateQual = @ele; 
--				 if @enum = 2   and @dtp01 = '573' set @PaidDateBegin = @ele; 
--				 if @enum = 2   and @dtp01 = '573' set @PaidDateEnd = @ele; 
--select 'X',left(@seg,20) , @enum, @ele, @dtp01, len(@dtp01), @PaidDateQual as PDq, @PaidDateBegin as pdb,@PaidDateEnd as pde
				 if @enum = 2   and @dtp01 = '434' 
				     begin
					   set @StatementDateQual = @dtp01
					   set @StatementDateBegin = SUBSTRING(@ele,1,8)
					   set @StatementDateEnd = SUBSTRING(@ele,10,8)
                     end --pp434
				 if @enum = 2   and @dtp01 = '573' 
				     begin
					   set @PaidDateQual = '573' --@dtp01
					   set @PaidDateBegin = @ele
					   set @PaidDateEnd = @ele
---elect left(@seg,20) ,@PaidDateQual as pdSQ, @PaidDateBegin as pdB, @PaidDateEnd as pdE --, @nm101 as nm1
				     end    --573
				 if @enum = 2   and @dtp01 = '472' 
				     begin
					   set @DateofServiceQual = @dtp01
					   set @DateofServiceBegin = @ele
					   set @DateofServiceEnd = @ele
--select left(@seg,20) ,@DateofServiceQual as DOSQ, @DateofServiceBegin as DOSB, @DateofServiceEnd as DOSE --, @nm101 as nm1
				     end --472
				     --end
				-- set @StatementDate = @ele;

---select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele ,@DateofServiceQual, @DateofServiceBegin, @DateofServiceEnd --, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END DTP-------------------------------------------------------------------------
-----------------------------Begin CN1------------------------------------------------------------------------
  if left(@Seg,4) = 'CN1*' or substring(@Seg,2,4) = 'CN1*'

	   begin
		   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 2
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0   set @cn101 = @ele;
				 if @enum = 1   and @cn101 = '09' set @ContractAmt = @ele;

--select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele--, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END CN1-------------------------------------------------------------------------
-----------------------------Begin K3------------------------------------------------------------------------
  if left(@Seg,3) = 'K3*' or substring(@Seg,2,3) = 'K3*'

	   begin
		   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 1
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0   set @MCOReceiptDate = @ele;

---select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele--, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END K3-------------------------------------------------------------------------
-----------------------------Begin HI------------------------------------------------------------------------
  if left(@Seg,3) = 'HI*' or substring(@Seg,2,3) = 'HI*'

	   begin
		   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep+ @elesep
	    while @enum < 2
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0   set @hi01 = @ele;
				 if @enum = 0   and substring(@ele,1,3) = 'ABK' begin set @hi01 = @ele set @PrimaryDiagCode = replace(substring(@ele,5,10),':','')  end;
				 if @enum = 1   and substring( @hi01,1,3) = 'APR' begin  set @ReasonForVisit = substring(@ele,5,5)  end;
--				 if @enum = 0   and substring(@ele,1,3) = 'ABF' begin set @hi01 = @ele set @PrimaryDiagCode = substring(@ele,5,4)  end;
--				 if @enum = 0   set @hi01 = @ele;

--select @enum, @ele
--select @Seg
--select left(@seg,20), @enum, @ele ,replace(substring(@ele,5,4),':','') --substring(@ele,1,3) ,substring(@ele,5,4),substring(@ele,5,5)--, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END HI-------------------------------------------------------------------------
-----------------------------Begin AMT------------------------------------------------------------------------
  if left(@Seg,4) = 'AMT*' or substring(@Seg,2,4) = 'AMT*'

	   begin
		   
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 2
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0   set @amt01 = @ele;
				 if @enum = 1   and @amt01 = 'D' set @PayerAmtPaid	= @ele;

-----select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele--, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END AMT-------------------------------------------------------------------------
--===========================================Detail Level ======================================================================
-----------------------------Begin LX------------------------------------------------------------------------
   if left(@Seg,3) = 'LX*' or substring(@Seg,2,3) = 'LX*'

	   begin
--select @seg as seg,'yes >0 ' ,  @lxflag as lxflag, @lxloop as lxloop

   if @lxloop >0 and @lxloop is not Null and @lxflag = 'yes'
		-- begin --insert the last LX loop
		   begin
--select 'Insert Detail LX **************'
		       insert into medicaid.staging.Medicaid_Recon_837I_Detail
					(    IsaSenderID , IsaControlId 
						-- , DateOfService  
					   --, ServiceLineRevenueCode  
					   ,PayerPrimaryID
					   , DaysInHospital  
					  , ProviderControlNumber  ,  ServiceLinePaidAmount  --,  DaysInHospital  
					   --, ProcCodeQual  , ProcrCode  , PaidServQty  
					   --, ProcCodeMod1  , ProcCodeMod2  , ProcCodeMod3    
					  -- , MedicareDeductible  , MedicareCoinsurance  , MedicareBloodDeductible  ,  MCODeniedLineAmt  
					   --, SEControlNum  , GEControlNum , IEAControlNum  
					   , LineItemNumber
					   , ClaimId
					   ,LoadDate
					  -- ,svdcode
					   ,ClmAdjGroupCode1, ClmAdjReasonCode1, ClmAdjAmount1, ClmAdjGroupCode2, ClmAdjReasonCode2, ClmAdjAmount2
					   ,ClmAdjGroupCode3, ClmAdjReasonCode3, ClmAdjAmount3, ClmAdjGroupCode4, ClmAdjReasonCode4, ClmAdjAmount4
					   ,ClmAdjGroupCode5, ClmAdjReasonCode5, ClmAdjAmount5, ClmAdjGroupCode6, ClmAdjReasonCode6, ClmAdjAmount6
					   ,TradingPartnerID
					    --,PaidDateQual , PaidDateBegin, PaidDateEnd 
         --               ,DateofServiceQual , DateofServiceBegin , DateofServiceEnd
                        ,DateofServiceQual , DateofServiceBegin , DateofServiceEnd
					    ,PaidDateQual , PaidDateBegin, PaidDateEnd
--					   , ProcCode1  , ProcCode2  , ProcCode3
					--,SrvProcCode 
					,SrvPRODQual ,ProdMod1  ,ProdMod2  ,ProdMod3  ,ProdMod4  ,SrvDescription , SrvProdID
					--, PaidServQty 
					,ServiceLineChrgAmount
					,SrvLineRevCode

				   )
				  select   @IsaSenderID , @IsaControlId 
						 --, @DateOfService as DtOfSrv
					   --, @ServiceLineRevenueCode as SerLnRevCode 
					   ,@PayerPrimaryID 
					   , 	 @DaysInHospital as DaysInHos
					   , @ProviderControlNumber as PrvrCtlNum,  @ServiceLinePaidAmount as Svdamt--,  @DaysInHospital as DysInHosp
					   --, @ProcCodeQual as ProdCodeQual , @ProviderCode as ProcCode, @PaidServQty as PdSrvQty
					   --, @ProcCodeMod1 as PCM1, @ProcCodeMod2 as PCM2, @ProcCodeMod3 as PCM3   
					  -- , @MedicareDeductible as MedDeduct, @MedicareCoinsurance as MedCoIns, @MedicareBloodDeductible as MediBlood,  @MCODeniedLineAmt as MCODenied
					   --, @SEControlNum as sectlnum, @GEControlNum as GECtl, @IEAControlNum as IEACtlNum
					   , @lx01 as linenum
					   , @ClaimId as Clmid
					   , @LoadDate
					  -- ,@svdcode
				   , @ClmAdjGroupCode1 ,@ClmAdjReasonCode1 ,@ClmAdjAmount1 ,@ClmAdjGroupCode2 ,@ClmAdjReasonCode2 ,@ClmAdjAmount2 
                   , @ClmAdjGroupCode3 ,@ClmAdjReasonCode3 ,@ClmAdjAmount3 ,@ClmAdjGroupCode4 ,@ClmAdjReasonCode4 ,@ClmAdjAmount4 
                   , @ClmAdjGroupCode5 ,@ClmAdjReasonCode5 ,@ClmAdjAmount5 ,@ClmAdjGroupCode6 ,@ClmAdjReasonCode6 ,@ClmAdjAmount6 
				   ,@TradingPartnerID
				  --  ,@StatementDateQual , @StatementDateBegin, @StatementDateEnd 
					,@DateofServiceQual , @DateofServiceBegin , @DateofServiceEnd
					,@PaidDateQual, @PaidDateBegin, @PaidDateEnd
					--   ,@ProcCode1  , @ProcCode2  , @ProcCode3    
					--,@SrvProcCode 
					,@SrvPRODQual ,@ProdMod1  ,@ProdMod2  ,@ProdMod3  ,@ProdMod4  ,@SrvDescription ,@SrvProdID
					--, @PaidServQty 
					,@ServiceLineChrgAmount
					,@SrvLineRevCode
     ------------------------------------------ clear CAS ids
				   set @ClmAdjGroupCode1 = NULL ; set @ClmAdjReasonCode1 = NULL ; set @ClmAdjAmount1 = NULL ; set @ClmAdjGroupCode2 = NULL ; set @ClmAdjReasonCode2 = NULL ; set @ClmAdjAmount2 = NULL ;
                   set @ClmAdjGroupCode3 = NULL ; set @ClmAdjReasonCode3 = NULL ; set @ClmAdjAmount3 = NULL ; set @ClmAdjGroupCode4 = NULL ; set @ClmAdjReasonCode4 = NULL ; set @ClmAdjAmount4 = NULL ;
                   set @ClmAdjGroupCode5  = NULL; set @ClmAdjReasonCode5 = NULL ; set @ClmAdjAmount5 = NULL ; set @ClmAdjGroupCode6 = NULL ; set @ClmAdjReasonCode6 = NULL ; set @ClmAdjAmount6 = NULL ;
				   		  set @SrvProcCode = NULL; set @SrvPRODQual = NULL; set @SrvProdID = NULL;
		  set @ProdMod1 = NULL; set @ProdMod2 = NULL; set @ProdMod3 = NULL; set @ProdMod4 = NULL; 
		  set @SrvDescription = NULL; set @SrvLineRevCode = NULL;-- set @ServiceLineChrgAmount = Null;
--select 'after detail line written B LX',@ClaimId as clmid, @ServiceLineChrgAmount

--select 'LX insert detail ',@STControlId as STctln,  @lx01 as lx01,@hlloop as hlloop,@lxloop as lxloop, @ClaimId as clmid
               end-- @lxloop >0 
--			  end ---if

--set @lxloop =  @lxloop + 1
       set @cascount =0
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 1
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				   if @enum = 0    set @lx01 = @ele;
				 --if @enum = 1  and  @nm101 = '85' set @BillingProvState = @ele;
				 --if @enum = 2  and  @nm101 = '85' set @BillingProvZip = @ele;

---select @enum,@x, @y, @ele
--if @enum = 0 select 'LX elements', @ele , @lx01 as lxo1

				 set @enum = @enum +1
				 set @x = @y
 		     end
			 set @lxloop = @lxloop +1
		--select @isa13 
--select 'LX seg end ',@Seg as seg ,@lx01 as lx01, @ClaimId as ClmId,  @lxloop as lxloop,@hlloop as hlloop
 
 --======================================================================================================
--select 'Insert Header 22 no' , @hl03 as hl02 , @lxflag as lxglag
      if  @hl03 = '22' and @lxflag = 'NO'
		 --begin --insert the last LX loop
		   begin
--select 'Insert Header LX **************', @MediPassRefNum
 			insert into  medicaid.staging.Medicaid_Recon_837I_Header
			 (
					 IsaSenderID ,  IsaReceiverId , IsaControlId
				   , GsSenderId , GsReceiverId  ,GSControlId 
				   , STControlId ,BatchID 
				  -- , SEControlNum
				   , GEControlNum
				   , IEAControlNum
				   , TPName , TPEINId , MedicaidName , MedicaidNumber
				   , MemberLastName , MemberFirstName , MemberMedicaidID 
				   , PrimaryPayerName , PrimaryPayerID
				   , SecondaryPayerName , SecondaryPayerID
				   , AttProviderFirstName ,AttProviderLastName, AttProviderCode  ,BillingProvName, BillingProvNPI
				   , BillingProvAddress  , BillingProvCity , BillingProvState , BillingProvZip  
				   , TaxonomyCode , BillingProvEIN  , MediPassRefNum9A --,  OriginalRefNum 
				  -- , ProviderControlNumber 
				   , ClaimId , ClaimAmt , FacilityType , ClaimFrequencyType  
--				   , StatementDate ,  ContractAmt ,MCOReceiptDate ,  PrimaryDiagCode , ReasonForVisit 
				   ,  ContractAmt ,MCOReceiptDate ,  PrimaryDiagCode , ReasonForVisit 
				   , AttendingProvTaxonomyCode ,  PayerAmtPaid , RefClaimNumD9 
				--   , ClaimPaidDateCode , ClaimPaidDate
				   ,loaddate,fname
				   ,TradingPartnerID
				   ,ContractAmtQual
				   --,ClmAdjGroupCode1, ClmAdjReasonCode1, ClmAdjAmount1, ClmAdjGroupCode2, ClmAdjReasonCode2, ClmAdjAmount2
       --            ,ClmAdjGroupCode3, ClmAdjReasonCode3, ClmAdjAmount3, ClmAdjGroupCode4, ClmAdjReasonCode4, ClmAdjAmount4
       --            ,ClmAdjGroupCode5, ClmAdjReasonCode5, ClmAdjAmount5, ClmAdjGroupCode6, ClmAdjReasonCode6, ClmAdjAmount6
				 	,StatementDateQual	, StatementDateBegin ,	StatementDateEnd
					--,PaidDateQual, PaidDateBegin, PaidDateEnd

				  
			 )
			 select  @IsaSenderID , @IsaReceiverId , @IsaControlId
				   , @GsSenderId , @GsReceiverId ,@GSControlId 
				   , @STControlId  ,@BatchID
				  -- , @SEControlNum as SECtrlnum
				   , @GEControlNum as GECtlNum
				   , @IEAControlNum as IEACtlNum
				   , @TPName as Trdname, @TPEINId as TPId, @MedicaidName  as McaidName, @MedicaidNumber as MCaidNum
				   , @MemberLastName as MbrLast, @MemberFirstName as MbrFirst, @MemberMedicaidID as MbrMCaid
				   , @PrimaryPayerName as PriPyrName, @PrimaryPayerID as PriPyrId
				   , @SeconaryPayerName as SecPyrName, @SecondaryPayerID as SecPyrId
				   , @AttProviderFirstName as APRVFName, @AttProviderLastName as AProvLname, @AttProcviderCode as AttPrvCode ,@BillingProvName asBilPrvName, @BillingProvNPI as BillPrvNPI
				   , @BillingProvAddress  as BillAdr, @BillingProvCity as BillCity, @BillingProvState as BillST, @BillingProvZip as BillZip 
				   , @TaxonomyCode as Taxncode, @BillingProvEIN  as BillPrvEIN, @MediPassRefNum9A as MdeiPass--,  @OriginalRefNum as OrigRefNum
				  -- , @ProviderControlNumber as PrvCtlNum
				   , @ClaimId as Clmid, @ClaimAmt as ClmAmt, @FacilityType as FacType, @ClaimFrequencyType as clmFr2Typ 
--				   , @StatementDate as StmtDt,  @ContractAmt as CntAmt,@MCOReceiptDate as MCORReptDt,  @PrimaryDiagCode as PriDiag, @ReasonForVisit as ReasonVisit
				   ,  @ContractAmt as CntAmt,@MCOReceiptDate as MCORReptDt,  @PrimaryDiagCode as PriDiag, @ReasonForVisit as ReasonVisit
				   , @AttendingProvTaxonomyCode as AtnTaxCode,  @PayerAmtPaid as PyrAmtPd ,@RefClaimNum as refclmnum
				--   , @ClaimPaidDateCode as ClmPdDtCode,  @ClaimPaidDate as ClmPdDt
				   , @LoadDate
				   , @FILENAME
				   ,@TradingPartnerID
				   ,@cn101
				   --, @ClmAdjGroupCode1 ,@ClmAdjReasonCode1 ,@ClmAdjAmount1 ,@ClmAdjGroupCode2 ,@ClmAdjReasonCode2 ,@ClmAdjAmount2 
       --            , @ClmAdjGroupCode3 ,@ClmAdjReasonCode3 ,@ClmAdjAmount3 ,@ClmAdjGroupCode4 ,@ClmAdjReasonCode4 ,@ClmAdjAmount4 
       --            , @ClmAdjGroupCode5 ,@ClmAdjReasonCode5 ,@ClmAdjAmount5 ,@ClmAdjGroupCode6 ,@ClmAdjReasonCode6 ,@ClmAdjAmount6 
				   --, @BillingProvName, @BillingProvNPI
				   	,@StatementDateQual	, @StatementDateBegin ,	@StatementDateEnd
					--,@PaidDateQual, @PaidDateBegin, @PaidDateEnd
   end --if write header
 --======================================================================================================
     set @lxflag = 'yes'

 end -- LX loop

--            end --while loop through elements
		 -- end --if 
----------------------------END LX-------------------------------------------------------------------------
--=========================================================================================================
-----------------------------Begin SV2------------------------------------------------------------------------
   if (left(@Seg,4) = 'SV2*' or substring(@Seg,2,4) = 'SV2*') and LEN(@seg) >15

	   begin
		  set @SrvProcCode = NULL; set @SrvPRODQual = NULL; set @SrvProdID = NULL;
		  set @ProdMod1 = NULL; set @ProdMod2 = NULL; set @ProdMod3 = NULL; set @ProdMod4 = NULL; 
		  set @SrvDescription = NULL;

	   set @enum = 0
	   set @subenum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 5
		    begin 
 --@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		  set @SrvProcCode = NULL; set @SrvPRODQual = NULL; set @SrvProdID = NULL;
		  set @ProdMod1 = NULL; set @ProdMod2 = NULL; set @ProdMod3 = NULL; set @ProdMod4 = NULL; 
		  set @SrvDescription = NULL;



IF OBJECT_ID('tempdb.dbo.#temp1') IS NOT NULL
	DROP TABLE #temp1;
drop table if exists #temp1

create table #temp1(
    [element] varchar (500) null,
	[segnum] [int] IDENTITY(1,1) NOT NULL,

	 )


declare @Segment varchar (500)
declare @subSegent varchar (500)
declare @subelement varchar(500)

--set  @Segment = 'SV2*0306*HC:U0002:QW::::COVID 19 LAB TEST NON CDC*199.6*UN*1~'


set @Segment = @Seg

insert into #temp1 
       select * from string_split(@Seg , '*')


drop table if exists #temp2
create table #temp2(
    [element] varchar (500) null,
	[segnum] [int] IDENTITY(1,1) NOT NULL,
	 )

set  @subSegent  = (select element from #temp1 where segnum = 3)

insert into #temp2 
       select * from string_split(@subSegent , ':')

--select * from #temp1

--select * from #temp2

 		  set @SrvProcCode = NULL; set @SrvPRODQual = NULL; set @SrvProdID = NULL;
		  set @ProdMod1 = NULL; set @ProdMod2 = NULL; set @ProdMod3 = NULL; set @ProdMod4 = NULL; 
		  set @SrvDescription = NULL;

              set @SrvProcCode = (select element from #temp1 where segnum = 2)
                set @ServiceLineChrgAmount = (select element from #temp1 where segnum = 4)
                set  @DaysInHospital = (select element from #temp1 where segnum = 6)
 -------------------------------------------------------------------------
                set @SrvPRODQual = (select element from #temp2 where segnum = 1)
                set @SrvProdID = (select element from #temp2 where segnum = 2)
                set @ProdMod1  = (select element from #temp2 where segnum = 3)
                set @ProdMod2 = (select element from #temp2 where segnum = 4)
                set @ProdMod3 = (select element from #temp2 where segnum = 5)
 --               set @ProdMod3 = (select element from #temp2 where segnum = 6)
                set @ProdMod4 = (select element from #temp2 where segnum = 6)
                set @SrvDescription = (select element from #temp2 where segnum = 7)


--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

								 
								 set @subenum = @subenum +1
								 set @subx = @suby
								-- if @subenum = 5   set @ProcCode3 = @subele;
--select 'X', left(@Seg,20)as ele,  @subele as subele, @subenum as subenum, @subx, @suby, @ProcCodeMod3 as oc3

								 
								-- set @subenum = @subenum +1
								 --set @subx = @suby
							--end -- IF while loop through subelements
								
-- select 'X', left(@Seg,20)as ele--,  @subele as subele, @subenum as subenum, @subx, @suby

				    -- end --1f
-----------------------------------------------------------------------------------------------------
				 --if @enum = 0   set @ServiceLineRevenueCode = @ele;
-----select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele ,@ServiceLinePaidAmount--, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END SV2-------------------------------------------------------------------------
-----------------------------Begin SVD------------------------------------------------------------------------
  if left(@Seg,4) = 'SVD*' or substring(@Seg,2,4) = 'SVD*'

	   begin
		   
	   set @enum = 0
	   set @subenum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 5
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 0   set @PayerPrimaryID = @ele;
--select @ClaimId, @enum as enum, @PayerPrimaryID as ppID
				 if @enum = 0   set @ServiceLineRevenueCode = @ele;
				 if @enum = 1   set @ServiceLinePaidAmount	=  @ele --substring(@ele,1,2);
				 if @enum = 4   set @DaysInHospital = @ele;
				 if @enum = 3   set @PaidServQty = @ele;
				 if @enum = 3   set @SrvLineRevCode = @ele;
------------------------------------------------------------------------------------------------------
				 if @enum = 2  set @ProcCodeQual = substring(@ele,1,2);
				 if @enum = 2  set @ProviderCode = substring(@ele,4,5);
----------------------------------------------------------------------------------------------------
				 --if @enum = 0   set @ServiceLineRevenueCode = @ele;
				 --if @enum = 0   set @ServiceLineRevenueCode = @ele;

--select @enum, @ele
--select left(@seg,20), @enum, @ele--, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END SVD-------------------------------------------------------------------------
-----------------------------Begin CAS------------------------------------------------------------------------
  if left(@Seg,4) = 'CAS*' or substring(@Seg,2,4) = 'CAS*'

	   begin
		   
       set @cascount = @cascount + 1
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 3
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 --if @enum = 1   set @cas02 = @ele;
				 --if @enum = 2   and @cas02 = '1' set @MedicareDeductible	= @ele;
				 --if @enum = 2   and @cas02 = '2' set @MedicareCoinsurance	= @ele;
				 --if @enum = 2   and @cas02 = '66' set @MedicareBloodDeductible	= @ele;
				 --if @enum = 2   and @cas02 = 'A1' set @MCODeniedLineAmt	= @ele;
  if @enum = 0 and  @cascount = 1 set @ClmAdjGroupCode1 = @ele
  if @enum = 1 and  @cascount = 1 set @ClmAdjReasonCode1 = @ele
  if @enum = 2 and  @cascount = 1 set @ClmAdjAmount1 = @ele
  if @enum = 0 and  @cascount = 2 set @ClmAdjGroupCode2 = @ele
  if @enum = 1 and  @cascount = 2 set @ClmAdjReasonCode2 = @ele
  if @enum = 2 and  @cascount = 2 set @ClmAdjAmount2 = @ele
  if @enum = 0 and  @cascount = 3 set @ClmAdjGroupCode3 = @ele
  if @enum = 1 and  @cascount = 3 set @ClmAdjReasonCode3 = @ele
  if @enum = 2 and  @cascount = 3 set @ClmAdjAmount3 = @ele
  if @enum = 0 and  @cascount = 4 set @ClmAdjGroupCode4 = @ele
  if @enum = 1 and  @cascount = 4 set @ClmAdjReasonCode4 = @ele
  if @enum = 2 and  @cascount = 4 set @ClmAdjAmount4 = @ele
  if @enum = 0 and  @cascount = 5 set @ClmAdjGroupCode5 = @ele
  if @enum = 1 and  @cascount = 5 set @ClmAdjReasonCode5 = @ele
  if @enum = 2 and  @cascount = 5 set @ClmAdjAmount5 = @ele
  if @enum = 0 and  @cascount = 6 set @ClmAdjGroupCode6 = @ele
  if @enum = 1 and  @cascount = 6 set @ClmAdjReasonCode6 = @ele
  if @enum = 2 and  @cascount = 6 set @ClmAdjAmount6 = @ele
-----select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele, @cascount --, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
		  end --if ST
		--select @isa13 
-----------------------------END CAS-------------------------------------------------------------------------
---------------------------- StartSE----------------------------------------------------------------------
   if left(@Seg,3) = 'SE*' or substring(@Seg,2,3) = 'SE*'

	   begin
--select 'Insert Detail  SE **************'

------------------------------insert last LX loop
insert into Medicaid.staging.Medicaid_Recon_837I_Detail
    (    IsaSenderID , IsaControlId 
      -- , DateOfService  
	   ---, ServiceLineRevenueCode
	   ,PayerPrimaryID
	   , DaysInHospital  
	   , ProviderControlNumber  ,  ServiceLinePaidAmount  --,  DaysInHospital  
	   --, ProcCodeQual  , ProcrCode  , PaidServQty  
	   --, ProcCodeMod1  , ProcCodeMod2  , ProcCodeMod3    
	  -- , MedicareDeductible  , MedicareCoinsurance  , MedicareBloodDeductible  ,  MCODeniedLineAmt  
	   --, SEControlNum  , GEControlNum , IEAControlNum  
	   , LineItemNumber
	   , ClaimId
	   ,LoadDate
				     ,ClmAdjGroupCode1, ClmAdjReasonCode1, ClmAdjAmount1, ClmAdjGroupCode2, ClmAdjReasonCode2, ClmAdjAmount2
                     ,ClmAdjGroupCode3, ClmAdjReasonCode3, ClmAdjAmount3, ClmAdjGroupCode4, ClmAdjReasonCode4, ClmAdjAmount4
                     ,ClmAdjGroupCode5, ClmAdjReasonCode5, ClmAdjAmount5, ClmAdjGroupCode6, ClmAdjReasonCode6, ClmAdjAmount6
	   --,svdcode
	   ,TradingPartnerID
--	   	,StatementDateQual	, StatementDateFrom	, StatementDateThru	
		 --,PaidDateQual , PaidDateBegin, PaidDateEnd 
		 --,DateofServiceQual , DateofServiceBegin , DateofServiceEnd
		 ,DateofServiceQual , DateofServiceBegin , DateofServiceEnd
		 ,PaidDateQual , PaidDateBegin, PaidDateEnd 
		 --  , ProcCode1  , ProcCode2  , ProcCode3 
 					--,SrvProcCode 
					,SrvPRODQual ,ProdMod1  ,ProdMod2  ,ProdMod3  ,ProdMod4  ,SrvDescription , SrvProdID
					--, PaidServQty 
					,ServiceLineChrgAmount
					,SrvLineRevCode

   )
  select   @IsaSenderID , @IsaControlId 
         --, @DateOfService as DtOfSrv
	   --, @ServiceLineRevenueCode as SerLnRevCode 
	   ,@PayerPrimaryID
	   , @DaysInHospital as DaysInHos
	   , @ProviderControlNumber as PrvrCtlNum,  @ServiceLinePaidAmount as Svdamt--,  @DaysInHospital as DysInHosp
	   --, @ProcCodeQual as ProdCodeQual , @ProviderCode as ProcCode, @PaidServQty as PdSrvQty
	   --, @ProcCodeMod1 as PCM1, @ProcCodeMod2 as PCM2, @ProcCodeMod3 as PCM3   
	   --, @MedicareDeductible as MedDeduct, @MedicareCoinsurance as MedCoIns, @MedicareBloodDeductible as MediBlood,  @MCODeniedLineAmt as MCODenied
	   --, @SEControlNum as sectlnum, @GEControlNum as GECtl, @IEAControlNum as IEACtlNum
	   , @lx01 as linenum
	   , @ClaimId as Clmid
	   , @LoadDate
				   , @ClmAdjGroupCode1 ,@ClmAdjReasonCode1 ,@ClmAdjAmount1 ,@ClmAdjGroupCode2 ,@ClmAdjReasonCode2 ,@ClmAdjAmount2 
                   , @ClmAdjGroupCode3 ,@ClmAdjReasonCode3 ,@ClmAdjAmount3 ,@ClmAdjGroupCode4 ,@ClmAdjReasonCode4 ,@ClmAdjAmount4 
                   , @ClmAdjGroupCode5 ,@ClmAdjReasonCode5 ,@ClmAdjAmount5 ,@ClmAdjGroupCode6 ,@ClmAdjReasonCode6 ,@ClmAdjAmount6 
	   --, @svdcode
	   ,@TradingPartnerID
--	   ,@StatementDateQual	, @StatementDateFrom	, @StatementDateThru	
        ,@DateofServiceQual , @DateofServiceBegin , @DateofServiceEnd
	    ,@PaidDateQual , @PaidDateBegin, @PaidDateEnd 
--   , @ProcCode1  ,@ProcCode2  , @ProcCode3    
					--,@SrvProcCode
					,@SrvPRODQual ,@ProdMod1  ,@ProdMod2  ,@ProdMod3  ,@ProdMod4  ,@SrvDescription ,@SrvProdID
					--, @PaidServQty 
					,@ServiceLineChrgAmount
					,@SrvLineRevCode

--------------------------------clear CAS variables
				   set @ClmAdjGroupCode1 = NULL ;set @ClmAdjReasonCode1 = NULL ;set @ClmAdjAmount1 = NULL ;set @ClmAdjGroupCode2 = NULL ;set @ClmAdjReasonCode2 = NULL ;set @ClmAdjAmount2 = NULL ;
                   set @ClmAdjGroupCode3 = NULL ;set @ClmAdjReasonCode3 = NULL ;set @ClmAdjAmount3 = NULL ;set @ClmAdjGroupCode4 = NULL ;set @ClmAdjReasonCode4 = NULL ;set @ClmAdjAmount4 = NULL ;
                   set @ClmAdjGroupCode5  = NULL;set @ClmAdjReasonCode5 = NULL ;set @ClmAdjAmount5 = NULL ;set @ClmAdjGroupCode6 = NULL ;set @ClmAdjReasonCode6 = NULL ;set @ClmAdjAmount6 = NULL ;
				   		  set @SrvProcCode = NULL; set @SrvPRODQual = NULL; set @SrvProdID = NULL;
		  set @ProdMod1 = NULL; set @ProdMod2 = NULL; set @ProdMod3 = NULL; set @ProdMod4 = NULL; 
		  set @SrvDescription = NULL; set @SrvLineRevCode = NULL;-- set @ServiceLineChrgAmount = Null;
select 'after detail line written SE', @lx01, @ServiceLineChrgAmount

--select 'SE insert Detail' ,@STControlId as STcntl, @lx01 as lx01
----------------------------------------------------
	   	   set @Seg = @Seg + @elesep

	     if @lxloop < 1 begin
				select  @DateOfService as DtOfSrv             
			  end
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 3
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = substring(@Seg,@x+1, @y-@x-1)
				 if @enum = 1  set @SEControlNum = replace(@ele,'~','');

---select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele --, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y

             end --loop through elements
--update m
--   set [SEControlNum]  = 'X' ---@SEControlNum
--     from Medicaid.staging.Medicaid_Recon_837I_Header m
--	 where m.SEControlNum = @SEControlNum

--select 'SE', @Seg
set @hlflag = ''; set  @hl03 = ''
		  end --if ST
         
	--   end
-- --if SE*
-----------------------------------------------end SE -------------------------------------------------------------------------
---------------------------- Start GE----------------------------------------------------------------------
   if left(@Seg,3) = 'GE*' or substring(@Seg,2,3) = 'GE*'

	   begin

	   	   set @Seg = @Seg + @elesep

	     if @lxloop < 1 begin
				select  @DateOfService as DtOfSrv             
			  end
	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 2
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 1  set @GEControlNum = @ele;

---select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements
update Medicaid.staging.Medicaid_Recon_837I_Header
   set [GEControlNum]  = @GEControlNum
    where GSControlId = @GSControlId
--select 'GE', @GEControlNum

		  end --if ST
         

	--   end
-- --if SE*
-----------------------------------------------end GE -------------------------------------------------------------------------
---------------------------- Start IEA----------------------------------------------------------------------
   if left(@Seg,4) = 'IEA*' or substring(@Seg,2,4) = 'IEA*'

	   begin

-------------------------------------------------------------------------------------------------------------------------
	   	   set @Seg = @Seg + @elesep

	   set @enum = 0
	   set @x = 0; set @y=0;
	   set @Seg = @Seg + @elesep
	    while @enum < 2
		    begin 
				 set @x = charindex(@elesep,@seg, @x)
				 set @y = charindex(@elesep,@seg,@x+1)
				 set @ele = replace(substring(@Seg,@x+1, @y-@x-1),'~','')
				 if @enum = 1  set @IEAControlNum = @ele;

---select @enum,@x, @y, @ele
--select left(@seg,20), @enum, @ele, @nm101 as nm1

				 set @enum = @enum +1
				 set @x = @y
             end --loop through elements

				update Medicaid.staging.Medicaid_Recon_837I_Header
				   set [IEAControlNum]  = @IEAControlNum
				   where IsaControlId = @IsaControlId

--select 'IEA', @IEAControlNum

-----------------------------------------------------------------
-------------------------------------------
		  end --if IEA
         
	--   end
-- --if SE*
-----------------------------------------------end IEA -------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------

	FETCH NEXT FROM cur INTO @CursorTestID,@Seg

END

CLOSE cur
DEALLOCATE cur 
 -------------------------------------------------------------------------------------------------------------
--=============================================================================================================================
--=============================================================================================================================
 GO


