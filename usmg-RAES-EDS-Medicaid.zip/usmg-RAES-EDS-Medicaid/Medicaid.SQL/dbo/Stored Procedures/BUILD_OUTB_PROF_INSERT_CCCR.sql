﻿CREATE PROCEDURE dbo.BUILD_OUTB_PROF_INSERT_CCCR
AS
/************************************************************************************************************************
** CREATE DATE: 08/10/2017
**
** AUTHOR: Henry Faust
**
** DESCRIPTION: Populates the table OUTB_Prof_CCCR. The table is used to eliminate multiple DX codes
**              
**              
**
**
Modification History
====================
Date			Who				Description
--------------------------------------------------------------------------------------------------------------------------
 08/10/2017		henry Faust   This procedure populates the table OUTB_PROF_CCCR with only the unique Diagnosis codes.
                              Primary Diag Code row number 1, the rest are offset by 1.     
								
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2017-08-10		Henry Faust TETDM 1501		WIPRO Implementation																							    
2018-04-01		Henry Faust TETDM 1769		fix codes and pointer issue	
2021-26-08		Anthony Ulmer	MES-133 Update to implement transfer to Medicaid database
*****************************************************************************************************/	
/* Notes: The logic for figureing out which DX codes to allow and in what order can be confusing. For
Professional claims, the Primary and secondary DX code 1 wil always be the same. Secondary DX codes 2-30 can 
be duplicates. Since the Primary and first secondary DX code are always the same, I started out by adding the 
Primary Code twice, that takes of getting that piece of logic correct. Then I when through and added Secondary 
DX codes 1-30, IF they weren't already in the temp table. There are many different combination sequences 
the codes could come in and those claims with missing sequence numbers. This logic was takes care of every 
scenario I have come across in testing. I set all the code to populate the table dbo.OUTB_PROF_CCCR 
so all the codes are in the correct order. That way when the mapping has to be done, it is a simple pick a 
row from a table. I decided to put all logic for ordering and correcting the data here instead of replicating
 30 times in the mapping SP.
*/

DECLARE
			@TOTAL_RECORDS INT;

					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('BUILD_OUTB_PROF_INSERT_CCCR' 
							,'1.1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							);


TRUNCATE TABLE dbo.OUTB_PROF_CCCR;

	IF OBJECT_ID('TEMPDB..#CLMPCDPS') <> 0
					DROP TABLE #CLMPCDPS;

	create table  #CLMPCDPS
	(claimid varchar(20),
	  dgcd VARCHAR(10),
	  sequence varchar(2),
	  POAIND varchar(1));
   CREATE CLUSTERED INDEX cmsidcps_idx ON #CLMPCDPS (claimid, sequence);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 1 AND cdd.DIAGNOSISTYPECODE = 'P'
)x;

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 1 AND cdd.DIAGNOSISTYPECODE = 'P'
)x;


INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 1 AND cdd.DIAGNOSISTYPECODE = 'S' 
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);


INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 2  
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);


INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 3          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 4          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 5          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 6          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 7          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 8          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 9          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 10          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);
--------------
-- 11 - 20
--------------
INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 11
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);


INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 12  
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);


INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 13          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 14          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 15          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 16          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 17          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 18          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 19          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 20          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);
--------------
-- 21 - 30
--------------
INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 21
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);


INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 22  
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);


INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 23          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 24          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 25          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 26          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 27          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 28          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 29          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);

INSERT INTO #CLMPCDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM Medicaid.[dbo].[CLAIMDIAGNOSISDIM] cdd --MES-133
			 JOIN dbo.OUTB_PROF_HEADER oph ON cdd.CLAIMID = oph.claim_id AND cdd.sequence = 30          
)x
WHERE NOT EXISTS (SELECT 1 FROM #CLMPCDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd);


-----
--insert into table
-----


TRUNCATE TABLE dbo.OUTB_PROF_CCCR;

INSERT INTO dbo.OUTB_PROF_CCCR
        ( Rownum,
  claim_id , dgcd, POAIND
        )

		SELECT 
		  ROW_NUMBER() OVER(PARTITION BY claimid  ORDER BY claimid, sequence) AS Rownum,
		  claimid ,  dgcd,  POAIND
		FROM  
		(
		SELECT TOP 100 percent claimid ,sequence, dgcd,  POAIND FROM #CLMPCDPS
		 --group BY claimid, sequence, dgcd, poaind
		 ORDER BY claimid, sequence
		)q;

--SELECT	* FROM  dbo.OUTB_PROF_CCCR					

			SET  @TOTAL_RECORDS = (SELECT COUNT(*) FROM dbo.OUTB_PROF_CCCR);								


						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_PROF_INSERT_CCCR' 
										and END_DT is null;













