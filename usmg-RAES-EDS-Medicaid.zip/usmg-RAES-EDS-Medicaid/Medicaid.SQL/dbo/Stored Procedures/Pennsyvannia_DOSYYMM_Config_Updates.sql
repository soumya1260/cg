﻿

CREATE PROCEDURE [dbo].[Pennsyvannia_DOSYYMM_Config_Updates]
(@JOBID INT) --DEFAULT VALUE)--, @DOS_BEGIN CHAR(8), @DOS_END CHAR(8))--, @BEGIN_BILLTYPECODE CHAR(5) , @END_BILLTYPECODE CHAR(5))
AS
/***************************************************************************************************
** CREATE DATE: 04/20/2023
**
** AUTHOR: Aaron Ridley 
**
** DESCRIPTION: Medicaid Configuration table updates 
**

-----------------------------------------------------------------------------------------------------*/

IF @JOBID = 6032
BEGIN

select
DISTINCT
'PA' AS LOB,
CASE WHEN RIGHT(LOB,2) = '12' AND SUBSTRING(LOB,3,4) = '2018' THEN '201901' 
	 WHEN RIGHT(LOB,2) = '12' AND SUBSTRING(LOB,3,4) = '2019' THEN '202001' 
	 WHEN RIGHT(LOB,2) = '12' AND SUBSTRING(LOB,3,4) = '2020' THEN '202101' 
	 WHEN RIGHT(LOB,2) = '12' AND SUBSTRING(LOB,3,4) = '2021' THEN '202201' 
	 WHEN RIGHT(LOB,2) = '12' AND SUBSTRING(LOB,3,4) = '2022' THEN '202301' 
	 ELSE 
	 RIGHT(lob,6) + 1
END   AS NEWLOB
INTO #TMP
FROM MEDICAID.[dbo].[MedicaidJobIDConfig] 
WHERE LEFT(LOB,2) = 'PA'

UPDATE A 
set lob = concat(b.LOB, NEWLOB)
FROM MEDICAID.[dbo].[MedicaidJobIDConfig] A
INNER JOIN #TMP B ON LEFT(A.LOB,2) = B.LOB
WHERE LEFT(A.LOB,2) = 'PA'  

END