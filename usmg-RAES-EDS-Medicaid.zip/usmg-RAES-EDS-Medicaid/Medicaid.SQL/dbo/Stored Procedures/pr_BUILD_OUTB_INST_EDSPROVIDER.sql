﻿
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_EDSPROVIDER]
AS
/***************************************************************************************************
** CREATE DATE: 01/19/2013
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY OBTAIN PROVIDER SPECIFIC  
**              INFORMATION NEEDED FOR THE HRP Institutional CLAIM FILE. 
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-------------------------------------------------------------------------------------------------------------
03/07/2013		loyal ricks		Renumbered step from 6B to 6. Procedure replaces old EXSP_HRP_CLAIM_PROVIDER
04/02/2013		Loyal Ricks		Revisions supporting EDPS_Data.dbo.EDS_ProviderDim vendor updates
04/05/2013		Loyal Ricks		Add BILL_PROV_GRP and BILL_PROV EDS_Provider Update Logic 
04/07/2013		Loyal Ricks		Remove 'UNKNOWN' values from BILL_PROV AddressLine2
04/16/2013		Loyal Ricks		Add case statement to remove 'UNKNOWN' value from Title
04/18/2013		Loyal Ricks		Add REF_PROV_NPI,REF_PROV_PCP_NPI,ATTN_PROV_NPI
								Revised Logic to omit duplicate records from #TMP_EDSPROV
								Revised logic to transform 'UNKNOWN' REF_PROV_ID TO ''
05/09/2013		Loyal Ricks		Add Rendering Provider logic with condition to remove bill_prov info
								when both bill prov and bill provider group are known and passed
								Removal of PayTo information due to HS claim submissions. Payto no longer 
								needed.
05/10/2013		Loyal Ricks		Add Rendering Provider Group Id & Org Name conditionally when rendering provider
								is suspected to be a entity and not an individual
05/23/2013		Loyal Ricks		Added additional logic for conditional Billing Prov Group Updates required to
								resolve rej_rea_id = 1 & FIELD_ERR = 'LastOrOrg'
06/25/13		Loyal Ricks		REF_PROV Updates using NPID from claim to find REF_PROV name and NPID from 
								EDS_Provider
---------------------------------------------Institutional Revisions---------------------------------------------
08/06/13		Loyal Ricks		EDPS_Data.dbo.EDS_ProviderDim.RecordSource revisions - Billing Group - Only use record source = 'V'
								records for Billing Provider Group address information. Global provider revisions
								have set all address info for recordsource = 'P' records to null.
08/16/13		Loyal Ricks     Revisions to support EDS_PROVIDERADDRESSDIM - Update Billing Provider Address info
								using EDS_ProviderAddressdim
09/25/2013		Loyal Ricks		Rename procedure from EXSP_HRP_CLAIM_EDSPROVIDER_INST
06/24/14		Loyal Ricks		Additional where clause "P.RecordSource = 'V' for BILL_PROV_GRP_NPI & BILL_PROV_ORG_NAME UPDATES
								EDPS_Data.dbo.EDS_ProviderDim CONTAINS MULTIPLE RECORDS, NEED TO UPDATE BILLING GROUP USING VENDOR RECORD
04/14/15		Loyal Ricks		 Add evaluation of zipcode in order to proper assign zip4 only when 5 digit zip exists
02/09/16		Loyal Ricks		TETDM-632 Billing Provider Group Address Info Update - Update when Group Address is blank
09/22/17		Scott Waller	TETDM-1611 MAO QNXT Inst Denied job kept failing on data being truncated
								95 char fields being moved into a 60 char field - 3 occurrences
03/15/2018      John Bartholomay TETDM-1678 Use NPI information from Historical claim when present
03/04/2019		Anthony Ulmer	TETDM-1957 Updates for NPI field showing up as 'UKNOWN'

06/11/2020		Scott Waller	TETDM-2278 Make correction to BILL_PROV_ORG_NAME, BILL_PROV_LNAME columns.  They 
								sometimes have the same values, or values in both when they should not.  Make 
								change so that if they both have values, that BILL_PROV_LNAME contains the value
								and BILL_PROV_ORG_NAME is blank.
								Also populate the BILL_PROV_TAXONOMY_CD column from the EDPS_Data.IDQ.CMSTaxonomy
								table.
								When BILL_PROV_NPI and BILL_PROV_GRP_NPI have the same value, set one to blank.
04/13/2023		Aaron Ridley	Medicaid update to use Configuration tables as we incorporate FL/PA 
**************************************************************************************************************/			
	--DECLARE VARIABLES

			DECLARE
			
			@TOTAL_RECORDS INT


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('pr_BUILD_OUTB_INST_EDSPROVIDER'
				,'6'
				,GETDATE()
				,null
				,' '
				,0
				,GETDATE()
				)
	--GET BILLING AND SERVICING PROVIDER INFORMATION FROM CLAIMDETAILDIM
	--03/21/13 ADD CLAIMDIM.VENDORNPI - USE VENDORNPI FROM CLAIMDIM TO IDENTIFY BILL_PROV_GRP INFO
	---CLAIMDETAILDIM.VENDORID OFTEN NOT FOUND IN EDPS_Data.dbo.EDS_ProviderDim.PROVIDERID
	IF OBJECT_ID('TEMPDB..#TMPDEV_CLMPROV') <> 0
		DROP TABLE #TMPDEV_CLMPROV
		
	SELECT DISTINCT  c.CLAIMID
					,cd.VENDORID
					,IIF(c.VENDORNPI = 'UNKNOWN',ISNULL(qc.billingprovidentifier,' '), isnull(c.vendornpi,' ')) as vendornpi
					,cd.PROVIDERID
					,CASE cd.PROVIDERNPI WHEN 'UNKNOWN' THEN ISNULL(qc.billingprovidentifier,' ') WHEN '0000000000' THEN ' ' ELSE cd.PROVIDERNPI END AS 'PROVIDERNPI'
					,c.SourceDataKey
	INTO  #TMPDEV_CLMPROV
	FROM Medicaid.dbo.claimdim c
		JOIN Medicaid.dbo.claimdetaildim cd 
			ON c.claimid = cd.claimid 
			AND c.SOURCEDATAKEY = cd.SOURCEDATAKEY
		LEFT JOIN EDPS_Data.dbo.QNXT_Claim837 qc
			ON c.CLAIMID = qc.ClaimID
	WHERE 1 = 1
			--and cd.VENDORID <> 'UNKNOWN'
			AND EXISTS (SELECT 1 FROM MEDICAID.dbo.OUTB_INST_HEADER oih WHERE oih.CLAIM_ID = c.claimid)
	
		
	--UPDATE OUTB_INST_HEADER WITH PROVIDER IDENTIFIERS FROM CLAIMDETAILDIM
	
	BEGIN TRANSACTION 
	UPDATE OUTB_INST_HEADER
	SET BILL_PROV_NPI = substring(rtrim(T.PROVIDERNPI),1,10)
		,BILL_PROV_ID = substring(rtrim(T.PROVIDERID),1,40)
		,BILL_PROV_GRP_ID = substring(rtrim(T.VENDORID),1,40)
		,BILL_PROV_GRP_NPI = substring(rtrim(ISNULL(T.VENDORNPI,' ')),1,40)
	FROM OUTB_INST_HEADER C
		,#TMPDEV_CLMPROV T
	WHERE C.CLAIM_ID = T.CLAIMID
	IF @@ERROR <> 0
		if @@ERROR <> 0
			begin
				rollback 
			end
		commit
			
	--Build #tmp_edsprov --Get Claim and provider identifiers along with additional provider info from EDPS_Data.dbo.EDS_ProviderDim
	
		IF OBJECT_ID('TEMPDB..#temp_clmprov') <> 0
		DROP TABLE #temp_clmprov
		
		Create Table #temp_clmprov
 		(
 		[CLAIMID]	[VARCHAR](20),
 		[BILL_PROV_GRP_ID] [VARCHAR] (40),
 		[BILL_PROV_GRP_NPI] [VARCHAR] (40),
 		[BILL_PROV_ID]	[VARCHAR](40),
 		[BILL_PROV_NPI] [VARCHAR] (40),
 		[REF_PROV_ID]	[VARCHAR](50),
 		--[REF_PCP_PROV_ID]	[VARCHAR](50),
 		[ATTN_PROV_ID]  [VARCHAR](50),
 		[SOURCEDATAKEY]	INT,
 		[STATUS_CD]  [VARCHAR] (500)
 		)
 		
 		--GET ALL CLAIM PROVIDER IDENTIFIERS 
 		insert into #temp_clmprov
 		select	claim_id
 				,BILL_PROV_GRP_ID	--Billing Provider Group ID
 				,BILL_PROV_GRP_NPI	--Billing Provider Group NPI
 				,BILL_PROV_ID		--Billing Provider Plan Provider ID
 				,BILL_PROV_NPI		--Billing Provider NPI
 				,case REF_PROV_ID  when 'UNKNOWN' THEN ' ' ELSE REF_PROV_ID END
 				--,case REF_PCP_PROV_ID when 'UNKNOWN' THEN ' ' ELSE REF_PCP_PROV_ID END
 				,CASE ATTN_PROV_ID when 'UNKNOWN' THEN ' ' ELSE ATTN_PROV_ID END
 				,SOURCEDATAKEY
 				,NULL
 		from OUTB_INST_HEADER	
 		
 	IF OBJECT_ID('TEMPDB..#TMP_EDSPROV_BILLGRP') <> 0
		DROP TABLE #TMP_EDSPROV_BILLGRP
		
 		
 	CREATE TABLE #TMP_EDSPROV_BILLGRP
 	(
 	[RecordSource] [CHAR] (1),
 	[ProviderID] [VARCHAR](20) ,
	[ProviderTypeCode] [varchar](15) ,
	[ProviderStatus] [varchar](10) ,
	[GlobalCurrentPatientLoad] [varchar](5) ,
	[AdditionalBusinessName] [varchar](35) ,
	[PrimaryBusinessName] [varchar](90) ,
	[FullName] [varchar](95) ,
	[ReverseFullName] [varchar](95) ,
	[LastName] [varchar](60) ,
	[FirstName] [varchar](40) ,
	[MiddleName] [varchar](30) ,
	[Title] [varchar](15) ,
	[GlobalPanelSize] [varchar](5) ,
	[NewPatientFlag] [char](1) ,
	[DeaNumber] [varchar](10) ,
	[Gender] [char](1) ,
	[DOBDateKey] [int] ,
	[UPIN] [varchar](20) ,
	[FIDN] [varchar](25) ,
	[NPID] [varchar](10) ,
	[MedicaidID] [varchar](20) ,
	[MedicareID] [varchar](20) ,
	[HandicapAccess] [varchar](1) ,
	[CredentialingStatus] [varchar](15) ,
	[ProvCategory] [varchar](15) ,
	[LicenseTypeCode] [char](1) ,
	[LeasedStatusCode] [char](1) ,
	[PreferredStatusCode] [char](1) ,
	[ChildFlg] [char](1) ,
	[YouthFlg] [char](1) ,
	[AdultFlg] [char](1) ,
	[StandardHoursInd] [char](1) ,
	[AfterHoursInd] [char](1) ,
	[WeekendHoursInd] [char](1) ,
	--[SourceDataKey] [int] ,
	[ProviderType_ProviderTypeDesc] [varchar](60) ,
	--Global Provider vendor revisions
	[VendorID] [varchar](20) ,
	[VendorTypeCode] [varchar](15),
	[Vendor_NPI] [varchar] (10),
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	[Vendor_Phone] [varchar](20) ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	[Vendor_AddressLine1] [varchar](60) ,
	[Vendor_AddressLine2] [varchar](60) ,
	[Vendor_City] [varchar](30) ,
	[Vendor_State] [char](2) ,
	[Vendor_ZipCode9] [varchar] (11),--(9) ,
	--[ProviderAddress_MultiAddressInd] [int] ,
	--[ProviderAddress_Latitude] [decimal](9, 6) ,
	--[ProviderAddress_Longitude] [decimal](9, 6) ,
	--[ProviderAddress_AddressTypeDesc] [varchar](20) ,
	[Ingenix_TaxonomyCode] [varchar](10) ,
	[Ingenix_SpecialtyName] [varchar](60) ,
	[Ingenix_SpecialtyGroupName] [varchar](60) ,
 	[SourceDataKey] [INT]
 	)
 		
	--Build Provider Record for Billing Group 
	
	INSERT INTO #TMP_EDSPROV_BILLGRP
	SELECT distinct 
	RecordSource ,
	T.BILL_PROV_GRP_ID,
	ProviderTypeCode  ,
	ProviderStatus  ,
	GlobalCurrentPatientLoad  ,
	AdditionalBusinessName  ,
	PrimaryBusinessName  ,
	Vendor_VendorName  ,
	ReverseFullName  ,
	LastName  ,
	FirstName  ,
	MiddleName  ,
	case Title when 'UNKNOWN' then ' ' else Title end,
	GlobalPanelSize  ,
	NewPatientFlag  ,
	DeaNumber  ,
	Gender  ,
	DOBDateKey  ,
	UPIN  ,
	--FIDN  ,	
	VENDOR_FEDERALID , --use vendor info for billing group
	isnull(NPID,' ')  ,
	MedicaidID  ,
	MedicareID  ,
	HandicapAccess  ,
	CredentialingStatus  ,
	ProvCategory  ,
	LicenseTypeCode  ,
	LeasedStatusCode  ,
	PreferredStatusCode  ,
	ChildFlg  ,
	YouthFlg  ,
	AdultFlg  ,
	StandardHoursInd  ,
	AfterHoursInd  ,
	WeekendHoursInd  ,
	--SourceDataKey  ,
	ProviderType_ProviderTypeDesc  ,
	t.BILL_PROV_GRP_ID  , --Vendor_VendorID ,
	Vendor_VendorTypeCode ,
	case t.BILL_PROV_GRP_NPI when 'N/A' then ' ' else ISNULL(t.BILL_PROV_GRP_NPI,' ') end , --Vendor_NPIID ,
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	Vendor_Phone ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	Vendor_AddressLine1  ,
	Vendor_AddressLine2  ,
	Vendor_City  ,
	Vendor_State  ,
	Vendor_Zip,--Code9 ,
	--ProviderAddress_MultiAddressInd  ,
	--ProviderAddress_Latitude  ,
	--ProviderAddress_Longitude  ,
	--ProviderAddress_AddressTypeDesc  ,
	Ingenix_TaxonomyCode  ,
	Ingenix_SpecialtyName  ,
	Ingenix_SpecialtyGroupName  ,
 	T.SourceDataKey
 	FROM #temp_clmprov T 
	JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 	ON rtrim(T.BILL_PROV_GRP_ID) = rtrim(EP.ProviderID)  
 	AND T.SOURCEDATAKEY = EP.SOURCEDATAKEY 
 	where RecordSource = 'V'
 	
 	--update NPI FROM EDPS_Data.dbo.EDS_ProviderDim For those providers where the vendornpi on the claim was unknown
 	-- Update VendorNPI from EDS_Provider.Vendor_NationalProviderID
 
 	update  #TMP_EDSPROV_BILLGRP
 	set vendor_npi = ISNULL(EP.Vendor_NationalProviderID,' ')
 	from #TMP_EDSPROV_BILLGRP BG
 		,EDPS_Data.dbo.EDS_ProviderDim EP
 	WHERE BG.VendorID = EP.Vendor_VendorID
 		AND BG.SourceDataKey = EP.SourceDataKey
 		AND BG.VendorID = EP.ProviderID 
 		AND LEN(ISNULL(BG.vendor_npi,' '))  < 10  
 		and EP.RecordSource = 'V'
 		
 		
 	--update billing group zip4, use default of '9998' when zip4 is blank
 	update #TMP_EDSPROV_BILLGRP
 	set Vendor_ZipCode9 = substring(vendor_zipcode9,1,5) + '' + '9998'
 	where (len(substring(vendor_zipcode9,1,5)) = 5 and  LEN(vendor_zipcode9) <> 9)
 	-- --update NPI FROM EDPS_Data.dbo.EDS_ProviderDim For those providers where the vendornpi on the claim was unknown
 	---- Update VendorNPI from EDS_Provider.isnull(NPID,' ')	
 	
 	-- 	update  #TMP_EDSPROV_BILLGRP
 	--set vendor_npi = ISNULL(EP.Vendor_NationalProviderID,' ')
 	--from #TMP_EDSPROV_BILLGRP BG
 	--	,EDPS_Data.dbo.EDS_ProviderDim EP
 	--WHERE BG.ProviderID = EP.ProviderID
 	--	AND BG.SourceDataKey = EP.SourceDataKey
 	--	AND EP.ProviderID = EP.Vendor_VendorID
 	--	AND LEN(ISNULL(BG.vendor_npi,' '))  <> 10  
 	--	and EP.RecordSource = 'P'	
 	
 	
 	IF OBJECT_ID('TEMPDB..#TMP_EDSPROV') <> 0
	DROP TABLE #TMP_EDSPROV
		
 	CREATE TABLE #TMP_EDSPROV
 	(
 	[RecordSource] [CHAR] (1),
 	[ProviderID] [VARCHAR](20) ,
	[ProviderTypeCode] [varchar](15) ,
	[ProviderStatus] [varchar](10) ,
	[GlobalCurrentPatientLoad] [varchar](5) ,
	[AdditionalBusinessName] [varchar](35) ,
	[PrimaryBusinessName] [varchar](90) ,
	[FullName] [varchar](95) ,
	[ReverseFullName] [varchar](95) ,
	[LastName] [varchar](60) ,
	[FirstName] [varchar](40) ,
	[MiddleName] [varchar](30) ,
	[Title] [varchar](15) ,
	[GlobalPanelSize] [varchar](5) ,
	[NewPatientFlag] [char](1) ,
	[DeaNumber] [varchar](10) ,
	[Gender] [char](1) ,
	[DOBDateKey] [int] ,
	[UPIN] [varchar](20) ,
	[FIDN] [varchar](25) ,
	[NPID] [varchar](10) ,
	[MedicaidID] [varchar](20) ,
	[MedicareID] [varchar](20) ,
	[HandicapAccess] [varchar](1) ,
	[CredentialingStatus] [varchar](15) ,
	[ProvCategory] [varchar](15) ,
	[LicenseTypeCode] [char](1) ,
	[LeasedStatusCode] [char](1) ,
	[PreferredStatusCode] [char](1) ,
	[ChildFlg] [char](1) ,
	[YouthFlg] [char](1) ,
	[AdultFlg] [char](1) ,
	[StandardHoursInd] [char](1) ,
	[AfterHoursInd] [char](1) ,
	[WeekendHoursInd] [char](1) ,
	--[SourceDataKey] [int] ,
	[ProviderType_ProviderTypeDesc] [varchar](60) ,
	--Global Provider vendor revisions
	[VendorID] [varchar](20) ,
	[VendorTypeCode] [varchar](15),
	[Vendor_NPI] [varchar] (10),	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	[Vendor_Phone] [varchar](20) ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	[Vendor_AddressLine1] [varchar](60) ,
	[Vendor_AddressLine2] [varchar](60) ,
	[Vendor_City] [varchar](30) ,
	[Vendor_State] [char](2) ,
	[Vendor_ZipCode9] [varchar] (11),--(9) ,
	--[ProviderAddress_MultiAddressInd] [int] ,
	--[ProviderAddress_Latitude] [decimal](9, 6) ,
	--[ProviderAddress_Longitude] [decimal](9, 6) ,
	--[ProviderAddress_AddressTypeDesc] [varchar](20) ,
	[Ingenix_TaxonomyCode] [varchar](10) ,
	[Ingenix_SpecialtyName] [varchar](60) ,
	[Ingenix_SpecialtyGroupName] [varchar](60) ,
 	SourceDataKey INT
 	)
	--BUILD BILL_PROV_ID
	
	INSERT INTO #TMP_EDSPROV
	SELECT DISTINCT 
	RecordSource,
	T.BILL_PROV_ID  ,
	ProviderTypeCode  ,
	ProviderStatus  ,
	GlobalCurrentPatientLoad  ,
	AdditionalBusinessName  ,
	PrimaryBusinessName  ,
	FullName  ,
	ReverseFullName  ,
	LastName  ,
	FirstName  ,
	MiddleName  ,
	case Title when 'UNKNOWN' then ' ' else Title end,
	GlobalPanelSize  ,
	NewPatientFlag  ,
	DeaNumber  ,
	Gender  ,
	DOBDateKey  ,
	UPIN  ,
	FIDN  ,
	--isnull(NPID,' ')  ,
	case T.BILL_PROV_NPI when 'N/A' then ' ' else T.BILL_PROV_NPI end,
	MedicaidID  ,
	MedicareID  ,
	HandicapAccess  ,
	CredentialingStatus  ,
	ProvCategory  ,
	LicenseTypeCode  ,
	LeasedStatusCode  ,
	PreferredStatusCode  ,
	ChildFlg  ,
	YouthFlg  ,
	AdultFlg  ,
	StandardHoursInd  ,
	AfterHoursInd  ,
	WeekendHoursInd  ,
	--SourceDataKey  ,
	ProviderType_ProviderTypeDesc  ,
	t.BILL_PROV_GRP_ID  , --Vendor_VendorID ,
	Vendor_VendorTypeCode ,
	case t.BILL_PROV_GRP_NPI when 'N/A' then ' ' else ISNULL(t.BILL_PROV_GRP_NPI,' ') end , --Vendor_NPIID ,
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	Vendor_Phone ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	' ',--ProviderAddress_AddressLine1  ,
	' ',--ProviderAddress_AddressLine2  ,
	' ',--ProviderAddress_City  ,
	' ',--ProviderAddress_State  ,
	' ',--ProviderAddress_ZipCode9 ,
	--ProviderAddress_MultiAddressInd  ,
	--ProviderAddress_Latitude  ,
	--ProviderAddress_Longitude  ,
	--ProviderAddress_AddressTypeDesc  ,
	Ingenix_TaxonomyCode  ,
	Ingenix_SpecialtyName  ,
	Ingenix_SpecialtyGroupName  ,
 	T.SourceDataKey
 	
 	FROM #temp_clmprov T
 	JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 	ON EP.ProviderID = T.BILL_PROV_ID
 	AND EP.SOURCEDATAKEY = T.SOURCEDATAKEY
 	WHERE EP.RecordSource = 'P'
 		AND  EP.ProviderID NOT IN (SELECT ProviderID FROM #TMP_EDSPROV)
 	
 	
	--BUILD REF_PROV_ID
	
	INSERT INTO #TMP_EDSPROV
	SELECT distinct
	 RecordSource,
	ProviderID  ,
	ProviderTypeCode  ,
	ProviderStatus  ,
	GlobalCurrentPatientLoad  ,
	AdditionalBusinessName  ,
	PrimaryBusinessName  ,
	FullName  ,
	ReverseFullName  ,
	LastName  ,
	FirstName  ,
	MiddleName  ,
	case Title when 'UNKNOWN' then ' ' else Title end,
	GlobalPanelSize  ,
	NewPatientFlag  ,
	DeaNumber  ,
	Gender  ,
	DOBDateKey  ,
	UPIN  ,
	FIDN  ,
	isnull(NPID,' ')  ,
	MedicaidID  ,
	MedicareID  ,
	HandicapAccess  ,
	CredentialingStatus  ,
	ProvCategory  ,
	LicenseTypeCode  ,
	LeasedStatusCode  ,
	PreferredStatusCode  ,
	ChildFlg  ,
	YouthFlg  ,
	AdultFlg  ,
	StandardHoursInd  ,
	AfterHoursInd  ,
	WeekendHoursInd  ,
	--SourceDataKey  ,
	ProviderType_ProviderTypeDesc  ,
	Vendor_VendorID ,
	Vendor_VendorTypeCode ,
	Vendor_NationalProviderID,
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	Vendor_Phone ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	Vendor_AddressLine1  ,
	Vendor_AddressLine2  ,
	Vendor_City  ,
	Vendor_State  ,
	Vendor_Zip,--Code9 ,
	--ProviderAddress_MultiAddressInd  ,
	--ProviderAddress_Latitude  ,
	--ProviderAddress_Longitude  ,
	--ProviderAddress_AddressTypeDesc  ,
	Ingenix_TaxonomyCode  ,
	Ingenix_SpecialtyName  ,
	Ingenix_SpecialtyGroupName  ,
 	T.SourceDataKey 
 	
 	FROM #temp_clmprov T
 	JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 	ON EP.ProviderID = T.REF_PROV_ID
 	AND EP.SOURCEDATAKEY = T.SOURCEDATAKEY		
 	WHERE EP.RecordSource = 'P'
 		AND  EP.ProviderID NOT IN (SELECT ProviderID FROM #TMP_EDSPROV)
 		
 	
				
	----REF_PCP_PROV_ID
	
	
	--INSERT INTO #TMP_EDSPROV
	--SELECT distinct
	--RecordSource,
	--ProviderID  ,
	--ProviderTypeCode  ,
	--ProviderStatus  ,
	--GlobalCurrentPatientLoad  ,
	--AdditionalBusinessName  ,
	--PrimaryBusinessName  ,
	--FullName  ,
	--ReverseFullName  ,
	--LastName  ,
	--FirstName  ,
	--MiddleName  ,
	--case Title when 'UNKNOWN' then ' ' else Title end,
	--GlobalPanelSize  ,
	--NewPatientFlag  ,
	--DeaNumber  ,
	--Gender  ,
	--DOBDateKey  ,
	--UPIN  ,
	--FIDN  ,
	--isnull(NPID,' ')  ,
	--MedicaidID  ,
	--MedicareID  ,
	--HandicapAccess  ,
	--CredentialingStatus  ,
	--ProvCategory  ,
	--LicenseTypeCode  ,
	--LeasedStatusCode  ,
	--PreferredStatusCode  ,
	--ChildFlg  ,
	--YouthFlg  ,
	--AdultFlg  ,
	--StandardHoursInd  ,
	--AfterHoursInd  ,
	--WeekendHoursInd  ,
	----SourceDataKey  ,
	--ProviderType_ProviderTypeDesc  ,
	--Vendor_VendorID ,
	--Vendor_VendorTypeCode ,
	--Vendor_NationalProviderID,
	----[ProviderGroup_BeginCoverageDateKey] [int] ,
	----[ProviderGroup_EndCoverageDateKey] [int] ,
	----[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	----[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	--Vendor_Phone ,
	----[ProviderPhone_FaxNumber] [varchar](20) ,
	----[ProviderPhone_MultiPhoneInd] [int] ,
	----[ProviderAddress_AddressTypeCode] [varchar](2) ,
	--Vendor_AddressLine1  ,
	--Vendor_AddressLine2  ,
	--Vendor_City  ,
	--Vendor_State  ,
	--Vendor_Zip,--Code9 ,
	----ProviderAddress_MultiAddressInd  ,
	----ProviderAddress_Latitude  ,
	----ProviderAddress_Longitude  ,
	----ProviderAddress_AddressTypeDesc  ,
	--Ingenix_TaxonomyCode  ,
	--Ingenix_SpecialtyName  ,
	--Ingenix_SpecialtyGroupName  ,
 --	T.SourceDataKey 
 	
 --	FROM #temp_clmprov T
 --	JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 --	ON EP.ProviderID = T.REF_PCP_PROV_ID
 --	AND EP.SOURCEDATAKEY = T.SOURCEDATAKEY
	--WHERE EP.RecordSource = 'P'
 --		AND  EP.ProviderID NOT IN (SELECT ProviderID FROM #TMP_EDSPROV)
					
			
	--ATTN_PROV_ID
	
		
	INSERT INTO #TMP_EDSPROV
	SELECT distinct
	RecordSource,
	ProviderID  ,
	ProviderTypeCode  ,
	ProviderStatus  ,
	GlobalCurrentPatientLoad  ,
	AdditionalBusinessName  ,
	PrimaryBusinessName  ,
	FullName  ,
	ReverseFullName  ,
	LastName  ,
	FirstName  ,
	MiddleName  ,
	case Title when 'UNKNOWN' then ' ' else Title end,
	GlobalPanelSize  ,
	NewPatientFlag  ,
	DeaNumber  ,
	Gender  ,
	DOBDateKey  ,
	UPIN  ,
	FIDN  ,
	isnull(NPID,' ')  ,
	MedicaidID  ,
	MedicareID  ,
	HandicapAccess  ,
	CredentialingStatus  ,
	ProvCategory  ,
	LicenseTypeCode  ,
	LeasedStatusCode  ,
	PreferredStatusCode  ,
	ChildFlg  ,
	YouthFlg  ,
	AdultFlg  ,
	StandardHoursInd  ,
	AfterHoursInd  ,
	WeekendHoursInd  ,
	--SourceDataKey  ,
	ProviderType_ProviderTypeDesc  ,
	Vendor_VendorID ,
	Vendor_VendorTypeCode ,
	Vendor_NationalProviderID,
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	Vendor_Phone ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	Vendor_AddressLine1  ,
	Vendor_AddressLine2  ,
	Vendor_City  ,
	Vendor_State  ,
	Vendor_Zip,--Code9 ,
	--ProviderAddress_MultiAddressInd  ,
	--ProviderAddress_Latitude  ,
	--ProviderAddress_Longitude  ,
	--ProviderAddress_AddressTypeDesc  ,
	Ingenix_TaxonomyCode  ,
	Ingenix_SpecialtyName  ,
	Ingenix_SpecialtyGroupName  ,
 	T.SourceDataKey 
 	
 	FROM #temp_clmprov T
 	JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 	ON EP.ProviderID = T.ATTN_PROV_ID
 	AND EP.SOURCEDATAKEY = T.SOURCEDATAKEY
 	WHERE EP.RecordSource = 'P'
 		AND  EP.ProviderID NOT IN (SELECT ProviderID FROM #TMP_EDSPROV)
 		
 	 	 	
 	--update NPI FROM EDPS_Data.dbo.EDS_ProviderDim For those providers where the providernpi on the claim was unknown
 	---- Update isnull(NPID,' ') from EDS_Provider.isnull(NPID,' '), EDS_Provider.RecordSource = P (Providerdim Source)
 	update #TMP_EDSPROV
 	set NPID = isnull(ep.NPID,' ')
 	from #TMP_EDSPROV BP
 		,EDPS_Data.dbo.EDS_ProviderDim EP
 	WHERE BP.ProviderID = EP.ProviderID
 		AND LEN(BP.NPID)  = 0
 		AND EP.RecordSource = 'P'
 		
 	--update NPI FROM EDPS_Data.dbo.EDS_ProviderDim For those providers where the providernpi on the claim was unknown
 	---- Update isnull(NPID,' ') from EDS_Provider.Vendor_NationalProviderid, EDS_Provider.RecordSource = P (Providerdim Source)
 	--EDPS_Data.dbo.EDS_ProviderDim Solo Groups (Xray, clinics, Hospitals)
 	
 	update #TMP_EDSPROV
 	set NPID = ep.Vendor_NationalProviderID
 	from #TMP_EDSPROV BP
 		,EDPS_Data.dbo.EDS_ProviderDim EP
 	WHERE BP.ProviderID = EP.ProviderID
 		and BP.ProviderID = EP.Vendor_VendorID
 		AND LEN(BP.NPID)  = 0
 		AND EP.RecordSource = 'P'
 		
 		
 		
	--UPDATE BILL_PROV & PAY_TO ADDRESS INFO
	--USING PROVIDERDIM AND CLAIMDETAILDIM.PROVIDERID (OUTB_INST_HEADER.BILL_PROV_ID)
	
		--BILLING PROVIDER EDS_PROVIDERADDRESSDIM UPDATES-08/16/13
 	
		UPDATE  #TMP_EDSPROV 
      SET Vendor_AddressLine1 = EP.Vendor_AddressLine1
			,Vendor_AddressLine2 = EP.Vendor_AddressLine2
			,Vendor_City = EP.Vendor_City
			,Vendor_State = EP.Vendor_State
			,Vendor_ZipCode9  = EP.Vendor_ZIP
	 FROM EDPS_Data.dbo.EDS_ProviderDim EP
	 JOIN #TMP_EDSPROV T
	 ON EP.ProviderID = T.ProviderID
	 AND EP.RecordSource = T.RecordSource
	 WHERE EP.RecordSource = 'V'
		AND T.RecordSource = 'V'
		                           
	
      UPDATE  #TMP_EDSPROV 
      SET Vendor_AddressLine1 = EP.AddressLine1
			,Vendor_AddressLine2 = EP.AddressLine2
			,Vendor_City = EP.City
			,Vendor_State = EP.State
			,Vendor_ZipCode9  = EP.ZipCode9
	 FROM EDS_ProviderAddressDim EP
	 JOIN #TMP_EDSPROV T
	 ON EP.ProviderID = T.ProviderID
	 WHERE EP.AddressTypeCode = 'PB'
		AND T.RecordSource = 'P'
			
	--update billing group zip4, use default of '9998' when zip4 is blank
 	update #TMP_EDSPROV
 	set Vendor_ZipCode9 = SUBSTRING(vendor_zipcode9,1,5) + '' + '9998'
 	where (len(substring(vendor_zipcode9,1,5)) = 5 and  LEN(vendor_zipcode9) <> 9)	
 				
	--OUTB_INST_HEADER UPDATES
				
	--UPDATE BILLING PROVIDER GROUP & CPO_NPI
	--USE THE VENDORID FROM CLAIMDETAILDIM AS THE BILL_PROV_GRP_ID TO APPLY UPDATES

-- TETDM-611	Scott Waller FULLNAME is varchar(95) and BILL_PROV_ORG_NAME is varchar(60)	
			UPDATE OUTB_INST_HEADER
			SET BILL_PROV_ORG_NAME = SUBSTRING(T.FULLNAME, 1, 60)
				,BILL_PROV_GRP_NPI = isnull(T.Vendor_NPI,' ')
				--,CPO_NPI = isnull(T.NPID,' ')
			FROM OUTB_INST_HEADER EHP
			JOIN  #TMP_EDSPROV_BILLGRP T
			ON EHP.BILL_PROV_GRP_ID = T.ProviderID
					AND EHP.SOURCEDATAKEY = T.SourceDataKey
					AND LEN(BILL_PROV_GRP_NPI) <> 10
					
				
			--UPDATE Billing Group Address
			UPDATE OUTB_INST_HEADER
			SET  BILL_PROV_ADDR1 =  substring(isnull(T.Vendor_AddressLine1,' '),1,55)
				,BILL_PROV_ADDR2 =  substring(isnull(T.Vendor_AddressLine2,' '),1,55)
				,BILL_PROV_CITY =  substring(isnull(T.Vendor_City,' '),1,30)
				,BILL_PROV_STATE =  substring(isnull(T.Vendor_State,' '),1,2)
				,BILL_PROV_ZIP =  substring(isnull(substring(T.Vendor_ZipCode9,1,5),' '),1,5)
				,BILL_PROV_ZIP4 =  substring(isnull(substring(T.Vendor_ZipCode9,6,4),' '),1,4)
			FROM OUTB_INST_HEADER EHP
			JOIN  #TMP_EDSPROV_BILLGRP T
			ON EHP.BILL_PROV_GRP_ID = T.ProviderID
			AND EHP.SOURCEDATAKEY = T.SourceDataKey		
					
			
			--UPDATE Billing Group Address using vendor record 
			UPDATE EXT_HRP_CLAIM
			SET  BILL_PROV_ADDR1 =  substring(isnull(T.Vendor_AddressLine1,' '),1,55)
				,BILL_PROV_ADDR2 =  substring(isnull(T.Vendor_AddressLine2,' '),1,55)
				,BILL_PROV_CITY =  substring(isnull(T.Vendor_City,' '),1,30)
				,BILL_PROV_STATE =  substring(isnull(T.Vendor_State,' '),1,2)
				,BILL_PROV_ZIP =  substring(isnull(substring(T.Vendor_ZipCode9,1,5),' '),1,5)
				,BILL_PROV_ZIP4 =  substring(isnull(substring(T.Vendor_ZipCode9,6,4),' '),1,4)
			FROM EXT_HRP_CLAIM EHP
			JOIN  #TMP_EDSPROV_BILLGRP T
			ON EHP.BILL_PROV_GRP_ID = T.ProviderID
			AND EHP.SOURCEDATAKEY = T.SourceDataKey	
			WHERE T.RecordSource = 'V'	
			
			
			--UPDATE Billing Group Address from Billing Group P record when vendor record not updated
			UPDATE EXT_HRP_CLAIM
			SET  BILL_PROV_ADDR1 =  substring(isnull(T.Vendor_AddressLine1,' '),1,55)
				,BILL_PROV_ADDR2 =  substring(isnull(T.Vendor_AddressLine2,' '),1,55)
				,BILL_PROV_CITY =  substring(isnull(T.Vendor_City,' '),1,30)
				,BILL_PROV_STATE =  substring(isnull(T.Vendor_State,' '),1,2)
				,BILL_PROV_ZIP =  substring(isnull(substring(T.Vendor_ZipCode9,1,5),' '),1,5)
				,BILL_PROV_ZIP4 =  substring(isnull(substring(T.Vendor_ZipCode9,6,4),' '),1,4)
			FROM EXT_HRP_CLAIM EHP
			JOIN  #TMP_EDSPROV_BILLGRP T
			ON EHP.BILL_PROV_GRP_ID = T.ProviderID
			AND EHP.SOURCEDATAKEY = T.SourceDataKey	
			WHERE T.RecordSource = 'P'	
				AND LEN(isnull(T.Vendor_AddressLine1,' ')) = 0		
			--5/9 - remove payto due to discussion during onsite visit
			--payto not needed due to the way claims are submitted		
			--UPDATE PAYTO INFO WHEN BILLING GROUP IS PAYTO	
			--	UPDATE OUTB_INST_HEADER
			--SET  PAYTO_ADDR1 =  substring(isnull(T.Vendor_AddressLine1,' '),1,55)
			--	,PAYTO_ADDR2 =  substring(isnull(T.Vendor_AddressLine2,' '),1,55)
			--	,PAYTO_CITY =  substring(isnull(T.Vendor_City,' '),1,30)
			--	,PAYTO_STATE =  substring(isnull(T.Vendor_State,' '),1,2)
			--	,PAYTO_ZIP =  substring(isnull(substring(T.Vendor_ZipCode9,1,5),' '),1,5)
			--	,PAYTO_ZIP4 =  substring(isnull(substring(T.Vendor_ZipCode9,6,4),' '),1,4)
			--FROM OUTB_INST_HEADER EHP
			--JOIN  #TMP_EDSPROV_BILLGRP T
			--ON EHP.BILL_PROV_GRP_ID = T.ProviderID--T.ProviderGroup_ProviderGroupID
			----AND EHP.CLAIM_ID = T.CLAIM_ID
			--AND EHP.SOURCEDATAKEY = T.SourceDataKey
			----where EHP.BILL_PROV_GRP_ID IS NOT NULL
			
			
			----3/12/13 UPDATE PAYTO USING BILL_PROV_GRP_NPI
			--removed 04/03/13 all BILL_PROV_GRP_ID will reside in EDPS_Data.dbo.EDS_ProviderDim no need to do NPI hit
			--		UPDATE OUTB_INST_HEADER
			--SET  PAYTO_ADDR1 =  substring(isnull(T.Vendor_AddressLine1,' '),1,55)
			--	,PAYTO_ADDR2 =  substring(isnull(T.Vendor_AddressLine2,' '),1,55)
			--	,PAYTO_CITY =  substring(isnull(T.Vendor_City,' '),1,30)
			--	,PAYTO_STATE =  substring(isnull(T.Vendor_State,' '),1,2)
			--	,PAYTO_ZIP =  substring(isnull(substring(T.Vendor_ZipCode9,1,5),' '),1,5)
			--	,PAYTO_ZIP4 =  substring(isnull(substring(T.Vendor_ZipCode9,6,4),' '),1,4)
			--FROM OUTB_INST_HEADER EHP
			--JOIN  #TMP_EDSPROV_BILLGRP T
			--ON EHP.BILL_PROV_GRP_NPI = T.Vendor_NPI--T.ProviderGroup_ProviderGroupNPI
			----AND EHP.CLAIM_ID = T.CLAIM_ID
			--AND EHP.SOURCEDATAKEY = T.SourceDataKey
		
		
	
			update OUTB_INST_HEADER
			set  BILL_PROV_LNAME = substring(isnull(TP.LastName,' '),1,60)
				,BILL_PROV_FNAME = substring(isnull(TP.FirstName,' '),1,35)
				,BILL_PROV_MID_INIT = substring(isnull(TP.MiddleName,' '),1,25)
				,BILL_PROV_SFX = substring(isnull(TP.Title,' '),1,10)
				,BILL_PROV_ADDR1 = substring(isnull(TP.Vendor_AddressLine1,' '),1,55)
				,BILL_PROV_ADDR2 =  CASE substring(isnull(TP.Vendor_AddressLine2,' '),1,55)
										WHEN 'UNKNOWN' THEN ' ' ELSE substring(isnull(TP.Vendor_AddressLine2,' '),1,55)
										END
				,BILL_PROV_CITY = substring(isnull(TP.Vendor_City,' '),1,30)
				,BILL_PROV_STATE = substring(isnull(TP.Vendor_State,' '),1,2)
				,BILL_PROV_ZIP =  substring(isnull(substring(TP.Vendor_ZipCode9,1,5),' ') ,1,5)
				,BILL_PROV_ZIP4 = substring(isnull(substring(TP.Vendor_ZipCode9,6,4) ,' ') ,1,4)
				,BILL_PROV_TAXONOMY_CD = substring(isnull(TP.Ingenix_TaxonomyCode,' '),1,10)
				,BILL_PROV_TAX_ID = substring(isnull(TP.FIDN,' '),1,11)
				--,BILL_PROV_SSN = TP.
				,BILL_PROV_UPIN = substring(isnull(TP.UPIN,' '),1,50)
				--,BILL_PROV_LICENSE_NO = TP.
			FROM dbo.OUTB_INST_HEADER EC
				JOIN #TMP_EDSPROV TP
			ON EC.BILL_PROV_ID = TP.ProviderID
			--AND EC.CLAIM_ID = TP.CLAIM_ID 
			AND EC.SOURCEDATAKEY = TP.SourceDataKey	
			
	 ---UPDATE BILL_PROV_NPI FOR THOSE WITH INVALID ('0000000000' OR 'UNKNOWN') CLAIMDETAILDIM.PROVIDERNPI
	 	
			update OUTB_INST_HEADER
			set	BILL_PROV_NPI = isnull(TP.NPID,' ')
			FROM dbo.OUTB_INST_HEADER EC
				JOIN #TMP_EDSPROV TP
			ON EC.BILL_PROV_ID = TP.ProviderID
			--AND EC.CLAIM_ID = TP.CLAIM_ID 
			AND EC.SOURCEDATAKEY = TP.SourceDataKey	
			WHERE LEN(BILL_PROV_NPI) = 0
					
			--UPDATE PAYTO INFO WHEN BILLING GROUP IS PAYTO	
			--IS THIS NEEDED? IS BILL_PROV_GRP_ID ALWAYS POPULATED ON THE CLAIM
			--ADDITIONAL RESEARCH REQUIRED
			/*	UPDATE OUTB_INST_HEADER
			SET  PAYTO_ADDR1 = T.Vendor_AddressLine1
				,PAYTO_ADDR2 = T.Vendor_AddressLine1
				,PAYTO_CITY = T.Vendor_City
				,PAYTO_STATE = T.Vendor_State
				,PAYTO_ZIP = substring(T.Vendor_Zip,1,5)
				,PAYTO_ZIP4 = substring(T.Vendor_Zip,6,4)
			FROM OUTB_INST_HEADER EHP
			JOIN  #TMP_EDSPROV_BILLGRP T
			ON EHP.BILL_PROV_ID = T.ProviderID--T.ProviderGroup_ProviderGroupID
			AND EHP.CLAIM_ID = T.CLAIM_ID
			AND EHP.SOURCEDATAKEY = T.SourceDataKey
			where EHP.BILL_PROV_GRP_ID IS NULL
				AND EHP.BILL_PROV_ID IS NOT NULL*/
			
			--REF_PROV UPDATES
			update OUTB_INST_HEADER
			set  REF_PROV_LNAME = isnull(TP.LastName,' ')
				,REF_PROV_FNAME = isnull(TP.FirstName,' ')
				,REF_PROV_MID_INIT = isnull(TP.MiddleName,' ')
				,REF_PROV_SFX = isnull(TP.Title,' ')
				--,REF_PROV_TAXONOMY_CD = isnull(TP.Ingenix_TaxonomyCode,' ')
				,REF_PROV_UPIN = isnull(TP.UPIN,' ')
				,REF_PROV_NPI = isnull(TP.NPID,' ')
				--,REF_PROV_LICENSE_NO = ----No data element in eds_provdierdim
			FROM dbo.OUTB_INST_HEADER EC
				JOIN #TMP_EDSPROV TP
			ON EC.REF_PROV_ID = TP.ProviderID
			--AND EC.CLAIM_ID = TP.CLAIM_ID 
			AND EC.SOURCEDATAKEY = TP.SourceDataKey			
				
			----REF_PCP UPDATES
			--update OUTB_INST_HEADER
			--set  REF_PCP_LNAME = isnull(TP.LastName,' ')
			--	,REF_PCP_FNAME = isnull(TP.FirstName,' ')
			--	,REF_PCP_MID_INIT = isnull(TP.MiddleName,' ')
			--	,REF_PCP_SFX = isnull(TP.Title,' ')
			--	--,REF_PCP_TAXONOMY_CD = isnull(TP.Ingenix_TaxonomyCode,' ')
			--	,REF_PCP_PROV_UPIN = isnull(TP.UPIN,' ')
			--	,REF_PCP_PROV_NPI = isnull(TP.NPID,' ')
			--FROM dbo.OUTB_INST_HEADER EC
			--	JOIN #TMP_EDSPROV TP
			--ON EC.REF_PCP_PROV_ID = TP.ProviderID
			----AND EC.CLAIM_ID = TP.CLAIM_ID 
			--AND EC.SOURCEDATAKEY = TP.SourceDataKey				
				
				
				
			--ATTN_PROV UPDATES
			update OUTB_INST_HEADER
			set  ATTN_PROV_LNAME = isnull(TP.LastName,' ')
				,ATTN_PROV_FNAME = isnull(TP.FirstName,' ')
				,ATTN_PROV_MIDINIT = isnull(TP.MiddleName,' ')
				,ATTN_PROV_SFX = isnull(TP.Title,' ')
				,ATTN_PROV_TAXONOMY_CD = isnull(TP.Ingenix_TaxonomyCode,' ')
				--,BILL_PROV_SSN = TP.
				,ATTN_PROV_UPIN = isnull(TP.UPIN,' ')
				,ATTN_PROV_NPI = isnull(TP.NPID,' ')
			FROM dbo.OUTB_INST_HEADER EC
				JOIN #TMP_EDSPROV TP
			ON EC.ATTN_PROV_ID = TP.ProviderID
			--AND EC.CLAIM_ID = TP.CLAIM_ID 
			AND EC.SOURCEDATAKEY = TP.SourceDataKey	
			
			--provider taxonomy code exclusion
			--temporary logic to omit submisson of taxonomy code
			Update OUTB_INST_HEADER 
			SET ATTN_PROV_TAXONOMY_CD = ' '
				,BILL_PROV_TAXONOMY_CD = ' '
				--REF_PROV_TAXONOMY_CD = ' '
				--,REF_PCP_TAXONOMY_CD = ' '
				
			

			---conditional name submissions from various sources
			---update Billing Group Org. Name  
			
			update OUTB_INST_HEADER
			SET BILL_PROV_ORG_NAME = SUBSTRING(RTRIM(bill_prov_lname) +' '+ RTRIM(bill_prov_fname) + ' '+ RTRIM(BILL_PROV_MID_INIT) + ' ' + RTRIM(bill_prov_sfx),1,60)
				,bill_prov_lname = ' '
				,BILL_PROV_FNAME = ' '
				,BILL_PROV_MID_INIT = ' '
				,BILL_PROV_SFX = ' '
--				,BILL_
			where  BILL_PROV_GRP_NPI = BILL_PROV_NPI

			--update Bill Provider Name 
-- TETDM-611 Scott Waller	FULLNAME is varchar(95) and BILL_PROV_ORG_NAME is varchar(60)	
			update OUTB_INST_HEADER
			SET BILL_PROV_ORG_NAME = SUBSTRING(isnull(P.FULLNAME,' '), 1, 60)
			FROM OUTB_INST_HEADER C
				,EDPS_Data.dbo.EDS_ProviderDim P
			WHERE C.BILL_PROV_GRP_ID = P.ProviderID
				AND C.SOURCEDATAKEY = P.SourceDataKey
				AND BILL_PROV_GRP_NPI <> BILL_PROV_NPI
				
				
			---6/24/13 Note
			--
			-- Additional where clause "P.RecordSource = 'V' for BILL_PROV_GRP_NPI & BILL_PROV_ORG_NAME UPDATES
			---EDPS_Data.dbo.EDS_ProviderDim CONTAINS MULTIPLE RECORDS, NEED TO UPDATE BILLING GROUP USING VENDOR RECORD

-- TETDM-611 Scott Waller	Vendor_VendorName is varchar(100) and BILL_PROV_ORG_NAME is varchar(60)					
			update OUTB_INST_HEADER
			SET BILL_PROV_GRP_NPI = ISNULL(P.Vendor_NationalProviderID,' ')
				,BILL_PROV_ORG_NAME = SUBSTRING(P.Vendor_VendorName, 1, 60)
			FROM OUTB_INST_HEADER C
				,EDPS_Data.dbo.EDS_ProviderDim P
			WHERE c.BILL_PROV_GRP_ID = p.ProviderID
			and c.SOURCEDATAKEY = p.SourceDataKey
			AND LEN(C.BILL_PROV_GRP_ID) > 0
				AND (LEN(C.BILL_PROV_GRP_NPI) = 0 OR LEN(C.BILL_PROV_ORG_NAME) = 0)
				AND  P.RecordSource = 'V'
				
				
			update OUTB_INST_HEADER
			set BILL_PROV_ORG_NAME = ' '
			where BILL_PROV_ORG_NAME is null
				
				
			--update rendering provider info when billing group info is known AND rendering provider is an individual
			UPDATE OUTB_INST_HEADER
			SET RENDERING_PROV_LAST_NAME = RTRIM(BILL_PROV_LNAME)
				,RENDERING_PROV_FIRST_NAME = RTRIM(BILL_PROV_FNAME)
				,RENDERING_PROV_MID_INIT = RTRIM(BILL_PROV_MID_INIT)
				,RENDERING_PROV_SFX = RTRIM(BILL_PROV_SFX)
				,RENDERING_PROV_NPI = BILL_PROV_NPI
				,RENDERING_PROV_ID = BILL_PROV_ID
				,BILL_PROV_LNAME = ' '
				,BILL_PROV_FNAME = ' '
				,BILL_PROV_MID_INIT = ' '
				,BILL_PROV_SFX = ' '
				,BILL_PROV_NPI = ' '
				,BILL_PROV_ID = ' '
			WHERE LEN(BILL_PROV_GRP_ID) > 0 
					AND LEN(BILL_PROV_ID) > 0
					and LEN(bill_prov_fname) > 0
			
			--update rendering provider info when billing group info is known AND rendering provider is an individual
			UPDATE OUTB_INST_HEADER
			SET RENDERING_PROV_ORG_NAME = isnull(BILL_PROV_LNAME,' ')
				,RENDERING_PROV_NPI = BILL_PROV_NPI
				,RENDERING_PROV_GRP_ID = BILL_PROV_ID
				,BILL_PROV_LNAME = ' '
				,BILL_PROV_FNAME = ' '
				,BILL_PROV_MID_INIT = ' '
				,BILL_PROV_SFX = ' '
				,BILL_PROV_NPI = ' '
				,BILL_PROV_ID = ' '
			WHERE LEN(BILL_PROV_GRP_ID) > 0 
					AND LEN(BILL_PROV_ID) > 0
					AND BILL_PROV_GRP_NPI <> BILL_PROV_NPI
					and LEN(bill_prov_fname) = 0	
			--SUBMIT BILL_PROV_GRP INFORMATION WHEN BILL_PROV_GRP_NPI = BILL_PROV_NPI
			UPDATE OUTB_INST_HEADER
			SET BILL_PROV_ID = ' '
				,BILL_PROV_NPI = ' '
			WHERE  BILL_PROV_GRP_NPI = BILL_PROV_NPI
			
			--UPDATE RENDERING_PROV_ORG_NAME
			UPDATE OUTB_INST_HEADER
			SET RENDERING_PROV_ORG_NAME =isnull(EP.FULLNAME,' ')
			FROM OUTB_INST_HEADER C
			JOIN EDPS_Data.dbo.EDS_ProviderDim EP
			ON C.RENDERING_PROV_GRP_ID = EP.ProviderID
			
			--Update missing REF_PROV INFO FROM EDS_PROVIDER 
			--REJ_REA_ID 1,FILE_SUBTYPE_qUAL = 'DN',FIELD_ERR - 'LASTORGORG'
						
			UPDATE OUTB_INST_HEADER
			SET REF_PROV_LNAME = ISNULL(E.lastname,' ')
				,REF_PROV_FNAME = isnull(E.FirstName,' ')
				,REF_PROV_MID_INIT = ISNULL(E.MiddleName,' ')
				,REF_PROV_NPI = isnull(E.NPID,' ')
				,REF_PROV_UPIN = isnull(E.UPIN,' ')
			FROM OUTB_INST_HEADER C
				,EDPS_Data.dbo.EDS_ProviderDim E
			WHERE C.REF_PROV_ID = E.ProviderID  
				AND E.RecordSource = 'P' 
				AND (LEN(C.REF_PROV_LNAME) = 0 AND LEN(C.REF_PROV_ID) > 0)
				
				
			UPDATE OUTB_INST_HEADER
			SET REF_PROV_LNAME = ISNULL(E.Vendor_VendorName,' ')
				,REF_PROV_FNAME = isnull(E.Vendor_FirstName,' ')
				,REF_PROV_NPI = isnull(E.Vendor_NationalProviderID,' ')
				,REF_PROV_UPIN = isnull(E.UPIN,' ')
			FROM OUTB_INST_HEADER C
				,EDPS_Data.dbo.EDS_ProviderDim E
			WHERE C.REF_PROV_ID = E.ProviderID   
				AND( LEN(C.REF_PROV_LNAME) = 0 AND LEN(C.REF_PROV_ID) > 0)  
				and e.NPID is null                                    
						
			---REF_PROV UPDATES WHEN REF_PROV_ID IS KNOWN AND NO HIT FOUND ON EDS_PROVIDER
			---NO HIT NORMALLY DUE TO USE OF REF_PROV NPID ON CLAIM INSTEAD OF REF_PROV_ID
			---IMPLEMENTED TO SUPPORT FACETS REF_PROV REJECT ISSUES 06/25/13						
							
			update OUTB_INST_HEADER
			SET REF_PROV_LNAME = ISNULL(P.LastName,' ')
				,REF_PROV_FNAME = ISNULL(P.FirstName,' ')
				,REF_PROV_NPI = P.NPID
			FROM OUTB_INST_HEADER C
				,EDPS_Data.dbo.EDS_ProviderDim P
			WHERE C.REF_PROV_ID = P.NPID
				AND C.SOURCEDATAKEY = P.SourceDataKey
				AND LEN(REF_PROV_ID) > 0
				AND LEN(REF_PROV_NPI) = 0
				AND LEN(REF_PROV_LNAME) = 0	
					
		
	--Update Billing Provider TIN on outbound claim 
					
			UPDATE OUTB_INST_HEADER
			SET BILL_PROV_TAX_ID = isnull(BG.FIDN,' ')
			FROM #TMP_EDSPROV_BILLGRP BG
			JOIN OUTB_INST_HEADER 	C
			ON BG.ProviderID = C.BILL_PROV_GRP_ID 
			WHERE LEN(C.BILL_PROV_TAX_ID) = 0
				AND LEN(BILL_PROV_GRP_ID) > 0 
				AND BG.RecordSource = 'V'
						

	--2/9/16 TETDM-632 Billing Provider Group Address Info Update - Update when Group Address is blank
			
			 UPDATE  OUTB_INST_HEADER 
				  SET BILL_PROV_ADDR1 = EP.AddressLine1
						,BILL_PROV_ADDR2 = EP.AddressLine2
						,BILL_PROV_CITY = EP.City
						,BILL_PROV_STATE = EP.State
						,BILL_PROV_ZIP  = SUBSTRING(EP.ZipCode9,1,5)
						,BILL_PROV_ZIP4 = SUBSTRING(EP.ZipCode9,6,4)
				 FROM edps_data.dbo.EDS_ProviderAddressDim EP
				 JOIN  OUTB_INST_HEADER T
				 ON EP.ProviderID = T.BILL_PROV_GRP_ID
				 WHERE EP.AddressTypeCode = 'PB'
				 and len(bill_prov_addr1) = 0

    --TETDM-1678 UPDATE BILLING PROVIDER INFORMATION IF IT EXITS IN THE HISTORICAL CLAIM TABLE
	  IF OBJECT_ID('TEMPDB..#TMPBILLING_CLMPROV') <> 0
		 DROP TABLE #TMPBILLING_CLMPROV
		
	  SELECT A.CLAIM_ID,
	         B.BillProvID,
             B.BillProvNPI,
		     B.BillProvTaxID,
		     B.BillProvFirst,
		     B.BillProvLast,
			 B.BillProvSuffix,
			 B.BillProvMiddle,
		     B.BillProvAddress,
		     B.BillProvAddress2,
		     B.BillProvCity,
		     B.BillProvState,
		     B.BillProvZip,
			 B.BillProvUPINLicense,
			 B.BillProvTaxonomy,
			 CASE 
			   WHEN LTRIM(RTRIM(A.BILL_PROV_GRP_NPI)) ='' THEN B.BillProvNPI 
			   WHEN LTRIM(RTRIM(UPPER(A.BILL_PROV_GRP_NPI))) = 'UNKNOWN' THEN b.BillProvNPI
			   ELSE A.BILL_PROV_GRP_NPI
			  END AS BILLPROV_GRP_NPI,
			 CASE 
			   WHEN LTRIM(RTRIM(A.BILL_PROV_GRP_ID)) ='' THEN B.BillProvNPI 
			 END AS BILL_PROV_GRP_ID
	  INTO  #TMPBILLING_CLMPROV
      FROM EDPS_Data.DBO.HistoricalClaim B 
      JOIN OUTB_INST_HEADER A
       ON B.InternalAppClaimID = A.Claim_ID
	   AND LEN(B.BILLPROVNPI) > 0
	 --  AND LEN(B.BillProvTaxonomy) > 0
	 --AND B.InternalAppClaimID = '15139E052897'
	 -- --------------------------------------------------
	 -- -- UPDATE BILLING PROVIDER INFO FROM HISTORY TABLE
	 -- ---------------------------------------------------
	  update OUTB_INST_HEADER
	  SET  BILL_PROV_LNAME = substring(isnull(T.BillProvLast,' '),1,60)
			-- TETDM-2278 if T.BillProvLast has a value, that value will be put into BILL_PROV_LNAME
			-- if that happens, we have to blank out any value that is in BILL_PROV_ORG_NAME
		   ,BILL_PROV_ORG_NAME = (CASE 
									WHEN substring(isnull(T.BillProvLast,' '),1,60) <> ' '
										THEN ' '
									ELSE 
										BILL_PROV_ORG_NAME
									END)
			-- end TETDM-2278
		   ,BILL_PROV_FNAME = substring(isnull(T.BillProvFirst,' '),1,35)
		   ,BILL_PROV_MID_INIT = substring(isnull(T.BillProvMiddle,' '),1,25)
		   ,BILL_PROV_SFX =  substring(isnull(T.BillProvSuffix,' '),1,10)
		   ,BILL_PROV_ADDR1 = substring(isnull(T.BillProvAddress,' '),1,55)
		   ,BILL_PROV_ADDR2 =  CASE substring(isnull(T.BillProvAddress2,' '),1,55)
								WHEN 'UNKNOWN' THEN ' ' ELSE substring(isnull(T.BillProvAddress2,' '),1,55)
								END
		   ,BILL_PROV_CITY = substring(isnull(T.BillProvCity,' '),1,30)
		   ,BILL_PROV_STATE = substring(isnull(T.BillProvState,' '),1,2)
		   ,BILL_PROV_ZIP =  substring(isnull(substring(T.BillProvZip,1,5),' ') ,1,5)
		   ,BILL_PROV_ZIP4 = substring(isnull(substring(T.BillProvZip,6,4) ,' ') ,1,4)
		   ,BILL_PROV_TAXONOMY_CD = substring(isnull(T.BillProvTaxonomy,' '),1,10)
		   ,BILL_PROV_TAX_ID = substring(isnull(T.BillProvTaxID,' '),1,11)
		   ,BILL_PROV_UPIN = substring(isnull(T.BillProvUPINLicense,' '),1,50)
--		   ,BILL_PROV_NPI = LTRIM(rtrim(T.BillProvNPI))
--		   ,BILL_PROV_GRP_NPI= LTRIM(RTRIM(T.BILLPROV_GRP_NPI))
		   ,BILL_PROV_GRP_ID = LTRIM(RTRIM(T.BILL_PROV_GRP_ID))
-- TETDM-2278 When BILL_PROV_NPI and BILL_PROV_GRP_NPI have the same value, set one to blank
			,BILL_PROV_NPI = CASE WHEN T.BillProvNPI = T.BILL_PROV_GRP_ID AND substring(isnull(T.BillProvLast,' '),1,60) <> ' '
									THEN	LTRIM(rtrim(T.BillProvNPI))
									ELSE	' '
								END
			,BILL_PROV_GRP_NPI = CASE WHEN T.BillProvNPI = T.BILL_PROV_GRP_ID AND substring(isnull(T.BillProvLast,' '),1,60) <> ' '
									THEN	' '
									ELSE	LTRIM(RTRIM(T.BILLPROV_GRP_NPI))
								END
		FROM dbo.OUTB_INST_HEADER  H
				JOIN #TMPBILLING_CLMPROV T
		 ON T.CLAIM_ID  = H.CLAIM_ID
	     AND LEN(T.BILLPROVNPI) > 0
	    -- AND LEN(T.BillProvTaxonomy) > 0	

	--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_INST_HEADER_RESEND

-- TETDM-2278 Scott Waller June 17, 2020
			UPDATE	OUTB_INST_HEADER
			SET		BILL_PROV_TAXONOMY_CD = HealthcareProviderTaxonomyCode
			FROM	OUTB_INST_HEADER I
			INNER JOIN EDPS_Data.IDQ.CMSTaxonomy T
			ON		I.BILL_PROV_GRP_NPI = T.NPI
			where	t.HealthcareProviderPrimaryTaxonomySwitch = 'Y'
-- end

-- TETDM-2278 Scott Waller June 17, 2020
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_HEADER)
	----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_EDSPROVIDER'
							AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
