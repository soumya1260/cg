﻿CREATE PROCEDURE dbo.BUILD_OUTB_INST_DENIED_LINE_ADJUSTMENTS_WIPRO
AS
/***************************************************************************************************
** CREATE DATE: 08/2015
**
** AUTHOR: LOYAL RICKS 
**
** DESCRIPTION: Procedure will compile denied claim logic including the population of the required
**				CAS segment. Denied claims with a blank CAS Group or Reason code will get assigned
**				to the existing 9021 denied claim exclusion code. These claims will also be 
**				removed from the outbound file.   
**              
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------
09/08/16		Loyal Ricks		Add table tblABF_EOBProvider_DenialLanguage
09/21/16		Loyal Ricks		TETDM-987 Revisions:
								1: when QNXT_claimedit.CLAIMLINE = 0 apply all adjustment codes to all associated lines 
								2: When the CAGC & CARC are duplicated within a line ONLY submit one iterration on the individual claim line
								3: update step 3A above to Revise logic to Only pull when QNXT_claimedit.status = 'DENY' 	
10/18/16		Loyal Ricks		Add logic to specifically look at claims that are denied to reset the GRP111 CODE																														    
03/08/2018      John Bartholomay Modified Join to only pull lines from QNXT Claims Denied Table
03/13/2018      John Bartholomay TETDM-1683 PR Fix to not create PR when Claim Level over ride exits
03/15/2018      John Bartholomay TETDM-1683 Do not creat OA segment for Capitated Claim Level lines
2021-26-08		Anthony Ulmer	MES-133 Update to implement transfer to Medicaid database
**********************************************************************************************************************************************/

	DECLARE
					
					@TOTAL_RECORDS INT;


			--HRP_CLAIM_FILE Run controls
		INSERT INTO EXT_SYS_RUNLOG
				(PROC_NAME
				,STEP
				,START_DT
				,END_DT
				,RUN_MINUTES
				,TOTAL_RECORDS
				,ENTRYDT
				)
				VALUES('BUILD_OUTB_INST_DENIED_ADJUSTMENTS_WIPRO'
						,'12'
						,GETDATE()
						,NULL
						,NULL
						,0
						,GETDATE()
						);

						---------------------------------------
						--1683 PR SEGMENT FIX, DO NOT CREATE PR
						--     WHEN CLAIM HEADER DENY EXISTS
						---------------------------------------
						IF OBJECT_ID('TEMPDB..#CLMLINE') <> 0
						   DROP TABLE #CLMLINE;

						   CREATE TABLE #CLMLINE
						   (CLAIMID  VARCHAR(20),
						    claimline  int
						   );

						   INSERT INTO #CLMLINE
						   SELECT ED.claimid,ED.claimline
						   FROM  Medicaid.dbo.QNXT_claimedit ED
						   JOIN  Medicaid.dbo.claimdim  cc 
						     ON  CC.CLAIMID = ed.claimid
						   JOIN  OUTB_INST_HEADER H
						     ON  H.CLAIM_ID = ED.claimid
						   WHERE ED.claimline = 0;   
                    

					       IF OBJECT_ID('TEMPDB..#INST_TMPDEV_CLMCAP') <> 0
							DROP TABLE #INST_TMPDEV_CLMCAP;
		
							Create Table #INST_TMPDEV_CLMCAP
 							(CLAIMID VARCHAR(20),
							 CLAIMLINEID VARCHAR(5),
							 CAP_AMT MONEY,
							 QUANTITY INT
							 );

				          --UPDATE CLM_ADJ_GRP5 INFORMATION - PROVIDER CAPITATION
				          --CALCULATE CAPITATED AMOUNT
				          --USE ALSO TO DETERMINE WHETHER CLM_ADJ_GRP1 'CO' SHOULD BE POPULATED
				          INSERT INTO #INST_TMPDEV_CLMCAP
				          SELECT CLAIMID,CLAIMLINEID,SUM(CD.RequestedAmt - CD.PAYMENTAMOUNT - CD.COBAMT - CD.DEDUCTIBLEAMT - CD.COPAYAMT - CD.COINSURANCEAMT) as 'CAP_AMT',Quantity
				          --INTO  #INST_TMPDEV_CLMCAP
				          FROM Medicaid.dbo.claimdetaildim CD
				          INNER JOIN OUTB_INST_HEADER IH
				          ON CD.SOURCEDATAKEY = IH.SOURCEDATAKEY 
				          AND CD.CLAIMID = IH.CLAIM_ID 
				          WHERE CAPITATEDLINEFLAG = 'Y'
				          GROUP BY ClaimID,ClaimLineID,Quantity;

					       -------------------------------- 1683  end
   
							IF OBJECT_ID('TEMPDB..#CLMDEN') <> 0
									DROP TABLE #CLMDEN;
                                
									create table  #CLMDEN
									(claimid varchar(20)
										,SOURCEDATAKEY INT
										,CLAIMLINE int
										,CAGC VARCHAR(2)
										,CARC VARCHAR(5)
										,REQUESTEDAMT MONEY
										,SEQUENCE INT
									);
	                   
								INSERT INTO #CLMDEN         
								SELECT 
										C.ClaimID ,
										C.SOURCEDATAKEY,
										CD.CLAIMLINEID ,--QC.CLAIMLINE ,
										EPD.GC1,
										EPD.RC1,
										CD.REQUESTEDAMT,
										 ROW_NUMBER() OVER ( PARTITION BY c.ClaimID,CD.CLAIMLINEID, EPD.GC1, EPD.RC1 ORDER BY c.CLAIMID,CD.CLAIMLINEID,EPD.GC1, EPD.RC1) AS 'SEQ'
								FROM    OUTb_INST_HEADER P
								INNER JOIN Medicaid.DBO.CLAIMDIM C
								ON P.SOURCEDATAKEY = C.SOURCEDATAKEY 
								AND P.CLAIM_ID = C.CLAIMID 
								INNER JOIN Medicaid.DBO.CLAIMDETAILDIM CD
								ON C.SOURCEDATAKEY = CD.SOURCEDATAKEY 
								AND C.CLAIMID = CD.CLAIMID 
								INNER JOIN  Medicaid.dbo.QNXT_claimedit QC
								 --ON  p.CLAIM_ID = QC.CLAIMID         --1683
								 ON  CD.CLAIMID = QC.CLAIMID           --1683
								 AND QC.claimline = CD.CLAIMLINEID     --1683
								-- inner join EDPS_DATA.DBO.tblABF_EOBProvider_DenialLanguage EPD
								--on qc.reason = epd.QNXT_Code
								JOIN Medicaid.dbo.ProviderDenialLanguage EPD
										ON QC.reason = EPD.Application_Code
								WHERE c.sourcedatakey = 50 
									AND CD.ClaimLineStatus = 'DENY' -- TETDM 1943/1939 
									AND QC.STATUS = 'DENY'
									AND CD.REQUESTEDAMT > 0         -- TETDM 
									--and  C.DENIEDFLAG = 1
								GROUP BY C.ClaimID ,
										C.SOURCEDATAKEY,
										CD.CLAIMLINEID ,
										EPD.GC1,
										EPD.RC1,
										CD.REQUESTEDAMT
								order BY  C.ClaimID ,
										CD.CLAIMLINEID; 

							    -- TETDM 1943/1939 - Removes non PI CAS records, per service line, when more that one EOB edit exist for a given service line
								DELETE a
								FROM #CLMDEN a
								JOIN #CLMDEN b ON a.claimid = b.claimid AND a.REQUESTEDAMT = b.REQUESTEDAMT
									           AND a.claimline = b.claimline 
								WHERE a.CAGC <> 'PI' AND (a.CAGC <> b.CAGC);
								
                            
								---TETDM-987 when QNXT_claimedit.CLAIMLINE = 0 apply all adjustment codes to all associated lines 
								--INSERT INTO #CLMDEN
								--		select cd.claimid
								--			,cd.sourcedatakey
								--			,cd.CLAIMLINEID
								--			,t.CAGC
								--			,T.CARC
								--			,T.SEQUENCE
								--		FROM Medicaid.DBO.CLAIMDETAILDIM CD
								--		INNER JOIN #clmden T
								--		ON CD.SOURCEDATAKEY = T.SOURCEDATAKEY 
								--		AND CD.CLAIMID = T.CLAIMID 
								--		WHERE T.CLAIMLINE = 0



					
								--INSERT INTO #CLMDEN         
								--SELECT 
								--		C.ClaimID ,
								--		C.SOURCEDATAKEY,
								--		CLAIMLINEID ,
								--		DENIEDREASONCODE,
								--		SEQUENCE,
								--		SPACE(5) AS 'CAGC',
								--		SPACE(5) AS 'CARC'
								--		 --ROW_NUMBER() OVER ( PARTITION BY ClaimID,CLAIMLINEID ORDER BY CLAIMID,CLAIMLINEID,SEQUENCE) AS 'SEQ'
								--FROM    OUT_INST_HEADER P
								--inner join EDPS_DATA.DBO.CLAIMDIM C
								--ON P.SOURCEDATAKEY = C.SOURCEDATAKEY 
								--AND P.CLAIM_ID = C.CLAIMID 
								--INNER JOIN  EDPS_DATA.DBO.ClaimHeaderAdjustmentDim CLA
								-- ON CLA.SOURCEDATAKEY = C.SOURCEDATAKEY 
								-- AND CLA.CLAIMID = C.CLAIMID
								--WHERE C.DENIEDFLAG = 1
								----SOURCEDATAKEY = 50 AND CLAIMID IN ('08319E26313','08319000001','12097E00687','12097E00896')
								--group by C.ClaimID ,
								--		C.SOURCEDATAKEY,
								--		CLA.CLAIMLINEID ,
								--		CLA.DENIEDREASONCODE,
								--		Sequence
								-- order BY  C.ClaimID ,
								--		C.SOURCEDATAKEY,
								--		CLA.CLAIMLINEID ,
								--		CLA.DENIEDREASONCODE

								
									--	UPDATE #CLMDEN
									--	SET CAGC = QD.GC1
									--	,CARC = QD.RC1
									--	FROM #CLMDEN C
									--	INNER JOIN EDPS_DATA.DBO.tblABF_EOBProvider_DenialLanguage QD
									--	ON RTRIM(C.DENIEDREASONCODE) = RTRIM(QD.CODE)


									--IF OBJECT_ID('TEMPDB.. #CLMDEN_CAS') <> 0	
									--DROP TABLE #CLMDEN_CAS
									--create table  #CLMDEN_CAS
									--	(claimid varchar(20)
									--	,SOURCEDATAKEY INT
									--	,CLAIMLINEID VARCHAR(5)
									--	,CAGC VARCHAR(30)
									--	,CARC VARCHAR(50)
									--	,SEQUENCE INT
										
									--)

									--	INSERT INTO #CLMDEN_CAS
									--	SELECT CLAIMID,
									--			SOURCEDATAKEY,
									--			CLAIMLINEID,
									--			CAGC,
									--			CARC,
									--			ROW_NUMBER() OVER (PARTITION BY CLAIMID,CLAIMLINEID,CAGC ORDER BY CLAIMID,CLAIMLINEID) AS 'SEQ'
									--	FROM #CLMDEN

									---Denied Claim Error Check 
									--Assign exclusion and remove claimid from outbound file if unable to build CAS segment with valid codes 
									--	IF OBJECT_ID('TEMPDB..#CLMDEN_ERR') <> 0
									--	DROP TABLE #CLMDEN_ERR

							
									--create table  #CLMDEN_ERR
									--(claimid varchar(20)
									--	,SOURCEDATAKEY INT
										
									--)

									--INSERT INTO #CLMDEN_ERR
									--SELECT DISTINCT CLAIMID,SOURCEDATAKEY
									--FROM #CLMDEN CL
									--WHERE LEN(CAGC) = 0 OR LEN(CARC) = 0


									--insert into EXT_CLAIM_EXCLUSION_HIST
									--SELECT DISTINCT CL.CLAIMID,CL.SOURCEDATAKEY,GETDATE(),9032,CASE FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE FORMTYPECODE END 
									--	FROM #CLMDEN_CAS CL
									--	INNER JOIN EDPS_DATA.DBO.CLAIMDIM C
									--	ON CL.SOURCEDATAKEY = C.SOURCEDATAKEY 
									--	AND CL.CLAIMID = C.CLAIMID 
									--	WHERE LEN(CAGC) = 0 OR LEN(CARC) = 0

									----Remove Claim from outbound file 
									--delete 
									--from OUT_INST_HEADER 
									--WHERE CLAIM_ID IN (SELECT CLAIMID FROM #CLMDEN_ERR)

									--delete 
									--from OUTB_INST_DETAIL 
									--WHERE CLAIM_ID IN (SELECT CLAIMID FROM #CLMDEN_ERR)

					
									---adjustment assignment 
									--CLM_ADJ_GRP13 = 'PR'
									--CLM_ADJ_GRP15 = 'CR'
									--CLM_ADJ_GRP111 = 'CO'
									--cagc
									--		CO
									--		OA
									--		PI
									--		PR
								
									--Remove EDS Default group and reason code 
									UPDATE OUTB_INST_DETAIL 
									SET CLM_ADJ_GRP111 = ' '
										,CLM_ADJ_REASON111 = ' '
								    FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CLM_ADJ_REASON111 = '45';

									--Update CO Groups
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_GRP111 = CAGC
										,CLM_ADJ_REASON111 = CARC
										,CLM_ADJ_AMT111 = CC.REQUESTEDAMT
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC = 'CO'
										AND CC.SEQUENCE = 1;
										

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON112 = CARC	
										,CLM_ADJ_AMT112 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY112 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC = 'CO'
										AND CC.SEQUENCE = 2;

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON113 = CARC
										,CLM_ADJ_AMT113 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY113 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC = 'CO'
										AND CC.SEQUENCE = 3;
									
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON114 = CARC
										,CLM_ADJ_AMT114 =CC.REQUESTEDAMT
										,CLM_ADJ_QTY114 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC = 'CO'
										AND CC.SEQUENCE = 4;

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON115 = CARC
										,CLM_ADJ_AMT115 =CC.REQUESTEDAMT
										,CLM_ADJ_QTY115 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC = 'CO'
										AND CC.SEQUENCE = 5;


									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON116 = CARC
										,CLM_ADJ_AMT116 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY116 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC = 'CO'
										AND CC.SEQUENCE = 6;


									--Update PR Groups 
									--
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_GRP13 = 'PR'
										,CLM_ADJ_REASON131 = CARC
										,CLM_ADJ_AMT131 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY131 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC =  'PR'
									  AND CC.SEQUENCE = 1
									  AND P.CLAIM_ID NOT IN (SELECT CLAIMID FROM #CLMLINE) --1683
									  AND LEN(p.CLM_ADJ_QTY131) = 0;  --not null and greater than 0tetdm-2085

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON132 = CARC
										,CLM_ADJ_AMT132 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY132 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC =  'PR'
										AND CC.SEQUENCE = 2
										AND P.CLAIM_ID NOT IN (SELECT CLAIMID FROM #CLMLINE); --1683

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON133 = CARC
										,CLM_ADJ_AMT133 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY133 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC =  'PR'
										AND CC.SEQUENCE = 3
										AND P.CLAIM_ID NOT IN (SELECT CLAIMID FROM #CLMLINE); --1683
									
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON134 = CARC
										,CLM_ADJ_AMT134 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY134 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC =  'PR'
										AND CC.SEQUENCE = 4
										AND P.CLAIM_ID NOT IN (SELECT CLAIMID FROM #CLMLINE); --1683

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON135 = CARC
										,CLM_ADJ_AMT135 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY135 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC =  'PR'
										AND CC.SEQUENCE = 5
										AND P.CLAIM_ID NOT IN (SELECT CLAIMID FROM #CLMLINE); --1683


									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON136 = CARC
										,CLM_ADJ_AMT136 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY136 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC =  'PR'
										AND CC.SEQUENCE = 6
										AND P.CLAIM_ID NOT IN (SELECT CLAIMID FROM #CLMLINE); --1683


									--Update OA Group 
										--Update PR Groups 
									--
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_GRP12 = 'OA'
										,CLM_ADJ_REASON121 = CARC
										,CLM_ADJ_AMT121 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY121 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC =  'OA'
										AND CC.SEQUENCE = 1;

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON122 = CARC
										,CLM_ADJ_AMT122 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY122 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC =  'OA'
										AND CC.SEQUENCE = 2;

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON123 = CARC
										,CLM_ADJ_AMT123 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY123 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC =  'OA'
										AND CC.SEQUENCE = 3;
									
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON124 = CARC
										,CLM_ADJ_AMT124 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY124 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC =  'OA'
										AND CC.SEQUENCE = 4;

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON125 = CARC
										,CLM_ADJ_AMT125 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY125 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC = 'OA'
										AND CC.SEQUENCE = 5;


									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON126 = CARC
										,CLM_ADJ_AMT126 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY126 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC =  'OA'
										AND CC.SEQUENCE = 6;

									--Update PI Group 
									--
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_GRP14 = 'PI'
										,CLM_ADJ_REASON141 = CARC
										,CLM_ADJ_AMT141 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY141 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									WHERE CC.CAGC =  'PI'
										AND CC.SEQUENCE = 1;

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON142 = CARC
										,CLM_ADJ_AMT142 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY142 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC =  'PI'
										AND CC.SEQUENCE = 2;

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON143 = CARC
										,CLM_ADJ_AMT143 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY143 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC =  'PI'
										AND CC.SEQUENCE = 3;
									
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON144 = CARC
										,CLM_ADJ_AMT144 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY144 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC =  'PI'
										AND CC.SEQUENCE = 4;

									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON145 = CARC
										,CLM_ADJ_AMT145 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY145 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC = 'PI'
										AND CC.SEQUENCE = 5;


									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON146 = CARC
										,CLM_ADJ_AMT146 = CC.REQUESTEDAMT
										,CLM_ADJ_QTY146 = CLM_ADJ_QTY111
									FROM OUTB_INST_DETAIL P
									INNER JOIN #CLMDEN CC
									ON P.CLAIM_ID = CC.CLAIMID
									AND P.CLAIM_LINE_NO = CC.CLAIMLINE 
									--AND P.CLAIM_ID NOT IN (SELECT CLAIM_ID FROM #INST_TMPDEV_CLMCAP) --1683 Commented out due to 1943
									WHERE CC.CAGC =  'PI'
										AND CC.SEQUENCE = 6;

									---Clear default CAS assignments for CLM_ADJ_GRP111 
									UPDATE OUTB_INST_DETAIL 
									SET CLM_ADJ_AMT111 = ' '
										,CLM_ADJ_QTY111 = ' '
									WHERE LEN(CLM_ADJ_GRP111) = 0; 

			--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUT_INST_HEADER_RESEND
										 
						SET @TOTAL_RECORDS = (SELECT COUNT(DISTINCT CLAIMID) FROM #CLMDEN);
					----HRP_CLAIM_FILE Update Run Controls
							
									UPDATE EXT_SYS_RUNLOG
									SET END_DT = GETDATE()	
										,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
										,TOTAL_RECORDS = @TOTAL_RECORDS
										,ENTRYDT = GETDATE()
									WHERE PROC_NAME = 'BUILD_OUTB_INST_DENIED_ADJUSTMENTS_WIPRO'
											AND END_DT IS NULL;





