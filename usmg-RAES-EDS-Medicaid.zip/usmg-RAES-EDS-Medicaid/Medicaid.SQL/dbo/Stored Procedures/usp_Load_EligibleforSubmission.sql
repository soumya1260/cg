﻿/*

Note: Use the Medicaid.dbo.MMR table as the driver table to identify the Member and Claims data needed for this table. 
When joining to the ClaimDim table ensure the at the ClaimDim.BeginServiceDatekey is between the MMR table Pymt_ADJ_Begin and Pymt_ADJ_End dates

Summary of Requirements
Create table (DataTypes identified at end of each column above)
Create Archive table (Added column ArchivedDate - datetime) All others columns should be pulled from the base table
(Interim) - Utilize Medicaid database dbo.MMR and EDPS_Data tables to accommodate testing the mapping specified above

select * from Medicaid.dbo.EligibleforSubmission

truncate table Medicaid.dbo.EligibleforSubmission

/**************************************************/
DAte		Author				Description
09/22/2021  Subhash Acharya     Initial Check in MES-114
10/27/2021  Subhash ACharya     update to Submission_Type Logic
04/13/2023	Aaron Ridley	Medicaid update to use Configuration tables as we incorporate FL/PA 


/***************************************************/



*/
CREATE PROC [dbo].[usp_Load_EligibleforSubmission]
AS
INSERT INTO Medicaid.dbo.EligibleforSubmission
(
    Claimid,
    MedicaidID,
    MemberID,
    SSN,
    ADJ_Date,
    Claim_Type,
    Submission_Type,
    SubmissionStatus,
    InsertDate,
    LastUpdateDate,
    ADJ_SEQ,
	RegulatoryMarket
)
SELECT DISTINCT
	--TOP 10000
	   CD.CLAIMID AS Claimid,
       MD.MedicaidID AS MedicaidID,
       CD.MEMBERID AS MemberID,
       MD.SSN AS SSN,
       QC.Adjuddate AS ADJ_Date,
       CASE
           WHEN CD.FORMTYPECODE = 'H' THEN
               'P'
           ELSE
               'I'
       END AS Claim_Type,
      CASE
           WHEN (MMD.RegulatoryMarket = 'TN' AND (QC.Frequencycode <> '7'  OR QC.CLAIMID NOT LIKE '%A%') AND  (QC.OrgClaimid IS NULL OR rtrim(ltrim(QC.OrgClaimid)) = '')) AND QC.[reimbursemember] = 'Y' THEN 'DMR_ORG'  
		   WHEN (MMD.RegulatoryMarket = 'TN' AND(QC.Frequencycode = '7'  OR QC.CLAIMID NOT LIKE '%A%') AND  (QC.OrgClaimid IS NULL OR rtrim(ltrim(QC.OrgClaimid)) = '')) AND QC.[reimbursemember] = 'Y' THEN 'DMR_ORG'  
           WHEN (MMD.RegulatoryMarket = 'TN' AND(QC.Frequencycode = '7' OR QC.CLAIMID LIKE '%A%') AND (QC.OrgClaimid IS NOT NULL OR rtrim(ltrim(QC.OrgClaimid)) <> '')) AND QC.[reimbursemember] = 'Y' THEN 'DMR_ADJ'  
           WHEN (MMD.RegulatoryMarket = 'TN' AND(QC.Frequencycode <> '7'  OR QC.CLAIMID NOT LIKE '%A%') AND (QC.OrgClaimid IS NULL OR rtrim(ltrim(QC.OrgClaimid)) = '')) AND  QC.[reimbursemember] <> 'Y' THEN 'Original'
		   WHEN (MMD.RegulatoryMarket = 'TN' AND(QC.Frequencycode = '7'  OR QC.CLAIMID NOT LIKE '%A%') AND (QC.OrgClaimid IS NULL OR rtrim(ltrim(QC.OrgClaimid)) = '')) AND  QC.[reimbursemember] <> 'Y' THEN 'Original'
           WHEN (MMD.RegulatoryMarket = 'TN' AND(QC.Frequencycode = '7' OR QC.CLAIMID LIKE '%A%') AND (QC.OrgClaimid IS NOT NULL OR rtrim(ltrim(QC.OrgClaimid)) <> '')) AND QC.[reimbursemember] <> 'Y' THEN 'Adjustment'
		   WHEN (MMD.RegulatoryMarket <> 'TN' AND(QC.Frequencycode NOT IN ('7','8'))  AND (QC.OrgClaimid IS NULL OR rtrim(ltrim(QC.OrgClaimid)) = '')) THEN 'Original'
		   WHEN (MMD.RegulatoryMarket <> 'TN' AND(QC.Frequencycode IN ('7','8')) AND (QC.OrgClaimid IS NOT NULL OR rtrim(ltrim(QC.OrgClaimid)) <> ''))  THEN 'Adjustment'
       ELSE 'RESEARCH COND' END AS Submission_Type,
       /*SubmissoinStatus - 'Y' - Submitted / 'N' Not Submitted - Based on Medicaid submission process updating transactional table (enc.Claim) - Char*/
       'N' AS SubmissionStatus,
       GETDATE() AS InsertDate,
       GETDATE() AS LastUpdateDate, --LastUpdateDate - getdate (when SubmissionStatus changes update) - DateTime
       NULL AS ADJ_SEQ,
	   MMD.RegulatoryMarket
FROM Medicaid.dbo.CLAIMDIM CD
    JOIN Medicaid.dbo.MemberDim MD
        ON CD.MEMBERID = MD.MemberID
    JOIN Medicaid.dbo.QNXT_Claim QC
        ON CD.CLAIMID = QC.claimid
	JOIN Medicaid.dbo.MonthlyMembershipDim MMD on MD.MemberID = MMD.MemberID AND left(CD.BeginServiceDateKey,6) = LEFT(MMD.ReportDateKey,6)
WHERE CD.CLAIMID NOT IN (SELECT CLAIMID FROM Medicaid.dbo.EligibleforSubmission 
						 UNION
						 SELECT CLAIMID FROM  Medicaid.dbo.EligibleforSubmission_Archive);

/*-------------------------------------------------------------------------------------------

REMOVE PA Medicaid Records for claims with DOS Prior to 20230401 - Config table will be used to replace the hardcoding later
---------------------------------------------------------------------------------------------*/
--DECLARE 
--@PLANACTIVEDATE VARCHAR (8); 

--SELECT REPLACE(PLANACTIVEDATE,'-','') FROM MEDICAID.[dbo].[MedicaidTradingPartner]

DELETE EFS
FROM Medicaid.dbo.EligibleforSubmission EFS
INNER JOIN Medicaid.dbo.ClaimDim CLM ON EFS.Claimid = CLM.CLAIMID AND EFS.RegulatoryMarket = 'PA'
WHERE CLM.BeginServiceDateKey < 20180101 AND EFS.SubmissionStatus ='N';

DELETE EFS
FROM Medicaid.dbo.EligibleforSubmission EFS
LEFT JOIN  WIPRO.dbo.OUTB_CLAIM_STATUS OBCS ON EFS.Claimid = OBCS.CLAIM_ID
WHERE EFS.RegulatoryMarket = 'PA' AND CLMSTAT_STATUS NOT IN ('A-ICN','MAO-004') 

DELETE EFS
FROM Medicaid.dbo.EligibleforSubmission EFS
LEFT JOIN  WIPRO.dbo.OUTB_CLAIM_STATUS OBCS ON EFS.Claimid = OBCS.CLAIM_ID
WHERE EFS.RegulatoryMarket = 'PA' AND OBCS.CLAIM_ID IS NULL

DELETE EFS
FROM Medicaid.dbo.EligibleforSubmission EFS
LEFT JOIN  WIPRO.dbo.OUTB_CLAIM_STATUS OBCS ON EFS.Claimid = OBCS.CLAIM_ID
WHERE EFS.RegulatoryMarket = 'PA' AND CMS_ICN IS NULL


/*------------------------------------------------------------------------------------------------------------
Arhcive Previsouly Submitted Records 
---------------------------------------------------------------------------------------------------------------*/


INSERT INTO Medicaid.dbo.EligibleforSubmission_Archive
(
    Claimid,
    MedicaidID,
    MemberID,
    SSN,
    ADJ_Date,
    Claim_Type,
    Submission_Type,
    SubmissionStatus,
    InsertDate,
    LastUpdateDate,
    ADJ_SEQ,
    ArchivedDate,
	RegulatoryMarket
)
SELECT Claimid,
       MedicaidID,
       MemberID,
       SSN,
       ADJ_Date,
       Claim_Type,
       Submission_Type,
       SubmissionStatus,
       InsertDate,
       LastUpdateDate,
       ADJ_SEQ,
       GETDATE(),
	   RegulatoryMarket
FROM Medicaid.dbo.EligibleforSubmission
WHERE SubmissionStatus = 'Y';

