﻿CREATE PROCEDURE dbo.BUILD_OUTB_INSERT_OCC_DATES
AS  
SET NOCOUNT ON;
/************************************************************************************************************************  
** CREATE DATE: 08/10/2017  
**  
** AUTHOR: Henry Faust  
**  
** DESCRIPTION: Populates the table OUTB_Prof_CCCR. The table is used to eliminate multiple DX codes  
**                
**                
**  
**  
Modification History  
====================  
Date			Who				Description  
--------------------------------------------------------------------------------------------------------------------------  
 08/10/2017		henry Faust   This procedure populates the table OUTB_PROF_CCCR with only the unique Diagnosis codes.  
                              Primary Diag Code row number 1, the rest are offset by 1.       
								  
*****************************************************************************************************	  
------------------------------------------------------------------------------------------------------  
******************************************************************************************************  
------------------------------------------------------------------------------------------------------  
  
2017-08-10		Henry Faust TETDM 1501		WIPRO Implementation
2021-26-08		Anthony Ulmer	MES-133 Update to implement transfer to Medicaid database
*****************************************************************************************************/	  
			DECLARE  
			  
			@TOTAL_RECORDS INT;  
              
			BEGIN TRANSACTION;   
					INSERT INTO EXT_SYS_RUNLOG  
							(PROC_NAME  
							,STEP  
							,START_DT  
							,END_DT  
							,RUN_MINUTES  
							,TOTAL_RECORDS  
							,ENTRYDT  
							)  
					VALUES('BUILD_OUTB_INSERT_OCC_DATES'   
							,'9.5'  
							,GETDATE()  
							,NULL  
							,NULL  
							,0  
							,GETDATE()  
							);  
					if @@ERROR <> 0  
							begin  
								rollback;   
							end;  
				commit;  
  
  
  
TRUNCATE TABLE OUTB_ClaimOccDate;  
TRUNCATE TABLE OUTB_ClaimOccSpanDate;  
  
  
INSERT INTO OUTB_ClaimOccDate  
  
SELECT a1.claimid, occ_code_01, occ_date_01 ,  occ_code_02, occ_date_02 , occ_code_03, occ_date_03 , occ_code_04, occ_date_04 , occ_code_05, occ_date_05 , occ_code_06, occ_date_06   
                 , occ_code_07, occ_date_07 , occ_code_08, occ_date_08 , occ_code_09, occ_date_09 , occ_code_10, occ_date_10   
				 , occ_code_11, occ_date_11 , occ_code_12, occ_date_12  
FROM   
(  
	SELECT rownum, claimid, occ_code_01, occ_date_01  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_01, OccuranceFromDateKey AS occ_date_01  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum =1  
)a1  
LEFT OUTER JOIN   
 (  
	SELECT rownum, claimid, occ_code_02, occ_date_02  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_02, OccuranceFromDateKey AS occ_date_02  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum =2  
)a2 ON a1.claimid = a2.claimid   
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_code_03, occ_date_03  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_03, OccuranceFromDateKey AS occ_date_03  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey 
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum =3  
)a3 ON a1.claimid = a3.claimid   
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_code_04, occ_date_04  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_04, OccuranceFromDateKey AS occ_date_04  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum =4  
)a4 ON a1.claimid = a4.claimid   
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_code_05, occ_date_05  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_05, OccuranceFromDateKey AS occ_date_05  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum = 5  
)a5 ON a1.claimid = a5.claimid   
  
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_code_06, occ_date_06  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_06, OccuranceFromDateKey AS occ_date_06  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum = 6  
)a6 ON a1.claimid = a6.claimid  
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_code_07, occ_date_07  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_07, OccuranceFromDateKey AS occ_date_07  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum = 7  
)a7 ON a1.claimid = a7.claimid    
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_code_08, occ_date_08  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_08, OccuranceFromDateKey AS occ_date_08  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum = 8  
)a8 ON a1.claimid = a8.claimid   
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_code_09, occ_date_09  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_09, OccuranceFromDateKey AS occ_date_09  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum = 9  
)a9 ON a1.claimid = a9.claimid    
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_code_10, occ_date_10  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_10, OccuranceFromDateKey AS occ_date_10  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum = 10  
)a10 ON a1.claimid = a10.claimid    
 LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_code_11, occ_date_11  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_11, OccuranceFromDateKey AS occ_date_11  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum = 11  
)a11 ON a1.claimid = a11.claimid    
 LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_code_12, occ_date_12  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_code_12, OccuranceFromDateKey AS occ_date_12  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'N'  
		   )x   
        
	      
	)one WHERE one.Rownum = 12  
)a12 ON a1.claimid = a12.claimid;    
  
-------------------------------------------  
---------------------- Span Code Part  
-------------------------------------------  
INSERT INTO OUTB_ClaimOccSpanDate  
  
SELECT a1.claimid, occ_scode_01, occ_SSdate_01 , occ_SEdate_01 ,  occ_scode_02, occ_SSdate_02 , occ_SEdate_02  , occ_scode_03, occ_SSdate_03 , occ_SEdate_03   
                 , occ_scode_04 , occ_SSdate_04 , occ_SEdate_04  , occ_scode_05, occ_SSdate_05 , occ_SEdate_05  , occ_scode_06, occ_SSdate_06 , occ_SEdate_06    
				 , occ_scode_07 , occ_SSdate_07 , occ_SEdate_07   
				 , occ_scode_08 , occ_SSdate_08 , occ_SEdate_08   
				 , occ_scode_09 , occ_SSdate_09 , occ_SEdate_09   
				 , occ_scode_10 , occ_SSdate_10 , occ_SEdate_10   
				 , occ_scode_11 , occ_SSdate_11 , occ_SEdate_11   
				 , occ_scode_12 , occ_SSdate_12 , occ_SEdate_12   
FROM   
(  
	SELECT rownum, claimid, occ_scode_01, occ_SSdate_01,  occ_SEdate_01  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_01, OccuranceFromDateKey AS occ_SSdate_01 , OccuranceToDateKey AS occ_SEdate_01  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum =1  
)a1  
LEFT OUTER JOIN   
 (  
	SELECT rownum, claimid, occ_scode_02, occ_SSdate_02,  occ_SEdate_02  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_02, OccuranceFromDateKey AS occ_SSdate_02 , OccuranceToDateKey AS occ_SEdate_02  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum =2  
)a2 ON a1.claimid = a2.claimid   
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_scode_03, occ_SSdate_03,  occ_SEdate_03  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_03, OccuranceFromDateKey AS occ_SSdate_03 , OccuranceToDateKey AS occ_SEdate_03  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum =3  
)a3 ON a1.claimid = a3.claimid   
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_scode_04, occ_SSdate_04,  occ_SEdate_04  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_04, OccuranceFromDateKey AS occ_SSdate_04 , OccuranceToDateKey AS occ_SEdate_04  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum =4  
)a4 ON a1.claimid = a4.claimid   
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_scode_05, occ_SSdate_05,  occ_SEdate_05  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_05, OccuranceFromDateKey AS occ_SSdate_05 , OccuranceToDateKey AS occ_SEdate_05  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey				  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum = 5  
)a5 ON a1.claimid = a5.claimid   
  
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_scode_06, occ_SSdate_06,  occ_SEdate_06  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_06, OccuranceFromDateKey AS occ_SSdate_06 , OccuranceToDateKey AS occ_SEdate_06  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey				  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum = 6  
)a6 ON a1.claimid = a6.claimid  
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_scode_07, occ_SSdate_07,  occ_SEdate_07  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_07, OccuranceFromDateKey AS occ_SSdate_07 , OccuranceToDateKey AS occ_SEdate_07  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey				  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum = 7  
)a7 ON a1.claimid = a5.claimid    
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_scode_08, occ_SSdate_08,  occ_SEdate_08  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_08, OccuranceFromDateKey AS occ_SSdate_08 , OccuranceToDateKey AS occ_SEdate_08  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey				  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum = 8  
)a8 ON a1.claimid = a5.claimid    
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_scode_09, occ_SSdate_09,  occ_SEdate_09  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_09, OccuranceFromDateKey AS occ_SSdate_09 , OccuranceToDateKey AS occ_SEdate_09  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey				  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum = 9  
)a9 ON a1.claimid = a5.claimid    
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_scode_10, occ_SSdate_10,  occ_SEdate_10  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_10, OccuranceFromDateKey AS occ_SSdate_10 , OccuranceToDateKey AS occ_SEdate_10  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey				  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum = 10  
)a10 ON a1.claimid = a5.claimid  
LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_scode_11, occ_SSdate_11,  occ_SEdate_11  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_11, OccuranceFromDateKey AS occ_SSdate_11 , OccuranceToDateKey AS occ_SEdate_11  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey				  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum = 11  
)a11 ON a1.claimid = a5.claimid    
 LEFT outer JOIN   
 (  
	SELECT rownum, claimid, occ_scode_12, occ_SSdate_12,  occ_SEdate_12  
	FROM  
	(  
	SELECT     
		ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid, UB923OccuranceKey ASC) AS Rownum, claimid, OccuranceCode AS occ_scode_12, OccuranceFromDateKey AS occ_SSdate_12 , OccuranceToDateKey AS occ_SEdate_12  
		  FROM   
			(SELECT  ClaimID, OccuranceCode, OccuranceFromDateKey,OccuranceToDateKey, UB923OccuranceKey				  
				FROM Medicaid.dbo.ClaimOccuranceDim cod  
				      ,dbo.OUTB_INST_HEADER oih  
				WHERE cod.CLAIMID = oih.CLAIM_ID   
--		                        (SELECT claim_id FROM [OUTB_INST_HEADER])  
                   and spanrecord = 'Y'  
		   )x   
        
	      
	)one WHERE one.Rownum = 12  
)a12 ON a1.claimid = a5.claimid;    
   
--*******************************************************   
 			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_HEADER);  
			SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM OUTB_INST_DETAIL);  
				BEGIN TRANSACTION;  
						UPDATE EXT_SYS_RUNLOG  
						SET END_DT = GETDATE()	  
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
							,TOTAL_RECORDS = @TOTAL_RECORDS  
							,ENTRYDT = GETDATE()  
						WHERE PROC_NAME = 'BUILD_OUTB_INSERT_OCC_DATES'    
										and END_DT is null;  
							IF @@ERROR <> 0  
										BEGIN   
												ROLLBACK;   
										END;  
						COMMIT;  
  
  
