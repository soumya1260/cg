﻿CREATE PROCEDURE dbo.pr_BUILD_OUTB_INST_REMOVE_ZERO_CAS_AMTS

AS

/***************************************************************************************************
** CREATE DATE: 01/2018
**
** AURTHOR: John Bartholomay
**
** DESCRIPTION: Procedure will Remove Zero Dollar amount CAS segements 121 - 156
**              TETDM-1715
**
**             
**              
**             
**
**
Modification History
====================
Date                Who                        Description
----------------------------------------------------------------------------------------------------
01/12/2018     John Bartholomay     TETDM-1715 Remove Zero Dollar Amount CAS Segments
                                    This will correct an issue at CMS where when reporting a 
									zero dollar amount in a CAS segment is causing a rejection
03/21/2018     John Bartholomay     TETDM-1715 Updates for Zero dollar segments
2021-26-08	   Anthony Ulmer		MES-133 Update to implement transfer to Medicaid database
-----------------------------------------------------------------------------------------------------*/

		DECLARE	
		@TOTAL_RECORDS INT;


        INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('pr_BUILD_OUTB_INST_REMOVE_ZERO_CAS_AMTS'
				,'4'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				);
  IF OBJECT_ID('TEMPDB..#OUTB_INST_CAS') <> 0
					DROP TABLE #OUTB_INST_CAS;
					
   
   CREATE TABLE #OUTB_INST_CAS
   (
	[CLAIM_ID] [char](20) NULL,
	[CLAIM_LINE_NO] [char](5) NULL,
	[CLM_ADJ_REASON111] [char](50) NULL,
	[CLM_ADJ_AMT111] [char](18) NULL,
	[CLM_ADJ_QTY111] [char](18) NULL,
	[CLM_ADJ_REASON112] [char](50) NULL,
	[CLM_ADJ_AMT112] [char](18) NULL,
	[CLM_ADJ_QTY112] [char](18) NULL,
	[CLM_ADJ_REASON113] [char](50) NULL,
	[CLM_ADJ_AMT113] [char](18) NULL,
	[CLM_ADJ_QTY113] [char](18) NULL,
	[CLM_ADJ_REASON114] [char](50) NULL,
	[CLM_ADJ_AMT114] [char](18) NULL,
	[CLM_ADJ_QTY114] [char](18) NULL,
	[CLM_ADJ_REASON115] [char](50) NULL,
	[CLM_ADJ_AMT115] [char](18) NULL,
	[CLM_ADJ_QTY115] [char](18) NULL,
	[CLM_ADJ_REASON116] [char](50) NULL,
	[CLM_ADJ_AMT116] [char](18) NULL,
	[CLM_ADJ_QTY116] [char](18) NULL,
	[CLM_ADJ_REASON121] [char](50) NULL,
	[CLM_ADJ_AMT121] [char](18) NULL,
	[CLM_ADJ_QTY121] [char](18) NULL,
	[CLM_ADJ_REASON122] [char](50) NULL,
	[CLM_ADJ_AMT122] [char](18) NULL,
	[CLM_ADJ_QTY122] [char](18) NULL,
	[CLM_ADJ_REASON123] [char](50) NULL,
	[CLM_ADJ_AMT123] [char](18) NULL,
	[CLM_ADJ_QTY123] [char](18) NULL,
	[CLM_ADJ_REASON124] [char](50) NULL,
	[CLM_ADJ_AMT124] [char](18) NULL,
	[CLM_ADJ_QTY124] [char](18) NULL,
	[CLM_ADJ_REASON125] [char](50) NULL,
	[CLM_ADJ_AMT125] [char](18) NULL,
	[CLM_ADJ_QTY125] [char](18) NULL,
	[CLM_ADJ_REASON126] [char](50) NULL,
	[CLM_ADJ_AMT126] [char](18) NULL,
	[CLM_ADJ_QTY126] [char](18) NULL,
	[CLM_ADJ_REASON131] [char](50) NULL,
	[CLM_ADJ_AMT131] [char](18) NULL,
	[CLM_ADJ_QTY131] [char](18) NULL,
	[CLM_ADJ_GRP13]  [VARCHAR](30) NULL,
	[CLM_ADJ_REASON132] [char](50) NULL,
	[CLM_ADJ_AMT132] [char](18) NULL,
	[CLM_ADJ_QTY132] [char](18) NULL,
	[CLM_ADJ_REASON133] [char](50) NULL,
	[CLM_ADJ_AMT133] [char](18) NULL,
	[CLM_ADJ_QTY133] [char](18) NULL,
	[CLM_ADJ_REASON134] [char](50) NULL,
	[CLM_ADJ_AMT134] [char](18) NULL,
	[CLM_ADJ_QTY134] [char](18) NULL,
	[CLM_ADJ_REASON135] [char](50) NULL,
	[CLM_ADJ_AMT135] [char](18) NULL,
	[CLM_ADJ_QTY135] [char](18) NULL,
	[CLM_ADJ_REASON136] [char](50) NULL,
	[CLM_ADJ_AMT136] [char](18) NULL,
	[CLM_ADJ_QTY136] [char](18) NULL,
	[CLM_ADJ_REASON141] [char](50) NULL,
	[CLM_ADJ_AMT141] [char](18) NULL,
	[CLM_ADJ_QTY141] [char](18) NULL,
	[CLM_ADJ_REASON142] [char](50) NULL,
	[CLM_ADJ_AMT142] [char](18) NULL,
	[CLM_ADJ_QTY142] [char](18) NULL,
	[CLM_ADJ_REASON143] [char](50) NULL,
	[CLM_ADJ_AMT143] [char](18) NULL,
	[CLM_ADJ_QTY143] [char](18) NULL,
	[CLM_ADJ_REASON144] [char](50) NULL,
	[CLM_ADJ_AMT144] [char](18) NULL,
	[CLM_ADJ_QTY144] [char](18) NULL,
	[CLM_ADJ_REASON145] [char](50) NULL,
	[CLM_ADJ_AMT145] [char](18) NULL,
	[CLM_ADJ_QTY145] [char](18) NULL,
	[CLM_ADJ_REASON146] [char](50) NULL,
	[CLM_ADJ_AMT146] [char](18) NULL,
	[CLM_ADJ_QTY146] [char](18) NULL,
	[CLM_ADJ_REASON151] [char](50) NULL,
	[CLM_ADJ_AMT151] [char](18) NULL,
	[CLM_ADJ_QTY151] [char](18) NULL,
	[CLM_ADJ_REASON152] [char](50) NULL,
	[CLM_ADJ_AMT152] [char](18) NULL,
	[CLM_ADJ_QTY152] [char](18) NULL,
	[CLM_ADJ_REASON153] [char](50) NULL,
	[CLM_ADJ_AMT153] [char](18) NULL,
	[CLM_ADJ_QTY153] [char](18) NULL,
	[CLM_ADJ_REASON154] [char](50) NULL,
	[CLM_ADJ_AMT154] [char](18) NULL,
	[CLM_ADJ_QTY154] [char](18) NULL,
	[CLM_ADJ_REASON155] [char](50) NULL,
	[CLM_ADJ_AMT155] [char](18) NULL,
	[CLM_ADJ_QTY155] [char](18) NULL,
	[CLM_ADJ_REASON156] [char](50) NULL,
	[CLM_ADJ_AMT156] [char](18) NULL,
	[CLM_ADJ_QTY156] [char](18) NULL,
	[SOURCEDATAKEY] [int] NULL
); 
   INSERT INTO #OUTB_INST_CAS 
   SELECT 
	  [CLAIM_ID]           ,
	  [CLAIM_LINE_NO]      ,
	  [CLM_ADJ_REASON111]  ,
	  [CLM_ADJ_AMT111]     ,
	  [CLM_ADJ_QTY111]     ,
	  [CLM_ADJ_REASON112]  ,
	  [CLM_ADJ_AMT112]     ,
	  [CLM_ADJ_QTY112]     ,
	  [CLM_ADJ_REASON113]  ,
	  [CLM_ADJ_AMT113]     ,
	  [CLM_ADJ_QTY113]     ,
	  [CLM_ADJ_REASON114]  ,
	  [CLM_ADJ_AMT114]     ,
	  [CLM_ADJ_QTY114]     ,
	  [CLM_ADJ_REASON115]  ,
	  [CLM_ADJ_AMT115]     ,
	  [CLM_ADJ_QTY115]     ,
	  [CLM_ADJ_REASON116]  ,
	  [CLM_ADJ_AMT116]     ,
	  [CLM_ADJ_QTY116]     ,
	  [CLM_ADJ_REASON121]  ,
	  [CLM_ADJ_AMT121]     ,
	  [CLM_ADJ_QTY121]     ,
	  [CLM_ADJ_REASON122]  ,
	  [CLM_ADJ_AMT122]     ,
	  [CLM_ADJ_QTY122]     ,
	  [CLM_ADJ_REASON123]  ,
	  [CLM_ADJ_AMT123]     ,
	  [CLM_ADJ_QTY123]     ,
	  [CLM_ADJ_REASON124]  ,
	  [CLM_ADJ_AMT124]     ,
	  [CLM_ADJ_QTY124]     ,
	  [CLM_ADJ_REASON125]  ,
	  [CLM_ADJ_AMT125]     ,
	  [CLM_ADJ_QTY125]     ,
	  [CLM_ADJ_REASON126]  ,
	  [CLM_ADJ_AMT126]     ,
	  [CLM_ADJ_QTY126]     ,
	  [CLM_ADJ_REASON131]  ,
	  [CLM_ADJ_AMT131]     ,
	  [CLM_ADJ_QTY131]     ,
	  [CLM_ADJ_GRP13]      ,
	  [CLM_ADJ_REASON132]  ,
	  [CLM_ADJ_AMT132]     ,
	  [CLM_ADJ_QTY132]     ,
	  [CLM_ADJ_REASON133]  ,
	  [CLM_ADJ_AMT133]     ,
	  [CLM_ADJ_QTY133]     ,
	  [CLM_ADJ_REASON134]  ,
	  [CLM_ADJ_AMT134]     ,
	  [CLM_ADJ_QTY134]     ,
	  [CLM_ADJ_REASON135]  ,
	  [CLM_ADJ_AMT135]     ,
	  [CLM_ADJ_QTY135]     ,
	  [CLM_ADJ_REASON136]  ,
	  [CLM_ADJ_AMT136]     ,
	  [CLM_ADJ_QTY136]     ,
	  [CLM_ADJ_REASON141]  ,
	  [CLM_ADJ_AMT141]     ,
	  [CLM_ADJ_QTY141]     ,
	  [CLM_ADJ_REASON142]  ,
	  [CLM_ADJ_AMT142]     ,
	  [CLM_ADJ_QTY142]     ,
	  [CLM_ADJ_REASON143]  ,
	  [CLM_ADJ_AMT143]     ,
	  [CLM_ADJ_QTY143]     ,
	  [CLM_ADJ_REASON144]  ,
	  [CLM_ADJ_AMT144]     ,
	  [CLM_ADJ_QTY144]     ,
	  [CLM_ADJ_REASON145]  ,
	  [CLM_ADJ_AMT145]     ,
	  [CLM_ADJ_QTY145]     ,
	  [CLM_ADJ_REASON146]  ,
	  [CLM_ADJ_AMT146]     ,
	  [CLM_ADJ_QTY146]     ,
	  [CLM_ADJ_REASON151]  ,
	  [CLM_ADJ_AMT151]     ,
	  [CLM_ADJ_QTY151]     ,
	  [CLM_ADJ_REASON152]  ,
	  [CLM_ADJ_AMT152]     ,
	  [CLM_ADJ_QTY152]     ,
	  [CLM_ADJ_REASON153]  ,
	  [CLM_ADJ_AMT153]     ,
	  [CLM_ADJ_QTY153]     ,
	  [CLM_ADJ_REASON154]  ,
	  [CLM_ADJ_AMT154]     ,
	  [CLM_ADJ_QTY154]     ,
	  [CLM_ADJ_REASON155]  ,
	  [CLM_ADJ_AMT155]     ,
	  [CLM_ADJ_QTY155]     ,
	  [CLM_ADJ_REASON156]  ,
	  [CLM_ADJ_AMT156]     ,
	  [CLM_ADJ_QTY156]     ,
	  [SOURCEDATAKEY] 
   FROM OUTB_INST_DETAIL;

   
   UPDATE CD 
     SET CLM_ADJ_AMT111 = '',
         CLM_ADJ_REASON111 = '',
         CLM_ADJ_QTY111 = '',
		 CLM_ADJ_GRP111 = ''
    FROM dbo.OUTB_INST_DETAIL CD,
	      #OUTB_INST_CAS IC
	WHERE CD.CLAIM_ID = IC.CLAIM_ID
	  AND  CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
	  AND  CD.TOTAL_CHRG_AMT = '0.00'
      AND  CD.CLM_ADJ_AMT111 = '0.00';

	    
	 UPDATE CD 
     SET CLM_ADJ_AMT111 = '',
         CLM_ADJ_REASON111 = '',
         CLM_ADJ_QTY111 = '',
		 CLM_ADJ_GRP111 = ''
    FROM dbo.OUTB_INST_DETAIL CD,
	      #OUTB_INST_CAS IC
	WHERE CD.CLAIM_ID = IC.CLAIM_ID
	  AND  CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
	  AND LTRIM(RTRIM(CD.CLM_ADJ_AMT111)) = '';

	 UPDATE CD 
      SET CLM_ADJ_AMT112 = '',
	       CLM_ADJ_REASON112 = '',
		   CLM_ADJ_QTY112 = ''
	  FROM dbo.OUTB_INST_DETAIL CD,
	        #OUTB_INST_CAS IC
	  WHERE CD.CLAIM_ID = IC.CLAIM_ID
	    AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
		AND  CD.TOTAL_CHRG_AMT = '0.00'
        AND CD.CLM_ADJ_AMT112 = '0.00';
	 

	  UPDATE CD 
		SET CLM_ADJ_AMT113 = '',
		    CLM_ADJ_REASON113 = '',
			CLM_ADJ_QTY113 = ''
	  FROM dbo.OUTB_INST_DETAIL CD,
		    #OUTB_INST_CAS IC
	  WHERE CD.CLAIM_ID = IC.CLAIM_ID
		AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
		AND  CD.TOTAL_CHRG_AMT = '0.00'
	    AND CD.CLM_ADJ_AMT113 = '0.00';
	 

	   UPDATE CD 
       SET CLM_ADJ_AMT114 = '',
		   CLM_ADJ_REASON114 = '',
		   CLM_ADJ_QTY114  = ''
	   FROM dbo.OUTB_INST_DETAIL CD,
		    #OUTB_INST_CAS IC
	   WHERE CD.CLAIM_ID = IC.CLAIM_ID
		 AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
		 AND  CD.TOTAL_CHRG_AMT = '0.00'
	     AND CD.CLM_ADJ_AMT114 = '0.00';

 	 
	   UPDATE CD 
	   SET CLM_ADJ_AMT115 = '', 
	       CLM_ADJ_REASON115 = '',
		   CLM_ADJ_QTY115 = ''
	   FROM dbo.OUTB_INST_DETAIL CD,
	        #OUTB_INST_CAS IC
	   WHERE CD.CLAIM_ID = IC.CLAIM_ID
	     AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
		 AND  CD.TOTAL_CHRG_AMT = '0.00'
	     AND CD.CLM_ADJ_AMT115 = '0.00';

	 
       UPDATE CD 
	   SET CLM_ADJ_AMT116 = '',
	       CLM_ADJ_REASON116 = '',
		   CLM_ADJ_QTY116 = ''
	   FROM OUTB_INST_DETAIL CD,
	        #OUTB_INST_CAS IC
	   WHERE CD.CLAIM_ID = IC.CLAIM_ID
	     AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
		 AND  CD.TOTAL_CHRG_AMT = '0.00'
	     AND CD.CLM_ADJ_AMT116 = '0.00';

	  
	    UPDATE CD 
        SET CLM_ADJ_AMT121 = '',
		    CLM_ADJ_REASON121 = '',
			CLM_ADJ_QTY121 = '',
			CLM_ADJ_GRP12 = ''
		FROM OUTB_INST_DETAIL CD,
		     #OUTB_INST_CAS IC
		WHERE CD.CLAIM_ID = IC.CLAIM_ID
		  AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
		  AND  CD.TOTAL_CHRG_AMT = '0.00'
	      AND CD.CLM_ADJ_AMT121 = '0.00';


        UPDATE CD 
        SET CLM_ADJ_AMT121 = '',
		    CLM_ADJ_REASON121 = '',
			CLM_ADJ_QTY121 = '',
			CLM_ADJ_GRP12 = ''
		FROM OUTB_INST_DETAIL CD,
		     #OUTB_INST_CAS IC
		WHERE CD.CLAIM_ID = IC.CLAIM_ID
		  AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
		  AND LTRIM(RTRIM(CD.CLM_ADJ_AMT121)) = '';

	    UPDATE CD 
		SET CLM_ADJ_AMT122 = '',
		    CLM_ADJ_REASON122 = '',
			CLM_ADJ_QTY122 = ''
		FROM OUTB_INST_DETAIL CD,
	         #OUTB_INST_CAS IC
	    WHERE CD.CLAIM_ID = IC.CLAIM_ID
	      AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
		  AND  CD.TOTAL_CHRG_AMT = '0.00'
	      AND CD.CLM_ADJ_AMT122 = '0.00';

       
	     UPDATE CD
		 SET CLM_ADJ_AMT123 = '',
			 CLM_ADJ_REASON123 = '',
		     CLM_ADJ_QTY123 = ''
         FROM OUTB_INST_DETAIL CD,
	          #OUTB_INST_CAS IC
	     WHERE CD.CLAIM_ID = IC.CLAIM_ID
	       AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
		   AND  CD.TOTAL_CHRG_AMT = '0.00'
		   AND CD.CLM_ADJ_AMT123 = '0.00';

       
	      UPDATE CD
		  SET CLM_ADJ_AMT124 = '',
			  CLM_ADJ_REASON124 = '',
			  CLM_ADJ_QTY124 = ''
		  FROM OUTB_INST_DETAIL CD,
	            #OUTB_INST_CAS IC
	      WHERE CD.CLAIM_ID = IC.CLAIM_ID
	        AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			AND  CD.TOTAL_CHRG_AMT = '0.00'
		    AND CD.CLM_ADJ_AMT124 = '0.00';

        
		   UPDATE CD
		   SET CLM_ADJ_AMT125 = '',
			   CLM_ADJ_REASON125 = '',
			    CLM_ADJ_QTY125 = ''
            FROM OUTB_INST_DETAIL CD,
	             #OUTB_INST_CAS IC
	        WHERE CD.CLAIM_ID = IC.CLAIM_ID
	          AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			  AND  CD.TOTAL_CHRG_AMT = '0.00'
		      AND CD.CLM_ADJ_AMT125 = '0.00';

        
		   UPDATE CD
		   SET CLM_ADJ_AMT126 = '',
		       CLM_ADJ_REASON126 = '',
			   CLM_ADJ_QTY126 = ''
            FROM OUTB_INST_DETAIL CD,
	             #OUTB_INST_CAS IC
	        WHERE CD.CLAIM_ID = IC.CLAIM_ID
	          AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			  AND  CD.TOTAL_CHRG_AMT = '0.00'
		      AND CD.CLM_ADJ_AMT126 = '0.00';

        
		   UPDATE CD
		   SET CLM_ADJ_AMT131 = '',
		       CLM_ADJ_REASON131 = '',
			   CLM_ADJ_QTY131 = '',
			   CLM_ADJ_GRP13 = ''
           FROM OUTB_INST_DETAIL CD,
	            #OUTB_INST_CAS IC
	       WHERE CD.CLAIM_ID = IC.CLAIM_ID
	         AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
			 AND  CD.TOTAL_CHRG_AMT = '0.00'
		     AND CD.CLM_ADJ_AMT131 = '0.00';

            UPDATE CD
		   SET CLM_ADJ_AMT131 = '',
		       CLM_ADJ_REASON131 = '',
			   CLM_ADJ_QTY131 = '',
			   CLM_ADJ_GRP13 = ''
           FROM OUTB_INST_DETAIL CD,
	            #OUTB_INST_CAS IC
	       WHERE CD.CLAIM_ID = IC.CLAIM_ID
	         AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
			 AND LEN(CD.CLM_ADJ_QTY131) = 0
			 AND LEN(CD.CLM_ADJ_GRP13) > 0;

		   UPDATE CD
		   SET CLM_ADJ_AMT132  = '',
		       CLM_ADJ_REASON132 = '',
			   CLM_ADJ_QTY132 = ''
            FROM OUTB_INST_DETAIL CD,
	             #OUTB_INST_CAS IC
	        WHERE CD.CLAIM_ID = IC.CLAIM_ID
	          AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			  AND  CD.TOTAL_CHRG_AMT = '0.00'
		      AND CD.CLM_ADJ_AMT132 = '0.00';

        
		  UPDATE CD
		  SET CLM_ADJ_AMT133 = '',
		      CLM_ADJ_REASON133 = '',
			  CLM_ADJ_QTY133 = ''
          FROM OUTB_INST_DETAIL CD,
	           #OUTB_INST_CAS IC
	      WHERE CD.CLAIM_ID = IC.CLAIM_ID
	        AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			AND  CD.TOTAL_CHRG_AMT = '0.00'
            AND CD.CLM_ADJ_AMT133 = '0.00';

         
		   UPDATE CD
		   SET CLM_ADJ_AMT134 = '',
			    CLM_ADJ_REASON134 = '',
				CLM_ADJ_QTY134 = ''
           FROM OUTB_INST_DETAIL CD,
	             #OUTB_INST_CAS IC
	       WHERE CD.CLAIM_ID = IC.CLAIM_ID
	          AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			  AND  CD.TOTAL_CHRG_AMT = '0.00'
		      AND CD.CLM_ADJ_AMT134 = '0.00';

         
		   UPDATE CD
		   SET CLM_ADJ_AMT135 = '',
			   CLM_ADJ_REASON135 = '',
			   CLM_ADJ_QTY135 = ''
           FROM OUTB_INST_DETAIL CD,
	             #OUTB_INST_CAS IC
	       WHERE CD.CLAIM_ID = IC.CLAIM_ID
	         AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			 AND  CD.TOTAL_CHRG_AMT = '0.00'
             AND CD.CLM_ADJ_AMT135 = '0.00';
    

		   UPDATE CD 
		   SET CLM_ADJ_AMT136 = '',
			   CLM_ADJ_REASON136 = '',
			   CLM_ADJ_QTY136 = ''
           FROM OUTB_INST_DETAIL CD,
	            #OUTB_INST_CAS IC
	       WHERE CD.CLAIM_ID = IC.CLAIM_ID
	         AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			 AND  CD.TOTAL_CHRG_AMT = '0.00'
		     AND CD.CLM_ADJ_AMT136 = '0.00';

         
		   UPDATE CD
		   SET CLM_ADJ_AMT141 = '',
			   CLM_ADJ_REASON141 = '',
			   CLM_ADJ_QTY141 = '',
			   CLM_ADJ_GRP14 = ''
            FROM OUTB_INST_DETAIL CD,
	             #OUTB_INST_CAS IC
	        WHERE CD.CLAIM_ID = IC.CLAIM_ID
	          AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			  AND  CD.TOTAL_CHRG_AMT = '0.00'
		      AND CD.CLM_ADJ_AMT141 = '0.00';
			   -- OR LTRIM(RTRIM(CD.CLM_ADJ_AMT141)) = ''
         
		   UPDATE CD
		    SET CLM_ADJ_AMT142 = '',
			    CLM_ADJ_REASON142 = '',
				CLM_ADJ_QTY142 = ''
           FROM OUTB_INST_DETAIL CD,
	             #OUTB_INST_CAS IC
	       WHERE CD.CLAIM_ID = IC.CLAIM_ID
	         AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO 
			 AND  CD.TOTAL_CHRG_AMT = '0.00'
		     AND CD.CLM_ADJ_AMT142 = '0.00';

         
		   UPDATE CD
		   SET CLM_ADJ_AMT143 = '',
			   CLM_ADJ_REASON143 = '',
			   CLM_ADJ_QTY143 = ''
            FROM OUTB_INST_DETAIL CD,
	             #OUTB_INST_CAS IC
	        WHERE CD.CLAIM_ID = IC.CLAIM_ID
	          AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			  AND  CD.TOTAL_CHRG_AMT = '0.00'
		      AND CD.CLM_ADJ_AMT143 = '0.00';

         
		   UPDATE CD
		   SET CLM_ADJ_AMT144 = '',
		       CLM_ADJ_REASON144 = '',
			   CLM_ADJ_QTY144 = ''
           FROM OUTB_INST_DETAIL CD,
	            #OUTB_INST_CAS IC
	      WHERE CD.CLAIM_ID = IC.CLAIM_ID
	        AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			AND  CD.TOTAL_CHRG_AMT = '0.00'
		    AND CD.CLM_ADJ_AMT144 = '0.00';

         
		   UPDATE CD
		   SET CLM_ADJ_AMT145 = '',
			   CLM_ADJ_REASON145 = '',
			   CLM_ADJ_QTY145 = '' 
           FROM OUTB_INST_DETAIL CD,
	            #OUTB_INST_CAS IC
	       WHERE CD.CLAIM_ID = IC.CLAIM_ID
	         AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			 AND  CD.TOTAL_CHRG_AMT = '0.00'
		     AND CD.CLM_ADJ_AMT145 = '0.00';	   

         
		   UPDATE CD
		   SET CLM_ADJ_AMT146 = '',
			   CLM_ADJ_REASON146 = '',
			   CLM_ADJ_QTY146 = ''
            FROM OUTB_INST_DETAIL CD,
	             #OUTB_INST_CAS IC
	        WHERE CD.CLAIM_ID = IC.CLAIM_ID
	          AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			  AND  CD.TOTAL_CHRG_AMT = '0.00'
              AND CD.CLM_ADJ_AMT146 = '0.00';

          
		    UPDATE CD
			SET CLM_ADJ_AMT151 = '',
			    CLM_ADJ_REASON151 = '',
				CLM_ADJ_QTY151 = '',
				CLM_ADJ_GRP15 = ''
             FROM OUTB_INST_DETAIL CD,
	              #OUTB_INST_CAS IC
	         WHERE CD.CLAIM_ID = IC.CLAIM_ID
	           AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			   AND  CD.TOTAL_CHRG_AMT = '0.00'
		       AND CD.CLM_ADJ_AMT151 = '0.00';
			   
           
		     UPDATE CD
			SET CLM_ADJ_AMT151 = '',
			    CLM_ADJ_REASON151 = '',
				CLM_ADJ_QTY151 = '',
				CLM_ADJ_GRP15 = ''
             FROM OUTB_INST_DETAIL CD,
	              #OUTB_INST_CAS IC
	         WHERE CD.CLAIM_ID = IC.CLAIM_ID
	           AND CD.CLAIM_LINE_NO  = IC.CLAIM_LINE_NO
			   AND  LTRIM(RTRIM(CD.CLM_ADJ_AMT151)) = '';


		     UPDATE CD
			 SET CLM_ADJ_AMT152 = '',
			     CLM_ADJ_REASON152 = '',
				 CLM_ADJ_QTY152 = ''
             FROM OUTB_INST_DETAIL CD,
	              #OUTB_INST_CAS IC
	         WHERE CD.CLAIM_ID = IC.CLAIM_ID
	           AND CD.CLAIM_LINE_NO= IC.CLAIM_LINE_NO
			   AND  CD.TOTAL_CHRG_AMT = '0.00'
			   AND CD.CLM_ADJ_AMT152 = '0.00';

            			
			  UPDATE CD
			  SET CLM_ADJ_AMT153 = '',
				  CLM_ADJ_REASON153 = '',
				  CLM_ADJ_QTY153 = ''
              FROM OUTB_INST_DETAIL CD,
	               #OUTB_INST_CAS IC
	          WHERE CD.CLAIM_ID = IC.CLAIM_ID
	            AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
				AND  CD.TOTAL_CHRG_AMT = '0.00'
			    AND CD.CLM_ADJ_AMT153 = '0.00';

            
			  UPDATE CD
			  SET CLM_ADJ_AMT154 = '',
				  CLM_ADJ_REASON154 = '',
				  CLM_ADJ_QTY154 = ''
              FROM OUTB_INST_DETAIL CD,
	               #OUTB_INST_CAS IC
	          WHERE CD.CLAIM_ID = IC.CLAIM_ID
	            AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
				AND  CD.TOTAL_CHRG_AMT = '0.00'
		        AND  CD.CLM_ADJ_AMT154 = '0.00';

           
		     UPDATE CD
			 SET CLM_ADJ_AMT155 = '',
			     CLM_ADJ_REASON155 = '',
				 CLM_ADJ_QTY155 = ''
             FROM OUTB_INST_DETAIL CD,
	              #OUTB_INST_CAS IC
	         WHERE CD.CLAIM_ID = IC.CLAIM_ID
	           AND CD.CLAIM_LINE_NO= IC.CLAIM_LINE_NO
			   AND  CD.TOTAL_CHRG_AMT = '0.00'
			   AND CD.CLM_ADJ_AMT155 = '0.00';

            
			  UPDATE CD
			  SET CLM_ADJ_AMT156 = '',
				  CLM_ADJ_REASON156 = '',
			      CLM_ADJ_QTY156 = ''
               FROM OUTB_INST_DETAIL CD,
	                #OUTB_INST_CAS IC
	           WHERE CD.CLAIM_ID = IC.CLAIM_ID
	             AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
				 AND  CD.TOTAL_CHRG_AMT = '0.00'
				 AND CD.CLM_ADJ_AMT156  = '0.00';

    ------------------------------------------------------
    ---- Update Run Controls
    ------------------------------------------------------
   
    SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_DETAIL);
									
	UPDATE EXT_SYS_RUNLOG
	SET END_DT = GETDATE()	
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
		,TOTAL_RECORDS = @TOTAL_RECORDS
		,ENTRYDT = GETDATE()
	WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_REMOVE_ZERO_CAS_AMTS'
	  AND END_DT IS NULL;



