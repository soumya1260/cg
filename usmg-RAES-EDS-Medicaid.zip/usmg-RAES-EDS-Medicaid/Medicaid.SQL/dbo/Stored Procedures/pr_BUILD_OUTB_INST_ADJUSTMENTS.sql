﻿CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_ADJUSTMENTS]

AS
/****************************************************************************************************************************************************
** CREATE DATE: 06/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM LINE 
**              ADJUSTMENT SEGMENTS (CAST SEGMENTS) INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------

11/09/12		LOYAL RICKS     MOVE DEDUCTIBLE ADJUSTMENT FROM GRP131 TO GRP 122
11/19/12		LOYAL RICKS		REVISED ADJUSTMENTS ALIGNING SEGEMENTS WITH APPROPRIATE GROUP CODE
11/27/12		LOYAL RICKS		REVISED USE OF TEMPDB, RENAME #INST_#INST_TMP TO #INST_#INST_TMPDEV TO ALLOW FOR MULTIPLE
								PROCESSING IN EDPS & EDPS_PROD
04/10/13		LOYAL RICKS		REMOVE ADJUSTMENT - CLM_ADJ_GRP12 = 'OA',CLM_ADJ_REASON121 = '94'
								ADD ADJUSTMENT - CLM_ADJ_GRP12 = 'CO',CLM_ADJ_REASON121 = '94' 
								OA (OVER PAYMENT) ADJUSTMENTS 
04/11/13		LOYAL RICKS		REVISE CLM_ADJ_GRP111 = 'CO',CLM_ADJ_REASON111 = '45' ADJUSTMENT SEG
								TO INCLUDE ADJUSTMENT FOR SPECIFIC NON CAP LINE
								Adjust GRP111 loop for conditional submission of Reason111 '45' and
								Reason112 '94'
05/14/13		Loyal Ricks		Add CLM_ADJ_GRP111 = 'CO',CLM_ADJ_REASON111 = '45' logic for Facets
06/03/13		Loyal Ricks		Add logic to ensure Member_Amt_paid is never populated on claim header
6/24/14			Loyal Ricks		Added evaluation for capitated line. Missing logic causing 103 edits when there is cap line. W/o logic outbound
								claim line is being submitted with both a CO-45 and CR-223. Lines should only contain CR-223 when capped. Additional 
								logic will ensure CO-45 (Contract Obligation) is not present for capitated line
07/03/14		Loyal Ricks		03/13/14 Sequestration - Add logic to CAS segment (Verisk Adj - CO) 
10/06/14		Loyal Ricks		Shift Adjustment Group 111-113 to allow adjustments to fall in order instead by Reason code due to MEDICAID requirement
									•	EDS-437	•	EDS-442 •	EDS-443
06/22/15		Loyal Ricks		Adjustment amount formatting left trim - adjust amounts - CLM_ADJ_AMT111,CLM_ADJ_AMT112,CLM_ADJ_AMT113
07/31/15		Loyal Ricks		TETDM-260 Institutional Sequestering Adjustment - CO-45 Adjustment - CLM_ADJ_AMT111 revised to include WITHHOLDAMT
08/27/15		Loyal Ricks		TETDM-321 PROD Logic Change - Balancing Fix - Paid amt greater than requested Revisions
09/09/15		Loyal Ricks		TETDM-321 - Revise logic from LTRIM(RequestedAmt - PaymentAmount ) to ltrim(requestedamt -  ELIGIBLEFEEAMT)
09/09/15		Loyal Ricks		TETDM-321 - Revise logic from ltrim(requestedamt -  ELIGIBLEFEEAMT) to ltrim(paymentamount - requestedamt )
09/20/15		Loyal Ricks		TETDM-321 - Revise logic for OTH_PAYER1_PAID_AMT to - (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)
09/21/15		Loyal Ricks		tetdm-321 Claim Header AMOUNT_PAID (OUTB_INST_HEADER.AMONT_PAID) adjustments
09/29/15		Loyal Ricks		TETDM-321 - Revise logic to check for claimdetaildim.withholdamt = 0 for overpayment only.
10/01/15		Loyal Ricks		TETDM-321 - -->>>> Removal of claim header paid_amt adjustment for sequestration (withholdamt > 0)--->>>>logic creates a mismatch with QNXT
10/15/15		Loyal Ricks		TETDM-321 - Revise logic changine Adjustment Group Code from CO to OA and applying negative amount to Adjustment Amount
12/01/15		Loyal Ricks		TETDM-550 - 12/1/15 Commenting out this logic and adding CO-24 to support Institutional Cap payment submissions (TETDM-550)
07/27/16		Loyal Ricks		TETDM-548 - Revise logic to exclude withhold amount in over payment segment when withholdamt > 0
08/01/16		Loyal Ricks		TETDM-917 Revise to exclude Facets claims (sdk-30)
08/01/16		Loyal Ricks		TETDM-917 Remove withholdamt from CLM_ADJ_AMT111 equation
09/06/16		Loyal Ricks		TETDM-917 Missed logic for capitation which needed to get put in "and cd.CAPITATEDLINEFLAG <> 'Y'"
04/10/16        John Bartholomay TETDM-548 Change to QA-94 logic for QNXT
08/07/2017		Subhash Acharya TETDM-1523 Account for negative amount
09/19/2017		Subhash Acharya TETDM-1523 reverting the changes
11/07/2017      John Bartholomay TETDM-1636  Exclude Adjustemts on CO where equal to (zero)
04/10/2018      John Bartholomay TETDM-1685 Check for 0.00 dollar amount PR Segment
05/24/2019      Aaron Ridley	 TETDM-1943 CAS segments Balancing Denied Lines with Billed Amount = .01	
2021-26-08		Anthony Ulmer	MES-133 Update to implement transfer to Medicaid database
*****************************************************************************************************************************************************/	
	--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM OUTB_INST_DETAIL_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT;
		


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_INST_ADJUSTMENTS'
				,'7'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				);


					IF OBJECT_ID('TEMPDB..#INST_TMPDEV_CLMCAP') <> 0
							DROP TABLE #INST_TMPDEV_CLMCAP;
		
							Create Table #INST_TMPDEV_CLMCAP
 							(CLAIMID VARCHAR(20),
							 CLAIMLINEID VARCHAR(5),
							 CAP_AMT MONEY,
							 QUANTITY INT
							 );

				--UPDATE CLM_ADJ_GRP5 INFORMATION - PROVIDER CAPITATION
				--CALCULATE CAPITATED AMOUNT
				--USE ALSO TO DETERMINE WHETHER CLM_ADJ_GRP1 'CO' SHOULD BE POPULATED
				INSERT INTO #INST_TMPDEV_CLMCAP
				SELECT CLAIMID,CLAIMLINEID,SUM(CD.RequestedAmt - CD.PAYMENTAMOUNT - CD.COBAMT - CD.DEDUCTIBLEAMT - CD.COPAYAMT - CD.COINSURANCEAMT) as 'CAP_AMT',Quantity
				--INTO  #INST_TMPDEV_CLMCAP
				FROM Medicaid.dbo.claimdetaildim CD
				INNER JOIN OUTB_INST_HEADER IH
				ON CD.SOURCEDATAKEY = IH.SOURCEDATAKEY 
				AND CD.CLAIMID = IH.CLAIM_ID 
				--WHERE CAPITATEDLINEFLAG = 'Y'   --commeted out for tetdm-1943
				GROUP BY ClaimID,ClaimLineID,Quantity;

	--UPDATE CLM_ADJ_GRP1 INFORMATION - CONTRACT ADJUSTMENT
	--REVISED LOGIC 7/5/12 BASED ON HRP CALL. CO AMOUNT SHOULD EQUAL CONTRACTED WRITE OFF AMOUNT
	--POTENTIAL FIX LOGIC REMOVED DUE TO EMAIL FROM K.DEHNKE VALIDATING THE USE OF MAXFEEAMT
	--POTENTIAL FIX LOGIC WAS --LTRIM(RequestedAmt - MAXFEEAMT - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt)
	--ADJUSTED BACK TO ORIGINAL LOGIC FROM 6/15
	--7/19/13 ADD CHECK TO ONLY APPLY UPDATE WHEN CLAIM IS NOT CAPITATED
	--6/24/14 Added evaluation for capitated line. Missing logic causing 103 edits when there is cap line. W/o logic outbound
	--	claim line is being submitted with both a CO-45 and CR-223. Lines should only contain CR-223 when capped. Additional 
	--logic will ensure CO-45 (Contract Obligation) is not present for capitated line
	--07/31/15-TETDM-260 Sequestering Logic Revision - CLM_ADJ_AMT111 revised to include WITHHOLDAMT
	--08/01/16-TETDM-917 Revise to exclude Facets claims (sdk-30)
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 = 'CO'
					,CLM_ADJ_REASON111 = '45'
					,CLM_ADJ_AMT111 = LTRIM(RequestedAmt - PaymentAmount - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt -WITHHOLDAMT )
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY111 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				JOIN Medicaid.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND  CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE (RequestedAmt - PaymentAmount - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt - WITHHOLDAMT) <> 0  --1523
						and ec.sourcedatakey <> 30 --and CONTRACT_type <> '05'
						--and cd.CAPITATEDLINEFLAG <> 'Y' -- Aaron - TETDM-1943 
						--AND rtrim(CLAIM_ID)+''+rtrim(CLAIM_LINE_NO) NOT IN (SELECT rtrim(ClaimID)+''+rtrim(CLAIMLINEID) FROM #INST_TMPDEV_CLMCAP)		
				        AND (RequestedAmt - PaymentAmount - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt -WITHHOLDAMT ) <> 0; --1636
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				----FACETS CO-45 ADJUSTMENT
				--07/31/15-TETDM-260 Sequestering Logic Revision - CLM_ADJ_AMT111 revised to include WITHHOLDAMT
				--08/01/16-TETDM-917 Remove withholdamt from CLM_ADJ_AMT111 equation
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 = 'CO'
					,CLM_ADJ_REASON111 = '45'
					,CLM_ADJ_AMT111 = LTRIM(RequestedAmt - PaymentAmount - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt )--- WITHHOLDAMT)
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY111 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN Medicaid.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE (RequestedAmt - PaymentAmount - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt) > 0
				AND		EC.SOURCEDATAKEY = 30
				--and cd.CAPITATEDLINEFLAG <> 'Y'-- Aaron - TETDM-1943 
				AND (RequestedAmt - PaymentAmount - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt ) <> 0; --1636
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				-----OTHER ADJUSTMENTS - WHEN TOTAL PAID AMOUNTS EXCEED TOTAL CHARGES
				--TETDM-321 - Revise logic for OTH_PAYER1_PAID_AMT to - (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)
				--TETDM-321 - Revise logic to check for claimdetaildim.withholdamt = 0 for overpayment only.
				--TETDM-321 - Revise logic changing Adjustment Group Code from CO to OA and applying negative amount to Adjustment Amount
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = 'OA'
					,CLM_ADJ_REASON121 = '94'
					,CLM_ADJ_AMT121 = ltrim(requestedamt - (paymentamount + withholdamt + cobamt + deductibleamt + copayamt + coinsuranceamt)) ---replaced 10/15/15 ltrim(paymentamount - requestedamt ) 
					--,OTH_PAYER1_PAID_AMT = (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)
					-- REVISED 09/09/15 replaced with above formula LTRIM(RequestedAmt - PaymentAmount )
					-- revised 08/27/15 TETDM-321 ,CLM_ADJ_AMT112 = LTRIM(RequestedAmt - (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)) 
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY112 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN Medicaid.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND CD.SOURCEDATAKEY IN (50)
				AND CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE RequestedAmt < (PaymentAmount + COBAmt + CoInsuranceAmt + withholdamt + DeductibleAmt + CoPayAmt) --added withhold 04/18/17
		    	  AND cd.WITHHOLDAMT = 0; 
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT

		        --TETDM-548 begin SDK = 30
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = 'OA'
					,CLM_ADJ_REASON121 = '94'
					,CLM_ADJ_AMT121 = ltrim(requestedamt - (paymentamount + cobamt + deductibleamt + copayamt + coinsuranceamt))
					,CLM_ADJ_QTY112 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN Medicaid.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY
				AND CD.SOURCEDATAKEY IN (30)
				AND CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE RequestedAmt < (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)
						and cd.WITHHOLDAMT = 0;
				--IF @@ERROR <> 0
				--TETDM-548 end

				--SET ROWCOUNT 5

				
				---tetdm-321 Claim Header AMOUNT_PAID (OUTB_INST_HEADER.AMONT_PAID) adjustments
				--TETDM-321 - Revise logic to check for claimdetaildim.withholdamt = 0 for overpayment only.
				IF OBJECT_ID('TEMPDB..#TMP_ADJ_PAY') <> 0
							DROP TABLE #TMP_ADJ_PAY;

				SELECT CLAIMID,SUM(PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt) AS 'AMOUNT_PAID'
				INTO #TMP_ADJ_PAY
				FROM Medicaid.DBO.CLAIMDETAILDIM CD
				INNER JOIN OUTB_INST_HEADER H
				ON CD.SOURCEDATAKEY = H.SOURCEDATAKEY 
				AND CD.CLAIMID = H.CLAIM_ID 
				WHERE  CD.RequestedAmt < (CD.PaymentAmount + CD.COBAmt + CD.CoInsuranceAmt + CD.DeductibleAmt + CD.CoPayAmt) 
					and cd.WITHHOLDAMT = 0
				  GROUP BY CLAIMID;

				  UPDATE OUTB_INST_HEADER
				  SET AMOUNT_PAID = T.AMOUNT_PAID 
				  FROM OUTB_INST_HEADER OH
				  INNER JOIN #TMP_ADJ_PAY T
				  ON OH.CLAIM_ID =T.CLAIMID; 

				--Negative amount formatting for CAS segment submissions
				--TETDM-321 Remove change of negative amount to positive
				-- update OUTB_INST_DETAIL
				--set CLM_ADJ_AMT112 = LTRIM(convert(money,CLM_ADJ_AMT112) * -1)
				-- from OUTB_INST_DETAIL
				--where CLM_ADJ_AMT112 <> ' '
				/*		REMOVED 4/10/13 OA ARE NOT OVER PAYMENT, THEY ARE CONTRACTED AMOUNTS	
							BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = 'OA'
					,CLM_ADJ_REASON121 = '94'
					,CLM_ADJ_AMT121 = LTRIM(RequestedAmt - (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt))
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY121 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				JOIN MEDICAID.dbo.claimdetaildim CD
				ON CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE RequestedAmt < (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)
				IF @@ERROR <> 0
					BEGIN 
							ROLLBACK 
					END
				COMMIT
				*/
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET /*CLM_ADJ_GRP111 = ' '
					,*/CLM_ADJ_REASON111 = ' '
				WHERE LEN(CLM_ADJ_AMT111) = 0;
						--AND LEN(CLM_ADJ_REASON112) = 0
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK
				--	END
				--COMMIT
				----REMOVE CLM_ADJ_GRP111 WHEN 
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 = ' '
					,CLM_ADJ_REASON111 = ' '
					,CLM_ADJ_REASON112 = ' '
				WHERE LEN(CLM_ADJ_AMT111) = 0
						AND LEN(CLM_ADJ_AMT112) = 0;
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK
				--	END
				--COMMIT
				
				----RESET CLM_ADJ_GRP12 WHEN NOT USED
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = ' '
					,CLM_ADJ_REASON121 = ' '
				WHERE LEN(CLM_ADJ_AMT121) = 0;
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK
				--	END
				--COMMIT
				--	-- Note:
				---- 03/13/14		Loyal Ricks		Sequestration
				----
				--	---OTHER ADJUSTMENTS - WHEN TOTAL PAID AMOUNTS EXCEED TOTAL CHARGES
				--09/29/15 - Revise paid_amt when sequestration --> ,OTH_PAYER1_PAID_AMT = (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)
				--BEGIN TRANSACTION 

				--09/29/15 ---sequestration over payment
				--09/29/15-->>>>> Should withholdamt required in where criteria? Will excluding this make a difference amongst claim scenarios
				---09/30/15 --->>>>> Revised CLM_ADJ_AMT112 --->>>>ltrim(PaymentAmount - requestedamt)
				--TETDM-321 - Revise logic changine Adjustment Group Code from CO to OA and applying negative amount to Adjustment Amount
				--TETDM-548 - Revise logic to exclude withhold amount in over payment segment when withholdamt > 0
				
				-----------------------------------------------------
				--TETDM-548 JAB ADDITIONAL CHANGE FOR SEQUESTRATION FOR QNXT AND FACETS
				-- QNXT
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = 'OA'
					,CLM_ADJ_REASON121 = '94'
					,CLM_ADJ_AMT121 =ltrim(requestedamt - (paymentamount + withholdamt + cobamt + deductibleamt + copayamt + coinsuranceamt))
					--Revised 10/15/15 ltrim(PaymentAmount - requestedamt)
					-- REVISED 09/09/15 replaced with above formula LTRIM(RequestedAmt - PaymentAmount )
					-- revised 08/27/15 TETDM-321 ,CLM_ADJ_AMT112 = LTRIM(RequestedAmt - (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)) 
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY112 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN Medicaid.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE RequestedAmt < (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt) -- OVER PAYMENT TRIGGER
						and cd.WITHHOLDAMT > 0 --SEQ TRIGGER
						AND EC.SOURCEDATAKEY = 50;

                ----------------------------------------------------------------
				-- TETDM-548 FACETS SEQUESTRATION
				-- FACETS
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = 'OA'
					,CLM_ADJ_REASON121 = '94'
					,CLM_ADJ_AMT121 =ltrim(requestedamt - (paymentamount  + cobamt + deductibleamt + copayamt + coinsuranceamt))
					--Revised 10/15/15 ltrim(PaymentAmount - requestedamt)
					-- REVISED 09/09/15 replaced with above formula LTRIM(RequestedAmt - PaymentAmount )
					-- revised 08/27/15 TETDM-321 ,CLM_ADJ_AMT112 = LTRIM(RequestedAmt - (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)) 
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY112 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN Medicaid.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE RequestedAmt < (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt) -- OVER PAYMENT TRIGGER
						and cd.WITHHOLDAMT > 0 --SEQ TRIGGER
						AND EC.SOURCEDATAKEY = 30;

				---09/30/15 --->>>>> Revised CLM_ADJ_AMT112 --->>>>ltrim(PaymentAmount - requestedamt)
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 = 'CO'
					,CLM_ADJ_REASON113 = '253'
					,CLM_ADJ_AMT113 = LTRIM(cd.WITHHOLDAMT)
					
					--LTRIM(RequestedAmt - ((PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)+ WITHHOLDAMT))
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY113 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN Medicaid.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE convert(money, cd.WITHHOLDAMT) > 0;
				--RequestedAmt < (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)
				--	and cd.WITHHOLDAMT > 0
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT

			
				---->>>>>>>>>>>>>>09/29/15
				---tetdm-321 Claim Header AMOUNT_PAID (OUTB_INST_HEADER.AMONT_PAID) adjustments
				--TETDM-321 - Revise logic to check for claimdetaildim.withholdamt > 0 for overpayment only.
				-->>>> Removal of claim header paid_amt adjustment --->>>>logic creates a mismatch with QNXT
				--SELECT CLAIMID,SUM(PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt + WITHHOLDAMT) AS 'AMOUNT_PAID'
				--INTO #TMP_ADJ_PAY_SEQ
				--FROM MEDICAID.DBO.CLAIMDETAILDIM CD
				--INNER JOIN OUTB_INST_HEADER H
				--ON CD.SOURCEDATAKEY = H.SOURCEDATAKEY 
				--AND CD.CLAIMID = H.CLAIM_ID 
				--WHERE  CD.RequestedAmt < (CD.PaymentAmount + CD.COBAmt + CD.CoInsuranceAmt + CD.DeductibleAmt + CD.CoPayAmt) 
				--	and cd.WITHHOLDAMT > 0
				--  GROUP BY CLAIMID

				--  UPDATE OUTB_INST_HEADER
				--  SET AMOUNT_PAID = T.AMOUNT_PAID 
				--  FROM OUTB_INST_HEADER OH
				--  INNER JOIN #TMP_ADJ_PAY_SEQ T
				--  ON OH.CLAIM_ID =T.CLAIMID 

				  ---tetdm-321 Claim DETAIL AMOUNT_PAID (OUTB_INST_DETAIL.OTH_PAYER1_PAID_AMT) adjustments
				--TETDM-321 - Revise logic to check for claimdetaildim.withholdamt > 0 for overpayment only.
				--IF OBJECT_ID('TEMPDB..#TMP_ADJ_PAY_SEQ_DTL') <> 0
				--			DROP TABLE #TMP_ADJ_PAY_SEQ_DTL

				--  SELECT CLAIMID,CLAIMLINEID,SUM(PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt + WITHHOLDAMT) AS 'AMOUNT_PAID'
				--INTO #TMP_ADJ_PAY_SEQ_DTL
				--FROM MEDICAID.DBO.CLAIMDETAILDIM CD
				--INNER JOIN OUTB_INST_HEADER H
				--ON CD.SOURCEDATAKEY = H.SOURCEDATAKEY 
				--AND CD.CLAIMID = H.CLAIM_ID 
				--WHERE  CD.RequestedAmt < (CD.PaymentAmount + CD.COBAmt + CD.CoInsuranceAmt + CD.DeductibleAmt + CD.CoPayAmt) 
				--	and cd.WITHHOLDAMT > 0
				--  GROUP BY CLAIMID,CLAIMLINEID

				--  UPDATE OUTB_INST_DETAIL
				--  SET OTH_PAYER1_PAID_AMT = T.AMOUNT_PAID 
				--  FROM OUTB_INST_DETAIL OH
				--  INNER JOIN #TMP_ADJ_PAY_SEQ_DTL T
				--  ON OH.CLAIM_ID =T.CLAIMID 
				--  AND OH.CLAIM_LINE_NO = T.CLAIMLINEID
				 

				--Negative amount formatting for CAS segment submissions
				--TETDM-321 removal of change of negative amount to positive
				-- update OUTB_INST_DETAIL
				--set CLM_ADJ_AMT112 = LTRIM(convert(money,CLM_ADJ_AMT112) * -1)
				-- from OUTB_INST_DETAIL
				--where CLM_ADJ_AMT112 <> ' '


							
				--BEGIN TRANSACTION 
				
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
									
				--begin transaction
					update OUTB_INST_DETAIL
					set CLM_ADJ_AMT113 = ' '
					where CLM_ADJ_REASON113 <> '253';
				--	IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				--	--UPDATE CLM_ADJ_GRP2 INFORMATION - COPAY ADJUSTMENT
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP13 = 'PR'
					,CLM_ADJ_REASON131 = '3'
					,CLM_ADJ_AMT131 = LTRIM(COPAYAMT)
					,CLM_ADJ_QTY131 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN Medicaid.dbo.claimdetaildim CD
				 ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				 AND EC.CLAIM_ID = CD.CLAIMID
				AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
					WHERE CD.COPAYAMT <> '0.00';	
				--				IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				----UNIT TEST FIX DUE TO ABOVE UPDATE, UPDATING RECORDS WITH ZERO COPAYAMT
				--BEGIN TRANSACTION 
					UPDATE OUTB_INST_DETAIL
					SET CLM_ADJ_GRP13 = ' '
							,CLM_ADJ_REASON131 = ' '
							,CLM_ADJ_AMT131 = ' '
					WHERE CLM_ADJ_AMT131 = '0.00';
				--	IF @@ERROR <> 0
				--		BEGIN 
				--			ROLLBACK
				--		END
				--COMMIT
				--	--UPDATE CLM_ADJ_GRP3 INFORMATION - DEDUCTIBLE ADJUSTMENT
				--	--11/09/12 - MOVE DEDUCTIBLE ADJUSTMENT FROM GRP131 TO GRP 122
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP13 = 'PR'
					,CLM_ADJ_REASON132 = '1'
					,CLM_ADJ_AMT132 = LTRIM(CD.DEDUCTIBLEAMT)
					,CLM_ADJ_QTY132 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN Medicaid.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND  EC.CLAIM_ID = CD.CLAIMID
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
				WHERE CD.DEDUCTIBLEAMT <> '0.00';
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				--		--UPDATE CLM_ADJ_GRP4 INFORMATION - COINSURANCE ADJUSTMENT
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP13 = 'PR'
					,CLM_ADJ_REASON133 = '2'
					,CLM_ADJ_AMT133 = LTRIM(CD.COINSURANCEAMT)
					,CLM_ADJ_QTY133 = QUANTITY
				FROM OUTB_INST_DETAIL EC
					,Medicaid.dbo.claimdetaildim CD
				WHERE EC.CLAIM_ID = CD.CLAIMID
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
					AND CD.COINSURANCEAMT <> '0.00';
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				----UPDATE CLM_ADJ_GRP5 INFORMATION - PROVIDER CAPITATION
				--BEGIN TRANSACTION 
				--7/17/15 BALANCING TEST
				--12/1/15 Commenting out this logic and adding CO-24 to support Institutional Cap payment submissions (TETDM-550)
				
				--UPDATE OUTB_INST_DETAIL
				--SET CLM_ADJ_GRP15 = 'CR'
				--	,CLM_ADJ_REASON151 = '223'
				--	,CLM_ADJ_AMT151 = LTRIM(CAP_AMT)
				--	,CLM_ADJ_QTY151 = QUANTITY
				--	,OTH_PAYER1_PAID_AMT = ltrim((OTH_PAYER1_PAID_AMT - cap_amt))
				--FROM OUTB_INST_DETAIL EC
				--	,#INST_TMPDEV_CLMCAP CD
				--WHERE EC.CLAIM_ID = CD.CLAIMID
				--	AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
				--	--AND EC.CONTRACT_CODE = '05'
				--	AND TOTAL_CHRG_AMT <> OTH_PAYER1_PAID_AMT
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT	
				--TETDM-274 Individual Line Capitation 
				--TETDM-358 Captiated Claims with $0 CAS Segement 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP15 = 'CO'
					,CLM_ADJ_REASON151 = '24'
					,CLM_ADJ_AMT151 = LTRIM(CAP_AMT)
					,CLM_ADJ_QTY151 = CD.QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN Medicaid.dbo.claimdetaildim CLMD
				ON EC.SOURCEDATAKEY = CLMD.SOURCEDATAKEY 
				AND CLAIM_ID = CLMD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CLMD.ClaimLineID)
				inner join #INST_TMPDEV_CLMCAP CD
				on		ec.claim_id =cd.claimid 
				AND		EC.CLAIM_LINE_NO = CD.CLAIMLINEID
				inner join OUTB_INST_HEADER EH
				ON EH.CLAIM_ID = CD.CLAIMID 
				WHERE convert(money, cap_amt) > 0  
				AND EC.CLM_ADJ_GRP111 <> 'CO'AND EC.CLM_ADJ_REASON111 <> '45'; -- 1943 Update 

					

				----RESET OTH_PAYER1_PAID_AMT & OTH_PAYER1_PAID_QTY WHEN OTH_PAYER1_PAID_AMT = 0
				----remove code, 7/18 ONSITE HRP SESSION FINDINGS THERE MUST ALWAYS BE AN AMOUNT
				----IN OTH_PAYER11_PAID_AMT DEFAULT = 0.00
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET OTH_PAYER1_PAID_AMT = '0.00'
					--,OTH_PAYER1_PAID_QTY = ' '
				WHERE (OTH_PAYER1_PAID_AMT = '0.00' OR LEN(OTH_PAYER1_PAID_AMT) = 0 );
					--AND CONTRACT_CODE = '05'
				--		IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT	
				
				--MAKE SURE MEMBER_AMT_PAID ON CLAIM HEADER IS NEVER SUBMITTED FOR PROFESSIONAL CLAIMS
				--SUBMITTING A VALUE WILL RESULT IN 103 REJECTIONS
				
				
		
						UPDATE OUTB_INST_HEADER
						SET MEMBER_AMT_PAID = ' '
						WHERE LEN(MEMBER_AMT_PAID) > 0;
					
					--Shift Segment 132 to 131 when 131 segment is not present

							
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON131 = CLM_ADJ_REASON132,
										CLM_ADJ_AMT131 = ltrim(CLM_ADJ_AMT132),
										CLM_ADJ_QTY131 = CLM_ADJ_QTY132,
										CLM_ADJ_REASON132 = ' ',
										CLM_ADJ_AMT132 = ' ',
										CLM_ADJ_QTY132 = ' '
									WHERE (LEN(CLM_ADJ_REASON131) = 0
										AND LEN(CLM_ADJ_REASON132) > 0);
							
							--Shift Segment 133 to 132 when 132 segment is not present
							 
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON132 = CLM_ADJ_REASON133,
										CLM_ADJ_AMT132 = ltrim(CLM_ADJ_AMT133),
										CLM_ADJ_QTY132 = CLM_ADJ_QTY133,
										CLM_ADJ_REASON133 = ' ',
										CLM_ADJ_AMT133 = ' ',
										CLM_ADJ_QTY133 = ' '
									WHERE LEN(CLM_ADJ_REASON132) = 0
										AND LEN(CLM_ADJ_REASON133) > 0;
							

						----Shift Segment 112 to 111 when 111 segment is not present

						
						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON111 = CLM_ADJ_REASON112,
							CLM_ADJ_AMT111 = ltrim(CLM_ADJ_AMT112),
							CLM_ADJ_QTY111 = CLM_ADJ_QTY112
						WHERE LEN(CLM_ADJ_REASON111) = 0;

						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON112 =' ',
							CLM_ADJ_AMT112 = ' ',
							 CLM_ADJ_QTY112 = ' '
						WHERE CLM_ADJ_REASON111 = CLM_ADJ_REASON112
							 AND CLM_ADJ_AMT111 = CLM_ADJ_AMT112;
					

						----Shift Segment 113 to 111 when 111 segment is not present
						 
						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON111 = CLM_ADJ_REASON113,
							CLM_ADJ_AMT111 = ltrim(CLM_ADJ_AMT113),
							CLM_ADJ_QTY111 = CLM_ADJ_QTY113
						WHERE LEN(CLM_ADJ_REASON111) = 0;

						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON113 =' ',
							CLM_ADJ_AMT113 = ' ',
							 CLM_ADJ_QTY113 = ' '
						WHERE CLM_ADJ_REASON111 = CLM_ADJ_REASON113
							 AND CLM_ADJ_AMT111 = CLM_ADJ_AMT113;
						

						----Shift Segment 113 to 111 when 111 segment is not present
						
						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON112 = CLM_ADJ_REASON113,
							CLM_ADJ_AMT112 = ltrim(CLM_ADJ_AMT113),
							CLM_ADJ_QTY112 = CLM_ADJ_QTY113
						WHERE LEN(CLM_ADJ_REASON111) > 0
							and LEN(CLM_ADJ_REASON112) = 0;

						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON113 =' ',
							CLM_ADJ_AMT113 = ' ',
							 CLM_ADJ_QTY113 = ' '
						WHERE CLM_ADJ_REASON112 = CLM_ADJ_REASON113
							 AND CLM_ADJ_AMT112 = CLM_ADJ_AMT113;
				

/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/
				
				UPDATE A
				SET A.CLM_ADJ_AMT111 = LTRIM(cd.WITHHOLDAMT)
				,a.CLM_ADJ_REASON111 = '253'
				,a.CLM_ADJ_QTY111 = Quantity
				--SELECT a.CLM_ADJ_AMT111, a.CLAIM_ID,b.CLM_ADJ_AMT121, b.CLAIM_ID,* 
				,a.CLM_ADJ_GRP111 = 'CO'
				--======================
				--,CLM_ADJ_GRP111 = ''
				,CLM_ADJ_REASON112 = ''
				,CLM_ADJ_AMT112 = ''
				,CLM_ADJ_QTY112 = ''
				--======================
				FROM OUTB_INST_DETAIL a --MES-133 removed MEDICAID reference
				JOIN OUTB_INST_DETAIL b --MES-133 removed MEDICAID reference
					ON b.CLAIM_ID = a.CLAIM_ID
					INNER JOIN Medicaid.dbo.claimdetaildim CD
				ON a.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND a.CLAIM_ID = CD.ClaimID
				AND LTRIM(a.CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE a.CLM_ADJ_GRP111 = 'CO'
					AND a.CLM_ADJ_REASON111 = '45'
					AND CONVERT(FLOAT,a.CLM_ADJ_AMT111) < 0
					AND a.SOURCEDATAKEY = 50
					AND b.CLM_ADJ_GRP12 = 'OA'
					AND b.CLM_ADJ_REASON121 = '94'
					AND CONVERT(FLOAT,b.CLM_ADJ_AMT121) < 0 
					AND b.SOURCEDATAKEY = 50
					AND CONVERT(FLOAT,a.CLM_ADJ_AMT111) = CONVERT(FLOAT,b.CLM_ADJ_AMT121) 
					AND	CONVERT(MONEY, cd.WITHHOLDAMT) > 0;


						--Negative amount formatting for CAS segment submissions
						--1523 commenting out the multiply by negative -1 for amount less then zero since we do wwant to submit -ve amount
						/*
						 update OUTB_INST_DETAIL
						set CLM_ADJ_AMT111 = LTRIM(convert(money,CLM_ADJ_AMT111) * -1)
						 from OUTB_INST_DETAIL
						where  CONVERT(MONEY, CLM_ADJ_AMT111) < 0

						 update OUTB_INST_DETAIL
						set CLM_ADJ_AMT112 = LTRIM(convert(money,CLM_ADJ_AMT112) * -1)
						 from OUTB_INST_DETAIL
						where  CONVERT(MONEY, CLM_ADJ_AMT112) < 0

						 update OUTB_INST_DETAIL
						set CLM_ADJ_AMT113 = LTRIM(convert(money,CLM_ADJ_AMT113) * -1)
						 from OUTB_INST_DETAIL
						where  CONVERT(MONEY, CLM_ADJ_AMT113) < 0
						*/


				---07/09/12 UPDATE CLAIM ADJUSTMENT GROUP FOR 'PR' ADJUSTMENT
				---ADJUSTMENT GROUPS GRP12 - GRP14 ARE 'PR' AND SHOULD ONLY HAVE 1 GROUP CODE SUBMITTED PER SEGMENT
				--SET CLM_ADJ_GRP13 WHEN GRP12 IS NOT POPULATED
			/*	BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP13 = 'PR'
				FROM OUTB_INST_DETAIL EC
					,MEDICAID.dbo.claimdetaildim CD
				WHERE EC.CLAIM_ID = CD.CLAIMID
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
					AND CD.DEDUCTIBLEAMT <> 0.00
					AND CLM_ADJ_GRP12 <> 'PR'
					IF @@ERROR <> 0
					BEGIN 
							ROLLBACK 
					END
				COMMIT	
				--SET CLM_ADJ_GRP14 WHEN GRP12 & GRP13 IS NOT POPULATED
				BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP14 = 'PR'
				FROM OUTB_INST_DETAIL EC
					,MEDICAID.dbo.claimdetaildim CD
				WHERE EC.CLAIM_ID = CD.CLAIMID
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
					AND CD.COINSURANCEAMT <> 0.00
					AND CLM_ADJ_GRP12 <> 'PR'
					AND CLM_ADJ_GRP13 <> 'PR'
					IF @@ERROR <> 0
					BEGIN 
							ROLLBACK 
					END
				COMMIT	*/
				--MHC PENALTY PAYMENT UPDATES
				/*
				BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = 'OA'
						,CLM_ADJ_REASON122 = '225'
					,CLM_ADJ_AMT122 = OTH_PAYER1_PAID_AMT
					,OTH_PAYER1_PROC_CD = ' '
					,SERV_ID_QUAL = ' '
					,PROC_CD = ' '
				FROM OUTB_INST_DETAIL
				WHERE PROC_CD = '0L6'
				COMMIT*/
				--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_INST_DETAIL_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_DETAIL);
									
		----HRP_CLAIM_FILE Update Run Controls
				--BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_INST_ADJUSTMENTS'
								AND END_DT IS NULL;							
						--	IF @@ERROR <> 0
						--				BEGIN 
						--						ROLLBACK 
						--				END
						--COMMIT
						











