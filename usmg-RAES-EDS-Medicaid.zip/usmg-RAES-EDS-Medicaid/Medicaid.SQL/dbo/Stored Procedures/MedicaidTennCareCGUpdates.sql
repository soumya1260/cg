﻿



/*********************************************************************************************************************************
Procedure:		MedicaidTennCareCGUpdates

Author:			Aaron Ridley

Date:			10/27/2021 

Purpose:		Populate TENNCARE Companion Guide Specific Updates. This script will overrite the specified records in the associated CSV tables 

Job:            EDIFECS TennCare Medicaid (Executed in File sprocs) 

History:		Date	  Author  HPSM    		Action									

03/23/2022    RTM-4  Henry Faust  Update CAS segment logic, remove c.EligibleFeeAmt < c.RequestedAmt
04/25/2022    RTM-5  Aaron Ridley Updates applied to resolve issue with the population of the Rendering/Attending Provider data and to fix the truncation of Pharmacy Units of Measure

Test Script:	


*********************************************************************************************************************************/
--/*

CREATE PROCEDURE [dbo].[MedicaidTennCareCGUpdates] 

    @CLAIM_TYPE varchar(2),
    @JobID int

AS
/*********************************************************************************************************************************/


/* Start Process  */ 


INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('dbo.MedicaidTennCareCGUpdates' + '-'  + rtrim(@CLAIM_TYPE)
				,'2'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)

/* IDENTIFY MOST CURRENT BILLING PROVIDER RECORD  */ 

	
SELECT DISTINCT  vd.* 
INTO #VENDORDIM
from dbo.VendorDim vd
INNER JOIN (select NationalProviderID,  max(loaddatekey) as LOADDATEKEY from dbo.VendorDim where sourcedatakey = '50' group by NationalProviderID) as sub on vd.NationalProviderID = sub.NationalProviderID and vd.LoadDateKey = sub.LOADDATEKEY
where SourceDataKey = '50'


----CLAIM Detail Build for Institutional Claims 

IF OBJECT_ID('tempdb.dbo.#CLAIMSPROV') IS NOT NULL
			DROP TABLE #CLAIMSPROV

			
		IF @CLAIM_TYPE = 'I'
		BEGIN 
		SELECT
						DISTINCT 
						CLMAgg.ClaimID, -- CLAIM_ID
						CLMDetail.ClaimLineID, -- CSVDETAIL.ClaimLineNumber
						CLMAgg.SourceDataKey, -- SOURCEDATAKEY
						CASE WHEN CLMAgg.FormTypeCode ='U' THEN 'I' ELSE 'P' END AS ClaimType,
						CLMAgg.MemberID,
						--CDD.ProcedureCode,
						CLMDetail.PaymentAmount,						
						CLMDetail.PaidDateKey,
						CLMDetail.RequestedAmt,			
						CLMDetail.DeductibleAmt, -- 431 - 2430_CAS06_ClaimAdjustmentAmount_1
						CLMDetail.CoPayAmt, -- 431 - 2430_CAS03_ClaimAdjustmentAmount_1
						CLMDetail.CoInsuranceAmt, -- 431 - 2430_CAS09_ClaimAdjustmentAmount_1
						CLMDetail.WithholdAmt,
						CLMDetail.ItemDiscountAmt,			
						CLMDetail.EligibleFeeAmt,
						--CLMAgg.PROVIDERNPI,
						CLMDim.VENDORNPI,
						CLMProv.NPI as CLAIMPROVNPI,
						CLMDetail.VendorID,
						--CLMDim.PCPID, 
						CLMAgg.PROVIDERID, 
						CLMAgg.ATTENDINGPHYSICIANID,
						CLMProv.[ProvFirstName] as CLAIMPROVFIRSTNAME,
						CLMProv.[ProvLastName] AS CLAIMPROVLASTNAME,
						CLMProv.[PhysTypeQualifier] AS CLAIMPROVPHYSTYPE,
						CLMDetail.Quantity,
						CLMDetail.ServicePlaceCode,
						CLMDetail.BeginServiceDateKey, -- 2400I_DTP03_Date (first eight)
						CLMDetail.EndServiceDateKey, -- 2400I_DTP03_Date (last eight) 
						CLMDetail.ContractID,
						CLMDetail.MaxFeeAmt,
						CLMDetail.Deleted,
						CLMDetail.Active,
						CONVERT (varchar(8),CLMDim.DateReceivedKey)as FILEINFO,
						CASE
							WHEN CLMDim.PreviousClaimID IN ('N/A', 'UNKNOWN') AND
									SUBSTRING(ub921.BillTypeCode, 3, 1) IS NULL THEN '1'
							WHEN CLMDim.PreviousClaimID IN ('N/A', 'UNKNOWN') AND
									SUBSTRING(ub921.BillTypeCode, 3, 1) IN  ('7', '8') THEN '1'
							ELSE ISNULL(SUBSTRING(ub921.BillTypeCode, 3, 1),'1')
							END AS ClaimFrequencyCode,
							CLMDetail.ProcedureCode
		INTO #CLAIMSPROV
		FROM dbo.EE_CSV_150I_Rec_Header CSVHeader
		INNER JOIN dbo.ClaimAgg CLMAgg ON CLMAgg.CLAIMID = CSVHeader.CLAIMID 
		INNER JOIN dbo.ClaimDim CLMDim ON CLMDim.CLAIMID = CSVHeader.CLAIMID 
		INNER JOIN dbo.ClaimDetailDim CLMDetail ON CLMDetail.CLAIMID = CLMAgg.CLAIMID --AND CSVDETAIL.CLAIMLINENUMBER = CSVCOBDETAIL.CLAIMLINENUMBER
		LEFT JOIN qnxt.ClaimProv CLMProv on CLMAgg.CLAIMID = CLMProv.CLAIMID 
		LEFT JOIN dbo.UB921AdmissionDim ub921 ON ub921.ClaimID = CSVHeader.ClaimID AND ub921.SourceDataKey = CSVHeader.SourceDataKey
		END;



		----CLAIM Detail Build for Professional Claims 
	
		IF @CLAIM_TYPE = 'P'
		BEGIN 
		SELECT
						DISTINCT 
						CLMAgg.ClaimID, -- CLAIM_ID
						CLMDetail.ClaimLineID, -- CSVDETAIL.ClaimLineNumber
						CLMAgg.SourceDataKey, -- SOURCEDATAKEY
						CASE WHEN CLMAgg.FormTypeCode ='U' THEN 'I' ELSE 'P' END AS ClaimType,
						CLMAgg.MemberID,
						--CDD.ProcedureCode,
						CLMDetail.PaymentAmount,						
						CLMDetail.PaidDateKey,
						CLMDetail.RequestedAmt,			
						CLMDetail.DeductibleAmt, -- 431 - 2430_CAS06_ClaimAdjustmentAmount_1
						CLMDetail.CoPayAmt, -- 431 - 2430_CAS03_ClaimAdjustmentAmount_1
						CLMDetail.CoInsuranceAmt, -- 431 - 2430_CAS09_ClaimAdjustmentAmount_1
						CLMDetail.WithholdAmt,
						CLMDetail.ItemDiscountAmt,			
						CLMDetail.EligibleFeeAmt,
						--CLMAgg.PROVIDERNPI,
						CLMDim.VENDORNPI,
						--CLMDim.ve
						CLMProv.NPI as CLAIMPROVNPI,
						CLMDetail.VendorID,
						--CLMDim.PCPID, 
						CLMAgg.PROVIDERID,
						CLMAgg.ATTENDINGPHYSICIANID,
						CLMProv.[ProvFirstName] as CLAIMPROVFIRSTNAME,
						CLMProv.[ProvLastName] AS CLAIMPROVLASTNAME,
						CLMProv.[PhysTypeQualifier] AS CLAIMPROVPHYSTYPE,
						CLMDetail.Quantity,
						CLMDetail.ServicePlaceCode,
						CLMDetail.BeginServiceDateKey, -- 2400I_DTP03_Date (first eight)
						CLMDetail.EndServiceDateKey, -- 2400I_DTP03_Date (last eight) 
						CLMDetail.ContractID,
						CLMDetail.MaxFeeAmt,
						CLMDetail.Deleted,
						CLMDetail.Active,
						CONVERT (varchar(8),CLMDim.DateReceivedKey)as FILEINFO,
						CASE
							WHEN CLMDim.PreviousClaimID IN ('N/A', 'UNKNOWN') AND
									SUBSTRING(ub921.BillTypeCode, 3, 1) IS NULL THEN '1'
							WHEN CLMDim.PreviousClaimID IN ('N/A', 'UNKNOWN') AND
									SUBSTRING(ub921.BillTypeCode, 3, 1) IN  ('7', '8') THEN '1'
							ELSE ISNULL(SUBSTRING(ub921.BillTypeCode, 3, 1),'1')
							END AS ClaimFrequencyCode,
							CLMDetail.ProcedureCode
		INTO #CLAIMSPROVP
		FROM dbo.EE_CSV_150P_Rec_Header CSVHeader
		INNER JOIN dbo.ClaimAgg CLMAgg ON CLMAgg.CLAIMID = CSVHeader.CLAIMID 
		INNER JOIN dbo.ClaimDim CLMDim ON CLMDim.CLAIMID = CSVHeader.CLAIMID 
		INNER JOIN dbo.ClaimDetailDim CLMDetail ON CLMDetail.CLAIMID =  CLMDim.CLAIMID --AND CSVDETAIL.CLAIMLINENUMBER = CSVCOBDETAIL.CLAIMLINENUMBER
		LEFT JOIN qnxt.ClaimProv CLMProv on CLMAgg.CLAIMID = CLMProv.CLAIMID
		LEFT JOIN dbo.UB921AdmissionDim ub921 ON ub921.ClaimID =  CSVHeader.ClaimID AND ub921.SourceDataKey = CSVHeader.SourceDataKey
		END;

	---- Load #Temp1 Claims 
		

		IF OBJECT_ID('tempdb.dbo.#Temp1') IS NOT NULL
			DROP TABLE #Temp1

		CREATE TABLE #Temp1 (
			[SourceDataKey] [INT],
			--[ID] [VARCHAR](50),
			[ClaimNo] [VARCHAR](50),
			--[CLM01] [VARCHAR](50),
			[ClaimType] [VARCHAR](50),
			--[TransactionType] [VARCHAR](50),
			--[AppCode] [VARCHAR](50),
			[BillProvEntity] [VARCHAR](10),
			[BillProvLast] [VARCHAR](60),
			[BillProvFirst] [VARCHAR](35),
			[BillProvNPI] [VARCHAR](80),
			[BillProvAddress] [VARCHAR](55),
			[BillProvAddress2] [VARCHAR](55),
			[BillProvCity] [VARCHAR](30),
			[BillProvState] [VARCHAR](2),
			[BillProvZip] [VARCHAR](15),
			[BillProvTaxID] [VARCHAR](50),
			[BillProvTel] [VARCHAR](256),
			[BillProvTaxonomy] [VARCHAR](50),
			[RendProvEntity] [VARCHAR](50),
			[RendProvLast] [VARCHAR](60),
			[RendProvFirst] [VARCHAR](35),
			[RendProvNPI] [VARCHAR](80),
			[RendProvTaxonomy] [VARCHAR](50),
			[RefProvEntity] [VARCHAR](10),
			[RefProvLast] [VARCHAR](60),
			[RefProvFirst] [VARCHAR](35),
			[RefProvID]    [VARCHAR](80), ---- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
			[RefProvIDType] [VARCHAR](50), ---- \* 8/1/2016 -- Added new column from Staging.dbo.SDE_ILICP_OB_Claims *\ 
			[RefProvNPI] [VARCHAR](80),
			[RefProvTaxonomy] [VARCHAR](50), ---- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
			--[RendProvTaxonomy] [varchar](50),
			[PCProvEntity] [VARCHAR](10),
			[PCProvLast] [VARCHAR](60),
			[PCProvFirst] [VARCHAR](35),
			[PCProvNPI] [VARCHAR](80),
			[PCPUPIN] [VARCHAR](50),
			[ClaimFrequencyCode] [VARCHAR](30),
			[AttendProvEntity] [VARCHAR](10) NULL,
			[AttendProvLast] [VARCHAR](60) NULL,
			[AttendProvFirst] [VARCHAR](35) NULL,
			[AttendProvNPI] [VARCHAR](80) NULL,
			[AttendProvTaxonomy] [VARCHAR](50) NULL,
			[SupervisingProvLast] [VARCHAR](60) NULL,
			[SupervisingProvFirst] [VARCHAR](35) NULL,
			[SupervisingProvNPI] [VARCHAR](80) NULL,
			[OperatingProvLast] [VARCHAR](60) NULL,
			[OperatingProvFirst] [VARCHAR](35) NULL,
			[OperatingProvNPI] [VARCHAR](80) NULL,
			--
            -- CM20004745.  Req 5.  Added ambulance fields.
            -- 
            [AmbulanceTransReason] [VARCHAR](50) NULL,
            [AmbulanceUOM] [VARCHAR](50) NULL,
            [AmbulanceDistance] REAL NULL,
			AmbulancePickupAddress VARCHAR (55) NULL,
            AmbulancePickupCity    VARCHAR (50) NULL,	
            AmbulancePickupState   VARCHAR (50) NULL,
            AmbulancePickupZip     VARCHAR (50) NULL,	
            AmbulanceDropName      VARCHAR (60) NULL,	
            AmbulanceDropAddress   VARCHAR (55) NULL,	
            AmbulanceDropCity      VARCHAR (50) NULL,
            AmbulanceDropState     VARCHAR (50) NULL,	
            AmbulanceDropZip       VARCHAR (50) NULL,	
			[FileInfo] [VARCHAR](100) NULL			
		)

		/* Build Temporary table for Institutional Transactions */ 

		IF @CLAIM_TYPE = 'I'
		BEGIN 
		INSERT INTO #Temp1
				SELECT DISTINCT
				SourceDataKey = claims.SourceDataKey,
				--ID = claims.GentranID,
				ClaimNo = claims.CLAIMID, --= Agg.ClaimID, -- removed "0000" statement 9/8/2014 '0000' + Agg.ClaimID, -- P, I
				--CLM01 = Agg.ClaimID,						
				ClaimType, 
				--TransactionType = 'CH' ,								
				--AppCode = 'ODSE',
				BillProvEntity = NULL,
				BillProvLast =
				CASE
								--WHEN ipd.LastName IS NOT NULL THEN LTRIM(RTRIM(ipd.LastName))
								WHEN vendprov.LastName IS NOT NULL THEN LTRIM(RTRIM(vendprov.LastName)) --updated 1/22/2015 per tenncare request
								WHEN Claims.ClaimType = 'I'  THEN LTRIM(RTRIM(ISNULL(NULLIF(vendprov.FirstName, 'UNKNOWN'), '') + ' ' + ISNULL(NULLIF(vendprov.LastName, 'UNKNOWN'), '')))
								ELSE NULLIF(vendprov.LastName, 'UNKNOWN')
							END,
				BillProvFirst = 
				CASE								
								WHEN  Claims.ClaimType = 'I'  THEN NULL
								WHEN vendprov.FirstName != 'UNKNOWN' THEN vendprov.[FirstName]
								ELSE NULLIF(NULLIF(vendprov.FirstName, 'UNKNOWN'),'')
								END,
				BillProvNPI =
				CASE
								WHEN NULLIF(Claims.[VendorNPI], 'UNKNOWN') IS NOT NULL THEN claims.[VendorNPI] --added 2/19/15 per tenncare request
								ELSE vendprov.NationalProviderID
								END,
				BillProvAddress =  REPLACE(dbo.fnStripCharacters(NULLIF(vendprov.AddressLine1, 'UNKNOWN'), '^-,^/,^0-9,^a-Z,^ '), '½', '1/2'),
				BillProvAddress2 = REPLACE(dbo.fnStripCharacters(NULLIF(vendprov.AddressLine2, 'UNKNOWN'), '^-,^/,^0-9,^a-Z,^ '), '½', '1/2') , -- P, I
				BillProvCity = NULLIF(vendprov.City, 'UNKNOWN'),
				BillProvState = NULLIF(vendprov.State, '--'),
				BillProvZip = LEFT(ISNULL(NULLIF(REPLACE(vendprov.Zip, '-', ''), 'UNKNOWN'), '00000') + '9999', 9),
				BillProvTaxID =  NULLIF(vendprov.FederalID, 'UNKNOWN'), --NULLIF(vd.FederalID, 'UNKNOWN') , -- P, I
				BillProvTel =  ISNULL(dbo.fnStripCharacters(NULLIF(vendprov.Phone, 'UNKNOWN'), '^0-9'), ''), --ISNULL(dbo.fnStripCharacters(NULLIF(vd.Phone, 'UNKNOWN'), '^0-9'), ''), -- P, I
				BillProvTaxonomy =  ISNULL(CMSTaxonomy.[HealthcareProviderTaxonomyCode],'') ,   ----NULL, TAKE a look
				RendProvEntity = NULL,
				RendProvLast = 
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								WHEN prov.LastName IS NOT NULL THEN LTRIM(RTRIM(prov.LastName))
								ELSE NULLIF(prov.LastName, 'UNKNOWN')
							END,
				RendProvFirst =
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								WHEN prov.FirstName IS NOT NULL THEN LTRIM(RTRIM(prov.FirstName))
								ELSE NULLIF(prov.FirstName, 'UNKNOWN')
							END,
				RendProvNPI = 
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								ELSE ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '')
							END, -- CASE WHEN NULLIF(vd.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID,'UNKNOWN'),'') 
				--	THEN '' ELSE ISNULL(NULLIF(prov.NPID,'UNKNOWN'),'') END, -- P, I
				RendProvTaxonomy = NULL,
				RefProvEntity = NULL,
				RefProvLast = CLMProvRef.[ProvLastName],
				RefProvFirst = CLMProvRef.[ProvFirstName],
				RefProvID    = NULL,  ---- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
				RefProvIDType = NULL, ---- \* 8/1/2016 -- Added new column from Staging.dbo.SDE_ILICP_OB_Claims *\ 
				RefProvNPI = CLMProvRef.[NPI],
				RefProvTaxonomy =NULL,  ----- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
				PCProvEntity = NULL,
				PCProvLast = NULL,
				PCProvFirst = NULL,
				PCProvNPI =
							CASE
								WHEN claims.ClaimType  != 'I' THEN prov.NPID
							END, -- P
				PCPUPIN =
							CASE
								WHEN claims.ClaimType != 'I' THEN NULLIF(prov.UPIN, 'UNKNOWN')
							END, -- P
				ClaimFrequencyCode, 
				[AttendProvEntity] = NULL,
				[AttendProvLast] = CLMProvAttend.[ProvLastName],
				[AttendProvFirst] = CLMProvAttend.[ProvFirstName],
				[AttendProvNPI] = CLMProvAttend.[NPI],
				[AttendProvTaxonomy] = NULL,
				[SupervisingProvLast] = CLMProvSup.[ProvLastName],
				[SupervisingProvFirst] = CLMProvSup.[ProvFirstName],
				[SupervisingProvNPI] = CLMProvSup.[NPI],
				[OperatingProvLast] = CLMProvOp.[ProvLastName],
				[OperatingProvFirst] = CLMProvOp.[ProvFirstName],
				[OperatingProvNPI] = CLMProvOp.[NPI],
				[AmbulanceTransReason] = NULL,
                [AmbulanceUOM] = NULL,
                [AmbulanceDistance] = NULL,
				AmbulancePickupAddress = NULL,
				AmbulancePickupCity    = NULL,	
				AmbulancePickupState   = NULL,
				AmbulancePickupZip     = NULL,	
				AmbulanceDropName      = NULL,	
				AmbulanceDropAddress   = NULL,	
				AmbulanceDropCity      = NULL,
				AmbulanceDropState     = NULL,	
				AmbulanceDropZip       = NULL,	
				[FileInfo]-- =    CONVERT (varchar(8),cd.DateReceivedKey)						
						
			--INTO #Temp1
			FROM #CLAIMSPROV claims
			LEFT JOIN dbo.ProviderDim prov ON prov.ProviderID = claims.PROVIDERID AND prov.SourceDataKey = claims.SourceDataKey
			--LEFT JOIN dbo.VendorDim 
			LEFT JOIN dbo.VendorDim  vendprov ON claims.VENDORNPI = vendprov.NationalProviderID AND claims.SOURCEDATAKEY = vendprov.SourceDataKey 
			LEFT JOIN dbo.QNXT_Claim qnxtclaim ON claims.CLAIMID = qnxtclaim.claimid
			LEFT JOIN qnxt.ClaimProv CLMProvAttend on claims.CLAIMID = CLMProvAttend.CLAIMID  AND  CLMProvAttend.[PhysTypeQualifier] = 'ATTENDING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvRef on claims.CLAIMID = CLMProvRef.CLAIMID  AND CLMProvRef.[PhysTypeQualifier] = 'REFERRING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvSup on claims.CLAIMID = CLMProvSup.CLAIMID  AND CLMProvSup.[PhysTypeQualifier] = 'SUPERVISING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvOp on claims.CLAIMID = CLMProvOp.CLAIMID  AND CLMProvOp.[PhysTypeQualifier] = 'OPERATING'-- Need to 
			--LEFT JOIN dbo.ProviderDim Attendprov ON Attendprov.ProviderID = claims.ATTENDINGPHYSICIANID AND Attendprov.SourceDataKey = claims.SourceDataKey
			LEFT JOIN EDPS_Data.IDQ.CMSTaxonomy CMSTaxonomy ON vendprov.NationalProviderID = CMSTaxonomy.NPI and
												HealthcareProviderPrimaryTaxonomySwitch ='Y' 
			END; 

			/* Build Temporary table for Professional Claims */

			IF @CLAIM_TYPE = 'P'
		BEGIN 
		INSERT INTO #Temp1
				SELECT DISTINCT
				SourceDataKey = claims.SourceDataKey,
				--ID = claims.GentranID,
				ClaimNo = claims.CLAIMID, --= Agg.ClaimID, -- removed "0000" statement 9/8/2014 '0000' + Agg.ClaimID, -- P, I
				--CLM01 = Agg.ClaimID,						
				ClaimType, 
				--TransactionType = 'CH' ,								
				--AppCode = 'ODSE',
				BillProvEntity = NULL,
				BillProvLast =
				CASE
								--WHEN ipd.LastName IS NOT NULL THEN LTRIM(RTRIM(ipd.LastName))
								WHEN vendprov.LastName IS NOT NULL THEN LTRIM(RTRIM(vendprov.LastName)) --updated 1/22/2015 per tenncare request
								WHEN Claims.ClaimType = 'I'  THEN LTRIM(RTRIM(ISNULL(NULLIF(vendprov.FirstName, 'UNKNOWN'), '') + ' ' + ISNULL(NULLIF(vendprov.LastName, 'UNKNOWN'), '')))
								ELSE NULLIF(vendprov.LastName, 'UNKNOWN')
							END,
				BillProvFirst = 
				CASE								
								WHEN  Claims.ClaimType = 'I'  THEN NULL
								WHEN vendprov.FirstName != 'UNKNOWN' THEN vendprov.[FirstName]
								ELSE NULLIF(NULLIF(vendprov.FirstName, 'UNKNOWN'),'')
								END,
				BillProvNPI =
				CASE
								WHEN NULLIF(Claims.[VendorNPI], 'UNKNOWN') IS NOT NULL THEN claims.[VendorNPI] --added 2/19/15 per tenncare request
								ELSE vendprov.NationalProviderID
								END,
				BillProvAddress =  REPLACE(dbo.fnStripCharacters(NULLIF(vendprov.AddressLine1, 'UNKNOWN'), '^-,^/,^0-9,^a-Z,^ '), '½', '1/2'),
				BillProvAddress2 = REPLACE(dbo.fnStripCharacters(NULLIF(vendprov.AddressLine2, 'UNKNOWN'), '^-,^/,^0-9,^a-Z,^ '), '½', '1/2') , -- P, I
				BillProvCity = NULLIF(vendprov.City, 'UNKNOWN'),
				BillProvState = NULLIF(vendprov.State, '--'),
				BillProvZip = LEFT(ISNULL(NULLIF(REPLACE(vendprov.Zip, '-', ''), 'UNKNOWN'), '00000') + '9999', 9),
				BillProvTaxID =  NULLIF(vendprov.FederalID, 'UNKNOWN'), --NULLIF(vd.FederalID, 'UNKNOWN') , -- P, I
				BillProvTel =  ISNULL(dbo.fnStripCharacters(NULLIF(vendprov.Phone, 'UNKNOWN'), '^0-9'), ''), --ISNULL(dbo.fnStripCharacters(NULLIF(vd.Phone, 'UNKNOWN'), '^0-9'), ''), -- P, I
				BillProvTaxonomy =  ISNULL(CMSTaxonomy.[HealthcareProviderTaxonomyCode],'') ,   ----NULL, TAKE a look
				RendProvEntity = NULL,
				RendProvLast = 
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								WHEN prov.LastName IS NOT NULL THEN LTRIM(RTRIM(prov.LastName))
								ELSE NULLIF(prov.LastName, 'UNKNOWN')
							END,
				RendProvFirst =
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								WHEN prov.FirstName IS NOT NULL THEN LTRIM(RTRIM(prov.FirstName))
								ELSE NULLIF(prov.FirstName, 'UNKNOWN')
							END,
				RendProvNPI = 
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								ELSE ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '')
							END, -- CASE WHEN NULLIF(vd.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID,'UNKNOWN'),'') 
				--	THEN '' ELSE ISNULL(NULLIF(prov.NPID,'UNKNOWN'),'') END, -- P, I
				RendProvTaxonomy = NULL,
				RefProvEntity = NULL,
				RefProvLast = CLMProvRef.[ProvLastName],
				RefProvFirst = CLMProvRef.[ProvFirstName],
				RefProvID    = NULL,  ---- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
				RefProvIDType = NULL, ---- \* 8/1/2016 -- Added new column from Staging.dbo.SDE_ILICP_OB_Claims *\ 
				RefProvNPI = CLMProvRef.[NPI],
				RefProvTaxonomy =NULL,  ----- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
				PCProvEntity = NULL,
				PCProvLast = NULL,
				PCProvFirst = NULL,
				PCProvNPI =
							CASE
								WHEN claims.ClaimType  != 'I' THEN prov.NPID
							END, -- P
				PCPUPIN =
							CASE
								WHEN claims.ClaimType != 'I' THEN NULLIF(prov.UPIN, 'UNKNOWN')
							END, -- P
				ClaimFrequencyCode, 
				[AttendProvEntity] = NULL,
				[AttendProvLast] = CLMProvAttend.[ProvLastName],
				[AttendProvFirst] = CLMProvAttend.[ProvFirstName],
				[AttendProvNPI] = CLMProvAttend.[NPI],
				[AttendProvTaxonomy] = NULL,
				[SupervisingProvLast] = CLMProvSup.[ProvLastName],
				[SupervisingProvFirst] = CLMProvSup.[ProvFirstName],
				[SupervisingProvNPI] = CLMProvSup.[NPI],
				[OperatingProvLast] = CLMProvOp.[ProvLastName],
				[OperatingProvFirst] = CLMProvOp.[ProvFirstName],
				[OperatingProvNPI] = CLMProvOp.[NPI],
				[AmbulanceTransReason] = NULL,
                [AmbulanceUOM] = NULL,
                [AmbulanceDistance] = NULL,
				AmbulancePickupAddress = NULL,
				AmbulancePickupCity    = NULL,	
				AmbulancePickupState   = NULL,
				AmbulancePickupZip     = NULL,	
				AmbulanceDropName      = NULL,	
				AmbulanceDropAddress   = NULL,	
				AmbulanceDropCity      = NULL,
				AmbulanceDropState     = NULL,	
				AmbulanceDropZip       = NULL,	
				[FileInfo]-- =    CONVERT (varchar(8),cd.DateReceivedKey)						
						
			--INTO #Temp1
			FROM #CLAIMSPROVP claims
			LEFT JOIN dbo.ProviderDim prov ON prov.ProviderID = claims.PROVIDERID AND prov.SourceDataKey = claims.SourceDataKey
			--LEFT JOIN dbo.VendorDim 
			LEFT JOIN dbo.VendorDim  vendprov ON claims.VENDORNPI = vendprov.NationalProviderID AND claims.SOURCEDATAKEY = vendprov.SourceDataKey 
			LEFT JOIN dbo.QNXT_Claim qnxtclaim ON claims.CLAIMID = qnxtclaim.claimid
			LEFT JOIN qnxt.ClaimProv CLMProvAttend on claims.CLAIMID = CLMProvAttend.CLAIMID  AND  CLMProvAttend.[PhysTypeQualifier] = 'ATTENDING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvRef on claims.CLAIMID = CLMProvRef.CLAIMID  AND CLMProvRef.[PhysTypeQualifier] = 'REFERRING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvSup on claims.CLAIMID = CLMProvSup.CLAIMID  AND CLMProvSup.[PhysTypeQualifier] = 'SUPERVISING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvOp on claims.CLAIMID = CLMProvOp.CLAIMID  AND CLMProvOp.[PhysTypeQualifier] = 'OPERATING'-- Need to 
			--LEFT JOIN dbo.ProviderDim Attendprov ON Attendprov.ProviderID = claims.ATTENDINGPHYSICIANID AND Attendprov.SourceDataKey = claims.SourceDataKey
			LEFT JOIN EDPS_Data.IDQ.CMSTaxonomy CMSTaxonomy ON vendprov.NationalProviderID = CMSTaxonomy.NPI and
												HealthcareProviderPrimaryTaxonomySwitch ='Y' 
			END; 

												 
				--- Update #temp  based on IL requirements
        --
        UPDATE 
            tmp
        SET
			AmbulanceDistance    = cdd.Quantity,
            AmbulanceUOM         = CASE WHEN cdd.Quantity > 0 THEN 'DH' ELSE NULL END,
            AmbulanceTransReason = CASE WHEN cdd.Quantity > 0 THEN 'A'  ELSE NULL END,
			AmbulancePickupAddress = LEFT(amb.PickUpAddress,55),
            AmbulancePickupCity    = LEFT(amb.PickUpCity,50),	
            AmbulancePickupState   = LEFT(amb.PickUpState,50),
            AmbulancePickupZip     = LEFT(amb.PickUpZip,50),	
            AmbulanceDropName      = CASE WHEN amb.DropOffLocation IN ('OTHER','UNKNOWN') THEN NULL ELSE LEFT(amb.DropOffLocation,60) END,	
            AmbulanceDropAddress   = LEFT(amb.DropOffAddress,55),	
            AmbulanceDropCity      = LEFT(amb.DropOffCity,50),
            AmbulanceDropState     = LEFT(amb.DropOffState,50),	
            AmbulanceDropZip       = LEFT(amb.DropOffZip,50)
        FROM 
            #Temp1 tmp
        INNER JOIN dbo.ClaimDetailDim cdd ON tmp.ClaimNo = cdd.ClaimID AND tmp.SourceDataKey = cdd.SourceDataKey  
															AND cdd.ProcedureCode IN ('A0425','A0436')
		INNER JOIN Medicaid.dbo.ClaimAmbulanceInfoDim amb ON cdd.CLAIMID = amb.ClaimID


		--added 1/23/2015 to fix null names from vendordim
		UPDATE t
			SET t.[AttendProvTaxonomy] = c.[HealthcareProviderTaxonomyCode]
			FROM #Temp1 t
				LEFT JOIN EDPS_Data.[IDQ].[CMSTaxonomy] c ON t.[AttendProvNPI] = c.[NPI] AND [c].[HealthcareProviderPrimaryTaxonomySwitch] = 'Y'
			WHERE t.ClaimType = 'I' AND t.[AttendProvNPI] <> '';

		UPDATE t
			SET t.[RendProvTaxonomy] = c.[HealthcareProviderTaxonomyCode]
			FROM #Temp1 [t]
				LEFT JOIN EDPS_Data.[IDQ].[CMSTaxonomy] AS [c] ON t.[RendProvNPI] = c.[NPI] AND [c].[HealthcareProviderPrimaryTaxonomySwitch] = 'Y'
		WHERE t.ClaimType = 'P' AND [t].[RendProvNPI] <> '';

		
	
		--added 1/23/2015 to fix null names from vendordim
		UPDATE t  
																		--updated to only impact ProviderAddress Data and not the other fields
		SET	
			t.[BillProvAddress] =  COALESCE(NULLIF([pad50].[AddressLine1],'UNKNOWN'), t.[BillProvAddress]),--, pda.[AddressLine1]),
			t.[BillProvAddress2] =  COALESCE(NULLIF([pad50].[AddressLine2],'UNKNOWN'), t.[BillProvAddress2]),--,pda.[AddressLine2]),
			t.[BillProvCity] = COALESCE([pad50].[City], t.[BillProvCity]),
			t.[BillProvState] = COALESCE([pad50].[State], t.[BillProvState]),
			t.[BillProvZip] = COALESCE( [pad50].[ZipCode9], t.[BillProvZip])
		FROM #Temp1 AS [t] 
			LEFT JOIN Medicaid.[dbo].[ProviderDim] AS [pd] ON [pd].NPID = t.BillProvNPI AND [pd].SourceDataKey = t.SourceDataKey
					--AND [pd].Deleted = 0
					--AND [pd].Active = 1
			LEFT JOIN Medicaid.dbo.ProviderAddressDim AS pda ON pd.ProviderID = pda.ProviderID 
				AND [pd].SourceDataKey = pda.SourceDataKey
				AND pda.[Active] = 1  --added 2/24/2015 per project manager request
				AND pda.deleted = 0  --added 2/24/2015 per project manager request
				AND [pda].[AddressTypeCode] = 'PB' --added 2/24/2015 per project manager request
			LEFT JOIN (--added 2/24/2015 per project manager request	
					SELECT distinct [pad].[ProviderID],[pad].[AddressLine1],[pad].[AddressLine2] , [pad].City, [pad].ZipCode9, [pad].State
					FROM Medicaid..[ProviderAddressDim] AS [pad] 
					WHERE ([pad].[AddressLine1] NOT LIKE '%P%O%BOX%' AND [pad].[AddressLine1] NOT LIKE '%PO%BOX%')   
						AND ([pad].[AddressLine2] NOT LIKE '%P%O%BOX%' AND [pad].[AddressLine2] NOT LIKE '%PO%BOX%' ) 
						AND active = 1 
						AND deleted = 0 
						AND addresstypecode = 'PB' 
						AND sourcedatakey = '50') pad50 
				on pd.ProviderID = pad50.[ProviderID]
			LEFT JOIN EDPS_Data.IDQ.CMSTaxonomy cms ON pd.NPID = cms.NPI
	



		/**************************************************************************************************************************
		Blank Rendering Provider Information for Institutional Claims. As this field is not required in the 837I transaction 
		************************************************************************************************************************/
		UPDATE c
		SET	RendProvEntity = '',
			RendProvLast = '',
			RendProvFirst = '',
			RendProvNPI = ''
		FROM #Temp1 c
		WHERE ClaimType = 'I'
		
	
		/**************************************************************************************************************************
		Retreive Claim Adjustment Segment Data utilizing logic specific to TennCare 
		************************************************************************************************************************/


			----- [SDE_ILICP_OB_ClaimAdjustments] table updates

			IF OBJECT_ID('tempdb.dbo.##CLAIMADJUSTMENTS') IS NOT NULL
			DROP TABLE ##CLAIMADJUSTMENTS

			CREATE TABLE ##CLAIMADJUSTMENTS ( 
			CLAIMID VARCHAR (20) NULL,
			CLAIMLEVEL VARCHAR (2) NULL, 
			CLAIMLINENUMBER VARCHAR (5) NULL,
			ClaimAdjustmentGroupCode VARCHAR (2) NULL,
			ClaimAdjustmentReason VARCHAR (4) NULL,
			ClaimAdjustmentAmount MONEY NULL
			)
			
			
			
			IF @CLAIM_TYPE = 'I'
				 BEGIN 
			INSERT ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'CO',
					ClaimAdjustmentReason = '45',
					ClaimAdjustmentAmount = c.RequestedAmt - c.paymentamount - c.DeductibleAmt - c.CoPayAmt	- c.CoInsuranceAmt - c.WithholdAmt - c.ItemDiscountAmt
					--ClaimAdjustmentAmount = c.RequestedAmt - c.paymentamount - c.DeductibleAmt - c.CoPayAmt	- c.WithholdAmt - c.ItemDiscountAmt
				FROM #CLAIMSPROV c
				INNER JOIN dbo.ClaimDetailDim cdd ON c.CLAIMID = cdd.claimid AND cdd.ClaimLineID = c.CLAIMLINEID
				--WHERE-c.EligibleFeeAmt < c.RequestedAmt    RTM-4
				--AND c.EligibleFeeAmt + c.RequestedAmt - c.paymentamount - c.DeductibleAmt - c.CoPayAmt
				WHERE c.EligibleFeeAmt + c.RequestedAmt - c.paymentamount - c.DeductibleAmt - c.CoPayAmt
				- c.CoInsuranceAmt - c.WithholdAmt - c.ItemDiscountAmt > 0
				AND cdd.ProcedureCode <> '0l6' 


			INSERT  ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'PI',
					ClaimAdjustmentReason = '253',
					ClaimAdjustmentAmount = cdd.WithholdAmt
				--INTO #CLAIMADJUSTMENTS
				FROM #CLAIMSPROV c
				INNER JOIN dbo.ClaimDetailDim cdd ON c.CLAIMID = cdd.claimid AND cdd.ClaimLineID = c.CLAIMLINEID
				WHERE cdd.WithholdAmt > 0
				AND cdd.ProcedureCode <> '0l6'

			
			INSERT ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'CO',
					ClaimAdjustmentReason = '131',
					ClaimAdjustmentAmount = cdd.ItemDiscountAmt
				FROM #CLAIMSPROV c
				INNER JOIN dbo.ClaimDetailDim cdd ON c.CLAIMID = cdd.claimid AND cdd.ClaimLineID = c.CLAIMLINEID
				WHERE cdd.ItemDiscountAmt > 0
				AND cdd.ProcedureCode <> '0l6'

			
			INSERT ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'PR',
					ClaimAdjustmentReason = '1',
					ClaimAdjustmentAmount = c.DEDUCTIBLEAMT
				FROM #CLAIMSPROV c
				WHERE c.DEDUCTIBLEAMT > 0


			INSERT ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'PR',
					ClaimAdjustmentReason = '2',
					ClaimAdjustmentAmount = c.COINSURANCEAMT
				FROM #CLAIMSPROV c
				WHERE c.COINSURANCEAMT > 0

			

			INSERT ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'PR',
					ClaimAdjustmentReason = '3',
					ClaimAdjustmentAmount = c.COPAYAMT
				FROM #CLAIMSPROV c
				WHERE c.COPAYAMT > 0

					
				-- its only for TENCARE	
				--added 1/21/2015 per Tenncare Request
				UPDATE a
				SET	ClaimAdjustmentGroupCode = 'PI',
					ClaimAdjustmentReason = 'A1'
				FROM ##CLAIMADJUSTMENTS a
				JOIN #CLAIMSPROV b
					ON a.ClaimID = b.CLAIMID
				JOIN  dbo.ClaimDetailDim cdd
					ON b.CLAIMID = cdd.ClaimID
					AND a.claimlinenumber = cdd.ClaimLineID
				WHERE 
				cdd.paymentamount = 0 AND cdd.ClaimLineStatus ='DENY';
				END; 
		
	IF @CLAIM_TYPE = 'P'
				 BEGIN 
			INSERT ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'CO',
					ClaimAdjustmentReason = '45',
					ClaimAdjustmentAmount = c.RequestedAmt - c.paymentamount - c.DeductibleAmt - c.CoPayAmt	- c.CoInsuranceAmt - c.WithholdAmt - c.ItemDiscountAmt
					--ClaimAdjustmentAmount = c.RequestedAmt - c.paymentamount - c.DeductibleAmt - c.CoPayAmt	- c.WithholdAmt - c.ItemDiscountAmt
				FROM #CLAIMSPROVP c
				INNER JOIN dbo.ClaimDetailDim cdd ON c.CLAIMID = cdd.claimid AND cdd.ClaimLineID = c.CLAIMLINEID
				--WHERE c.EligibleFeeAmt < c.RequestedAmt  RTM-4
				--AND c.EligibleFeeAmt + c.RequestedAmt - c.paymentamount - c.DeductibleAmt - c.CoPayAmt
				WHERE c.EligibleFeeAmt + c.RequestedAmt - c.paymentamount - c.DeductibleAmt - c.CoPayAmt
				- c.CoInsuranceAmt - c.WithholdAmt - c.ItemDiscountAmt > 0
				AND cdd.ProcedureCode <> '0l6' 


			INSERT  ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'PI',
					ClaimAdjustmentReason = '253',
					ClaimAdjustmentAmount = cdd.WithholdAmt
				--INTO #CLAIMADJUSTMENTS
				FROM #CLAIMSPROVP c
				INNER JOIN dbo.ClaimDetailDim cdd ON c.CLAIMID = cdd.claimid AND cdd.ClaimLineID = c.CLAIMLINEID
				WHERE cdd.WithholdAmt > 0
				AND cdd.ProcedureCode <> '0l6'

			
			INSERT ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'CO',
					ClaimAdjustmentReason = '131',
					ClaimAdjustmentAmount = cdd.ItemDiscountAmt
				FROM #CLAIMSPROVP c
				INNER JOIN dbo.ClaimDetailDim cdd ON c.CLAIMID = cdd.claimid AND cdd.ClaimLineID = c.CLAIMLINEID
				WHERE cdd.ItemDiscountAmt > 0
				AND cdd.ProcedureCode <> '0l6'

			
			INSERT ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'PR',
					ClaimAdjustmentReason = '1',
					ClaimAdjustmentAmount = c.DEDUCTIBLEAMT
				FROM #CLAIMSPROVP c
				WHERE c.DEDUCTIBLEAMT > 0


			INSERT ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'PR',
					ClaimAdjustmentReason = '2',
					ClaimAdjustmentAmount = c.COINSURANCEAMT
				FROM #CLAIMSPROVP c
				WHERE c.COINSURANCEAMT > 0

			

			INSERT ##CLAIMADJUSTMENTS (ClaimID, ClaimLevel, ClaimLineNumber, ClaimAdjustmentGroupCode, ClaimAdjustmentReason, ClaimAdjustmentAmount)
				SELECT DISTINCT
					claimid = c.CLAIMID,
					claimlevel = 'S',
					ClaimLineNumber = c.CLAIMLINEID,
					ClaimAdjustmentGroupCode = 'PR',
					ClaimAdjustmentReason = '3',
					ClaimAdjustmentAmount = c.COPAYAMT
				FROM #CLAIMSPROVP c
				WHERE c.COPAYAMT > 0

					
				-- its only for TENCARE	
				--added 1/21/2015 per Tenncare Request
				UPDATE a
				SET	ClaimAdjustmentGroupCode = 'PI',
					ClaimAdjustmentReason = 'A1'
				FROM ##CLAIMADJUSTMENTS a
				JOIN #CLAIMSPROVP b
					ON a.ClaimID = b.CLAIMID
				JOIN  dbo.ClaimDetailDim cdd
					ON b.CLAIMID = cdd.ClaimID
					AND a.claimlinenumber = cdd.ClaimLineID
				WHERE 
				cdd.paymentamount = 0 AND cdd.ClaimLineStatus ='DENY';
				END; 
						



			
/**************************************************************************************************************************************************
 Mapping of TennCare Companion Guide specific updates into the existing CSV tables
 *************************************************************************************************************************************************/
 
 -- 100I Record  - [Medicaid].[dbo].[EE_CSV_100I_Rec_Header]

IF @CLAIM_TYPE = 'I'
 BEGIN 
	UPDATE CSV100I
		SET
			 [2010AA_NM103_BillingOrg_LastName]  					= [BillProvLast]	
			,[2010AA_NM104_BillingFirstName]						= [BillProvFirst]	
			,[2010AA_NM109_BillingProviderIdentifier]				= [BillProvNPI]		
			,[2010AA_N301_BillingAddressLine1]						= [BillProvAddress]	
			,[2010AA_N302_BillingAddressLine2]						= [BillProvAddress2]
			,[2010AA_N401_BillingCity]								= [BillProvCity]	
			,[2010AA_N402_BillingState]								= [BillProvState]	
			,[2010AA_N403_BillingPostalCode]						= [BillProvZip]		
			,[2010AA_REF02_BillingProviderIdentifier_1]				= [BillProvTaxID]	
			,[2010AA_PER04_BillingProviderCommunicationNumber_1]	= [BillProvTel]		
			,[2000A_PRV03_BillingProviderTaxonomy]					= [BillProvTaxonomy]
	 FROM  [Medicaid].[dbo].[EE_CSV_100I_Rec_Header] CSV100I
		 INNER JOIN #Temp1 CLAIMSPROV ON CSV100I.ClaimID = CLAIMSPROV.ClaimNo



		 -- 20I record -	 [Medicaid].[dbo].[EE_CSV_20I_Rec_Header]	
	UPDATE CSV20I
		SET
				 [2310AI_NM103_LastName]							= [AttendProvLast]
				,[2310AI_NM104_FirstName]							= [AttendProvFirst]
				,[2310AI_NM109_ProviderIdentifier]					= [AttendProvNPI]
				,[2310AI_PRV03_ProviderTaxonomy]					= [AttendProvTaxonomy]

				,[2310BI_NM103_LastName]							= [OperatingProvLast]
				,[2310BI_NM104_FirstName]							= [OperatingProvFirst]
				,[2310BI_NM109_ProviderIdentifier]					= [OperatingProvNPI]
	
				,[2310DI_NM103_LastName]							= [RendProvLast]
				,[2310DI_NM104_FirstName]							= [RendProvFirst]
				,[2310DI_NM109_ProviderIdentifier]					= [RendProvNPI]
																	
					
				,[2310FI_NM103_LastName]							= [RefProvLast]
				,[2310FI_NM104_FirstName]							= [RefProvFirst]
				,[2310FI_NM109_ProviderIdentifier]					= [RefProvNPI]
				,[2300I_CLM05-03_ClaimFrequencyCode]                = ClaimFrequencyCode
				,[2300I_REF01_FileInformation]						= [FileInfo]
			FROM  [Medicaid].[dbo].[EE_CSV_20I_Rec_Header] CSV20I
		 INNER JOIN #Temp1 CLAIMSPROV ON CSV20I.ClaimID = CLAIMSPROV.ClaimNo


		   --431I  [Medicaid].[dbo].[EE_CSV_431I_Rec_Detail] CAS Segment upates applied 

	/*  Sort Adjustment table for final CSV TABLE POPULATION */

	IF OBJECT_ID('tempdb.dbo.##CLAIMADJUSTMENTSSORTED') IS NOT NULL
	DROP TABLE ##CLAIMADJUSTMENTSSORTED

	SELECT * ,  
	[SEQUENCE] = ROW_NUMBER() OVER (PARTITION BY CLAIMID, CLAIMLINENUMBER ORDER BY CLAIMADJUSTMENTGROUPCODE desc)
	INTO ##CLAIMADJUSTMENTSSORTED
	FROM ##CLAIMADJUSTMENTS


     UPDATE CSV431I
		SET
			 [2430_CAS01_ClaimAdjustmentGroup_1]				= CASADJ1.ClaimAdjustmentGroupCode
			,[2430_CAS02_ClaimAdjustmentReason_1]				= CASADJ1.ClaimAdjustmentReason
			,[2430_CAS03_ClaimAdjustmentAmount_1]				= CASADJ1.ClaimAdjustmentAmount
			,[2430_CAS01_ClaimAdjustmentGroup_2]				= CASADJ2.ClaimAdjustmentGroupCode
			,[2430_CAS02_ClaimAdjustmentReason_2]				= CASADJ2.ClaimAdjustmentReason
			,[2430_CAS03_ClaimAdjustmentAmount_2]				= CASADJ2.ClaimAdjustmentAmount
			,[2430_CAS01_ClaimAdjustmentGroup_3]				= CASADJ3.ClaimAdjustmentGroupCode
			,[2430_CAS02_ClaimAdjustmentReason_3]				= CASADJ3.ClaimAdjustmentReason
			,[2430_CAS03_ClaimAdjustmentAmount_3]				= CASADJ3.ClaimAdjustmentAmount
			,[2430_CAS01_ClaimAdjustmentGroup_4]				= CASADJ4.ClaimAdjustmentGroupCode
			,[2430_CAS02_ClaimAdjustmentReason_4]				= CASADJ4.ClaimAdjustmentReason
			,[2430_CAS03_ClaimAdjustmentAmount_4]				= CASADJ4.ClaimAdjustmentAmount
	FROM [Medicaid].[dbo].[EE_CSV_431I_Rec_Detail] CSV431I
	LEFT JOIN ##CLAIMADJUSTMENTSSORTED CASADJ1 ON CSV431I.ClaimID = CASADJ1.CLAIMID AND CSV431I.ClaimLineNumber = CASADJ1.CLAIMLINENUMBER AND CASADJ1.SEQUENCE = '1'
	LEFT JOIN ##CLAIMADJUSTMENTSSORTED CASADJ2 ON CSV431I.ClaimID = CASADJ2.CLAIMID AND CSV431I.ClaimLineNumber = CASADJ2.CLAIMLINENUMBER AND CASADJ2.SEQUENCE = '2'
	LEFT JOIN ##CLAIMADJUSTMENTSSORTED CASADJ3 ON CSV431I.ClaimID = CASADJ3.CLAIMID AND CSV431I.ClaimLineNumber = CASADJ3.CLAIMLINENUMBER  AND CASADJ3.SEQUENCE = '3'
	LEFT JOIN ##CLAIMADJUSTMENTSSORTED CASADJ4 ON CSV431I.ClaimID = CASADJ4.CLAIMID AND CSV431I.ClaimLineNumber = CASADJ4.CLAIMLINENUMBER  AND CASADJ4.SEQUENCE = '4'
	LEFT JOIN ##CLAIMADJUSTMENTSSORTED CASADJ5 ON CSV431I.ClaimID = CASADJ5.CLAIMID AND CSV431I.ClaimLineNumber = CASADJ5.CLAIMLINENUMBER  AND CASADJ5.SEQUENCE = '5'
	END;

	-----------------------------------------------------------------------------------------------------------------------------------------------------
		---- Professional Claim updates 
	-----------------------------------------------------------------------------------------------------------------------------------------------------

	IF @CLAIM_TYPE = 'P'
 BEGIN 
	UPDATE CSV100P
	SET 
-- 100P Record  [Medicaid].[dbo].[EE_CSV_100P_Rec_Header]

		[2010AA_NM102_BillingPersonIndicator]					= [BillProvEntity]
		,[2010AA_NM103_BillingOrg_LastName]  					= [BillProvLast]	
		,[2010AA_NM104_BillingFirstName]						= [BillProvFirst]	
		,[2010AA_NM109_BillingProviderIdentifier]				= [BillProvNPI]		
		,[2010AA_N301_BillingAddressLine1]						= [BillProvAddress]	
		,[2010AA_N302_BillingAddressLine2]						= [BillProvAddress2]
		,[2010AA_N401_BillingCity]								= [BillProvCity]	
		,[2010AA_N402_BillingState]								= [BillProvState]	
		,[2010AA_N403_BillingPostalCode]						= [BillProvZip]		
		,[2010AA_REF02_BillingProviderIdentifier_1]				= [BillProvTaxID]	
		,[2010AA_PER04_BillingProviderCommunicationNumber_1]	= [BillProvTel]		
		,[2000A_PRV03_BillingProviderTaxonomy]					= [BillProvTaxonomy]
	FROM  [Medicaid].[dbo].[EE_CSV_100P_Rec_Header] CSV100P
	 INNER JOIN #Temp1 CLAIMSPROV ON CSV100P.ClaimID = CLAIMSPROV.ClaimNo


	 UPDATE CSV20P
	 SET
-- 20P record -	 [Medicaid].[dbo].[EE_CSV_20I_Rec_Header]	
		
		 [2310AP_NM103_LastName]							= [RefProvLast]
		,[2310AP_NM104_FirstName]							= [RefProvFirst]
		,[2310AP_NM109_ProviderIdentifier]					= [RefProvNPI]

		,[2310BP_NM103_LastName]							= [RendProvLast]
		,[2310BP_NM104_FirstName]							= [RendProvFirst]
		,[2310BP_NM109_ProviderIdentifier]					= [RendProvNPI]
		,[2310BP_PRV03_ProviderTaxonomy]					= [RendProvTaxonomy]

		,[2310DP_NM103_LastName]							= [SupervisingProvLast]
		,[2310DP_NM104_FirstName]							= [SupervisingProvFirst]
		,[2310DP_NM109_ProviderIdentifier]					= [SupervisingProvNPI]

		,[2300P_CLM05-03_ClaimFrequencyCode]				= ClaimFrequencyCode
		,[2300P_CR104_AmbulanceTransportReason]				= [AmbulanceTransReason]
		,[2300P_CR105_AmbulanceMeasure]						= [AmbulanceUOM]
		,[2300P_CR106_AmbulanceDistance]					= [AmbulanceDistance]
		,[2310EP_N301_AddressLine1]							= AmbulancePickupAddress
		,[2310EP_N401_City]									= AmbulancePickupCity
		,[2310EP_N402_State]								= AmbulancePickupState
		,[2310EP_N403_PostalCode]							= AmbulancePickupZip
		,[2310FP_NM103_ORG_LastName]						= AmbulanceDropName
		,[2310FP_N301_AddressLine1]							= AmbulanceDropAddress
		,[2310FP_N401_City]									= AmbulanceDropCity
		,[2310FP_N402_State]								= AmbulanceDropState
		,[2310FP_N403_PostalCode]							= AmbulanceDropZip
		,[2300P_REF01_FileInformation]						= [FileInfo]
	FROM  [Medicaid].[dbo].[EE_CSV_20P_Rec_Header] CSV20P
	 INNER JOIN #Temp1 CLAIMSPROV ON CSV20P.ClaimID = CLAIMSPROV.ClaimNo



   /*  Sort Adjustment table for final CSV TABLE POPULATION */

	IF OBJECT_ID('tempdb.dbo.##CLAIMADJUSTMENTSSORTEDPROF') IS NOT NULL
	DROP TABLE ##CLAIMADJUSTMENTSSORTEDPROF

	SELECT * ,  
	[SEQUENCE] = ROW_NUMBER() OVER (PARTITION BY CLAIMID, CLAIMLINENUMBER ORDER BY CLAIMADJUSTMENTGROUPCODE desc)
	INTO ##CLAIMADJUSTMENTSSORTEDPROF
	FROM ##CLAIMADJUSTMENTS


     UPDATE CSV431P
		SET
			 [2430_CAS01_ClaimAdjustmentGroup_1]				= CASADJ1.ClaimAdjustmentGroupCode
			,[2430_CAS02_ClaimAdjustmentReason_1]				= CASADJ1.ClaimAdjustmentReason
			,[2430_CAS03_ClaimAdjustmentAmount_1]				= CASADJ1.ClaimAdjustmentAmount
			,[2430_CAS01_ClaimAdjustmentGroup_2]				= CASADJ2.ClaimAdjustmentGroupCode
			,[2430_CAS02_ClaimAdjustmentReason_2]				= CASADJ2.ClaimAdjustmentReason
			,[2430_CAS03_ClaimAdjustmentAmount_2]				= CASADJ2.ClaimAdjustmentAmount
			,[2430_CAS01_ClaimAdjustmentGroup_3]				= CASADJ3.ClaimAdjustmentGroupCode
			,[2430_CAS02_ClaimAdjustmentReason_3]				= CASADJ3.ClaimAdjustmentReason
			,[2430_CAS03_ClaimAdjustmentAmount_3]				= CASADJ3.ClaimAdjustmentAmount
			,[2430_CAS01_ClaimAdjustmentGroup_4]				= CASADJ4.ClaimAdjustmentGroupCode
			,[2430_CAS02_ClaimAdjustmentReason_4]				= CASADJ4.ClaimAdjustmentReason
			,[2430_CAS03_ClaimAdjustmentAmount_4]				= CASADJ4.ClaimAdjustmentAmount
	FROM [Medicaid].[dbo].[EE_CSV_431P_Rec_Detail] CSV431P
	LEFT JOIN ##CLAIMADJUSTMENTSSORTEDPROF CASADJ1 ON CSV431P.ClaimID = CASADJ1.CLAIMID AND CSV431P.ClaimLineNumber = CASADJ1.CLAIMLINENUMBER AND CASADJ1.SEQUENCE = '1'
	LEFT JOIN ##CLAIMADJUSTMENTSSORTEDPROF CASADJ2 ON CSV431P.ClaimID = CASADJ2.CLAIMID AND CSV431P.ClaimLineNumber = CASADJ2.CLAIMLINENUMBER AND CASADJ2.SEQUENCE = '2'
	LEFT JOIN ##CLAIMADJUSTMENTSSORTEDPROF CASADJ3 ON CSV431P.ClaimID = CASADJ3.CLAIMID AND CSV431P.ClaimLineNumber = CASADJ3.CLAIMLINENUMBER  AND CASADJ3.SEQUENCE = '3'
	LEFT JOIN ##CLAIMADJUSTMENTSSORTEDPROF CASADJ4 ON CSV431P.ClaimID = CASADJ4.CLAIMID AND CSV431P.ClaimLineNumber = CASADJ4.CLAIMLINENUMBER  AND CASADJ4.SEQUENCE = '4'
	LEFT JOIN ##CLAIMADJUSTMENTSSORTEDPROF CASADJ5 ON CSV431P.ClaimID = CASADJ5.CLAIMID AND CSV431P.ClaimLineNumber = CASADJ5.CLAIMLINENUMBER  AND CASADJ5.SEQUENCE = '5'
	END;


		/**************************************************************************************************************************
		DMR Record Updates 
		************************************************************************************************************************/
		IF @JOBID = '6002'
		BEGIN 
			UPDATE CSV100I
				SET 
				 [2010AA_NM103_BillingOrg_LastName]  					= 'MBRPAID'	
				,[2010AA_NM104_BillingFirstName]						= ''	
				,[2010AA_NM109_BillingProviderIdentifier]				= ''		
				,[2010AA_N301_BillingAddressLine1]						= ''	
				,[2010AA_N302_BillingAddressLine2]						= ''
				,[2010AA_N401_BillingCity]								= ''	
				,[2010AA_N402_BillingState]								= ''	
				,[2010AA_N403_BillingPostalCode]						= ''		
				,[2010AA_REF02_BillingProviderIdentifier_1]				= '626001445'	
				,[2010AA_PER04_BillingProviderCommunicationNumber_1]	= ''		
				,[2000A_PRV03_BillingProviderTaxonomy]					= '174400000X'
			FROM  [Medicaid].[dbo].[EE_CSV_100I_Rec_Header] CSV100I
		END;
		

		IF @JOBID = '6003'
			BEGIN 
				UPDATE CSV100P
				SET 
				 [2010AA_NM103_BillingOrg_LastName]  					= 'MBRPAID'	
				,[2010AA_NM104_BillingFirstName]						= ''	
				,[2010AA_NM109_BillingProviderIdentifier]				= ''		
				,[2010AA_N301_BillingAddressLine1]						= ''	
				,[2010AA_N302_BillingAddressLine2]						= ''
				,[2010AA_N401_BillingCity]								= ''	
				,[2010AA_N402_BillingState]								= ''	
				,[2010AA_N403_BillingPostalCode]						= ''		
				,[2010AA_REF02_BillingProviderIdentifier_1]				= '626001445'	
				,[2010AA_PER04_BillingProviderCommunicationNumber_1]	= ''		
				,[2000A_PRV03_BillingProviderTaxonomy]					= '174400000X'
			FROM  [Medicaid].[dbo].[EE_CSV_100P_Rec_Header] CSV100P
			END;	

		
/* NDC AND CPT Mapping for claims with J% Procedure Codes */

	IF @CLAIM_TYPE = 'I'
 BEGIN 
     UPDATE CSV40I
		SET
			[2410I_LIN03_NationalDrugCode]  = ndckey
		   ,[2410I_CTP04_Quantity]			= FORMAT(CLMPHRM.metricqty,'0.00##')
	       ,[2410I_CTP05_01_Units]			= UnitOfMeasure			
	FROM [Medicaid].[dbo].[EE_CSV_40I_Rec_Detail] CSV40I
	LEFT JOIN Medicaid.dbo.claimpharm CLMPHRM ON CSV40I.ClaimID = CLMPHRM.claimid AND CSV40I.ClaimLineNumber = CLMPHRM.claimline
			  AND  CSV40I.[2400I_SV202_02_ServiceCode] LIKE 'J%'
	END;
			 

	IF @CLAIM_TYPE = 'P'
 BEGIN
	UPDATE CSV40P
		SET
			 [2410P_LIN03_NationalDrugCode]  = ndckey
			,[2410P_CTP04_Quantity]			 =  FORMAT(CLMPHRM.metricqty,'0.00##')
			,[2410P_CTP05_01_Units]			 = UnitOfMeasure
	FROM [Medicaid].[dbo].[EE_CSV_40P_Rec_Detail] CSV40P
	LEFT JOIN Medicaid.dbo.claimpharm CLMPHRM ON CSV40P.ClaimID = CLMPHRM.claimid AND CSV40P.ClaimLineNumber = CLMPHRM.claimline
		AND CSV40P.[2400P_SV101_02_ServiceCode] like 'J%' 
	END;
/*    SYSLOG UPDATES - END OF PROCESS 
----------------------------------------------------------------------------------------------------------*/ 
						
						UPDATE dbo.EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = ''
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'dbo.MedicaidTennCareCGUpdates' + '-'  + rtrim(@CLAIM_TYPE)
										and END_DT is null

