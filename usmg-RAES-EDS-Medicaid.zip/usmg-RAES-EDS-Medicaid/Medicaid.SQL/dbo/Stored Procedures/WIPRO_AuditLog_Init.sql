﻿


CREATE  PROCEDURE [dbo].[WIPRO_AuditLog_Init]
(
	@DataSourceID			NVARCHAR(50),
	@DataSource				NVARCHAR(50),
	@DataTarget				NVARCHAR(50),
	@ProcessName			NVARCHAR(50),
	@PackageGUID			NVARCHAR(50),
	@PackageName			NVARCHAR(100),
	@PackageVersionMajor	INT,
	@PackageVersionMinor	INT,
	@PackageVersionBuild	INT,
	@StartDT				DATETIME
)
/**********************************************************************************************
PROCEDURE:	[dbo].[WIPRO_AuditLog_Init]
PURPOSE:	Creates initial audit record for EDS ETL processes
NOTES:		
CREATED:	2012-12-14
REVISIONS:
Date		Author			Description
------------------------------------------------------------------------------------------------
2012-12-14	Dwight Staggs	Original
*************************************************************************************************/
AS

BEGIN

	SET NOCOUNT ON;
	DECLARE @AuditID			INT,
			@CatchErrorMessage	VARCHAR(2200);
			
	IF @StartDT IS NULL
	BEGIN
		SET @StartDT = GETDATE()
	END
	
	
	BEGIN TRY
		INSERT INTO
			dbo.EDS_AuditLog
           ([AuditDate]
           ,[DataSourceID]
           ,[DataSource]
           ,[DataTarget]
           ,[ProcessName]
           ,[SourceCount]
		   ,[StagingPreCount]
		   ,[StagingPostCount]
		   ,[StagingProcessCount]
           ,[TargetPreCount]
           ,[TargetPostCount]
           ,[TargetProcessCount]
           ,[PackageGUID]
           ,[PackageName]
           ,[PackageVersionMajor]
           ,[PackageVersionMinor]
           ,[PackageVersionBuild]
           ,[StartDT]
           ,[EndDT]
           ,[ExecutionStatus]
           )
		SELECT
			GETDATE(),
			@DataSourceID,
			@DataSource,
			@DataTarget,
			@ProcessName,
			0,								--	SourceCount
			0,								--	StagingPreCount
			0,								--	StagingPostCount
			0,								--	StagingProcessCount
			0,								--	TargetPreCount
			0,								--	TargetPostCount
			0,								--	TargetProcessCount
			@PackageGUID,
			@PackageName,
			@PackageVersionMajor,
			@PackageVersionMinor,
			@PackageVersionBuild,
			@StartDT,
			NULL,							--	@EndDT,
			'Executing'						--	@ExecutionStatus
			
		SELECT CAST(SCOPE_IDENTITY() AS INT) AS 'AuditID'
			
	END TRY
	
	BEGIN CATCH
		SELECT @CatchErrorMessage = 
			'Procedure: ' + 
			OBJECT_NAME(@@PROCID) +
			' || ErrorNumber: ' + 
			CAST(ERROR_NUMBER() AS VARCHAR(10)) +
			' || ErrorMessage: ' +
			ERROR_MESSAGE() +
			' || ErrorLine: ' +
			CAST(ERROR_LINE() AS VARCHAR(10));
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;
		RAISERROR(@CatchErrorMessage, 16, 1);
	END CATCH
	
END

/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()

BEGIN TRANSACTION
	
	EXEC [dbo].[WIPRO_AuditLog_Init]
	@DataSourceID			= '2',
	@DataSource				= 'BIDW.ClaimDim',
	@DataTarget				= 'dbo.ClaimDim',
	@ProcessName			= 'BIDW_to_EDS_DataLoad',
	@PackageGUID			= '6819782D-6E56-472A-BB26-95AFCD6C0ABB',
	@PackageName			= 'HRP_EDPS_DEV_DataLoad_v5.dtsx',
	@PackageVersionMajor	= 1,
	@PackageVersionMinor	= 0,
	@PackageVersionBuild	= 332,
	@StartDT				= '2012-12-14 13:27:05.003'

		
ROLLBACK TRANSACTION

SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/






