﻿



CREATE PROCEDURE [dbo].[EDS_CMS_837LoTN_ENC_45DAY_Reject_Load]
--(
--@FILENAME CHAR(256) = 'test.txt'
--,@elesep char(1) = '*'
--,@segsep char(1) = '~'
--)
AS
/***************************************************************************************************
** CREATE DATE: 11/2022
**
** AUTHOR: Henry faust
**
** DESCRIPTION: 
**   RMT-13 45Day Report Automation 
 
**      Take rows/data from [Medicaid].[staging].[TN_ENC_45DAY_Reject_Hold] and get the data for
**     the fields for [Medicaid].[staging].[TN_ENC_45DAY_Reject_Load]
**       [CLAIM_ID]
**      ,[Reponse_Errortype]
**      ,[Response_ErrorCode]
**     ,[Response_ErrorDesc]
**     ,[Response_Loaddate]      
**              
**               
**
**
**/


declare @FILENAME CHAR(256) = 'test.txt'
,@elesep char(1) = ','
,@segsep char(1) = ','

DECLARE @CursorTestID INT = 1;
DECLARE @RunningTotal BIGINT = 0;
DECLARE @RowCnt BIGINT = 0;
declare @Seg varchar(1000),
		
		@x int =0, @y int = 0, @z int =0,
		@claimID varchar(20) = '',
		@errortype varchar(20) ='',
		@errorcode varchar(20) ='',
		@errordesc varchar(500) ='',
		@loaddate varchar(20) ='',
		@enum int = 0,
		@ele varchar(1000) = '' ;

-------------------------------------------------------------------------------------
    IF OBJECT_ID('TEMPDB..#TResp') <> 0
						   DROP TABLE #TResp

						   CREATE TABLE #TResp
						   (	[CLAIM_ID] [varchar](20) NULL,
							[Reponse_Errortype] [varchar](50) NULL,
							[Response_ErrorCode] [varchar](50) NULL,
							[Response_ErrorDesc] [varchar](500) NULL,
							[Response_Loaddate] [datetime] NULL
						   )

 -----------------------------------------------------------------------------------------------------------
 

DECLARE cur CURSOR FAST_FORWARD READ_ONLY LOCAL FOR
	SELECT segnum,segment
	FROM [staging].[TN_ENC_45DAY_Reject_Hold]

OPEN cur

FETCH NEXT FROM cur INTO @CursorTestID,@Seg

WHILE @@FETCH_STATUS = 0 BEGIN
set @Seg = @Seg +'@'  -- add end of segment terminator

--select 	 @CursorTestID,@Seg, charindex(@elesep,@seg, @x)
----------------------------------------------------------------------------------
----------------------------------------------------------------------------------
 
 	   begin
	   set @enum = 1
	   set @x = 0
	   set @y = 0
--select 'set enum = 1 ', @Seg
	    while @enum <= 6
		    begin 
			   if @enum = 6 --reason
			     Begin --if
				    set @x = charindex(',',@seg, @x) 
					set @y = charindex('@',@seg,@x+1)
				    set @ele = substring(@Seg,@x+1, @y-@x-1)
				    set @x = @y
		            if @enum = 6  set @errordesc = @ele;

--select 'X', @enum as enum,@x as x, @y as y, @ele as ele
				    set @enum = @enum +1
				 end --if
               else 
			     begin
				 set @x = charindex(',',@seg, @x)
				 set @y = charindex(',',@seg,@x+1)
				 set @ele = substring(@Seg,@x+1, @y-@x-1)
  		          if @enum = 1 set @claimID  = @ele;
		          if @enum = 4 set @errortype = @ele;
		          if @enum = 5 set @errorcode = @ele;

--select  @enum as enum,@x as x, @y as y, @ele as ele
				 set @enum = @enum +1
				 set @x = @y
              end --else
             end --end of while
		  end  --end of while fetch

insert into #TResp
  select @claimID,@errortype, @errorcode,@errordesc,getdate()



----------------------------------------------------------------------------------
----------------------------------------------------------------------------------


	FETCH NEXT FROM cur INTO @CursorTestID,@Seg

--select * from  #TResp

END

CLOSE cur
DEALLOCATE cur 
 -------------------------------------------------------------------------------------------------------------

 insert into [Medicaid].[staging].[TN_ENC_45DAY_Reject_Load]
   select * from  #TResp

  DROP TABLE #TResp


