﻿

CREATE PROCEDURE [dbo].[Submission_Exclusions]    
AS    
    
/***************************************************************************************************    
** CREATE DATE: 11/14/2022    
**    
** AUTHOR: Aaron Ridley  
**    
** DESCRIPTION: Procedure will identify all Medicaid Claims eligible for  Encounter File Exclusion.    
**              
*****************************************************************************************************
Modification History    
====================    
Date			Who				Description    
    
--------------------------------------------------------------------------------------------------------------------------------------------------------------    
11/14/22		Aaron Ridley    ADD HPLAN EXCLUSION LOGIC   
05/05/23		Aaron Ridley	ADD Florida Medicaid PML Provider exclusion 
 
-----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
                  DECLARE VARIABLES    
------------------------------------------------------------------------------*/
 
	DECLARE  		    
			@TOTAL_RECORDS INT    
			,@CURRENTDATE	DATE;

   SELECT @CURRENTDATE = getdate();

/*------------------------------------------------------------------------------
	Truncate current table to start with fresh exclusions every refresh 
-------------------------------------------------------------------------------*/
TRUNCATE TABLE  dbo.EXT_CLAIM_EXCLUSION 

IF OBJECT_ID('TEMPDB..#EXCLUSIONS') <> 0    
	DROP TABLE #EXCLUSIONS    
		    
		CREATE TABLE #EXCLUSIONS    
		    
		( CLAIMID VARCHAR(20),  
		  SOURCEDATAKEY INT,
		  BATCH_RUN_DT DATETIME, 
		  EXCL_ID INT,
		  CLAIM_TYPE CHAR(1), 
		  OPERATIONAL_MARKET VARCHAR(2)
		);  

/*-------------------------------------------------------------------------------
               Update syslog for process execution tracking 
--------------------------------------------------------------------------------*/
	INSERT INTO EXT_SYS_RUNLOG    
							(PROC_NAME    
							,STEP    
							,START_DT    
							,END_DT    
							,RUN_MINUTES    
							,TOTAL_RECORDS    
							,ENTRYDT    
							)    
	VALUES('Submission_Exclusions'    
							,'1'    
							,GETDATE()    
							,NULL    
							,NULL    
							,0    
							,GETDATE()    
							)  


/*-----------------------------------------------------------------------------------------------
-- first, collect all claims that aren't in an exclusion already, and available for submission.
 9070 Exlcusions - Excludes claims with Missing Diag Records or missing Primary Diag Records -- 
-----------------------------------------------------------------------------------------------*/

	INSERT INTO EXT_SYS_RUNLOG    
							(PROC_NAME    
							,STEP    
							,START_DT    
							,END_DT    
							,RUN_MINUTES    
							,TOTAL_RECORDS    
							,ENTRYDT    
							)    
	VALUES('Submission_Exclusions - Exclude Claims with no Prim DX'    
							,'1'    
							,GETDATE()    
							,NULL    
							,NULL    
							,0
							,GETDATE()    
							);
							
/*----------------------------------------------------------------------------------------
     START 9070 SELECTION 
---------------------------------------------------------------------------------------*/ 

WITH EXCL_9070 AS (
SELECT  EFS.CLAIMID, CDD.claimid as DiagClaim,  CDD.SOURCEDATAKEY, @CURRENTDATE AS BATCH_RUN_DT, 9070 AS EXCL_ID, EFS.CLAIM_TYPE, 'TN' AS OPERATIONAL_MARKET
	FROM Medicaid.dbo.EligibleforSubmission EFS
	INNER JOIN Medicaid.dbo.CLAIMDIAGNOSISDIM CDD
		on	CDD.SourceDataKey		= '50'
		and	CDD.CLAIMID			= EFS.CLAIMID
	WHERE EFS.RegulatoryMarket = 'TN'
	group by CDD.SOURCEDATAKEY, EFS.CLAIMID ,CDD.claimid, EFS.CLAIM_TYPE
	)	
	INSERT INTO #EXCLUSIONS
	SELECT DISTINCT CLAIMID, '50', BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE, OPERATIONAL_MARKET  
	FROM EXCL_9070 WHERE DIAGCLAIM IS NULL or DIAGCLAIM NOT IN (SELECT CLAIMID FROM Medicaid.dbo.CLAIMDIAGNOSISDIM WHERE DIAGNOSISTYPECODE = 'P');

	SET
	@TOTAL_RECORDS = (SELECT COUNT(*) FROM #EXCLUSIONS WHERE EXCL_ID = 9070);
/*----------------------------------------------------------------------------------------------------
          9070 SYSLOG UPDATE POST EXCLUSION RUN 
-----------------------------------------------------------------------------------------------------*/

	UPDATE EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @TOTAL_RECORDS
		,ENTRYDT = GETDATE()    
	WHERE PROC_NAME = 'Submission_Exclusions - Exclude Claims with no Prim DX'    
	AND END_DT IS NULL

/*----------------------------------------------------------------------------------------------------
       1. INSERT IDENTIFIED EXCLUSION INTO THE FINAL TABLE
	   2. UPDATE SUBMISSION TABLE, SETTING EXCLUDED CLAIMS TO E. THIS WILL SUPPRESS SUBMISSIONS 
	   3. FINALIZE SYSLOG UPDATE
-----------------------------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------------------------
- 9071 Exlcusions - Florida Medicaid - Billing NPI Not available in PML File                    -- 
-----------------------------------------------------------------------------------------------*/

	INSERT INTO EXT_SYS_RUNLOG    
							(PROC_NAME    
							,STEP    
							,START_DT    
							,END_DT    
							,RUN_MINUTES    
							,TOTAL_RECORDS    
							,ENTRYDT    
							)    
	VALUES('Submission_Exclusions(FL)Missing NPI'    
							,'2'    
							,GETDATE()    
							,NULL    
							,NULL    
							,0
							,GETDATE()    
							);
							
/*----------------------------------------------------------------------------------------
     START 8005 SELECTION 
---------------------------------------------------------------------------------------*/ 

WITH EXCL_8005 AS (
SELECT  DISTINCT EFS.CLAIMID, CD.VENDORNPI,  CD.SOURCEDATAKEY, @CURRENTDATE AS BATCH_RUN_DT, 8005 AS EXCL_ID, EFS.CLAIM_TYPE, 'FL' AS OPERATIONAL_MARKET
	FROM Medicaid.dbo.EligibleforSubmission EFS
	INNER JOIN Medicaid.dbo.CLAIMDIM CD
		on	CD.SourceDataKey		= '50'
		and	CD.CLAIMID			= EFS.CLAIMID
	WHERE EFS.RegulatoryMarket = 'FL'
	)	
	INSERT INTO #EXCLUSIONS
	SELECT DISTINCT CLAIMID, '50', BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE, OPERATIONAL_MARKET  
	FROM EXCL_8005 WHERE VENDORNPI NOT IN (SELECT NPI FROM Medicaid.dbo.FLORIDA_PROVIDER_MASTER_LIST);

	SET
	@TOTAL_RECORDS = (SELECT COUNT(*) FROM #EXCLUSIONS WHERE EXCL_ID = 8005);
/*----------------------------------------------------------------------------------------------------
          8005 SYSLOG UPDATE POST EXCLUSION RUN 
-----------------------------------------------------------------------------------------------------*/

	UPDATE EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @TOTAL_RECORDS
		,ENTRYDT = GETDATE()    
	WHERE PROC_NAME = 'Submission_Exclusions(FL)Missing NPI'    
	AND END_DT IS NULL;

/*----------------------------------------------------------------------------------------
     START 9000 SELECTION 
---------------------------------------------------------------------------------------*/ 

WITH EXCL_9000 AS (
SELECT  DISTINCT EFS.CLAIMID, CD.VENDORNPI,  CD.SOURCEDATAKEY, @CURRENTDATE AS BATCH_RUN_DT, 9000 AS EXCL_ID, EFS.CLAIM_TYPE, 'TN' AS OPERATIONAL_MARKET
    FROM Medicaid.dbo.EligibleforSubmission EFS
    INNER JOIN Medicaid.dbo.CLAIMDIM CD
        on    CD.SourceDataKey        = '50'
        and    CD.CLAIMID            = EFS.CLAIMID
        and CD.BeginServiceDateKey > '20231231'
        and EFS.SUBMISSION_TYPE NOT LIKE '%DMR%'
    WHERE EFS.RegulatoryMarket = 'TN'
    ) 
    INSERT INTO #EXCLUSIONS
    SELECT DISTINCT CLAIMID, '50', BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE, OPERATIONAL_MARKET  
    FROM EXCL_9000;

	SET
	@TOTAL_RECORDS = (SELECT COUNT(*) FROM #EXCLUSIONS WHERE EXCL_ID = 9000);
/*----------------------------------------------------------------------------------------------------
          9000 SYSLOG UPDATE POST EXCLUSION RUN 
-----------------------------------------------------------------------------------------------------*/

	UPDATE EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @TOTAL_RECORDS
		,ENTRYDT = GETDATE()    
	WHERE PROC_NAME = 'Submission_Exclusions(TN)DOS Out of Range'    
	AND END_DT IS NULL

/*----------------------------------------------------------------------------------------------------
       1. INSERT IDENTIFIED EXCLUSION INTO THE FINAL TABLE
	   2. UPDATE SUBMISSION TABLE, SETTING EXCLUDED CLAIMS TO E. THIS WILL SUPPRESS SUBMISSIONS 
	   3. FINALIZE SYSLOG UPDATE
-----------------------------------------------------------------------------------------------------*/

	INSERT INTO Medicaid.dbo.EXT_CLAIM_EXCLUSION
	SELECT * FROM #EXCLUSIONS; 

	UPDATE EFS
	SET SubmissionStatus = CASE WHEN ECE.CLAIM_ID IS NULL THEN 'N' ELSE 'E' END 
	FROM Medicaid.dbo.EligibleforSubmission EFS
	LEFT JOIN Medicaid.dbo.EXT_CLAIM_EXCLUSION ECE ON EFS.CLAIMID = ECE.CLAIM_ID;

SET @TOTAL_RECORDS = (SELECT COUNT(*)  FROM #EXCLUSIONS);	    
				---HRP_CLAIM_FILE Update Run Controls    
						    
	UPDATE EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @TOTAL_RECORDS    
		,ENTRYDT = GETDATE()    
	WHERE PROC_NAME = 'Submission_Exclusions'    
			AND END_DT IS NULL;