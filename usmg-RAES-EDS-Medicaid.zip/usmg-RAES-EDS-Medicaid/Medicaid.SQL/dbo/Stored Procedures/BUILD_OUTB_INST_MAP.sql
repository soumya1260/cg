﻿

CREATE PROCEDURE [dbo].[BUILD_OUTB_INST_MAP]
( @LOB CHAR(10),
@LOBCODE VARCHAR(15),
@JOBID INT
)
AS
/********************************************************************************************************************************************************************
  01-17-2020		Anthony Ulmer	Created based on [BUILD_OUTB_PROF_MAP] procedure contained in MEDICAID database
  08/25/2020        Aaron Ridley    TETDM-2337 Added logic to accommodate MMP file naming convention
  02/24/2020        Aaron Ridley    TETDM-2359 - FileID updated to accommodate Adjustment file generation
  09/16/2024		Anthony Ulmer	MES-84 changes to accomodate Medicaid processes
  09/12/2022		Sasi T			RMT-10 populate [Filedate] Column in [Medicaid].[dbo].[OUTB_CLAIM_STATUS]  
  04/13/2023		Aaron Ridley	Medicaid update to use Configuration tables as we incorporate FL/PA 
*********************************************************************************************************************************************************************/
/* Modifications

07/14/2020	Scott Waller	EDS-2343	Correct the TOTAL_CLAIM and FILEDESC values in the OUTB_FILE_HIST table

*/

SET NOCOUNT ON;

	DECLARE @TOTAL_RECORDS INT
		   ,
			--FILE FOOTER	  
			@TOTAL_CLAIM INT
		   ,@TOTAL_PROF_CLM INT
		   ,@TOTAL_INST_CLM INT
		   ,@TOTAL_DENTAL_CLM INT
		   ,@TOTAL_LINES INT
		   ,@SUM_TOTAL_CHARGES MONEY
		   ,@SUM_LINE_CHARGES MONEY
		   ,@SUM_TOTAL_CHARGES2 MONEY
		   ,@SUM_LINE_CHARGES2 MONEY
		   ,@TOTAL_EOF_COUNT INT
		   ,@CREATEDT CHAR(14)
		   ,@FILEID CHAR(50)
		   ,@FOOTER CHAR(255)
		   ,@HEADER_CNTRL INT
		   ,@FOOTER_CNTRL INT
		   ,@RECHEADER_CNTRL INT
		   ,@RECDTL_CNTRL INT
		   ,@RECOTH_CNTRL INT
		   ,@FILE_TYPE CHAR(50) = 'Claim Encounter'
		   ,@VERSION CHAR(10) = '1.5.3'
		   ,@SOURCEDATAKEY INT
		   ,@FILEDESC VARCHAR(35)
		   ,@CLAIMTYPE VARCHAR(1)
		   ,@PRODUCTINDICATOR VARCHAR(4)
		   ,@FILESUBTYPE VARCHAR(15)
		   ,@SUBMITTERID VARCHAR(15)
		   ,@PRODUCTNODE VARCHAR(7)
		   ,@MISSINGDTLCTR INT
		   ,@Procedure_Name VARCHAR(75) = 'MEDICAID.dbo.pr_BUILD_OUTB_INST_MAP (MEDICAID)' --MES-84
		   ,@Sender_ID VARCHAR(15) --MES-84
		   ,@Receiver_ID VARCHAR(13)
		   ,@IsAdjustment varchar(50); ----MES-84 Field Expanded from 7 to 11


	/* Set Variables  */ 

	SET @Receiver_ID = (SELECT [Receiver_ID] FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID); 
	SET @Sender_ID = (SELECT [Sender_ID] FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID); 

	--HRP_CLAIM_FILE Run controls  
	INSERT INTO MEDICAID.dbo.EXT_SYS_RUNLOG (PROC_NAME
	, STEP
	, START_DT
	, END_DT
	, RUN_MINUTES
	, TOTAL_RECORDS
	, ENTRYDT)
		VALUES (@Procedure_Name, '10', GETDATE(), NULL, NULL, 0, GETDATE());  

  -- 03/15/2018 Scott Waller  TETDM-1758
  --NOTE: NEED TO FIGURE OUT WHAT RESUB CODES WILL BE FOR MEDCAID CLAIMS
	/*
	IF @JOBID BETWEEN 2000 AND 2050
	BEGIN
		SELECT TOP 1
			@LOBCODE = TB.LOBCODE
		FROM MEDICAID.dbo.OUTB_MEDICAID_TEST_BED TB
		WHERE tb.TESTID = @JOBID;

		-- TETDM-1770
		SELECT TOP 1
			@LOB = TB.typecode
		FROM MEDICAID.dbo.OUTB_MEDICAID_TEST_BED TB
		WHERE tb.TESTID = @JOBID;
	END;
	*/

	--PROCEDURE VARIABLES  
		--IF @@SERVERNAME IN ('HSTNEDSDB01')  
		--	BEGIN   
		--		SET @PRODUCTINDICATOR = 'PROD';  
		--		SET @FILEID = 'HSCE.PROD.';  
		--	END;  
		--ELSE IF @@SERVERNAME IN ('HSTNEDSDEVDB02')   
		--	BEGIN   
		--		SET @PRODUCTINDICATOR = 'TEST';  
		--		SET @FILEID = 'HSCE.DEV.';  
		--	END;  
		--ELSE IF @@SERVERNAME IN ('HSTNEDSDEVDB01')   
		--	BEGIN   
		--		SET @PRODUCTINDICATOR = 'TEST';  
		--		SET @FILEID = 'HSCE.QA.';  
		--	END;  

		--This should only ever return one value.  if multiple are returned here, table is broken.	
		SELECT
			@PRODUCTINDICATOR = IIF(re.Enviornment != 'PROD','TEST',TRIM(re.Enviornment)),
			@FILEID = CONCAT('HSCE.',TRIM(re.Enviornment),'.')
		FROM WIPRO.dbo.Resolve_Environment re
		WHERE @@servername = re.Server_Name;		

		IF @PRODUCTINDICATOR IS NULL BEGIN;
    		THROW 51000, 'The Product Indicator cannot be NULL.  Check that the Resolve_Environment table is updated for the server running this script.', 1; 
		END; 
		--File naming convention Submitterid node assignment  
		--remove default @LOBCODE Value used by SSIS package  
		
		
		SET @CREATEDT = FORMAT(GETDATE(),'yyyyMMddhhmmss');   -- RMT-10
		BEGIN 
		SET @SOURCEDATAKEY = (SELECT DISTINCT SOURCEDATAKEY FROM MEDICAID.dbo.OUTB_INST_HEADER);  
		SET @CLAIMTYPE = (SELECT DISTINCT CLAIM_TYPE FROM MEDICAID.dbo.OUTB_INST_HEADER);  		
		SET @FILEDESC = CONCAT((SELECT RTRIM(SOURCEDESC) FROM MEDICAID.dbo.SourceDataDim WHERE SourceDataKey = @SOURCEDATAKEY) , '-', @CLAIMTYPE , '-', RTRIM(@LOB));
	    END

		--SET LOB Dynamically 
			SET @LOB = (SELECT LOB FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID);
			SET @PRODUCTNODE = (SELECT PRODUCTNODE FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID);
			SET @IsAdjustment = (SELECT [IsAdjustmentFlag] FROM Medicaid.dbo.MedicaidJobIDConfig  WHERE @JOBID = JOBID); 

			IF @PRODUCTNODE IN ('CAID','CAIDDMR') AND @IsAdjustment <> 'TRUE' AND @JOBID NOT IN ('6031','6032','6033','6034')
				BEGIN
				SET @FILEID = CONCAT(RTRIM(@FILEID),'',rtrim(@LOB),'.',RTRIM(@sourcedatakey),'.',@CLAIMTYPE,'.',@PRODUCTNODE,'.',FORMAT(GETDATE(),'yyyyMMddhhmmss'));
				END
      		ELSE IF @PRODUCTNODE IN ('CAID','CAIDDMR') AND @IsAdjustment = 'TRUE' AND @JOBID NOT IN ('6031','6032','6033','6034')
				BEGIN
				SET @FILEID = CONCAT(RTRIM(@FILEID),'',rtrim(@LOB),'.',RTRIM(@sourcedatakey),'.',@CLAIMTYPE,'.',@PRODUCTNODE,'.adjustment.',FORMAT(GETDATE(),'yyyyMMddhhmmss'));
				END;

			IF @PRODUCTNODE IN ('CAID','CAIDDMR') AND @IsAdjustment <> 'TRUE' AND @JOBID IN ('6031','6032','6033','6034')
				BEGIN
				SET @FILEID = CONCAT(RTRIM(@FILEID),'',rtrim(@LOB),'.',RTRIM(@sourcedatakey),'.',@CLAIMTYPE,'.',@PRODUCTNODE,'.MAO.',FORMAT(GETDATE(),'yyyyMMddhhmmss'));
				END
      		ELSE IF @PRODUCTNODE IN ('CAID','CAIDDMR') AND @IsAdjustment = 'TRUE' AND @JOBID NOT IN ('6031','6032','6033','6034')
				BEGIN
				SET @FILEID = CONCAT(RTRIM(@FILEID),'',rtrim(@LOB),'.',RTRIM(@sourcedatakey),'.',@CLAIMTYPE,'.',@PRODUCTNODE,'.adjustment.MAO.',FORMAT(GETDATE(),'yyyyMMddhhmmss'));
				END;
             
        

-- EDS-2343
		SET @TOTAL_CLAIM = (SELECT COUNT(*) FROM MEDICAID.dbo.OUTB_INST_HEADER);		
-- end		
		IF OBJECT_ID('tempdb.dbo.#Claim_Hold') IS NOT NULL
        	DROP TABLE #Claim_Hold;
			
		IF OBJECT_ID('tempdb.dbo.#data_rows') IS NOT NULL
			DROP TABLE #data_rows;		

		CREATE TABLE #data_rows
		(
			ID BIGINT PRIMARY KEY IDENTITY(1,1),
			Record_Type varchar(3),
			Record_Order INT,
			Claim_ID VARCHAR(50), --claimid in claimdim = 20, claimid in encounterclaimdim = 50
			Claim_Line_Number INT,
			Records VARCHAR(8000)	
		) WITH (DATA_COMPRESSION = ROW);



		DECLARE @header_record_counts INT;
		--100
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID, Records)
		SELECT
			Record_Type = '100'
		   ,Record_Order = 1
		   ,ecirh.ClaimID
		   ,Records =	CONCAT( '100','|'
					   ,LTRIM(RTRIM(ecirh.ClaimID										 )),'|'
					   ,LTRIM(RTRIM(ecirh.ClaimStatus									 )),'|'
					   ,LTRIM(RTRIM(ecirh.ClaimType										 )),'|'
					   ,LTRIM(RTRIM(ecirh.SenderID										 )),'|'
					   ,LTRIM(RTRIM(ecirh.Receiver_ID_									 )),'|'
					   ,LTRIM(RTRIM(ecirh.OriginatorID									 )),'|'
					   ,LTRIM(RTRIM(ecirh.Contract_ID									 )),'|'
					   ,LTRIM(RTRIM(ecirh.DestinationID									 )),'|'
					   ,LTRIM(RTRIM(ecirh.HistoricalIndicator							 )),'|'
					   ,LTRIM(RTRIM(ecirh.HistoricalDispositionStatus					 )),'|'
					   ,LTRIM(RTRIM(ecirh.HistoricalEncounterICN						 )),'|'
					   ,LTRIM(RTRIM(ecirh.HistoricalEncounterID							 )),'|'
					   ,LTRIM(RTRIM(ecirh.Paper											 )),'|'
					   ,LTRIM(RTRIM(ecirh.DME											 )),'|'
					   ,LTRIM(RTRIM(ecirh.Administrative_Denial							 )),'|'
					   ,LTRIM(RTRIM(ecirh.Chart_Review_Data								 )),'|'
					   ,LTRIM(RTRIM(ecirh.Source_										 )),'|'
					   ,LTRIM(RTRIM(ecirh.Filler										 )),'|'
					   ,LTRIM(RTRIM(ecirh.TraceNumber									 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_NM101_SubmitterEntityRole]				 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_NM102_SubmitterPersonIndicator]		 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_NM103_SubmitterLastName]				 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_NM108_SubmitterIdentifierQualifier]	 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_NM109_SubmitterIdentifier]				 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_PER01_01_SubmitterContactIdentifier]	 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_PER02_01_SubmitterContactName]			 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_PER03_01_SubmitterContactQualifier1]	 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_PER04_01_SubmitterContact1]			 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_PER05_01_SubmitterContacQualifier2]	 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_PER06_01_SubmitterContact2]			 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000B_NM101_ReceiverEntityRole_]				 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000B_NM102_PersonIndicator]					 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000B_NM103_ReceiverName]					 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000B_NM108_ReceiverIdentifierQualifier]		 )),'|'
					   ,LTRIM(RTRIM(ecirh.[1000B_NM109_ReceiverIdentifier]				 )),'|'
					   ,LTRIM(RTRIM(ecirh.[2000A_PRV01_BillingProviderCode]				 )),'|'
					   ,LTRIM(RTRIM(ecirh.[2000A_PRV02_BillingProviderCodeQualifier]     )),'|'
					   ,LTRIM(RTRIM(ecirh.[2000A_PRV03_BillingProviderTaxonomy]				 )),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_NM101_BillingProviderRole]				 )),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_NM102_BillingPersonIndicator]				 )),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_NM103_BillingOrg_LastName]				 )),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_NM104_BillingFirstName]					 )),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_NM105_BillingMiddleName]					 )),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_NM107_BillingSuffix]						 )),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_NM108_BillingProviderIdentifierQualifier]  )),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_NM109_BillingProviderIdentifier]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_N301_BillingAddressLine1]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_N302_BillingAddressLine2]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_N401_BillingCity]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_N402_BillingState]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_N403_BillingPostalCode]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_N404_BillingCountry]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_REF01_BillingProviderIdentifierQualifier_1]			)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_REF02_BillingProviderIdentifier_1]					)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_REF01_BillingProviderIdentifierQualifier_2]			)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_REF02_BillingProviderIdentifier_2]					)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_BillingProviderSpeciality]							)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_BillingProviderType_]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER01_BillingProviderContactFunction_1]				)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER02_BillingProviderContactName_1]					)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER03_BillingProviderCommunicationNumberQualifier_1]	)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER04_BillingProviderCommunicationNumber_1]			)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER05_BillingProviderCommunicatioNumberQualifier_1]	)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER06_BillingProviderCommunicationNumber_1]			)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER07_BillingProviderCommunicatioNumberQualifier_1]	)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER08_BillingProviderCommunicationNumber_1]			)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER01_BillingProviderContactFunction_2]				)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER02_BillingProviderContactName_2]					)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER03_CommunicatioNumberQualifier_2]					)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER04_BillingProviderCommunicationNumber_2]			)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER05_BillingProviderCommunicatioNumberQualifier_2]	)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER06_BillingProviderCommunicationNumber_2]			)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER07_BillingProviderCommunicatioNumberQualifier_2]   )),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AA_PER08_BillingProviderCommunicationNumber_2]           )),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AB_NM101_PayToProviderRole]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AB_NM102_PayToPersonIndicator]							)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AB_N301_PayToAddressLine1]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AB_N302_PayToAddressLine2]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AB_N401_PayToCity]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AB_N402_PayToState]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AB_N403_PayToPostalCode]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AB_N404_PayToCountry]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_NM101_PayToPlanOrganizationRole]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_NM102_PayToPlanPersonIndicator]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_NM103_PayToPlanName]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_NM108_PayToPlanOrganizationIDQualifier]				)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_NM109_PayToPlanOrganizationIdentifier]				)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_N301_PayToPlanAddressLine1]							)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_N302_PayToPlanAddressLine2]							)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_N401_PayToPlanCity]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_N402_PayToPlanState]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_N403_PayToPlanPostalCode]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_N404_PayToPlanCountry]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_REF01_OrganizationIDQualifier_1]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_REF02_OrganizationIdentifier_1]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_REF01_OrganizationIDQualifier_2]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010AC_REF02_OrganizationIdentifier_2]						)),'|'
					   ,LTRIM(RTRIM(ecirh.Claim_Encounter_Cleanup										)),'|'
					   ,LTRIM(RTRIM(ecirh.Atypical_Provider_Flag										)),'|'
					   ,LTRIM(RTRIM(ecirh.Supplemental_Interim_Flag										)),'|'
					   ,LTRIM(RTRIM(ecirh.Interim_Late_Charge_Flag										)),'|'
					   ,LTRIM(RTRIM(ecirh.IssuerIdentifier												)),'|'
					   ,LTRIM(RTRIM(ecirh.[100_Filler_05]												)),'|'
					   ,LTRIM(RTRIM(ecirh.[100R_MonetaryAmountChangeFlag]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[1000A_NM104_SubmitterFirstName]								)),'|'
					   ,LTRIM(RTRIM(ecirh.BillingCountyCode												)),'|'
					   ,LTRIM(RTRIM(ecirh.[100_Filler_06]												)),'|'
					   ,LTRIM(RTRIM(ecirh.ClaimInputMethod												)),'|'
					   ,LTRIM(RTRIM(ecirh.Rehab_Flag													)),'|'
					   ,LTRIM(RTRIM(ecirh.PS_Custom_Field_1												)),'|'
					   ,LTRIM(RTRIM(ecirh.Void_Reason													)),'|'
					   ,LTRIM(RTRIM(ecirh.PS_Custom_Field_2												)),'|'
					   ,LTRIM(RTRIM(ecirh.[100_Filler_12]												)),'|'
					   ,LTRIM(RTRIM(ecirh.[100_Filler_13]												)),'|'
					   ,LTRIM(RTRIM(ecirh.[100_Filler_14]												)),'|'
					   ,LTRIM(RTRIM(ecirh.[100_Filler_15]												)),'|'
					   ,LTRIM(RTRIM(ecirh.[100_Filler_16]                                               )),'|'
					   ,LTRIM(RTRIM(ecirh.[100_Filler_17])))  
		FROM MEDICAID.dbo.EE_CSV_100I_Rec_Header ecirh;

		SELECT @header_record_counts = @@rowcount; --count of this should be the total record count (header is a single record) in file

		--150
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID, Records)
		SELECT
			Record_Type = '150'
		   ,Record_Order = 2
		   ,ecirh.ClaimID
		   ,Records =	CONCAT('150','|'
					   ,LTRIM(RTRIM(ecirh.ClaimID															)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000B_SBR01_SubscriberPayerResponsibilitySequence]				)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000B_SBR02_SubscriberRelationship]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000B_SBR03_SubscriberPolicyNumber]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000B_SBR04_InsuredGroupName]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000B_SBR09_ClaimFilingIndicator]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_NM101_SubscriberPersonRole]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_NM102_SubscriberPersonIndicator]							)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_NM103_SubscriberLastName]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_NM104_SubscriberFirstName]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_NM105_SubscriberMiddleName]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_NM107_SubscriberSuffix]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_NM108_SubscriberIdentifierQualifer]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_NM109_SubscriberIdentifier]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_REF01_SubscriberSSNQualifier]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_REF02_Subscriber_Identifier_SSN]							)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_REF01_PropertyandCasualty_Qualifier]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_REF02_PropertyandCasualty_Identifier]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_N301_SubscriberAddressLine1]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_N302_SubscriberAddressLine2]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_N401_SubscriberCity]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_N402_SubscriberState]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_N403_SubscriberPostalCode]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_N404_SubscriberCountry]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_DMG01_DateQualifer]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_DMG02_DateOfBirth]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_DMG03_Gender]												)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_REF01_SubscriberIdentifierQualifier_1]					)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_REF02_SubscriberIdentifier_1]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_REF01_SubscriberIdentifierQualifer_2]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BA_REF02_SubscriberIdentifier_2]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_NM101_Payer_OrganizationRole]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_NM102_PayerPersonIndicator]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_NM103_PayerName]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_NM108_PayerOrganizationIDQualifier]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_NM109_PayerOrganizationIdentifier]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_N301_PayerAddressLine1]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_N302_PayerAddressLine2]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_N401_PayerCity]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_N402_PayerState]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_N403_PayerPostalCode]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_N404_PayerCountry]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_REF01_PayerOrganizationIDQualifier_1]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_REF02_PayerOrganizationIdentifier_1]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_REF01_ProviderIDQualifier_1]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_REF02_BillingProviderIdentifier_1]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_REF01_BillingProviderIDQualifier_2]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_REF02_BillingProviderIdentifier_2]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_REF01_BillingProviderIDQualifier_3]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_REF02_ProviderIdentifier_3]								)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_REF01_BillingProviderIDQualifier_4]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[2010BB_REF02_BillingProviderIdentifier_4]						)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_Last_Name]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_First_Name]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_Middle_Name]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_SSN]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_Member_ID]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_Gender]												)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_DOB]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_Address_Line1]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_Address_Line2]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_Address_City]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_Address_State]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Patient_Address_Zip]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_PCP_ID_Qual]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_PCP_ID]														)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_PCP_Group_Identifier]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_PDP_IPA_PMG_Type]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_PDP_IPA_PMG_ID]												)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_PCP_Open_Indic]												)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_PCP_Eligibility_Ind]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_COS]															)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Service_Category_Type]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Rendering_Prov_Eff_Date]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Rendering_Prov_Term_Date]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Rendering_Prov_DEA_ID]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Rendering_Prov_Gender]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Provider_Par_Non_Par]										)),'|'
					   ,LTRIM(RTRIM(ecirh.Care_Plan_Option_Indicator										)),'|'
					   ,LTRIM(RTRIM(ecirh.Group_Indentifier													)),'|'
					   ,LTRIM(RTRIM(ecirh.Care_Type_Code													)),'|'
					   ,LTRIM(RTRIM(ecirh.Financial_Arrangement_Code										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_05]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000B_SBR05_InsuranceTypeCode]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000B_PAT09_PregnancyIndicator]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_6]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_7]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_8]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_9]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_10]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_11]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_12]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_13]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_14]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_Filler_15]													)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000B_PAT06_PatientDeathDate]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000C_PAT01_PatientRelationship]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000C_PAT06_PatientDeathDate]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000C_PAT08_PatientWeight]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[2000C_PAT09_PregnancyIndicator]									)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_SubscriberRegionCode]										)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_SubscriberOtherInsuranceCoverage]							)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_PurchasedIndicator]											)),'|'
					   ,LTRIM(RTRIM(ecirh.[150_BehavioralHealth_COS]										)))
		FROM MEDICAID.dbo.EE_CSV_150I_Rec_Header ecirh;

		--20P
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID, Records)
		SELECT
			Record_Type = '20I'
		   ,Record_Order = 3
		   ,ecirh.ClaimID
		   ,records = CONCAT( --had to break up concat as it only accepts a max of 254 values
						CONCAT('20I','|'	
						,LTRIM(RTRIM(ecirh.[ClaimID]																)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CLM01_ClaimNumber]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CLM02_TotalClaimCharge]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CLM05-01_FacilityTypeCode]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CLM05-02_BillTypeQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CLM05-03_ClaimFrequencyCode]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CLM07_MedicareAssignment]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CLM08_BenefitAssignmentIndicator]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CLM09_ReleaseOfInformation]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CLM20_DelayReason]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP01_DateTimeQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP02_FormatQualifier_1]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP03_DateTime_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP01_DateTimeQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP02_FormatQualifier_2]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP03_DateTime_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP01_DateTimeQualifier_3]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP02_FormatQualifier_3]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP03_DateTime_3]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP01_DateTimeQualifier_4]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP02_FormatQualifier_4]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_DTP03_DateTime_4]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CL101_AdmissionType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CL102_AdmissionSource]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CL103_PatientStatus]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CN101_ContractTypeCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CN102_MonetaryAmount]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CN103_ContractPercentage]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CN104_ContractCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CN105_TermsDiscountPercent]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CN106_ContractVersionIdentifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_AMT01_AmountQualifier]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_AMT02_PatientAmountDue]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_ClaimReferenceNumberQualifier_1]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_ClaimReferenceNumber_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_ClaimReferenceNumberQualifier_2]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_ClaimReferenceNumber_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_ClaimReferenceNumberQualifier_3]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_ClaimReferenceNumber_3]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_ClaimReferenceNumberQualifier_4]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_ClaimReferenceNumber_4]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_ClaimReferenceNumberQualifier_5]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_ClaimReferenceNumber_5]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_ClaimReferenceNumberQualifier_6]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_ClaimReferenceNumber_6]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_ClaimReferenceNumberQualifier_7]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_ClaimReferenceNumber_7]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_ClaimReferenceNumberQualifier_8]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_ClaimReferenceNumber_8]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_NTE01_ClaimNoteType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_NTE02_ClaimNote]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_NTE01_BillNoteType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_NTE01_BillNote]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CRC01_ServiceCertificationCategory]								)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CRC02_ServiceCertificationIndicator]								)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CRC03_ConditionIndicatorCode]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CRC04_ConditionIndicatorCode]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_CRC05_ConditionIndicatorCode]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_PrinDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_PrincipalDXCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-09_PrincipalDXPOA]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_AdmittingDXType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_AdmittingDXCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_PatientDXType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_PatientDXCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_PatientDXType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_PatientDXCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_PatientDXType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_PatientDXCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-02_ECIDXCode]												)),'|')--BREAK CONCAT
						,CONCAT(LTRIM(RTRIM(ecirh.[2300I_HI11-09_ECIDXPOA]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_ECIDXType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_ECIDXCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-09_ECIDXPOA]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_DRGType]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_DRGCode]													)),'|'
						,LTRIM(RTRIM(ecirh.[20I_DRG_Version]														)),'|'
						,LTRIM(RTRIM(ecirh.[20I_DRG_Severity]														)),'|'
						,LTRIM(RTRIM(ecirh.[20I_DRG_Risk]															)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_DXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_DXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-09_DXPOA_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-01_DXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-02_DXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-09_DXPOA_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_PrincipalPXType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_PrincipalPXCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-03_PrincipalPXDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-04_PrincipalPXDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_PXType_1]													)),'|')--BREAK CONCAT
						,CONCAT(LTRIM(RTRIM(ecirh.[2300I_HI03-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_PXType_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_PXCode_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-03_PXDateQualifier_1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-04_PXDate_1]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_PXType_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_PXCode_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-03_PXDateQualifier_2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-04_PXDate_2]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_OccurSpanType]											)),'|')--BREAK CONCAT
						,CONCAT(LTRIM(RTRIM(ecirh.[2300I_HI04-02_OccurSpanCode]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-02_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-05_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_ValueCode_1 ]												)),'|')--BREAK CONCAT
						,CONCAT(LTRIM(RTRIM(ecirh.[2300I_HI06-05_ValueCodeAmount_1 ]								)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-02_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_ValueCodeQualifer_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_ValueCode_1 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-05_ValueCodeAmount_1 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_ValueCodeQualifer_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_ValueCode_2 ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-05_ValueCodeAmount_2 ]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI01-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI02-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI03-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI04-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI05-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI06-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI07-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI08-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI09-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI10-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI11-01_TreatmentCodeQualifier]									)),'|')--BREAK CONCAT
						,CONCAT(LTRIM(RTRIM(ecirh.[2300I_HI11-02_TreatmentCode ]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI12-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP01_PricingMethod ]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP02_AllowedAmount]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP03_SavingAmount]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP04_OrgID]														)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP05_PricingRate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP06_ApprovedDRGCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP07_ApprovedDRGAmount]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP08_ApprovedRevenueCode]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP11_Units]														)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP12_Quatity]													)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP13_RejectReason]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP14_PolicyCompliance]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HCP15_ExceptionCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_NM101_ProviderRole]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_NM102_PersonIndicator]											)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_NM103_LastName]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_NM104_FirstName]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_NM105_MiddleName]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_NM107_Suffix]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_NM108_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_NM109_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_PRV01_ProviderCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_PRV02_ProviderCodeQualifer]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_PRV03_ProviderTaxonomy]											)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_REF01_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_REF02_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_REF01_ProviderIdentifierQualifer_02]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310AI_REF02_ProviderIdentifier_02]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_NM101_ProviderRole]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_NM102_PersonIndicator]											)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_NM103_LastName]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_NM104_FirstName]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_NM105_MiddleName]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_NM107_Suffix]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_NM108_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_NM109_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_REF01_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_REF02_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_REF01_ProviderIdentifierQualifer_02]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310BI_REF02_ProviderIdentifier_02]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_NM101_ProviderRole]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_NM102_PersonIndicator]											)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_NM103_LastName]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_NM104_FirstName]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_NM105_MiddleName]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_NM107_Suffix]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_NM108_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_NM109_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_REF01_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_REF02_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_REF01_ProviderIdentifierQualifer_02]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310CI_REF02_ProviderIdentifier_02]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_NM101_ProviderRole]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_NM102_PersonIndicator]											)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_NM103_LastName]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_NM104_FirstName]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_NM105_MiddleName]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_NM107_Suffix]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_NM108_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_NM109_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_REF01_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_REF02_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_REF01_ProviderIdentifierQualifer_02]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310DI_REF02_ProviderIdentifier_02]										)),'|'
						,LTRIM(RTRIM(ecirh.[20I_RenderingProviderAddress1]											)),'|'
						,LTRIM(RTRIM(ecirh.[20I_RenderingProviderAddress2]											)),'|'
						,LTRIM(RTRIM(ecirh.[20I_RenderingProviderCity]												)),'|'
						,LTRIM(RTRIM(ecirh.[20I_RenderingProviderState]												)),'|'
						,LTRIM(RTRIM(ecirh.[20I_RenderingProviderZip]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_NM101_ProviderRole]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_NM102_PersonIndicator]											)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_NM103_ORG_LastName]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_NM108_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_NM109_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_N301_AddressLine1]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_N302_AddressLine2]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_N401_City]														)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_N402_State]														)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_N403_PostalCode]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_N404_Country]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_REF01_ProviderIdentifierQualifer1]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_REF02_ProviderIdentifier1]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_REF01_ProviderIdentifierQualifer2]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_REF02_ProviderIdentifier2]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_NM101_ProviderRole]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_NM102_PersonIndicator]											)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_NM103_LastName]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_NM104_FirstName]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_NM105_MiddleName]												)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_NM107_Suffix]													)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_NM108_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_NM109_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_REF01_ProviderIdentifierQualifer]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_REF02_ProviderIdentifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_REF01_ProviderIdentifierQualifer_02]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310FI_REF02_ProviderIdentifier_02]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_PWK01_AttachmentReportType]										)),'|')--BREAK CONCAT
						,CONCAT(LTRIM(RTRIM(ecirh.[2300I_PWK02_AttachmentTransmissionCode]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_PWK06_AttachmentControlNumber]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_ServiceAuthorizationExceptionCode_Qualifier]				)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_ServiceAuthorizationExceptionCode]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_InvestigationalDeviceExemptionNumber_Qualifier]				)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_InvestigationalDeviceExemptionNumber]						)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_DemonstrationProject_Qualifier]								)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_DemonstrationProjectIdentifier]								)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_PeerReviewOrganization_Qualifier]							)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF02_PeerReviewOrganizationNumber ]								)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation_Qualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation]											)),'|'
						,LTRIM(RTRIM(ecirh.[Claim Processor Receiver Date]											)),'|'
						,LTRIM(RTRIM(ecirh.[InNetworkIndicator ]													)),'|'
						,LTRIM(RTRIM(ecirh.PatientControlNumber														)),'|'
						,LTRIM(RTRIM(ecirh.[20I-Filler 04]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-Filler 05]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-Filler 06]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-Filler 07]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-Filler 08]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-IFiller 09]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-IFiller 10]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-IFiller 11]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-IFiller 12]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-IFiller 13]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-IFiller 14]															)),'|'
						,LTRIM(RTRIM(ecirh.[20I-IFiller 15]															)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-01_OccurSpanType]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-02_OccurSpanCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-03_OccurSpanDateQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-04_OccurSpanDate]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-01_OccurType]												)),'|')--BREAK CONCAT
						,CONCAT(LTRIM(RTRIM(ecirh.[2300I_HI19-02_OccurCode]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-01_OccurType]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-02_OccurCode]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-03_OccurDateQualifier]										)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-04_OccurDate]												)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-01_TreatmentCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-02_TreatmentCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI13-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI14-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI15-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI16-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI17-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI18-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI19-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI20-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI21-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI22-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI23-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-01_ConditionCodeQualifier]									)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_HI24-02_ConditionCode ]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation2]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation3]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation4]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation5]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation6]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation7]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation8]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation9]											)),'|'
						,LTRIM(RTRIM(ecirh.[2300I_REF01_FileInformation10]											)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_REF01_ProviderIdentifierQualifer3]								)),'|'
						,LTRIM(RTRIM(ecirh.[2310EI_REF02_ProviderIdentifier3]										))))
		FROM MEDICAID.dbo.EE_CSV_20I_Rec_Header ecirh;

		--310
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID, Records)
		SELECT
			Record_Type = '310'
		   ,Record_Order = 4
		   ,ecirh.ClaimID
		   ,Records = CONCAT(CONCAT('310','|'
		   ,LTRIM(RTRIM(ecirh.ClaimID												)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_SBR01_PayerResponsibilitySequence]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_SBR02_SubscriberRelationship]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_SBR03_PolicyNumber]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_ProductIDNumber]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_DelegatedBenefitAdminOrgID]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_SBR04_InsuredGroupName]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_SBR05_InsuranceType]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_SBR09_ClaimFilingIndicator]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_ClaimDisposition]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_1]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_2]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_3]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_4]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_5]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_6]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_7]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_8]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_9]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_10]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_11]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_12]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_13]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_14]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_15]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_16]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_17]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_18]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_19]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_20]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_21]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_22]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_23]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RiskAssessmentCode_24]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_ClaimLevelDenial_1]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_ClaimLevelDenial_2]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_ClaimLevelDenial_3]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_ClaimLevelDenial_4]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_ClaimLevelDenial_5]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_ClaimLevelDenial_6]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_ClaimLevelDenial_7]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_ClaimLevelDenial_8]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_ClaimLevelDenial_9]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_ClaimLevelDenial_10]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS01_ClaimAdjustmentGroup_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS02_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS03_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS04_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS05_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS06_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS07_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS08_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS09_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS10_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS11_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS12_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS12_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS14_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS15_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS16_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS17_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS18_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS19_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS01_ClaimAdjustmentGroup_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS02_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS03_ClaimAdjustmentAmount_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS04_ClaimAdjustmentquantity_2]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS05_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS06_ClaimAdjustmentAmount_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS07_ClaimAdjustmentquantity_2]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS08_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS09_ClaimAdjustmentAmount_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS10_ClaimAdjustmentquantity_2]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS11_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS12_ClaimAdjustmentAmount_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS12_ClaimAdjustmentquantity_2]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS14_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS15_ClaimAdjustmentAmount_2]					)),'|') --break concat
		   ,CONCAT(LTRIM(RTRIM(ecirh.[2320_CAS16_ClaimAdjustmentquantity_2]		)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS17_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS18_ClaimAdjustmentAmount_2]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS19_ClaimAdjustmentquantity_2]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS01_ClaimAdjustmentGroup_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS02_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS03_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS04_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS05_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS06_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS07_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS08_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS09_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS10_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS11_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS12_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS12_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS14_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS15_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS16_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS17_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS18_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS19_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS01_ClaimAdjustmentGroup_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS02_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS03_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS04_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS05_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS06_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS07_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS08_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS09_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS10_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS11_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS12_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS12_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS14_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS15_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS16_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS17_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS18_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS19_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS01_ClaimAdjustmentGroup_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS02_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS03_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS04_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS05_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS06_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS07_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS08_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS09_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS10_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS11_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS12_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS12_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS14_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS15_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS16_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS17_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS18_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_CAS19_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_AMT01_AmountQualifier_1]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_AMT02_COBAmount_1]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_AMT01_AmountQualifier_2]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_AMT02_COBAmount_2]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_AMT01_AmountQualifier_3]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_AMT02_COBAmount_3]								)),'|')--Break Concat
		   ,CONCAT(LTRIM(RTRIM(ecirh.[2320_OI03_AssignBenefitsIndicator]			)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_OI04_PatientSignature]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_OI06_ReleaseOfInformation]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA01_AdjudQuantity]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA03_AdjudQuantity]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA04_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA05_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA06_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA07_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA08_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA09_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA10_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA11_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA12_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA13_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA14_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA15_AdjudQuantity]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA16_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA17_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA18_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA19_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA20_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA21_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA22_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA23_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MIA24_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MOA01_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MOA02_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MOA03_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MOA04_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MOA05_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MOA06_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MOA07_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MOA08_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2320_MOA09_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_NM101_PersonRole]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_NM102_PersonIndicator]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_NM103_LastName]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_NM104_FirstName]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_NM105_MiddleName]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_NM107_Suffix]									)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_NM108_PersonIdentifierQualifier]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_NM109_PersonIdentifier]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_N301_AddressLine1]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_N302_AddressLine2]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_N401_City]									)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_N402_State]									)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_N403_PostalCode]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330A_N404_Country]									)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_NM101_OrganizationRole]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_NM102_PersonIndicator]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_NM103_Name]									)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_NM108_OrganizationIdQualifier]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_NM109_OrganizationIdentifier]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_N301_AddressLine1]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_N302_AddressLine2]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_N401_City]									)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_N402_State]									)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_N403_PostalCode]								)),'|') --Break concat
		   ,CONCAT(LTRIM(RTRIM(ecirh.[2330B_N404_Country]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_DTP01_DateTimeQualifier]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_DTP02_DateTimeFormat]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_DTP03_ClaimPaidDate]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_OverPaymentID]									)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_OrganizationIdQualifier_1]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_OrganizationIdentifier_1]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_OrganizationIdQualifier_2]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_OrganizationIdentifier_2]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_OrganizationIdQualifier_3]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_OrganizationIdentifier_3]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_OrganizationIdQualifier_4]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_OrganizationIdentifier_4]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_OrganizationIdQualifier_5]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_OrganizationIdentifier_5]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_ReportBeginDate]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_ReportEndDate]									)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_PaymentYear]									)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF01_AdjudicatedDRGQualifier]				)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF02_AdjudicatedDRG]							)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF04-01_ReferenceIdentificationQualifier]	)),'|'
		   ,LTRIM(RTRIM(ecirh.[2330B_REF04-02_DRGGrouperVersion]					)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_Rate_Increase_Indicator]						)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_Bundle_Indicator]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_Bundle_Claim_Number]							)),'|'
		   ,LTRIM(RTRIM(ecirh.ClaimApprovedAmount									)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_PaymentCheckDate]								)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_03]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_04]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_05]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_06]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_07]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_08]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_09]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_10]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_11]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_12]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_13]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_14]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310-Filler_15]										)),'|'
		   ,LTRIM(RTRIM(ecirh.[310_RecipientAidCategory]							))))
		FROM MEDICAID.dbo.EE_CSV_310I_Rec_Header ecirh;

		--40P
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID,Claim_Line_Number, Records)
		SELECT
			Record_Type = '40I'
			,Record_Order = 5
			,ecird.ClaimID
			,ClaimLineNumber = CAST(ecird.ClaimLineNumber AS INT)
			,Records = CONCAT(CONCAT('40I','|'															  
					,LTRIM(RTRIM(ecird.ClaimID															)),'|'					
					,TRY_CAST(ecird.[2400I_LX01_LineCounter] AS INT) 									  ,'|'
					,LTRIM(RTRIM(ecird.[2400I_SV201_RevenueCode]										)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV202_01_ServiceCodeType]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV202_02_ServiceCode]										)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV202_03_ServiceModifier1]								)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV202_04_ServiceModifier2]								)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV202_05_ServiceModifier3]								)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV202_06_ServiceModifier4]								)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV202_07_ServiceCodeDescription]							)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV203_LineCharge]											)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV204_ServiceUnitMeasure]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV205_Quantity]											)),'|'
					,LTRIM(RTRIM(ecird.[2400I_SV207_NonCoveredCharge]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_PWK01_ReportType]											)),'|'
					,LTRIM(RTRIM(ecird.[2400I_PWK02_TransmissionCode]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_PWK05_CodeQualifier]										)),'|'
					,LTRIM(RTRIM(ecird.[2400I_PWK06_ControlNumber]										)),'|'
					,LTRIM(RTRIM(ecird.[2400I_DTP01_DateTimeQualifier]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_DTP02_FormatQualifier]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_DTP03_Date]												)),'|'
					,LTRIM(RTRIM(ecird.[2400I_REF01_ServiceRefNumberQualifier]							)),'|'
					,TRY_CAST(ecird.[2400I_REF02_ServiceRefNumber] AS INT)								  ,'|'
					,LTRIM(RTRIM(ecird.[2410I_LIN02_DrugCodeType]										)),'|'
					,LTRIM(RTRIM(ecird.[2410I_LIN03_NationalDrugCode]									)),'|'
					,LTRIM(RTRIM(ecird.[2410I_CTP04_Quantity]											)),'|'
					,LTRIM(RTRIM(ecird.[2410I_CTP05_01_Units]											)),'|'
					,LTRIM(RTRIM(ecird.[2410I_REF01_ReferenceIDQualifier]								)),'|'
					,LTRIM(RTRIM(ecird.[2410I_REF02_ReferenceIdentifier]								)),'|'
					,LTRIM(RTRIM(ecird.[2400I_REF01_RepricedLineItemReference_Qualifier]				)),'|'
					,LTRIM(RTRIM(ecird.[2400I_REF02_RepricedLineItemReferenceNumber]					)),'|'
					,LTRIM(RTRIM(ecird.[2400I_REF01_AdjustedRepricedLineItemReference_Qualifier]		)),'|'
					,LTRIM(RTRIM(ecird.[2400I_REF02_AdjustedRepricedLineItemReferenceNumber]			)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP01_PricingMethodology]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP02_RepricedAllowedAmt]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP03_RepricedSavingAmt]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP04_RepricingOrganziationIdentifier]					)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP05_RepricingPerDiem]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP06_APGPricingCode]										)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP07_APGPricingAmt]										)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP09_ServiceType]										)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP10_ApprovedServiceCode]								)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP11_RepricingUnits]										)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP12_RepricingQuantity]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP13_RejectReasonCode]									)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP14_PolicyComplianceCode]								)),'|'
					,LTRIM(RTRIM(ecird.[2400I_HCP15_ExceptionCode]										)),'|'
					,LTRIM(RTRIM(ecird.[2410I_REF01_ReferenceIDQualifier_2]								)),'|'
					,LTRIM(RTRIM(ecird.[2410I_REF02_ReferenceIdentifier_2]								)),'|'
					,LTRIM(RTRIM(ecird.[40I_Filler_01]													)),'|'
					,LTRIM(RTRIM(ecird.[40I_Filler_02]													)),'|'
					,LTRIM(RTRIM(ecird.[40I_Filler_03]													)),'|'
					,LTRIM(RTRIM(ecird.[40I_Filler_04]													)),'|'
					,LTRIM(RTRIM(ecird.[40I_Filler 05]													)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_NM101_ProviderRole]										)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_NM102_PersonIndicator]									)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_NM103_LastName]											)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_NM104_FirstName]											)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_NM105_MiddleName]										)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_NM107_Suffix]											)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_NM108_ProviderIdentifierQualifer]						)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_NM109_ProviderIdentifier]								)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_REF01_ProviderIdentifierQualifer_1]						)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_REF02_ProviderIdentifier_1]								)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_REF01_ProviderIdentifierQualifer_2]						)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_REF02_ProviderIdentifier_2]								)),'|'
					,LTRIM(RTRIM(ecird.[2420AI_REF01_ProviderIdentifierQualifer_3]						)),'|')--Break concat
					,CONCAT(LTRIM(RTRIM(ecird.[2420AI_REF02_ProviderIdentifier_3]						)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_NM101_ProviderRole]										)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_NM102_PersonIndicator]									)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_NM103_LastName]											)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_NM104_FirstName]											)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_NM105_MiddleName]										)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_NM107_Suffix]											)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_NM108_ProviderIdentifierQualifer]						)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_NM109_ProviderIdentifier]								)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_REF01_ProviderIdentifierQualifer_1]						)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_REF02_ProviderIdentifier_1]								)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_REF01_ProviderIdentifierQualifer_2]						)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_REF02_ProviderIdentifier_2]								)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_REF01_ProviderIdentifierQualifer_3]						)),'|'
					,LTRIM(RTRIM(ecird.[2420BI_REF02_ProviderIdentifier_3]								)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_NM101_ProviderRole]										)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_NM102_PersonIndicator]									)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_NM103_LastName]											)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_NM104_FirstName]											)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_NM105_MiddleName]										)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_NM107_Suffix]											)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_NM108_ProviderIdentifierQualifer]						)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_NM109_ProviderIdentifier]								)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_REF01_ProviderIdentifierQualifer_1]						)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_REF02_ProviderIdentifier_1]								)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_REF01_ProviderIdentifierQualifer_2]						)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_REF02_ProviderIdentifier_2]								)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_REF01_ProviderIdentifierQualifer_3]						)),'|'
					,LTRIM(RTRIM(ecird.[2420CI_REF02_ProviderIdentifier_3]								)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_NM101_ProviderRole]										)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_NM102_PersonIndicator]									)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_NM103_LastName]											)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_NM104_FirstName]											)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_NM105_MiddleName]										)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_NM107_Suffix]											)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_NM108_ProviderIdentifierQualifer]						)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_NM109_ProviderIdentifier]								)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_REF01_ProviderIdentifierQualifer_1]						)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_REF02_ProviderIdentifier_1]								)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_REF01_ProviderIdentifierQualifer_2]						)),'|'
					,LTRIM(RTRIM(ecird.[2420DI_REF02_ProviderIdentifier_2]								)),'|'
					,LTRIM(RTRIM(ecird.[InNetworkIndicator ]											)),'|'
					,LTRIM(RTRIM(ecird.ServiceLineContractID											)),'|'
					,LTRIM(RTRIM(ecird.TPLPaidAmount													)),'|'
					,LTRIM(RTRIM(ecird.[2400I_NTE02_ServiceNote]										)),'|'
					,LTRIM(RTRIM(ecird.AccommodationCode												)),'|'
					,LTRIM(RTRIM(ecird.[40I_Filler_11]													)),'|'
					,LTRIM(RTRIM(ecird.[40I_Filler_12]													)),'|'
					,LTRIM(RTRIM(ecird.[40I_Filler_13]													)),'|'
					,LTRIM(RTRIM(ecird.[40I_Filler_14]													)),'|'
					,LTRIM(RTRIM(ecird.[40I_Filler_15]													)),'|'
					,LTRIM(RTRIM(ecird.ServiceHealthPlan												)),'|'
					,LTRIM(RTRIM(ecird.ServiceBenefitPlan												)),'|'
					,LTRIM(RTRIM(ecird.ServiceAdministrativeCounty										)),'|'
					,LTRIM(RTRIM(ecird.ServiceResidenceCounty											)),'|'
					,LTRIM(RTRIM(ecird.ServiceEligibilityCode											)),'|'
					,LTRIM(RTRIM(ecird.ServiceSubProgram1												)),'|'
					,LTRIM(RTRIM(ecird.ServiceSubProgram2												)),'|'
					,LTRIM(RTRIM(ecird.ServiceSubProgram3												)),'|'
					,LTRIM(RTRIM(ecird.ServiceSubProgram4												)),'|'
					,LTRIM(RTRIM(ecird.ServiceArrangementCode											)),'|'
					,LTRIM(RTRIM(ecird.ServiceTribalCode												)),'|'
					,LTRIM(RTRIM(ecird.FamilyPlanningService											)),'|'
					,LTRIM(RTRIM(ecird.[40I_MediaType]													)),'|'
					,LTRIM(RTRIM(ecird.BeneficiaryCostSharingStatus										)),'|'
					,LTRIM(RTRIM(ecird.OutOfPocketMaximum												)),'|'
					,LTRIM(RTRIM(ecird.BeneficiaryLockInStatus											))))
		FROM MEDICAID.dbo.EE_CSV_40I_Rec_Detail ecird;

		--431		
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID, Claim_Line_Number, Records)
		SELECT
			Record_Type = '431'
		   ,Record_Order = 6
		   ,ecird.ClaimID
		   ,ClaimLineNumber = CAST(ecird.ClaimLineNumber AS INT)
		   ,Records = CONCAT(CONCAT('431','|'								
							,LTRIM(RTRIM(ecird.ClaimID										)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD01_COBPrimaryPayerID]				)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD02_COBServicePaidAmount]			)),'|'
							,LTRIM(RTRIM(ecird.[431_ClaimLineDisposition]					)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD03_01_ServiceCodeType]				)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD03_02_ServiceCode]					)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD03_03_ServiceModifier1]				)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD03_04_ServiceModifier2]				)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD03_05_ServiceModifier3]				)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD03_06_ServiceModifier4]				)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD03_07_ServiceCodeDescription]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD04_RevenueCode]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD05_Quantity]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_SVD06_BundledLineNumber]				)),'|'
							,LTRIM(RTRIM(ecird.[2430_LineLevelDenial_1]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_LineLevelDenial_2]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_LineLevelDenial_3]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_LineLevelDenial_4]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_LineLevelDenial_5]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_LineLevelDenial_6]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_LineLevelDenial_7]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_LineLevelDenial_8]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_LineLevelDenial_9]						)),'|'
							,LTRIM(RTRIM(ecird.[2430_LineLevelDenial_10]					)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS01_ClaimAdjustmentGroup_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS02_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS03_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS04_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS05_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS06_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS07_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS08_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS09_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS10_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS11_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS12_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS13_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS14_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS15_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS16_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS17_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS18_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS19_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS01_ClaimAdjustmentGroup_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS02_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS03_ClaimAdjustmentAmount_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS04_ClaimAdjustmentquantity_2]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS05_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS06_ClaimAdjustmentAmount_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS07_ClaimAdjustmentquantity_2]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS08_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS09_ClaimAdjustmentAmount_2]			)),'|') --break concat
							,CONCAT(LTRIM(RTRIM(ecird.[2430_CAS10_ClaimAdjustmentquantity_2])),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS11_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS12_ClaimAdjustmentAmount_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS13_ClaimAdjustmentquantity_2]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS14_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS15_ClaimAdjustmentAmount_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS16_ClaimAdjustmentquantity_2]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS17_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS18_ClaimAdjustmentAmount_2]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS19_ClaimAdjustmentquantity_2]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS01_ClaimAdjustmentGroup_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS02_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS03_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS04_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS05_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS06_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS07_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS08_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS09_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS10_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS11_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS12_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS13_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS14_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS15_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS16_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS17_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS18_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS19_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS01_ClaimAdjustmentGroup_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS02_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS03_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS04_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS05_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS06_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS07_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS08_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS09_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS10_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS11_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS12_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS13_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS14_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS15_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS16_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS17_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS18_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS19_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS01_ClaimAdjustmentGroup_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS02_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS03_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS04_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS05_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS06_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS07_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS08_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS09_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS10_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS11_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS12_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS13_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS14_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS15_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS16_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS17_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS18_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecird.[2430_CAS19_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecird.[2430_DTP01_DateTimeQualifier]				)),'|'
							,LTRIM(RTRIM(ecird.[2430_DTP02_DateTimeFormat]					)),'|'
							,LTRIM(RTRIM(ecird.[2430_DTP03_ServicePaidDate]					)),'|'
							,LTRIM(RTRIM(ecird.[2430_AMT01_AmountQualifier]					)),'|'
							,LTRIM(RTRIM(ecird.[2430_AMT02_PatientLiabilityAmount]			)),'|'
							,LTRIM(RTRIM(ecird.[431_Allowed_Amount]							)),'|'
							,LTRIM(RTRIM(ecird.EOB_CODE										)),'|'
							,LTRIM(RTRIM(ecird.AccommodationCode							)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_03]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_04]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_05]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_06]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_07]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_08]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_09]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_10]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_11]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_12]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_13]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_14]								)),'|'
							,LTRIM(RTRIM(ecird.[431_Filler_15]								)),'|'
							,LTRIM(RTRIM(ecird.[431_RecipientAidCategory]					))))
		FROM MEDICAID.dbo.EE_CSV_431I_Rec_Detail ecird;

		IF OBJECT_ID('tempdb.dbo.#sorted_data_rows') IS NOT NULL
			DROP TABLE #sorted_data_rows;		

		CREATE TABLE #sorted_data_rows --final sort order
		(
			ID BIGINT PRIMARY KEY IDENTITY(1,1),
			Records VARCHAR(8000)	
		) WITH (DATA_COMPRESSION = ROW);


		INSERT INTO #sorted_data_rows (Records)
		SELECT Records = CONCAT('00|EMCSV|',LTRIM(RTRIM(@VERSION)),'|',LTRIM(RTRIM(@FILEID)),'|Medical|',FORMAT(GETDATE(),'yyyyMMddhhmmss'),'|',@Sender_ID,'|',@Receiver_ID);

		--Not needed for TennCare Medicaid
		--IF OBJECT_ID('tempdb.dbo.#Claim_Hold') IS NOT NULL
  --      	DROP TABLE #Claim_Hold;
			
		----Taken from EXSP_CLAIM_EXCLUSION_MISSING_DETAIL to partially mimic exclusion behavior		
		--SELECT DISTINCT
		--		Claim_ID = oph.CLAIM_ID,
		--		SourceDataKey = oph.SOURCEDATAKEY,
		--		BATCH_RUNDT = GETDATE(),
		--		EXCL_ID = 9054,
		--		CLAIM_TYPE = oph.CLAIM_TYPE
		--INTO #Claim_Hold
		--FROM MEDICAID.dbo.OUTB_INST_HEADER oph
		--	left join MEDICAID.dbo.OUTB_INST_DETAIL opd on opd.claim_id = oph.claim_id
		--	left join MEDICAID.dbo.claimdim cd on cd.claimid = oph.claim_id
		--where 1 = 1
		--	AND opd.claim_id is NULL
		--	AND NOT EXISTS (  SELECT --filter claims already seen
		--						1
		--					  FROM MEDICAID.dbo.EXT_CLAIM_EXCLUSION_HIST eceh
		--					  WHERE 1 = 1
		--							AND oph.Claim_ID = eceh.Claim_ID
		--							AND eceh.EXCL_ID = 9054);

			INSERT INTO #sorted_data_rows (Records)
			SELECT
				dr.Records
			FROM #data_rows dr
			--Not needed for TennCare WHERE NOT EXISTS (SELECT * FROM #Claim_Hold ch WHERE ch.Claim_ID = dr.Claim_ID)
			ORDER BY 
				dr.Claim_ID,			
				dr.Claim_Line_Number,
				dr.Record_Order;

		--trailer record
		/****************************************
		Field #	Column Name	Field		Values
			1	00 Trailer Record		  01
			2	TRT Record				  TRT			
			3	Total_Professional		
			4	Total_Institutional		
			5	Total_Dental			
			6	Total_Claim_Count
		*****************************************/
		INSERT INTO #sorted_data_rows (Records)
		SELECT Records = CONCAT('01|TRT|0|',@header_record_counts,'|0|',@header_record_counts);
		--For our files we only send one type in each file so if that changes, the above needs to change too
			   		 	  
						  
		TRUNCATE TABLE MEDICAID.dbo.OUTB_INST_CLAIM_MAP;

		SET XACT_ABORT ON;
		--begin dangerous stuff.....
		BEGIN TRY
			
			BEGIN TRANSACTION;
			--datapoints from legacy MEDICAID process
			SET @HEADER_CNTRL = (select  distinct dbo.countrecorddelimter(dr.Records,'|') from #data_rows dr Where Record_Type = '00');  
			SET @FOOTER_CNTRL = (select  distinct dbo.countrecorddelimter(dr.Records,'|') from #data_rows dr Where Record_Type = '01');  
			SET @RECHEADER_CNTRL = (select  distinct dbo.countrecorddelimter(dr.Records,'|') from #data_rows dr Where Record_Type = '100');  
			SET @RECDTL_CNTRL = (select  distinct dbo.countrecorddelimter(dr.Records,'|') from #data_rows dr Where Record_Type = '431');  


			INSERT INTO MEDICAID.dbo.OUTB_FILE_HIST (FILEID, FILEDATE, FILENAME, FILEHEADER, FILEFOOTER, ENTRYDT,
													FILEHEADER_AUD_CNTRL, FILEFOOTER_AUD_CNTRL, RECTYPEHEADER_AUD_CNTRL, RECTYPEDETAIL_AUD_CNTRL,
													RECTYPEOTHER_AUD_CNTRL, FILE_TYPE, FILE_VERSION, REJ_FILE_ID, REJ_FILE_DT, REJ_REA_CD,
													REJ_REA_MSG, REJ_TRAILER, REJ_VAL_RPTD, REJ_VAL_CALC, ACK_FILE_ID, ACK_FILE_DT, ACK_TOTALREC_REC_AMT,
													ACK_HDR_REC_AMT, ACK_LINE_REC_AMT, ACK_SUPL_REC_AMT, STAT_FILE_ID, STAT_FILE_DT, STAT_REC_AMT,
													STAT_ACCPT_AMT, STAT_REJ_AMT, LAST_UPD_DT, TOTAL_CLM, SOURCEDATAKEY, STAT_FATAL_ERR_AMT,
													STAT_DUP_CLM_AMT, STAT_INV_DOS_AMT, FILEDESC)
			SELECT	@FILEID,GETDATE(),NULL
					,RTRIM((SELECT TOP 1 dr.Records FROM #data_rows dr WHERE dr.Record_Type = '00'))		
					,RTRIM((SELECT TOP 1 dr.Records FROM #data_rows dr WHERE dr.Record_Type = '01'))
					,GETDATE(),@HEADER_CNTRL  
					,@FOOTER_CNTRL,@RECHEADER_CNTRL,@RECDTL_CNTRL,NULL,@FILE_TYPE,@VERSION  
					,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL  
					,NULL,NULL,NULL,NULL,@TOTAL_CLAIM,@SOURCEDATAKEY,NULL,NULL,NULL,CONCAT(@FILEDESC,'-JobId-',@JOBID);	
			--end legacy MEDICAID datapoints


			INSERT INTO MEDICAID.dbo.OUTB_INST_CLAIM_MAP (DATAROW)
			SELECT
				sdr.Records
			FROM #sorted_data_rows sdr
			ORDER BY sdr.ID;

			----insert claims found for exclusion into exclusion history table, filtered for existing already
			--INSERT INTO MEDICAID.dbo.EXT_CLAIM_EXCLUSION_HIST (Claim_ID, SourceDataKey, BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE)
			--SELECT
			--	ch.Claim_ID
			--	,ch.SourceDataKey
			--	,ch.BATCH_RUNDT
			--	,ch.EXCL_ID
			--	,ch.CLAIM_TYPE
			--FROM #Claim_Hold ch;	

			--legacy MEDICAID tracking table
			INSERT INTO MEDICAID.dbo.OUTB_CLAIM_STATUS  (CLAIM_ID, CLAIM_TYPE, FILEID, CLM_IND, SOURCEDATAKEY, MEMBER_ID, HICN_NUM, BILL_PROV_GRP_ID, BILL_PROV_ID, REF_PROV_ID,
															REF_PCP_PROV_ID, ATTN_PROV_ID, FILEDATE, LAST_UPD_DATE, DOS_MONTH)
			SELECT CLAIM_ID,CLAIM_TYPE,@FILEID,CLM_IND,SOURCEDATAKEY,MEMBER_ID  
					,HICN_NUM,BILL_PROV_GRP_ID,BILL_PROV_ID,REF_PROV_ID,' '  
					,ATTN_PROV_ID,@CREATEDT,GETDATE(),SUBSTRING(STATE_BEGIN_DT,1,6)  
			FROM MEDICAID.dbo.OUTB_INST_HEADER;
			
			-- ATTENTION: Need to research for TennCare EXEC MEDICAID.dbo.pr_ClaimInstitutionalExtractHistoryInsert @FILEID;

			COMMIT TRANSACTION;

		END TRY
		BEGIN CATCH
			DECLARE @error NVARCHAR(MAX) = ERROR_MESSAGE();

			UPDATE MEDICAID.dbo.EXT_SYS_RUNLOG
			SET END_DT = GETDATE()
			   ,RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE())
			   ,TOTAL_RECORDS = @header_record_counts
			   ,ENTRYDT = GETDATE()
			WHERE PROC_NAME = @Procedure_Name
			AND END_DT IS NULL;

			IF (XACT_STATE() = 1) BEGIN  
    			ROLLBACK TRANSACTION;
			END;
    
			SET XACT_ABORT OFF;
			RAISERROR(@error,15,-1);
		END CATCH;

		SET XACT_ABORT OFF;

		--cleanup
		--IF OBJECT_ID('tempdb.dbo.#Claim_Hold') IS NOT NULL
  --      DROP TABLE #Claim_Hold;

		IF OBJECT_ID('tempdb.dbo.#data_rows') IS NOT NULL
        DROP TABLE #data_rows;

		UPDATE MEDICAID.dbo.EXT_SYS_RUNLOG
		SET END_DT = GETDATE()
			,RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE())
			,TOTAL_RECORDS = @header_record_counts
			,ENTRYDT = GETDATE()
		WHERE PROC_NAME = @Procedure_Name
		AND END_DT IS NULL;

SET NOCOUNT OFF;
