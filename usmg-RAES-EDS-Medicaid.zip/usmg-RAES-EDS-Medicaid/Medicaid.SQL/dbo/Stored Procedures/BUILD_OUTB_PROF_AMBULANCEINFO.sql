﻿

CREATE PROCEDURE [dbo].[BUILD_OUTB_PROF_AMBULANCEINFO]

AS
/******************************************************************************************************************
** CREATE DATE: 04/2016
**
** AUTHOR: LOYAL RICKS - Loyal Ricks
**
** DESCRIPTION: tetdm-667 - Procedure will update the outbound Professional Claim Ambulance Information from 
**				the ClaimAmbulanceInfoDim table.
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
2021-26-08		Anthony Ulmer	MES-133 Update to implement transfer to Medicaid database
******************************************************************************************************************/

--DECLARE VARIABLES

			DECLARE
			
			@TOTAL_RECORDS INT;
			
		

-- Run controls
			
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('BUILD_OUTB_PROF_AMBULANCEINFO'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							);


											IF OBJECT_ID('TEMPDB..#prof_amb') <> 0
													DROP TABLE #prof_amb;
	
											CREATE TABLE [dbo].[#prof_amb](

												[CLAIM_ID] [char](20) NULL,
												[SOURCEDATAKEY] [INT],	
												[TRANS_PICKUP_ADDR1] [varchar](55) NULL,
												[TRANS_PICKUP_CITY] [varchar](30) NULL,
												[TRANS_PICKUP_STATE] [varchar](2) NULL,
												[TRANS_PICKUP_ZIP] [varchar](5) NULL,
												[TRANS_PICKUP_ZIP4] [varchar](4) NULL,
												[TRANS_DROPOFF_ADDR1] [varchar](55) NULL,
												[TRANS_DROPOFF_CITY] [varchar](30) NULL,
												[TRANS_DROPOFF_STATE] [varchar](2) NULL,
												[TRANS_DROPOFF_ZIP] [varchar](5) NULL,
												[TRANS_DROPOFF_ZIP4] [varchar](4) NULL
											); 


											insert into #prof_amb
											select ci.claimid,
													ci.sourcedatakey,
													ci.pickupaddress,
													ci.pickupcity,
													ci.pickupstate,
													substring(ci.pickupzip,1,5),
													substring(ci.pickupzip,6,4),
													ci.dropoffaddress,
													ci.dropoffcity,
													ci.dropoffstate,
													substring(ci.dropoffzip,1,5),
													substring(ci.dropoffzip,6,4)
											from MEDICAID.dbo.ClaimAmbulanceInfoDim ci
											inner join outb_prof_header h
											on ci.sourcedatakey = h.sourcedatakey
											and ci.claimid = h.claim_id; 

											update OUTB_PROF_HEADER 
											SET TRANS_PICKUP_ADDR1 = ISNULL(PA.TRANS_PICKUP_ADDR1,' '),
												TRANS_PICKUP_CITY = ISNULL(PA.TRANS_PICKUP_CITY,' '),
												TRANS_PICKUP_STATE = ISNULL(PA.TRANS_PICKUP_STATE,' '),
												TRANS_PICKUP_ZIP = ISNULL(PA.TRANS_PICKUP_ZIP,' '),
												TRANS_PICKUP_ZIP4 = ISNULL(PA.TRANS_PICKUP_ZIP4,' '),
												TRANS_DROPOFF_ADDR1 = ISNULL(PA.TRANS_DROPOFF_ADDR1,' '),
												TRANS_DROPOFF_CITY = ISNULL(PA.TRANS_DROPOFF_CITY,' '),
												TRANS_DROPOFF_STATE = ISNULL(PA.TRANS_DROPOFF_STATE,' '),
												TRANS_DROPOFF_ZIP = ISNULL(PA.TRANS_DROPOFF_ZIP,' '),
												TRANS_DROPOFF_ZIP4 = ISNULL(PA.TRANS_DROPOFF_ZIP4,' ')
											FROM #prof_amb PA 
											INNER JOIN OUTB_PROF_HEADER P
											ON PA.SOURCEDATAKEY = P.SOURCEDATAKEY 
											and PA.CLAIM_ID = P.CLAIM_ID; 



								--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM #MAO_002_Detail_DAILY
							 
										SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #prof_amb);
									
									----HRP_CLAIM_FILE Update Run Controls
				
													UPDATE EXT_SYS_RUNLOG
													SET END_DT = GETDATE()	
														,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
														,TOTAL_RECORDS = @TOTAL_RECORDS
														,ENTRYDT = GETDATE()
													WHERE PROC_NAME = 'BUILD_OUTB_PROF_AMBULANCEINFO'
																	and END_DT is null;
