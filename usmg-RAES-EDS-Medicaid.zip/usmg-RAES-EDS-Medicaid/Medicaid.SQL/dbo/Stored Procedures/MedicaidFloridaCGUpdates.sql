﻿



/*********************************************************************************************************************************
Procedure:		MedicaidFloridaCGUpdates

Author:			Aaron Ridley

Date:			03/31/2023

Purpose:		Populate Florida Companion Guide Specific Updates. This script will overrite the specified records in the associated CSV tables 

Job:            EDIFECS Florida Medicaid (Executed in File sprocs) 

History:		Date	  Author  HPSM    		Action									

    

Test Script:	


*********************************************************************************************************************************/
--/*

CREATE PROCEDURE [dbo].[MedicaidFloridaCGUpdates] 

    @CLAIM_TYPE varchar(2),
    @JobID int

AS
/*********************************************************************************************************************************/


/* Start Process  */ 


INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('dbo.MedicaidFloridaCGUpdates' + '-'  + rtrim(@CLAIM_TYPE)
				,'1'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)



/*---------------------------------------------------------------------------------

	IDENTIFY THE MEMBER PBPCODE UTILIZING MONTHLYMEMBERSHIPDIM  
-----------------------------------------------------------------------------------*/

IF @CLAIM_TYPE = 'I'
BEGIN
		SELECT DISTINCT CLAIM_ID, 
				CASE WHEN [CAPITATEDLINEFLAG] ='Y' OR TOTALPAID = 0 THEN '05' ELSE '09' END AS CONTRACT_TYPE,
				[DATERECEIVEDKEY] AS K3DATE,
				CAST(TOTALPAID AS VARCHAR) AS TOTALPAID,
				CASE WHEN LEFT(UB92.BILLTYPECODE,2) = '21' THEN '1'
					 WHEN LEFT(UB92.BILLTYPECODE,2) = '25' THEN '2'
					 WHEN LEFT(UB92.BILLTYPECODE,2) = '26' THEN '3'
				ELSE 
				 ''
				 END AS TOC,
				 MEM.MEDICAIDID,
				 LEFT(UB92.BILLTYPECODE,2) AS BILLTYPE,
				 CD.VENDORNPI,
				 CD.SOURCEDATAKEY
		INTO #INSTCSV
		FROM MEDICAID.dbo.OUTB_INST_HEADER OIH 
		JOIN MEDICAID.dbo.ClaimDim CD ON OIH.CLAIM_ID = CD.CLAIMID 
		JOIN MEDICAID.dbo.ClaimDetailDim CDD ON OIH.CLAIM_ID = CDD.CLAIMID
		JOIN MEDICAID.dbo.UB921AdmissionDim UB92 ON OIH.CLAIM_ID = UB92.CLAIMID
		JOIN MEDICAID.dbo.MemberDim MEM ON CD.MEMBERID = MEM.MEMBERID AND CD.SOURCEDATAKEY = MEM.SOURCEDATAKEY;

		UPDATE CSV20I
		SET [2300I_CN101_ContractTypeCode]= CSVINST.CONTRACT_TYPE, 
			[2300I_CN102_MonetaryAmount] = CSVINST.TOTALPAID,
			[2300I_NTE02_ClaimNote] = CASE WHEN CSVINST.TOC ='' THEN  'LOCAMT=;0'
											ELSE 'LOCAMT=' + CSVINST.TOC + ';' + CSVINST.TOTALPAID 
											END,
			[2300I_NTE01_BillNoteType] = 'UPI',	
			[Claim Processor Receiver Date] = CSVINST.K3DATE,
			[2300I_CLM05-01_FacilityTypeCode] = CSVINST.BILLTYPE,
			[2300I_HI01-09_PrincipalDXPOA] = CASE WHEN  ISNULL([2300I_HI01-09_PrincipalDXPOA],' ') = ' ' THEN 'N' ELSE [2300I_HI01-09_PrincipalDXPOA] END,
			[2300I_HI01-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI01-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI01-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI01-09_DXPOA_1] END,
			[2300I_HI02-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI02-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI02-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI02-09_DXPOA_1] END,
			[2300I_HI03-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI03-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI03-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI03-09_DXPOA_1] END,
			[2300I_HI04-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI04-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI04-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI04-09_DXPOA_1] END,
			[2300I_HI05-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI05-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI05-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI05-09_DXPOA_1] END,
			[2300I_HI06-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI06-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI06-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI06-09_DXPOA_1] END,
			[2300I_HI07-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI07-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI07-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI07-09_DXPOA_1] END,
			[2300I_HI08-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI08-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI08-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI08-09_DXPOA_1] END,
			[2300I_HI09-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI09-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI09-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI09-09_DXPOA_1] END,
			[2300I_HI10-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI10-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI10-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI10-09_DXPOA_1] END,
			[2300I_HI11-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI11-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI11-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI11-09_DXPOA_1] END,
			[2300I_HI12-09_DXPOA_1] = CASE WHEN ISNULL([2300I_HI12-02_DXCode_1],' ') <> ' ' AND ISNULL([2300I_HI12-09_DXPOA_1],' ') = ' ' THEN 'U' ELSE [2300I_HI12-09_DXPOA_1] END,
			[2300I_HI01-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI01-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI01-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI01-09_DXPOA_2] END,
			[2300I_HI02-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI02-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI02-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI02-09_DXPOA_2] END,
			[2300I_HI03-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI03-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI03-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI03-09_DXPOA_2] END,
			[2300I_HI04-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI04-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI04-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI04-09_DXPOA_2] END,
			[2300I_HI05-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI05-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI05-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI05-09_DXPOA_2] END,
			[2300I_HI06-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI06-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI06-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI06-09_DXPOA_2] END,
			[2300I_HI07-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI07-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI07-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI07-09_DXPOA_2] END,
			[2300I_HI08-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI08-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI08-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI08-09_DXPOA_2] END,
			[2300I_HI09-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI09-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI09-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI09-09_DXPOA_2] END,
			[2300I_HI10-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI10-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI10-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI10-09_DXPOA_2] END,
			[2300I_HI11-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI11-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI11-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI11-09_DXPOA_2] END,
			[2300I_HI12-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI12-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI12-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI12-09_DXPOA_2] END,
			[2300I_HI13-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI13-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI13-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI13-09_DXPOA_2] END,
			[2300I_HI14-09_DXPOA_2] = CASE WHEN ISNULL([2300I_HI14-02_DXCode_2],' ') <> ' ' AND ISNULL([2300I_HI14-09_DXPOA_2],' ') = ' ' THEN 'U' ELSE [2300I_HI14-09_DXPOA_2] END
		FROM MEDICAID.dbo.EE_CSV_20I_Rec_Header CSV20I
		INNER JOIN #INSTCSV CSVINST ON  CSV20I.CLAIMID = CSVINST.CLAIM_ID;

		UPDATE CSV150I
		SET [2010BA_NM102_SubscriberPersonIndicator] = '0F',
			[2010BA_NM109_SubscriberIdentifier] = CSVINST.MEDICAIDID,
		    [2010BA_REF02_SubscriberIdentifier_1] = CSVINST.MEDICAIDID
		FROM MEDICAID.dbo.EE_CSV_150I_Rec_Header CSV150I
		INNER JOIN #INSTCSV CSVINST ON  CSV150I.CLAIMID = CSVINST.CLAIM_ID;

		UPDATE CSV310I
		SET [2330B_DTP03_ClaimPaidDate] = CA.PAIDDATEKEY,
			[2330B_NM109_OrganizationIdentifier] = CSVINST.MEDICAIDID
		FROM MEDICAID.dbo.EE_CSV_310I_Rec_Header CSV310I
		INNER JOIN MEDICAID.DBO.ClaimAgg CA ON CSV310I.ClaimID = CA.CLAIMID
		LEFT JOIN #INSTCSV CSVINST ON  CSV310I.CLAIMID = CSVINST.CLAIM_ID;
END

IF @CLAIM_TYPE = 'P'
BEGIN
		SELECT DISTINCT CLAIM_ID, 
				CASE WHEN [CAPITATEDLINEFLAG] ='Y' OR TOTALPAID = 0 THEN '05' ELSE '09' END AS CONTRACT_TYPE,
				[DATERECEIVEDKEY] AS K3DATE,
				TOTALPAID,
				MEM.MEDICAIDID,
				CD.VENDORNPI,
				CD.SOURCEDATAKEY
		INTO #PROFCSV
		FROM MEDICAID.dbo.OUTB_PROF_HEADER OPH 
		JOIN MEDICAID.dbo.ClaimDim CD ON OPH.CLAIM_ID = CD.CLAIMID 
		JOIN MEDICAID.dbo.ClaimDetailDim CDD ON OPH.CLAIM_ID = CDD.CLAIMID
		JOIN MEDICAID.dbo.MemberDim MEM ON CD.MEMBERID = MEM.MEMBERID AND CD.SOURCEDATAKEY = MEM.SOURCEDATAKEY;
		

		UPDATE CSV20P
		SET [2300P_CN101_ContractTypeCode] = CSVPROF.CONTRACT_TYPE, 
			[2300P_CN102_MonetaryAmount] = CSVPROF.TOTALPAID,
			[Claim Processor Receiver Date] = CSVPROF.K3DATE
		FROM MEDICAID.[dbo].[EE_CSV_20P_Rec_Header] CSV20P
		INNER JOIN #PROFCSV CSVPROF ON  CSV20P.CLAIMID = CSVPROF.CLAIM_ID

		UPDATE CSV150P
		SET [2010BA_NM102_SubscriberPersonIndicator] = '0F',
			[2010BA_NM109_SubscriberIdentifier] = CSVPROF.MEDICAIDID,
			[2010BA_REF02_SubscriberIdentifier_1] = CSVPROF.MEDICAIDID
		FROM MEDICAID.dbo.EE_CSV_150P_Rec_Header CSV150P
		INNER JOIN #PROFCSV CSVPROF ON  CSV150P.CLAIMID = CSVPROF.CLAIM_ID;

		UPDATE CSV310P
		SET [2330B_DTP03_ClaimPaidDate] = CA.PAIDDATEKEY,
			[2330B_NM109_OrganizationIdentifier] = CSVPROF.MEDICAIDID
		FROM MEDICAID.[dbo].[EE_CSV_310P_Rec_Header] CSV310P
		INNER JOIN MEDICAID.DBO.ClaimAgg CA ON CSV310P.ClaimID = CA.CLAIMID
		LEFT JOIN #PROFCSV CSVPROF ON  CSV310P.CLAIMID = CSVPROF.CLAIM_ID;
END


/* --------------------------------------------------------------------------------------------------------
--            Provider Data Backfilll (CSV 20 and 100 updates) 
--
-----------------------------------------------------------------------------------------------------------*/

		IF OBJECT_ID('tempdb.dbo.#Temp1') IS NOT NULL
			DROP TABLE #Temp1

		CREATE TABLE #Temp1 (
			[SourceDataKey] [INT],
			[ClaimNo] [VARCHAR](50),
			[ClaimType] [VARCHAR](50),
			[BillProvEntity] [VARCHAR](10),
			[BillProvLast] [VARCHAR](60),
			[BillProvFirst] [VARCHAR](35),
			[BillProvNPI] [VARCHAR](80),
			[BillProvAddress] [VARCHAR](55),
			[BillProvAddress2] [VARCHAR](55),
			[BillProvCity] [VARCHAR](30),
			[BillProvState] [VARCHAR](2),
			[BillProvZip] [VARCHAR](15),
			[BillProvTaxID] [VARCHAR](50),
			[BillProvTel] [VARCHAR](256),
			[BillProvTaxonomy] [VARCHAR](50),
			[RendProvEntity] [VARCHAR](50),
			[RendProvLast] [VARCHAR](60),
			[RendProvFirst] [VARCHAR](35),
			[RendProvNPI] [VARCHAR](80),
			[RendProvTaxonomy] [VARCHAR](50),
			[RefProvEntity] [VARCHAR](10),
			[RefProvLast] [VARCHAR](60),
			[RefProvFirst] [VARCHAR](35),
			[RefProvID]    [VARCHAR](80), ---- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
			[RefProvIDType] [VARCHAR](50), ---- \* 8/1/2016 -- Added new column from Staging.dbo.SDE_ILICP_OB_Claims *\ 
			[RefProvNPI] [VARCHAR](80),
			[RefProvTaxonomy] [VARCHAR](50), ---- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
			--[RendProvTaxonomy] [varchar](50),
			[PCProvEntity] [VARCHAR](10),
			[PCProvLast] [VARCHAR](60),
			[PCProvFirst] [VARCHAR](35),
			[PCProvNPI] [VARCHAR](80),
			[PCPUPIN] [VARCHAR](50),
			[AttendProvEntity] [VARCHAR](10) NULL,
			[AttendProvLast] [VARCHAR](60) NULL,
			[AttendProvFirst] [VARCHAR](35) NULL,
			[AttendProvNPI] [VARCHAR](80) NULL,
			[AttendProvTaxonomy] [VARCHAR](50) NULL,
			[SupervisingProvLast] [VARCHAR](60) NULL,
			[SupervisingProvFirst] [VARCHAR](35) NULL,
			[SupervisingProvNPI] [VARCHAR](80) NULL,
			[OperatingProvLast] [VARCHAR](60) NULL,
			[OperatingProvFirst] [VARCHAR](35) NULL,
			[OperatingProvNPI] [VARCHAR](80) NULL	
		)

	/* Build Temporary table for Institutional Transactions */ 

		IF @CLAIM_TYPE = 'I'
		BEGIN 
		INSERT INTO #Temp1
				SELECT DISTINCT
				SourceDataKey = Claims.SourceDataKey,
				--ID = claims.GentranID,
				ClaimNo = Claims.CLAIM_ID, --= Agg.ClaimID, -- removed "0000" statement 9/8/2014 '0000' + Agg.ClaimID, -- P, I
				--CLM01 = Agg.ClaimID,						
			    ClaimType ='I', 
				--TransactionType = 'CH' ,								
				--AppCode = 'ODSE',
				BillProvEntity = NULL,
				BillProvLast =
				CASE
								--WHEN ipd.LastName IS NOT NULL THEN LTRIM(RTRIM(ipd.LastName))
								WHEN vendprov.LastName IS NOT NULL THEN LTRIM(RTRIM(vendprov.LastName)) --updated 1/22/2015 per tenncare request
								WHEN vendprov.LastName IS NULL THEN LTRIM(RTRIM(ISNULL(NULLIF(vendprov.FirstName, 'UNKNOWN'), '') + ' ' + ISNULL(NULLIF(vendprov.LastName, 'UNKNOWN'), '')))
								ELSE NULLIF(vendprov.LastName, 'UNKNOWN')
							END,
				BillProvFirst =  
				CASE								
								--WHEN  Claims.ClaimType = 'I'  THEN NULL
								WHEN vendprov.FirstName != 'UNKNOWN' THEN vendprov.[FirstName]
								WHEN vendprov.FirstName = 'UNKNOWN' THEN NULL
								ELSE NULL
				END,
				BillProvNPI =
				CASE
								WHEN NULLIF(Claims.[VendorNPI], 'UNKNOWN') IS NOT NULL THEN claims.[VendorNPI] --added 2/19/15 per tenncare request
								ELSE vendprov.NationalProviderID
								END,
				BillProvAddress =  REPLACE(dbo.fnStripCharacters(NULLIF(vendprov.AddressLine1, 'UNKNOWN'), '^-,^/,^0-9,^a-Z,^ '), '½', '1/2'),
				BillProvAddress2 = REPLACE(dbo.fnStripCharacters(NULLIF(vendprov.AddressLine2, 'UNKNOWN'), '^-,^/,^0-9,^a-Z,^ '), '½', '1/2') , -- P, I
				BillProvCity = NULLIF(vendprov.City, 'UNKNOWN'),
				BillProvState = NULLIF(vendprov.State, '--'),
				BillProvZip = LEFT(ISNULL(NULLIF(REPLACE(vendprov.Zip, '-', ''), 'UNKNOWN'), '00000') + '9999', 9),
				BillProvTaxID =  NULLIF(vendprov.FederalID, 'UNKNOWN'), --NULLIF(vd.FederalID, 'UNKNOWN') , -- P, I
				BillProvTel =  ISNULL(dbo.fnStripCharacters(NULLIF(vendprov.Phone, 'UNKNOWN'), '^0-9'), ''), --ISNULL(dbo.fnStripCharacters(NULLIF(vd.Phone, 'UNKNOWN'), '^0-9'), ''), -- P, I
				BillProvTaxonomy =  ISNULL(CMSTaxonomy.[HealthcareProviderTaxonomyCode],CMSTaxonomyProv.[HealthcareProviderTaxonomyCode]) ,   ----NULL, TAKE a look
				RendProvEntity = NULL,
				RendProvLast = 
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								WHEN prov.LastName IS NOT NULL THEN LTRIM(RTRIM(prov.LastName))
								ELSE NULLIF(prov.LastName, 'UNKNOWN')
							END,
				RendProvFirst =
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								WHEN prov.FirstName IS NOT NULL THEN LTRIM(RTRIM(prov.FirstName))
								ELSE NULLIF(prov.FirstName, 'UNKNOWN')
							END,
				RendProvNPI = 
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								ELSE ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '')
							END, -- CASE WHEN NULLIF(vd.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID,'UNKNOWN'),'') 
				--	THEN '' ELSE ISNULL(NULLIF(prov.NPID,'UNKNOWN'),'') END, -- P, I
				RendProvTaxonomy = NULL,
				RefProvEntity = NULL,
				RefProvLast = CLMProvRef.[ProvLastName],
				RefProvFirst = CLMProvRef.[ProvFirstName],
				RefProvID    = NULL,  ---- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
				RefProvIDType = NULL, ---- \* 8/1/2016 -- Added new column from Staging.dbo.SDE_ILICP_OB_Claims *\ 
				RefProvNPI = CLMProvRef.[NPI],
				RefProvTaxonomy =NULL,  ----- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
				PCProvEntity = NULL,
				PCProvLast = NULL,
				PCProvFirst = NULL,
				PCProvNPI = NULL,
				--			CASE
				--				WHEN claims.ClaimType  != 'I' THEN prov.NPID
				--			END, -- P
				PCPUPIN = NULL,
				--			CASE
				--				WHEN claims.ClaimType != 'I' THEN NULLIF(prov.UPIN, 'UNKNOWN')
				--			END, -- P
				[AttendProvEntity] = NULL,
				[AttendProvLast] = CLMProvAttend.[ProvLastName],
				[AttendProvFirst] = CLMProvAttend.[ProvFirstName],
				[AttendProvNPI] = CLMProvAttend.[NPI],
				[AttendProvTaxonomy] = NULL,
				[SupervisingProvLast] = CLMProvSup.[ProvLastName],
				[SupervisingProvFirst] = CLMProvSup.[ProvFirstName],
				[SupervisingProvNPI] = CLMProvSup.[NPI],
				[OperatingProvLast] = CLMProvOp.[ProvLastName],
				[OperatingProvFirst] = CLMProvOp.[ProvFirstName],
				[OperatingProvNPI] = CLMProvOp.[NPI]
			FROM #INSTCSV claims
			INNER JOIN  dbo.ClaimAgg ClaimAgg on claims.claim_id = ClaimAgg.ClaimID
			LEFT JOIN dbo.ProviderDim prov ON prov.ProviderID = ClaimAgg.PROVIDERID AND prov.SourceDataKey = ClaimAgg.SourceDataKey
			LEFT JOIN dbo.VendorDim  vendprov ON claims.VENDORNPI = vendprov.NationalProviderID AND claims.SOURCEDATAKEY = vendprov.SourceDataKey 
			LEFT JOIN dbo.QNXT_Claim qnxtclaim ON claims.CLAIM_ID = qnxtclaim.claimid
			LEFT JOIN qnxt.ClaimProv CLMProvAttend on claims.CLAIM_ID = CLMProvAttend.CLAIMID  AND  CLMProvAttend.[PhysTypeQualifier] = 'ATTENDING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvRef on claims.CLAIM_ID = CLMProvRef.CLAIMID  AND CLMProvRef.[PhysTypeQualifier] = 'REFERRING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvSup on claims.CLAIM_ID = CLMProvSup.CLAIMID  AND CLMProvSup.[PhysTypeQualifier] = 'SUPERVISING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvOp on claims.CLAIM_ID = CLMProvOp.CLAIMID  AND CLMProvOp.[PhysTypeQualifier] = 'OPERATING'-- Need to 
			LEFT JOIN EDPS_Data.IDQ.CMSTaxonomy CMSTaxonomy ON vendprov.NationalProviderID = CMSTaxonomy.NPI and CMSTaxonomy.HealthcareProviderPrimaryTaxonomySwitch ='Y' 
			LEFT JOIN EDPS_Data.IDQ.CMSTaxonomy CMSTaxonomyProv ON prov.NPID = CMSTaxonomyProv.NPI and CMSTaxonomyProv.HealthcareProviderPrimaryTaxonomySwitch ='Y'
			END; 

			/* Build Temporary table for Professional Claims */

			IF @CLAIM_TYPE = 'P'
		BEGIN 
		INSERT INTO #Temp1
				SELECT DISTINCT
				SourceDataKey = claims.SourceDataKey,
				--ID = claims.GentranID,
				ClaimNo = claims.CLAIM_ID, --= Agg.ClaimID, -- removed "0000" statement 9/8/2014 '0000' + Agg.ClaimID, -- P, I
				--CLM01 = Agg.ClaimID,						
				ClaimType = 'P', 
				--TransactionType = 'CH' ,								
				--AppCode = 'ODSE',
				BillProvEntity = NULL,
				BillProvLast =
				CASE
								--WHEN ipd.LastName IS NOT NULL THEN LTRIM(RTRIM(ipd.LastName))
								WHEN vendprov.LastName IS NOT NULL THEN LTRIM(RTRIM(vendprov.LastName)) --updated 1/22/2015 per tenncare request
								--WHEN Claims.ClaimType = 'I'  THEN LTRIM(RTRIM(ISNULL(NULLIF(vendprov.FirstName, 'UNKNOWN'), '') + ' ' + ISNULL(NULLIF(vendprov.LastName, 'UNKNOWN'), '')))
								ELSE NULL
							END,
				BillProvFirst = 
				CASE								
								--WHEN  Claims.ClaimType = 'I'  THEN NULL
								WHEN vendprov.FirstName != 'UNKNOWN' THEN vendprov.[FirstName]
								ELSE NULLIF(NULLIF(vendprov.FirstName, 'UNKNOWN'),'')
								END,
				BillProvNPI =
				CASE
								WHEN NULLIF(Claims.[VendorNPI], 'UNKNOWN') IS NOT NULL THEN Claims.[VendorNPI] --added 2/19/15 per tenncare request
								ELSE vendprov.NationalProviderID
								END,
				BillProvAddress =  REPLACE(dbo.fnStripCharacters(NULLIF(vendprov.AddressLine1, 'UNKNOWN'), '^-,^/,^0-9,^a-Z,^ '), '½', '1/2'),
				BillProvAddress2 = REPLACE(dbo.fnStripCharacters(NULLIF(vendprov.AddressLine2, 'UNKNOWN'), '^-,^/,^0-9,^a-Z,^ '), '½', '1/2') , -- P, I
				BillProvCity = NULLIF(vendprov.City, 'UNKNOWN'),
				BillProvState = NULLIF(vendprov.State, '--'),
				BillProvZip = LEFT(ISNULL(NULLIF(REPLACE(vendprov.Zip, '-', ''), 'UNKNOWN'), '00000') + '9999', 9),
				BillProvTaxID =  NULLIF(vendprov.FederalID, 'UNKNOWN'), --NULLIF(vd.FederalID, 'UNKNOWN') , -- P, I
				BillProvTel =  ISNULL(dbo.fnStripCharacters(NULLIF(vendprov.Phone, 'UNKNOWN'), '^0-9'), ''), --ISNULL(dbo.fnStripCharacters(NULLIF(vd.Phone, 'UNKNOWN'), '^0-9'), ''), -- P, I
				BillProvTaxonomy =  ISNULL(CMSTaxonomy.[HealthcareProviderTaxonomyCode],CMSTaxonomyProv.[HealthcareProviderTaxonomyCode]) ,   ----NULL, TAKE a look
				RendProvEntity = NULL,
				RendProvLast = 
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								WHEN prov.LastName IS NOT NULL THEN LTRIM(RTRIM(prov.LastName))
								ELSE NULLIF(prov.LastName, 'UNKNOWN')
							END,
				RendProvFirst =
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								WHEN prov.FirstName IS NOT NULL THEN LTRIM(RTRIM(prov.FirstName))
								ELSE NULLIF(prov.FirstName, 'UNKNOWN')
							END,
				RendProvNPI = 
				CASE
								WHEN NULLIF(vendprov.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '') THEN ''
								ELSE ISNULL(NULLIF(prov.NPID, 'UNKNOWN'), '')
							END, -- CASE WHEN NULLIF(vd.NationalProviderID, 'N/A') = ISNULL(NULLIF(prov.NPID,'UNKNOWN'),'') 
				--	THEN '' ELSE ISNULL(NULLIF(prov.NPID,'UNKNOWN'),'') END, -- P, I
				RendProvTaxonomy = NULL,
				RefProvEntity = NULL,
				RefProvLast = CLMProvRef.[ProvLastName],
				RefProvFirst = CLMProvRef.[ProvFirstName],
				RefProvID    = NULL,  ---- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
				RefProvIDType = NULL, ---- \* 8/1/2016 -- Added new column from Staging.dbo.SDE_ILICP_OB_Claims *\ 
				RefProvNPI = CLMProvRef.[NPI],
				RefProvTaxonomy =NULL,  ----- \* 7/6/2016 -- Added new column from DataExchange.dbo.HistoricalClaim table *\ 
				PCProvEntity = NULL,
				PCProvLast = NULL,
				PCProvFirst = NULL,
				PCProvNPI = prov.NPID,
							--CASE
							--	WHEN claims.ClaimType  != 'I' THEN prov.NPID
							--END, -- P
				PCPUPIN = NULLIF(prov.UPIN, 'UNKNOWN'),
							--CASE
							--	WHEN claims.ClaimType != 'I' THEN NULLIF(prov.UPIN, 'UNKNOWN')
							--END, -- P
				[AttendProvEntity] = NULL,
				[AttendProvLast] = CLMProvAttend.[ProvLastName],
				[AttendProvFirst] = CLMProvAttend.[ProvFirstName],
				[AttendProvNPI] = CLMProvAttend.[NPI],
				[AttendProvTaxonomy] = NULL,
				[SupervisingProvLast] = CLMProvSup.[ProvLastName],
				[SupervisingProvFirst] = CLMProvSup.[ProvFirstName],
				[SupervisingProvNPI] = CLMProvSup.[NPI],
				[OperatingProvLast] = CLMProvOp.[ProvLastName],
				[OperatingProvFirst] = CLMProvOp.[ProvFirstName],
				[OperatingProvNPI] = CLMProvOp.[NPI]
			FROM #PROFCSV claims 
			INNER JOIN  dbo.ClaimAgg ClaimAgg on claims.claim_id = ClaimAgg.ClaimID
			LEFT JOIN dbo.ProviderDim prov ON prov.ProviderID = ClaimAgg.PROVIDERID AND prov.SourceDataKey = ClaimAgg.SourceDataKey
			LEFT JOIN dbo.VendorDim  vendprov ON claims.VENDORNPI = vendprov.NationalProviderID AND claims.SOURCEDATAKEY = vendprov.SourceDataKey 
			LEFT JOIN dbo.QNXT_Claim qnxtclaim ON claims.CLAIM_ID = qnxtclaim.claimid
			LEFT JOIN qnxt.ClaimProv CLMProvAttend on claims.CLAIM_ID = CLMProvAttend.CLAIMID  AND  CLMProvAttend.[PhysTypeQualifier] = 'ATTENDING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvRef on claims.CLAIM_ID = CLMProvRef.CLAIMID  AND CLMProvRef.[PhysTypeQualifier] = 'REFERRING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvSup on claims.CLAIM_ID = CLMProvSup.CLAIMID  AND CLMProvSup.[PhysTypeQualifier] = 'SUPERVISING'-- Need to 
			LEFT JOIN qnxt.ClaimProv CLMProvOp on claims.CLAIM_ID = CLMProvOp.CLAIMID  AND CLMProvOp.[PhysTypeQualifier] = 'OPERATING'-- Need to 
			LEFT JOIN EDPS_Data.IDQ.CMSTaxonomy CMSTaxonomy ON vendprov.NationalProviderID = CMSTaxonomy.NPI and CMSTaxonomy.HealthcareProviderPrimaryTaxonomySwitch ='Y' 
			LEFT JOIN EDPS_Data.IDQ.CMSTaxonomy CMSTaxonomyProv ON prov.NPID = CMSTaxonomyProv.NPI and CMSTaxonomyProv.HealthcareProviderPrimaryTaxonomySwitch ='Y' 
			END; 

												 
		
		--Attending and Rendering Provder Data Updates 
		UPDATE t
			SET t.[AttendProvTaxonomy] = c.[HealthcareProviderTaxonomyCode]
			FROM #Temp1 t
				LEFT JOIN EDPS_Data.[IDQ].[CMSTaxonomy] c ON t.[AttendProvNPI] = c.[NPI] AND [c].[HealthcareProviderPrimaryTaxonomySwitch] = 'Y'
			WHERE t.ClaimType = 'I' AND t.[AttendProvNPI] <> '';

		UPDATE t
			SET t.[RendProvTaxonomy] = c.[HealthcareProviderTaxonomyCode]
			FROM #Temp1 [t]
				LEFT JOIN EDPS_Data.[IDQ].[CMSTaxonomy] AS [c] ON t.[RendProvNPI] = c.[NPI] AND [c].[HealthcareProviderPrimaryTaxonomySwitch] = 'Y'
		WHERE t.ClaimType = 'P' AND [t].[RendProvNPI] <> '';

		
	
		--Address Data backfill
		UPDATE t  
																		--updated to only impact ProviderAddress Data and not the other fields
		SET	
			t.[BillProvAddress] =  COALESCE(NULLIF([pad50].[AddressLine1],'UNKNOWN'), t.[BillProvAddress]),--, pda.[AddressLine1]),
			t.[BillProvAddress2] =  COALESCE(NULLIF([pad50].[AddressLine2],'UNKNOWN'), t.[BillProvAddress2]),--,pda.[AddressLine2]),
			t.[BillProvCity] = COALESCE([pad50].[City], t.[BillProvCity]),
			t.[BillProvState] = COALESCE([pad50].[State], t.[BillProvState]),
			t.[BillProvZip] = COALESCE( [pad50].[ZipCode9], t.[BillProvZip])
		FROM #Temp1 AS [t] 
			LEFT JOIN Medicaid.[dbo].[ProviderDim] AS [pd] ON [pd].NPID = t.BillProvNPI AND [pd].SourceDataKey = t.SourceDataKey
					--AND [pd].Deleted = 0
					--AND [pd].Active = 1
			LEFT JOIN Medicaid.dbo.ProviderAddressDim AS pda ON pd.ProviderID = pda.ProviderID 
				AND [pd].SourceDataKey = pda.SourceDataKey
				AND pda.[Active] = 1  --added 2/24/2015 per project manager request
				AND pda.deleted = 0  --added 2/24/2015 per project manager request
				AND [pda].[AddressTypeCode] = 'PB' --added 2/24/2015 per project manager request
			LEFT JOIN (--added 2/24/2015 per project manager request	
					SELECT distinct [pad].[ProviderID],[pad].[AddressLine1],[pad].[AddressLine2] , [pad].City, [pad].ZipCode9, [pad].State
					FROM Medicaid..[ProviderAddressDim] AS [pad] 
					WHERE ([pad].[AddressLine1] NOT LIKE '%P%O%BOX%' AND [pad].[AddressLine1] NOT LIKE '%PO%BOX%')   
						AND ([pad].[AddressLine2] NOT LIKE '%P%O%BOX%' AND [pad].[AddressLine2] NOT LIKE '%PO%BOX%' ) 
						AND active = 1 
						AND deleted = 0 
						AND addresstypecode = 'PB' 
						AND sourcedatakey = '50') pad50 
				on pd.ProviderID = pad50.[ProviderID]
			LEFT JOIN EDPS_Data.IDQ.CMSTaxonomy cms ON pd.NPID = cms.NPI
	



		/**************************************************************************************************************************
		Blank Rendering Provider Information for Institutional Claims. As this field is not required in the 837I transaction 
		************************************************************************************************************************/
		UPDATE c
		SET	RendProvEntity = '',
			RendProvLast = '',
			RendProvFirst = '',
			RendProvNPI = ''
		FROM #Temp1 c
		WHERE ClaimType = 'I'
		
	
		/**************************************************************************************************************************/


 -- 100I Record  - [Medicaid].[dbo].[EE_CSV_100I_Rec_Header]

IF @CLAIM_TYPE = 'I'
 BEGIN 
	UPDATE CSV100I
		SET
			 [2010AA_NM103_BillingOrg_LastName]  					= [BillProvLast]	
			,[2010AA_NM104_BillingFirstName]						= [BillProvFirst]	
			,[2010AA_NM109_BillingProviderIdentifier]				= [BillProvNPI]		
			,[2010AA_N301_BillingAddressLine1]						= [BillProvAddress]	
			,[2010AA_N302_BillingAddressLine2]						= [BillProvAddress2]
			,[2010AA_N401_BillingCity]								= [BillProvCity]	
			,[2010AA_N402_BillingState]								= [BillProvState]	
			,[2010AA_N403_BillingPostalCode]						= [BillProvZip]		
			,[2010AA_REF02_BillingProviderIdentifier_1]				= [BillProvTaxID]	
			,[2010AA_PER04_BillingProviderCommunicationNumber_1]	= [BillProvTel]		
			,[2000A_PRV03_BillingProviderTaxonomy]					= [BillProvTaxonomy]
	 FROM  [Medicaid].[dbo].[EE_CSV_100I_Rec_Header] CSV100I
		 INNER JOIN #Temp1 CLAIMSPROV ON CSV100I.ClaimID = CLAIMSPROV.ClaimNo



		 -- 20I record -	 [Medicaid].[dbo].[EE_CSV_20I_Rec_Header]	
	UPDATE CSV20I
		SET
				 [2310AI_NM103_LastName]							= [AttendProvLast]
				,[2310AI_NM104_FirstName]							= [AttendProvFirst]
				,[2310AI_NM109_ProviderIdentifier]					= [AttendProvNPI]
				,[2310AI_PRV03_ProviderTaxonomy]					= [AttendProvTaxonomy]

				,[2310BI_NM103_LastName]							= [OperatingProvLast]
				,[2310BI_NM104_FirstName]							= [OperatingProvFirst]
				,[2310BI_NM109_ProviderIdentifier]					= [OperatingProvNPI]
	
				,[2310DI_NM103_LastName]							= [RendProvLast]
				,[2310DI_NM104_FirstName]							= [RendProvFirst]
				,[2310DI_NM109_ProviderIdentifier]					= [RendProvNPI]
																	
					
				,[2310FI_NM103_LastName]							= [RefProvLast]
				,[2310FI_NM104_FirstName]							= [RefProvFirst]
				,[2310FI_NM109_ProviderIdentifier]					= [RefProvNPI]
		 FROM  [Medicaid].[dbo].[EE_CSV_20I_Rec_Header] CSV20I
		 INNER JOIN #Temp1 CLAIMSPROV ON CSV20I.ClaimID = CLAIMSPROV.ClaimNo
	END;


	-----------------------------------------------------------------------------------------------------------------------------------------------------
		---- Professional Claim updates 
	-----------------------------------------------------------------------------------------------------------------------------------------------------

	IF @CLAIM_TYPE = 'P'
 BEGIN 
	UPDATE CSV100P
	SET 
-- 100P Record  [Medicaid].[dbo].[EE_CSV_100P_Rec_Header]

		[2010AA_NM102_BillingPersonIndicator]					= [BillProvEntity]
		,[2010AA_NM103_BillingOrg_LastName]  					= [BillProvLast]	
		,[2010AA_NM104_BillingFirstName]						= [BillProvFirst]	
		,[2010AA_NM109_BillingProviderIdentifier]				= [BillProvNPI]		
		,[2010AA_N301_BillingAddressLine1]						= [BillProvAddress]	
		,[2010AA_N302_BillingAddressLine2]						= [BillProvAddress2]
		,[2010AA_N401_BillingCity]								= [BillProvCity]	
		,[2010AA_N402_BillingState]								= [BillProvState]	
		,[2010AA_N403_BillingPostalCode]						= [BillProvZip]		
		,[2010AA_REF02_BillingProviderIdentifier_1]				= [BillProvTaxID]	
		,[2010AA_PER04_BillingProviderCommunicationNumber_1]	= [BillProvTel]		
		,[2000A_PRV03_BillingProviderTaxonomy]					= [BillProvTaxonomy]
	FROM  [Medicaid].[dbo].[EE_CSV_100P_Rec_Header] CSV100P
	 INNER JOIN #Temp1 CLAIMSPROV ON CSV100P.ClaimID = CLAIMSPROV.ClaimNo


	 UPDATE CSV20P
	 SET
-- 20P record -	 [Medicaid].[dbo].[EE_CSV_20I_Rec_Header]	
		
		 [2310AP_NM103_LastName]							= [RefProvLast]
		,[2310AP_NM104_FirstName]							= [RefProvFirst]
		,[2310AP_NM109_ProviderIdentifier]					= [RefProvNPI]

		,[2310BP_NM103_LastName]							= [RendProvLast]
		,[2310BP_NM104_FirstName]							= [RendProvFirst]
		,[2310BP_NM109_ProviderIdentifier]					= [RendProvNPI]
		,[2310BP_PRV03_ProviderTaxonomy]					= [RendProvTaxonomy]

		,[2310DP_NM103_LastName]							= [SupervisingProvLast]
		,[2310DP_NM104_FirstName]							= [SupervisingProvFirst]
		,[2310DP_NM109_ProviderIdentifier]					= [SupervisingProvNPI]
	 FROM  [Medicaid].[dbo].[EE_CSV_20P_Rec_Header] CSV20P
	 INNER JOIN #Temp1 CLAIMSPROV ON CSV20P.ClaimID = CLAIMSPROV.ClaimNo
 END;


/*    SYSLOG UPDATES - END OF PROCESS 
----------------------------------------------------------------------------------------------------------*/ 
						
						UPDATE dbo.EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = CASE WHEN @CLAIM_TYPE = 'I' THEN (SELECT COUNT(DISTINCT(CLAIM_ID)) FROM MEDICAID.dbo.OUTB_INST_HEADER)
								                  WHEN @CLAIM_TYPE = 'P' THEN (SELECT COUNT(DISTINCT(CLAIM_ID)) FROM MEDICAID.dbo.OUTB_PROF_HEADER)
											 END
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'dbo.MedicaidFloridaCGUpdates' + '-'  + rtrim(@CLAIM_TYPE)
										and END_DT is null
GO


