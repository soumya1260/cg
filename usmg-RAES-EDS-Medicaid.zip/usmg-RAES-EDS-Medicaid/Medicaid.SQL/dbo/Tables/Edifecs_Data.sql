﻿CREATE TABLE [dbo].[Edifecs_Data] (
    [TRACKINGIDENTIFIER] VARCHAR (50) NULL,
    [claimid]            VARCHAR (50) NULL,
    [Sourcekey]          VARCHAR (50) NULL,
    [encountericn]       VARCHAR (50) NULL,
    [PCN]                VARCHAR (50) NULL,
    [Sourcedesc]         VARCHAR (50) NULL
);

