﻿CREATE TABLE [dbo].[LineofBusinessDim] (
    [LineOfBusinessKey]      INT              NOT NULL,
    [LOBCode]                VARCHAR (15)     NOT NULL,
    [ProductType]            VARCHAR (10)     NOT NULL,
    [CompanyCode]            VARCHAR (25)     NULL,
    [Name]                   VARCHAR (30)     NOT NULL,
    [TypeCode]               VARCHAR (3)      NOT NULL,
    [Grouping]               VARCHAR (2)      NOT NULL,
    [State]                  CHAR (15)        NOT NULL,
    [RegulatoryMarket]       VARCHAR (15)     NOT NULL,
    [OperationalMarket]      VARCHAR (3)      NOT NULL,
    [Orig_OperationalMarket] CHAR (2)         NOT NULL,
    [HCFACode]               VARCHAR (5)      NOT NULL,
    [FullName]               VARCHAR (60)     NOT NULL,
    [SourceDataKey]          INT              NOT NULL,
    [Active]                 BIT              NOT NULL,
    [Deleted]                BIT              NOT NULL,
    [LoadDateKey]            INT              NOT NULL,
    [EnterpriseID]           UNIQUEIDENTIFIER NOT NULL,
    [LastUpdateDateKey]      INT              NOT NULL
);

