﻿CREATE TABLE [dbo].[OUTB_CLAIM_STATUS] (
    [CLAIM_ID]                    VARCHAR (20)   NULL,
    [CLAIM_TYPE]                  VARCHAR (1)    NULL,
    [FILEID]                      CHAR (50)      NULL,
    [CLM_IND]                     VARCHAR (20)   NULL,
    [SOURCEDATAKEY]               INT            NULL,
    [MEMBER_ID]                   CHAR (80)      NULL,
    [HICN_NUM]                    CHAR (20)      NULL,
    [BILL_PROV_GRP_ID]            CHAR (40)      NULL,
    [BILL_PROV_ID]                CHAR (40)      NULL,
    [REF_PROV_ID]                 CHAR (50)      NULL,
    [REF_PCP_PROV_ID]             CHAR (50)      NULL,
    [ATTN_PROV_ID]                CHAR (50)      NULL,
    [CLMSTAT_STATUS]              VARCHAR (50)   NULL,
    [STAT_CLM_TYPE]               VARCHAR (1)    NULL,
    [WIPRO_CLAIM_ID]              VARCHAR (20)   NULL,
    [CMS_ICN]                     VARCHAR (20)   NULL,
    [STAT_FATAL_ERR_FLAG]         VARCHAR (1)    NULL,
    [STAT_REJ_REA_ID]             VARCHAR (8)    NULL,
    [REJ_REA_MSG]                 VARCHAR (200)  NULL,
    [LINE_SEQ_NO]                 VARCHAR (4)    NULL,
    [OTH_PAYER_ID]                VARCHAR (50)   NULL,
    [FIELD_TYPE]                  VARCHAR (100)  NULL,
    [SUBTYPE]                     VARCHAR (50)   NULL,
    [FIELD_SUB_QUAL]              VARCHAR (15)   NULL,
    [FIELD_POS]                   VARCHAR (50)   NULL,
    [FIELD_ERR]                   VARCHAR (100)  NULL,
    [VAL_ERR]                     VARCHAR (1024) NULL,
    [FILEDATE]                    VARCHAR (14)   NULL,
    [LAST_UPD_DATE]               DATETIME       NULL,
    [DOS_MONTH]                   VARCHAR (6)    NULL,
    [SecondaryPlanClaimNumber]    VARCHAR (20)   NULL,
    [EffectiveEncounterFlag]      CHAR (1)       NULL,
    [OriginalPlanClaimID]         VARCHAR (20)   NULL,
    [TradingPartnerID]            VARCHAR (1000) NULL,
    [SenderIdentifier]            VARCHAR (500)  NULL,
    [ReceiverIdentifier]          VARCHAR (500)  NULL,
    [837FileName]                 VARCHAR (8000) NULL,
    [EncountersStatus]            VARCHAR (500)  NULL,
    [EncDispositionCaption]       VARCHAR (500)  NULL,
    [TransTypeCaption]            VARCHAR (500)  NULL,
    [ChannelStatus]               VARCHAR (500)  NULL,
    [ExternalStatus999]           VARCHAR (500)  NULL,
    [AckTransFile999]             VARCHAR (500)  NULL,
    [ExternalStatus277]           VARCHAR (500)  NULL,
    [FileName277]                 VARCHAR (500)  NULL,
    [Transactiondate277]          VARCHAR (500)  NULL,
    [PlanID]                      VARCHAR (100)  NULL,
    [ClaimAdjudicateStatus]       VARCHAR (100)  NULL,
    [PaidAmount]                  MONEY          NULL,
    [PaidDate]                    INT            NULL,
    [ServiceDateFrom]             INT            NULL,
    [ServiceDateTo]               INT            NULL,
    [ClaimAmount]                 MONEY          NULL,
    [OrgClaimID]                  VARCHAR (50)   NULL,
    [MemberID]                    VARCHAR (80)   NULL,
    [SSN]                         VARCHAR (11)   NULL,
    [FirstName]                   VARCHAR (35)   NULL,
    [LastName]                    VARCHAR (60)   NULL,
    [DOB]                         VARCHAR (10)   NULL,
    [BillingProvNPI]              VARCHAR (10)   NULL,
    [BillingProviderTaxonomy]     VARCHAR (10)   NULL,
    [Acceptedextclmcontrolnumber] VARCHAR (250)  NULL,
    [Rejectedextclmcontrolnumber] VARCHAR (250)  NULL
);




GO
CREATE CLUSTERED INDEX [IDX_CLAIMID_SOURCEDATAKEY]
    ON [dbo].[OUTB_CLAIM_STATUS]([CLAIM_ID] ASC, [SOURCEDATAKEY] ASC) WITH (FILLFACTOR = 100);


GO
CREATE NONCLUSTERED INDEX [NIX_OUTB_CLAIM_STATUS_FileDate_IncClaimIdFileId]
    ON [dbo].[OUTB_CLAIM_STATUS]([FILEDATE] ASC)
    INCLUDE([CLAIM_ID], [FILEID]) WITH (FILLFACTOR = 100);


GO
CREATE NONCLUSTERED INDEX [NIX_OUTB_CLAIM_STATUS_for_BuildClaimRejectSummary]
    ON [dbo].[OUTB_CLAIM_STATUS]([CLMSTAT_STATUS] ASC, [STAT_REJ_REA_ID] ASC)
    INCLUDE([CLAIM_ID], [FILEID], [SOURCEDATAKEY]) WITH (FILLFACTOR = 100);


GO
CREATE NONCLUSTERED INDEX [NIX_OUTB_CLAIM_STATUS_ForClaimSummaryReportData]
    ON [dbo].[OUTB_CLAIM_STATUS]([CLAIM_ID] ASC, [FILEID] ASC, [FILEDATE] ASC) WITH (FILLFACTOR = 100);


GO
CREATE NONCLUSTERED INDEX [NIX_OUTB_CLAIM_STATUS_SourceDataKey_EncounterReports]
    ON [dbo].[OUTB_CLAIM_STATUS]([SOURCEDATAKEY] ASC)
    INCLUDE([ATTN_PROV_ID], [BILL_PROV_GRP_ID], [BILL_PROV_ID], [CLAIM_ID], [FILEID], [HICN_NUM], [MEMBER_ID]) WITH (FILLFACTOR = 100);


GO
CREATE NONCLUSTERED INDEX [NIX_OUTB_CLAIM_STATUS_SourceDataKey_FileDate_Inc_ClaimID_FileID]
    ON [dbo].[OUTB_CLAIM_STATUS]([SOURCEDATAKEY] ASC, [FILEDATE] ASC)
    INCLUDE([CLAIM_ID], [FILEID]) WITH (FILLFACTOR = 100);


GO
CREATE NONCLUSTERED INDEX [NIX_FileDate_for_RejVolSummRpt]
    ON [dbo].[OUTB_CLAIM_STATUS]([FILEDATE] ASC)
    INCLUDE([CLAIM_ID], [CLMSTAT_STATUS], [FIELD_TYPE], [REJ_REA_MSG], [SOURCEDATAKEY], [STAT_REJ_REA_ID], [SUBTYPE]) WITH (FILLFACTOR = 100);


GO
CREATE NONCLUSTERED INDEX [testing_1]
    ON [dbo].[OUTB_CLAIM_STATUS]([FILEID] ASC)
    INCLUDE([CLAIM_ID]) WITH (FILLFACTOR = 100);


GO
CREATE NONCLUSTERED INDEX [Idx_CLMSTAT_STATUS]
    ON [dbo].[OUTB_CLAIM_STATUS]([CLMSTAT_STATUS] ASC)
    INCLUDE([CLAIM_ID], [CLAIM_TYPE], [SOURCEDATAKEY]);


GO
CREATE NONCLUSTERED INDEX [idx_STAT_REJ_REA_ID]
    ON [dbo].[OUTB_CLAIM_STATUS]([STAT_REJ_REA_ID] ASC)
    INCLUDE([CLAIM_ID], [FILEID], [SOURCEDATAKEY]);


GO
CREATE NONCLUSTERED INDEX [ix_OUTB_CLAIM_STATUS_SOURCEDATAKEY_CLMSTAT_STATUS_includes]
    ON [dbo].[OUTB_CLAIM_STATUS]([SOURCEDATAKEY] ASC, [CLMSTAT_STATUS] ASC)
    INCLUDE([CLAIM_ID], [FILEID], [LAST_UPD_DATE]) WITH (FILLFACTOR = 80);


GO
CREATE NONCLUSTERED INDEX [NIX_OUTB_CLAIM_STATUS_SDK_CLMSTAT_CMS_ICN]
    ON [dbo].[OUTB_CLAIM_STATUS]([SOURCEDATAKEY] ASC, [CLMSTAT_STATUS] ASC)
    INCLUDE([CLAIM_ID], [FILEID], [CMS_ICN]);


GO
CREATE NONCLUSTERED INDEX [IDX_OUTB_CLAIM_STATUS_SOURCEDATAKEY_CLMSTAT_STATUS]
    ON [dbo].[OUTB_CLAIM_STATUS]([SOURCEDATAKEY] ASC, [CLMSTAT_STATUS] ASC)
    INCLUDE([CLAIM_ID], [FILEID], [CMS_ICN]);


GO
CREATE NONCLUSTERED INDEX [IDX_OUTB_CLAIM_STATUS_FILEID_SOURCEDATAKEY_CLAIM_ID]
    ON [dbo].[OUTB_CLAIM_STATUS]([FILEID] ASC, [SOURCEDATAKEY] ASC)
    INCLUDE([CLAIM_ID]);


GO
CREATE NONCLUSTERED INDEX [IDX_FileDate_ClaimID_ClaimType_SourceKey_MemberID]
    ON [dbo].[OUTB_CLAIM_STATUS]([FILEDATE] ASC)
    INCLUDE([CLAIM_ID], [CLAIM_TYPE], [SOURCEDATAKEY], [MEMBER_ID], [HICN_NUM], [BILL_PROV_ID], [CLMSTAT_STATUS], [LAST_UPD_DATE]);


GO
CREATE NONCLUSTERED INDEX [IDX_SourceDataKey_ClaimID]
    ON [dbo].[OUTB_CLAIM_STATUS]([SOURCEDATAKEY] ASC, [CLAIM_ID] ASC) WITH (FILLFACTOR = 100);


GO
CREATE NONCLUSTERED INDEX [idx_ICN_file_ID]
    ON [dbo].[OUTB_CLAIM_STATUS]([CMS_ICN] ASC, [FILEID] ASC) WITH (DATA_COMPRESSION = PAGE);

