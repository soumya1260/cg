﻿CREATE TABLE [dbo].[OUTB_CLAIM_ERRORSUMMARY] (
    [CLAIM_ID]         VARCHAR (500)  NULL,
    [LAST_UPD_DATE]    DATETIME       NULL,
    [Sourcedatakey]    VARCHAR (500)  NULL,
    [FileID]           VARCHAR (8000) NULL,
    [STAT_REJ_REA_ID]  VARCHAR (500)  NULL,
    [REJ_REA_MSG]      VARCHAR (3000) NULL,
    [ChannelStatus]    VARCHAR (500)  NULL,
    [errorseverityid]  VARCHAR (50)   NULL,
    [CLAIM_TYPE]       VARCHAR (50)   NULL,
    [TradingPartnerID] VARCHAR (1000) NULL
);

