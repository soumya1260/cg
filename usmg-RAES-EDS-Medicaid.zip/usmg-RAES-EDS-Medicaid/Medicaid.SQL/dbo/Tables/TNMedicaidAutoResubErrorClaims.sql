﻿CREATE TABLE [dbo].[TNMedicaidAutoResubErrorClaims] (
    [ClaimID] VARCHAR (50) NULL
);

