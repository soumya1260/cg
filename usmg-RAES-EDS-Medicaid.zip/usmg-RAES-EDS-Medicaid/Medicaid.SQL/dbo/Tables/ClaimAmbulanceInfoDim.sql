﻿CREATE TABLE [dbo].[ClaimAmbulanceInfoDim] (
    [ClaimAmbulanceKey] INT              NOT NULL,
    [ClaimID]           VARCHAR (20)     NULL,
    [PickUpAddress]     VARCHAR (60)     NULL,
    [PickUpCity]        VARCHAR (60)     NULL,
    [PickUpState]       VARCHAR (2)      NULL,
    [PickUpZip]         VARCHAR (10)     NULL,
    [DropOffLocation]   VARCHAR (60)     NULL,
    [DropOffAddress]    VARCHAR (60)     NULL,
    [DropOffCity]       VARCHAR (60)     NULL,
    [DropOffState]      VARCHAR (2)      NULL,
    [DropOffZip]        VARCHAR (10)     NULL,
    [CreateDate]        INT              NULL,
    [LastUpdateDateKey] INT              NULL,
    [LoadDateKey]       INT              NULL,
    [SourceDataKey]     INT              NULL,
    [Active]            BIT              NULL,
    [Deleted]           BIT              NULL,
    [EnterpriseID]      UNIQUEIDENTIFIER NULL
);

