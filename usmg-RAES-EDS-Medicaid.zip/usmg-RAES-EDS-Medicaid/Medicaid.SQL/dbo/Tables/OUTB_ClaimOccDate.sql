﻿CREATE TABLE [dbo].[OUTB_ClaimOccDate] (
    [ClaimID]     VARCHAR (20) NOT NULL,
    [Occ_Code_01] VARCHAR (3)  NULL,
    [Occ_Date_01] VARCHAR (8)  NULL,
    [Occ_Code_02] VARCHAR (3)  NULL,
    [Occ_Date_02] VARCHAR (8)  NULL,
    [Occ_Code_03] VARCHAR (3)  NULL,
    [Occ_Date_03] VARCHAR (8)  NULL,
    [Occ_Code_04] VARCHAR (3)  NULL,
    [Occ_Date_04] VARCHAR (8)  NULL,
    [Occ_Code_05] VARCHAR (3)  NULL,
    [Occ_Date_05] VARCHAR (8)  NULL,
    [Occ_Code_06] VARCHAR (3)  NULL,
    [Occ_Date_06] VARCHAR (8)  NULL,
    [Occ_Code_07] VARCHAR (3)  NULL,
    [Occ_Date_07] VARCHAR (8)  NULL,
    [Occ_Code_08] VARCHAR (3)  NULL,
    [Occ_Date_08] VARCHAR (8)  NULL,
    [Occ_Code_09] VARCHAR (3)  NULL,
    [Occ_Date_09] VARCHAR (8)  NULL,
    [Occ_Code_10] VARCHAR (3)  NULL,
    [Occ_Date_10] VARCHAR (8)  NULL,
    [Occ_Code_11] VARCHAR (3)  NULL,
    [Occ_Date_11] VARCHAR (8)  NULL,
    [Occ_Code_12] VARCHAR (3)  NULL,
    [Occ_Date_12] VARCHAR (8)  NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20180110-101155]
    ON [dbo].[OUTB_ClaimOccDate]([ClaimID] ASC);

