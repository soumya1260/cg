﻿CREATE TABLE [dbo].[OUTB_ClaimOccSpanDate] (
    [ClaimID]       VARCHAR (20) NOT NULL,
    [Occ_SCode_01]  VARCHAR (3)  NULL,
    [Occ_SSDate_01] VARCHAR (8)  NULL,
    [Occ_SEDate_01] VARCHAR (8)  NULL,
    [Occ_SCode_02]  VARCHAR (3)  NULL,
    [Occ_SSDate_02] VARCHAR (8)  NULL,
    [Occ_SEDate_02] VARCHAR (8)  NULL,
    [Occ_SCode_03]  VARCHAR (3)  NULL,
    [Occ_SSDate_03] VARCHAR (8)  NULL,
    [Occ_SEDate_03] VARCHAR (8)  NULL,
    [Occ_SCode_04]  VARCHAR (3)  NULL,
    [Occ_SSDate_04] VARCHAR (8)  NULL,
    [Occ_SEDate_04] VARCHAR (8)  NULL,
    [Occ_SCode_05]  VARCHAR (3)  NULL,
    [Occ_SSDate_05] VARCHAR (8)  NULL,
    [Occ_SEDate_05] VARCHAR (8)  NULL,
    [Occ_SCode_06]  VARCHAR (3)  NULL,
    [Occ_SSDate_06] VARCHAR (8)  NULL,
    [Occ_SEDate_06] VARCHAR (8)  NULL,
    [Occ_SCode_07]  VARCHAR (3)  NULL,
    [Occ_SSDate_07] VARCHAR (8)  NULL,
    [Occ_SEDate_07] VARCHAR (8)  NULL,
    [Occ_SCode_08]  VARCHAR (3)  NULL,
    [Occ_SSDate_08] VARCHAR (8)  NULL,
    [Occ_SEDate_08] VARCHAR (8)  NULL,
    [Occ_SCode_09]  VARCHAR (3)  NULL,
    [Occ_SSDate_09] VARCHAR (8)  NULL,
    [Occ_SEDate_09] VARCHAR (8)  NULL,
    [Occ_SCode_10]  VARCHAR (3)  NULL,
    [Occ_SSDate_10] VARCHAR (8)  NULL,
    [Occ_SEDate_10] VARCHAR (8)  NULL,
    [Occ_SCode_11]  VARCHAR (3)  NULL,
    [Occ_SSDate_11] VARCHAR (8)  NULL,
    [Occ_SEDate_11] VARCHAR (8)  NULL,
    [Occ_SCode_12]  VARCHAR (3)  NULL,
    [Occ_SSDate_12] VARCHAR (8)  NULL,
    [Occ_SEDate_12] VARCHAR (8)  NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20180110-101122]
    ON [dbo].[OUTB_ClaimOccSpanDate]([ClaimID] ASC);

