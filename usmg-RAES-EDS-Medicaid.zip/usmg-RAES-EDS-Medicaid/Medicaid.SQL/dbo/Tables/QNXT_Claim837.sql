﻿CREATE TABLE [dbo].[QNXT_Claim837] (
    [ClaimID]               CHAR (15)     NOT NULL,
    [BillingProvName]       VARCHAR (95)  NULL,
    [BillingProvQualifier]  CHAR (2)      NULL,
    [billingprovidentifier] CHAR (80)     NULL,
    [createid]              VARCHAR (120) NULL,
    [createdate]            DATETIME      NULL,
    [updateid]              VARCHAR (120) NULL,
    [lastupdate]            DATETIME      NULL
);


GO
CREATE NONCLUSTERED INDEX [IDX_QNXT_claim837_01]
    ON [dbo].[QNXT_Claim837]([ClaimID] ASC)
    INCLUDE([billingprovidentifier]);

