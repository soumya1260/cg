﻿CREATE TABLE [dbo].[EDS_ClaimExtractParams] (
    [SourceDataKey]          INT           NOT NULL,
    [SourceDesc]             VARCHAR (200) NOT NULL,
    [MaxClaimsPerFile]       INT           NULL,
    [ManualMaxClaimsPerFile] INT           NULL,
    [CLAIM_TYPE]             VARCHAR (1)   NULL
);

