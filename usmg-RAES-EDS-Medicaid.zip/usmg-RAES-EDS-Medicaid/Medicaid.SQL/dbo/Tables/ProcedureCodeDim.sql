﻿CREATE TABLE [dbo].[ProcedureCodeDim] (
    [procedurecode]        VARCHAR (11)     NULL,
    [procedurecodekey]     INT              NULL,
    [effectivedatekey]     INT              NULL,
    [enddatekey]           INT              NULL,
    [proceduredesc]        VARCHAR (255)    NULL,
    [proceduretypecode]    VARCHAR (1)      NULL,
    [SourceDataKey]        INT              NULL,
    [DiagnosisCodeVersion] VARCHAR (1)      NULL,
    [Accomodation]         VARCHAR (1)      NULL,
    [ProcedureGroup]       VARCHAR (30)     NULL,
    [LastUpdateDateKey]    INT              NULL,
    [Active]               BIT              NULL,
    [Deleted]              BIT              NULL,
    [LoadDateKey]          INT              NULL,
    [EnterpriseID]         UNIQUEIDENTIFIER NULL
);

