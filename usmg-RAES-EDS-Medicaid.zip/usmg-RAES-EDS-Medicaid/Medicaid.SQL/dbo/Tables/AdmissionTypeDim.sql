﻿CREATE TABLE [dbo].[AdmissionTypeDim] (
    [AdmissionTypeKey]  INT              NOT NULL,
    [AdmissionTypeCode] VARCHAR (10)     NOT NULL,
    [AdmissionTypeDesc] VARCHAR (40)     NOT NULL,
    [SourceDataKey]     INT              NOT NULL,
    [Active]            BIT              NOT NULL,
    [Deleted]           BIT              NOT NULL,
    [LoadDateKey]       INT              NOT NULL,
    [EnterpriseID]      UNIQUEIDENTIFIER NOT NULL
);

