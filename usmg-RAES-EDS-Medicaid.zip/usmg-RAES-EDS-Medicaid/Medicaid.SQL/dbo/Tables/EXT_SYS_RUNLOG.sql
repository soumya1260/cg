﻿CREATE TABLE [dbo].[EXT_SYS_RUNLOG] (
    [PROC_NAME]     VARCHAR (75) NULL,
    [STEP]          VARCHAR (15) NULL,
    [START_DT]      DATETIME     NULL,
    [END_DT]        DATETIME     NULL,
    [RUN_MINUTES]   INT          NULL,
    [TOTAL_RECORDS] INT          NULL,
    [ENTRYDT]       DATETIME     NULL
);

