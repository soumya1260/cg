﻿CREATE TABLE [dbo].[EDS_ProviderPhoneDim] (
    [SourceDataKey] INT          NULL,
    [ProviderID]    VARCHAR (20) NULL,
    [PhoneTypeCode] VARCHAR (2)  NULL,
    [PhoneNumber]   VARCHAR (20) NULL,
    [FaxNumber]     VARCHAR (20) NULL,
    [MultiPhoneInd] INT          NULL
);

