﻿CREATE TABLE [dbo].[MonthlyMembershipDim] (
    [MonthlyMembershipKey]       INT          NULL,
    [MemberID]                   VARCHAR (16) NULL,
    [BeginCoverageDateKey]       INT          NOT NULL,
    [EndCoverageDateKey]         INT          NOT NULL,
    [ContinuousEffectiveDateKey] INT          NULL,
    [DOBDateKey]                 INT          NULL,
    [MemberAge]                  INT          NULL,
    [ReportDateKey]              INT          NOT NULL,
    [ModifiedReportDateKey]      INT          NOT NULL,
    [CntMemFlag]                 INT          NULL,
    [SubscriberID]               VARCHAR (16) NULL,
    [MedicareID]                 VARCHAR (25) NULL,
    [MedicaidID]                 VARCHAR (20) NULL,
    [LobCode]                    VARCHAR (15) NULL,
    [ProductType]                VARCHAR (10) NULL,
    [OperationalMarket]          CHAR (2)     NULL,
    [RegulatoryMarket]           CHAR (2)     NULL,
    [EmployerCode]               VARCHAR (30) NULL,
    [GroupID]                    VARCHAR (30) NULL,
    [RegionCode]                 VARCHAR (10) NULL,
    [PCPID]                      VARCHAR (20) NULL,
    [P4QFlag]                    CHAR (1)     NULL,
    [P4QGroupCode]               VARCHAR (20) NULL,
    [PodCode]                    VARCHAR (6)  NULL,
    [GrpBenPlanCd]               VARCHAR (15) NULL,
    [HCFACode]                   VARCHAR (5)  NOT NULL,
    [PBPCode]                    VARCHAR (3)  NULL,
    [SCCCode]                    VARCHAR (5)  NULL,
    [LISFlag]                    CHAR (1)     NULL,
    [LISSubsidy]                 VARCHAR (3)  NULL,
    [ESRDRiskInd]                CHAR (1)     NULL,
    [AgeDisabledRiskInd]         CHAR (1)     NULL,
    [WelfareRiskInd]             CHAR (1)     NULL,
    [WorkAgedRiskInd]            CHAR (1)     NULL,
    [InstitutionalRiskInd]       CHAR (1)     NULL,
    [HospiceRiskInd]             CHAR (1)     NULL,
    [MedicaidRiskInd]            CHAR (1)     NULL,
    [MedicaidLVL]                VARCHAR (40) NULL,
    [MedicaidLVLDesc]            VARCHAR (50) NULL,
    [CostShareFlag]              VARCHAR (3)  NULL,
    [SourceDataKey]              INT          NOT NULL
);


GO
CREATE NONCLUSTERED INDEX [IDX_MonthlyMemberShip_MemberID_CoverageDate]
    ON [dbo].[MonthlyMembershipDim]([BeginCoverageDateKey] ASC, [EndCoverageDateKey] ASC, [MemberID] ASC);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20160929-190013]
    ON [dbo].[MonthlyMembershipDim]([MemberID] ASC);

