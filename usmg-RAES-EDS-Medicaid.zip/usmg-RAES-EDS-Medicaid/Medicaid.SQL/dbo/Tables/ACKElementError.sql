﻿CREATE TABLE [dbo].[ACKElementError] (
    [ID]          INT           IDENTITY (1, 1) NOT NULL,
    [CODE]        VARCHAR (3)   NOT NULL,
    [DESCRIPTION] VARCHAR (MAX) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

