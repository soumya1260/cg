﻿CREATE TABLE [dbo].[MedicaidENCAdhocRefresh] (
    [MemberID] VARCHAR (50) NULL,
    [ClaimID]  VARCHAR (50) NULL
);


GO
CREATE CLUSTERED INDEX [ENCAdhoc_MemClaim]
    ON [dbo].[MedicaidENCAdhocRefresh]([MemberID] ASC, [ClaimID] ASC);

