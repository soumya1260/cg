﻿CREATE TABLE [dbo].[ACKFileDetail] (
    [FileDetailID]   INT           IDENTITY (1, 1) NOT NULL,
    [TRNSDATE]       DATETIME      NOT NULL,
    [FILENAME]       VARCHAR (255) NOT NULL,
    [ISASNDRID]      VARCHAR (15)  NOT NULL,
    [ISARCVRID]      VARCHAR (15)  NOT NULL,
    [ISACNTRL#]      VARCHAR (10)  NOT NULL,
    [GSSNDRID]       VARCHAR (15)  NOT NULL,
    [GSRCVRID]       VARCHAR (15)  NOT NULL,
    [GSCNTRL#]       VARCHAR (10)  NOT NULL,
    [VERSION]        VARCHAR (15)  NOT NULL,
    [TSTorPRD]       VARCHAR (1)   NOT NULL,
    [TRANSTYPE]      VARCHAR (10)  NOT NULL,
    [DIRECTION]      VARCHAR (3)   NOT NULL,
    [RCVDCNT]        INT           NOT NULL,
    [RJCTDCNT]       INT           NOT NULL,
    [ACCPTDCNT]      INT           NOT NULL,
    [ACCPTWTHERRCNT] INT           NOT NULL,
    [LOADDATEKEY]    INT           NOT NULL
);

