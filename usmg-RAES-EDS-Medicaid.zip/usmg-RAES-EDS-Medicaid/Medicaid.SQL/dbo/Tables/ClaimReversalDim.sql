﻿CREATE TABLE [dbo].[ClaimReversalDim] (
    [CLAIMID]          VARCHAR (20)     NULL,
    [SOURCEDATAKEY]    INT              NULL,
    [CLAIMREVERSALKEY] INT              NULL,
    [REVERSALFLAG]     VARCHAR (1)      NULL,
    [ACTIVE]           BIT              NULL,
    [DELETED]          BIT              NULL,
    [LOADDATEKEY]      INT              NULL,
    [ENTERPRISEID]     UNIQUEIDENTIFIER NULL
);

