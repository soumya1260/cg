﻿CREATE TABLE [dbo].[SATEst] (
    [id] INT NULL
);

