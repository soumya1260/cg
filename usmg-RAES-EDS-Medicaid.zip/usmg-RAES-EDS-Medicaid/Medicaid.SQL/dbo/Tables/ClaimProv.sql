﻿CREATE TABLE [dbo].[ClaimProv] (
    [ClaimId]                 CHAR (15)     NOT NULL,
    [SequenceId]              INT           NOT NULL,
    [ProvId]                  CHAR (15)     NOT NULL,
    [PhysTypeQualifier]       CHAR (15)     NOT NULL,
    [PhysTypeSubQualifier]    CHAR (15)     NOT NULL,
    [ExternalProvId]          CHAR (30)     NOT NULL,
    [ExternalProvIdQualifier] CHAR (15)     NOT NULL,
    [ProvFirstName]           VARCHAR (35)  NOT NULL,
    [ProvLastName]            CHAR (60)     NOT NULL,
    [Npi]                     CHAR (10)     NOT NULL,
    [CreateId]                VARCHAR (120) NOT NULL,
    [CreateDate]              DATETIME      NOT NULL,
    [UpdateId]                VARCHAR (120) NOT NULL,
    [LastUpdate]              DATETIME      NOT NULL,
    [TaxonomyCodeId]          VARCHAR (30)  NULL,
    CONSTRAINT [PK_ClaimProv] PRIMARY KEY CLUSTERED ([ClaimId] ASC, [SequenceId] ASC)
);

