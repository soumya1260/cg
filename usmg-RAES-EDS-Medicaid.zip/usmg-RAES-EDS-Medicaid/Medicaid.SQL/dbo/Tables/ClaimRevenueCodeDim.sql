﻿CREATE TABLE [dbo].[ClaimRevenueCodeDim] (
    [CLAIMID]       VARCHAR (20) NULL,
    [REVENUECODE]   VARCHAR (5)  NULL,
    [PROCEDURECODE] VARCHAR (11) NULL,
    [SERVICEDATE]   VARCHAR (8)  NULL,
    [QUANTITY]      VARCHAR (7)  NULL,
    [CHARGES]       VARCHAR (15) NULL,
    [SourceDataKey] INT          NULL
);

