﻿CREATE TABLE [dbo].[CLAIMSTATUSDIM] (
    [CLAIMID]             VARCHAR (20)     NULL,
    [SOURCEDATAKEY]       INT              NULL,
    [CLAIMSTATUSKEY]      BIGINT           NULL,
    [STATUSSEQUENCE]      INT              NULL,
    [STATUSCODE]          VARCHAR (10)     NULL,
    [ADJUDICATORINITIALS] VARCHAR (20)     NULL,
    [STATUSCHANGEDATEKEY] INT              NULL,
    [ACTIVE]              BIT              NULL,
    [DELETED]             BIT              NULL,
    [LOADDATEKEY]         INT              NULL,
    [ENTERPRISEID]        UNIQUEIDENTIFIER NULL
);

