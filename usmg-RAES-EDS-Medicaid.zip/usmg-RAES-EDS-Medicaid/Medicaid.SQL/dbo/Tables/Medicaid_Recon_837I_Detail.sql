﻿CREATE TABLE [dbo].[Medicaid_Recon_837I_Detail](
	[IsaSenderID] [varchar](20) NULL,
	[IsaControlId] [varchar](20) NULL,
	[TradingPartnerID] [varchar](60) NULL,
	[ClaimId] [varchar](20) NULL,
	[LineItemNumber] [int] NULL,
	[PayerPrimaryID] [varchar](10) NULL,
	[DaysInHospital] [varchar](10) NULL,
	[ProviderControlNumber] [varchar](20) NULL,
	[ServiceLinePaidAmount] [varchar](20) NULL,
	[ServiceLineChrgAmount] [varchar](20) NULL,
	[SrvLineRevCode] [varchar](10) NULL,
	[SrvPRODQual] [varchar](10) NULL,
	[SrvProdID] [varchar](10) NULL,
	[ProdMod1] [varchar](10) NULL,
	[ProdMod2] [varchar](10) NULL,
	[ProdMod3] [varchar](10) NULL,
	[ProdMod4] [varchar](10) NULL,
	[SrvDescription] [varchar](80) NULL,
	[ClmAdjGroupCode1] [varchar](5) NULL,
	[ClmAdjReasonCode1] [varchar](5) NULL,
	[ClmAdjAmount1] [varchar](20) NULL,
	[ClmAdjGroupCode2] [varchar](5) NULL,
	[ClmAdjReasonCode2] [varchar](5) NULL,
	[ClmAdjAmount2] [varchar](20) NULL,
	[ClmAdjGroupCode3] [varchar](5) NULL,
	[ClmAdjReasonCode3] [varchar](5) NULL,
	[ClmAdjAmount3] [varchar](20) NULL,
	[ClmAdjGroupCode4] [varchar](5) NULL,
	[ClmAdjReasonCode4] [varchar](5) NULL,
	[ClmAdjAmount4] [varchar](20) NULL,
	[ClmAdjGroupCode5] [varchar](5) NULL,
	[ClmAdjReasonCode5] [varchar](5) NULL,
	[ClmAdjAmount5] [varchar](20) NULL,
	[ClmAdjGroupCode6] [varchar](5) NULL,
	[ClmAdjReasonCode6] [varchar](5) NULL,
	[ClmAdjAmount6] [varchar](20) NULL,
	[DateofServiceQual] [varchar](20) NULL,
	[DateofServiceBegin] [varchar](20) NULL,
	[DateofServiceEnd] [varchar](20) NULL,
	[PaidDateQual] [varchar](20) NULL,
	[PaidDateBegin] [varchar](20) NULL,
	[PaidDateEnd] [varchar](20) NULL,
	[LoadDate] [datetime] NULL
) ON [PRIMARY]
GO


/****** Object:  Index [ClusteredIndex-20241105-115606]    Script Date: 12/3/2024 10:48:19 AM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20241105-115606] ON [dbo].[Medicaid_Recon_837I_Detail]
(
	[IsaSenderID] ASC,
	[IsaControlId] ASC,
	[TradingPartnerID] ASC,
	[ClaimId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
