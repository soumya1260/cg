﻿CREATE TABLE [dbo].[ClaimDim] (
    [CLAIMKEY]                    BIGINT           NULL,
    [MEMBERID]                    VARCHAR (16)     NULL,
    [CLAIMID]                     VARCHAR (20)     NULL,
    [PREVIOUSCLAIMID]             VARCHAR (20)     NULL,
    [SUBSCRIBERID]                VARCHAR (15)     NULL,
    [GROUPID]                     VARCHAR (30)     NULL,
    [AUTHORIZATIONID]             VARCHAR (30)     NULL,
    [BATCHID]                     VARCHAR (24)     NULL,
    [PATIENTID]                   VARCHAR (24)     NULL,
    [PCPID]                       VARCHAR (20)     NULL,
    [PCPVENDOR]                   VARCHAR (20)     NULL,
    [PAYTOVENDORORFAMILYFLAG]     VARCHAR (1)      NULL,
    [MHCFINANCIALDATEKEY]         INT              NULL,
    [ADMISSIONDATEKEY]            INT              NULL,
    [DISCHARGEDATEKEY]            INT              NULL,
    [DATERECEIVEDKEY]             INT              NULL,
    [CODEREVIEWDATEKEY]           INT              NULL,
    [INVOICEDATEKEY]              INT              NULL,
    [DISPOSITIONCODE]             VARCHAR (5)      NULL,
    [VENDORNPI]                   VARCHAR (10)     NULL,
    [FORMTYPECODE]                VARCHAR (1)      NULL,
    [DENIEDFLAG]                  VARCHAR (1)      NULL,
    [INVOICENUMBER]               VARCHAR (15)     NULL,
    [CURRENTSTATUSCODE]           VARCHAR (10)     NULL,
    [TYPECODE]                    VARCHAR (15)     NULL,
    [UNCLEANFLAG]                 VARCHAR (1)      NULL,
    [FAMILYPAYMENTAMT]            MONEY            NULL,
    [MEMBERPAIDAMT]               MONEY            NULL,
    [TOTALDISCOUNTEDAMT]          MONEY            NULL,
    [ACCIDENTDATEKEY]             INT              NULL,
    [VISITSCOUNT]                 INT              NULL,
    [CLAIMBILLEDAMT]              MONEY            NULL,
    [REFERRINGPHYSICIANID]        VARCHAR (25)     NULL,
    [ATTENDINGPHYSICIANID]        VARCHAR (25)     NULL,
    [VENDORPAYMENT]               MONEY            NULL,
    [TOTALPAID]                   MONEY            NULL,
    [CODEREVIEWORIGINALLYPAIDAMT] MONEY            NULL,
    [BENEFITPLAN]                 VARCHAR (15)     NULL,
    [LOBCODE]                     VARCHAR (15)     NULL,
    [DRGCODE]                     VARCHAR (6)      NULL,
    [DRGCHARGEAMOUNT]             MONEY            NULL,
    [CAPACITYCODE]                VARCHAR (5)      NULL,
    [PROVIDERREGIONCODE]          VARCHAR (15)     NULL,
    [MEMBERREGIONCODE]            VARCHAR (15)     NULL,
    [BEDTYPECODE]                 VARCHAR (3)      NULL,
    [COMPANYID]                   VARCHAR (15)     NULL,
    [SOURCEDATAKEY]               INT              NULL,
    [ACTIVE]                      BIT              NULL,
    [DELETED]                     BIT              NULL,
    [LOADDATEKEY]                 INT              NULL,
    [ENTERPRISEID]                UNIQUEIDENTIFIER NULL,
    [BeginServiceDateKey]         INT              NULL,
    [EndServiceDateKey]           INT              NULL,
    [LastUpdateDateKey]           INT              NULL,
    [ICNStatus]                   CHAR (1)         NULL
);


GO
CREATE NONCLUSTERED INDEX [IDX_BeginDOS_MemberID_ClaimId_SubsID_GrpID_AdminDate_DischargeDate_More]
    ON [dbo].[ClaimDim]([BeginServiceDateKey] ASC)
    INCLUDE([MEMBERID], [CLAIMID], [PREVIOUSCLAIMID], [SUBSCRIBERID], [GROUPID], [PCPID], [ADMISSIONDATEKEY], [DISCHARGEDATEKEY], [VENDORNPI], [FORMTYPECODE], [DENIEDFLAG], [CURRENTSTATUSCODE], [TYPECODE], [CLAIMBILLEDAMT], [REFERRINGPHYSICIANID], [ATTENDINGPHYSICIANID], [TOTALPAID], [LOBCODE], [SOURCEDATAKEY], [ACTIVE], [DELETED], [EndServiceDateKey]);


GO
CREATE NONCLUSTERED INDEX [idx_Filter_Formtypecode]
    ON [dbo].[ClaimDim]([FORMTYPECODE] ASC)
    INCLUDE([BeginServiceDateKey], [EndServiceDateKey], [CLAIMID], [MEMBERID]) WHERE ([FORMTYPECODE]='H');


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDim_ExclusionProcessing_1]
    ON [dbo].[ClaimDim]([CLAIMID] ASC, [SOURCEDATAKEY] ASC)
    INCLUDE([FORMTYPECODE]);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDim_ExtractProcessing_1]
    ON [dbo].[ClaimDim]([FORMTYPECODE] ASC, [SOURCEDATAKEY] ASC)
    INCLUDE([CLAIMID], [DENIEDFLAG], [LOBCODE]);

