﻿CREATE TABLE [dbo].[MedicaidTradingPartner] (
    [OperationalMarket]       VARCHAR (50) NULL,
    [TradingPartnerID]        VARCHAR (50) NULL,
    [HCFACODE]                VARCHAR (50) NULL,
    [PBP]                     VARCHAR (50) NULL,
    [Dual_Status_Code]        VARCHAR (50) NULL,
    [ClaimsDependent]         VARCHAR (50) NULL,
    [PlanActiveDate]          DATE         NULL,
    [PlanEndDate]             DATE         NULL,
    [Verify_Dual_Status_Code] INT          NULL,
    [Verify_ClaimDependent]   INT          NULL,
    [IsActive]                INT          NULL,
    [LastUpdate]              DATETIME     NULL,
    [FinancialYear]           INT          NULL
);

