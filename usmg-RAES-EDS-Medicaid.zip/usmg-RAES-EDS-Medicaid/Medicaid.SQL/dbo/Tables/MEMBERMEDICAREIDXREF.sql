﻿CREATE TABLE [dbo].[MEMBERMEDICAREIDXREF] (
    [MemberID]          VARCHAR (20) NULL,
    [MedicareID]        VARCHAR (12) NULL,
    [AccountingDateKey] INT          NULL,
    [Source]            VARCHAR (3)  NULL
);

