﻿CREATE TABLE [dbo].[Eds_medicaid_claims] (
    [ClaimID] VARCHAR (50) NULL
);

