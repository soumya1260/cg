﻿CREATE TABLE [dbo].[ClaimConditionDim] (
    [ClaimConditionKey] INT              NULL,
    [ClaimID]           VARCHAR (20)     NULL,
    [ConditionCode]     CHAR (5)         NULL,
    [LastUpdateDateKey] INT              NULL,
    [SourceDataKey]     INT              NULL,
    [Active]            BIT              NULL,
    [Deleted]           BIT              NULL,
    [LoadDateKey]       INT              NULL,
    [EnterpriseID]      UNIQUEIDENTIFIER NULL
);

