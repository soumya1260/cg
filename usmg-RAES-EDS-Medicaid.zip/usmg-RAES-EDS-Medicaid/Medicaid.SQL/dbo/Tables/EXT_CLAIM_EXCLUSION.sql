﻿CREATE TABLE [dbo].[EXT_CLAIM_EXCLUSION] (
    [CLAIM_ID]           VARCHAR (20) NULL,
    [SOURCEDATAKEY]      INT          NULL,
    [BATCH_RUN_DT]       DATETIME     NOT NULL,
    [EXCL_ID]            INT          NULL,
    [CLAIM_TYPE]         CHAR (1)     NULL,
    [OPERATIONAL_MARKET] VARCHAR (2)  NULL
);

