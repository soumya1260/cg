﻿CREATE TABLE [dbo].[SourceDataDim] (
    [SourceDataKey] INT              NOT NULL,
    [SourceDesc]    VARCHAR (350)    NOT NULL,
    [Active]        BIT              NOT NULL,
    [Deleted]       BIT              NOT NULL,
    [LoadDateKey]   INT              NOT NULL,
    [EnterpriseID]  UNIQUEIDENTIFIER NOT NULL
);


GO
CREATE NONCLUSTERED INDEX [NIX_SourceDataDim_SourceDataKey_Inc_SourceDesc]
    ON [dbo].[SourceDataDim]([SourceDataKey] ASC)
    INCLUDE([SourceDesc]);


GO
CREATE NONCLUSTERED INDEX [idx_SOURCEDATAKEY]
    ON [dbo].[SourceDataDim]([SourceDataKey] ASC);

