﻿CREATE TABLE [dbo].[ANES_2018] (
    [ANES_CODE] VARCHAR (5) NULL,
    [BASE_UNIT] INT         NULL
);

