﻿CREATE TABLE [dbo].[ELIG_CLM] (
    [ClaimID] VARCHAR (20) NULL
);

