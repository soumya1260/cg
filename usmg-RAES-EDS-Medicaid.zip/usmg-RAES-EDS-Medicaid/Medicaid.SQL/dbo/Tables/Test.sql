﻿CREATE TABLE [dbo].[Test] (
    [TestID] VARCHAR (10) NULL
);

