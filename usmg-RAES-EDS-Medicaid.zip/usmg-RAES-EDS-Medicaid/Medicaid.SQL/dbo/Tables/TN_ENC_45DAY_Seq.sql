﻿CREATE TABLE [dbo].[TN_ENC_45DAY_Seq] (
    [SequenceNo] INT DEFAULT ((0)) NULL
);

