﻿CREATE TABLE [dbo].[TNMedicaidResub] (
    [ClaimID] VARCHAR (50) NULL
);


GO
CREATE NONCLUSTERED INDEX [TNMedicaidResub_ClaimID]
    ON [dbo].[TNMedicaidResub]([ClaimID] ASC);

