﻿CREATE TABLE [dbo].[ClaimAgg] (
    [CLAIMID]                 VARCHAR (100) NULL,
    [SOURCEDATAKEY]           INT           NULL,
    [PREVIOUSCLAIMID]         VARCHAR (100) NULL,
    [MEMBERID]                VARCHAR (100) NULL,
    [SUBSCRIBERID]            VARCHAR (100) NULL,
    [PATIENTID]               VARCHAR (100) NULL,
    [MEMBERREGIONCODE]        VARCHAR (100) NULL,
    [PROVIDERREGIONCODE]      VARCHAR (100) NULL,
    [GROUPID]                 VARCHAR (100) NULL,
    [AUTHORIZATIONID]         VARCHAR (100) NULL,
    [PCPID]                   VARCHAR (100) NULL,
    [PAYTOVENDORORFAMILYFLAG] VARCHAR (100) NULL,
    [PAIDDATEKEY]             INT           NULL,
    [ADMISSIONDATEKEY]        INT           NULL,
    [DISCHARGEDATEKEY]        INT           NULL,
    [DATERECEIVEDKEY]         INT           NULL,
    [BEGINSERVICEDATEKEY]     INT           NULL,
    [ENDSERVICEDATEKEY]       INT           NULL,
    [DISPOSITIONCODE]         VARCHAR (100) NULL,
    [FORMTYPECODE]            VARCHAR (100) NULL,
    [CURRENTSTATUSCODE]       VARCHAR (100) NULL,
    [TYPECODE]                VARCHAR (100) NULL,
    [VISITSCOUNT]             INT           NULL,
    [REFERRINGPHYSICIANID]    VARCHAR (100) NULL,
    [ATTENDINGPHYSICIANID]    VARCHAR (100) NULL,
    [LOBCODE]                 VARCHAR (100) NULL,
    [DRGCODE]                 VARCHAR (100) NULL,
    [PROVIDERID]              VARCHAR (100) NULL,
    [PROVIDERNPI]             VARCHAR (100) NULL,
    [REQUESTEDAMT]            MONEY         NULL,
    [MAXFEEAMT]               MONEY         NULL,
    [ELIGIBLEFEEAMT]          MONEY         NULL,
    [COBAMT]                  MONEY         NULL,
    [DEDUCTIBLEAMT]           MONEY         NULL,
    [COPAYAMT]                MONEY         NULL,
    [COINSURANCEAMT]          MONEY         NULL,
    [WITHHOLDAMT]             MONEY         NULL,
    [PAIDAMT]                 MONEY         NULL,
    [COMPANYID]               VARCHAR (100) NULL,
    [BillTypeCode]            VARCHAR (3)   NULL,
    [MemberPaidAmt]           MONEY         NULL,
    [VendorID]                VARCHAR (20)  NULL,
    [VendorNPI]               VARCHAR (10)  NULL,
    [CheckNum]                VARCHAR (12)  NULL,
    [OriginalEntryDateKey]    INT           NULL,
    [LastUpdateDateKey]       INT           NULL,
    [LastUpdate]              DATETIME      NULL,
    [LoadDateKey]             INT           NULL,
    [CurrentMemberID]         VARCHAR (16)  NULL,
    [CurrentStatusCodeDesc]   VARCHAR (10)  NULL
);




GO
CREATE NONCLUSTERED INDEX [NIX_ClaimAgg_Submissions_1]
    ON [dbo].[ClaimAgg]([CURRENTSTATUSCODE] ASC, [PREVIOUSCLAIMID] ASC)
    INCLUDE([CLAIMID]);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimAgg_Submissions_2]
    ON [dbo].[ClaimAgg]([CLAIMID] ASC)
    INCLUDE([PAIDDATEKEY]);

