﻿CREATE TABLE [dbo].[EDS_AllExtractClaims] (
    [SOURCEDATAKEY] INT          NULL,
    [ClaimID]       VARCHAR (20) NULL
);

