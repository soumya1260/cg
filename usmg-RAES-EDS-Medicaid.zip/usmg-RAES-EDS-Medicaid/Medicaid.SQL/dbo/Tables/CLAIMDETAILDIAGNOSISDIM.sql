﻿CREATE TABLE [dbo].[CLAIMDETAILDIAGNOSISDIM] (
    [CLAIMID]                 VARCHAR (20)     NULL,
    [SOURCEDATAKEY]           INT              NULL,
    [CLAIMDETAILDIAGNOSISKEY] NUMERIC (18)     NULL,
    [CLAIMLINEID]             VARCHAR (5)      NULL,
    [DIAGNOSISCODE]           VARCHAR (10)     NULL,
    [SEQUENCE]                INT              NULL,
    [ACTIVE]                  BIT              NULL,
    [DELETED]                 BIT              NULL,
    [LOADDATEKEY]             INT              NULL,
    [ENTERPRISEID]            UNIQUEIDENTIFIER NULL,
    [DiagnosisCodeVersion]    CHAR (1)         NULL
);

