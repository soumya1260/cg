﻿CREATE TABLE [dbo].[ClaimStatusCodeDim] (
    [SOURCEDATAKEY]      INT              NULL,
    [CLAIMSTATUSCODEKEY] INT              NULL,
    [CLAIMSTATUSCODE]    VARCHAR (16)     NULL,
    [CLAIMSTATUSDESC]    VARCHAR (255)    NULL,
    [ACTIVE]             BIT              NULL,
    [DELETED]            BIT              NULL,
    [LOADDATEKEY]        INT              NULL,
    [ENTERPRISEID]       UNIQUEIDENTIFIER NULL
);

