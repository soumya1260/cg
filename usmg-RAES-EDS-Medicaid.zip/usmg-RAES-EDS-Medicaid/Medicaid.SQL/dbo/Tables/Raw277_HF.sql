﻿CREATE TABLE [dbo].[Raw277_HF] (
    [segnum]  INT           IDENTITY (1, 1) NOT NULL,
    [Segment] VARCHAR (MAX) NULL
);

