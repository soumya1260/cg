﻿CREATE TABLE [dbo].[OUTB_PROF_DETAIL_CCCR] (
    [CLAIM_ID]    CHAR (20) NULL,
    [CLAIMLINEID] CHAR (5)  NULL,
    [DGCD]        CHAR (10) NULL,
    [ROWNUM]      INT       NULL,
    [PARENT]      INT       NULL
);

