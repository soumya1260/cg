﻿CREATE TABLE [dbo].[OUTB_INST_CCCR] (
    [CLAIM_ID]   CHAR (20)   NULL,
    [DGCD]       CHAR (10)   NULL,
    [dgcd_count] INT         NULL,
    [POAIND]     VARCHAR (1) NULL,
    [ROWNUM]     INT         NULL
);


GO
CREATE CLUSTERED INDEX [ClusteredIndex-OUTB_INST_CCCR]
    ON [dbo].[OUTB_INST_CCCR]([CLAIM_ID] ASC, [DGCD] ASC, [ROWNUM] ASC);

