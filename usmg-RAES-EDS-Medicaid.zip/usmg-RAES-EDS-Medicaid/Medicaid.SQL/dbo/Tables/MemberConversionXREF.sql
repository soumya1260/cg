﻿CREATE TABLE [dbo].[MemberConversionXREF] (
    [SourceDataKey] INT          NULL,
    [MemberID]      VARCHAR (16) NULL,
    [OldMemberID]   VARCHAR (16) NULL
);

