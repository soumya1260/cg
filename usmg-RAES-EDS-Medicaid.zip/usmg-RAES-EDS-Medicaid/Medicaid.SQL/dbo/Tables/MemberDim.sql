﻿CREATE TABLE [dbo].[MemberDim] (
    [MemberKey]                         INT              NULL,
    [MemberID]                          VARCHAR (16)     NOT NULL,
    [MedicareID]                        VARCHAR (250)    NULL,
    [DOBDateKey]                        INT              NOT NULL,
    [BeginCoverageDateKey]              INT              NOT NULL,
    [RelationshipCode]                  CHAR (1)         NOT NULL,
    [CreditableCoverage]                VARCHAR (8)      NOT NULL,
    [COBFlag]                           CHAR (1)         NOT NULL,
    [EnrollmentStatusCode]              CHAR (1)         NOT NULL,
    [DependentStatusCode]               CHAR (1)         NOT NULL,
    [MedicareRevenueStatusCode]         VARCHAR (35)     NOT NULL,
    [LastName]                          VARCHAR (100)    NOT NULL,
    [FirstName]                         VARCHAR (100)    NOT NULL,
    [MiddleName]                        VARCHAR (30)     NOT NULL,
    [Gender]                            CHAR (1)         NOT NULL,
    [SSN]                               VARCHAR (9)      NOT NULL,
    [AddressLine1]                      VARCHAR (60)     NOT NULL,
    [AddressLine2]                      VARCHAR (250)    NULL,
    [AddressLine3]                      VARCHAR (40)     NOT NULL,
    [City]                              VARCHAR (30)     NOT NULL,
    [State]                             VARCHAR (2)      NOT NULL,
    [Zip]                               VARCHAR (11)     NOT NULL,
    [HomePhone]                         VARCHAR (20)     NOT NULL,
    [WorkPhone]                         VARCHAR (20)     NOT NULL,
    [CurrentRegionCode]                 VARCHAR (10)     NULL,
    [CurrentRegionEnrollmentDateKey]    INT              NOT NULL,
    [CurrentPhysicianID]                VARCHAR (15)     NOT NULL,
    [CurrentPhysicianEnrollmentDateKey] INT              NOT NULL,
    [SourceDataKey]                     INT              NOT NULL,
    [Active]                            BIT              NOT NULL,
    [Deleted]                           BIT              NOT NULL,
    [LoadDateKey]                       INT              NOT NULL,
    [EnterpriseID]                      UNIQUEIDENTIFIER NOT NULL,
    [MDQOLoadDate]                      DATETIME         CONSTRAINT [DF_MemberDim_MDQOLoadDate] DEFAULT (getdate()) NULL,
    [MedicaidID]                        VARCHAR (20)     NULL,
    [MemberDimID]                       INT              IDENTITY (1, 1) NOT NULL,
    CONSTRAINT [PK_MemberDim] PRIMARY KEY CLUSTERED ([MemberDimID] ASC)
);


GO
CREATE NONCLUSTERED INDEX [IDX_Deleted_MedicareID]
    ON [dbo].[MemberDim]([Deleted] ASC, [MedicareID] ASC)
    INCLUDE([MemberID], [LoadDateKey]);


GO
CREATE NONCLUSTERED INDEX [IDX_Medicare]
    ON [dbo].[MemberDim]([MedicareID] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_MemberID]
    ON [dbo].[MemberDim]([MemberID] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_SourceDataKey]
    ON [dbo].[MemberDim]([SourceDataKey] ASC)
    INCLUDE([MemberID]);

