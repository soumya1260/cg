﻿CREATE TABLE [dbo].[EligibleforSubmission_Archive] (
    [EligibleForSubmissionID] INT           NULL,
    [Claimid]                 VARCHAR (50)  NULL,
    [MedicaidID]              VARCHAR (20)  NULL,
    [MemberID]                VARCHAR (16)  NULL,
    [SSN]                     VARCHAR (9)   NULL,
    [ADJ_Date]                SMALLDATETIME NULL,
    [Claim_Type]              CHAR (1)      NULL,
    [Submission_Type]         VARCHAR (15)  NULL,
    [SubmissionStatus]        CHAR (1)      NULL,
    [InsertDate]              DATETIME      NULL,
    [LastUpdateDate]          DATETIME      DEFAULT (getdate()) NOT NULL,
    [ADJ_SEQ]                 INT           NULL,
    [ArchivedDate]            DATETIME      DEFAULT (getdate()) NOT NULL,
    [RegulatoryMarket]        VARCHAR (4)   NULL
);



