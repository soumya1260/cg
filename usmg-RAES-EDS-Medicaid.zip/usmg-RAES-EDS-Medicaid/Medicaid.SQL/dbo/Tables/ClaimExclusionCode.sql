﻿CREATE TABLE [dbo].[ClaimExclusionCode] (
    [EXCL_ID]            INT           NOT NULL,
    [EXCLUSION_DESC]     VARCHAR (256) NOT NULL,
    [SOURCEDATAKEY]      INT           NOT NULL,
    [SOURCEDESC]         VARCHAR (350) NOT NULL,
    [OPERATIONAL_MARKET] VARCHAR (2)   NULL
);

