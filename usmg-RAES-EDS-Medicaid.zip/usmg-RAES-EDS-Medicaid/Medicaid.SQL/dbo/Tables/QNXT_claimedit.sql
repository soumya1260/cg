﻿CREATE TABLE [dbo].[QNXT_claimedit] (
    [claimid]              CHAR (15)     NOT NULL,
    [claimline]            INT           NOT NULL,
    [ruleid]               CHAR (15)     NOT NULL,
    [status]               CHAR (10)     NOT NULL,
    [reason]               CHAR (15)     NOT NULL,
    [clearby]              CHAR (15)     NULL,
    [cleardate]            SMALLDATETIME NULL,
    [lastupdate]           DATETIME      NULL,
    [updateid]             VARCHAR (120) NULL,
    [state]                CHAR (10)     NULL,
    [createid]             VARCHAR (120) NULL,
    [createdate]           DATETIME      NULL,
    [eobid]                CHAR (15)     NULL,
    [editxml]              TEXT          NULL,
    [overrideroleid]       CHAR (15)     NULL,
    [sequence]             INT           NULL,
    [benesequence]         INT           NULL,
    [contractid]           CHAR (15)     NULL,
    [dfmsgcode]            CHAR (15)     NULL,
    [dfmsgsrce]            CHAR (3)      NULL,
    [reject]               CHAR (1)      NULL,
    [eoboverridemessage]   VARCHAR (MAX) NULL,
    [remitoverridemessage] VARCHAR (MAX) NULL,
    [SfMsgCode]            CHAR (15)     NULL,
    [SfMsgSrce]            CHAR (3)      NULL,
    [IsMemResp]            CHAR (1)      NULL
);


GO
CREATE NONCLUSTERED INDEX [IDX_QNXT_claimedit_01]
    ON [dbo].[QNXT_claimedit]([claimid] ASC);

