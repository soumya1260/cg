﻿CREATE TABLE [dbo].[EDSCLAIMSUBMISSIONDATE] (
    [ClaimID]           VARCHAR (50) NULL,
    [SubmissionStatus]  VARCHAR (15) NULL,
    [SOURCEDATAKEY]     VARCHAR (2)  NULL,
    [CMSICN]            VARCHAR (15) NULL,
    [EDSSubmissionDate] VARCHAR (8)  NULL
);

