﻿CREATE TABLE [dbo].[MedicaidJobIDConfig] (
    [JobID]            VARCHAR (50) NULL,
    [Sender_ID]        VARCHAR (50) NULL,
    [Receiver_ID]      VARCHAR (50) NULL,
    [ContractID]       VARCHAR (50) NULL,
    [DestinationID]    VARCHAR (50) NULL,
    [LOB]              VARCHAR (50) NULL,
    [SOURCEDATAKEY]    VARCHAR (50) NULL,
    [CLAIMTYPE]        VARCHAR (50) NULL,
    [PRODUCTNODE]      VARCHAR (50) NULL,
    [IsAdjustmentFlag] VARCHAR (50) NULL,
    [FILE_TYPE]        VARCHAR (50) NULL,
    [VERSION]          VARCHAR (50) NULL,
    [DenialFlag]       VARCHAR (50) NULL,
    [ClaimIDprefix]    VARCHAR (50) NULL,
    [ClaimIDSufix]     VARCHAR (50) NULL,
    [Fileshare]        VARCHAR (50) NULL
);

