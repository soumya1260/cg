﻿CREATE TABLE [dbo].[ClaimICD9ProcedureDim] (
    [ClaimICD9ProcedureKey] BIGINT           NULL,
    [ClaimID]               VARCHAR (20)     NOT NULL,
    [ICD9Code]              VARCHAR (9)      NOT NULL,
    [ProcedureTypeCode]     VARCHAR (2)      NULL,
    [Sequence]              CHAR (2)         NOT NULL,
    [DiagnosisCodeVersion]  VARCHAR (1)      NULL,
    [LastUpdateDateKey]     INT              NULL,
    [SourceDataKey]         INT              NOT NULL,
    [Active]                BIT              NOT NULL,
    [Deleted]               BIT              NOT NULL,
    [LoadDateKey]           INT              NOT NULL,
    [EnterpriseID]          UNIQUEIDENTIFIER NOT NULL,
    [ProcedureDate]         INT              NULL
);

