﻿CREATE TABLE [dbo].[OUTB_PROF_CCCR] (
    [CLAIM_ID]   CHAR (20)   NULL,
    [DGCD]       CHAR (10)   NULL,
    [dgcd_count] INT         NULL,
    [POAIND]     VARCHAR (1) NULL,
    [ROWNUM]     INT         NULL
);

