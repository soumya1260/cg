﻿



CREATE FUNCTION [dbo].[Countrecorddelimter]
 (     @searchString nvarchar(max),     @searchTerm nvarchar(max) ) RETURNS INT 
AS 
BEGIN    
 return (LEN(@searchString)-LEN(REPLACE(@searchString,@searchTerm,'')))/LEN(@searchTerm) 
END 

