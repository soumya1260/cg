﻿EXECUTE sp_addextendedproperty @name = N'APP_CONTACT', @value = N'SQLServer@Cigna.com';


GO
EXECUTE sp_addextendedproperty @name = N'APP_NA', @value = N'SQL Server';


GO
EXECUTE sp_addextendedproperty @name = N'DB_ID', @value = N'16195';


GO
EXECUTE sp_addextendedproperty @name = N'EAP_ID', @value = N'265.1268';


GO
EXECUTE sp_addextendedproperty @name = N'HPSM_CI', @value = N'CI0000019158';

