﻿CREATE TABLE [staging].[TN_ENC_45DAY] (
    [CLAIM_ID]              VARCHAR (20)   NULL,
    [CLAIM_TYPE]            VARCHAR (1)    NULL,
    [TradingPartnerID]      VARCHAR (1000) NULL,
    [Encounter_Status]      VARCHAR (500)  NULL,
    [EncDispositionCaption] VARCHAR (500)  NULL,
    [TransTypeCaption]      VARCHAR (500)  NULL,
    [ExternalStatus999]     VARCHAR (500)  NULL,
    [AckTransFile999]       VARCHAR (500)  NULL,
    [FILEID]                CHAR (50)      NULL,
    [FILEDATE]              VARCHAR (14)   NULL,
    [Aging_Days]            INT            NULL,
    [CSV_SubmitDate]        DATETIME       NULL,
    [Reponse_Errortype]     VARCHAR (50)   NULL,
    [Response_ErrorCode]    VARCHAR (50)   NULL,
    [Response_ErrorDesc]    VARCHAR (500)  NULL,
    [Response_Loaddate]     DATETIME       NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-staging.TN_ENC_45DAY]
    ON [staging].[TN_ENC_45DAY]([CLAIM_ID] ASC, [CLAIM_TYPE] ASC);

