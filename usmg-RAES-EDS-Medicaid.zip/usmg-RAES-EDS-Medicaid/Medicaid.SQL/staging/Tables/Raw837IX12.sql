﻿
CREATE TABLE [staging].[Raw837IX12](
	[segnum] [int] IDENTITY(1,1) NOT NULL,
	[ComFile] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

