﻿CREATE TABLE [staging].[TN_ENC_45DAY_Reject_Hold] (
    [segnum]  INT           IDENTITY (1, 1) NOT NULL,
    [segment] VARCHAR (500) NULL,
    PRIMARY KEY CLUSTERED ([segnum] ASC)
);

