﻿
CREATE TABLE [staging].[Medicaid_Recon_837I_Header](
	[IsaSenderID] [varchar](20) NULL,
	[IsaReceiverId] [varchar](20) NULL,
	[IsaControlId] [varchar](20) NULL,
	[GsSenderId] [varchar](20) NULL,
	[GsReceiverId] [varchar](20) NULL,
	[GSControlId] [varchar](20) NULL,
	[STControlId] [varchar](20) NULL,
	[GEControlNum] [varchar](20) NULL,
	[IEAControlNum] [varchar](20) NULL,
	[TradingPartnerID] [varchar](60) NULL,
	[ClaimId] [varchar](20) NULL,
	[ClaimAmt] [varchar](10) NULL,
	[BatchID] [varchar](10) NULL,
	[TPName] [varchar](60) NULL,
	[TPEINId] [varchar](80) NULL,
	[MedicaidName] [varchar](60) NULL,
	[MedicaidNumber] [varchar](80) NULL,
	[TaxonomyCode] [varchar](10) NULL,
	[BillingProvName] [varchar](60) NULL,
	[BillingProvNPI] [varchar](80) NULL,
	[BillingProvAddress] [varchar](60) NULL,
	[BillingProvCity] [varchar](60) NULL,
	[BillingProvState] [varchar](60) NULL,
	[BillingProvZip] [varchar](9) NULL,
	[BillingProvEIN] [varchar](20) NULL,
	[MemberLastName] [varchar](60) NULL,
	[MemberFirstName] [varchar](60) NULL,
	[MemberMedicaidID] [varchar](80) NULL,
	[PrimaryPayerName] [varchar](60) NULL,
	[PrimaryPayerID] [varchar](60) NULL,
	[SecondaryPayerName] [varchar](60) NULL,
	[SecondaryPayerID] [varchar](60) NULL,
	[FacilityType] [varchar](10) NULL,
	[ClaimFrequencyType] [varchar](20) NULL,
	[StatementDateQual] [varchar](20) NULL,
	[StatementDateBegin] [varchar](20) NULL,
	[StatementDateEnd] [varchar](20) NULL,
	[ContractAmtQual] [varchar](10) NULL,
	[ContractAmt] [varchar](10) NULL,
	[MediPassRefNum9A] [varchar](20) NULL,
	[RefClaimNumD9] [varchar](20) NULL,
	[MCOReceiptDate] [varchar](8) NULL,
	[PrimaryDiagCode] [varchar](10) NULL,
	[ReasonForVisit] [varchar](10) NULL,
	[AttendingProvTaxonomyCode] [varchar](20) NULL,
	[PayerAmtPaid] [varchar](10) NULL,
	[AttProviderFirstName] [varchar](60) NULL,
	[AttProviderLastName] [varchar](60) NULL,
	[AttProviderCode] [varchar](60) NULL,
	[LoadDate] [datetime] NULL,
	[FName] [varchar](255) NULL
) ON [PRIMARY]
GO



/****** Object:  Index [NonClusteredIndex-20240927-105222]    Script Date: 12/3/2024 10:33:02 AM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20240927-105222] ON [staging].[Medicaid_Recon_837I_Header]
(
	[IsaSenderID] ASC,
	[IsaReceiverId] ASC,
	[IsaControlId] ASC,
	[GsSenderId] ASC,
	[GsReceiverId] ASC,
	[GSControlId] ASC,
	[STControlId] ASC,
	[GEControlNum] ASC,
	[IEAControlNum] ASC,
	[TradingPartnerID] ASC,
	[ClaimId] ASC,
	[LoadDate] ASC,
	[FName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO

