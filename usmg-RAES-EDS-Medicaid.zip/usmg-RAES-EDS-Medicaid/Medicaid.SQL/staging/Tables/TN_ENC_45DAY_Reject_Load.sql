﻿CREATE TABLE [staging].[TN_ENC_45DAY_Reject_Load] (
    [CLAIM_ID]           VARCHAR (20)  NULL,
    [Reponse_Errortype]  VARCHAR (50)  NULL,
    [Response_ErrorCode] VARCHAR (50)  NULL,
    [Response_ErrorDesc] VARCHAR (500) NULL,
    [Response_Loaddate]  DATETIME      NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-staging.TN_ENC_45DAY_Reject_Load]
    ON [staging].[TN_ENC_45DAY_Reject_Load]([CLAIM_ID] ASC, [Reponse_Errortype] ASC, [Response_ErrorCode] ASC, [Response_ErrorDesc] ASC, [Response_Loaddate] ASC);

