﻿CREATE TABLE [staging].[OUTB_CLAIM_STATUS] (
    [CLAIM_ID]                    VARCHAR (500)  NULL,
    [CMS_ICN]                     VARCHAR (500)  NULL,
    [CLMSTAT_STATUS]              VARCHAR (500)  NULL,
    [LAST_UPD_DATE]               DATETIME       NULL,
    [Sourcedatakey]               VARCHAR (500)  NULL,
    [FileID]                      VARCHAR (8000) NULL,
    [STAT_REJ_REA_ID]             VARCHAR (500)  NULL,
    [REJ_REA_MSG]                 VARCHAR (3000) NULL,
    [TradingPartnerID]            VARCHAR (1000) NULL,
    [SenderIdentifier]            VARCHAR (500)  NULL,
    [ReceiverIdentifier]          VARCHAR (500)  NULL,
    [837FileName]                 VARCHAR (8000) NULL,
    [EncountersStatus]            VARCHAR (500)  NULL,
    [EncDispositionCaption]       VARCHAR (500)  NULL,
    [TransTypeCaption]            VARCHAR (500)  NULL,
    [ChannelStatus]               VARCHAR (500)  NULL,
    [ExternalStatus999]           VARCHAR (500)  NULL,
    [AckTransFile999]             VARCHAR (500)  NULL,
    [ExternalStatus277]           VARCHAR (500)  NULL,
    [FileName277]                 VARCHAR (8000) NULL,
    [Transactiondate277]          VARCHAR (500)  NULL,
    [Acceptedextclmcontrolnumber] VARCHAR (250)  NULL,
    [Rejectedextclmcontrolnumber] VARCHAR (250)  NULL
);



