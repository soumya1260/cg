$environment = $OctopusParameters['Octopus.Environment.Name']

$paramsFile = "Project.$environment.params"
$IsPacFiles = Get-ChildItem -Recurse -Path $DeployedPath | Where-Object { $_.Extension.ToLower() -eq ".ispac" }

if (test-path $paramsFile) {

  if (test-path "Project.params") {
    Remove-Item "Project.params" -Force -Confirm:$false -ErrorAction Ignore
  }
  
  #print message
  Write-Host "Copy $paramsFile into ispac."
  
  #rename Project.params file for deploy enviornment
  Rename-Item $paramsFile "Project.params"
  
  foreach ($IsPacFile in $IsPacFiles) {

      #$ispac = Get-ChildItem -Name -Filter *.ispac | Select-Object -f 1
      #$ispac = [System.IO.File]::ReadAllBytes($IsPacFile.Name)
      $ispac = $IsPacFile.Name

      Write-Host "File $ispac"      

      Rename-Item $ispac "$ispac.zip"

      Compress-Archive -update Project.params "$ispac.zip"

      Rename-Item "$ispac.zip" $ispac
    }
}

# Start-Sleep -Seconds 30 