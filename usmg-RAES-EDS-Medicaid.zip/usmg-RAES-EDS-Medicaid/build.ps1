param ($buildSql = 1, $buildSSIS = 1, $configuration = 'Release')

if (Test-Path -Path variable-overrides.ps1) { 
    Write-Host "Importing variable-overrides.ps1" -ForegroundColor DarkBlue -BackgroundColor White
    . .\variable-overrides.ps1
}

Write-Host "Current UserName:  $env:UserName" -ForegroundColor DarkBlue -BackgroundColor White
Write-Host "Current UserDomain:  $env:UserDomain" -ForegroundColor DarkBlue -BackgroundColor White
Write-Host "Current ComputerName:  $env:ComputerName" -ForegroundColor DarkBlue -BackgroundColor White

if (Test-Path -Path build-assets/RAES-Build-Assets/README.md) { 
    Write-Host "Pulling build-assets/RAES-Build-Assets" -ForegroundColor DarkBlue -BackgroundColor White
    Push-Location build-assets/RAES-Build-Assets
    git pull
    Pop-Location
}
else {
    Write-Host "Cloning build-assets/RAES-Build-Assets" -ForegroundColor DarkBlue -BackgroundColor White
    Push-Location build-assets
    git clone git@github.sys.cigna.com:cigna/RAES-Build-Assets.git
    Pop-Location
}

if (Test-Path -Path build-assets/RAES-Build-Assets/publish.ps1) { 
    Write-Host "Importing from publish.ps1" -ForegroundColor DarkBlue -BackgroundColor White
    . .\build-assets/RAES-Build-Assets\publish.ps1
}
else {
    Write-Host "Could not find publish.ps1 file." -ForegroundColor DarkRed
    return;
}

$pathToDeployments = "$PSScriptRoot\builds"
$currentBranch = git rev-parse --symbolic-full-name HEAD
$releaseInfo = Get-VersionFromBranch $currentBranch # Get-VersionFromBranch is defined in jenkins.ps1

$pathToDeployments = if ([string]::IsNullOrEmpty($pathToDeployments)) { "$PSScriptRoot\build" } else { $pathToDeployments }
$pathToEnv = "$pathToDeployments\$($releaseInfo.Name)"
$pathToSqlOutput = "$pathToEnv\sql"
$pathToSSISOutput = "$pathToEnv\ssis"

Write-Host "Publising to: $pathToDeployments" -ForegroundColor DarkBlue -BackgroundColor White

Remove-Item $pathToEnv -Recurse -Force -Confirm:$false -ErrorAction Ignore

#
#     BUILD SQL
#
if ($buildSql -ne 0) {
    write-host "Building SQL Scripts for branch: $branchName"

    Publish-DacPack $pathToSqlOutput "$PSScriptRoot/Medicaid.SQL/Medicaid.SQL.sqlproj" "$PSScriptRoot/Medicaid.SQL/bin/$configuration/Medicaid.SQL.dacpac" "$PSScriptRoot/Medicaid.SQL/Medicaid.SQL.publish.xml"
}


#
#     BUILD SSIS
#
if ($buildSSIS -ne 0) {
    write-host "Building SSIS ISPAC for branch: $branchName"

    Publish-SSIS $pathToSSISOutput $false "$PSScriptRoot/MedicaidTradingPartnerLoad"    
}

write-host "Finished.  Your files are here:  $pathToEnv"
