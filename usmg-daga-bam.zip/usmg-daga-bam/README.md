[![Build Status](https://w2-jenkins.sys.cigna.com/buildStatus/icon?job=HEALTHSPRING/CHSDEVOPS/GBS-DigitalApps/BAMbuild)](https://w2-jenkins.sys.cigna.com/job/HEALTHSPRING/job/CHSDEVOPS/job/GBS-DigitalApps/job/BAMbuild/) [![Quality Gate Status](https://sonarqube.sys.cigna.com/api/project_badges/measure?project=com.cigna.CHS.DigiApps.BAM&metric=alert_status)](https://sonarqube.sys.cigna.com/dashboard?id=com.cigna.CHS.DigiApps.BAM)
# daga-bam 
# BAM!  A Broker API for MRDE
###### _"We were hoping for a richer API... but it's broker."_

BAM! is a small suite of applications supporting Cigna for Brokers.  The suite currently consists of:
* A [REST API](#bam-rest-api) tailored to Cigna for Brokers
* A [scheduler](#bam-scheduler) with tasks to support back-end functions of Cigna for Brokers

## BAM! REST API

BAM! supplies a REST-ish[^1] API that connects broker information housed in
MRDE databases to the Cigna for Brokers Dashboard.

The API currently supports two calls:

* GetBrokerRequestsForInformation()
* GetBrokerNotifications()

The basics of these calls are described below, but full 
documentation and code generation are available from our 
[Integration and Test Swagger site](https://INT-DigitalAppsBAM.silver.com/swagger).

The original API requirements can be found [here](https://confluence.sys.cigna.com/pages/viewpage.action?spaceKey=DS&title=MA+Data+API+Requirements). 


### GetBrokerRequestsForInformation()
This API call returns a list of "RFIs" -- which are actually 
call-outs to member applications that have missing data.

Example request:
```url
curl -X 'GET' \
  'https://hostname/bam/api/v1.0/brokers/rfi?producerCode=487311' \
  -H 'accept: text/plain' \
  -H 'service_reference_id: 254-sdfg2345-90870' \
  -H 'suppress_response_code: true' \
  -H 'Authorization: Bearer <big hairy monster JWT>'
```

Example response:
```json
{
  "rfis": [
    {
      "memberName": "REGINALD PERRY",
      "medicareId": "XXXXXXXXXXX"
      "dueDate": "00/01/0001",
      "reasonCode": "",
      "salesForceId": "a0B1U00000B8mZPUAZ"
    },
    {
      "memberName": "DOUGLAS SHIPMAN",
      "medicareId": "XXXXXXXXXXX",
      "dueDate": "00/01/0001",
      "reasonCode": "",
      "salesForceId": "a0B1U00000B9PSvUAN"
    }
  ],
  "metadata": {
    "serviceReferenceId": "254-sdfg2345-90870",
    "outcome": {
      "statusCode": 200,
      "type": "OK",
      "message": "Successful",
      "code": 0,
      "additionalDetails": []
    }
  }
}
```

### GetBrokerNotifications()
This method returns two lists of information:

* A list of the broker's expiring licenses;
* A list of appointment contracts showing the states where the contracts are valid.

Example request:
```curl
curl -X 'GET' \
  'https://hostname/bam/api/v1.0/brokers/notifications?producerCode=150861' \
  -H 'accept: text/plain' \
  -H 'service_reference_id: afds876afds876-987asdf-oiu87' \
  -H 'suppress_response_code: true' \
  -H 'Authorization: Bearer <big hairy monster JWT>'
```


Example response:
```json
{
  "notifications": {
    "licenses": [
      {
        "stateCode": "AL",
        "licenseNumber": "150861_AL_20070412",
        "startDate": "04/12/2007",
        "endDate": "06/30/2022",
        "active": true
      },
      {
        "stateCode": "AR",
        "licenseNumber": "150861_AR_20051205",
        "startDate": "12/05/2005",
        "endDate": "06/30/2022",
        "active": true
      },
      {
        "stateCode": "CO",
        "licenseNumber": "150861_CO_20210217",
        "startDate": "02/17/2021",
        "endDate": "06/30/2022",
        "active": true
      }
    ],
    "acls": [
      {
        "status": "",
        "aclNotifications": [
          {
            "year": "2022",
            "stateCode": "AK",
            "productCodes": [
              "PDP"
            ]
          },
          {
            "year": "2022",
            "stateCode": "AZ",
            "productCodes": [
              "MAPD",
              "PDP"
            ]
          }
        ]
      },
      {
        "status": "Ready to Sell",
        "aclNotifications": [
          {
            "year": "2022",
            "stateCode": "AL",
            "productCodes": [
              "MAPD",
              "PDP"
            ]
          },
          {
            "year": "2022",
            "stateCode": "AR",
            "productCodes": [
              "MAPD",
              "PDP"
            ]
          },
          {
            "year": "2022",
            "stateCode": "FL",
            "productCodes": [
              "MAPD",
              "PDP"
            ]
          }
        ]
      }
    ]
  },
  "metadata": {
    "serviceReferenceId": "afds876afds876-987asdf-oiu87",
    "outcome": {
      "statusCode": 200,
      "type": "OK",
      "message": "Successful",
      "code": 0,
      "additionalDetails": []
    }
  }
}
```

## BAM! Scheduler

The BAM! Scheduler is built off of Don Perkins' Cigna.TaskScheduling library.  It currently is configured with two tasks that collect
broker compensation files into ZIP and manifest files on a weekly basis.

## Why "BAM!"?
The lie is that BAM stands for "Broker API for MRDE".

The truth is that we just wanted to have another monosyllabic onomatopoeia word to name an application suite, similar to how THUD! was named.

[^1]: We say "REST-ish" because the interface doesn't strictly
adhere to the REST resource pattern.
