﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Controllers;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Repositories;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Diagnostics.CodeAnalysis;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Tests.Unit
{
    [ExcludeFromCodeCoverage]  // Tests.  Not production code.
    public class DiagnosticsControllerTests
    {
        [Fact]
        public async Task Ping_ReturnsExpectedResultInNonProductionEnvironment()
        {
            var mockEnvironment = new Mock<IWebHostEnvironment>();
            mockEnvironment.SetupGet(env => env.EnvironmentName).Returns("DEV");
            var controller = new DiagnosticsController(mockEnvironment.Object, new FakeBrokerDataRepository());
            
            ActionResult<PingResponse> result = await controller.Ping();
            
            Assert.NotNull(result?.Value);
            Assert.Equal("DEV", result!.Value!.Environment);
            Assert.Equal(System.Net.Dns.GetHostName(), result.Value.HostName);
            Assert.Equal("PASSED", result.Value.SelfTestResult);
        }

        [Fact]
        public async Task Ping_OmitsHostNameInProductionEnvironment()
        {
            var mockEnvironment = new Mock<IWebHostEnvironment>();
            mockEnvironment.SetupGet(env => env.EnvironmentName).Returns("PROD");
            var controller = new DiagnosticsController(mockEnvironment.Object, new FakeBrokerDataRepository());
            
            ActionResult<PingResponse> result = await controller.Ping();
            
            Assert.NotNull(result?.Value);
            Assert.Equal("PROD", result!.Value!.Environment);
            Assert.Null(result.Value.HostName);
            Assert.Equal("PASSED", result.Value.SelfTestResult);
        }
    }
}
