using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Controllers;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Repositories;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Moq;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Tests.Unit
{
    [ExcludeFromCodeCoverage]  // Tests.  Not production code.

    public class BrokersControllerTests
    {
        private readonly BrokersController _controller;
        private static readonly Regex DateFormatRegex = new(@"\d{2}/\d{2}/\d{4}", RegexOptions.Compiled | RegexOptions.CultureInvariant);

        public BrokersControllerTests()
        {
            _controller = GetBrokersControllerWithFakeRepository();
            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext()
            };
        }

        #region GetBrokerRequestForInformation() tests

        [Fact]
        public async Task GetBrokerRequestsForInformation_Returns500WhenExceptionIsThrownFromRepository()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("EXCEPTION", useMetadataResponse: false);
            var result = apiResult.Result as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal(500, result!.StatusCode);
        }

        [Fact]
        public async Task GetBrokerRequestsForInformation_Returns500InMetadataWhenExceptionIsThrownFromRepositoryAndMetadataOptionIsSelected()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("EXCEPTION", useMetadataResponse: true);

            Assert.NotNull(apiResult);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result?.Value as ApiResponse;
            Assert.NotNull(response);

            Assert.Equal(500, response?.ApiMetadata?.HttpOutcome.StatusCode);
        }

        [Fact]
        public async Task GetBrokerRequestsForInformation_ErrorMetadataFieldsAreProperlyPopulatedWhenExceptionIsThrownFromRepositoryAndMetadataOptionIsSelected()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("EXCEPTION", useMetadataResponse: true);

            Assert.NotNull(apiResult);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result?.Value as ApiResponse;
            Assert.NotNull(response);

            Assert.Equal(500, response?.ApiMetadata?.HttpOutcome.StatusCode ?? 0);
            Assert.Equal(10002, response!.ApiMetadata!.HttpOutcome.ResultCode);
            Assert.Equal("Error while getting RFIs for producerCode 'EXCEPTION'.", response!.ApiMetadata!.HttpOutcome!.Message, StringComparer.InvariantCultureIgnoreCase);
            Assert.True(response!.ApiMetadata!.HttpOutcome!.AdditionalDetails!.Any());
            Assert.Equal("Really, really bad producer code! (Parameter 'producerCode')", response!.ApiMetadata!.HttpOutcome!.AdditionalDetails![0]!.Message, StringComparer.InvariantCultureIgnoreCase);
            Assert.Equal("ERROR", response!.ApiMetadata!.HttpOutcome!.AdditionalDetails![0]!.Severity, StringComparer.InvariantCultureIgnoreCase);
            Assert.Equal(-2147024809, response!.ApiMetadata!.HttpOutcome!.AdditionalDetails![0]!.Code);
            Assert.Equal("InternalServerError", response!.ApiMetadata!.HttpOutcome!.Type, StringComparer.InvariantCultureIgnoreCase);
        }

        [Fact]
        public async Task GetBrokerRequestsForInformation_Returns404WhenBadProducerCodeIsSupplied()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("777", useMetadataResponse: false);

            //
            // Note that we are expecting a StatusCodeResult and not an
            // ObjectResult since there is no response body.
            //
            var result = apiResult.Result as StatusCodeResult;

            Assert.NotNull(result);
            Assert.Equal(404, result!.StatusCode);
        }

        [Fact]
        public async Task GetBrokerRequestsForInformation_ReturnsMetadataAnd200IfOptionIsSelected()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("777", useMetadataResponse: true);

            Assert.NotNull(apiResult);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result?.Value as ApiResponse;
            Assert.NotNull(response);


            Assert.Equal(200, result!.StatusCode);
        }

        [Fact]
        public async Task GetBrokerRequestsForInformation_ReturnsMetadataAnd404InMetadataIfOptionIsSelected()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("777", useMetadataResponse: true);

            Assert.NotNull(apiResult);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result?.Value as ApiResponse;
            Assert.NotNull(response);

            Assert.Equal(404, response?.ApiMetadata?.HttpOutcome.StatusCode);
        }

        [Fact]
        public async Task GetBrokerRequestsForInformation_Returns200WhenGoodProducerCodeIsSupplied()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal(200, result!.StatusCode);
        }

        [Fact]
        public async Task GetBrokerRequestsForInformation_Returns200AsMetadataWhenGoodProducerCodeIsSupplied()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("11111", useMetadataResponse: true);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as ApiResponse;
            Assert.Equal(200, response?.ApiMetadata?.HttpOutcome.StatusCode);
            Assert.Equal("OK", response?.ApiMetadata?.HttpOutcome.Type);
            Assert.Equal("Successful", response?.ApiMetadata?.HttpOutcome.Message);
        }

        [Fact]
        public async Task GetBrokerRequestForInformation_ContainsTwoRecordsForProducerCode11111()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as RequestForInformationResponse;
            Assert.NotNull(response);
            Assert.Equal(2, response?.RequestsForInformation?.Count);
        }

        [Fact]
        public async Task GetBrokerRequestForInformation_FirstRecordForProducerCode11111IsAlBundy()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as RequestForInformationResponse;
            Assert.NotNull(response);
            Assert.Equal(
                "AL BUNDY",
                response?.RequestsForInformation?[0].MemberName,
                StringComparer.InvariantCultureIgnoreCase);
        }

        [Fact]
        public async Task GetBrokerRequestForInformation_FirstRecordForProducerCode11111HasMedicareId000000000()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as RequestForInformationResponse;
            Assert.NotNull(response);
            Assert.Equal(
                "000000000",
                response?.RequestsForInformation?[0].MedicareId);
        }

        [Fact]
        public async Task GetBrokerRequestForInformation_FirstRecordForProducerCode11111HasSalesForceIdThx1138()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as RequestForInformationResponse;
            Assert.NotNull(response);
            Assert.Equal(
                "THX1138",
                response?.RequestsForInformation?[0].SalesForceId,
                StringComparer.InvariantCultureIgnoreCase);
        }

        [Fact]
        public async Task GetBrokerRequestForInformation_FirstRecordForProducerCode11111HasReasonCodeOther()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as RequestForInformationResponse;
            Assert.NotNull(response);
            Assert.Equal(
                "OTHER",
                response?.RequestsForInformation?[0].ReasonCode,
                StringComparer.InvariantCultureIgnoreCase);
        }

        [Fact]
        public async Task GetBrokerRequestForInformation_FirstRecordForProducerCode11111HasEmptyDueDate()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as RequestForInformationResponse;
            Assert.NotNull(response);
            Assert.Empty(response!.RequestsForInformation![0]!.DueDateString);
        }

        [Fact]
        public async Task GetBrokerRequestForInformation_SecondRecordForProducerCode11111HasCorrectlyFormattedDate()
        {
            var apiResult = await _controller.GetBrokerRequestsForInformation("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as RequestForInformationResponse;
            Assert.NotNull(response);
            Assert.Matches(DateFormatRegex, response!.RequestsForInformation![1]!.DueDateString);
        }

        #endregion GetBrokerRequestForInformation() tests

        #region GetBrokerNotifications() tests

        [Fact]
        public async Task GetBrokerNotifications_Returns500WhenExceptionIsThrownFromRepository()
        {
            var apiResult = await _controller.GetBrokerNotifications("EXCEPTION", useMetadataResponse: false);
            var result = apiResult.Result as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal(500, result!.StatusCode);
        }

        [Fact]
        public async Task GetBrokerNotifications_Returns500InMetadataWhenExceptionIsThrownFromRepositoryAndMetadataOptionIsSelected()
        {
            var apiResult = await _controller.GetBrokerNotifications("EXCEPTION", useMetadataResponse: true);

            Assert.NotNull(apiResult);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result?.Value as ApiResponse;
            Assert.NotNull(response);

            Assert.Equal(500, response?.ApiMetadata?.HttpOutcome.StatusCode);
        }



        [Fact]
        public async Task GetBrokerNotifications_Returns404WhenBadProducerCodeIsSupplied()
        {
            var apiResult = await _controller.GetBrokerNotifications("777", useMetadataResponse: false);

            //
            // Note that we are expecting a StatusCodeResult and not an
            // ObjectResult since there is no response body.
            //
            var result = apiResult.Result as StatusCodeResult;

            Assert.NotNull(result);
            Assert.Equal(404, result!.StatusCode);
        }

        [Fact]
        public async Task GetBrokerNotifications_ReturnsMetadataAnd200IfOptionIsSelected()
        {
            var apiResult = await _controller.GetBrokerNotifications("777", useMetadataResponse: true);

            Assert.NotNull(apiResult);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result?.Value as ApiResponse;
            Assert.NotNull(response);


            Assert.Equal(200, result!.StatusCode);
        }

        [Fact]
        public async Task GetBrokerNotifications_CreatesServiceReferenceIdIfNotSupplied()
        {
            var apiResult = await _controller.GetBrokerNotifications("777", useMetadataResponse: true);

            Assert.NotNull(apiResult);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result?.Value as ApiResponse;
            Assert.NotNull(response);
            Assert.NotEmpty(response!.ApiMetadata!.ServiceReferenceId);
        }

        [Fact]
        public async Task GetBrokerNotifications_PreservesServiceReferenceIdIfSupplied()
        {
            string serviceReferenceId = Guid.NewGuid().ToString();
            var apiResult = await _controller.GetBrokerNotifications("777", useMetadataResponse: true, serviceReferenceId: serviceReferenceId);

            Assert.NotNull(apiResult);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result?.Value as ApiResponse;
            Assert.NotNull(response);
            Assert.Equal(serviceReferenceId, response!.ApiMetadata!.ServiceReferenceId, StringComparer.InvariantCultureIgnoreCase);
        }

        [Fact]
        public async Task GetBrokerNotifications_ReturnsMetadataAnd404InMetadataIfOptionIsSelected()
        {
            var apiResult = await _controller.GetBrokerNotifications("777", useMetadataResponse: true);

            Assert.NotNull(apiResult);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result?.Value as ApiResponse;
            Assert.NotNull(response);

            Assert.Equal(404, response?.ApiMetadata?.HttpOutcome.StatusCode);
        }

        [Fact]
        public async Task GetBrokerNotifications_Returns200WhenGoodProducerCodeIsSupplied()
        {
            var apiResult = await _controller.GetBrokerNotifications("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal(200, result!.StatusCode);
        }

        [Fact]
        public async Task GetBrokerNotifications_ApiMetadataIsNullIfMetadataIsNotSelected()
        {
            var apiResult = await _controller.GetBrokerNotifications("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as NotificationResponse;
            Assert.NotNull(response);
            Assert.Null(response!.ApiMetadata);
        }

        [Fact]
        public async Task GetBrokerNotifications_ReturnsOneLicenseNotificationForProducerCode11111()
        {
            var apiResult = await _controller.GetBrokerNotifications("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as NotificationResponse;
            Assert.NotNull(response);
            Assert.Equal(1, response!.Notifications?.Licenses?.Count);
        }

        [Fact]
        public async Task GetBrokerNotifications_LicenseValuesMatchExpectationsForProducerCode11111()
        {
            var apiResult = await _controller.GetBrokerNotifications("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as NotificationResponse;
            Assert.NotNull(response);
            Assert.True(response!.Notifications?.Licenses?[0]?.Active);
            Assert.Equal(new DateTime(2020, 1, 1), response!.Notifications!.Licenses![0]!.EffectiveDate);
            Assert.Equal(new DateTime(2022, 6, 1), response!.Notifications!.Licenses![0]!.ExpirationDate);
            Assert.Equal("12PARSECS", response!.Notifications!.Licenses![0]!.LicenseNumber, StringComparer.InvariantCultureIgnoreCase);
            Assert.Equal("TN", response!.Notifications!.Licenses![0]!.StateCode, StringComparer.InvariantCultureIgnoreCase);
        }

        [Fact]
        public async Task GetBrokerNotifications_LicenseEffectiveDateStringIsFormattedCorrectly()
        {
            var apiResult = await _controller.GetBrokerNotifications("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as NotificationResponse;
            Assert.NotNull(response);
            Assert.Matches(DateFormatRegex, response!.Notifications!.Licenses![0]!.EffectiveDateString);
        }

        [Fact]
        public async Task GetBrokerNotifications_LicenseExpirationStringIsFormattedCorrectly()
        {
            var apiResult = await _controller.GetBrokerNotifications("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as NotificationResponse;
            Assert.NotNull(response);
            Assert.Matches(DateFormatRegex, response!.Notifications!.Licenses![0]!.ExpirationDateString);
        }

        [Fact]
        public async Task GetBrokerNotifications_ReturnsTwoAclsForProducerCode11111()
        {
            var apiResult = await _controller.GetBrokerNotifications("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as NotificationResponse;
            Assert.NotNull(response);
            Assert.Equal(2, response!.Notifications?.AppointmentContractLicenses?.Count);
        }

        [Fact]
        public async Task GetBrokerNotifications_AclsMatchExpectedValuesForProducerCode11111()
        {
            var apiResult = await _controller.GetBrokerNotifications("11111", useMetadataResponse: false);

            var result = apiResult.Result as ObjectResult;
            Assert.NotNull(result);

            var response = result!.Value as NotificationResponse;
            Assert.NotNull(response);
            Assert.Empty(response!.Notifications?.AppointmentContractLicenses?[0]?.Status);
            Assert.Equal("Ready to sell", response!.Notifications!.AppointmentContractLicenses![1]?.Status);
            Assert.Equal(1, response!.Notifications!.AppointmentContractLicenses![1]!.AppointmentContractLicenses?.Count);
            Assert.Equal(2022, response!.Notifications!.AppointmentContractLicenses![1]!.AppointmentContractLicenses![0]!.EffectiveYear);
            Assert.Equal("2022", response!.Notifications!.AppointmentContractLicenses![1]!.AppointmentContractLicenses![0]!.YearString, StringComparer.InvariantCultureIgnoreCase);
            Assert.Equal("AL", response!.Notifications!.AppointmentContractLicenses![1]!.AppointmentContractLicenses![0]!.StateCode, StringComparer.InvariantCultureIgnoreCase);
            Assert.Equal(2, response!.Notifications!.AppointmentContractLicenses![1]!.AppointmentContractLicenses![0]!.ProductCodes?.Count);
            Assert.Equal("221BBAKER", response!.Notifications!.AppointmentContractLicenses![1]!.AppointmentContractLicenses![0]!.ProductCodes![0], StringComparer.InvariantCultureIgnoreCase);

        }


        #endregion GetBrokerNotifications() tests

        #region Constructor tests

        [Fact]
        public void BrokersControllerConstructor_ThrowsArgumentExceptionIfNoRepositoryIsSupplied()
        {
            Assert.Throws<ArgumentException>(() => new BrokersController(null!, null!));
        }

        #endregion Constructor tests

        #region Private support methods

        private static BrokersController GetBrokersControllerWithFakeRepository()
            => new(new FakeBrokerDataRepository(), new Mock<ILogger<BrokersController>>().Object);

        #endregion
    }
}