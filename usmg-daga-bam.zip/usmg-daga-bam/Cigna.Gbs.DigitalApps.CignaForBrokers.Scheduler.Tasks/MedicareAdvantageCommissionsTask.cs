﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Mail;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.CommissionObjects;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.Exceptions;
using Cigna.TaskScheduling.Domain;
using ClosedXML.Excel;
using CsvHelper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MoreLinq.Extensions;
using System.Diagnostics;
using System.Globalization;
using System.IO.Compression;
using System.Runtime.CompilerServices;
using System.Text;

// ReSharper disable ConvertToUsingDeclaration

[assembly: InternalsVisibleTo("Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.Tests.Unit")]
namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks
{
    public abstract class MedicareAdvantageCommissionsTask : TaskScheduling.Domain.Task
    {
        #region Abstract properties and methods

        public abstract DayOfWeek CompensationDay { get; }
        protected abstract string TaskName { get; }
        protected abstract string CommissionFolderPartialPath(DateTime date);

        #endregion Abstract properties and methods

        #region Injected dependencies

        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;
        private readonly IMailClient _mailClient;

        #endregion Injected dependencies

        #region Constants

        //
        // Miscellaneous constants
        //
        private const int CompensationStatementsBatchSize = 30_000;

        private const string VendorDemographicsSearchPattern = "HS_MA_COMM_VNDR-*.csv";
        private const string CommissionFileNamePattern = "*Cigna Medicare Commission*.xl*";
        private const string TriggerFileName = "trigger.ProducerCommissionsMA";

        //
        // Configuration keys
        //
        internal const string CommissionStatementsConfigurationKey = "MedicareAdvantageCommissionsTask:CommissionStatementsFilePath";
        internal const string VendorDemographicsConfigurationKey = "MedicareAdvantageCommissionsTask:VendorDemographicsFilePath";
        private const string ConnectDirectDeliveryPathConfigurationKey = "MedicareAdvantageCommissionsTask:ConnectDirectDeliveryPath";
        private const string UseConnectDirectConfigurationKey = "MedicareAdvantageCommissionsTask:UseConnectDirect";
        private const string ConnectDirectEndpointHostConfigurationKey = "MedicareAdvantageCommissionsTask:ConnectDirectEndpointHost";
        private const string ConnectDirectEndpointPathConfigurationKey = "MedicareAdvantageCommissionsTask:ConnectDirectEndpointPath";
        private const string ConnectDirectExecutablePathConfigurationKey = "MedicareAdvantageCommissionsTask:ConnectDirectExecutablePath";
        private const string ConnectDirectAuthenticationPathConfigurationKey = "MedicareAdvantageCommissionsTask:ConnectDirectAuthenticationPath";
        private const string ConnectDirectArchivePathConfigurationKey = "MedicareAdvantageCommissionsTask:ConnectDirectArchivePath";

        //
        // Commission statement worksheet references
        //
        private const string CurrentStatementWorksheetName = "Current Statement";
        private const string TotalPaymentsCellName = "J8";
        private const string PreviousBalanceCellName = "A8";
        private const string NewEarningsExpression = "SUM(C8,E8,G8)";

        #endregion Constants

        #region Dynamic path functions

        private static string ManifestFilePath(DateTime timestamp) => Path.Combine(Path.GetTempPath(), $"ProducerCommissions_MA_{timestamp:yyyyMMddHHmmssfff}.txt");
        internal static string WorkFolderPath(DateTime timestamp) => Path.Combine(Path.GetTempPath(), $"Compensation-{timestamp:yyyyMMddHHmmssfff}");
        private static string WorkFilePath(string workFolder, string sourceFileName) => Path.Combine(workFolder, Path.GetFileName(sourceFileName));
        private static string ZipFilePath(DateTime timestamp) => Path.Combine(Path.GetTempPath(), $"ProducerCommissions_MA_{timestamp:yyyyMMddHHmmssfff}.zip");

        #endregion Dynamic path functions

        #region Constructors

        /// <summary>
        /// Default constructor.  Used by the scheduler using Reflection.
        /// </summary>
        protected MedicareAdvantageCommissionsTask() : this(TaskConfigurationFactory.Instance)
        { }

        /// <summary>
        /// Injection constructor.  Used directly by unit/integration tests.  Used indirectly by the scheduler.
        /// </summary>
        /// <param name="factory"></param>
        protected MedicareAdvantageCommissionsTask(ITaskConfigurationFactory factory)
        {
            _logger = factory.GetLogger();
            _configuration = factory.GetConfigurationManager();
            _mailClient = factory.GetMailClient();
        }

        #endregion Constructors

        #region Public methods

        /// <inheritdoc />
        public override void Start()
        {
            CompletionStatus = TaskCompletionStatus.Succeeded;
            try
            {
                _logger.LogInformation("{task} started.", nameof(MedicareAdvantageCommissionsTask));

                Run();

                _logger.LogInformation(
                    "{task} completed with Completion status of {completionStatus}.",
                    nameof(MedicareAdvantageCommissionsTask),
                    CompletionStatus);
            }
            catch (Exception exception)
            {
                CompletionStatus = TaskCompletionStatus.Failed;
                _logger.LogCritical(exception, "Error executing task.");
                return;
            }

            if (StopCalled) CompletionStatus = TaskCompletionStatus.Stopped;
        }

        #endregion Public methods

        #region Internal (unit-testable) methods

        /// <summary>
        /// Delivers a single batch of compensation files to the P8Loader-monitored folder.
        /// </summary>
        /// <param name="compensationFiles">a list of files representing the batch to be processed</param>
        /// <param name="vendorDemographics">a database of vendor (broker) demographics</param>
        /// <param name="outputFolder">the delivery folder for processing by the P8Loader</param>
        /// <param name="timestamp">the timestamp to be inserted into all file artifacts for this batch</param>
        internal void DeliverCompensationBatch(
            List<string> compensationFiles,
            Dictionary<string, VendorDemographics> vendorDemographics,
            string outputFolder,
            DateTime timestamp)
        {
            //
            // Create the working folder.
            //
            string workFolder = WorkFolderPath(timestamp);
            try
            {
                Directory.CreateDirectory(workFolder);

                //
                // Build the list of compensation records.
                // This has the intentional side-effect of copying the files to the work folder.
                //
                List<Compensation> compensationRecords = GetCompensationDataFromFiles(
                    compensationFiles,
                    vendorDemographics,
                    workFolder,
                    timestamp);

                //
                // ZIP the files.
                //
                string zipArchiveFullPath = MoveCompensationFilesIntoZipArchive(workFolder, timestamp);

                //
                // Create the manifest.
                //
                string manifestFileFullPath = CreateManifest(compensationRecords, timestamp);

                //
                // Move ZIP archive and manifest to monitored folder.
                //
                MoveArtifactsToOutputFolder(zipArchiveFullPath, manifestFileFullPath, outputFolder);

                //
                // Create trigger file in monitored folder.
                //
                PullTheTrigger(outputFolder);
            }
            finally
            {
                RemoveWorkFolder(workFolder);
            }
        }

        /// <summary>
        /// Retrieves compensation data based on the list of compensation files.
        /// </summary>
        /// <param name="compensationFiles">a list of compensation files to be scanned and processed</param>
        /// <param name="vendorDemographics">a database of vendor demographics</param>
        /// <param name="workFolder">the working folder where the compensation files should be copied for processing</param>
        /// <param name="timestamp">timestamp to use when creating file names and statement date</param>
        /// <returns></returns>
        internal List<Compensation> GetCompensationDataFromFiles(
            List<string> compensationFiles,
            Dictionary<string, VendorDemographics> vendorDemographics,
            string workFolder,
            DateTime timestamp)
        {
            _logger.LogInformation("Retrieving compensation data for {count} files.", compensationFiles.Count);

            var compensationRecords = new List<Compensation>();
            foreach (var sourceFileName in compensationFiles)
            {
                try
                {
                    var compensationRecord = GetCompensationRecord(
                        workFolder,
                        sourceFileName,
                        vendorDemographics,
                        timestamp.Date);

                    if (compensationRecord is { IncludeInArchive: true }) compensationRecords.Add(compensationRecord);
                }
                catch (Exception exception)
                {
                    //
                    // At this point, I don't think this catch block is heuristically reachable,
                    // but it's here just in case.
                    //
                    _logger.LogError(exception, "Could not add file \"{sourceFileName}\" to manifest.", sourceFileName);
                    
                    SendErrorEmail(
                        @$"Could not add file ""{sourceFileName}"" to manifest.
Process will continue for any remaining files.",
                        exception);
                }
            }

            return compensationRecords;
        }

        /// <summary>
        /// Archives the files in the work folder into a ZIP archive file.
        /// </summary>
        /// <param name="workFolder">The working folder where the files to be archived are located</param>
        /// <param name="timestamp">The timestamp to insert into the ZIP archive file name</param>
        /// <returns>the full path to the ZIP archive that was created</returns>
        internal string MoveCompensationFilesIntoZipArchive(string workFolder, DateTime timestamp)
        {
            string archiveName = ZipFilePath(timestamp);

            _logger.LogInformation("Creating ZIP archive {archiveName}.", archiveName);
            ZipFile.CreateFromDirectory(workFolder, archiveName, CompressionLevel.Optimal, false);

            return archiveName;
        }

        /// <summary>
        /// Creates a manifest file for consumption by the P8Loader.
        /// </summary>
        /// <param name="compensationFiles">The list of Compensation objects to be added to the manifest</param>
        /// <param name="timestamp">A timestamp to be inserted into the manifest file name</param>
        /// <returns></returns>
        internal string CreateManifest(List<Compensation> compensationFiles, DateTime timestamp)
        {
            string manifestFileName = ManifestFilePath(timestamp);

            _logger.LogInformation("Writing manifest file {file}", manifestFileName);
            using var writer = new StreamWriter(manifestFileName);
            foreach (var compensationFile in compensationFiles.Where(f => f.IncludeInArchive))
            {
                writer.Write($"{Compensation.DocumentClass}|");
                writer.Write($"{compensationFile.PayeeName}|");
                writer.Write($"{Compensation.DbaName}|");
                writer.Write($"{compensationFile.MailingAddress1}|");
                writer.Write($"{Compensation.MailingAddress2}|");
                writer.Write($"{compensationFile.MailingAddressCity}|");
                writer.Write($"{compensationFile.MailingAddressState}|");
                writer.Write($"{compensationFile.MailingAddressZipCode}|");
                writer.Write($"{Compensation.CheckNumber}|");
                writer.Write($"{compensationFile.ProducerCode}|");
                writer.Write($"{compensationFile.RunDate:d}|");
                writer.Write($"{compensationFile.StatementDate:d}|");
                writer.Write($"{compensationFile.TotalPayment:F2}|");
                writer.Write($"{Compensation.Published}|");
                writer.Write($"{compensationFile.ApplicationUniqueId}|");
                writer.Write($"{compensationFile.NewEarnings:F2}|");
                writer.Write($"{compensationFile.PreviousBalance:F2}|");
                writer.Write($"{Compensation.LineOfBusiness}|");
                writer.Write($"{compensationFile.OutputFileName}");
                writer.WriteLine();
            }
            writer.Flush();
            writer.Close();

            return manifestFileName;
        }
        
        /// <summary>
        /// Updates the compensation record with demographic data from the in-memory demographics database.
        /// </summary>
        /// <param name="demographics">In-memory vendor demographics database</param>
        /// <param name="compensation">The Compensation record to be updated</param>
        /// <exception cref="VendorIdCouldNotBeFoundException"></exception>
        internal bool GetVendorDataFromDemographicsDatabase(
            Dictionary<string, VendorDemographics> demographics,
            Compensation compensation)
        {
            _logger.LogDebug("Retrieving demographic data for vendor ID {vendorId}", compensation.VendorId);

            try
            {
                VendorDemographics demographicsEntry = demographics[compensation.VendorId];
                compensation.PayeeName = demographicsEntry.SupplierName;
                compensation.MailingAddress1 = demographicsEntry.AddressLine1;
                compensation.MailingAddressCity = demographicsEntry.City;
                compensation.MailingAddressState = demographicsEntry.State;
                compensation.MailingAddressZipCode = demographicsEntry.PostalCode;

                return true;
            }
            catch (KeyNotFoundException notFoundException)
            {
                compensation.IncludeInArchive = false;
                _logger.LogError(notFoundException, "Could not locate vendor ID {vendorId} in demographics file.", compensation.VendorId);
                return false;
            }
        }

        /// <summary>
        /// Retrieves key data items from the compensation workbook.
        /// </summary>
        /// <param name="compensation">The compensation record to be updated</param>
        internal bool ExtractCompensationDataFromFile(Compensation compensation)
        {
            _logger.LogDebug("Extracting compensation data from {file}", compensation.WorkFileName);

            try
            {
                using var workbook = new XLWorkbook(compensation.WorkFileName);
                var worksheet = workbook.Worksheet(CurrentStatementWorksheetName);
                compensation.TotalPayment = worksheet.Cell(TotalPaymentsCellName).GetValue<double>();
                compensation.PreviousBalance = worksheet.Cell(PreviousBalanceCellName).GetValue<double>();
                compensation.NewEarnings = (double)worksheet.Evaluate(NewEarningsExpression);

                return true;
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "Could not extract compensation information from Excel file {fileName}", compensation.WorkFileName);
                SendErrorEmail($@"Could not get compensation information from {compensation.WorkFileName}.
See exception below for specific reason.
Processing will continue for any remaining files.",
                    exception);

                compensation.IncludeInArchive = false;

                return false;
            }
        }

        /// <summary>
        /// Gets the most recent list of compensation files
        /// </summary>
        /// <param name="path">Root path to where the compensation files can be found</param>
        /// <param name="today">Today's date - used to decide which compensation folders to use</param>
        /// <param name="compensationDay">Day of the week to determine compensation folder name</param>
        /// <returns></returns>
        internal List<string> GetCompensationFiles(string path, DateTime today, DayOfWeek compensationDay)
        {
            var compensationFilesPath = GetCompensationFolder(today, path, compensationDay);

            _logger.LogInformation(
                "Looking for compensation files in {folder} matching pattern '{pattern}'.",
                compensationFilesPath,
                CommissionFileNamePattern);

            var compensationFiles = Directory.GetFiles(compensationFilesPath, CommissionFileNamePattern).ToList();

            return compensationFiles;
        }

        /// <summary>
        /// Builds a vendor demographics database from the most recent file found in the supplied path
        /// </summary>
        /// <param name="path">The full path to a folder of vendor demographics files</param>
        /// <returns>a database of vendor demographics</returns>
        internal Dictionary<string, VendorDemographics> GetVendorDemographics(string? path = null)
        {
            try
            {
                path ??= _configuration[VendorDemographicsConfigurationKey];

                if (path == null)
                {
                    _logger.LogError("Could not build demographics database because the path is null.");
                    return new Dictionary<string, VendorDemographics>();
                }

                _logger.LogInformation("Looking for vendor demographics files in folder {path}.", path);

                var demographics = GetVendorDemographicsFromCsvFile(path);

                _logger.LogInformation("Building vendor demographic database.");
                var vendorDemographicsDictionary = new Dictionary<string, VendorDemographics>();
                foreach (var vendorDemographic in demographics)
                {
                    vendorDemographicsDictionary.Add(vendorDemographic.SupplierId!, vendorDemographic);
                }

                return vendorDemographicsDictionary;
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "Could not read vendor demographics from {path}", path);
                SendErrorEmail($"Could not read vendor demographics from {path}", exception);

                return new Dictionary<string, VendorDemographics>();
            }
        }

        /// <summary>
        /// Reads the most recent vendor demographics CSV file from the specified path into memory.
        /// </summary>
        /// <param name="path">Full path to the folder containing vendor demographics CSV files</param>
        /// <returns>a list of VendorDemographics objects</returns>
        /// <exception cref="CouldNotReadVendorDemographicsFolderException">thrown when demographics path is unreachable or empty</exception>
        internal List<VendorDemographics> GetVendorDemographicsFromCsvFile(string path)
        {
            var files = Directory.GetFiles(path, VendorDemographicsSearchPattern, SearchOption.TopDirectoryOnly);

            if (files.Length == 0)
            {
                throw new CouldNotReadVendorDemographicsFolderException(path);
            }

            Array.Sort(files);
            var filePath = files.Last();

            try
            {
                //
                // We are only interested in the most recent file, whose name should sort to the bottom of the list.
                //
                _logger.LogInformation("Reading vendor demographics from {filePath}", filePath);

                using var reader = new StreamReader(filePath);
                using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);
                csv.Context.RegisterClassMap<VendorDemographicsMap>();

                return csv.GetRecords<VendorDemographics>().ToList();
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "Error while attempting to read vendor demographics data from {filePath}", filePath);
            }

            return new List<VendorDemographics>();
        }

        #endregion Internal (unit-testable) methods

        #region Private methods

        /// <summary>
        /// Top-level worker method for this task.
        /// </summary>
        private void Run()
        {
            var vendorDemographics = GetVendorDemographics();
            if (VendorDemographicsIsEmpty(vendorDemographics)) return;

            List<string> compensationFiles = GetCompensationFiles(
                _configuration[CommissionStatementsConfigurationKey],
                DateTime.Today,
                CompensationDay);

            if (ThereAreNoCompensationFilesToProcess(compensationFiles)) return;

            var outputFolder = _configuration[ConnectDirectDeliveryPathConfigurationKey];

            //
            // Break the data into batches and deliver each batch to the P8Loader folder.
            //
            foreach (var batch in compensationFiles.Batch(CompensationStatementsBatchSize))
            {
                DeliverCompensationBatch(batch.ToList(), vendorDemographics, outputFolder, DateTime.Now);
            }

            //
            // Kick off the ConnectDirect job.
            //
            RunConnectDirect();

            //
            // Move files to the Archive
            //
            MoveFilesToArchiveFolder();
        }

        private void RemoveWorkFolder(string workFolder)
        {
            try
            {
                if (Directory.Exists(workFolder))
                {
                    //
                    // Remove temporary artifacts.
                    // 
                    Directory.Delete(workFolder, true);
                }
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "Could not remove work folder {workFolder}", workFolder);
            }
        }

        private static void RemoveFailedCompensationFile(string workFolder, string sourceFileName)
        {
            //
            // Attempt to delete the file from the working folder.
            //
            try
            {
                string filePath = WorkFilePath(workFolder, sourceFileName);
                if (File.Exists(filePath)) File.Delete(filePath);
            }
            catch (IOException)
            {
                //
                // Swallow the exception.
                //
            }
        }

        /// <summary>
        /// Moves all of the task artifacts to the P8Loader staging folder.
        /// </summary>
        /// <param name="zipArchiveFullPath">Full path to the the ZIP archive of compensation worksheets</param>
        /// <param name="manifestFileFullPath">Full path to the manifest file</param>
        /// <param name="outputFolder">Folder where the P8Loader expects to find the files</param>
        private void MoveArtifactsToOutputFolder(string zipArchiveFullPath, string manifestFileFullPath, string outputFolder)
        {
            if (!Directory.Exists(outputFolder))
            {
                _logger.LogInformation("Creating output folder {outputFolder}", outputFolder);
                Directory.CreateDirectory(outputFolder);
            }

            _logger.LogInformation("Moving artifacts to {outputFolder}.", outputFolder);
            File.Move(zipArchiveFullPath, Path.Combine(outputFolder, Path.GetFileName(zipArchiveFullPath)));
            File.Move(manifestFileFullPath, Path.Combine(outputFolder, Path.GetFileName(manifestFileFullPath)));

            //
            // For some reason, File.Move() sometimes only does a copy.  Make sure these are gone!
            //
            if (File.Exists(zipArchiveFullPath)) File.Delete(zipArchiveFullPath);
            if (File.Exists(manifestFileFullPath)) File.Delete(manifestFileFullPath);
        }

        /// <summary>
        /// Creates an empty trigger file to signal to the P8Loader that the files are ready to be transferred.
        /// </summary>
        /// <param name="outputFolder">Folder where the P8Loader expects to find the trigger</param>
        /// <throws>IOException</throws>
        private void PullTheTrigger(string outputFolder)
        {
            string triggerFilePath = Path.Combine(outputFolder, TriggerFileName);
            _logger.LogInformation("Creating trigger file {fileName}", triggerFilePath);
            var file = File.Create(triggerFilePath);
            file.Close();
        }

        /// <summary>
        /// Builds a single compensation record based on the supplied source file.
        /// </summary>
        /// <param name="workFolder">Working folder where the compensation workbook will be copied</param>
        /// <param name="sourceFileName">Full path to the source compensation workbook file</param>
        /// <param name="vendorDemographics">A database of vendor demographics containing addresses</param>
        /// <param name="today">timestamp to use for statement date</param>
        /// <returns>a Compensation record built from the source file if successful; null otherwise</returns>
        private Compensation? GetCompensationRecord(string workFolder, string sourceFileName, Dictionary<string, VendorDemographics> vendorDemographics, DateTime today)
        {
            _logger.LogDebug("Retrieving compensation data for {sourceFileName}", sourceFileName);

            if (!CopyCompensationFileToWorkFilePath(workFolder, sourceFileName)) return null;

            //
            // Each of the methods below is responsible for setting the value 
            // of IncludeInArchive to false if there is a failure.
            //
            var workFilePath = WorkFilePath(workFolder, sourceFileName);
            var compensation = new Compensation(workFilePath, today);
            try
            {
                if (!compensation.SuccessfullyParsed)
                {
                    SendBadFileNameEmail(compensation);
                    return null;
                }

                //
                // Extract manifest data from file contents
                //
                if (!ExtractCompensationDataFromFile(compensation)) return null;

                //
                // Look up manifest data from vendor database
                //
                if (!GetVendorDataFromDemographicsDatabase(vendorDemographics, compensation)) return null;

                //
                // Rename the file
                //
                return RenameCompensationFile(workFolder, sourceFileName, workFilePath, compensation)
                    ? compensation 
                    : null;
            }
            finally
            {
                if (!compensation.IncludeInArchive) RemoveFailedCompensationFile(workFolder, sourceFileName);
            }
        }

        private bool RenameCompensationFile(
            string workFolder,
            string sourceFileName,
            string workFilePath,
            Compensation compensation)
        {
            try
            {
                _logger.LogDebug("Renaming {source} to {destination}.", workFilePath, compensation.OutputFileName);
                File.Move(workFilePath, Path.Combine(workFolder, compensation.OutputFileName));
                compensation.IncludeInArchive = true;
                return true;
            }
            catch (Exception exception)
            {
                _logger.LogError(
                    exception,
                    "Could not move {source} to {destination}.",
                    workFilePath,
                    compensation.OutputFileName);

                compensation.IncludeInArchive = false;

                SendErrorEmail(
                    @$"Could not rename file ""{sourceFileName}"" to ""{compensation.OutputFileName}""
Digital Applications has been notified of the issue.
Process will continue for any remaining files.",
                    exception);

                return false;
            }
        }

        private bool CopyCompensationFileToWorkFilePath(string workFolder, string sourceFileName)
        {
            var workFileName = WorkFilePath(workFolder, sourceFileName);

            // 
            // Copy file to working folder.
            //
            try
            {
                _logger.LogDebug("Copying {source} to {destination}.", sourceFileName, workFileName);
                File.Copy(sourceFileName, workFileName);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "Could not copy {source} to {destination}", sourceFileName, workFileName);
                SendErrorEmail(
                    $@"Could not copy {sourceFileName} to {workFileName}.
The issue has been reported to Digital Applications for review.<br/>
Processing will continue for any remaining files.", exception);
                return false;
            }

            return true;
        }

        private string GetCompensationFolder(DateTime today, string path, DayOfWeek compensationDay)
        {
            var dateToProcess = GetUpcomingProcessingDate(today, compensationDay);
            return Path.Combine(path, CommissionFolderPartialPath(dateToProcess));
        }

        /// <summary>
        /// Given a date, this method returns the upcoming processing day relative to the date supplied.
        /// </summary>
        /// <param name="date">A date for which the most current upcoming processing day is desired</param>
        /// <param name="processingDay">Day of the week to determine the next processing date</param>
        /// <returns>The supplied date if it is the same as processingDay; otherwise the upcoming processing day with respect to the supplied date</returns>
        private static DateTime GetUpcomingProcessingDate(DateTime date, DayOfWeek processingDay)
        {
            DateTime processingDate = date;
            while (processingDate.DayOfWeek != processingDay) processingDate = processingDate.AddDays(1);
            return processingDate;
        }

        private void SendErrorEmail(string message, Exception? exception = null)
        {
            var emailMessage = new Message()
            {
                To = EmailAddress.AddressList(_configuration["MailErrors:ToAddress"]),
                From = EmailAddress.SingleAddress(_configuration["MailErrors:FromAddress"]),
                Cc = new List<EmailAddress>(),
                Bcc = new List<EmailAddress>(),
                Subject = _configuration["MailErrors:Subject"],
                PlainTextBody = FormatPlainTextBody(TaskName, message, exception),
                HtmlTextBody = FormatHtmlTextBody(TaskName, message, exception)
            };

            try { _mailClient.Send(emailMessage); }
            catch (Exception sendException)
            {
                _logger.LogError(sendException, "Could not send email message with body {message}", message);
            }
        }

        private void SendBadFileNameEmail(Compensation compensation)
        {
            var emailMessage = new Message()
            {
                To = EmailAddress.AddressList(_configuration["MailErrors:ToAddress"]),
                From = EmailAddress.SingleAddress(_configuration["MailErrors:FromAddress"]),
                Cc = new List<EmailAddress>(),
                Bcc = new List<EmailAddress>(),
                Subject = _configuration["MailErrors:Subject"],
                PlainTextBody = string.Empty,
                HtmlTextBody = compensation.BadFileNameEmailBody()
            };

            try { _mailClient.Send(emailMessage); }
            catch (Exception sendException)
            {
                _logger.LogError(
                    sendException,
                    "Could not send email message with body {message}",
                    compensation.BadFileNameEmailBody());
            }
        }

        private string FormatPlainTextBody(string source, string message, Exception? exception)
        {
            var builder = new StringBuilder();
            builder.AppendLine($"ERROR: {message}");
            builder.AppendLine($"Environment: {_configuration["Environment"]}");
            builder.AppendLine($"Host: {Environment.MachineName}");
            builder.AppendLine($"Task: {source}");
            builder.AppendLine($"User ID: {Environment.UserName}");

            if (exception is not null) FormatPlainTextException(builder, exception);

            return builder.ToString();
        }

        private void FormatPlainTextException(StringBuilder builder, Exception exception)
        {
            builder.AppendLine();
            builder.AppendLine($"EXCEPTION: {exception.Message}");
            builder.AppendLine();
            builder.AppendLine("STACK TRACE:");
            builder.AppendLine(exception.StackTrace);

            if (exception.InnerException is not null) FormatPlainTextException(builder, exception.InnerException);
        }

        private string FormatHtmlTextBody(string source, string message, Exception? exception)
        {
            var builder = new StringBuilder();

            HtmlMessageElementsHelper.SetHtmlHeader(builder);
            var messages = message.Split("\n");
            builder.AppendLine($@"<h1 class='error'>ERROR: {messages[0]}</h1>");
            if (messages.Length > 1)
            {
                foreach (var m in messages.Skip(1)) builder.AppendLine($@"<p>{m}</p>");
                builder.AppendLine(@"<p>&nbsp;</p>");
            }
            builder.AppendLine($"<p><strong>Environment:</strong> {_configuration["Environment"]}<br/>");
            builder.AppendLine($"<strong>Host:</strong> {Environment.MachineName}<br/>");
            builder.AppendLine($"<strong>Task:</strong> {source}<br/>");
            builder.AppendLine($"<strong>User ID:</strong> {Environment.UserName}</p>");

            if (exception is not null) FormatHtmlException(builder, exception);
            HtmlMessageElementsHelper.CloseHtml(builder);

            return builder.ToString();
        }

        private static void FormatHtmlException(StringBuilder builder, Exception exception)
        {
            while (true)
            {
                builder.AppendLine("<hr/>");
                builder.AppendLine($"<h2 class='error'>EXCEPTION: {exception.Message}</h2>");
                builder.AppendLine($"<pre>{exception.StackTrace}</pre>");

                if (exception.InnerException is not null)
                {
                    exception = exception.InnerException;
                    continue;
                }

                break;
            }
        }

        private void RunConnectDirect()
        {
            if (_configuration[UseConnectDirectConfigurationKey].Equals("false", StringComparison.InvariantCultureIgnoreCase))
            {
                _logger.LogInformation("Skipping Connect:Direct transfer because this environment is not configured to use it.");
                return;
            }

            string destinationHostName = _configuration[ConnectDirectEndpointHostConfigurationKey];
            string destinationFolder = _configuration[ConnectDirectEndpointPathConfigurationKey];
            string sourceFolder = _configuration[ConnectDirectDeliveryPathConfigurationKey];

            // ReSharper disable StringLiteralTypo
            string commandScript = @$"
submit maxdelay=unlimited
COMPSEND  PROCESS
    &DT=%SUBDATE1
    &TM=%SUBTIME
    &SRC=""{sourceFolder}""
    SNODE={destinationHostName}

STEP1  COPY FROM (
        FILE=""&SRC\*.*""	
        SYSOPTS=""DATATYPE(BINARY)""
        PNODE
    )
    TO (
        FILE=""{destinationFolder}""
        DISP=NEW
        sysopts=""DATATYPE(BINARY)""
        SNODE
    )

PEND;
sel stat PNAME=COMPSEND    detail=yes recids=(CTRC,RTED) startt=(today);
quit;
";
            // ReSharper restore StringLiteralTypo

            string connectDirectExecutablePath = _configuration[ConnectDirectExecutablePathConfigurationKey];
            string connectDirectAuthenticationPath = _configuration[ConnectDirectAuthenticationPathConfigurationKey];

            _logger.LogInformation(
                "Attempting to run Connect:Direct using executable {executablePath} and authorization file {authorizationPath}",
                connectDirectExecutablePath,
                connectDirectAuthenticationPath);

            Process? process = null;
            try
            {
                var startInfo = new ProcessStartInfo(
                    $"{connectDirectExecutablePath}",
                    $@"-f ""{connectDirectAuthenticationPath}""")
                {
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    RedirectStandardInput = true,
                    UseShellExecute = false
                };

                process = Process.Start(startInfo);
                if (process == null)
                {
                    CompletionStatus = TaskCompletionStatus.Failed;
                    _logger.LogError("Connect:Direct process failed to start.");
                }

                process!.OutputDataReceived += LogConnectDirectStandardOutput;
                process.ErrorDataReceived += LogConnectDirectErrorOutput;

                process.BeginOutputReadLine();
                process.BeginErrorReadLine();

                _logger.LogInformation("Sending command script to Connect:Direct process.  Command script contents:\n {script}", commandScript);
                process.StandardInput.WriteLine(commandScript);
                process.WaitForExit();

                _logger.LogInformation("Connect:Direct process completed with status code {code}", process.ExitCode);

            }
            catch (Exception exception)
            {
                CompletionStatus = TaskCompletionStatus.Failed;
                _logger.LogError(exception, "Error occurred while attempting to run Connect:Direct.");
            }
            finally
            {
                process?.Close();
            }
        }

        private bool EnsureFolderExists(string folder)
        {
            try
            {
                if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
                return true;
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "Could not create missing folder {folder}", folder);
                return false;
            }
        }

        private void LogConnectDirectStandardOutput(object sender, DataReceivedEventArgs e)
        {
            if (e.Data == null) return;
            _logger.LogInformation("CD MSG: {message}", e.Data);
        }

        private void LogConnectDirectErrorOutput(object sender, DataReceivedEventArgs e)
        {
            if (e.Data == null) return;
            _logger.LogError("CD ERROR: {message}", e.Data);
        }

        private bool ThereAreNoCompensationFilesToProcess(List<string> compensationFiles)
        {
            if (compensationFiles.Count == 0)
            {
                const string message = "No member files were available for transmission.";
                _logger.LogError(message);
                SendErrorEmail(message);
                CompletionStatus = TaskCompletionStatus.Failed;
                return true;
            }

            return false;
        }

        private bool VendorDemographicsIsEmpty(Dictionary<string, VendorDemographics> vendorDemographics)
        {
            if (vendorDemographics.Count == 0)
            {
                const string message = "Could not find a vendor demographics file to load.";
                _logger.LogError(message);
                SendErrorEmail(message);
                CompletionStatus = TaskCompletionStatus.Failed;
                return true;
            }

            return false;
        }

        private void MoveFilesToArchiveFolder()
        {
            var deliveryFolder = _configuration[ConnectDirectDeliveryPathConfigurationKey];
            var archiveFolder = _configuration[ConnectDirectArchivePathConfigurationKey];

            if (!EnsureFolderExists(archiveFolder))
            {
                _logger.LogCritical(
                    "Could not access or create ConnectDirect Archive folder: {archiveFolder}",
                    archiveFolder);

                return;
            }

            var files = new List<string>();
            files.AddRange(Directory.GetFiles(deliveryFolder, "*.zip"));
            files.AddRange(Directory.GetFiles(deliveryFolder, "*.txt"));

            _logger.LogInformation("Moving files to the archive folder.");
            foreach (var file in files)
            {
                var destination = Path.Combine(archiveFolder, Path.GetFileName(file));
                try
                {
                    File.Move(file, destination);
                }
                catch (Exception exception)
                {
                    _logger.LogError(exception, "Error moving {file} to the archive folder {archive}.", file, destination);
                }
            }

            var triggerFile = Path.Combine(deliveryFolder, TriggerFileName);
            try
            {
                if (File.Exists(triggerFile)) File.Delete(triggerFile);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "Error removing trigger file {file}", triggerFile);
            }
        }

        #endregion Private methods
    }
}
