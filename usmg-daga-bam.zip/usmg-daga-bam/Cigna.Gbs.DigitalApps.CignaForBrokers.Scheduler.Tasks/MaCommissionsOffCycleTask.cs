﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks
{
    public class MaCommissionsOffCycleTask: MedicareAdvantageCommissionsTask
    {
        #region Members implemented for MedicareAdvantageCommissionsTask

        /// <inheritdoc />
        public override DayOfWeek CompensationDay => DayOfWeek.Wednesday;

        /// <inheritdoc />
        protected override string TaskName => nameof(MaCommissionsOffCycleTask);

        protected override string CommissionFolderPartialPath(DateTime date) => 
            Path.Combine($"{date.Year:D4}", $"{date.Month:D2} {date.Day:D2} {date.Year % 100:D2} CMS Alteryx");

        #endregion Members implemented for MedicareAdvantageCommissionsTask

        #region Constructors

        public MaCommissionsOffCycleTask() : base(TaskConfigurationFactory.Instance) { }

        public MaCommissionsOffCycleTask(ITaskConfigurationFactory factory) : base(factory) { }

        #endregion Constructors

    }
}
