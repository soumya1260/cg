﻿using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;

[assembly: InternalsVisibleTo("Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.Tests.Unit")]
namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.CommissionObjects
{
    public class Compensation
    {
        public static string DocumentClass => "ProducerCommissions";
        public string? PayeeName { get; set; } = "Could not parse";
        public static string DbaName => string.Empty;
        public string? MailingAddress1 { get; set; }
        public static string MailingAddress2 => string.Empty;
        public string? MailingAddressCity { get; set; }
        public string? MailingAddressState { get; set; }
        public string? MailingAddressZipCode { get; set; }
        public static string CheckNumber => string.Empty;
        public string ProducerCode => VendorId;
        public DateTime RunDate { get; }
        public DateTime StatementDate { get; }
        public double TotalPayment { get; set; }
        public static string Published => "TRUE";
        public string ApplicationUniqueId => $"{ProducerCode}{StatementDate:yyyyMMdd}";
        public double NewEarnings { get; set; }
        public double PreviousBalance { get; set; }
        public static string LineOfBusiness => "MA";
        public string VendorId { get; private set; } = "Could not parse";
        public string OutputFileName => $"MACommissions-{VendorId}-{StatementDate:yyyyMMdd}.xlsx";
        public string WorkFileName { get; }
        public bool IncludeInArchive { get; set; }

        //
        // Parse conditions
        //
        public bool SuccessfullyParsed { get; }
        internal bool PartialMatch { get; private set; }
        internal  string EffectiveDateString { get; private set; }  = "Could not parse";
        internal  string FileExtension { get; private set; } = "Could not parse";
        internal  string PayeeNameStatus { get; private set; } = "OK";
        internal  string VendorIdStatus { get; private set; } = "OK";
        internal  string StatementIdentifierStatus { get; private set; } = "OK";
        internal  string EffectiveDateStatus { get; private set; } = "OK";
        internal  string FileExtensionStatus { get; private set; } = "OK";

        private static readonly Regex FileNameRegex = new(
            @"^(?<VendorName>.*)\s+(?<VendorId>\d{10})\s+Cigna Medicare Commission\s+(?<Date>\d{4}-\d{2}-\d{2})\.(?<FileExtension>xlsx)$",
            RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Singleline);

        public Compensation(string workFileName, DateTime? runDate = null)
        {
            WorkFileName = workFileName;
            var matches = FileNameRegex.Matches(workFileName);
            if (matches.Any())
            {
                var groups = matches[0].Groups;

                PayeeName = groups["VendorName"].Value;  // Note: This will be reassigned from the vendor file later.
                VendorId = groups["VendorId"].Value;
                EffectiveDateString = groups["Date"].Value;
                FileExtension = groups["FileExtension"].Value;

                StatementDate = DateTime.TryParse(EffectiveDateString, out DateTime statementDate)
                    ? statementDate
                    : DateTime.MinValue;

                SuccessfullyParsed = true;
            }
            else
            {
                SuccessfullyParsed = false;
                DetectFileNameProblems();
            }

            IncludeInArchive = SuccessfullyParsed;
            RunDate = runDate ?? DateTime.Today;
        }

        private static readonly Regex GeneralizedFileNameRegex = new(
            @"^(?<VendorName>.*)\s+(?<VendorId>\d*)\s+Cigna Medicare Commission\s+(?<Date>.*)\.(?<Extension>[^\.]*)$",
            RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Singleline);

        private static readonly Regex VendorIdRegex = new(
            @"^\d{10}$",
            RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Singleline);

        private static readonly Regex EffectiveDateRegex = new(
            @"^\d{4}-\d{2}-\d{2}$",
            RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Singleline);

        
        private void DetectFileNameProblems()
        {
            //
            // Try to break the file name into less-specific pieces.
            //
            var matches = GeneralizedFileNameRegex.Matches(WorkFileName);
            if (!matches.Any())
            {
                PartialMatch = false;

                PayeeNameStatus = "INVALID";
                VendorIdStatus = "INVALID";
                StatementIdentifierStatus = "INVALID";
                EffectiveDateStatus = "INVALID";
                FileExtensionStatus = "INVALID";

                return;
            }

            PartialMatch = true;

            var groups = matches[0].Groups;
            PayeeName = groups["VendorName"].Value;
            VendorId = groups["VendorId"].Value;
            EffectiveDateString = groups["Date"].Value;
            FileExtension = groups["Extension"].Value;

            VendorIdStatus = VendorIdRegex.IsMatch(VendorId) 
                ? "OK" 
                : $"Expected 10 digits; actual length is {VendorId.Length}";

            EffectiveDateStatus = EffectiveDateRegex.IsMatch(EffectiveDateString)
                ? "OK"
                : $"Expected 'yyyy-mm-dd'; found '{EffectiveDateString}'";

            FileExtensionStatus = FileExtension.Equals("xlsx", StringComparison.InvariantCultureIgnoreCase)
                ? "OK"
                : $"Expected an extension of 'xlsx'; found '{FileExtension}'";
        }

        public string BadFileNameEmailBody()
        {
            var builder = new StringBuilder();

            HtmlMessageElementsHelper.SetHtmlHeader(builder);
            builder.AppendLine("<h1>Error Adding Compensation File</h1>");

            if (!PartialMatch)
            {
                builder.AppendLine($"<p>The file \"<span class='error mono-spaced'>{WorkFileName}</span>\" could not be added to today's compensation archive for <em>Cigna for Brokers</em>.</p>");
                builder.AppendLine("<p>The file name does not conform to the pattern: \"<span class='mono-spaced'><em>Payee_Name</em> <em>9999999999</em> Cigna Medicare Commission <em>yyyy-mm-dd</em>.xlsx</span>\".</p>");
            }
            else
            {
                builder.AppendLine("<p>The file name below does not conform to the file name guidelines:</p>");
                builder.AppendLine("<p class='mono-spaced centered'>");
                builder.Append(FormatFilenamePortion(PayeeNameStatus, PayeeName!));

                //
                // This is grabbing the spaces between
                //
                builder.Append(WorkFileName.AsSpan(
                    PayeeName!.Length, 
                    WorkFileName.IndexOf(VendorId, StringComparison.InvariantCultureIgnoreCase) - PayeeName.Length));

                builder.Append(FormatFilenamePortion(VendorIdStatus, VendorId));

                //
                // Spaces and the file type identifier
                //
                int start = WorkFileName.IndexOf(VendorId, StringComparison.InvariantCultureIgnoreCase) + VendorId.Length;
                string section = WorkFileName.Substring(
                    start,
                    WorkFileName.IndexOf(EffectiveDateString, StringComparison.InvariantCultureIgnoreCase) - start);
                builder.Append(FormatFilenamePortion(StatementIdentifierStatus, section));

                builder.Append(FormatFilenamePortion(EffectiveDateStatus, EffectiveDateString));
                builder.Append('.');
                builder.Append(FormatFilenamePortion(FileExtensionStatus, FileExtension));
                
                builder.AppendLine("</p>");
            }

            builder.AppendLine("<p class='mono-spaced'>");
            builder.AppendLine(FormatStatusLine("Payee Name", PayeeNameStatus));
            builder.AppendLine(FormatStatusLine("Vendor ID", VendorIdStatus));
            builder.AppendLine(FormatStatusLine("Statement Type", StatementIdentifierStatus));
            builder.AppendLine(FormatStatusLine("Effective Date", EffectiveDateStatus));
            builder.AppendLine(FormatStatusLine("File Extension", FileExtensionStatus));
            builder.AppendLine("</p>");


            builder.AppendLine("<p>The file will be skipped.  Please correct the file name and re-submit with the next batch.</p>");

            HtmlMessageElementsHelper.CloseHtml(builder);

            return builder.ToString();
        }

        private static string FormatStatusLine(string label, string status) => $"{$"{label,-14}".Replace(" ", "&nbsp;")}: {FormatStatusSpan(status)}<br/>";

        private static string FormatStatusSpan(string status) => $"<span {FormatStatusClass(status)}>{status}</span>";

        private static string FormatFilenamePortion(string status, string value) => $"<span {FormatStatusClass(status)}>{value}</span>";

        private static string FormatStatusClass(string status) => $"class='{(status == "OK" ? "okay" : "error")}'";
    }
}