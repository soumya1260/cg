﻿using CsvHelper.Configuration;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.CommissionObjects
{
    /// <summary>
    /// CSV to Class mapper for VendorDemographics
    /// </summary>
    // ReSharper disable once ClassNeverInstantiated.Global
    public sealed class VendorDemographicsMap : ClassMap<VendorDemographics>
    {
        public VendorDemographicsMap()
        {
            //
            // Mapping all items for consistency and to avoid problems with name refactoring.
            //
            Map(m => m.SupplierId).Name("Supplier ID");
            Map(m => m.SupplierName).Name("Supplier");
            Map(m => m.Class).Name("Class");
            Map(m => m.Status).Name("Status");
            Map(m => m.TaxId).Name("Tax ID");
            Map(m => m.PivotalId).Name("Pivotal ID");
            Map(m => m.CignaProducerCode).Name("Cigna Producer Code");
            Map(m => m.EffectiveDate).Name("Eff Date");
            Map(m => m.AddressLine1).Name("Address 1");
            Map(m => m.AddressLine2).Name("Address 2");
            Map(m => m.City).Name("City");
            Map(m => m.State).Name("State");
            Map(m => m.PostalCode).Name("Postal");
            Map(m => m.CancellationDate).Name("Cancel Date");
        }
    }
}
