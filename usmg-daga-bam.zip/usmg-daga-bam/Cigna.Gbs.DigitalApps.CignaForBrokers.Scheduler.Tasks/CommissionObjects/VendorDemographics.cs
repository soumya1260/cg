﻿// ReSharper disable UnusedAutoPropertyAccessor.Global
// ReSharper disable ClassNeverInstantiated.Global

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.CommissionObjects
{
    /// <summary>
    /// Demographics record for a broker (vendor)
    /// </summary>
    public class VendorDemographics
    {
        public string? SupplierId { get; set; }
        public string? SupplierName { get; set; }
        public char Class { get; set; }
        public char Status { get; set; }
        public string? TaxId { get; set; }
        public string? PivotalId { get; set; }
        public string? CignaProducerCode { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public string? AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? PostalCode { get; set; }
        public DateTime? CancellationDate { get; set; }
    }
}
