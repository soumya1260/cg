﻿namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.Exceptions
{
    [Serializable]
    public class VendorIdCouldNotBeFoundException : Exception
    {
        public VendorIdCouldNotBeFoundException() { }
        public VendorIdCouldNotBeFoundException(string vendorId)
            : base($"Could not find Supplier ID matching {vendorId} in demographics file.") { }
        public VendorIdCouldNotBeFoundException(string vendorId, Exception inner) 
            : base($"Could not find Supplier ID matching {vendorId} in demographics file.", inner) { }
        protected VendorIdCouldNotBeFoundException(
            System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}