﻿namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.Exceptions
{
    [Serializable]
    public class CouldNotReadVendorDemographicsFolderException : Exception
    {
        public CouldNotReadVendorDemographicsFolderException() 
            : base("Could not access vendor demographics in folder.  Path is inaccessible, contains no demographic files or does not exist.") { }

        public CouldNotReadVendorDemographicsFolderException(string path)
            : base($"Could not access vendor demographics in folder {path}.  Path is inaccessible, contains no demographic files or does not exist.") { }

        public CouldNotReadVendorDemographicsFolderException(string path, Exception inner)
            : base($"Could not access vendor demographics in folder {path}.  Path is inaccessible, contains no demographic files or does not exist.", inner) { }

        protected CouldNotReadVendorDemographicsFolderException(
            System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}