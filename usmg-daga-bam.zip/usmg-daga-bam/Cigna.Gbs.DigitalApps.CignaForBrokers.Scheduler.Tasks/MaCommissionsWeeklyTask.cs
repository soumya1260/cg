﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks
{
    public class MaCommissionsWeeklyTask: MedicareAdvantageCommissionsTask
    {
        #region Members implemented for MedicareAdvantageCommissionsTask

        /// <inheritdoc />
        public override DayOfWeek CompensationDay => DayOfWeek.Friday;

        /// <inheritdoc />
        protected override string TaskName => nameof(MaCommissionsWeeklyTask);

        protected override string CommissionFolderPartialPath(DateTime date) => 
            Path.Combine($"{date.Year:D4}", $"{date.Month:D2} {date.Day:D2} {date.Year % 100:D2} Alteryx");

        #endregion Members implemented for MedicareAdvantageCommissionsTask

        #region Constructors

        public MaCommissionsWeeklyTask() : base(TaskConfigurationFactory.Instance) { }
        public MaCommissionsWeeklyTask(ITaskConfigurationFactory factory) : base(factory) { }

        #endregion
    }
}
