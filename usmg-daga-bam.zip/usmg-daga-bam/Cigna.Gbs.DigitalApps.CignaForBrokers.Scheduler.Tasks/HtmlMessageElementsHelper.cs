﻿using System.Text;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks
{
    public static class HtmlMessageElementsHelper
    {
        public static void SetHtmlHeader(StringBuilder emailBody)
        {
            emailBody.AppendLine(
                $@"
<html>
  <head>{EmailStyleSheet}</head>
  <body>");
        }

        public static void CloseHtml(StringBuilder emailBody)
        {
            emailBody.AppendLine(
                @"
  </body>
</html>");
        }

        private static string EmailStyleSheet =>
            @"
      <style>
        body { 
          font-family: Calibri, Arial, sans-serif;
          font-size: 11pt;
        }

        table, th, td {
          border-style: solid;
          border-width: 1px;
          border-color: #237eb8;
          padding: 4px;
          margin: 0 0 0 0;
          border-collapse: collapse;
        }

        tr {
          margin: 0 0 0 0;
        }

        th {
          background-color: #237eb8;
          border-color: #ffffff;
          color: #ffffff;
        }

        .mono-spaced {
          font-family: ""Cascadia Code"", Consolas, ""Courier New"", Courier, monospace;
        }

        .centered {
          text-align: center;
        }

        .error {
          color: red;
          font-weight: bold;
        }

        .okay {
          color: green;
          font-weight: bold;
        }
      </style>
";
    }
}