namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.Tests.Unit
{
    public enum CompensationStatementType
    {
        Weekly,
        OffCycle
    }
}