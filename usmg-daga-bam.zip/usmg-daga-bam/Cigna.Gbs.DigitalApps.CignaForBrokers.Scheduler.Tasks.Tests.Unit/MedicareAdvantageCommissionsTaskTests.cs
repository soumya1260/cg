using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Mail;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.CommissionObjects;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.IO.Compression;
using System.Text.RegularExpressions;

// ReSharper disable CommentTypo
// ReSharper disable StringLiteralTypo
// ReSharper disable MemberCanBePrivate.Global

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.Tests.Unit
{
    [ExcludeFromCodeCoverage]
    public class MedicareAdvantageCommissionsTaskTests
    {
        private readonly MedicareAdvantageCommissionsTask _weeklyCommissionsTask;
        private readonly MedicareAdvantageCommissionsTask _offCycleCommissionsTask;
        private readonly IConfiguration _configuration;

        private const string File1 =
            @"\\hsnas4.healthspring.inside\deptshares\Corporate_Sales\Market Data File\Statements\2022\11 04 22 Alteryx\ABC HAWKINSURANCE AGCY 0000296209 Cigna Medicare Commission 2022-11-04.xlsx";

        private const string File2 =
            @"\\hsnas4.healthspring.inside\deptshares\Corporate_Sales\Market Data File\Statements\2022\11 04 22 Alteryx\ADAM SAADI INSURANCE AGENCY 0000248878 Cigna Medicare Commission 2022-11-04.xlsx";

        /// <summary>
        /// Test constructor
        /// </summary>
        public MedicareAdvantageCommissionsTaskTests()
        {
            _configuration = InitConfiguration();
            var taskConfigurationFactory = TaskConfigurationFactory.Instance;
            taskConfigurationFactory.ConfigurationManager = _configuration;
            taskConfigurationFactory.Logger = new LoggerFactory().AddSerilog().CreateLogger("Logger");  // You can also use NullLogger<T>() here.
            taskConfigurationFactory.MailClient = new FakeMailClient();

            _weeklyCommissionsTask = new MaCommissionsWeeklyTask(taskConfigurationFactory);
            _offCycleCommissionsTask = new MaCommissionsOffCycleTask(taskConfigurationFactory);
        }

        /// <summary>
        /// Boilerplate .NET 6 configuration initialization.
        /// </summary>
        /// <returns></returns>
        private static IConfiguration InitConfiguration()
        {
            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.test.json")
                .AddEnvironmentVariables()
                .Build();

            return config;
        }

        [Test]
        public void GetVendorDemographics_ReturnsExpectedNumberOfRowsFromCorrectFile()
        {
            string path = _configuration[MedicareAdvantageCommissionsTask.VendorDemographicsConfigurationKey];
            var vendorDemographics = _weeklyCommissionsTask.GetVendorDemographicsFromCsvFile(path);
            Assert.That(vendorDemographics, Has.Count.EqualTo(60_000));
        }

        //
        // Source folder: \\hsnas4.healthspring.inside\deptshares\Corporate_Sales\Market Data File\Statements\2022
        //
        [TestCase(2022, 10, 25, "10 28 22 Alteryx", 1094, CompensationStatementType.Weekly)]
        [TestCase(2022, 11, 01, "11 04 22 Alteryx", 653, CompensationStatementType.Weekly)]
        [TestCase(2022, 11, 22, "11 25 22 Alteryx", 945, CompensationStatementType.Weekly)]
        [TestCase(2023, 03, 20, "03 22 23 CMS Alteryx", 120, CompensationStatementType.OffCycle)]
        public void GetCompensationFiles_ReturnsExpectedNumberOfFilePaths(
            int year,
            int month,
            int day,
            string expectedPath,
            int expectedNumberOfCompensationFileNames,
            CompensationStatementType type)
        {
            var commissionStatementsBasePath = 
                _configuration[MedicareAdvantageCommissionsTask.CommissionStatementsConfigurationKey];
            
            var task = type == CompensationStatementType.Weekly
                ? _weeklyCommissionsTask
                : _offCycleCommissionsTask;
            
            var compensationFiles = task.GetCompensationFiles(
                commissionStatementsBasePath,
                new DateTime(year, month, day),
                task.CompensationDay);

            Assert.That(compensationFiles, Has.Count.EqualTo(expectedNumberOfCompensationFileNames));
        }

        [TestCase(File1, "0000296209", "2022-11-04", "MACommissions-0000296209-20221104.xlsx")]
        [TestCase(File2, "0000248878", "2022-11-04", "MACommissions-0000248878-20221104.xlsx")]
        public void CompensationConstructor_InitializesFieldsCorrectly(
            string workFileName,
            string agentId,
            string statementDate,
            string fileName)
        {
            var compensation = new Compensation(workFileName, DateTime.Parse(statementDate));
            Assert.Multiple(
                () =>
                {
                    Assert.That(compensation.StatementDate, Is.EqualTo(DateTime.Parse(statementDate)));
                    Assert.That(compensation.VendorId, Is.EqualTo(agentId));
                    Assert.That(compensation.OutputFileName, Is.EqualTo(fileName));
                });
        }

        [TestCase(File1, 150, 0, 0)]
        [TestCase(File2, 36.08, -91.75, 127.83)]
        public void ExtractManifestDataFromFile_ReturnsExpectedValues(
            string filename,
            double totalPayment,
            double previousBalance,
            double newEarnings)
        {
            var compensation = new Compensation(filename);
            _weeklyCommissionsTask.ExtractCompensationDataFromFile(compensation);

            Assert.Multiple(
                () =>
                {
                    Assert.That(compensation.TotalPayment, Is.EqualTo(totalPayment));
                    Assert.That(compensation.PreviousBalance, Is.EqualTo(previousBalance));
                    Assert.That(compensation.NewEarnings, Is.EqualTo(newEarnings));
                });
        }

        [TestCase(
            File1,
            "ABC HAWKINSURANCE AGCY",
            "1937 BELLATRIX DR",
            "HASLET",
            "TX",
            "76052")]
        [TestCase(
            File2,
            "ADAM SAADI INSURANCE AGENCY",
            "12727 FEATHERWOOD DR STE. 115B",
            "HOUSTON",
            "TX",
            "77034")]

        public void ExtractManifestDataFromDemographicsDatabase_ReturnsExpectedValues(
            string workFileName,
            string payeeName,
            string mailingAddress1,
            string city,
            string state,
            string zipCode)
        {
            //
            // Read in demographics for later use.
            //
            string path = _configuration[MedicareAdvantageCommissionsTask.VendorDemographicsConfigurationKey];
            var vendorDemographics = _weeklyCommissionsTask.GetVendorDemographics(path);

            //
            // Initialize the compensation object
            //
            var compensation = new Compensation(workFileName);

            //
            // Act: extract the demographic data.
            //
            _weeklyCommissionsTask.GetVendorDataFromDemographicsDatabase(vendorDemographics, compensation);

            //
            // Assertions
            //
            Assert.Multiple(
                () =>
                {
                    Assert.That(compensation.PayeeName, Is.EqualTo(payeeName));
                    Assert.That(compensation.MailingAddress1, Is.EqualTo(mailingAddress1));
                    Assert.That(compensation.MailingAddressCity, Is.EqualTo(city));
                    Assert.That(compensation.MailingAddressState, Is.EqualTo(state));
                    Assert.That(compensation.MailingAddressZipCode, Is.EqualTo(zipCode));
                });
        }

        [Test]
        public void ArchiveFiles_CreatesTopLevelArchiveWithAllExpectedFiles()
        {
            //
            // Copy some files into the temporary folder
            //
            string workFolder = Path.Combine(Path.GetTempPath(), $"Compensation-{DateTime.Now:yyyyMMddHHmmssfff}");
            Directory.CreateDirectory(workFolder);

            File.Copy(File1, Path.Combine(workFolder, Path.GetFileName(File1)));
            File.Copy(File2, Path.Combine(workFolder, Path.GetFileName(File2)));

            string archiveName = _weeklyCommissionsTask.MoveCompensationFilesIntoZipArchive(workFolder, DateTime.Now);

            using (var archive = ZipFile.OpenRead(archiveName))
            {
                Assert.Multiple(
                    () =>
                    {
                        Assert.That(
                            Regex.IsMatch(archiveName, @".*ProducerCommissions_MA_\d{17}\.zip$"),
                            "Archive file name doesn't match expected pattern.");
                        Assert.That(File.Exists(archiveName), $"Archive {archiveName} could not be found.");
                        Assert.That(new FileInfo(archiveName), Has.Length.GreaterThan(0));
                        Assert.That(archive.Entries, Is.Not.Null);
                        Assert.That(archive.Entries, Has.Count.EqualTo(2));
                    });
            }

            Directory.Delete(workFolder, true);
            File.Delete(archiveName);
        }

        [Test]
        public void CreateManifest_ProducesExpectedFileOutput()
        {
            var timestamp = new DateTime(
                2022,
                11,
                5,
                13,
                14,
                15,
                16);

            //
            // Set up our working folder.
            //
            string workFolder = MedicareAdvantageCommissionsTask.WorkFolderPath(timestamp);
            Directory.CreateDirectory(workFolder);

            string expectedManifestFileName = Path.Combine(
                Path.GetTempPath(),
                "ProducerCommissions_MA_20221105131415016.txt");

            try
            {
                string path = _configuration[MedicareAdvantageCommissionsTask.VendorDemographicsConfigurationKey];
                var vendorDemographics = _weeklyCommissionsTask.GetVendorDemographics(path);

                var compensationFiles = new List<string> { File1, File2 };

                //
                // Build our manifest object.
                //
                List<Compensation> manifest = _weeklyCommissionsTask.GetCompensationDataFromFiles(
                    compensationFiles,
                    vendorDemographics,
                    workFolder,
                    timestamp);

                //
                // Act
                //
                var manifestFile = _weeklyCommissionsTask.CreateManifest(manifest, timestamp);

                string[] manifestFileContents = File.ReadAllLines(manifestFile);
                string[] expectedManifest =
                {
                    "ProducerCommissions|ABC HAWKINSURANCE AGCY||1937 BELLATRIX DR||HASLET|TX|76052||0000296209|11/5/2022|11/4/2022|150.00|TRUE|000029620920221104|0.00|0.00|MA|MACommissions-0000296209-20221104.xlsx",
                    "ProducerCommissions|ADAM SAADI INSURANCE AGENCY||12727 FEATHERWOOD DR STE. 115B||HOUSTON|TX|77034||0000248878|11/5/2022|11/4/2022|36.08|TRUE|000024887820221104|127.83|-91.75|MA|MACommissions-0000248878-20221104.xlsx"
                };

                //
                // Assert
                //
                Assert.Multiple(
                    () =>
                    {
                        Assert.That(manifestFile, Is.EqualTo(expectedManifestFileName));
                        Assert.That(File.Exists(manifestFile));
                        Assert.That(manifestFileContents[0], Is.EqualTo(expectedManifest[0]));
                        Assert.That(manifestFileContents[1], Is.EqualTo(expectedManifest[1]));
                    });
            }
            finally
            {
                Directory.Delete(workFolder, true);
                File.Delete(expectedManifestFileName);
            }
        }

        [Test]
        public void DeliverBatch_DeliversExpectedFiles()
        {
            string path = _configuration[MedicareAdvantageCommissionsTask.VendorDemographicsConfigurationKey];
            var vendorDemographics = _weeklyCommissionsTask.GetVendorDemographics(path);

            var compensationFiles = new List<string> { File1, File2 };

            string outputFolder = Path.Combine(Path.GetTempPath(), "MA_Commissions");

            var timestamp = new DateTime(
                2022,
                01,
                16,
                12,
                34,
                56,
                789);

            try
            {
                _weeklyCommissionsTask.DeliverCompensationBatch(compensationFiles, vendorDemographics, outputFolder, timestamp);

                Assert.Multiple(
                    () =>
                    {
                        Assert.That(File.Exists(Path.Combine(outputFolder, "ProducerCommissions_MA_20220116123456789.txt")), "Could not find manifest file in output folder.");
                        Assert.That(File.Exists(Path.Combine(outputFolder, "ProducerCommissions_MA_20220116123456789.zip")), "Could not find ZIP file in output folder.");
                        Assert.That(File.Exists(Path.Combine(outputFolder, "trigger.ProducerCommissionsMA")), "Could not find trigger file in output folder.");
                    });
            }
            finally
            {
                Directory.Delete(outputFolder, true);
                File.Delete(Path.Combine(Path.GetTempPath(), "ProducerCommissions_MA_20220116123456789.txt"));
                File.Delete(Path.Combine(Path.GetTempPath(), "ProducerCommissions_MA_20220116123456789.zip"));
            }
        }
    }
}