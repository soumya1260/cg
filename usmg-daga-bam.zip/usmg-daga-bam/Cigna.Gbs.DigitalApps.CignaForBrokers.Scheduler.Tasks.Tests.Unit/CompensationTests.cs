﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.CommissionObjects;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler.Tasks.Tests.Unit
{
    [TestFixture]
    public class CompensationTests
    {
        private const string BartGoodFile = "BART SIMPSON 0123456789 Cigna Medicare Commission 2023-02-17.xlsx";
        private const string BartBadFile = "BART SIMPSON yellow Cigna Medicare Commission ballyhoo.xlsx";
        private const string LeeFile = "LEE W HAMPTON 199121 Cigna Medicare Commission 2023-02-17.xlsx";
        private const string ComprehensiveFile = "COMPREHENSIVE BENEFITS, LLC 0000111362 Cigna Medicare Commission 2023-03....xlsx";
        private const string Cynthia1File = "CYNTHIA A GONZALEZ 0000164054 Cigna Medicare Commission 20210108.xlsx";
        private const string Cynthia2File = "CYNTHIA A GONZALEZ 0000164054 Cigna Medicare Commission 20211126.xlsx";
        private const string Cynthia3File = "CYNTHIA A GONZALEZ 0000164054 Cigna Medicare Commission 20220128.xlsx";
        private const string Cynthia4File = "CYNTHIA A GONZALEZ 0000164054 Cigna Medicare Commission 20210115.xls";

        //
        // Note: Most of these test cases are taken from real-world errors.
        //
        [TestCase(BartGoodFile,
             "BART SIMPSON",
             "0123456789",
             "2023-02-17",
             "xlsx",
             true,
             false,
             "OK",
             "OK",
             "OK",
             "OK",
             "OK"),
         
         TestCase(LeeFile,
             "LEE W HAMPTON",
             "199121",
             "2023-02-17", "xlsx",
             false,
             true,
             "OK",
             "Expected 10 digits; actual length is 6",
             "OK",
             "OK",
             "OK"),

         TestCase(ComprehensiveFile,
             "COMPREHENSIVE BENEFITS, LLC",
             "0000111362",
             "2023-03...", "xlsx",
             false,
             true,
             "OK",
             "OK",
             "OK",
             "Expected 'yyyy-mm-dd'; found '2023-03...'",
             "OK"),

         TestCase(Cynthia1File,
             "CYNTHIA A GONZALEZ",
             "0000164054",
             "20210108",
             "xlsx",
             false, true,
             "OK",
             "OK",
             "OK",
             "Expected 'yyyy-mm-dd'; found '20210108'",
             "OK"),

         TestCase(Cynthia2File,
             "CYNTHIA A GONZALEZ",
             "0000164054",
             "20211126",
             "xlsx",
             false, true,
             "OK",
             "OK",
             "OK",
             "Expected 'yyyy-mm-dd'; found '20211126'",
             "OK"),

         TestCase(Cynthia3File,
             "CYNTHIA A GONZALEZ",
             "0000164054",
             "20220128",
             "xlsx",
             false, true,
             "OK",
             "OK",
             "OK",
             "Expected 'yyyy-mm-dd'; found '20220128'",
             "OK"),

         TestCase(Cynthia4File,
             "CYNTHIA A GONZALEZ",
             "0000164054",
             "20210115",
             "xls",
             false, true,
             "OK",
             "OK",
             "OK",
             "Expected 'yyyy-mm-dd'; found '20210115'",
             "Expected an extension of 'xlsx'; found 'xls'")]
        public void Compensation_NewObjectIsBuiltWithExpectedPropertyValues(
            string fileName,
            string expectedPayeeName,
            string expectedVendorId,
            string expectedEffectiveDate,
            string expectedExtension,
            bool expectedToParse,
            bool expectedPartialMatch,
            string expectedPayeeNameStatus,
            string expectedVendorIdStatus,
            string expectedStatementIdentifierStatus,
            string expectedEffectiveDateStatus,
            string expectedExtensionStatus)
        {
            var result = new Compensation(fileName);
            Assert.Multiple(() =>
            {
                Assert.That(result.PayeeName, Is.EqualTo(expectedPayeeName));
                Assert.That(result.VendorId, Is.EqualTo(expectedVendorId));
                Assert.That(result.EffectiveDateString, Is.EqualTo(expectedEffectiveDate));
                Assert.That(result.FileExtension, Is.EqualTo(expectedExtension));
                Assert.That(result.SuccessfullyParsed, Is.EqualTo(expectedToParse));
                Assert.That(result.PartialMatch, Is.EqualTo(expectedPartialMatch));
                Assert.That(result.PayeeNameStatus, Is.EqualTo(expectedPayeeNameStatus));
                Assert.That(result.VendorIdStatus, Is.EqualTo(expectedVendorIdStatus));
                Assert.That(result.StatementIdentifierStatus, Is.EqualTo(expectedStatementIdentifierStatus));
                Assert.That(result.EffectiveDateStatus, Is.EqualTo(expectedEffectiveDateStatus));
                Assert.That(result.FileExtensionStatus, Is.EqualTo(expectedExtensionStatus));
            });
        }

        [TestCase(BartBadFile)]
        public void Compensation_NewObjectFailsGracefully(string fileName)
        {
            var result = new Compensation(fileName);
            Assert.Multiple(() =>
            {
                Assert.That(result.SuccessfullyParsed, Is.False);
                Assert.That(result.PartialMatch, Is.False);

                Assert.That(result.PayeeName, Is.EqualTo("Could not parse"));
                Assert.That(result.VendorId, Is.EqualTo("Could not parse"));
                Assert.That(result.EffectiveDateString, Is.EqualTo("Could not parse"));
                Assert.That(result.FileExtension, Is.EqualTo("Could not parse"));

                Assert.That(result.PayeeNameStatus, Is.EqualTo("INVALID"));
                Assert.That(result.VendorIdStatus, Is.EqualTo("INVALID"));
                Assert.That(result.StatementIdentifierStatus, Is.EqualTo("INVALID"));
                Assert.That(result.EffectiveDateStatus, Is.EqualTo("INVALID"));
                Assert.That(result.FileExtensionStatus, Is.EqualTo("INVALID"));
            });
        }

        [TestCase(BartBadFile, BartResult)]
        [TestCase(ComprehensiveFile, ComprehensiveResult)]
        [TestCase(Cynthia1File, Cynthia1Result)]
        [TestCase(Cynthia4File, Cynthia4Result)]
        [TestCase(LeeFile, LeeResult)]
        public void BadFileNameEmailBody_CreatesExpectedEmail(string fileName, string expectedEmailBody)
        {
            var compensation = new Compensation(fileName);
            Assert.That(compensation.BadFileNameEmailBody(), Is.EqualTo(expectedEmailBody));
        }

        private const string BartResult = @"
<html>
  <head>
      <style>
        body { 
          font-family: Calibri, Arial, sans-serif;
          font-size: 11pt;
        }

        table, th, td {
          border-style: solid;
          border-width: 1px;
          border-color: #237eb8;
          padding: 4px;
          margin: 0 0 0 0;
          border-collapse: collapse;
        }

        tr {
          margin: 0 0 0 0;
        }

        th {
          background-color: #237eb8;
          border-color: #ffffff;
          color: #ffffff;
        }

        .mono-spaced {
          font-family: ""Cascadia Code"", Consolas, ""Courier New"", Courier, monospace;
        }

        .centered {
          text-align: center;
        }

        .error {
          color: red;
          font-weight: bold;
        }

        .okay {
          color: green;
          font-weight: bold;
        }
      </style>
</head>
  <body>
<h1>Error Adding Compensation File</h1>
<p>The file ""<span class='error mono-spaced'>BART SIMPSON yellow Cigna Medicare Commission ballyhoo.xlsx</span>"" could not be added to today's compensation archive for <em>Cigna for Brokers</em>.</p>
<p>The file name does not conform to the pattern: ""<span class='mono-spaced'><em>Payee_Name</em> <em>9999999999</em> Cigna Medicare Commission <em>yyyy-mm-dd</em>.xlsx</span>"".</p>
<p class='mono-spaced'>
Payee&nbsp;Name&nbsp;&nbsp;&nbsp;&nbsp;: <span class='error'>INVALID</span><br/>
Vendor&nbsp;ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span class='error'>INVALID</span><br/>
Statement&nbsp;Type: <span class='error'>INVALID</span><br/>
Effective&nbsp;Date: <span class='error'>INVALID</span><br/>
File&nbsp;Extension: <span class='error'>INVALID</span><br/>
</p>
<p>The file will be skipped.  Please correct the file name and re-submit with the next batch.</p>

  </body>
</html>
";

        private const string ComprehensiveResult = @"
<html>
  <head>
      <style>
        body { 
          font-family: Calibri, Arial, sans-serif;
          font-size: 11pt;
        }

        table, th, td {
          border-style: solid;
          border-width: 1px;
          border-color: #237eb8;
          padding: 4px;
          margin: 0 0 0 0;
          border-collapse: collapse;
        }

        tr {
          margin: 0 0 0 0;
        }

        th {
          background-color: #237eb8;
          border-color: #ffffff;
          color: #ffffff;
        }

        .mono-spaced {
          font-family: ""Cascadia Code"", Consolas, ""Courier New"", Courier, monospace;
        }

        .centered {
          text-align: center;
        }

        .error {
          color: red;
          font-weight: bold;
        }

        .okay {
          color: green;
          font-weight: bold;
        }
      </style>
</head>
  <body>
<h1>Error Adding Compensation File</h1>
<p>The file name below does not conform to the file name guidelines:</p>
<p class='mono-spaced centered'>
<span class='okay'>COMPREHENSIVE BENEFITS, LLC</span> <span class='okay'>0000111362</span><span class='okay'> Cigna Medicare Commission </span><span class='error'>2023-03...</span>.<span class='okay'>xlsx</span></p>
<p class='mono-spaced'>
Payee&nbsp;Name&nbsp;&nbsp;&nbsp;&nbsp;: <span class='okay'>OK</span><br/>
Vendor&nbsp;ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span class='okay'>OK</span><br/>
Statement&nbsp;Type: <span class='okay'>OK</span><br/>
Effective&nbsp;Date: <span class='error'>Expected 'yyyy-mm-dd'; found '2023-03...'</span><br/>
File&nbsp;Extension: <span class='okay'>OK</span><br/>
</p>
<p>The file will be skipped.  Please correct the file name and re-submit with the next batch.</p>

  </body>
</html>
";

        private const string Cynthia1Result = @"
<html>
  <head>
      <style>
        body { 
          font-family: Calibri, Arial, sans-serif;
          font-size: 11pt;
        }

        table, th, td {
          border-style: solid;
          border-width: 1px;
          border-color: #237eb8;
          padding: 4px;
          margin: 0 0 0 0;
          border-collapse: collapse;
        }

        tr {
          margin: 0 0 0 0;
        }

        th {
          background-color: #237eb8;
          border-color: #ffffff;
          color: #ffffff;
        }

        .mono-spaced {
          font-family: ""Cascadia Code"", Consolas, ""Courier New"", Courier, monospace;
        }

        .centered {
          text-align: center;
        }

        .error {
          color: red;
          font-weight: bold;
        }

        .okay {
          color: green;
          font-weight: bold;
        }
      </style>
</head>
  <body>
<h1>Error Adding Compensation File</h1>
<p>The file name below does not conform to the file name guidelines:</p>
<p class='mono-spaced centered'>
<span class='okay'>CYNTHIA A GONZALEZ</span> <span class='okay'>0000164054</span><span class='okay'> Cigna Medicare Commission </span><span class='error'>20210108</span>.<span class='okay'>xlsx</span></p>
<p class='mono-spaced'>
Payee&nbsp;Name&nbsp;&nbsp;&nbsp;&nbsp;: <span class='okay'>OK</span><br/>
Vendor&nbsp;ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span class='okay'>OK</span><br/>
Statement&nbsp;Type: <span class='okay'>OK</span><br/>
Effective&nbsp;Date: <span class='error'>Expected 'yyyy-mm-dd'; found '20210108'</span><br/>
File&nbsp;Extension: <span class='okay'>OK</span><br/>
</p>
<p>The file will be skipped.  Please correct the file name and re-submit with the next batch.</p>

  </body>
</html>
";

        private const string Cynthia4Result = @"
<html>
  <head>
      <style>
        body { 
          font-family: Calibri, Arial, sans-serif;
          font-size: 11pt;
        }

        table, th, td {
          border-style: solid;
          border-width: 1px;
          border-color: #237eb8;
          padding: 4px;
          margin: 0 0 0 0;
          border-collapse: collapse;
        }

        tr {
          margin: 0 0 0 0;
        }

        th {
          background-color: #237eb8;
          border-color: #ffffff;
          color: #ffffff;
        }

        .mono-spaced {
          font-family: ""Cascadia Code"", Consolas, ""Courier New"", Courier, monospace;
        }

        .centered {
          text-align: center;
        }

        .error {
          color: red;
          font-weight: bold;
        }

        .okay {
          color: green;
          font-weight: bold;
        }
      </style>
</head>
  <body>
<h1>Error Adding Compensation File</h1>
<p>The file name below does not conform to the file name guidelines:</p>
<p class='mono-spaced centered'>
<span class='okay'>CYNTHIA A GONZALEZ</span> <span class='okay'>0000164054</span><span class='okay'> Cigna Medicare Commission </span><span class='error'>20210115</span>.<span class='error'>xls</span></p>
<p class='mono-spaced'>
Payee&nbsp;Name&nbsp;&nbsp;&nbsp;&nbsp;: <span class='okay'>OK</span><br/>
Vendor&nbsp;ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span class='okay'>OK</span><br/>
Statement&nbsp;Type: <span class='okay'>OK</span><br/>
Effective&nbsp;Date: <span class='error'>Expected 'yyyy-mm-dd'; found '20210115'</span><br/>
File&nbsp;Extension: <span class='error'>Expected an extension of 'xlsx'; found 'xls'</span><br/>
</p>
<p>The file will be skipped.  Please correct the file name and re-submit with the next batch.</p>

  </body>
</html>
";

        private const string LeeResult = @"
<html>
  <head>
      <style>
        body { 
          font-family: Calibri, Arial, sans-serif;
          font-size: 11pt;
        }

        table, th, td {
          border-style: solid;
          border-width: 1px;
          border-color: #237eb8;
          padding: 4px;
          margin: 0 0 0 0;
          border-collapse: collapse;
        }

        tr {
          margin: 0 0 0 0;
        }

        th {
          background-color: #237eb8;
          border-color: #ffffff;
          color: #ffffff;
        }

        .mono-spaced {
          font-family: ""Cascadia Code"", Consolas, ""Courier New"", Courier, monospace;
        }

        .centered {
          text-align: center;
        }

        .error {
          color: red;
          font-weight: bold;
        }

        .okay {
          color: green;
          font-weight: bold;
        }
      </style>
</head>
  <body>
<h1>Error Adding Compensation File</h1>
<p>The file name below does not conform to the file name guidelines:</p>
<p class='mono-spaced centered'>
<span class='okay'>LEE W HAMPTON</span> <span class='error'>199121</span><span class='okay'> Cigna Medicare Commission </span><span class='okay'>2023-02-17</span>.<span class='okay'>xlsx</span></p>
<p class='mono-spaced'>
Payee&nbsp;Name&nbsp;&nbsp;&nbsp;&nbsp;: <span class='okay'>OK</span><br/>
Vendor&nbsp;ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <span class='error'>Expected 10 digits; actual length is 6</span><br/>
Statement&nbsp;Type: <span class='okay'>OK</span><br/>
Effective&nbsp;Date: <span class='okay'>OK</span><br/>
File&nbsp;Extension: <span class='okay'>OK</span><br/>
</p>
<p>The file will be skipped.  Please correct the file name and re-submit with the next batch.</p>

  </body>
</html>
";
    }
}
