﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.RepositoryContracts;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Text.Json;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Controllers
{
    /// <summary>
    /// Controller for all basic Broker-related requests.
    /// </summary>
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/brokers/")]
    [Authorize]
    public class BrokersController : ExtendedStatusCodesController
    {
        private readonly IBrokerDataRepository _repository;
        /// <summary>
        /// Injection-based constructor for the BrokersController class.
        /// </summary>
        public BrokersController(IBrokerDataRepository repository)
        {
            _repository = repository ?? throw new ArgumentException($"{nameof(repository)} parameter cannot be null!");
        }

        /// <summary>
        /// Gets all incomplete applications associated with the requested broker.
        /// </summary>
        /// <param name="producerCode">The broker's Producer Code identifier</param>
        /// <param name="serviceReferenceId">The service reference ID, usually a GUID.  The service will create one and return it in the response if one is not supplied.</param>
        /// <param name="useMetadataResponse">Determines whether normal HTTP response codes will be used or if all responses will return a 200 OK code with additional metadata in the response body. </param>
        /// <returns>An IActionResult</returns>
        /// <response code="200">
        ///     A response object containing a summary of incomplete applications for the referenced
        ///     broker and, optionally, a metadata response object.
        /// </response>
        /// <response code="401">
        ///     The request credentials could not be authenticated.
        /// </response>
        /// <response code="404">
        ///     The provider code was not found.  This indicates that the producer code does not exist
        ///     in the MRDE/SalesForce database at the time of the request.
        /// </response>
        /// <response code="500">
        ///     Catastrophic error.  Something unexpected happened while processing the request.
        ///     Contact Digital Applications Product Support and be prepared to mention the "BAM"
        ///     API and the service_reference_id of the request.
        /// </response>
        [Route("rfi"), HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<RequestForInformationResponse>> GetBrokerRequestsForInformation(
            [FromQuery, Required] string producerCode,
            [FromHeader(Name = "service_reference_id")] string? serviceReferenceId = null,
            [FromHeader(Name = "suppress_response_code")] bool useMetadataResponse = false)
        {
            //
            // Note: LogRequest has the intentional side-effect of ensuring that serviceReferenceId is always non-null.
            //
            LogRequest(
                nameof(GetBrokerRequestsForInformation),
                JsonSerializer.Serialize(new { producerCode, useMetadataResponse }),
                ref serviceReferenceId);

            try
            {
                //
                // Is this a producer code that we recognize?
                //
                if (!await _repository.ProducerCodeExistsAsync(producerCode))
                {
                    return NotFound(
                        $"Producer code '{producerCode}' could not be located by the service.",
                        10001,
                        serviceReferenceId!,
                        useMetadataResponse);
                }

                //
                // Get the available RFIs for this producer code.
                //
                var response = new RequestForInformationResponse
                {
                    RequestsForInformation = await _repository.GetRequestsForInformationAsync(producerCode)
                };

                return Ok(response, serviceReferenceId!, useMetadataResponse);
            }
            catch (Exception exception)
            {
                string message = $"Error while getting RFIs for producerCode '{producerCode}'.";
                return ServerError(
                    message,
                    resultCode: 10002,
                    exception,
                    serviceReferenceId!,
                    useMetadataResponse);
            }
        }

        /// <summary>
        /// Gets a summary of broker notifications for the Broker Dashboard
        /// </summary>
        /// <param name="producerCode">The broker's Producer Code identifier</param>
        /// <param name="serviceReferenceId">The service reference ID, usually a GUID.  The service will create one and return it in the response if one is not supplied.</param>
        /// <param name="useMetadataResponse">Determines whether normal HTTP response codes will be used or if all responses will return a 200 OK code with additional metadata in the response body. </param>
        /// <returns>An IActionResult</returns>
        /// <response code="200">
        ///     A response object containing a summary of incomplete applications for the referenced
        ///     broker and, optionally, a metadata response object.
        /// </response>
        /// <response code="401">
        ///     The request credentials could not be authenticated.
        /// </response>
        /// <response code="404">
        ///     The provider code was not found.  This indicates that the producer code does not exist
        ///     in the MRDE/SalesForce database at the time of the request.
        /// </response>
        /// <response code="500">
        ///     Catastrophic error.  Something unexpected happened while processing the request.
        ///     Contact Digital Applications Product Support and be prepared to mention the "BAM"
        ///     API and the service_reference_id of the request.
        /// </response>
        [Route("notifications"), HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<NotificationResponse>> GetBrokerNotifications(
            [FromQuery, Required] string producerCode,
            [FromHeader(Name = "service_reference_id")] string? serviceReferenceId = null,
            [FromHeader(Name = "suppress_response_code")] bool useMetadataResponse = false)
        {
            //
            // Note: LogRequest has the intentional side-effect of ensuring that serviceReferenceId is always non-null.
            //
            LogRequest(
                nameof(GetBrokerNotifications),
                JsonSerializer.Serialize(new { producerCode, useMetadataResponse }),
                ref serviceReferenceId);

            try
            {
                //
                // Is this a producer code that we recognize?
                //
                if (!await _repository.ProducerCodeExistsAsync(producerCode))
                {
                    return NotFound(
                        $"Producer code '{producerCode}' could not be located.",
                        10011,
                        serviceReferenceId!,
                        useMetadataResponse);
                }

                var response = new NotificationResponse()
                {
                    Notifications = new Notification()
                    {
                        Licenses = new List<LicenseNotification>(),
                        AppointmentContractLicenses = new List<AppointmentContractedAndLicensedNotification>()
                    }
                };

                var repositoryResponse = await _repository.GetBrokerNotificationsAsync(producerCode);
                response.Notifications.Licenses = repositoryResponse.Item1;
                response.Notifications.AppointmentContractLicenses = repositoryResponse.Item2;

                return Ok(response, serviceReferenceId!, useMetadataResponse);
            }
            catch (Exception exception)
            {
                string message = $"Error while getting notifications for producerCode {producerCode}.";
                return ServerError(message, 10012, exception, serviceReferenceId!, useMetadataResponse);
            }
        }

    }
}
