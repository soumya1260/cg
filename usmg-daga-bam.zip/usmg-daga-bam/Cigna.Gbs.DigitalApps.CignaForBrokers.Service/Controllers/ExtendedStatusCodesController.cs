﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Controllers
{
    /// <summary>
    /// Abstract class supporting the return of metadata instead of non-200
    /// HTTP response codes.
    /// </summary>
    public abstract class ExtendedStatusCodesController : ControllerBase
    {
        const string ReferenceIdToken = "service-reference-id";

        /// <summary>
        /// Informs the client that the request was processed successfully.
        /// </summary>
        /// <param name="value">Response payload to be returned to the client</param>
        /// <param name="serviceReferenceId">Unique identifier for this request</param>
        /// <param name="useMetadataResponse"></param>
        /// <returns></returns>
        protected OkObjectResult Ok(
            ApiResponse value,
            string serviceReferenceId,
            bool useMetadataResponse)
        {
            if (useMetadataResponse)
            {
                value.ApiMetadata = new ApiMetadata
                {
                    ServiceReferenceId = serviceReferenceId,
                    HttpOutcome = new HttpOutcome
                    {
                        StatusCode = 200,
                        Type = "OK",
                        Message = "Successful",
                        ResultCode = 0,
                        AdditionalDetails = new List<ErrorDetail>()
                    }
                };
            }
            else
            {
                Response.Headers.Add(ReferenceIdToken, serviceReferenceId);
            }

            return Ok(value);
        }

        /// <summary>
        /// Returns a 404 HTTP response code or a metadata equivalent.
        /// </summary>
        /// <param name="message">Message to be included in the metadata response.</param>
        /// <param name="resultCode">Unique diagnostic code indicating where the 404 was detected.</param>
        /// <param name="serviceReferenceId"></param>
        /// <param name="useMetadataResponse"></param>
        /// <returns></returns>
        protected ActionResult NotFound(
            string message,
            int resultCode,
            string serviceReferenceId,
            bool useMetadataResponse)
        {
            if (useMetadataResponse)
            {
                var response = new ApiResponse
                {
                    ApiMetadata = new ApiMetadata
                    {
                        ServiceReferenceId = serviceReferenceId,
                        HttpOutcome = new HttpOutcome
                        {
                            StatusCode = 404,
                            Type = "Not Found",
                            Message = message,
                            ResultCode = resultCode,
                            AdditionalDetails = new List<ErrorDetail>()
                        }
                    }
                };
                return Ok(response);
            }

            Response.Headers.Add(ReferenceIdToken, serviceReferenceId);
            return NotFound();
        }

        /// <summary>
        /// Informs the client that an internal server error has occurred.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="resultCode"></param>
        /// <param name="exception"></param>
        /// <param name="serviceReferenceId"></param>
        /// <param name="useMetadataResponse"></param>
        /// <returns></returns>
        protected ObjectResult ServerError(
            string message,
            int resultCode,
            Exception exception,
            string serviceReferenceId,
            bool useMetadataResponse)
        {
            Log.Error(
                $"{serviceReferenceId}: {message} - RESULT: {resultCode}",
                message,
                exception);

            if (useMetadataResponse)
            {

                var additionalDetails = new List<ErrorDetail>
                {
                    new()
                    {
                        Severity = "ERROR",
                        Message = exception.Message,
                        Code = exception.HResult
                    }
                };

                var innerException = exception.InnerException;
                while (innerException != null)
                {
                    additionalDetails.Add(
                        new ErrorDetail
                        {
                            Severity = "ERROR",
                            Message = innerException.Message,
                            Code = innerException.HResult
                        });
                    innerException = innerException.InnerException;
                }

                var response = new ApiResponse
                {
                    ApiMetadata = new ApiMetadata
                    {
                        ServiceReferenceId = serviceReferenceId,
                        HttpOutcome = new HttpOutcome
                        {
                            StatusCode = 500,
                            Type = "InternalServerError",
                            Message = message,
                            ResultCode = resultCode,
                            AdditionalDetails = additionalDetails
                        }
                    }
                };
                return Ok(response);
            }

            Response.Headers.Add(ReferenceIdToken, serviceReferenceId);
            return StatusCode(StatusCodes.Status500InternalServerError, message);
        }

        /// <summary>
        /// Used to log each API request.
        /// </summary>
        /// <param name="requestName">Name of the method called.</param>
        /// <param name="parameters">A JSON-formatted list of important parameters.</param>
        /// <param name="serviceReferenceId">The service reference identifier.  If null or empty, a GUID will be generated for it.</param>
        /// <param name="userName">The authenticated user making the request.</param>
        protected void LogRequest(
            string requestName,
            string parameters,
            ref string? serviceReferenceId,
            string userName = "unknown")
        {
            if (string.IsNullOrWhiteSpace(serviceReferenceId)) serviceReferenceId = Guid.NewGuid().ToString();
            Log.Information($"{serviceReferenceId}: User '{userName}' called '{requestName}' with parameters '{parameters}'.");
        }

    }
}
