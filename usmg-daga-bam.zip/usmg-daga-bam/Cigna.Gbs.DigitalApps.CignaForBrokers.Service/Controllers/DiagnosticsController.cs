﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.RepositoryContracts;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects;
using Microsoft.AspNetCore.Mvc;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/diagnostics")]
    [ApiController]
    public class DiagnosticsController : ControllerBase
    {
        private readonly IWebHostEnvironment _environment;
        private readonly IBrokerDataRepository _repository;

        /// <summary>
        /// Injecting constructor.
        /// </summary>
        /// <param name="environment">An IWebHostEnvironment object containing the current environment information</param>
        /// <param name="repository">An IBrokerDataRepository object to be used for broker data interactions</param>
        public DiagnosticsController(
            IWebHostEnvironment environment,
            IBrokerDataRepository repository)
        {
            _environment = environment;
            _repository = repository;
        }
        
        /// <summary>
        /// Used to validate that the service is running.
        /// </summary>
        /// <returns>a PingResponse object indicating the health of the service.</returns>
        [Route("ping"), HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<PingResponse>> Ping()
        {
            bool selfTestResult = await SelfTestAsync();

            var response = new PingResponse
            {
                Environment = _environment.EnvironmentName,
                HostName = _environment.IsEnvironment("Prod") || _environment.IsProduction() 
                    ? null 
                    : System.Net.Dns.GetHostName(),
                SelfTestResult = selfTestResult ? "PASSED" : "FAILED"
            };

            return await Task.FromResult(response);
        }

        private async Task<bool> SelfTestAsync()
        {
            return await _repository.DatabaseConnectionIsGoodAsync();
        }
    }
}
