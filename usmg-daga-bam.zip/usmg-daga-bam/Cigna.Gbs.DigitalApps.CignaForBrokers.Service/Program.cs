using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.RepositoryContracts;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Contexts;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Repositories;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Primitives;
using Microsoft.Net.Http.Headers;
using Microsoft.OpenApi.Models;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.IdentityModel.Tokens.Jwt;
using System.Reflection;
using System.Text.Json.Serialization;
using Microsoft.IdentityModel.Tokens;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service
{
    /// <summary>
    /// Primary entry point for web service.
    /// </summary>
    [ExcludeFromCodeCoverage] // Because this really only contains start-up configuration actions.
    public static class Program
    {
        /// <summary>
        /// Main.  Gotta have it.
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            //
            // Create the web application container.
            //
            var webApplicationBuilder = WebApplication.CreateBuilder(args);

            webApplicationBuilder.InitializeLogger();
            LogStartupBanner(webApplicationBuilder);
            
            webApplicationBuilder.Services.InjectDependencies();
            webApplicationBuilder.Services.AddControllersWithOptions();
            webApplicationBuilder.Services.AddEndpointsApiExplorer();
            webApplicationBuilder.Services.BuildSwaggerService();
            webApplicationBuilder.Services.AddMultiSchemeJwtBearerAuthentication(webApplicationBuilder.Configuration);
            webApplicationBuilder.Services.AddMultiSchemeAuthorization(webApplicationBuilder.Configuration);
            webApplicationBuilder.Services.AddApiVersioningWithDefaults(1, 0);

            LogConfiguredJwtAuthorities(webApplicationBuilder.Configuration);

            var webApplication = webApplicationBuilder.Build();

            webApplication.UseSwaggerInTestEnvironments();
            webApplication.UseHttpsRedirection();
            webApplication.UseAuthentication();
            webApplication.UseAuthorization();
            webApplication.MapControllers();
            webApplication.Run();
        }

        #region WebApplicationBuilder extension methods

        private static void InitializeLogger(this WebApplicationBuilder builder)
        {
            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(builder.Configuration)
                .Enrich.FromLogContext()
                .CreateLogger();

            builder.Logging.ClearProviders();
            builder.Logging.AddSerilog(Log.Logger);
        }

        #endregion
        
        #region IServiceCollection extension methods

        private static void AddControllersWithOptions(this IServiceCollection services)
        {
            services
                .AddControllers()
                .AddJsonOptions(
                    options =>
                    {
                        //
                        // Don't serialize null fields.
                        //
                        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
                    });
        }

        private static void InjectDependencies(this IServiceCollection services)
        {
            services.AddSingleton<SimpleDatabaseContext, MrdeDatabaseContext>();
            services.AddScoped<IBrokerDataRepository, MrdeBrokerDataRepository>();
        }

        private static void AddApiVersioningWithDefaults(
            this IServiceCollection services,
            int majorVersion,
            int minorVersion)
        {
            services.AddApiVersioning(setupAction =>
                {
                    setupAction.AssumeDefaultVersionWhenUnspecified = true;
                    setupAction.DefaultApiVersion = new Microsoft.AspNetCore.Mvc.ApiVersion(majorVersion, minorVersion);
                    setupAction.ReportApiVersions = true;
                });
        }

        private static void BuildSwaggerService(this IServiceCollection services)
        {
            services.AddSwaggerGen(
                setupAction =>
                {
                    //
                    // Service documentation
                    //
                    var xmlCommentsFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                    var xmlCommentsFullPath = Path.Combine(AppContext.BaseDirectory, xmlCommentsFile);

                    setupAction.IncludeXmlComments(xmlCommentsFullPath);

                    //
                    // Domain documentation
                    //
                    xmlCommentsFile = $"{typeof(Notification).Assembly.GetName().Name}.xml";
                    xmlCommentsFullPath = Path.Combine(AppContext.BaseDirectory, xmlCommentsFile);
                    setupAction.IncludeXmlComments(xmlCommentsFullPath);

                    //
                    // Bearer authentication
                    //
                    var jwtSecurityScheme = new OpenApiSecurityScheme
                    {
                        Scheme = JwtBearerDefaults.AuthenticationScheme,
                        BearerFormat = "JWT",
                        Name = "Authorization",
                        In = ParameterLocation.Header,
                        Type = SecuritySchemeType.Http,
                        Description = "Enter your bearer token below.  Do not include the \"Bearer\" prefix.",

                        Reference = new OpenApiReference
                        {
                            Id = JwtBearerDefaults.AuthenticationScheme,
                            Type = ReferenceType.SecurityScheme
                        }
                    };

                    setupAction.AddSecurityDefinition(jwtSecurityScheme.Reference.Id, jwtSecurityScheme);

                    setupAction.AddSecurityRequirement(new() { { jwtSecurityScheme, Array.Empty<string>() } });
                });
        }

        private static void AddMultiSchemeJwtBearerAuthentication(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            var schemes = configuration
                .GetSection("JwtAuthorities")
                .GetChildren()
                .DistinctBy(s => s["Name"])
                .ToList();

            //
            // .NET 6 and later requires a default scheme.
            //
            var authenticationBuilder = services.AddAuthentication(
                options =>
                {
                    options.DefaultScheme = schemes.First()["Name"];
                });

            foreach (var scheme in schemes)
            {
                authenticationBuilder.AddJwtBearer(
                    scheme["Name"],
                    options =>
                    {
                        options.Audience = scheme["Audience"];
                        options.Authority = scheme["Authority"] ?? scheme["Issuer"];

                        options.TokenValidationParameters = new TokenValidationParameters
                        {
                            ValidateIssuer = true,
                            ValidateAudience = true,
                            ValidateLifetime = true
                        };
                    });
            }

            AddSchemeSelector(authenticationBuilder, schemes);
        }

        private static void AddMultiSchemeAuthorization(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddAuthorization(options =>
            {
                options.DefaultPolicy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .AddAuthenticationSchemes(configuration
                        .GetSection("JwtAuthorities")
                        .GetChildren()
                        .DistinctBy(s => s["Name"])
                        .Select(a => a["Name"]).ToArray())
                    .Build();
            });
        }

        #endregion 

        #region WebApplication extension methods

        private static void UseSwaggerInTestEnvironments(this WebApplication webApplication)
        {
            if (!(webApplication.Environment.IsProduction() || webApplication.Environment.IsEnvironment("Prod")))
            {
                webApplication.UseSwagger();
                webApplication.UseSwaggerUI();
            }
        }

        #endregion

        #region Support methods

        private static void LogStartupBanner(WebApplicationBuilder builder)
        {
            var assembly = typeof(Program).Assembly;
            Log.Information("*********************************************************************");
            Log.Information($"BAM! Web API Release {assembly.GetName().Version}");
            Log.Information($"{assembly.GetCustomAttribute<AssemblyCopyrightAttribute>()?.Copyright}");
            Log.Information($"Environment: {builder.Environment.EnvironmentName}");
            Log.Information("*********************************************************************");

            Log.Information($"BAM! Web API started.");
        }

        private static void LogConfiguredJwtAuthorities(IConfiguration configuration)
        {
            var schemes = configuration
                .GetSection("JwtAuthorities")
                .GetChildren()
                .DistinctBy(s => s["Name"])
                .Select(s => s["Name"])
                .ToList();


            Log.Information(
                "Configured JWT Authorities: {schemeList}", 
                string.Join(", ", schemes));
        }

        private static void AddSchemeSelector(AuthenticationBuilder authenticationBuilder, List<IConfigurationSection> schemes)
        {
            authenticationBuilder.AddPolicyScheme(
                JwtBearerDefaults.AuthenticationScheme,
                "Selector",
                options =>
                {
                    options.ForwardDefaultSelector = context =>
                    {
                        //
                        // Find the first authentication header with a JWT Bearer token whose issuer
                        // contains one of the scheme names and return the found scheme name.
                        //
                        var authHeaderNames = new[]
                        {
                            HeaderNames.Authorization,
                            HeaderNames.WWWAuthenticate
                        };

                        var headers = new StringValues();
                        foreach (var headerName in authHeaderNames)
                        {
                            if (context.Request.Headers.TryGetValue(headerName, out headers) &&
                                !StringValues.IsNullOrEmpty(headers)) { break; }
                        }

                        return StringValues.IsNullOrEmpty(headers) 
                            ? schemes[0]["Name"] 
                            : FindSchemeMatchingSubmittedIssuer(schemes, headers);
                    };
                }
            );
        }

        private static string? FindSchemeMatchingSubmittedIssuer(List<IConfigurationSection> schemes, StringValues headers)
        {
            foreach (var header in headers)
            {
                //
                // Skip past the "Bearer " identifier and extract the JWT token.
                //
                var encodedToken = header[(JwtBearerDefaults.AuthenticationScheme.Length + 1)..];
                var jwtHandler = new JwtSecurityTokenHandler();
                var decodedToken = jwtHandler.ReadJwtToken(encodedToken);

                //
                // See if the issuer matches the issuer in one of the schemes
                //
                var issuer = decodedToken?.Issuer;
                foreach (var scheme in schemes)
                {
                    if (issuer?.Contains(scheme["Name"], StringComparison.InvariantCultureIgnoreCase) == true)
                    {
                        return scheme["Name"];
                    }
                }
            }

            //
            // Issuer wasn't recognized.  Default to the primary scheme and let the
            // framework issue an authentication failure.
            //
            return schemes.First()["Name"];
        }

        #endregion
    }
}