﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects;
using System.Text.Json.Serialization;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects
{
    /// <summary>
    /// Response object for returning broker dashboard notifications regarding licensing and
    /// appointment contract statuses.
    /// </summary>
    public class NotificationResponse : ApiResponse
    {
        /// <summary>
        /// A list of current license and appointment contract status notifications.
        /// </summary>
        [JsonPropertyName("notifications"), JsonPropertyOrder(1)]
        public Notification Notifications { get; init; } = null!;
    }
}
