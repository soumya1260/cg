﻿using System.Text.Json.Serialization;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects
{
    /// <summary>
    /// Error reporting object.
    /// </summary>
    public class ErrorDetail
    {
        /// <summary>
        /// Severity of the error.
        /// </summary>
        [JsonPropertyName("severity")] public string? Severity { get; init; }

        /// <summary>
        /// A description of the error. 
        /// </summary>
        [JsonPropertyName("message")] public string? Message { get; init; }

        /// <summary>
        /// The associated error code. 
        /// </summary>
        [JsonPropertyName("code")] public int? Code { get; init; }
    }
}