﻿namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects
{
    /// <summary>
    /// 
    /// </summary>
    public class PingResponse
    {
        /// <summary>
        /// The current operating environment.  This sources from ASPNETCORE_ENVIRONMENT as defined on the host.
        /// </summary>
        public string Environment { get; init; } = string.Empty;

        /// <summary>
        /// Host name of the system generating the response.  This value will be suppressed in production environments.
        /// </summary>
        public string? HostName { get; init; }

        /// <summary>
        /// PASSED/FAILED result string indicating the overall result of the self-tests.
        /// </summary>
        public string SelfTestResult { get; init; } = string.Empty;
    }
}
