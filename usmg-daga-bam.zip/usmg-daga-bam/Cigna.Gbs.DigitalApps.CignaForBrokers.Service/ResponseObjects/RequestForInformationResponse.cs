﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects;
using System.Text.Json.Serialization;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects
{
    /// <summary>
    /// Response object containing all current Request for Information (RFI) items.
    /// </summary>
    public class RequestForInformationResponse : ApiResponse
    {
        /// <summary>
        /// The list of RFIs.
        /// </summary>
        // ReSharper disable once StringLiteralTypo
        [JsonPropertyName("rfis"), JsonPropertyOrder(1)]
        public List<RequestForInformation>? RequestsForInformation { get; init; }
    }
}