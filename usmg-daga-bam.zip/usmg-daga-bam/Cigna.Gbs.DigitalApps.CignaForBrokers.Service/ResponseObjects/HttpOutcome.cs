﻿using System.Text.Json.Serialization;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects
{
    /// <summary>
    /// Substitute HTTP REST header contained in an API response body.
    /// </summary>
    public class HttpOutcome
    {
        /// <summary>
        /// An HTTP response status code (200, 404, 500, etc.)
        /// </summary>
        [JsonPropertyName("statusCode")]
        public int StatusCode { get; init; }

        /// <summary>
        /// Descriptive text for the status code.
        /// </summary>
        [JsonPropertyName("type")]
        public string? Type { get; init; } = null!;

        /// <summary>
        /// Informational message describing the specifics of the outcome.
        /// </summary>

        [JsonPropertyName("message")]
        public string? Message { get; init; } = null!;

        /// <summary>
        /// An API-specific diagnostic result code that can be used to
        /// reference the specific event in the code where an error or
        /// other extraordinary event was detected.
        /// </summary>
        [JsonPropertyName("code")]
        public int ResultCode { get; init; }

        /// <summary>
        /// Additional information about the result.  This should not
        /// include stack traces or any information that would be likely
        /// to compromise application security.
        /// </summary>
        [JsonPropertyName("additionalDetails")]
        public List<ErrorDetail>? AdditionalDetails { get; init; } = null!;
    }
}