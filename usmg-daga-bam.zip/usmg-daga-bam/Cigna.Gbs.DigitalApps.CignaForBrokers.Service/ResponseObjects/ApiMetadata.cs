﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects;
using System.Text.Json.Serialization;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects
{
    /// <summary>
    /// Metadata container for inclusion in API response bodies.
    /// </summary>
    public class ApiMetadata
    {
        /// <summary>
        /// Service Reference ID to track the request and response.
        /// </summary>
        [JsonPropertyName("serviceReferenceId")]
        public string ServiceReferenceId { get; init; } = null!;

        /// <summary>
        /// A substitute outcome object mimicking return status information that would
        /// normally be supplied in an HTTP response header.
        /// </summary>
        [JsonPropertyName("outcome")]
        public HttpOutcome HttpOutcome { get; init; } = null!;
    }
}