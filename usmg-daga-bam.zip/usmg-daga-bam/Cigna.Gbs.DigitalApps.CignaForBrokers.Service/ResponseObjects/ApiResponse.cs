﻿using System.Text.Json.Serialization;
namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.ResponseObjects
{
    /// <summary>
    /// Base class for all API responses.  Allows for the inclusion of optional metadata in the response.
    /// </summary>
    /// <remarks>
    /// Note that this class can be instantiated without being inherited when returning exceptions, so
    /// it is intentionally not abstract.
    /// </remarks>
    public class ApiResponse
    {
        /// <summary>
        /// Optional metadata to be added to an API response body.
        /// </summary>
        [JsonPropertyName("metadata"), JsonPropertyOrder(100)]
        public ApiMetadata? ApiMetadata { get; set; } = null!;
    }
}