﻿using System.Data.Common;
using System.Diagnostics.CodeAnalysis;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Contexts
{
    /// <summary>
    /// Abstract base class for creating database context objects.
    /// </summary>
    [ExcludeFromCodeCoverage]  // Abstract class whose only inheritors are not currently unit testable.
    public abstract class SimpleDatabaseContext : IDisposable

    {
        /// <summary>
        /// Property containing the context's database connection object.
        /// </summary>
        public DbConnection Connection { get; }

        /// <summary>
        /// Injection constructor.
        /// </summary>
        protected SimpleDatabaseContext(Func<DbConnection> connectionCreator)
        {
            Connection = connectionCreator();
        }

        /// <summary>
        /// Dispose pattern implementation requirement.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposing) return;

            Connection.Dispose();
        }

        /// <inheritdoc />
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
