using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Contexts
{
    /// <summary>
    /// MRDE database context.  Establishes a connection to the MRDE database.
    /// </summary>
    [ExcludeFromCodeCoverage]  // Integrates with database.  Short of resorting to SQL Lite, we'll assume it is not unit testable.
    public class MrdeDatabaseContext : SimpleDatabaseContext
    {
        /// <inheritdoc />
        public MrdeDatabaseContext(IConfiguration configuration) :
            base(() =>
            {
                var builder = new SqlConnectionStringBuilder(configuration.GetConnectionString("MRDE"))
                {
                    //
                    // Password is added to the connection string from a configuration secret.
                    //
                    Password = configuration["MrdeDbPassword"]
                };

                return new SqlConnection(builder.ToString());
            })
        { }

        /// <summary>
        /// Override IDisposable implementation inherited from base class.
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }
    }
}