﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.RepositoryContracts;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Contexts;
using Dapper;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using Serilog;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Repositories
{
    /// <summary>
    /// Broker data repository utilizing the MRDE database.
    /// </summary>
    [ExcludeFromCodeCoverage]  // We currently don't have a good way to mock the database context that won't break Dapper.
    public class MrdeBrokerDataRepository : IBrokerDataRepository
    {
        private readonly IDbConnection _connection;

        /// <summary>
        /// Injection-based constructor.
        /// </summary>
        /// <param name="context">
        /// A database context object that has a valid database connection.
        /// </param>
        public MrdeBrokerDataRepository(SimpleDatabaseContext context)
        {
            _connection = context.Connection;
        }

        /// <inheritdoc />
        public async Task<bool> ProducerCodeExistsAsync(string producerCode)
        {
            return await _connection.ExecuteScalarAsync<bool>(
                ProducerCodeExistsQuery,
                new { ProducerCode = producerCode },
                commandType: CommandType.Text);

        }

        /// <inheritdoc />
        public async Task<List<RequestForInformation>> GetRequestsForInformationAsync(string producerCode)
        {
            var result = await _connection.QueryAsync<RequestForInformation>(
                RfiQuery, new { ProducerCode = producerCode }, commandType: CommandType.Text);

            return result.ToList();
        }

        /// <inheritdoc />
        public async Task<(List<LicenseNotification>, List<AppointmentContractedAndLicensedNotification>)>
            GetBrokerNotificationsAsync(string producerCode)
        {
            var expiringLicenses = await _connection
                .QueryAsync<LicenseNotification>(
                LicenseExpirationQuery,
                new { ProducerCode = producerCode, DaysBeforeExpiration = 30, DaysAfterExpiration = 60 },
                commandType: CommandType.Text);

            var aclDictionary = new Dictionary<string, AppointmentContractedAndLicensedNotification>();
            await _connection
                .QueryAsync<AppointmentContractedAndLicensedNotification, AppointmentContractedAndLicensed, string, AppointmentContractedAndLicensedNotification>(
                    AclQuery,
                    (notification, acl, productCode) =>
                    {
                        if (!aclDictionary
                                .TryGetValue(notification.Status, out var tempNotification))
                        {
                            tempNotification = notification;
                            aclDictionary.Add(notification.Status, notification);
                        }

                        var tempAcl = tempNotification
                            .AppointmentContractLicenses
                            .FirstOrDefault(a => a.EffectiveYear == acl.EffectiveYear && a.StateCode == acl.StateCode);

                        if (tempAcl == null)
                        {
                            tempNotification.AppointmentContractLicenses
                                .Add(new AppointmentContractedAndLicensed
                                {
                                    EffectiveYear = acl.EffectiveYear,
                                    StateCode = acl.StateCode,
                                    ProductCodes = new List<string> { productCode }
                                });
                        }
                        else
                        {
                            tempAcl.ProductCodes.Add(productCode);
                        }

                        return notification;
                    },
                    new { ProducerCode = producerCode, StartYear = DateTime.Now.Year, EndYear = DateTime.Now.Year },
                    splitOn: "EffectiveYear,ProductCode",
                    commandType: CommandType.Text);

            //
            // Re-order the dictionary since dictionaries don't preserve sorting.
            // Not a big O(n) problem since these dictionaries shouldn't have more
            // than three items in them.
            //
            // "zzzz" bit forces blank records to the end.
            //
            var acls = aclDictionary
                .Values
                .OrderBy(acl => string.IsNullOrWhiteSpace(acl.Status) ? "zzzz" : acl.Status)
                .ToList();

            return (expiringLicenses.ToList(), acls);
        }

        /// <inheritdoc />
        public async Task<bool> DatabaseConnectionIsGoodAsync()
        {
            //
            // Validate connection.
            //
            try
            {
                await _connection.ExecuteAsync("SELECT @@SERVERNAME;", commandType: CommandType.Text);
            }
            catch (Exception exception)
            {
                Log.Error(exception, "Could not connect to database because of exception '{@Exception}'.", exception);
                return false;
            }

            //
            // Validate access to one of the MRDE tables.
            //
            try
            {
                var result = await _connection.ExecuteScalarAsync<string?>("SELECT TOP 1 Producer_Code__c FROM MRDE.BH.CONTACT;", commandType: CommandType.Text);
                if (result == null)
                {
                    Log.Error("Table access test returned no data.");
                    return false;
                }

            }
            catch (Exception exception)
            {
                Log.Error(exception, "Could not access table MRDE.BH.CONTACT.  Exception '{@Exception}'.", exception);
                return false;
            }

            return true;
        }

        #region Query strings

        //
        // Upon review, the IIF() is a bit obtuse here.  Basically it returns
        // "numRecords" if numRecords is 0 or 1, and 1 if it is greater.  It 
        // made more sense when I was writing it than it does reviewing it.
        //
        // A better expression of intent would probably be something like
        // the mathematically equivalent:
        //
        // SELECT IIF(NumRecords = 0, 0, 1)
        //
        private const string ProducerCodeExistsQuery = @"
            --
            -- See if a producer code exists.  Return 1 if true; 0 if false;
            --
            -- In the API, we will return a 404 NOT FOUND for both request
            -- types if the result is 0.
            --
            WITH findProducerCodeCte AS (
                SELECT  COUNT(Producer_Code__c) AS NumRecords
                FROM    MRDE.BH.CONTACT (NOLOCK)
                WHERE   Producer_Code__c = @ProducerCode
                AND     @ProducerCode <> ''
                AND     RecordTypeId = '0121U000000lP9lQAE')

            SELECT  IIF (1 >= NumRecords, NumRecords, 1)
            FROM    findProducerCodeCte;";

        private const string RfiQuery = @"
            --
            -- Return all incomplete applications associated with a producer code.
            --
            SELECT      APP.id AS SalesForceId, 
                        APP.[vlocity_ins__Status__c] AS [Status],           -- Not used by API
                        APP.[Licensed_Sales_Representative_Agent_ID__c],    -- Not used by API
                        APP.agent__c AS AgentName,                          -- Not used by API
                        CT.[Producer_Code__c] AS ProducerCode,              -- Not used by API
                        APP.[First_Name__c]                                 AS MemberGivenName,
                        APP.[Last_Name__c]                                  AS MemberSurname,
                        APP.[Medicare_Number__c]                            AS MedicareId,
                        APP.[RFI_Reason_1__c]                               AS ReasonCode,
                        APP.[RFI_Due_Date__c]                               AS DueDate
            FROM        [MRDE].[bh].[vlocity_ins__Application__c] APP (NOLOCK)
            INNER JOIN  MRDE.BH.CONTACT CT (NOLOCK) ON APP.AGENT__C = CT.ID
            WHERE       CT.Producer_Code__c = @ProducerCode
            AND         APP.[vlocity_ins__Status__c] LIKE '%INCOMPLETE%'
            ORDER BY    DueDate ASC, MemberSurname ASC, MemberGivenName ASC;";

        private const string LicenseExpirationQuery = @"
            DECLARE @Today              DATE = GETDATE();
            DECLARE @InvertedDaysBefore DATE = DATEADD(day,-@DaysAfterExpiration, @today);
            DECLARE @InvertedDaysAfter  DATE = DATEADD(day, @DaysBeforeExpiration, @today);

            SELECT      CT.Id,                                  -- Not used by API 
                        CT.Producer_Code__c AS ProducerCode,    -- Not used by API
                        LIC.[NAME],                             -- Not used by API
                        LIC.LicenseId__c                        AS LicenseNumber, 
                        LIC.vlocity_ins__Jurisdiction__c        AS StateCode,
                        LIC.vlocity_ins__EffectiveDate__c       AS EffectiveDate,
                        LIC.vlocity_ins__ExpirationDate__c      AS ExpirationDate,
                        LIC.IsActive__c                         AS Active
            FROM        MRDE.BH.CONTACT CT (NOLOCK)
            LEFT JOIN   MRDE.BH.vlocity_ins__ProducerLicense__c LIC (NOLOCK) ON CT.Id = LIC.vlocity_ins__ProducerId__c
            WHERE       ct.RecordTypeId = '0121U000000lP9lQAE'
            AND         Producer_Code__c = @ProducerCode
            AND         LIC.vlocity_ins__ExpirationDate__c BETWEEN @InvertedDaysBefore AND @InvertedDaysAfter
            ORDER BY    ExpirationDate ASC, StateCode ASC, LicenseNumber ASC;";

        private const string AclQuery = @"
            SELECT      CT.Id,                                  -- Not used by API
                        CT.Producer_Code__c AS ProducerCode,    -- Not used by API
                        ACL.ACL_Status__c                       AS [Status],
                        ACL.EffectiveYear__C                    AS EffectiveYear,
                        ACL.Jurisdiction__c                     AS StateCode,
                        ACL.Plan_Type__c                        AS ProductCode
            FROM        MRDE.BH.CONTACT CT (NOLOCK)
            LEFT JOIN   MRDE.bh.Agent_ACL_Statuses__c ACL (NOLOCK) ON CT.Id = ACL.Contact_ID__c
            WHERE       ct.RecordTypeId = '0121U000000lP9lQAE'
            AND         CT.Producer_Code__c = @ProducerCode
            AND         ACL.EffectiveYear__C BETWEEN @StartYear AND @EndYear
            ORDER BY    [Status] ASC, EffectiveYear ASC, StateCode ASC, ProductCode ASC;";

        #endregion Query strings

    }
}
