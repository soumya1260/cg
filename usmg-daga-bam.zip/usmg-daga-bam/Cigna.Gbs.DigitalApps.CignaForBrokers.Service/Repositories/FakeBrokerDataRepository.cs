﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.RepositoryContracts;
using System.Diagnostics.CodeAnalysis;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Service.Repositories
{
    /// <summary>
    /// Fake broker repository used for testing.
    /// </summary>
    [ExcludeFromCodeCoverage]  // This is a Fake.  Not production code.
    public class FakeBrokerDataRepository : IBrokerDataRepository
    {
        /// <inheritdoc />
        public Task<bool> ProducerCodeExistsAsync(string producerCode)
        {
            //
            // In order to test the exception-handling code, this method will throw when
            // the producerCode is "EXCEPTION"
            //
            if (producerCode == "EXCEPTION")
            {
                try
                {
                    //
                    // This will be the inner exception.
                    //
                    throw new ArgumentException("Really bad producer code!", nameof(producerCode));
                }
                catch (ArgumentException exception)
                {
                    //
                    // This will be the outer exception.
                    //
                    throw new ArgumentException("Really, really bad producer code!", nameof(producerCode), exception);
                }

            }

            return ProducerCodeCheckAsync(producerCode);
        }

        private static async Task<bool> ProducerCodeCheckAsync(string producerCode)
        {
            //
            // 11111 is good.  All others are unrecognized.
            // 
            return await Task.FromResult(producerCode == "11111");
        }

        /// <inheritdoc />
        public async Task<List<RequestForInformation>> GetRequestsForInformationAsync(string producerCode)
        {
            //
            // Static return result.
            //
            var result = new List<RequestForInformation>
            {
                new()
                {
                    MemberGivenName = "RAY",
                    MemberSurname = "JONES",
                    MedicareId = "999999999",
                    ReasonCode = "Incomplete - Duplicate",
                    DueDate = new DateTime(2020,06,21),
                    SalesForceId = "UB40"
                },
                new()
                {
                    MemberGivenName = "AL",
                    MemberSurname = "BUNDY",
                    MedicareId = "000000000",
                    ReasonCode = "Other",
                    DueDate = null,
                    SalesForceId = "THX1138"
                }

            };

            result = result
                .OrderBy(rfi => rfi.DueDate)
                .ThenBy(rfi => rfi.MemberSurname)
                .ThenBy(rfi => rfi.MemberGivenName)
                .ToList();

            return await Task.FromResult(result);
        }

        /// <inheritdoc />
        public async Task<(List<LicenseNotification>, List<AppointmentContractedAndLicensedNotification>)> GetBrokerNotificationsAsync(string producerCode)
        {
            //
            // Static results.
            //
            var licenses = new List<LicenseNotification>
            {
                new()
                {
                    Active = true,
                    EffectiveDate = new DateTime(2020,1,1),
                    ExpirationDate = new DateTime(2022,6, 1),
                    LicenseNumber = "12PARSECS",
                    StateCode = "TN"
                }
            };
            var acls = new List<AppointmentContractedAndLicensedNotification>
            {
                new()
                {
                    AppointmentContractLicenses = new List<AppointmentContractedAndLicensed>
                    {
                        new()
                        {
                            EffectiveYear = 2022,
                            StateCode = "TN",
                            ProductCodes = new List<string>
                            {
                                "1.21GIAGWATTS",
                                "1313MOCKINGBIRDLN"
                            }
                        },
                    },
                    Status = string.Empty
                },
                new()
                {
                    Status = "Ready to sell",
                    AppointmentContractLicenses = new List<AppointmentContractedAndLicensed>
                    {
                        new()
                        {
                            EffectiveYear = 2022,
                            StateCode = "AL",
                            ProductCodes = new List<string>
                            {
                                "221BBAKER",
                                "4PRIVETDRIVE"
                            }
                        },
                    }
                }
            };

            return await Task.FromResult((licenses, acls));
        }

        /// <inheritdoc />
        public Task<bool> DatabaseConnectionIsGoodAsync()
        {
            //
            // Database connection is always good.
            //
            return Task.FromResult(true);
        }
    }
}