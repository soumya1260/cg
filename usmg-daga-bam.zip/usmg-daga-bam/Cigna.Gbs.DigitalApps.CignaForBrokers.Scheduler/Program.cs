using Serilog;
using System.Diagnostics.CodeAnalysis;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler
{
    public static class Program
    {
        [ExcludeFromCodeCoverage]
        public static int Main(string[] args)
        {
            Log.Logger = new LoggerConfiguration()
                .Enrich.FromLogContext()
                .CreateLogger();

            try
            {
                var builder = Host.CreateDefaultBuilder(args)
                    .ConfigureServices(services => { services.AddHostedService<Worker>(); })
                    .UseSerilog((ctx, cfg) => cfg.ReadFrom.Configuration(ctx.Configuration))
                    .UseWindowsService(options => { options.ServiceName = "BAM! Scheduler"; });

                IHost host = builder.Build();
                host.Run();
            }
            catch (Exception exception)
            {
                Log.Fatal(exception, "Host terminated unexpectedly.");
                return 1;
            }
            finally
            {
                Log.CloseAndFlush();
            }

            return 0;
        }
    }
}