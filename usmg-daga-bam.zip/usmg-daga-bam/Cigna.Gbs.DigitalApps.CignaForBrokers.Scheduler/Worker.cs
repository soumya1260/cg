using System.Reflection;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain;
using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Mail;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Scheduler
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;

        public Worker(ILogger<Worker> logger, IConfiguration configuration)
        {
            _logger = logger;
            var factory = TaskConfigurationFactory.Instance;
            factory.Logger = logger;
            factory.ConfigurationManager = configuration;
            factory.MailClient = new CignaInternalMailKitClient(configuration);
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var assembly = typeof(Program).Assembly;
            _logger.LogInformation("*********************************************************************");
            _logger.LogInformation("BAM! Scheduler Release {version}", assembly.GetName().Version);
            _logger.LogInformation("{copyright}", assembly.GetCustomAttribute<AssemblyCopyrightAttribute>()?.Copyright);
            _logger.LogInformation("*********************************************************************");
            _logger.LogInformation("BAM! Scheduler started.");
            var scheduler = TaskScheduling.Scheduler.Instance;
            await Task.Run(() => { scheduler.Start(); }, stoppingToken);
        }
    }
}