﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.RepositoryContracts
{
    /// <summary>
    /// Contract definition for Broker Data repositories.
    /// </summary>
    public interface IBrokerDataRepository
    {
        /// <summary>
        /// Checks to see if the producer code exists in the repository.
        /// </summary>
        /// <param name="producerCode">The producer code to verify</param>
        /// <returns>true if it exists; false otherwise</returns>
        Task<bool> ProducerCodeExistsAsync(string producerCode);

        /// <summary>
        /// Gets a list of incomplete applications related to the supplied producer code.
        /// </summary>
        /// <param name="producerCode">The producer code of the client making the request</param>
        /// <returns>A list of incomplete applications.</returns>
        Task<List<RequestForInformation>> GetRequestsForInformationAsync(string producerCode);

        /// <summary>
        /// Gets broker notifications related to the supplied producer code.
        /// </summary>
        /// <param name="producerCode">The producer code of the client making the request</param>
        /// <returns>A tuple containing a list of license notifications and a list of ACL notifications.</returns>
        Task<(List<LicenseNotification>, List<AppointmentContractedAndLicensedNotification>)>
            GetBrokerNotificationsAsync(string producerCode);

        /// <summary>
        /// Checks to see if the database is accessible using the current configuration.
        /// </summary>
        /// <returns>true if the connection is accessible; false otherwise.</returns>
        Task<bool> DatabaseConnectionIsGoodAsync();
    }
}
