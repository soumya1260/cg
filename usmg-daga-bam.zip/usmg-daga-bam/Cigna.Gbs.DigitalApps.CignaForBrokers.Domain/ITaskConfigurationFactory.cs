﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Mail;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain
{
    /// <summary>
    /// Abstract interface for Task Configuration factories.
    /// </summary>
    public interface ITaskConfigurationFactory
    {
        /// <summary>
        /// Factory method returning an ILogger object.
        /// </summary>
        /// <returns></returns>
        ILogger GetLogger();

        /// <summary>
        /// Factory method returning an IConfiguration object.
        /// </summary>
        /// <returns></returns>
        IConfiguration GetConfigurationManager();

        /// <summary>
        /// Factory method returning an IMailClient object.
        /// </summary>
        /// <returns></returns>
        IMailClient GetMailClient();
    }
}
