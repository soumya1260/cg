﻿namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Mail
{
    /// <summary>
    /// Interface abstraction for mail clients
    /// </summary>
    public interface IMailClient
    {
        /// <summary>
        /// Sends an email
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        bool Send(Message message);

        /// <summary>
        /// Provides the name of the selected IMailClient
        /// </summary>
        string ClientName { get; }
    }
}
