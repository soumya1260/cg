﻿using Microsoft.Extensions.Configuration;
using MailKit.Net.Smtp;
using MimeKit;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Mail
{
    /// <summary>
    /// MailKit implementation of IMailClient
    /// </summary>
    public class CignaInternalMailKitClient: IMailClient
    {
        private readonly string _smtpServer;

        private const int DefaultSmtpPort = 25; // No SSL
        
        /// <summary>
        /// Injection constructor
        /// </summary>
        /// <param name="configuration"></param>
        public CignaInternalMailKitClient(IConfiguration configuration)
        {
            _smtpServer = configuration["SmtpServer"] ?? "localhost";
        }

        /// <summary>
        /// Returns the name of this mail client
        /// </summary>
        public string ClientName => "MailKit for Cigna internal network mail relays";

        /// <inheritdoc />
        public bool Send(Message message)
        {
            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = message.HtmlTextBody, 
                TextBody = message.PlainTextBody
            };

            var outgoingMessage = new MimeMessage
            {
                Subject = message.Subject,
                Body = bodyBuilder.ToMessageBody()
            };

            if (message.From != null) AddAddresses(message.From, outgoingMessage.From);
            if (message.To != null) AddAddresses(message.To, outgoingMessage.To);
            if (message.Cc != null) AddAddresses(message.Cc, outgoingMessage.Cc);
            if (message.Bcc != null) AddAddresses(message.Bcc, outgoingMessage.Bcc);

            using var client = new SmtpClient();
            //
            // Within the Cigna networks, we don't use SSL for SMTP.
            //
            client.Connect(_smtpServer, DefaultSmtpPort);

            //
            // No authentication since our service accounts aren't in the "INTERNAL" realm.
            // Servers must be whitelisted using the tool found at https://getsmtp.cigna.com/
            //
            client.Send(outgoingMessage);
            client.Disconnect(true);

            return true;
        }

        private static void AddAddresses(List<EmailAddress>? source, InternetAddressList destination)
        {
            if (source == null || !source.Any()) return;

            foreach (var address in source)
            {
                destination.Add(new MailboxAddress(address.DisplayName, address.Address));
            }
        }
    }
}