﻿using System.Runtime.Serialization;
#pragma warning disable CS1591

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Mail
{
    /// <summary>
    /// Message class for containing a simple email message.
    /// </summary>
    /// <remarks>
    /// NOTE: Attachments are not currently supported because BAM! currently doesn't send email attachments.
    /// </remarks>
    [DataContract]
    public class Message
    {
        [DataMember] public List<EmailAddress>? From { get; set; }
        [DataMember] public List<EmailAddress>? To { get; set; }
        [DataMember] public List<EmailAddress>? Cc { get; set; }
        [DataMember] public List<EmailAddress>? Bcc { get; set; }
        [DataMember] public string? Subject { get; set; }
        [DataMember] public string? PlainTextBody { get; set; }
        [DataMember] public string? HtmlTextBody { get; set; }
    }
}
