﻿namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Mail
{
    /// <summary>
    /// Fake email client.  Used for testing and localhost development.
    /// </summary>
    public class FakeMailClient : IMailClient
    {
        /// <inheritdoc />
        public bool Send(Message message)
        {
            return true;
        }

        /// <inheritdoc />
        public string ClientName => "Fake mail client";
    }
}
