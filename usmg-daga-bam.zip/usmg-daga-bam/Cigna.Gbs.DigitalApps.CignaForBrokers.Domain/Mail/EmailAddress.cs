﻿using System.Runtime.Serialization;
using System.Text;
// ReSharper disable UnusedMember.Global

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Mail
{
    /// <summary>
    /// Email Address class supporting single and multiple addresses
    /// </summary>
    [DataContract]
    public class EmailAddress
    {
        /// <summary>
        /// Simple constructor for an email address without an associated display name.
        /// </summary>
        /// <param name="address">the RFC 5322 email address</param>
        public EmailAddress(string address)
        {
            DisplayName = Address = address;
        }

        /// <summary>
        /// Constructor for an email address with a display name.
        /// </summary>
        /// <param name="displayName">the name to be displayed in place of the email address in an email client</param>
        /// <param name="address">the RFC 5322 email address</param>
        public EmailAddress(string displayName, string address)
        {
            DisplayName = displayName;
            Address = address;
        }

        /// <summary>
        /// The name to be displayed in place of the email address in an email client
        /// </summary>
        [DataMember] public string DisplayName { get; set; }

        /// <summary>
        /// And email address conforming to RFC 5322
        /// </summary>
        [DataMember] public string Address { get; set; }

        /// <summary>
        /// Helper method for creating address lists with only one EmailAddress object.
        /// </summary>
        /// <param name="address">the email address</param>
        /// <returns>a list with one EmailAddress object</returns>
        public static List<EmailAddress> SingleAddress(string address) => new() { new EmailAddress(address) };

        /// <summary>
        /// Helper method for creating address lists with only one EmailAddress object.
        /// </summary>
        /// <param name="displayName">the name to be displayed for the sender or recipient</param>
        /// <param name="address">the email address</param>
        /// <returns>a list with one EmailAddress object</returns>
        public static List<EmailAddress> SingleAddress(string displayName, string address) => new() { new EmailAddress(displayName, address) };

        /// <summary>
        /// Converts a comma-separated list of email addresses into a List structure.
        /// </summary>
        /// <param name="addressList">comma-separated list of email addresses without display names</param>
        /// <returns></returns>
        public static List<EmailAddress> AddressList(string addressList)
        {
            var result = new List<EmailAddress>();
            
            if (string.IsNullOrWhiteSpace(addressList)) return result;

            string[] addresses = addressList.Split(',');
            result.AddRange(addresses.Select(address => new EmailAddress(address.Trim())));

            return result;
        }

        /// <summary>
        /// Produces a comma-separated list from a list of email addresses.
        /// </summary>
        /// <param name="addresses"></param>
        /// <returns></returns>
        public static string CommaSeparatedAddressList(List<EmailAddress> addresses)
        {
            var result = new StringBuilder();
            var first = true;

            foreach (var address in addresses)
            {
                if (first)
                {
                    first = false;
                }
                else
                {
                    result.Append(", ");
                }
                result.Append($"\"{address.DisplayName}\" {address.Address}");
            }

            return result.ToString();
        }
    }
}
