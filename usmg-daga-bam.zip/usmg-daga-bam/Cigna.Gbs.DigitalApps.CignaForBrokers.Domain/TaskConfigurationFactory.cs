﻿using Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Mail;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class TaskConfigurationFactory: ITaskConfigurationFactory
    {
        private static readonly Lazy<TaskConfigurationFactory> Factory = new(() => new TaskConfigurationFactory());

        private TaskConfigurationFactory() {}

        /// <summary>
        /// Instance property for getting a copy of the factory singleton.
        /// </summary>
        public static TaskConfigurationFactory Instance => Factory.Value;

        /// <inheritdoc />
        public ILogger? Logger { private get; set; }

        /// <inheritdoc />
        public IConfiguration? ConfigurationManager { private get; set; }

        /// <inheritdoc />
        public IMailClient? MailClient { private get; set; }


        /// <inheritdoc />
        public ILogger GetLogger() => Logger!;

        /// <inheritdoc />
        public IConfiguration GetConfigurationManager() => ConfigurationManager!;

        /// <inheritdoc />
        public IMailClient GetMailClient() => MailClient!;
    }
}
