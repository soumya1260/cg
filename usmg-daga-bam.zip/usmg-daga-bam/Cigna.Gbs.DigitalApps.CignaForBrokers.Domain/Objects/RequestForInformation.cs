﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects
{
    /// <summary>
    /// Response object containing a single Request for Information (RFI) item.
    /// </summary>
    public class RequestForInformation
    {
        /// <summary>
        /// Member's full name using the Occidental convention of "GivenName Surname".
        /// </summary>
        [MaxLength(255 + 255 + 1)]
        [JsonPropertyName("memberName")]
        public string MemberName => $"{MemberGivenName} {MemberSurname}".Trim();

        /// <summary>
        /// Member's given name.  (First name in Western cultures.)
        /// </summary>
        [JsonIgnore] public string MemberGivenName { get; set; } = string.Empty;

        /// <summary>
        /// Member's surname.  (Last name in Western cultures.)
        /// </summary>
        [JsonIgnore] public string MemberSurname { get; set; } = string.Empty;

        /// <summary>
        /// The member's Medicare ID
        /// </summary>
        [MaxLength(255)]
        [JsonPropertyName("medicareId")]
        public string MedicareId { get; set; } = string.Empty;

        /// <summary>
        /// The due date for this request.  Formatted as "MM/DD/YYYY".
        /// </summary>
        [MaxLength(2 + 1 + 2 + 1 + 4)]
        [JsonPropertyName("dueDate")]
        public string DueDateString => DueDate?.ToString("MM/dd/yyyy") ?? string.Empty;

        /// <summary>
        /// Underlying date value for due date.  Allows us to preserve the date format and
        /// easily use a data mapper while still returning a formatted date string to the
        /// client without committing to a particular output formatter.
        /// </summary>
        /// <remarks>
        /// At the time of development this field was always null in all environments.
        /// </remarks>
        [JsonIgnore] public DateTime? DueDate { get; set; } = DateTime.MinValue;

        /// <summary>
        /// Reason for the request.
        /// </summary>
        [MaxLength(255)]
        [JsonPropertyName("reasonCode")]
        public string ReasonCode { get; set; } = string.Empty;

        /// <summary>
        /// SalesForce deep link identifier.  (SalesForce object key.)
        /// </summary>
        [MaxLength(255)]
        [JsonPropertyName("salesForceId")]
        public string SalesForceId { get; set; } = string.Empty;
    }
}