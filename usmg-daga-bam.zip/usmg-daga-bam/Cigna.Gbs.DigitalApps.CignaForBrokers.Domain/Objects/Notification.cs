﻿using System.Text.Json.Serialization;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects
{
    /// <summary>
    /// Broker license notifications about license expirations and appointment contract licenses.
    /// </summary>
    public class Notification
    {
        /// <summary>
        /// A list of the broker's licenses that have expired or will expire soon.
        /// </summary>
        [JsonPropertyName("licenses"), JsonPropertyOrder(1)]
        public List<LicenseNotification>? Licenses { get; set; }

        /// <summary>
        /// A list of the broker's appointments that are contracted and licensed.
        /// </summary>
        [JsonPropertyName("acls"), JsonPropertyOrder(2)]
        public List<AppointmentContractedAndLicensedNotification>? AppointmentContractLicenses { get; set; }
    }
}