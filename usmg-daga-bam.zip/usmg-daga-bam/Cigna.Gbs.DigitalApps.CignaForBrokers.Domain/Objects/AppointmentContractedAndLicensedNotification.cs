﻿using System.Text.Json.Serialization;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects
{
    /// <summary>
    /// A notification regarding the broker's ability to make membership solicitation
    /// appointments in a given set of states for a given year.
    /// </summary>
    public class AppointmentContractedAndLicensedNotification
    {
        /// <summary>
        /// Status of all the appointment contracts listed in the AclNotifications property.
        /// This is a grouping value. 
        /// </summary>
        [JsonPropertyName("status"), JsonPropertyOrder(1)]
        public string Status { get; set; } = string.Empty;

        /// <summary>
        /// A list of appointments that are contracted and licensed corresponding to the Status property.
        /// </summary>
        // ReSharper disable once StringLiteralTypo
        [JsonPropertyName("aclNotifications"), JsonPropertyOrder(2)]
        public List<AppointmentContractedAndLicensed> AppointmentContractLicenses { get; set; } =
            new();
    }
}