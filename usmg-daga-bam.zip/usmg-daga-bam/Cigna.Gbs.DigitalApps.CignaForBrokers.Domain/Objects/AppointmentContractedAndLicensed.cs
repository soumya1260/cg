﻿using System.Text.Json.Serialization;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects
{
    /// <summary>
    /// Class representing an Appointment that is Contracted and Licensed (ACL)
    /// </summary>
    public class AppointmentContractedAndLicensed
    {
        /// <summary>
        /// Year during which this license is effective represented as a string.  Format is "yyyy".
        /// </summary>
        [JsonPropertyName("year")] public string YearString => EffectiveYear.ToString("D4");

        /// <summary>
        /// Year during which this contract is effective.
        /// </summary>
        [JsonIgnore]
        public int EffectiveYear { get; set; }

        /// <summary>
        /// State code for the contract.
        /// </summary>
        [JsonPropertyName("stateCode")] public string StateCode { get; set; } = string.Empty;

        /// <summary>
        /// A list of all the product codes included in this contract.
        /// </summary>
        [JsonPropertyName("productCodes")] public List<string> ProductCodes { get; set; } = new();

    }
}