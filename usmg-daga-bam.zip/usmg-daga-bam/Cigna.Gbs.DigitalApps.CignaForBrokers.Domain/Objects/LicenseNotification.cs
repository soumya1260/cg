﻿using System.Text.Json.Serialization;

namespace Cigna.Gbs.DigitalApps.CignaForBrokers.Domain.Objects
{
    /// <summary>
    /// A single license notification for a broker.
    /// </summary>
    public class LicenseNotification
    {
        /// <summary>
        /// State code for the license that is expiring/has expired.
        /// </summary>
        [JsonPropertyName("stateCode")] public string StateCode { get; set; } = string.Empty;

        /// <summary>
        /// License number of the expiring license.
        /// </summary>
        [JsonPropertyName("licenseNumber")] public string LicenseNumber { get; set; } = string.Empty;

        /// <summary>
        /// Effective date of the license represented as a string.  Format is MM/dd/yyyy.
        /// </summary>
        [JsonPropertyName("startDate")]
        public string EffectiveDateString => EffectiveDate.ToString("MM/dd/yyyy");

        /// <summary>
        /// Effective date of the license.
        /// </summary>
        [JsonIgnore] public DateTime EffectiveDate { get; set; } = DateTime.MinValue;

        /// <summary>
        /// Expiration date of the license represented as a string.  Format is MM/dd/yyyy.
        /// </summary>
        [JsonPropertyName("endDate")] public string ExpirationDateString => ExpirationDate.ToString("MM/dd/yyyy");

        /// <summary>
        /// Expiration date of the license
        /// </summary>
        [JsonIgnore] public DateTime ExpirationDate { get; set; } = DateTime.MaxValue;

        /// <summary>
        /// Indicates whether or not the license is active.  Note that this value sources from
        /// the data store and is not calculated based on the license expiration date.
        /// </summary>
        [JsonPropertyName("active")] public bool Active { get; set; } = false;
    }
}