//
// NOTE: This file is used for reference only during the CI/CD build.  It does
//       not get compiled.
//
using System.Reflection;

[assembly: AssemblyVersion("2023.4.1.0")]
[assembly: AssemblyFileVersion("2023.4.1.0")]

[assembly: AssemblyCopyright("Copyright © 2023 Cigna - All Rights Reserved")]
