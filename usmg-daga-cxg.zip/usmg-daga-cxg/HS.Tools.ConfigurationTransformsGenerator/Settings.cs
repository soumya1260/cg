﻿using System;
using System.Collections.Generic;

namespace HS.Tools.ConfigurationTransformsGenerator
{
    public class Settings
    {
        public List<string> ControlFileNames { get; }
        public string OutputFolder { get; }
        public string TemplateFile { get; }
        public string EnvironmentPrefix { get; }

        public Settings(IReadOnlyList<string> args)
        {
            int index = 0;
            if (string.Equals(args[0], "-prefix", StringComparison.InvariantCultureIgnoreCase))
            {
                ++index; // Skip over -prefix
                EnvironmentPrefix = args[index++];
            }

            TemplateFile = args[index++];
            OutputFolder = args[index++];

            ControlFileNames = new List<string>();
            while (index < args.Count)
            {
                ControlFileNames.Add(args[index++]);
            }
        }
    }
}