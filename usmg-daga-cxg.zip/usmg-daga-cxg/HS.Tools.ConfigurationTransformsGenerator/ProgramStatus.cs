﻿using System;

#pragma warning disable S2228 // Console application.  Interactions with the system console are appropriate.

namespace HS.Tools.ConfigurationTransformsGenerator
{
    internal static class ProgramStatus
    {
        public enum ErrorLevel { Warning, Error }

        //
        // ERRORLEVEL return values
        //
        public const int IncorrectNumberOfParameters = 101;

        public const int TemplateFileCouldNotBeRead = 102;
        public const int CouldNotAccessOutputFolder = 103;
        public const int UnmatchedTokensFoundInTemplate = 104;
        public const int SettingsWorksheetNotFoundInControlFile = 105;
        public const int ControlFileCouldNotBeRead = 106;
        public const int CouldNotAccessTemplateFile = 107;
        public const int NoTemplatesFoundInTemplateFolder = 108;
        public const int DuplicateEnvironmentValueInControlFile = 109;

        public const int OperationSuccessful = 0;

        public const int FatalError = 200;

        public static int CurrentStatus { get; set; }

        /// <summary>
        ///     Displays an error message on the console. It will be color-coded if attached to a
        ///     color-capable device.
        /// </summary>
        /// <param name="exception">Exception object.  Nulls are okay.</param>
        /// <param name="formatString">A string.Format()-style format string.</param>
        /// <param name="args">Zero or more format arguments.</param>
        internal static void DisplayErrorMessage(Exception exception, string formatString, params object[] args)
        {
            DisplayMessage(ErrorLevel.Error, string.Format(formatString, args), exception);
        }

        /// <summary>
        ///     Displays a warning message on the console. It will be color-coded if attached to a
        ///     color-capable device.
        /// </summary>
        /// <param name="formatString">A string.Format()-style format string.</param>
        /// <param name="args">Zero or more format arguments.</param>
        internal static void DisplayWarningMessage(string formatString, params object[] args)
        {
            DisplayMessage(ErrorLevel.Warning, string.Format(formatString, args));
        }

        /// <summary>
        /// Displays a message on the console, formatted to work with the Visual Studio Error
        /// window.  It will be color-coded if attached to a color-capable device.
        /// </summary>
        /// <param name="errorLevel"></param>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="source"></param>
        internal static void DisplayMessage(
            ErrorLevel errorLevel,
            string message,
            Exception exception = null,
            string source = "CXG")
        {
            ConsoleColor originalColor = Console.ForegroundColor;
            Console.ForegroundColor = errorLevel == ErrorLevel.Error ? ConsoleColor.Red : ConsoleColor.Yellow;
            Console.Write($"{source} : ERROR CXG{CurrentStatus:D4}: ");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(message);
            if (exception != null)
            {
                Console.WriteLine(exception.Message);
            }

            Console.ForegroundColor = originalColor;
            Console.WriteLine();
        }
    }
}