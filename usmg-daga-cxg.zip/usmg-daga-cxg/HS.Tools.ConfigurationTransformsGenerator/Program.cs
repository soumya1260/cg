﻿using System;

#pragma warning disable S2228 // Console application.  Interactions with the system console are appropriate.

namespace HS.Tools.ConfigurationTransformsGenerator
{
    internal static class Program
    {
        private static int Main(string[] args)
        {
            try
            {
                const int minimumArgs = 3;

                if (args.Length < minimumArgs)
                {
                    ProgramStatus.CurrentStatus = ProgramStatus.IncorrectNumberOfParameters;
                    Console.WriteLine("Incorrect number of arguments: {0}.  Expected three or more.", args.Length);
                    Usage();

                    return ProgramStatus.CurrentStatus;
                }

                ProgramStatus.CurrentStatus = ProgramStatus.OperationSuccessful;

                var settings = new Settings(args);
                var formatter = new ConfigurationFormatter(settings);

                formatter.GenerateFiles();
            }
            catch (Exception ex)
            {
                ProgramStatus.CurrentStatus = ProgramStatus.FatalError;
                ProgramStatus.DisplayErrorMessage(
                    ex,
                    "The Configuration Transforms Generator encountered a fatal error. Exiting program.");
            }

            return ProgramStatus.CurrentStatus;
        }

        private static void Usage()
        {
            ConsoleColor originalColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Usage: cxg [-prefix environment_prefix] template_file output_path PROJECT_control_file [COMMON_control_file]");
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = originalColor;
        }
    }
}