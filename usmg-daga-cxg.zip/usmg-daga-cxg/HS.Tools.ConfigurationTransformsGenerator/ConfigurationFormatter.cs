﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace HS.Tools.ConfigurationTransformsGenerator
{
    internal class ConfigurationFormatter
    {
        #region Private member variables

        private readonly string _templateFile;
        private readonly List<string> _controlFileNames;
        private readonly string _outputPath;
        private readonly string _environmentPrefix;

        #endregion Private member variables

        public ConfigurationFormatter(Settings settings)
        {
            _outputPath = settings.OutputFolder;
            _controlFileNames = settings.ControlFileNames;
            _templateFile = settings.TemplateFile;
            _environmentPrefix = settings.EnvironmentPrefix;
        }

        /// <summary>
        ///     File generation method. Creates configuration transform files by merging the control file with the
        ///     template file.
        /// </summary>
        /// <returns>ERRORLEVEL value for return to the calling process.</returns>
        public void GenerateFiles()
        {
            if (VerifyOutputFolder() != ProgramStatus.OperationSuccessful)
            {
                return;
            }

            //
            // Get the list of configuration templates from the template folder.
            //
            TemplateFile templateFile = LoadTemplateFiles();
            if (ProgramStatus.CurrentStatus != ProgramStatus.OperationSuccessful)
            {
                return;
            }

            //
            // Read key/value pairs by environment from control files.
            //
            List<ControlFile> controlFiles = _controlFileNames.Select(filename => new ControlFile(filename)).ToList();
            if (ProgramStatus.CurrentStatus != ProgramStatus.OperationSuccessful)
            {
                return;
            }

            //
            // Assume all tokens from the project control file are unused.  Tokens will be
            // removed from this list as they are matched to the templates.  Environment
            // is removed from the list since it may not be referenced by the templates,
            // but is still a required field.
            //
            Dictionary<string, Token> unusedTokens = controlFiles[0]["DEV:localhost"].ToDictionary(token => token.Name);
            unusedTokens.Remove("Environment");

            //
            // Generate files for each environment.
            //
            if (!GenerateFilesForEachEnvironment(controlFiles, templateFile, unusedTokens))
            {
                return;
            }

            //
            // List out any unused tokens found in the control files.
            //
            foreach (string tokenName in unusedTokens.Keys)
            {
                ProgramStatus.DisplayWarningMessage(
                    "Token \"{0}\" from {1} could not be found in any of the templates.",
                    tokenName,
                    controlFiles[0].FileName);
            }
        }

        private bool GenerateFilesForEachEnvironment(List<ControlFile> controlFiles, TemplateFile templateFile, Dictionary<string, Token> unusedTokens)
        {
            foreach (string environment in controlFiles[0].GetEnvironments())
            {
                //
                // Ignore DEV:localhost
                //
                if (string.Equals(environment, "DEV:localhost", StringComparison.InvariantCultureIgnoreCase))
                {
                    continue;
                }
                //
                // Generated files for the localhost environment will go into the output
                // folder designated by the user.  Files for all other environments will
                // go into sub-folders grouped by environment.
                //
                string folder = _outputPath;
                VerifyOutputFolder(folder);

                //
                // Generate file for the current environment.
                //
                if (!GenerateFileForEnvironment(controlFiles, templateFile, unusedTokens, environment, folder))
                {
                    return false;
                }
            }

            return true;
        }

        private bool GenerateFileForEnvironment(
            List<ControlFile> controlFiles,
            TemplateFile template,
            Dictionary<string, Token> unusedTokens,
            string environment,
            string folder)
        {
            string fileContents = template.Contents;
            foreach (ControlFile controlFile in controlFiles)
            {
                fileContents = ProcessControlFile(unusedTokens, environment, controlFile, fileContents);
            }

            //
            // Create an OutputFile object and use it to write out the generated file.
            // Note that as a side-effect, the WriteFile() method will generate an error
            // if any tokens remain in the output file.
            //
            string prefix = string.IsNullOrWhiteSpace(_environmentPrefix) ? string.Empty : $"{_environmentPrefix}-";

            var outputFile = new OutputFile(
                fileContents,
                Regex.Replace(
                    template.Name,
                    @"\.template",
                    $".{prefix}{environment}",
                    RegexOptions.IgnoreCase));

            outputFile.WriteFile(folder);

            if (ProgramStatus.CurrentStatus != ProgramStatus.OperationSuccessful)
            {
                return false;
            }

            return true;
        }

        private static string ProcessControlFile(
            Dictionary<string, Token> unusedTokens,
            string environment,
            ControlFile controlFile,
            string fileContents)
        {
            string newFileContents = fileContents;

            for (var index = 0; index < controlFile[environment].Count; ++index)
            {
                Token token = controlFile[environment][index];
                if (Regex.IsMatch(newFileContents, token.Pattern, RegexOptions.IgnoreCase))
                {
                    newFileContents = Regex.Replace(
                        newFileContents,
                        token.Pattern,
                        token.Value,
                        RegexOptions.IgnoreCase);

                    if (unusedTokens.ContainsKey(token.Name))
                    {
                        unusedTokens.Remove(token.Name);
                    }
                }
            }

            return newFileContents;
        }

        private TemplateFile LoadTemplateFiles()
        {
            var templateFile = new TemplateFile(_templateFile);
            try
            {
                if (!File.Exists(_templateFile))
                {
                    ProgramStatus.CurrentStatus = ProgramStatus.NoTemplatesFoundInTemplateFolder;
                    throw new FileNotFoundException(
                        $"Could not access template folder {_templateFile}.");
                }
            }
            catch (Exception exception)
            {
                ProgramStatus.CurrentStatus = ProgramStatus.CouldNotAccessTemplateFile;
                ProgramStatus.DisplayErrorMessage(
                    exception,
                    "Error reading from template file {0}.",
                    _templateFile);
            }

            return templateFile;
        }

        private int VerifyOutputFolder(string subPath = null)
        {
            string path = _outputPath;
            if (subPath != null)
            {
                path = subPath;
            }

            //
            // Try to create output folder
            //
            try
            {
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
            }
            catch (Exception exception)
            {
                ProgramStatus.CurrentStatus = ProgramStatus.CouldNotAccessOutputFolder;
                ProgramStatus.DisplayErrorMessage(
                    exception,
                    "Could not access or create folder {0}.  Please verify security permissions.",
                    path);
            }

            return ProgramStatus.CurrentStatus;
        }
    }
}