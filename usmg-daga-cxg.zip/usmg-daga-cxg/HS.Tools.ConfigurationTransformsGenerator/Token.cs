﻿namespace HS.Tools.ConfigurationTransformsGenerator
{
    public struct Token
    {
        public readonly string Name;
        public readonly string Pattern;
        public readonly string Value;

        public Token(string name, string value)
        {
            Name = name;
            Pattern = $@"{{%{name}%\}}";
            Value = value;
        }
    }
}