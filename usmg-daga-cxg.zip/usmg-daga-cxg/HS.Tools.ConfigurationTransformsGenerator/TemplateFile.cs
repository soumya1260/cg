﻿using System;
using System.IO;

namespace HS.Tools.ConfigurationTransformsGenerator
{
    public class TemplateFile
    {
        public readonly string Contents;
        public readonly string Name;

        public TemplateFile(string filename)
        {
            Name = Path.GetFileName(filename);

            try
            {
                Contents = File.ReadAllText(filename);
            }
            catch (Exception exception)
            {
                ProgramStatus.CurrentStatus = ProgramStatus.TemplateFileCouldNotBeRead;
                ProgramStatus.DisplayMessage(
                    ProgramStatus.ErrorLevel.Error,
                    $"Could not read file {filename}.",
                    exception,
                    filename);
            }
        }
    }
}