﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading;

namespace HS.Tools.ConfigurationTransformsGenerator
{
    public class ControlFile
    {
        private const int MaximumRetries = 20;
        private const int RetryInterval = 500;
        private readonly Dictionary<string, List<Token>> _tokenRows;
        public readonly string FileName;
        private int _retries;

        public ControlFile(string filename)
        {
            FileName = Path.GetFileName(filename);
            _tokenRows = LoadTokens(filename);
            _retries = 0;
        }

        private Dictionary<string, List<Token>> LoadTokens(string filename)
        {
            var tokenRows = new Dictionary<string, List<Token>>();

            DataSet dataSet = ExtractDataSetFromControlFile(filename);
            if (ProgramStatus.CurrentStatus != ProgramStatus.OperationSuccessful)
            {
                return tokenRows;
            }

            if (!dataSet.Tables.Contains("Settings"))
            {
                ProgramStatus.CurrentStatus = ProgramStatus.SettingsWorksheetNotFoundInControlFile;
                ProgramStatus.DisplayErrorMessage(
                    null,
                    "Could not find a worksheet named \"Settings\" in {0}.",
                    filename);
                return tokenRows;
            }

            foreach (DataRow row in dataSet.Tables["Settings"].Rows)
            {
                if (RowIsEmpty(row))
                {
                    break;
                }

                string environment = GetEnvironment(row);
                if (environment == null)
                {
                    throw new ControlFileException("Required column 'Environment' was not found in control file.");
                }

                var tokens = new List<Token>();

                for (var columnIndex = 0; columnIndex < row.Table.Columns.Count; ++columnIndex)
                {
                    //
                    // Get the column name. This will be the substitution token we will be matching on.
                    //
                    string tokenName = row.Table.Columns[columnIndex].ColumnName;
                    string tokenValue = row.IsNull(columnIndex)
                        ? string.Empty
                        : (string)row[columnIndex];

                    var token = new Token(tokenName, tokenValue);
                    tokens.Add(token);
                }

                try
                {
                    tokenRows.Add(environment, tokens);
                }
                catch (ArgumentException argumentException)
                {
                    ProgramStatus.CurrentStatus = ProgramStatus.DuplicateEnvironmentValueInControlFile;
                    ProgramStatus.DisplayErrorMessage(
                        argumentException,
                        "Duplicate environment '{0}' encountered.  Environment values must be unique.",
                        environment);
                    throw;
                }
            }

            return tokenRows;
        }

        private DataSet ExtractDataSetFromControlFile(string controlFile)
        {
            try
            {
                using (FileStream stream = File.Open(controlFile, FileMode.Open, FileAccess.Read))
                {
                    try
                    {
                        using (IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream))
                        {
                            //
                            // Return the result as a dataset.
                            //
                            return reader.AsDataSet(
                                new ExcelDataSetConfiguration
                                {
                                    UseColumnDataType = true,
                                    ConfigureDataTable = tableReader =>
                                        new ExcelDataTableConfiguration
                                        {
                                            UseHeaderRow = true,
                                            ReadHeaderRow = rowReader =>
                                            {
                                                /* Do nothing.  Used to skip rows. */
                                            },
                                            FilterRow = rowReader => true
                                        }
                                });
                        }
                    }
                    catch (Exception exception)
                    {
                        ProgramStatus.CurrentStatus = ProgramStatus.ControlFileCouldNotBeRead;
                        ProgramStatus.DisplayErrorMessage(
                            exception,
                            "Could not read {0} as an Excel document.",
                            controlFile);
                    }
                }
            }
            catch (Exception ex)
            {
                if (ProgramStatus.CurrentStatus != ProgramStatus.OperationSuccessful)
                {
                    return null;
                }

                //
                // Sometimes an Excel file gets locked during a multi-threaded build.
                // This gives us a buffer to retry a few times before giving up.
                //
                if (_retries < MaximumRetries)
                {
                    ++_retries;
                    Thread.Sleep(RetryInterval);
                    return ExtractDataSetFromControlFile(controlFile);
                }

                ProgramStatus.CurrentStatus = ProgramStatus.ControlFileCouldNotBeRead;
                ProgramStatus.DisplayErrorMessage(
                    ex, "Could not access control file.  Is it open in Excel?", FileName);
            }

            return null;
        }

        private static bool RowIsEmpty(DataRow row)
        {
            //
            // Check for an empty cell in the first column, which would indicate the end
            // of the data we should be looking at.
            //
            return row.IsNull(0) || string.IsNullOrWhiteSpace(row[0].ToString());
        }

        private static string GetEnvironment(DataRow row)
        {
            string environment = null;
            for (var columnIndex = 0; columnIndex < row.Table.Columns.Count; ++columnIndex)
            {
                // search through every column until we find the "Environment" column
                string tokenName = row.Table.Columns[columnIndex].ColumnName;
                if (!tokenName.Trim().Equals("ENVIRONMENT", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                environment = row.IsNull(columnIndex) ? string.Empty : (string)row[columnIndex];
                break;
            }
            return environment;
        }

        #region Properties

        public List<string> GetEnvironments()
        {
            return _tokenRows.Keys.ToList();
        }

        public List<Token> this[string index] => _tokenRows[index];

        #endregion Properties
    }
}