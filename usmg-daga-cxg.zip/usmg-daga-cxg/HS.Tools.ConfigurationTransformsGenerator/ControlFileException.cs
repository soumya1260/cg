﻿using System;
using System.Runtime.Serialization;

namespace HS.Tools.ConfigurationTransformsGenerator
{
    [Serializable]
    public class ControlFileException : Exception
    {
        public ControlFileException()
        {
        }

        public ControlFileException(string message) : base(message)
        {
        }

        public ControlFileException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ControlFileException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}