﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace HS.Tools.ConfigurationTransformsGenerator
{
    public class OutputFile
    {
        public OutputFile(string contents, string fileName)
        {
            FileContents = contents;
            FileName = fileName;
        }

        private string FileName { get; }
        private string FileContents { get; }

        /// <summary>
        ///     Looks through fileContents for anything that looks like a token.
        /// </summary>
        /// <returns>the number of unprocessed tokens</returns>
        private int UnprocessedTokens()
        {
            //
            // Scan the output to see if there are any missed tokens.
            //
            MatchCollection matches = Regex.Matches(FileContents, @"\{%[^%]*%\}", RegexOptions.IgnoreCase);
            if (matches.Count > 0)
            {
                var unmatchedTokens = new StringBuilder();
                foreach (object match in matches)
                {
                    unmatchedTokens.AppendFormat("{0} ", match);
                }

                ProgramStatus.CurrentStatus = ProgramStatus.UnmatchedTokensFoundInTemplate;

                ProgramStatus.DisplayMessage(
                    ProgramStatus.ErrorLevel.Error,
                    $"The following token{(matches.Count == 1 ? string.Empty : "s")} in the template file {(matches.Count == 1 ? "was" : "were")} not resolved: {unmatchedTokens}",
                    source: FileName);
            }
            return matches.Count;
        }

        public void WriteFile(string path)
        {
            var successful = true;
            string outputFileFullPath = string.Empty;

            if (UnprocessedTokens() > 0)
            {
                successful = false;
                ProgramStatus.CurrentStatus = ProgramStatus.UnmatchedTokensFoundInTemplate;
            }
            else
            {
                outputFileFullPath = $"{path}\\{FileName}";

                try
                {
                    //
                    // Sometimes version control sets the read-only attribute on files that are not
                    // checked out. This block checks for read-only files and resets the attribute
                    // so that the file can be over-written.
                    //
                    if (File.Exists(outputFileFullPath))
                    {
                        var file = new FileInfo(outputFileFullPath);
                        if (file.IsReadOnly)
                        {
                            File.SetAttributes(
                                outputFileFullPath,
                                File.GetAttributes(outputFileFullPath) ^ FileAttributes.ReadOnly);
                        }
                    }

                    File.WriteAllText(outputFileFullPath, FileContents, Encoding.UTF8);
                }
                catch (Exception exception)
                {
                    ProgramStatus.CurrentStatus = ProgramStatus.CouldNotAccessOutputFolder;
                    ProgramStatus.DisplayMessage(
                        ProgramStatus.ErrorLevel.Error,
                        $"Could not access or create file {outputFileFullPath}.  Please verify security permissions.",
                        exception,
                        FileName);
                    successful = false;
                }
            }

#pragma warning disable S2228 // Console application.  This is not logging.
            if (successful)
            {
                ConsoleColor originalColor = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Writing file {0}.", outputFileFullPath);
                Console.ForegroundColor = originalColor;
            }
#pragma warning restore S2228
        }
    }
}