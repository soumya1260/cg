
[//]: # (Ignore the gobbledegook for the badges.)

[![Build Status](https://w2-jenkins.sys.cigna.com/buildStatus/icon?job=HEALTHSPRING/CHSDEVOPS/GBS-DigitalApps/CXGBuild)](https://w2-jenkins.sys.cigna.com/job/HEALTHSPRING/job/CHSDEVOPS/job/GBS-DigitalApps/job/CXGBuild/) [![Quality Gate Status](https://sonarqube.sys.cigna.com/api/project_badges/measure?project=com.cigna.CHS.InternalTools.ConfigurationTransformsGenerator&metric=alert_status&token=sqb_98f292049f7d2760d5c4805972c4fcc33e20267f)](https://sonarqube.sys.cigna.com/dashboard?id=com.cigna.CHS.InternalTools.ConfigurationTransformsGenerator)

[//]: # (Documentation starts here.)

# CXG (Configuration Transforms Generator)

CXG is a utility to bring "mail merge" capabilities to 
configuration transformation files from within Visual Studio.

See the [Documentation](HS.Tools.ConfigurationTransformsGenerator/ConfigurationTransformsGenerator-Manual.docx "CXG Manual")
for full information on how to use the tool and integrate it into 
Visual Studio builds.
