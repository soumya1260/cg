﻿// DO NOT REMOVE THIS FILE
// IT STILL CONTROLS VERSION INFORMATION DURING THE JENKINS BUILD!

// AssemblyVersion("2023.1.0.0")
// AssemblyFileVersion("2023.1.0.0")

// AssemblyCopyright("Copyright © 2023 Cigna - All Rights Reserved")