﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: Guid("9b08c117-0dcf-4f9d-8d37-ab2e2525d8f7")]
