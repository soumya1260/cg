﻿// Decompiled with JetBrains decompiler
// Type: HS.SearchCriteria`1
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using HS.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.Serialization;

namespace HS
{
    [DataContract]
    public class SearchCriteria<T> where T : class
    {
        [DataMember]
        public int PageSize { get; set; }

        [DataMember]
        public int PageNumber { get; set; }

        [DataMember]
        public SortOrder SortOrder { get; set; }

        [DataMember]
        public string SortExpression { get; set; }

        [DataMember]
        public string FilterText { get; set; }

        [DataMember]
        public List<SearchCondition> SearchConditions { get; set; }

        public IQueryable<T> ApplySorting(IQueryable<T> query)
        {
            IQueryable<T> source = query;
            if (!string.IsNullOrEmpty(this.SortExpression))
                source = (IQueryable<T>)source.OrderBy<T>(this.SortExpression, this.SortOrder);
            return source;
        }

        public IQueryable<T> ApplyPaging(IQueryable<T> query)
        {
            IQueryable<T> source = query;
            if (this.PageSize > 0)
                source = source.Skip<T>((this.PageNumber - 1) * this.PageSize).Take<T>(this.PageSize);
            return source;
        }

        public virtual IQueryable<T> ApplyFilter(IQueryable<T> query)
        {
            IQueryable<T> source1 = query;
            if (this.SearchConditions != null && this.SearchConditions.Count > 0)
            {
                IQueryable<object> source2 = Queryable.Cast<object>(query);
                Expression<Func<object, bool>> filterExpression = this.GetFilterExpression();
                if (filterExpression != null)
                    source2 = source2.Where<object>(filterExpression.Compile()).AsQueryable<object>();
                source1 = Queryable.Cast<T>(source2);
            }
            if (!string.IsNullOrEmpty(this.FilterText))
            {
                ParameterExpression parameterExpression = Expression.Parameter(typeof(T), "t");
                List<Expression> expressionList = new List<Expression>();
                MethodInfo method1 = typeof(string).GetMethod("Contains", new Type[1]
                {
          typeof (string)
                });
                MethodInfo method2 = typeof(object).GetMethod("ToString");
                foreach (PropertyInfo property in typeof(T).GetProperties())
                    expressionList.Add((Expression)Expression.Call((Expression)Expression.Condition((Expression)Expression.Equal((Expression)Expression.Convert((Expression)Expression.Property((Expression)parameterExpression, property.Name), typeof(object)), (Expression)Expression.Constant((object)null)), (Expression)Expression.Constant((object)string.Empty), (Expression)Expression.Call((Expression)Expression.Property((Expression)parameterExpression, property.Name), method2)), method1, (Expression)Expression.Constant((object)this.FilterText)));
                Expression expression = (Expression)null;
                foreach (Expression right in expressionList)
                    expression = expression != null ? (Expression)Expression.OrElse(expression, right) : right;
                if (expression != null)
                {
                    Func<T, bool> predicate = Expression.Lambda<Func<T, bool>>(expression, parameterExpression).Compile();
                    source1 = source1.Where<T>(predicate).AsQueryable<T>();
                }
            }
            return source1;
        }

        /// <summary>
        /// Parses the requested parameters and returns a corresponding
        /// LINQ expression
        /// </summary>
        /// <param name="field">The field to search</param>
        /// <param name="op">The operation to apply to the field and value</param>
        /// <param name="value">The value to search for</param>
        /// <param name="not">Whether to negate the expression</param>
        /// <param name="type">The type.</param>
        /// <param name="paramEx">The parameter that serves as input to the expression</param>
        /// <returns>The requested LINQ expression</returns>
        protected Expression GetFilterExpression(string field, Operator op, string value, bool not, DbType type, ParameterExpression paramEx)
        {

            // If the user didn't enter anything, return a null expression
            if (string.IsNullOrEmpty(value)) return null;

            DbType expressionType = type;

            // If the operation is "Contains", or if the column is generated
            // by a Lambda expression, treat the compare value like a string
            if (op == Operator.Contains ||
                op == Operator.StartsWith ||
                type == DbType.String ||
                type == DbType.StringFixedLength ||
                type == DbType.AnsiString ||
                type == DbType.AnsiStringFixedLength ||
                type == DbType.Guid ||
                type == DbType.Object ||
                type == DbType.Xml)
                expressionType = DbType.String;

            // This contains the expression which returns the value of the
            // specified column from the current row in the data source
            Expression valueEx = null;

            #region Create the expression which returns the current value from the current row

            #region Create the function to query the property value

            //Note that because this is used in the lambda expressions
            //down below, it stays in scope as long as they do.
            PropertyInfo pi = typeof(T).GetProperty(field);

            // Create a function to return the current value of the 
            // requested column of the current row. Unfortunately, 
            // late binding isn't allowed in LINQ expressions so we 
            // have to get the value using Reflection and manually
            // cast it to the correct data type. If it's a string
            // (or it's being treated as one) the conversion takes
            // place after the value has been retrieved (see the
            // end of this switch block)
            switch (expressionType)
            {
                case DbType.String:
                    {
                        Expression<Func<object, object>> func = ((object o) => pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Boolean:
                    {
                        Expression<Func<object, bool>> func = ((object o) => (bool)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Byte:
                case DbType.SByte:
                    {
                        Expression<Func<object, byte>> func = ((object o) => (byte)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Currency:
                case DbType.Decimal:
                    {
                        Expression<Func<object, decimal>> func = ((object o) => (decimal)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Date:
                    {
                        Expression<Func<object, DateTime>> func = ((object o) => ((DateTime)pi.GetValue(o, null)).Date);
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.DateTime:
                case DbType.DateTime2:
                    {
                        Expression<Func<object, DateTime>> func = ((object o) => (DateTime)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Time:
                    {
                        Expression<Func<object, long>> func = ((object o) => ((DateTime)pi.GetValue(o, null)).TimeOfDay.Ticks);
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.DateTimeOffset:
                    {
                        Expression<Func<object, TimeSpan>> func = ((object o) => (TimeSpan)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Double:
                case DbType.VarNumeric:
                    {
                        Expression<Func<object, double>> func = ((object o) => (double)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Int16:
                    {
                        Expression<Func<object, short>> func = ((object o) => (short)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Int32:
                    {
                        Expression<Func<object, int>> func = ((object o) => (int)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Int64:
                    {
                        Expression<Func<object, long>> func = ((object o) => (long)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Single:
                    {
                        Expression<Func<object, float>> func = ((object o) => (float)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.UInt16:
                    {
                        Expression<Func<object, ushort>> func = ((object o) => (ushort)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.UInt32:
                    {
                        Expression<Func<object, uint>> func = ((object o) => (uint)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.UInt64:
                    {
                        Expression<Func<object, ulong>> func = ((object o) => (ulong)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
            }

            #endregion

            // If the expression returns a string - or if we're forcing it
            // to return one - add a "ToString" to it.
            if (expressionType == DbType.String)
            {
                valueEx =
                    Expression.Call(
                        Expression.Call(valueEx, "ToString", null, null),
                            "ToUpper", null, null);
            }

            #endregion

            // This expression contains the value were searching for
            ConstantExpression valueToCompareEx = null;

            #region Create the expression which returns the value to search for (and validate it's datatype)

            // Create a ConstantExpression which contains the value to
            // search for. Since the comparison is type checked, we 
            // also have to cast it to the correct type. If the user
            // entered an invalid value for that type, though, we
            // show an error here and bail out
            //
            // TODO: We may want to change this so that instead of throwing
            // we force the expression to a string comparison. This might
            // be a little more user friendly
            switch (expressionType)
            {
                case DbType.String:
                    {
                        valueToCompareEx = Expression.Constant(value.ToUpper());
                        break;
                    }
                case DbType.Boolean:
                    {
                        bool x = bool.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.Byte:
                case DbType.SByte:
                    {
                        byte x = byte.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.Currency:
                case DbType.Decimal:
                    {
                        decimal x = decimal.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.Date:
                    {
                        DateTime x = DateTime.Parse(value);
                        valueToCompareEx = Expression.Constant(x.Date);
                        break;
                    }
                case DbType.DateTime:
                case DbType.DateTime2:
                    {
                        DateTime x = DateTime.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.Time:
                    {
                        DateTime x = DateTime.Parse(value);
                        valueToCompareEx = Expression.Constant(x.TimeOfDay.Ticks);
                        break;
                    }
                case DbType.DateTimeOffset:
                    {
                        TimeSpan x = TimeSpan.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.Double:
                case DbType.VarNumeric:
                    {
                        double x = double.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.Int16:
                    {
                        short x = short.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.Int32:
                    {
                        int x = int.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.Int64:
                    {
                        long x = long.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.Single:
                    {
                        float x = float.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.UInt16:
                    {
                        ushort x = ushort.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.UInt32:
                    {
                        uint x = uint.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
                case DbType.UInt64:
                    {
                        ulong x = ulong.Parse(value);
                        valueToCompareEx = Expression.Constant(x);
                        break;
                    }
            }

            #endregion

            // This expression contains the comparison between the first
            // and second expressions
            Expression compareEx = null;

            #region Create the comparison operation

            // Combine the two expressions using the requested operation.
            // Note that strings have to be handled differently because 
            // the built in GreaterThan/LessThan operators only operate
            // on numeric (and date) data types.
            switch (op)
            {
                case Operator.Contains:
                    compareEx = Expression.Call(valueEx, "Contains", null, valueToCompareEx);
                    break;
                case Operator.StartsWith:
                    compareEx = Expression.Call(valueEx, "StartsWith", null, valueToCompareEx);
                    break;
                case Operator.Equals:
                    compareEx = Expression.Equal(valueEx, valueToCompareEx);
                    break;
                case Operator.GreaterThan:
                    if (expressionType == DbType.String)
                    {
                        compareEx = Expression.Call(valueEx,
                            typeof(string).GetMethod("CompareTo", new Type[] { typeof(string) }),
                                valueToCompareEx);
                        compareEx = Expression.GreaterThan(compareEx, Expression.Constant(0));
                    }
                    else
                    {
                        compareEx = Expression.GreaterThan(valueEx, valueToCompareEx);
                    }
                    break;
                case Operator.LessThan:
                    if (expressionType == DbType.String)
                    {
                        compareEx = Expression.Call(valueEx,
                            typeof(string).GetMethod("CompareTo", new Type[] { typeof(string) }),
                                valueToCompareEx);
                        compareEx = Expression.LessThan(compareEx, Expression.Constant(0));
                    }
                    else
                    {
                        compareEx = Expression.LessThan(valueEx, valueToCompareEx);
                    }
                    break;
                case Operator.GreaterThanOrEqualTo:
                    if (expressionType == DbType.String)
                    {
                        compareEx = Expression.Call(valueEx,
                            typeof(string).GetMethod("CompareTo", new Type[] { typeof(string) }),
                                valueToCompareEx);
                        compareEx = Expression.GreaterThanOrEqual(compareEx, Expression.Constant(0));
                    }
                    else
                    {
                        compareEx = Expression.GreaterThanOrEqual(valueEx, valueToCompareEx);
                    }
                    break;
                case Operator.LessThanOrEqualTo:
                    if (expressionType == DbType.String)
                    {
                        compareEx = Expression.Call(valueEx,
                            typeof(string).GetMethod("CompareTo", new Type[] { typeof(string) }),
                                valueToCompareEx);
                        compareEx = Expression.LessThanOrEqual(compareEx, Expression.Constant(0));
                    }
                    else
                    {
                        compareEx = Expression.LessThanOrEqual(valueEx, valueToCompareEx);
                    }
                    break;
            }

            #endregion

            // Negate the expression if requested
            if (not)
                compareEx = Expression.Not(compareEx);

            return compareEx;
        }

        protected Expression CombineFilters(Expression ex1, Expression ex2, JoinOperator op)
        {
            if (ex1 == null)
                return ex2;
            if (ex2 == null)
                return ex1;
            return op == JoinOperator.Default || op == JoinOperator.Default ? (Expression)Expression.AndAlso(ex1, ex2) : (Expression)Expression.OrElse(ex1, ex2);
        }

        protected Expression<Func<object, bool>> GetFilterExpression()
        {
            ParameterExpression paramEx = Expression.Parameter(typeof(object), "o");
            Expression<Func<object, bool>> filterExpression1 = (Expression<Func<object, bool>>)null;
            Expression expression = (Expression)null;
            foreach (SearchCondition searchCondition in this.SearchConditions)
            {
                Expression filterExpression2 = this.GetFilterExpression(searchCondition.SearchField, searchCondition.Operator, searchCondition.SearchValue, searchCondition.Not, searchCondition.DataType, paramEx);
                if (filterExpression2 != null)
                    expression = expression != null ? this.CombineFilters(expression, filterExpression2, searchCondition.JoinOperator) : filterExpression2;
            }
            if (expression != null)
                filterExpression1 = Expression.Lambda<Func<object, bool>>(expression, paramEx);
            return filterExpression1;
        }

        public IQueryable<T> ApplyFilterPagingAndSorting(IQueryable<T> query) => this.ApplyPaging(this.ApplySorting(this.ApplyFilter(query)));
    }
}
