﻿// Decompiled with JetBrains decompiler
// Type: HS.ListRequest`1
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace HS
{
  [DataContract]
  public class ListRequest<T> : ServiceRequest where T : class
  {
    [DataMember]
    public List<T> Items { get; set; }

    [DataMember]
    public int TotalItems { get; set; }

    public ListRequest() => this.Items = new List<T>();

    [DataMember]
    public HS.SearchCriteria<T> SearchCriteria { get; set; }

    public IQueryable<T> ApplyFilter(IQueryable<T> query) => this.SearchCriteria == null ? query : this.SearchCriteria.ApplyFilter(query);

    public IQueryable<T> ApplySorting(IQueryable<T> query) => this.SearchCriteria == null ? query : this.SearchCriteria.ApplySorting(query);

    public IQueryable<T> ApplyPaging(IQueryable<T> query) => this.SearchCriteria == null ? query : this.SearchCriteria.ApplyPaging(query);

    public IQueryable<T> ApplyFilterPagingAndSorting(IQueryable<T> query) => this.SearchCriteria == null ? query : this.SearchCriteria.ApplyFilterPagingAndSorting(query);

    public void ApplyFilterPagingAndSorting(IList<T> list, ListResponse<T> response)
    {
      response.Items = this.ApplyFilterPagingAndSorting(list.AsQueryable<T>()).ToList<T>();
      response.TotalItems = list.Count;
    }
  }
}
