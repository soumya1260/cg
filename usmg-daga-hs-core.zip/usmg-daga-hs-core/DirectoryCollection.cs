﻿// Decompiled with JetBrains decompiler
// Type: HS.DirectoryCollection
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.Configuration;

namespace HS
{
  public class DirectoryCollection : ConfigurationElementCollection
  {
    public override ConfigurationElementCollectionType CollectionType => ConfigurationElementCollectionType.AddRemoveClearMap;

    protected override ConfigurationElement CreateNewElement() => (ConfigurationElement) new DirectoryElement();

    protected override ConfigurationElement CreateNewElement(string name) => (ConfigurationElement) new DirectoryElement()
    {
      Name = name
    };

    protected override object GetElementKey(ConfigurationElement element) => (object) ((DirectoryElement) element).Name;

    public new string AddElementName
    {
      get => base.AddElementName;
      set => base.AddElementName = value;
    }

    public new string ClearElementName
    {
      get => base.ClearElementName;
      set => base.AddElementName = value;
    }

    public new string RemoveElementName => base.RemoveElementName;

    public new int Count => base.Count;

    public DirectoryElement this[int index]
    {
      get => (DirectoryElement) this.BaseGet(index);
      set
      {
        if (this.BaseGet(index) != null)
          this.BaseRemoveAt(index);
        this.BaseAdd(index, (ConfigurationElement) value);
      }
    }

    public DirectoryElement this[string Name] => (DirectoryElement) this.BaseGet((object) Name);

    public int IndexOf(DirectoryElement item) => this.BaseIndexOf((ConfigurationElement) item);

    public void Add(DirectoryElement item) => this.BaseAdd((ConfigurationElement) item);

    protected override void BaseAdd(ConfigurationElement element) => this.BaseAdd(element, false);

    public void Remove(DirectoryElement item)
    {
      if (this.BaseIndexOf((ConfigurationElement) item) < 0)
        return;
      this.BaseRemove((object) item.Name);
    }

    public void RemoveAt(int index) => this.BaseRemoveAt(index);

    public void Remove(string name) => this.BaseRemove((object) name);

    public void Clear() => this.BaseClear();
  }
}
