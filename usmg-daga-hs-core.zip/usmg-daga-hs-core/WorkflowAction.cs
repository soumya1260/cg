﻿// Decompiled with JetBrains decompiler
// Type: HS.WorkflowAction
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace HS
{
  [DataContract]
  public class WorkflowAction
  {
    private List<ServiceFault> _reasons;

    [DataMember]
    public string Name { get; set; }

    [DataMember]
    public ActionStatus Status { get; set; }

    [DataMember]
    public List<ServiceFault> Reasons
    {
      get
      {
        if (this._reasons == null)
          this._reasons = new List<ServiceFault>();
        return this._reasons;
      }
      set => this._reasons = value;
    }

    public void Deny(ServiceFault reason)
    {
      if (this.Reasons == null)
        this.Reasons = new List<ServiceFault>();
      this.Reasons.Add(reason);
      this.Status = ActionStatus.Deny;
    }

    public void Deny(IEnumerable<ServiceFault> reasons)
    {
      if (this.Reasons == null)
        this.Reasons = new List<ServiceFault>();
      if (reasons != null)
        this.Reasons.AddRange(reasons);
      this.Status = ActionStatus.Deny;
    }

    public void Allow()
    {
      this.Reasons = new List<ServiceFault>();
      this.Status = ActionStatus.Allow;
    }

    public void AllowIfNoReasons()
    {
      if (this.Reasons != null && this.Reasons.Count != 0)
        return;
      this.Status = ActionStatus.Allow;
    }

    public bool Assert(Assertion test)
    {
      if (!test.Test)
        this.Deny(new ServiceFault()
        {
          Source = test.Source,
          Message = test.Message,
          IsLocalized = test.IsLocalized,
          FaultCode = test.FaultCode
        });
      return test.Test;
    }

    public bool Assert(bool test, Decimal faultCode)
    {
      if (!test)
        this.Deny(new ServiceFault()
        {
          Source = string.Empty,
          Message = string.Empty,
          IsLocalized = false,
          FaultCode = faultCode
        });
      return test;
    }

    public bool HasReason(ServiceFault reason) => this.Reasons != null && this.Reasons.Exists((Predicate<ServiceFault>) (f => f.GetType() == reason.GetType()));
  }
}
