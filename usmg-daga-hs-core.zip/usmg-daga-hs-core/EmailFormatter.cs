﻿// Decompiled with JetBrains decompiler
// Type: HS.EmailFormatter
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Configuration;
using System.IO;
using System.Text;

namespace HS
{
  public class EmailFormatter
  {
    public static string FormatEmailBodyForException(WriteToLogRequest req, bool IncludeLink)
    {
      StringBuilder stringBuilder = new StringBuilder();
      switch (req.LogMessage.MessageType)
      {
        case MessageTypeEnum.Informational:
          return EmailFormatter.FormatInformationalEmailBody(req);
        case MessageTypeEnum.Exception:
          return EmailFormatter.FormatExceptionEmailBody(req, IncludeLink);
        default:
          return EmailFormatter.FormatExceptionEmailBody(req, IncludeLink);
      }
    }

    public static string FormatExceptionEmailBody(WriteToLogRequest req, bool IncludeLink)
    {
      StringWriter stringWriter = new StringWriter();
      stringWriter.WriteLine("<div style='font-family:calibri,tahoma,arial;'><table cellpadding='2'>");
      string format = "<tr><td><b>{0}</b>:</td><td style='color:#222222; font-size:0.9em;'>{1}</td></tr>";
      stringWriter.WriteLine(string.Format(format, (object) "Log Entry ID", (object) req.LogMessage.OriginalMessageID.ToString()));
      stringWriter.WriteLine(string.Format(format, (object) "Title", (object) req.LogMessage.MessageTitle));
      stringWriter.WriteLine(string.Format(format, (object) "Application Name", (object) req.LogMessage.SendingApplication));
      stringWriter.WriteLine(string.Format(format, (object) "Server", (object) req.LogMessage.MessageSentFrom));
      stringWriter.WriteLine(string.Format(format, (object) "Exception Type", (object) req.LogMessage.ExceptionType));
      stringWriter.WriteLine(string.Format(format, (object) "Message Type", (object) req.LogMessage.MessageType.ToString()));
      stringWriter.WriteLine(string.Format(format, (object) "Promotion Environment", (object) req.LogMessage.PromotionEnvironment));
      stringWriter.WriteLine(string.Format(format, (object) "Message", (object) req.LogMessage.Message));
      if (req.LogMessage.ContainsException)
        stringWriter.WriteLine(string.Format(format, (object) "Exception Message", (object) req.LogMessage.ExceptionMessage));
      stringWriter.WriteLine(string.Format(format, (object) "NOTES:", (object) ""));
      if (req.LogMessage.AdditionalMessages != null && req.LogMessage.AdditionalMessages.Count > 0)
      {
        foreach (string additionalMessage in req.LogMessage.AdditionalMessages)
          stringWriter.WriteLine(string.Format(format, (object) "Note", (object) additionalMessage));
      }
      string str = ConfigurationManager.AppSettings.Get("LoggerAdminURL");
      if (IncludeLink)
        stringWriter.WriteLine(string.Format(format, (object) "Link", (object) ("Click <a href =\"http:\\\\" + str + "\\LogEntry.aspx?ID=" + (object) req.LogMessage.OriginalMessageID + "\"Here</a> to view Log Entry")));
      stringWriter.WriteLine(string.Format(format, (object) "Stack Trace", (object) ""));
      if (req.LogMessage.ExceptionStackTrace != null)
        stringWriter.WriteLine(string.Format(format, (object) "", (object) req.LogMessage.ExceptionStackTrace.ToString()));
      stringWriter.WriteLine("See Database Exception Log for more details.....");
      stringWriter.WriteLine(string.Format(format, (object) "", (object) ""));
      stringWriter.WriteLine(string.Format(format, (object) "This EMAIL Was Sent from the logging server :", (object) Environment.MachineName.ToString()));
      stringWriter.WriteLine("</table></div>");
      return stringWriter.ToString();
    }

    public static string FormatInformationalEmailBody(WriteToLogRequest req)
    {
      StringWriter stringWriter = new StringWriter();
      stringWriter.WriteLine("<div style='font-family:calibri,tahoma,arial;'><table cellpadding='2'>");
      string format = "<tr><td>{0}:</td><td style='color:#222222; font-size:0.9em;'>{1}</td></tr>";
      stringWriter.WriteLine(string.Format(format, (object) "Title", (object) req.LogMessage.MessageTitle));
      stringWriter.WriteLine(string.Format(format, (object) "Exception Type", (object) req.LogMessage.ExceptionType));
      stringWriter.WriteLine(string.Format(format, (object) "Application Name", (object) req.LogMessage.SendingApplication));
      stringWriter.WriteLine(string.Format(format, (object) "Server", (object) req.LogMessage.MessageSentFrom));
      stringWriter.WriteLine(string.Format(format, (object) "Message Type", (object) req.LogMessage.MessageType.ToString()));
      stringWriter.WriteLine(string.Format(format, (object) "Promotion Environment", (object) req.LogMessage.PromotionEnvironment));
      stringWriter.WriteLine(string.Format(format, (object) "Message", (object) req.LogMessage.Message));
      stringWriter.WriteLine(string.Format(format, (object) "NOTES:", (object) ""));
      if (req.LogMessage.AdditionalMessages == null && req.LogMessage.AdditionalMessages.Count > 0)
      {
        foreach (string additionalMessage in req.LogMessage.AdditionalMessages)
          stringWriter.WriteLine(string.Format(format, (object) "Note", (object) additionalMessage));
      }
      stringWriter.WriteLine(string.Format(format, (object) "Stack Strace:", (object) ""));
      if (req.LogMessage.ExceptionStackTrace != null)
        stringWriter.WriteLine(string.Format(format, (object) "Stack Trace", (object) req.LogMessage.ExceptionStackTrace.ToString()));
      stringWriter.WriteLine("</table></div>");
      return stringWriter.ToString();
    }
  }
}
