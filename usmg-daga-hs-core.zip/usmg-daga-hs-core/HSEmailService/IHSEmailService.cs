﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.IHSEmailService
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.CodeDom.Compiler;
using System.ServiceModel;

namespace HS.HSEmailService
{
  [GeneratedCode("System.ServiceModel", "4.0.0.0")]
  [ServiceContract(ConfigurationName = "HSEmailService.IHSEmailService")]
  public interface IHSEmailService
  {
    [OperationContract(Action = "http://tempuri.org/IHSEmailService/sendEmail", ReplyAction = "http://tempuri.org/IHSEmailService/sendEmailResponse")]
    bool sendEmail(Email email);

    [OperationContract(Action = "http://tempuri.org/IHSEmailService/sendAsyncEmail", IsOneWay = true)]
    void sendAsyncEmail(Email email);

    [OperationContract(Action = "http://tempuri.org/IHSEmailService/sendFax", ReplyAction = "http://tempuri.org/IHSEmailService/sendFaxResponse")]
    bool sendFax(Email email, string faxNumber);

    [OperationContract(Action = "http://tempuri.org/IHSEmailService/sendFaxXMeduis", ReplyAction = "http://tempuri.org/IHSEmailService/sendFaxXMeduisResponse")]
    FaxResult sendFaxXMeduis(XFax xfax);

    [OperationContract(Action = "http://tempuri.org/IHSEmailService/sendAsynFaxXMeduis", ReplyAction = "http://tempuri.org/IHSEmailService/sendAsynFaxXMeduisResponse")]
    bool sendAsynFaxXMeduis(XFax xfax);

    [OperationContract(Action = "http://tempuri.org/IHSEmailService/GetOutboundFaxesAdvanced", ReplyAction = "http://tempuri.org/IHSEmailService/GetOutboundFaxesAdvancedResponse")]
    OutboundUserFaxResponse GetOutboundFaxesAdvanced(
      XMediusFaxRetrieval xfaxDetails);

    [OperationContract(Action = "http://tempuri.org/IHSEmailService/GetOutboundFaxes", ReplyAction = "http://tempuri.org/IHSEmailService/GetOutboundFaxesResponse")]
    OutboundUserFaxResponse GetOutboundFaxes(XMediusFaxRetrieval xfaxDetails);

    [OperationContract(Action = "http://tempuri.org/IHSEmailService/GetOutgoingFaxes", ReplyAction = "http://tempuri.org/IHSEmailService/GetOutgoingFaxesResponse")]
    OutgoingFaxResponse GetOutgoingFaxes(XMediusFaxRetrieval xfaxDetails);

    [OperationContract(Action = "http://tempuri.org/IHSEmailService/GetOutgoingFaxesAdvanced", ReplyAction = "http://tempuri.org/IHSEmailService/GetOutgoingFaxesAdvancedResponse")]
    OutgoingFaxResponse GetOutgoingFaxesAdvanced(XMediusFaxRetrieval xfaxDetails);

    [OperationContract(Action = "http://tempuri.org/IHSEmailService/GetInboundFaxes", ReplyAction = "http://tempuri.org/IHSEmailService/GetInboundFaxesResponse")]
    InboundUserFaxResponse GetInboundFaxes(XMediusFaxRetrieval xfaxDetails);

    [OperationContract(Action = "http://tempuri.org/IHSEmailService/GetInboundFaxesAdvanced", ReplyAction = "http://tempuri.org/IHSEmailService/GetInboundFaxesAdvancedResponse")]
    InboundUserFaxResponse GetInboundFaxesAdvanced(
      XMediusFaxRetrieval xfaxDetails);
  }
}
