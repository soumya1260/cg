﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.OutboundSortProperty
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.CodeDom.Compiler;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DataContract(Name = "OutboundSortProperty", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail.XMediusFax")]
  public enum OutboundSortProperty
  {
    [EnumMember] UserId,
    [EnumMember] CompletedTime,
    [EnumMember] Duration,
    [EnumMember] ModifiedDestination,
    [EnumMember] Status,
    [EnumMember] ErrorCode,
    [EnumMember] SenderBillingCode,
    [EnumMember] SenderSubBillingCode,
    [EnumMember] RecipientBillingCode,
    [EnumMember] SenderSubBillingCode1,
    [EnumMember] RetryDelay,
    [EnumMember] RemoteCsid,
    [EnumMember] RecipientName,
    [EnumMember] Priority,
    [EnumMember] PagesSubmitted,
    [EnumMember] PagesSent,
    [EnumMember] OriginalTransactionId,
    [EnumMember] OriginalDestination,
    [EnumMember] NoOfRetries,
    [EnumMember] ErrorDescription,
    [EnumMember] ChannelNumber,
    [EnumMember] SubmittedTime,
    [EnumMember] BroadcastId,
    [EnumMember] AttemptCount,
    [EnumMember] ArchivedTime,
    [EnumMember] Speed,
    [EnumMember] Subject,
    [EnumMember] TransactionId,
  }
}
