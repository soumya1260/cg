﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.AttachedFile
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [DebuggerStepThrough]
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DataContract(Name = "AttachedFile", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail.XMediusFax")]
  [Serializable]
  public class AttachedFile : IExtensibleDataObject, INotifyPropertyChanged
  {
    [NonSerialized]
    private ExtensionDataObject extensionDataField;
    private byte[] contentsFieldField;
    private string nameFieldField;

    [Browsable(false)]
    public ExtensionDataObject ExtensionData
    {
      get => this.extensionDataField;
      set => this.extensionDataField = value;
    }

    [DataMember(IsRequired = true)]
    public byte[] contentsField
    {
      get => this.contentsFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.contentsFieldField, (object) value))
          return;
        this.contentsFieldField = value;
        this.RaisePropertyChanged(nameof (contentsField));
      }
    }

    [DataMember(IsRequired = true)]
    public string nameField
    {
      get => this.nameFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.nameFieldField, (object) value))
          return;
        this.nameFieldField = value;
        this.RaisePropertyChanged(nameof (nameField));
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
      if (propertyChanged == null)
        return;
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
