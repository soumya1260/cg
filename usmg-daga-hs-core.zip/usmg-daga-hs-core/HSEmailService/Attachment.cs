﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.Attachment
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DataContract(Name = "Attachment", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail")]
  [DebuggerStepThrough]
  [Serializable]
  public class Attachment : IExtensibleDataObject, INotifyPropertyChanged
  {
    [NonSerialized]
    private ExtensionDataObject extensionDataField;
    [OptionalField]
    private byte[] BytesField;
    [OptionalField]
    private string ContentTypeField;
    [OptionalField]
    private string FilenameField;

    [Browsable(false)]
    public ExtensionDataObject ExtensionData
    {
      get => this.extensionDataField;
      set => this.extensionDataField = value;
    }

    [DataMember]
    public byte[] Bytes
    {
      get => this.BytesField;
      set
      {
        if (object.ReferenceEquals((object) this.BytesField, (object) value))
          return;
        this.BytesField = value;
        this.RaisePropertyChanged(nameof (Bytes));
      }
    }

    [DataMember]
    public string ContentType
    {
      get => this.ContentTypeField;
      set
      {
        if (object.ReferenceEquals((object) this.ContentTypeField, (object) value))
          return;
        this.ContentTypeField = value;
        this.RaisePropertyChanged(nameof (ContentType));
      }
    }

    [DataMember]
    public string Filename
    {
      get => this.FilenameField;
      set
      {
        if (object.ReferenceEquals((object) this.FilenameField, (object) value))
          return;
        this.FilenameField = value;
        this.RaisePropertyChanged(nameof (Filename));
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
      if (propertyChanged == null)
        return;
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
