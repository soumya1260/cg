﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.OutgoingStatus
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.CodeDom.Compiler;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [DataContract(Name = "OutgoingStatus", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail.XMediusFax")]
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  public enum OutgoingStatus
  {
    [EnumMember] NotSpecified,
    [EnumMember] Preprocessing,
    [EnumMember] Authorizing,
    [EnumMember] Readytosend,
    [EnumMember] Sending,
    [EnumMember] Waitingtoretry,
    [EnumMember] Sent,
    [EnumMember] Failed,
    [EnumMember] Delayed,
  }
}
