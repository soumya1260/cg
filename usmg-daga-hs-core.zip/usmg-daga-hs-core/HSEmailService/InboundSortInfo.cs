﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.InboundSortInfo
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [DebuggerStepThrough]
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DataContract(Name = "InboundSortInfo", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail.XMediusFax")]
  [Serializable]
  public class InboundSortInfo : IExtensibleDataObject, INotifyPropertyChanged
  {
    [NonSerialized]
    private ExtensionDataObject extensionDataField;
    private bool ascendingFieldField;
    private InboundSortProperty sortPropertyFieldField;

    [Browsable(false)]
    public ExtensionDataObject ExtensionData
    {
      get => this.extensionDataField;
      set => this.extensionDataField = value;
    }

    [DataMember(IsRequired = true)]
    public bool ascendingField
    {
      get => this.ascendingFieldField;
      set
      {
        if (this.ascendingFieldField.Equals(value))
          return;
        this.ascendingFieldField = value;
        this.RaisePropertyChanged(nameof (ascendingField));
      }
    }

    [DataMember(IsRequired = true)]
    public InboundSortProperty sortPropertyField
    {
      get => this.sortPropertyFieldField;
      set
      {
        if (this.sortPropertyFieldField.Equals((object) value))
          return;
        this.sortPropertyFieldField = value;
        this.RaisePropertyChanged(nameof (sortPropertyField));
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
      if (propertyChanged == null)
        return;
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
