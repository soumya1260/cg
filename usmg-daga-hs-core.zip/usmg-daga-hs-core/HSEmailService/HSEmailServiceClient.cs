﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.HSEmailServiceClient
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.CodeDom.Compiler;
using System.Diagnostics;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace HS.HSEmailService
{
  [GeneratedCode("System.ServiceModel", "4.0.0.0")]
  [DebuggerStepThrough]
  public class HSEmailServiceClient : ClientBase<IHSEmailService>, IHSEmailService
  {
    public HSEmailServiceClient()
    {
    }

    public HSEmailServiceClient(string endpointConfigurationName)
      : base(endpointConfigurationName)
    {
    }

    public HSEmailServiceClient(string endpointConfigurationName, string remoteAddress)
      : base(endpointConfigurationName, remoteAddress)
    {
    }

    public HSEmailServiceClient(string endpointConfigurationName, EndpointAddress remoteAddress)
      : base(endpointConfigurationName, remoteAddress)
    {
    }

    public HSEmailServiceClient(Binding binding, EndpointAddress remoteAddress)
      : base(binding, remoteAddress)
    {
    }

    public bool sendEmail(Email email) => this.Channel.sendEmail(email);

    public void sendAsyncEmail(Email email) => this.Channel.sendAsyncEmail(email);

    public bool sendFax(Email email, string faxNumber) => this.Channel.sendFax(email, faxNumber);

    public FaxResult sendFaxXMeduis(XFax xfax) => this.Channel.sendFaxXMeduis(xfax);

    public bool sendAsynFaxXMeduis(XFax xfax) => this.Channel.sendAsynFaxXMeduis(xfax);

    public OutboundUserFaxResponse GetOutboundFaxesAdvanced(
      XMediusFaxRetrieval xfaxDetails)
    {
      return this.Channel.GetOutboundFaxesAdvanced(xfaxDetails);
    }

    public OutboundUserFaxResponse GetOutboundFaxes(
      XMediusFaxRetrieval xfaxDetails)
    {
      return this.Channel.GetOutboundFaxes(xfaxDetails);
    }

    public OutgoingFaxResponse GetOutgoingFaxes(XMediusFaxRetrieval xfaxDetails) => this.Channel.GetOutgoingFaxes(xfaxDetails);

    public OutgoingFaxResponse GetOutgoingFaxesAdvanced(
      XMediusFaxRetrieval xfaxDetails)
    {
      return this.Channel.GetOutgoingFaxesAdvanced(xfaxDetails);
    }

    public InboundUserFaxResponse GetInboundFaxes(
      XMediusFaxRetrieval xfaxDetails)
    {
      return this.Channel.GetInboundFaxes(xfaxDetails);
    }

    public InboundUserFaxResponse GetInboundFaxesAdvanced(
      XMediusFaxRetrieval xfaxDetails)
    {
      return this.Channel.GetInboundFaxesAdvanced(xfaxDetails);
    }
  }
}
