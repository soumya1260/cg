﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.XMediusFaxRetrieval
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DataContract(Name = "XMediusFaxRetrieval", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail")]
  [DebuggerStepThrough]
  [Serializable]
  public class XMediusFaxRetrieval : IExtensibleDataObject, INotifyPropertyChanged
  {
    [NonSerialized]
    private ExtensionDataObject extensionDataField;
    [OptionalField]
    private string AccountUserIDField;
    [OptionalField]
    private string AuthenticationTypeField;
    [OptionalField]
    private string FaxUserIDField;
    [OptionalField]
    private int MaxCountField;
    [OptionalField]
    private string ServicePasswordField;
    [OptionalField]
    private string ServiceUserField;
    [OptionalField]
    private int StartIndexField;
    [OptionalField]
    private InboundSortInfo iSortField;
    [OptionalField]
    private InboundUserKeywordInfo iUserKeywordInfoField;
    [OptionalField]
    private InboundUserSearchInfo iUserSearchInfoField;
    [OptionalField]
    private OutboundSortInfo oSortField;
    [OptionalField]
    private OutboundUserKeywordInfo oUserKeywordInfoField;
    [OptionalField]
    private OutboundUserSearchInfo oUserSearchInfoField;
    [OptionalField]
    private OutgoingSearchInfo ogSearchInfoField;

    [Browsable(false)]
    public ExtensionDataObject ExtensionData
    {
      get => this.extensionDataField;
      set => this.extensionDataField = value;
    }

    [DataMember]
    public string AccountUserID
    {
      get => this.AccountUserIDField;
      set
      {
        if (object.ReferenceEquals((object) this.AccountUserIDField, (object) value))
          return;
        this.AccountUserIDField = value;
        this.RaisePropertyChanged(nameof (AccountUserID));
      }
    }

    [DataMember]
    public string AuthenticationType
    {
      get => this.AuthenticationTypeField;
      set
      {
        if (object.ReferenceEquals((object) this.AuthenticationTypeField, (object) value))
          return;
        this.AuthenticationTypeField = value;
        this.RaisePropertyChanged(nameof (AuthenticationType));
      }
    }

    [DataMember]
    public string FaxUserID
    {
      get => this.FaxUserIDField;
      set
      {
        if (object.ReferenceEquals((object) this.FaxUserIDField, (object) value))
          return;
        this.FaxUserIDField = value;
        this.RaisePropertyChanged(nameof (FaxUserID));
      }
    }

    [DataMember]
    public int MaxCount
    {
      get => this.MaxCountField;
      set
      {
        if (this.MaxCountField.Equals(value))
          return;
        this.MaxCountField = value;
        this.RaisePropertyChanged(nameof (MaxCount));
      }
    }

    [DataMember]
    public string ServicePassword
    {
      get => this.ServicePasswordField;
      set
      {
        if (object.ReferenceEquals((object) this.ServicePasswordField, (object) value))
          return;
        this.ServicePasswordField = value;
        this.RaisePropertyChanged(nameof (ServicePassword));
      }
    }

    [DataMember]
    public string ServiceUser
    {
      get => this.ServiceUserField;
      set
      {
        if (object.ReferenceEquals((object) this.ServiceUserField, (object) value))
          return;
        this.ServiceUserField = value;
        this.RaisePropertyChanged(nameof (ServiceUser));
      }
    }

    [DataMember]
    public int StartIndex
    {
      get => this.StartIndexField;
      set
      {
        if (this.StartIndexField.Equals(value))
          return;
        this.StartIndexField = value;
        this.RaisePropertyChanged(nameof (StartIndex));
      }
    }

    [DataMember]
    public InboundSortInfo iSort
    {
      get => this.iSortField;
      set
      {
        if (object.ReferenceEquals((object) this.iSortField, (object) value))
          return;
        this.iSortField = value;
        this.RaisePropertyChanged(nameof (iSort));
      }
    }

    [DataMember]
    public InboundUserKeywordInfo iUserKeywordInfo
    {
      get => this.iUserKeywordInfoField;
      set
      {
        if (object.ReferenceEquals((object) this.iUserKeywordInfoField, (object) value))
          return;
        this.iUserKeywordInfoField = value;
        this.RaisePropertyChanged(nameof (iUserKeywordInfo));
      }
    }

    [DataMember]
    public InboundUserSearchInfo iUserSearchInfo
    {
      get => this.iUserSearchInfoField;
      set
      {
        if (object.ReferenceEquals((object) this.iUserSearchInfoField, (object) value))
          return;
        this.iUserSearchInfoField = value;
        this.RaisePropertyChanged(nameof (iUserSearchInfo));
      }
    }

    [DataMember]
    public OutboundSortInfo oSort
    {
      get => this.oSortField;
      set
      {
        if (object.ReferenceEquals((object) this.oSortField, (object) value))
          return;
        this.oSortField = value;
        this.RaisePropertyChanged(nameof (oSort));
      }
    }

    [DataMember]
    public OutboundUserKeywordInfo oUserKeywordInfo
    {
      get => this.oUserKeywordInfoField;
      set
      {
        if (object.ReferenceEquals((object) this.oUserKeywordInfoField, (object) value))
          return;
        this.oUserKeywordInfoField = value;
        this.RaisePropertyChanged(nameof (oUserKeywordInfo));
      }
    }

    [DataMember]
    public OutboundUserSearchInfo oUserSearchInfo
    {
      get => this.oUserSearchInfoField;
      set
      {
        if (object.ReferenceEquals((object) this.oUserSearchInfoField, (object) value))
          return;
        this.oUserSearchInfoField = value;
        this.RaisePropertyChanged(nameof (oUserSearchInfo));
      }
    }

    [DataMember]
    public OutgoingSearchInfo ogSearchInfo
    {
      get => this.ogSearchInfoField;
      set
      {
        if (object.ReferenceEquals((object) this.ogSearchInfoField, (object) value))
          return;
        this.ogSearchInfoField = value;
        this.RaisePropertyChanged(nameof (ogSearchInfo));
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
      if (propertyChanged == null)
        return;
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
