﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.Email
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DataContract(Name = "Email", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail")]
  [DebuggerStepThrough]
  [Serializable]
  public class Email : IExtensibleDataObject, INotifyPropertyChanged
  {
    [NonSerialized]
    private ExtensionDataObject extensionDataField;
    [OptionalField]
    private Attachment[] AttachmentsField;
    [OptionalField]
    private string BodyField;
    [OptionalField]
    private string CCField;
    [OptionalField]
    private string FromField;
    [OptionalField]
    private string SubjectField;
    [OptionalField]
    private string ToField;
    [OptionalField]
    private bool isHTMLField;

    [Browsable(false)]
    public ExtensionDataObject ExtensionData
    {
      get => this.extensionDataField;
      set => this.extensionDataField = value;
    }

    [DataMember]
    public Attachment[] Attachments
    {
      get => this.AttachmentsField;
      set
      {
        if (object.ReferenceEquals((object) this.AttachmentsField, (object) value))
          return;
        this.AttachmentsField = value;
        this.RaisePropertyChanged(nameof (Attachments));
      }
    }

    [DataMember]
    public string Body
    {
      get => this.BodyField;
      set
      {
        if (object.ReferenceEquals((object) this.BodyField, (object) value))
          return;
        this.BodyField = value;
        this.RaisePropertyChanged(nameof (Body));
      }
    }

    [DataMember]
    public string CC
    {
      get => this.CCField;
      set
      {
        if (object.ReferenceEquals((object) this.CCField, (object) value))
          return;
        this.CCField = value;
        this.RaisePropertyChanged(nameof (CC));
      }
    }

    [DataMember]
    public string From
    {
      get => this.FromField;
      set
      {
        if (object.ReferenceEquals((object) this.FromField, (object) value))
          return;
        this.FromField = value;
        this.RaisePropertyChanged(nameof (From));
      }
    }

    [DataMember]
    public string Subject
    {
      get => this.SubjectField;
      set
      {
        if (object.ReferenceEquals((object) this.SubjectField, (object) value))
          return;
        this.SubjectField = value;
        this.RaisePropertyChanged(nameof (Subject));
      }
    }

    [DataMember]
    public string To
    {
      get => this.ToField;
      set
      {
        if (object.ReferenceEquals((object) this.ToField, (object) value))
          return;
        this.ToField = value;
        this.RaisePropertyChanged(nameof (To));
      }
    }

    [DataMember]
    public bool isHTML
    {
      get => this.isHTMLField;
      set
      {
        if (this.isHTMLField.Equals(value))
          return;
        this.isHTMLField = value;
        this.RaisePropertyChanged(nameof (isHTML));
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
      if (propertyChanged == null)
        return;
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
