﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.InboundUserFaxItem
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [DebuggerStepThrough]
  [DataContract(Name = "InboundUserFaxItem", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail.XMediusFax")]
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [Serializable]
  public class InboundUserFaxItem : InboundFaxItem
  {
    private bool isForwardedFieldField;
    private bool isForwardedFieldSpecifiedField;
    private bool isViewedFieldField;
    private bool isViewedFieldSpecifiedField;
    private string noteFieldField;
    private string senderNameFieldField;
    private DateTime submittedTimeFieldField;
    private bool submittedTimeFieldSpecifiedField;

    [DataMember(IsRequired = true)]
    public bool isForwardedField
    {
      get => this.isForwardedFieldField;
      set
      {
        if (this.isForwardedFieldField.Equals(value))
          return;
        this.isForwardedFieldField = value;
        this.RaisePropertyChanged(nameof (isForwardedField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool isForwardedFieldSpecified
    {
      get => this.isForwardedFieldSpecifiedField;
      set
      {
        if (this.isForwardedFieldSpecifiedField.Equals(value))
          return;
        this.isForwardedFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (isForwardedFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public bool isViewedField
    {
      get => this.isViewedFieldField;
      set
      {
        if (this.isViewedFieldField.Equals(value))
          return;
        this.isViewedFieldField = value;
        this.RaisePropertyChanged(nameof (isViewedField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool isViewedFieldSpecified
    {
      get => this.isViewedFieldSpecifiedField;
      set
      {
        if (this.isViewedFieldSpecifiedField.Equals(value))
          return;
        this.isViewedFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (isViewedFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string noteField
    {
      get => this.noteFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.noteFieldField, (object) value))
          return;
        this.noteFieldField = value;
        this.RaisePropertyChanged(nameof (noteField));
      }
    }

    [DataMember(IsRequired = true)]
    public string senderNameField
    {
      get => this.senderNameFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.senderNameFieldField, (object) value))
          return;
        this.senderNameFieldField = value;
        this.RaisePropertyChanged(nameof (senderNameField));
      }
    }

    [DataMember(IsRequired = true)]
    public DateTime submittedTimeField
    {
      get => this.submittedTimeFieldField;
      set
      {
        if (this.submittedTimeFieldField.Equals(value))
          return;
        this.submittedTimeFieldField = value;
        this.RaisePropertyChanged(nameof (submittedTimeField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool submittedTimeFieldSpecified
    {
      get => this.submittedTimeFieldSpecifiedField;
      set
      {
        if (this.submittedTimeFieldSpecifiedField.Equals(value))
          return;
        this.submittedTimeFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (submittedTimeFieldSpecified));
      }
    }
  }
}
