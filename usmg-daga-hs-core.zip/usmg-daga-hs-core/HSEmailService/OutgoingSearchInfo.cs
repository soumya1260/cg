﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.OutgoingSearchInfo
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DataContract(Name = "OutgoingSearchInfo", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail.XMediusFax")]
  [DebuggerStepThrough]
  [Serializable]
  public class OutgoingSearchInfo : IExtensibleDataObject, INotifyPropertyChanged
  {
    [NonSerialized]
    private ExtensionDataObject extensionDataField;
    private string broadcastIdFieldField;
    private string modifiedDestinationFieldField;
    private string originalDestinationFieldField;
    private string originalTransactionIdFieldField;
    private SendingPriority priorityFieldField;
    private bool priorityFieldSpecifiedField;
    private DateTimeRange submittedTimeFieldField;
    private string transactionIdFieldField;
    private string userIdFieldField;

    [Browsable(false)]
    public ExtensionDataObject ExtensionData
    {
      get => this.extensionDataField;
      set => this.extensionDataField = value;
    }

    [DataMember(IsRequired = true)]
    public string broadcastIdField
    {
      get => this.broadcastIdFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.broadcastIdFieldField, (object) value))
          return;
        this.broadcastIdFieldField = value;
        this.RaisePropertyChanged(nameof (broadcastIdField));
      }
    }

    [DataMember(IsRequired = true)]
    public string modifiedDestinationField
    {
      get => this.modifiedDestinationFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.modifiedDestinationFieldField, (object) value))
          return;
        this.modifiedDestinationFieldField = value;
        this.RaisePropertyChanged(nameof (modifiedDestinationField));
      }
    }

    [DataMember(IsRequired = true)]
    public string originalDestinationField
    {
      get => this.originalDestinationFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.originalDestinationFieldField, (object) value))
          return;
        this.originalDestinationFieldField = value;
        this.RaisePropertyChanged(nameof (originalDestinationField));
      }
    }

    [DataMember(IsRequired = true)]
    public string originalTransactionIdField
    {
      get => this.originalTransactionIdFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.originalTransactionIdFieldField, (object) value))
          return;
        this.originalTransactionIdFieldField = value;
        this.RaisePropertyChanged(nameof (originalTransactionIdField));
      }
    }

    [DataMember(IsRequired = true)]
    public SendingPriority priorityField
    {
      get => this.priorityFieldField;
      set
      {
        if (this.priorityFieldField.Equals((object) value))
          return;
        this.priorityFieldField = value;
        this.RaisePropertyChanged(nameof (priorityField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool priorityFieldSpecified
    {
      get => this.priorityFieldSpecifiedField;
      set
      {
        if (this.priorityFieldSpecifiedField.Equals(value))
          return;
        this.priorityFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (priorityFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public DateTimeRange submittedTimeField
    {
      get => this.submittedTimeFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.submittedTimeFieldField, (object) value))
          return;
        this.submittedTimeFieldField = value;
        this.RaisePropertyChanged(nameof (submittedTimeField));
      }
    }

    [DataMember(IsRequired = true)]
    public string transactionIdField
    {
      get => this.transactionIdFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.transactionIdFieldField, (object) value))
          return;
        this.transactionIdFieldField = value;
        this.RaisePropertyChanged(nameof (transactionIdField));
      }
    }

    [DataMember(IsRequired = true)]
    public string userIdField
    {
      get => this.userIdFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.userIdFieldField, (object) value))
          return;
        this.userIdFieldField = value;
        this.RaisePropertyChanged(nameof (userIdField));
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
      if (propertyChanged == null)
        return;
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
