﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.InboundUserSearchInfo
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DataContract(Name = "InboundUserSearchInfo", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail.XMediusFax")]
  [DebuggerStepThrough]
  [Serializable]
  public class InboundUserSearchInfo : InboundSearchInfo
  {
    private bool isDeletedFieldField;
    private bool isDeletedFieldSpecifiedField;
    private string noteFieldField;
    private string userIdFieldField;

    [DataMember(IsRequired = true)]
    public bool isDeletedField
    {
      get => this.isDeletedFieldField;
      set
      {
        if (this.isDeletedFieldField.Equals(value))
          return;
        this.isDeletedFieldField = value;
        this.RaisePropertyChanged(nameof (isDeletedField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool isDeletedFieldSpecified
    {
      get => this.isDeletedFieldSpecifiedField;
      set
      {
        if (this.isDeletedFieldSpecifiedField.Equals(value))
          return;
        this.isDeletedFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (isDeletedFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string noteField
    {
      get => this.noteFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.noteFieldField, (object) value))
          return;
        this.noteFieldField = value;
        this.RaisePropertyChanged(nameof (noteField));
      }
    }

    [DataMember(IsRequired = true)]
    public string userIdField
    {
      get => this.userIdFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.userIdFieldField, (object) value))
          return;
        this.userIdFieldField = value;
        this.RaisePropertyChanged(nameof (userIdField));
      }
    }
  }
}
