﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.InboundFaxItem
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [DebuggerStepThrough]
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DataContract(Name = "InboundFaxItem", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail.XMediusFax")]
  [KnownType(typeof (InboundUserFaxItem))]
  [Serializable]
  public class InboundFaxItem : IExtensibleDataObject, INotifyPropertyChanged
  {
    [NonSerialized]
    private ExtensionDataObject extensionDataField;
    private string aniFieldField;
    private DateTime archivedTimeFieldField;
    private bool archivedTimeFieldSpecifiedField;
    private uint channelNumberFieldField;
    private bool channelNumberFieldSpecifiedField;
    private string dnisOrDidFieldField;
    private string dtmfFieldField;
    private uint durationFieldField;
    private bool durationFieldSpecifiedField;
    private uint errorCodeFieldField;
    private bool errorCodeFieldSpecifiedField;
    private string errorDescriptionFieldField;
    private string idFieldField;
    private string localCsidFieldField;
    private uint pagesReceivedFieldField;
    private bool pagesReceivedFieldSpecifiedField;
    private DateTime receivedTimeFieldField;
    private bool receivedTimeFieldSpecifiedField;
    private string remoteCsidFieldField;
    private string siteNameFieldField;
    private long speedFieldField;
    private bool speedFieldSpecifiedField;
    private InboundStatus statusFieldField;
    private bool statusFieldSpecifiedField;
    private string transactionIdFieldField;

    [Browsable(false)]
    public ExtensionDataObject ExtensionData
    {
      get => this.extensionDataField;
      set => this.extensionDataField = value;
    }

    [DataMember(IsRequired = true)]
    public string aniField
    {
      get => this.aniFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.aniFieldField, (object) value))
          return;
        this.aniFieldField = value;
        this.RaisePropertyChanged(nameof (aniField));
      }
    }

    [DataMember(IsRequired = true)]
    public DateTime archivedTimeField
    {
      get => this.archivedTimeFieldField;
      set
      {
        if (this.archivedTimeFieldField.Equals(value))
          return;
        this.archivedTimeFieldField = value;
        this.RaisePropertyChanged(nameof (archivedTimeField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool archivedTimeFieldSpecified
    {
      get => this.archivedTimeFieldSpecifiedField;
      set
      {
        if (this.archivedTimeFieldSpecifiedField.Equals(value))
          return;
        this.archivedTimeFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (archivedTimeFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public uint channelNumberField
    {
      get => this.channelNumberFieldField;
      set
      {
        if (this.channelNumberFieldField.Equals(value))
          return;
        this.channelNumberFieldField = value;
        this.RaisePropertyChanged(nameof (channelNumberField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool channelNumberFieldSpecified
    {
      get => this.channelNumberFieldSpecifiedField;
      set
      {
        if (this.channelNumberFieldSpecifiedField.Equals(value))
          return;
        this.channelNumberFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (channelNumberFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string dnisOrDidField
    {
      get => this.dnisOrDidFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.dnisOrDidFieldField, (object) value))
          return;
        this.dnisOrDidFieldField = value;
        this.RaisePropertyChanged(nameof (dnisOrDidField));
      }
    }

    [DataMember(IsRequired = true)]
    public string dtmfField
    {
      get => this.dtmfFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.dtmfFieldField, (object) value))
          return;
        this.dtmfFieldField = value;
        this.RaisePropertyChanged(nameof (dtmfField));
      }
    }

    [DataMember(IsRequired = true)]
    public uint durationField
    {
      get => this.durationFieldField;
      set
      {
        if (this.durationFieldField.Equals(value))
          return;
        this.durationFieldField = value;
        this.RaisePropertyChanged(nameof (durationField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool durationFieldSpecified
    {
      get => this.durationFieldSpecifiedField;
      set
      {
        if (this.durationFieldSpecifiedField.Equals(value))
          return;
        this.durationFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (durationFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public uint errorCodeField
    {
      get => this.errorCodeFieldField;
      set
      {
        if (this.errorCodeFieldField.Equals(value))
          return;
        this.errorCodeFieldField = value;
        this.RaisePropertyChanged(nameof (errorCodeField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool errorCodeFieldSpecified
    {
      get => this.errorCodeFieldSpecifiedField;
      set
      {
        if (this.errorCodeFieldSpecifiedField.Equals(value))
          return;
        this.errorCodeFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (errorCodeFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string errorDescriptionField
    {
      get => this.errorDescriptionFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.errorDescriptionFieldField, (object) value))
          return;
        this.errorDescriptionFieldField = value;
        this.RaisePropertyChanged(nameof (errorDescriptionField));
      }
    }

    [DataMember(IsRequired = true)]
    public string idField
    {
      get => this.idFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.idFieldField, (object) value))
          return;
        this.idFieldField = value;
        this.RaisePropertyChanged(nameof (idField));
      }
    }

    [DataMember(IsRequired = true)]
    public string localCsidField
    {
      get => this.localCsidFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.localCsidFieldField, (object) value))
          return;
        this.localCsidFieldField = value;
        this.RaisePropertyChanged(nameof (localCsidField));
      }
    }

    [DataMember(IsRequired = true)]
    public uint pagesReceivedField
    {
      get => this.pagesReceivedFieldField;
      set
      {
        if (this.pagesReceivedFieldField.Equals(value))
          return;
        this.pagesReceivedFieldField = value;
        this.RaisePropertyChanged(nameof (pagesReceivedField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool pagesReceivedFieldSpecified
    {
      get => this.pagesReceivedFieldSpecifiedField;
      set
      {
        if (this.pagesReceivedFieldSpecifiedField.Equals(value))
          return;
        this.pagesReceivedFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (pagesReceivedFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public DateTime receivedTimeField
    {
      get => this.receivedTimeFieldField;
      set
      {
        if (this.receivedTimeFieldField.Equals(value))
          return;
        this.receivedTimeFieldField = value;
        this.RaisePropertyChanged(nameof (receivedTimeField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool receivedTimeFieldSpecified
    {
      get => this.receivedTimeFieldSpecifiedField;
      set
      {
        if (this.receivedTimeFieldSpecifiedField.Equals(value))
          return;
        this.receivedTimeFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (receivedTimeFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string remoteCsidField
    {
      get => this.remoteCsidFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.remoteCsidFieldField, (object) value))
          return;
        this.remoteCsidFieldField = value;
        this.RaisePropertyChanged(nameof (remoteCsidField));
      }
    }

    [DataMember(IsRequired = true)]
    public string siteNameField
    {
      get => this.siteNameFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.siteNameFieldField, (object) value))
          return;
        this.siteNameFieldField = value;
        this.RaisePropertyChanged(nameof (siteNameField));
      }
    }

    [DataMember(IsRequired = true)]
    public long speedField
    {
      get => this.speedFieldField;
      set
      {
        if (this.speedFieldField.Equals(value))
          return;
        this.speedFieldField = value;
        this.RaisePropertyChanged(nameof (speedField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool speedFieldSpecified
    {
      get => this.speedFieldSpecifiedField;
      set
      {
        if (this.speedFieldSpecifiedField.Equals(value))
          return;
        this.speedFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (speedFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public InboundStatus statusField
    {
      get => this.statusFieldField;
      set
      {
        if (this.statusFieldField.Equals((object) value))
          return;
        this.statusFieldField = value;
        this.RaisePropertyChanged(nameof (statusField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool statusFieldSpecified
    {
      get => this.statusFieldSpecifiedField;
      set
      {
        if (this.statusFieldSpecifiedField.Equals(value))
          return;
        this.statusFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (statusFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string transactionIdField
    {
      get => this.transactionIdFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.transactionIdFieldField, (object) value))
          return;
        this.transactionIdFieldField = value;
        this.RaisePropertyChanged(nameof (transactionIdField));
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
      if (propertyChanged == null)
        return;
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
