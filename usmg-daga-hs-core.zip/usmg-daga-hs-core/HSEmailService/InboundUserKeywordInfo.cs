﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.InboundUserKeywordInfo
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [DataContract(Name = "InboundUserKeywordInfo", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail.XMediusFax")]
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DebuggerStepThrough]
  [Serializable]
  public class InboundUserKeywordInfo : KeywordInfo
  {
    private InboundUserKeywordProperty?[] propertyFieldField;

    [DataMember(IsRequired = true)]
    public InboundUserKeywordProperty?[] propertyField
    {
      get => this.propertyFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.propertyFieldField, (object) value))
          return;
        this.propertyFieldField = value;
        this.RaisePropertyChanged(nameof (propertyField));
      }
    }
  }
}
