﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.OutboundFaxItem
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DataContract(Name = "OutboundFaxItem", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail.XMediusFax")]
  [KnownType(typeof (OutboundUserFaxItem))]
  [DebuggerStepThrough]
  [Serializable]
  public class OutboundFaxItem : IExtensibleDataObject, INotifyPropertyChanged
  {
    [NonSerialized]
    private ExtensionDataObject extensionDataField;
    private DateTime archivedTimeFieldField;
    private bool archivedTimeFieldSpecifiedField;
    private uint attemptCountFieldField;
    private bool attemptCountFieldSpecifiedField;
    private string broadcastIdFieldField;
    private uint channelNumberFieldField;
    private bool channelNumberFieldSpecifiedField;
    private DateTime completedTimeFieldField;
    private bool completedTimeFieldSpecifiedField;
    private DateTime delayUntilFieldField;
    private bool delayUntilFieldSpecifiedField;
    private uint durationFieldField;
    private bool durationFieldSpecifiedField;
    private uint errorCodeFieldField;
    private bool errorCodeFieldSpecifiedField;
    private string errorDescriptionFieldField;
    private string idFieldField;
    private string modifiedDestinationFieldField;
    private uint noOfRetriesFieldField;
    private bool noOfRetriesFieldSpecifiedField;
    private string originalDestinationFieldField;
    private string originalTransactionIdFieldField;
    private uint pagesSentFieldField;
    private bool pagesSentFieldSpecifiedField;
    private uint pagesSubmittedFieldField;
    private bool pagesSubmittedFieldSpecifiedField;
    private SendingPriority priorityFieldField;
    private bool priorityFieldSpecifiedField;
    private string recipientBillingCodeFieldField;
    private string recipientNameFieldField;
    private string recipientSubBillingCodeFieldField;
    private string remoteCsidFieldField;
    private uint retryDelayFieldField;
    private bool retryDelayFieldSpecifiedField;
    private string senderBillingCodeFieldField;
    private string senderSubBillingCodeFieldField;
    private long speedFieldField;
    private bool speedFieldSpecifiedField;
    private OutboundStatus statusFieldField;
    private bool statusFieldSpecifiedField;
    private string subjectFieldField;
    private DateTime submittedTimeFieldField;
    private bool submittedTimeFieldSpecifiedField;
    private string transactionIdFieldField;
    private string userIdFieldField;

    [Browsable(false)]
    public ExtensionDataObject ExtensionData
    {
      get => this.extensionDataField;
      set => this.extensionDataField = value;
    }

    [DataMember(IsRequired = true)]
    public DateTime archivedTimeField
    {
      get => this.archivedTimeFieldField;
      set
      {
        if (this.archivedTimeFieldField.Equals(value))
          return;
        this.archivedTimeFieldField = value;
        this.RaisePropertyChanged(nameof (archivedTimeField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool archivedTimeFieldSpecified
    {
      get => this.archivedTimeFieldSpecifiedField;
      set
      {
        if (this.archivedTimeFieldSpecifiedField.Equals(value))
          return;
        this.archivedTimeFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (archivedTimeFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public uint attemptCountField
    {
      get => this.attemptCountFieldField;
      set
      {
        if (this.attemptCountFieldField.Equals(value))
          return;
        this.attemptCountFieldField = value;
        this.RaisePropertyChanged(nameof (attemptCountField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool attemptCountFieldSpecified
    {
      get => this.attemptCountFieldSpecifiedField;
      set
      {
        if (this.attemptCountFieldSpecifiedField.Equals(value))
          return;
        this.attemptCountFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (attemptCountFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string broadcastIdField
    {
      get => this.broadcastIdFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.broadcastIdFieldField, (object) value))
          return;
        this.broadcastIdFieldField = value;
        this.RaisePropertyChanged(nameof (broadcastIdField));
      }
    }

    [DataMember(IsRequired = true)]
    public uint channelNumberField
    {
      get => this.channelNumberFieldField;
      set
      {
        if (this.channelNumberFieldField.Equals(value))
          return;
        this.channelNumberFieldField = value;
        this.RaisePropertyChanged(nameof (channelNumberField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool channelNumberFieldSpecified
    {
      get => this.channelNumberFieldSpecifiedField;
      set
      {
        if (this.channelNumberFieldSpecifiedField.Equals(value))
          return;
        this.channelNumberFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (channelNumberFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public DateTime completedTimeField
    {
      get => this.completedTimeFieldField;
      set
      {
        if (this.completedTimeFieldField.Equals(value))
          return;
        this.completedTimeFieldField = value;
        this.RaisePropertyChanged(nameof (completedTimeField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool completedTimeFieldSpecified
    {
      get => this.completedTimeFieldSpecifiedField;
      set
      {
        if (this.completedTimeFieldSpecifiedField.Equals(value))
          return;
        this.completedTimeFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (completedTimeFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public DateTime delayUntilField
    {
      get => this.delayUntilFieldField;
      set
      {
        if (this.delayUntilFieldField.Equals(value))
          return;
        this.delayUntilFieldField = value;
        this.RaisePropertyChanged(nameof (delayUntilField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool delayUntilFieldSpecified
    {
      get => this.delayUntilFieldSpecifiedField;
      set
      {
        if (this.delayUntilFieldSpecifiedField.Equals(value))
          return;
        this.delayUntilFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (delayUntilFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public uint durationField
    {
      get => this.durationFieldField;
      set
      {
        if (this.durationFieldField.Equals(value))
          return;
        this.durationFieldField = value;
        this.RaisePropertyChanged(nameof (durationField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool durationFieldSpecified
    {
      get => this.durationFieldSpecifiedField;
      set
      {
        if (this.durationFieldSpecifiedField.Equals(value))
          return;
        this.durationFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (durationFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public uint errorCodeField
    {
      get => this.errorCodeFieldField;
      set
      {
        if (this.errorCodeFieldField.Equals(value))
          return;
        this.errorCodeFieldField = value;
        this.RaisePropertyChanged(nameof (errorCodeField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool errorCodeFieldSpecified
    {
      get => this.errorCodeFieldSpecifiedField;
      set
      {
        if (this.errorCodeFieldSpecifiedField.Equals(value))
          return;
        this.errorCodeFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (errorCodeFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string errorDescriptionField
    {
      get => this.errorDescriptionFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.errorDescriptionFieldField, (object) value))
          return;
        this.errorDescriptionFieldField = value;
        this.RaisePropertyChanged(nameof (errorDescriptionField));
      }
    }

    [DataMember(IsRequired = true)]
    public string idField
    {
      get => this.idFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.idFieldField, (object) value))
          return;
        this.idFieldField = value;
        this.RaisePropertyChanged(nameof (idField));
      }
    }

    [DataMember(IsRequired = true)]
    public string modifiedDestinationField
    {
      get => this.modifiedDestinationFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.modifiedDestinationFieldField, (object) value))
          return;
        this.modifiedDestinationFieldField = value;
        this.RaisePropertyChanged(nameof (modifiedDestinationField));
      }
    }

    [DataMember(IsRequired = true)]
    public uint noOfRetriesField
    {
      get => this.noOfRetriesFieldField;
      set
      {
        if (this.noOfRetriesFieldField.Equals(value))
          return;
        this.noOfRetriesFieldField = value;
        this.RaisePropertyChanged(nameof (noOfRetriesField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool noOfRetriesFieldSpecified
    {
      get => this.noOfRetriesFieldSpecifiedField;
      set
      {
        if (this.noOfRetriesFieldSpecifiedField.Equals(value))
          return;
        this.noOfRetriesFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (noOfRetriesFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string originalDestinationField
    {
      get => this.originalDestinationFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.originalDestinationFieldField, (object) value))
          return;
        this.originalDestinationFieldField = value;
        this.RaisePropertyChanged(nameof (originalDestinationField));
      }
    }

    [DataMember(IsRequired = true)]
    public string originalTransactionIdField
    {
      get => this.originalTransactionIdFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.originalTransactionIdFieldField, (object) value))
          return;
        this.originalTransactionIdFieldField = value;
        this.RaisePropertyChanged(nameof (originalTransactionIdField));
      }
    }

    [DataMember(IsRequired = true)]
    public uint pagesSentField
    {
      get => this.pagesSentFieldField;
      set
      {
        if (this.pagesSentFieldField.Equals(value))
          return;
        this.pagesSentFieldField = value;
        this.RaisePropertyChanged(nameof (pagesSentField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool pagesSentFieldSpecified
    {
      get => this.pagesSentFieldSpecifiedField;
      set
      {
        if (this.pagesSentFieldSpecifiedField.Equals(value))
          return;
        this.pagesSentFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (pagesSentFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public uint pagesSubmittedField
    {
      get => this.pagesSubmittedFieldField;
      set
      {
        if (this.pagesSubmittedFieldField.Equals(value))
          return;
        this.pagesSubmittedFieldField = value;
        this.RaisePropertyChanged(nameof (pagesSubmittedField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool pagesSubmittedFieldSpecified
    {
      get => this.pagesSubmittedFieldSpecifiedField;
      set
      {
        if (this.pagesSubmittedFieldSpecifiedField.Equals(value))
          return;
        this.pagesSubmittedFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (pagesSubmittedFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public SendingPriority priorityField
    {
      get => this.priorityFieldField;
      set
      {
        if (this.priorityFieldField.Equals((object) value))
          return;
        this.priorityFieldField = value;
        this.RaisePropertyChanged(nameof (priorityField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool priorityFieldSpecified
    {
      get => this.priorityFieldSpecifiedField;
      set
      {
        if (this.priorityFieldSpecifiedField.Equals(value))
          return;
        this.priorityFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (priorityFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string recipientBillingCodeField
    {
      get => this.recipientBillingCodeFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.recipientBillingCodeFieldField, (object) value))
          return;
        this.recipientBillingCodeFieldField = value;
        this.RaisePropertyChanged(nameof (recipientBillingCodeField));
      }
    }

    [DataMember(IsRequired = true)]
    public string recipientNameField
    {
      get => this.recipientNameFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.recipientNameFieldField, (object) value))
          return;
        this.recipientNameFieldField = value;
        this.RaisePropertyChanged(nameof (recipientNameField));
      }
    }

    [DataMember(IsRequired = true)]
    public string recipientSubBillingCodeField
    {
      get => this.recipientSubBillingCodeFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.recipientSubBillingCodeFieldField, (object) value))
          return;
        this.recipientSubBillingCodeFieldField = value;
        this.RaisePropertyChanged(nameof (recipientSubBillingCodeField));
      }
    }

    [DataMember(IsRequired = true)]
    public string remoteCsidField
    {
      get => this.remoteCsidFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.remoteCsidFieldField, (object) value))
          return;
        this.remoteCsidFieldField = value;
        this.RaisePropertyChanged(nameof (remoteCsidField));
      }
    }

    [DataMember(IsRequired = true)]
    public uint retryDelayField
    {
      get => this.retryDelayFieldField;
      set
      {
        if (this.retryDelayFieldField.Equals(value))
          return;
        this.retryDelayFieldField = value;
        this.RaisePropertyChanged(nameof (retryDelayField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool retryDelayFieldSpecified
    {
      get => this.retryDelayFieldSpecifiedField;
      set
      {
        if (this.retryDelayFieldSpecifiedField.Equals(value))
          return;
        this.retryDelayFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (retryDelayFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string senderBillingCodeField
    {
      get => this.senderBillingCodeFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.senderBillingCodeFieldField, (object) value))
          return;
        this.senderBillingCodeFieldField = value;
        this.RaisePropertyChanged(nameof (senderBillingCodeField));
      }
    }

    [DataMember(IsRequired = true)]
    public string senderSubBillingCodeField
    {
      get => this.senderSubBillingCodeFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.senderSubBillingCodeFieldField, (object) value))
          return;
        this.senderSubBillingCodeFieldField = value;
        this.RaisePropertyChanged(nameof (senderSubBillingCodeField));
      }
    }

    [DataMember(IsRequired = true)]
    public long speedField
    {
      get => this.speedFieldField;
      set
      {
        if (this.speedFieldField.Equals(value))
          return;
        this.speedFieldField = value;
        this.RaisePropertyChanged(nameof (speedField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool speedFieldSpecified
    {
      get => this.speedFieldSpecifiedField;
      set
      {
        if (this.speedFieldSpecifiedField.Equals(value))
          return;
        this.speedFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (speedFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public OutboundStatus statusField
    {
      get => this.statusFieldField;
      set
      {
        if (this.statusFieldField.Equals((object) value))
          return;
        this.statusFieldField = value;
        this.RaisePropertyChanged(nameof (statusField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool statusFieldSpecified
    {
      get => this.statusFieldSpecifiedField;
      set
      {
        if (this.statusFieldSpecifiedField.Equals(value))
          return;
        this.statusFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (statusFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string subjectField
    {
      get => this.subjectFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.subjectFieldField, (object) value))
          return;
        this.subjectFieldField = value;
        this.RaisePropertyChanged(nameof (subjectField));
      }
    }

    [DataMember(IsRequired = true)]
    public DateTime submittedTimeField
    {
      get => this.submittedTimeFieldField;
      set
      {
        if (this.submittedTimeFieldField.Equals(value))
          return;
        this.submittedTimeFieldField = value;
        this.RaisePropertyChanged(nameof (submittedTimeField));
      }
    }

    [DataMember(IsRequired = true)]
    public bool submittedTimeFieldSpecified
    {
      get => this.submittedTimeFieldSpecifiedField;
      set
      {
        if (this.submittedTimeFieldSpecifiedField.Equals(value))
          return;
        this.submittedTimeFieldSpecifiedField = value;
        this.RaisePropertyChanged(nameof (submittedTimeFieldSpecified));
      }
    }

    [DataMember(IsRequired = true)]
    public string transactionIdField
    {
      get => this.transactionIdFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.transactionIdFieldField, (object) value))
          return;
        this.transactionIdFieldField = value;
        this.RaisePropertyChanged(nameof (transactionIdField));
      }
    }

    [DataMember(IsRequired = true)]
    public string userIdField
    {
      get => this.userIdFieldField;
      set
      {
        if (object.ReferenceEquals((object) this.userIdFieldField, (object) value))
          return;
        this.userIdFieldField = value;
        this.RaisePropertyChanged(nameof (userIdField));
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
      if (propertyChanged == null)
        return;
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
