﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailService.XFax
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace HS.HSEmailService
{
  [GeneratedCode("System.Runtime.Serialization", "4.0.0.0")]
  [DebuggerStepThrough]
  [DataContract(Name = "XFax", Namespace = "http://schemas.datacontract.org/2004/07/HSEmail")]
  [Serializable]
  public class XFax : IExtensibleDataObject, INotifyPropertyChanged
  {
    [NonSerialized]
    private ExtensionDataObject extensionDataField;
    [OptionalField]
    private string AccountUserIDField;
    [OptionalField]
    private AttachedFile[] AttachmentsField;
    [OptionalField]
    private string AuthenticationTypeField;
    [OptionalField]
    private string CommentField;
    [OptionalField]
    private string CoverPageField;
    [OptionalField]
    private uint FaxOptionsNoOfRetriesField;
    [OptionalField]
    private bool FaxOptionsNotifyOnSuccessField;
    [OptionalField]
    private string RecipientCompanyField;
    [OptionalField]
    private string RecipientFaxNumberField;
    [OptionalField]
    private string RecipientNameField;
    [OptionalField]
    private string SenderBillingCodeField;
    [OptionalField]
    private string SenderEmailField;
    [OptionalField]
    private string SenderFNameField;
    [OptionalField]
    private string SenderLNameField;
    [OptionalField]
    private string SenderNumberField;
    [OptionalField]
    private string SenderSubBillingCodeField;
    [OptionalField]
    private string ServicePasswordField;
    [OptionalField]
    private string ServiceUserField;
    [OptionalField]
    private string SubjectField;

    [Browsable(false)]
    public ExtensionDataObject ExtensionData
    {
      get => this.extensionDataField;
      set => this.extensionDataField = value;
    }

    [DataMember]
    public string AccountUserID
    {
      get => this.AccountUserIDField;
      set
      {
        if (object.ReferenceEquals((object) this.AccountUserIDField, (object) value))
          return;
        this.AccountUserIDField = value;
        this.RaisePropertyChanged(nameof (AccountUserID));
      }
    }

    [DataMember]
    public AttachedFile[] Attachments
    {
      get => this.AttachmentsField;
      set
      {
        if (object.ReferenceEquals((object) this.AttachmentsField, (object) value))
          return;
        this.AttachmentsField = value;
        this.RaisePropertyChanged(nameof (Attachments));
      }
    }

    [DataMember]
    public string AuthenticationType
    {
      get => this.AuthenticationTypeField;
      set
      {
        if (object.ReferenceEquals((object) this.AuthenticationTypeField, (object) value))
          return;
        this.AuthenticationTypeField = value;
        this.RaisePropertyChanged(nameof (AuthenticationType));
      }
    }

    [DataMember]
    public string Comment
    {
      get => this.CommentField;
      set
      {
        if (object.ReferenceEquals((object) this.CommentField, (object) value))
          return;
        this.CommentField = value;
        this.RaisePropertyChanged(nameof (Comment));
      }
    }

    [DataMember]
    public string CoverPage
    {
      get => this.CoverPageField;
      set
      {
        if (object.ReferenceEquals((object) this.CoverPageField, (object) value))
          return;
        this.CoverPageField = value;
        this.RaisePropertyChanged(nameof (CoverPage));
      }
    }

    [DataMember]
    public uint FaxOptionsNoOfRetries
    {
      get => this.FaxOptionsNoOfRetriesField;
      set
      {
        if (this.FaxOptionsNoOfRetriesField.Equals(value))
          return;
        this.FaxOptionsNoOfRetriesField = value;
        this.RaisePropertyChanged(nameof (FaxOptionsNoOfRetries));
      }
    }

    [DataMember]
    public bool FaxOptionsNotifyOnSuccess
    {
      get => this.FaxOptionsNotifyOnSuccessField;
      set
      {
        if (this.FaxOptionsNotifyOnSuccessField.Equals(value))
          return;
        this.FaxOptionsNotifyOnSuccessField = value;
        this.RaisePropertyChanged(nameof (FaxOptionsNotifyOnSuccess));
      }
    }

    [DataMember]
    public string RecipientCompany
    {
      get => this.RecipientCompanyField;
      set
      {
        if (object.ReferenceEquals((object) this.RecipientCompanyField, (object) value))
          return;
        this.RecipientCompanyField = value;
        this.RaisePropertyChanged(nameof (RecipientCompany));
      }
    }

    [DataMember]
    public string RecipientFaxNumber
    {
      get => this.RecipientFaxNumberField;
      set
      {
        if (object.ReferenceEquals((object) this.RecipientFaxNumberField, (object) value))
          return;
        this.RecipientFaxNumberField = value;
        this.RaisePropertyChanged(nameof (RecipientFaxNumber));
      }
    }

    [DataMember]
    public string RecipientName
    {
      get => this.RecipientNameField;
      set
      {
        if (object.ReferenceEquals((object) this.RecipientNameField, (object) value))
          return;
        this.RecipientNameField = value;
        this.RaisePropertyChanged(nameof (RecipientName));
      }
    }

    [DataMember]
    public string SenderBillingCode
    {
      get => this.SenderBillingCodeField;
      set
      {
        if (object.ReferenceEquals((object) this.SenderBillingCodeField, (object) value))
          return;
        this.SenderBillingCodeField = value;
        this.RaisePropertyChanged(nameof (SenderBillingCode));
      }
    }

    [DataMember]
    public string SenderEmail
    {
      get => this.SenderEmailField;
      set
      {
        if (object.ReferenceEquals((object) this.SenderEmailField, (object) value))
          return;
        this.SenderEmailField = value;
        this.RaisePropertyChanged(nameof (SenderEmail));
      }
    }

    [DataMember]
    public string SenderFName
    {
      get => this.SenderFNameField;
      set
      {
        if (object.ReferenceEquals((object) this.SenderFNameField, (object) value))
          return;
        this.SenderFNameField = value;
        this.RaisePropertyChanged(nameof (SenderFName));
      }
    }

    [DataMember]
    public string SenderLName
    {
      get => this.SenderLNameField;
      set
      {
        if (object.ReferenceEquals((object) this.SenderLNameField, (object) value))
          return;
        this.SenderLNameField = value;
        this.RaisePropertyChanged(nameof (SenderLName));
      }
    }

    [DataMember]
    public string SenderNumber
    {
      get => this.SenderNumberField;
      set
      {
        if (object.ReferenceEquals((object) this.SenderNumberField, (object) value))
          return;
        this.SenderNumberField = value;
        this.RaisePropertyChanged(nameof (SenderNumber));
      }
    }

    [DataMember]
    public string SenderSubBillingCode
    {
      get => this.SenderSubBillingCodeField;
      set
      {
        if (object.ReferenceEquals((object) this.SenderSubBillingCodeField, (object) value))
          return;
        this.SenderSubBillingCodeField = value;
        this.RaisePropertyChanged(nameof (SenderSubBillingCode));
      }
    }

    [DataMember]
    public string ServicePassword
    {
      get => this.ServicePasswordField;
      set
      {
        if (object.ReferenceEquals((object) this.ServicePasswordField, (object) value))
          return;
        this.ServicePasswordField = value;
        this.RaisePropertyChanged(nameof (ServicePassword));
      }
    }

    [DataMember]
    public string ServiceUser
    {
      get => this.ServiceUserField;
      set
      {
        if (object.ReferenceEquals((object) this.ServiceUserField, (object) value))
          return;
        this.ServiceUserField = value;
        this.RaisePropertyChanged(nameof (ServiceUser));
      }
    }

    [DataMember]
    public string Subject
    {
      get => this.SubjectField;
      set
      {
        if (object.ReferenceEquals((object) this.SubjectField, (object) value))
          return;
        this.SubjectField = value;
        this.RaisePropertyChanged(nameof (Subject));
      }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
      if (propertyChanged == null)
        return;
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
