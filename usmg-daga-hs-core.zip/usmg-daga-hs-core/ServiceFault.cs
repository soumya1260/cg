﻿// Decompiled with JetBrains decompiler
// Type: HS.ServiceFault
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Runtime.Serialization;

namespace HS
{
  [DataContract]
  public class ServiceFault
  {
    public const Decimal NullReference = -0.0010M;
    public const Decimal StringOverflow = -0.0020M;
    public const Decimal MissingField = -0.0030M;
    public const Decimal MismatchedKey = -0.0040M;
    public const Decimal FieldOutOfRange = -0.0050M;
    public const Decimal DataWasUpdatedSinceLastRead = -0.0060M;
    public const Decimal ActionIsDisabled = -0.0070M;
    public const Decimal NoSelection = -0.0080M;
    public const Decimal InvalidNumber = -0.0090M;
    public const Decimal InvalidDate = -0.0100M;
    public const Decimal ItemDoesNotExist = -0.0110M;
    public const Decimal UnexpectedError = -0.9999M;
    public const Decimal ValidationError = -0.0120M;
    public const Decimal TooManyResultsFound = -0.0130M;
    private bool _isLocalized = true;

    [DataMember]
    public string Message { get; set; }

    [DataMember]
    public string Source { get; set; }

    [DataMember]
    public bool IsLocalized
    {
      get => this._isLocalized;
      set => this._isLocalized = value;
    }

    [DataMember]
    public Decimal FaultCode { get; set; }

    public ServiceFault()
    {
    }

    public ServiceFault(Decimal faultCode) => this.FaultCode = faultCode;
  }
}
