﻿// Decompiled with JetBrains decompiler
// Type: HS.ListDictionary`2
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Serialization;

namespace HS
{
  [CollectionDataContract(Name = "ListDictionary")]
  [Serializable]
  public class ListDictionary<TKey, TValue> : 
    IDictionary<TKey, TValue>,
    ICollection<KeyValuePair<TKey, TValue>>,
    IEnumerable<KeyValuePair<TKey, TValue>>,
    IEnumerable,
    ISerializable
  {
    private System.Collections.Generic.List<TKey> _list;
    private System.Collections.Generic.Dictionary<TKey, TValue> _dictionary;

    protected System.Collections.Generic.List<TKey> List
    {
      get => this._list;
      set => this._list = value;
    }

    protected System.Collections.Generic.Dictionary<TKey, TValue> Dictionary
    {
      get => this._dictionary;
      set => this._dictionary = value;
    }

    public void Add(TKey key, TValue value)
    {
      this._dictionary.Add(key, value);
      this._list.Add(key);
    }

    public bool ContainsKey(TKey key) => this._dictionary.ContainsKey(key);

    public ICollection<TKey> Keys => (ICollection<TKey>) new ReadOnlyCollection<TKey>((IList<TKey>) this._list);

    public bool Remove(TKey key)
    {
      this._list.Remove(key);
      return this._dictionary.Remove(key);
    }

    public bool TryGetValue(TKey key, out TValue value) => this._dictionary.TryGetValue(key, out value);

    public ICollection<TValue> Values => (ICollection<TValue>) new ReadOnlyCollection<TValue>((IList<TValue>) this._list.Select<TKey, TValue>((Func<TKey, TValue>) (i => this._dictionary[i])).ToList<TValue>());

    public TValue this[TKey key]
    {
      get => this._dictionary[key];
      set
      {
        if (!this._dictionary.ContainsKey(key))
          this._list.Add(key);
        this._dictionary[key] = value;
      }
    }

    public void Add(KeyValuePair<TKey, TValue> item)
    {
      this._dictionary.Add(item.Key, item.Value);
      this._list.Add(item.Key);
    }

    public void Clear()
    {
      this._list.Clear();
      this._dictionary.Clear();
    }

    public bool Contains(KeyValuePair<TKey, TValue> item) => this._dictionary.Contains<KeyValuePair<TKey, TValue>>(item);

    public void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
    {
      if (array == null)
        throw new ArgumentNullException(nameof (array), "array is a null reference");
      if (arrayIndex < 0)
        throw new ArgumentOutOfRangeException(nameof (arrayIndex), "index is less than zero.");
      if (arrayIndex >= array.Length)
        throw new ArgumentException(nameof (arrayIndex), "index is equal to or greater than the length of array.");
      if (this._list.Count >= array.Length - arrayIndex)
        throw new ArgumentException(nameof (arrayIndex), "The number of elements in the source Dictionary<(Of <(TKey, TValue>)>).ValueCollection is greater than the available space from index to the end of the destination array.");
      for (int index = 0; index < this._list.Count; ++index)
      {
        TKey key = this._list[index];
        array[arrayIndex + index] = new KeyValuePair<TKey, TValue>(key, this._dictionary[key]);
      }
    }

    public int Count => this._list.Count;

    public bool IsReadOnly => false;

    public bool Remove(KeyValuePair<TKey, TValue> item)
    {
      this._list.Remove(item.Key);
      return this._dictionary.Remove(item.Key);
    }

    public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
    {
      foreach (TKey key in this._list)
        yield return new KeyValuePair<TKey, TValue>(key, this._dictionary[key]);
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
      foreach (TKey key in this._list)
        yield return (object) new KeyValuePair<TKey, TValue>(key, this._dictionary[key]);
    }

    public void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      info.AddValue("_list", (object) this._list);
      info.AddValue("_dictionary", (object) this._dictionary);
    }

    public ListDictionary()
    {
      this._list = new System.Collections.Generic.List<TKey>();
      this._dictionary = new System.Collections.Generic.Dictionary<TKey, TValue>();
    }

    public ListDictionary(int capacity)
    {
      this._list = new System.Collections.Generic.List<TKey>(capacity);
      this._dictionary = new System.Collections.Generic.Dictionary<TKey, TValue>(capacity);
    }

    public ListDictionary(IEqualityComparer<TKey> comparer)
    {
      this._list = new System.Collections.Generic.List<TKey>();
      this._dictionary = new System.Collections.Generic.Dictionary<TKey, TValue>(comparer);
    }

    public ListDictionary(IDictionary<TKey, TValue> dictionary)
    {
      this._list = new System.Collections.Generic.List<TKey>((IEnumerable<TKey>) dictionary.Keys);
      this._dictionary = new System.Collections.Generic.Dictionary<TKey, TValue>(dictionary);
    }

    public ListDictionary(int capacity, IEqualityComparer<TKey> comparer)
    {
      this._list = new System.Collections.Generic.List<TKey>(capacity);
      this._dictionary = new System.Collections.Generic.Dictionary<TKey, TValue>(capacity, comparer);
    }

    public ListDictionary(IDictionary<TKey, TValue> dictionary, IEqualityComparer<TKey> comparer)
    {
      this._list = new System.Collections.Generic.List<TKey>((IEnumerable<TKey>) dictionary.Keys);
      this._dictionary = new System.Collections.Generic.Dictionary<TKey, TValue>(dictionary, comparer);
    }

    protected ListDictionary(SerializationInfo info, StreamingContext context)
    {
      this._list = (System.Collections.Generic.List<TKey>) info.GetValue(nameof (_list), typeof (System.Collections.Generic.List<TKey>));
      this._dictionary = (System.Collections.Generic.Dictionary<TKey, TValue>) info.GetValue(nameof (_dictionary), typeof (System.Collections.Generic.Dictionary<TKey, TValue>));
    }
  }
}
