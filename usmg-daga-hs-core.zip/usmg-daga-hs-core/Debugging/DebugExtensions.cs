﻿// Decompiled with JetBrains decompiler
// Type: HS.Debugging.DebugExtensions
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace HS.Debugging
{
  public static class DebugExtensions
  {
    [DebuggerStepThrough]
    public static void ToDebug(this string source)
    {
    }

    [DebuggerStepThrough]
    public static void ToDebug(this string source, params object[] data)
    {
    }

    [DebuggerStepThrough]
    public static void ToDebugLine(this string source)
    {
    }

    [DebuggerStepThrough]
    public static void ToDebugLine(this string source, params object[] data)
    {
    }

    [DebuggerStepThrough]
    public static void ToDebug(this Exception source)
    {
    }

    [DebuggerStepThrough]
    public static void ToDebug(this Exception source, string message) => source.ToDebug();

    [DebuggerStepThrough]
    public static void ToDebug(this Exception source, string message, params object[] data) => source.ToDebug();

    [DebuggerStepThrough]
    public static void ToDebug<T>(this ICollection<T> source)
    {
      int length = source.GetType().FullName.Length;
      source.GetType().FullName.ToDebugLine();
      new string('-', length).ToDebugLine();
      foreach (T obj in (IEnumerable<T>) source)
      {
        if ((object) obj is IConvertible)
          Convert.ToString((object) obj).ToDebugLine();
        else
          obj.ToString().ToDebugLine();
      }
      new string('-', length).ToDebugLine();
    }

    [DebuggerStepThrough]
    public static string FormatString(this string source, params object[] data) => string.Format(source, data);
  }
}
