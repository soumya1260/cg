﻿// Decompiled with JetBrains decompiler
// Type: HS.AddressInformation
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.Runtime.Serialization;

namespace HS
{
  [DataContract]
  public abstract class AddressInformation
  {
    [DataMember]
    public string StreetAddress1 { get; set; }

    [DataMember]
    public string StreetAddress2 { get; set; }

    [DataMember]
    public string City { get; set; }

    [DataMember]
    public string State { get; set; }

    [DataMember]
    public string PostalCode { get; set; }

    [DataMember]
    public string HomePhone { get; set; }

    [DataMember]
    public string CellPhone { get; set; }

    [DataMember]
    public string WorkPhone { get; set; }

    [DataMember]
    public string Fax { get; set; }

    [DataMember]
    public string EMailAddress { get; set; }

    [DataMember]
    public string EMailAddress2 { get; set; }
  }
}
