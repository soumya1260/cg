﻿// Decompiled with JetBrains decompiler
// Type: HS.ExtensionMethods
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Text.RegularExpressions;

namespace HS
{
  public static class ExtensionMethods
  {
    public static TResult Try<TTarget, TResult>(
      this TTarget target,
      Func<TTarget, TResult> func,
      TResult defaultValue)
    {
      return object.ReferenceEquals((object) target, (object) null) || object.ReferenceEquals((object) target, (object) DBNull.Value) ? defaultValue : func(target);
    }

    public static TResult Try<TTarget, TResult>(this TTarget target, Func<TTarget, TResult> func) => object.ReferenceEquals((object) target, (object) null) || object.ReferenceEquals((object) target, (object) DBNull.Value) ? default (TResult) : func(target);

    public static void Try<TTarget>(this TTarget target, Action<TTarget> func)
    {
      if (object.ReferenceEquals((object) target, (object) null) || object.ReferenceEquals((object) target, (object) DBNull.Value))
        return;
      func(target);
    }

    public static void Try<TTarget>(
      this TTarget target,
      Action<TTarget> notNullFunc,
      Action nullFunc)
    {
      if (!object.ReferenceEquals((object) target, (object) null) && !object.ReferenceEquals((object) target, (object) DBNull.Value))
        notNullFunc(target);
      else
        nullFunc();
    }

    public static TResult Try<TTarget, TResult>(
      this TTarget target,
      Func<TTarget, TResult> notNullFunc,
      Func<TTarget, TResult> nullFunc)
    {
      return !object.ReferenceEquals((object) target, (object) null) && !object.ReferenceEquals((object) target, (object) DBNull.Value) ? notNullFunc(target) : nullFunc(target);
    }

    public static TResult IIF<TTarget, TResult>(
      this TTarget target,
      Func<TTarget, bool> conditional,
      TResult trueValue,
      TResult falseValue)
    {
      if ((object) target == null)
        return default (TResult);
      return !conditional(target) ? falseValue : trueValue;
    }

    public static TResult IIF<TTarget, TResult>(
      this TTarget target,
      Func<TTarget, bool> conditional,
      Func<TTarget, TResult> trueFunc,
      Func<TTarget, TResult> falseFunc)
    {
      if ((object) target == null)
        return default (TResult);
      return !conditional(target) ? falseFunc(target) : trueFunc(target);
    }

    public static void IIF<TTarget>(
      this TTarget target,
      Func<TTarget, bool> conditional,
      Action<TTarget> trueAction,
      Action<TTarget> falseAction)
    {
      if ((object) target == null)
        throw new ArgumentNullException(nameof (target));
      if (conditional(target))
        trueAction(target);
      else
        falseAction(target);
    }

    public static void AddRangeUniquely<T, TKey>(
      this IList<T> target,
      IList<T> source,
      Func<T, TKey> keySelector)
    {
      Dictionary<TKey, T> targetDict = target != null ? target.ToDictionary<T, TKey>(keySelector) : throw new NullReferenceException(nameof (target));
      source.ForEach<T>((Action<T>) (f =>
      {
        if (targetDict.ContainsKey(keySelector(f)))
          return;
        ((ICollection<T>) target).Add(f);
      }));
    }

    public static void ForEach<T>(this IEnumerable<T> target, Action<T> func)
    {
      if (target == null)
        return;
      foreach (T obj in target)
        func(obj);
    }

    public static T TryGet<T>(this IList<T> target, int index) => target.Try<IList<T>, T>((Func<IList<T>, T>) (t => t.Count<T>() > index ? target[index] : default (T)));

    public static string ToSQLInList<T>(this IEnumerable<T> target, Func<T, string> valueSelector)
    {
      if (target == null)
        throw new ArgumentNullException(nameof (target));
      string result = "(";
      target.ForEach<T>((Action<T>) (i =>
      {
        if (result != "(")
          result += ",";
        result = result + "'" + valueSelector(i) + "'";
      }));
      result += ")";
      return result;
    }

    public static DateTime GetFirstDayOfYear(this DateTime target) => new DateTime(target.Year, 1, 1);

    public static DateTime GetLastDayOfMonth(this DateTime target) => new DateTime(target.Year, target.Month, DateTime.DaysInMonth(target.Year, target.Month));

    public static int GetAge(this DateTime target)
    {
      DateTime now = DateTime.Now;
      int age = now.Year - target.Year;
      if (now.Month < target.Month || now.Month == target.Month && now.Day < target.Day)
        --age;
      return age;
    }

    public static int GetMonthsSince(this DateTime target, DateTime beginning)
    {
      int num = target.Year - beginning.Year;
      if (beginning.Month > target.Month)
        --num;
      return num * 12 + (target.Month - beginning.Month);
    }

    public static string GetValidSQLServerDateTimeDisplay(this DateTime target) => target <= SqlDateTime.MinValue.Value || target >= SqlDateTime.MaxValue.Value ? string.Empty : target.ToString("MM/dd/yyyy hh:mm tt");

    public static string GetValidSQLServerDateDisplay(this DateTime target) => target <= SqlDateTime.MinValue.Value || target >= SqlDateTime.MaxValue.Value ? string.Empty : target.ToShortDateString();

    public static string GetValidSQLServerDateDisplay(this DateTime? target)
    {
      if (!target.HasValue)
        throw new ArgumentNullException(nameof (target));
      bool flag;
      if (target.HasValue)
      {
        DateTime dateTime = target.Value;
        flag = true;
      }
      else
        flag = false;
      return flag ? (target.Value <= SqlDateTime.MinValue.Value || target.Value >= SqlDateTime.MaxValue.Value ? string.Empty : target.Value.ToShortDateString()) : string.Empty;
    }

    public static string getFileExtension(this string fileName)
    {
      string fileExtension = "";
      char[] charArray = fileName.ToCharArray();
      int num = 0;
      for (int index = 0; index < charArray.Length; ++index)
      {
        if (charArray[index] == '.')
          num = index - 1;
      }
      for (int index = num + 1; index < charArray.Length; ++index)
        fileExtension += (string) (object) charArray[index];
      return fileExtension;
    }

    public static void Open<TChannel>(this ClientBase<TChannel> source) where TChannel : class => source.Open();

    public static string CoalesceEmpty(this string source, string value) => string.IsNullOrEmpty(source) ? value : source;

    [DebuggerStepThrough]
    public static T SqlCoalesce<T>(this object value)
    {
      if (value is DBNull)
        return default (T);
      try
      {
        if (!value.IsNotNull<object>())
          return default (T);
        Type type = typeof (T);
        T obj;
        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof (Nullable<>))
        {
          Type conversionType = ((IEnumerable<Type>) type.GetGenericArguments()).FirstOrDefault<Type>();
          obj = (T) Convert.ChangeType(value, conversionType);
        }
        else
          obj = (T) value;
        return obj;
      }
      catch (Exception ex)
      {
        ex.Data.Add((object) nameof (value), value);
        ex.ToDebug();
        throw;
      }
    }

    public static object SqlCoalesce(this object value)
    {
      try
      {
        switch (value.GetType().ToString())
        {
          case "System.String":
            return (object) value.SqlCoalesce<string>();
          case "System.Double":
            return (object) value.SqlCoalesce<double>();
          case "System.Int32":
            return (object) value.SqlCoalesce<int>();
          case "System.Int16":
            return (object) value.SqlCoalesce<short>();
          case "System.Int64":
            return (object) value.SqlCoalesce<long>();
          case "System.Boolean":
            return (object) value.SqlCoalesce<bool>();
          case "System.DateTime":
            return (object) value.SqlCoalesce<DateTime>();
          case "System.Decimal":
            return (object) value.SqlCoalesce<Decimal>();
          case "System.Single":
            return (object) value.SqlCoalesce<float>();
          default:
            return (object) null;
        }
      }
      catch (Exception ex)
      {
        ex.Data.Add((object) nameof (value), value);
        ex.ToDebug();
        throw;
      }
    }

    public static List<T> BuildList<T>(this DataTable DT)
    {
      List<T> objList = new List<T>();
      PropertyInfo[] properties = typeof (T).GetProperties();
      DataView defaultView = DT.DefaultView;
      for (int recordIndex = 0; recordIndex < defaultView.Count; ++recordIndex)
      {
        DataRowView dataRowView = defaultView[recordIndex];
        T instance = (T) Activator.CreateInstance(typeof (T));
        foreach (PropertyInfo propertyInfo in properties)
        {
          if (propertyInfo.CanWrite && DT.Columns.Contains(propertyInfo.Name) && dataRowView[propertyInfo.Name] != null)
            propertyInfo.SetValue((object) instance, dataRowView[propertyInfo.Name].SqlCoalesce(), (object[]) null);
        }
        objList.Add(instance);
      }
      return objList;
    }

    public static DataSet BuildDataSet<T>(this IList<T> source)
    {
      DataTable table = new DataTable();
      DataSet dataSet = new DataSet();
      PropertyInfo[] properties = typeof (T).GetProperties();
      foreach (PropertyInfo propertyInfo in properties)
      {
        if (propertyInfo.CanWrite)
        {
          if (propertyInfo.PropertyType.ToString().Contains("System.Nullable"))
          {
            DataColumn column = new DataColumn(propertyInfo.Name, Nullable.GetUnderlyingType(propertyInfo.PropertyType));
            table.Columns.Add(column);
          }
          else
          {
            DataColumn column = new DataColumn(propertyInfo.Name, propertyInfo.PropertyType);
            table.Columns.Add(column);
          }
        }
      }
      foreach (T obj in (IEnumerable<T>) source)
      {
        DataRow row = table.NewRow();
        foreach (PropertyInfo propertyInfo in properties)
        {
          try
          {
            if (propertyInfo.CanRead)
            {
              if (propertyInfo.CanWrite)
                row[propertyInfo.Name] = propertyInfo.GetValue((object) obj, (object[]) null);
            }
          }
          catch (ArgumentException ex1)
          {
            if (Nullable.GetUnderlyingType(propertyInfo.PropertyType) != null)
            {
              if (propertyInfo.GetValue((object) obj, (object[]) null) == null)
              {
                try
                {
                  row[propertyInfo.Name] = (object) DBNull.Value;
                  continue;
                }
                catch (Exception ex2)
                {
                  throw new InvalidOperationException(ex1.Message + "\n" + ex2.Message);
                }
              }
            }
            throw new InvalidOperationException(ex1.Message);
          }
          catch (Exception ex)
          {
            throw new InvalidOperationException(ex.Message);
          }
        }
        table.Rows.Add(row);
      }
      dataSet.Tables.Add(table);
      return dataSet;
    }

    public static DataTable BuildDataTable<T>(this IList<T> source)
    {
      DataTable dataTable = new DataTable();
      PropertyInfo[] properties = typeof (T).GetProperties();
      foreach (PropertyInfo propertyInfo in properties)
      {
        if (propertyInfo.CanWrite)
        {
          if (propertyInfo.PropertyType.ToString().Contains("System.Nullable"))
          {
            DataColumn column = new DataColumn(propertyInfo.Name, Nullable.GetUnderlyingType(propertyInfo.PropertyType));
            dataTable.Columns.Add(column);
          }
          else
          {
            DataColumn column = new DataColumn(propertyInfo.Name, propertyInfo.PropertyType);
            dataTable.Columns.Add(column);
          }
        }
      }
      foreach (T obj in (IEnumerable<T>) source)
      {
        DataRow row = dataTable.NewRow();
        foreach (PropertyInfo propertyInfo in properties)
        {
          try
          {
            if (propertyInfo.CanRead)
            {
              if (propertyInfo.CanWrite)
                row[propertyInfo.Name] = propertyInfo.GetValue((object) obj, (object[]) null);
            }
          }
          catch (Exception ex)
          {
            throw new InvalidOperationException(ex.Message);
          }
        }
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }

    public static DataTable LINQToDataTable<T>(this IEnumerable<T> varList)
    {
      DataTable dataTable = new DataTable();
      try
      {
        PropertyInfo[] propertyInfoArray = (PropertyInfo[]) null;
        if (varList == null)
          return dataTable;
        foreach (T var in varList)
        {
          if (propertyInfoArray == null)
          {
            propertyInfoArray = var.GetType().GetProperties();
            foreach (PropertyInfo propertyInfo in propertyInfoArray)
            {
              Type dataType = propertyInfo.PropertyType;
              if (dataType.IsGenericType && dataType.GetGenericTypeDefinition() == typeof (Nullable<>))
                dataType = dataType.GetGenericArguments()[0];
              dataTable.Columns.Add(new DataColumn(propertyInfo.Name, dataType));
            }
          }
          DataRow row = dataTable.NewRow();
          foreach (PropertyInfo propertyInfo in propertyInfoArray)
            row[propertyInfo.Name] = propertyInfo.GetValue((object) var, (object[]) null) == null ? (object) DBNull.Value : propertyInfo.GetValue((object) var, (object[]) null);
          dataTable.Rows.Add(row);
        }
      }
      catch (Exception ex)
      {
        throw;
      }
      return dataTable;
    }

    [DebuggerStepThrough]
    public static void SetParameterValue(this SqlParameter parameter, object value)
    {
      if (parameter == null)
        throw new ArgumentNullException(nameof (parameter), "The parameter cannot be null.");
      if (value == null)
        parameter.Value = (object) DBNull.Value;
      else
        parameter.Value = value;
    }

    [DebuggerStepThrough]
    public static void SetParameterValue(this SqlParameter parameter, string value)
    {
      if (parameter == null)
        throw new ArgumentNullException(nameof (parameter), "The parameter cannot be null.");
      if (string.IsNullOrEmpty(value))
        parameter.Value = (object) DBNull.Value;
      else
        parameter.Value = (object) value;
    }

    [DebuggerStepThrough]
    public static int? ToNullableInt(this string value)
    {
      int? nullableInt = new int?();
      if (!string.IsNullOrEmpty(value))
        nullableInt = new int?(Convert.ToInt32(value));
      return nullableInt;
    }

    [DebuggerStepThrough]
    public static DateTime? ToNullableDateTime(this string value)
    {
      DateTime? nullableDateTime = new DateTime?();
      DateTime result;
      if (!string.IsNullOrEmpty(value) && DateTime.TryParse(value, out result))
        nullableDateTime = new DateTime?(result);
      return nullableDateTime;
    }

    public static void TestExcludeItems() => new List<int?>()
    {
      new int?(1),
      new int?(2),
      new int?(3)
    }.ExcludeItems<int?, int>((IList<int?>) new List<int?>()
    {
      new int?(2)
    }, (Func<int?, int>) (x => x.Value)).ToDebug<int?>();

    public static IList<TList> ExcludeItems<TList, TKey>(
      this IList<TList> sourceList,
      IList<TList> excludeList,
      Func<TList, TKey> selector)
    {
      List<TList> list1 = sourceList.ToList<TList>();
      foreach (TList exclude in (IEnumerable<TList>) excludeList)
      {
        TList item = exclude;
        TList list2 = list1.Where<TList>((Func<TList, bool>) (i => selector(i).Equals((object) selector(item)))).FirstOrDefault<TList>();
        if ((object) list2 != null)
          list1.Remove(list2);
      }
      return (IList<TList>) list1;
    }

    public static bool ContainsItem<TList, TKey>(
      this IList<TList> list,
      Func<TList, TKey> selector,
      TList item)
    {
      return list.Where<TList>((Func<TList, bool>) (x => selector(x).Equals((object) selector(item)))).ToList<TList>().IsNotNullOrEmpty<TList>();
    }

    [DebuggerStepThrough]
    public static Decimal Max<TList, TKey>(
      this IList<TList> list,
      Func<TList, TKey> selector)
      where TKey : struct
    {
      Decimal val1 = 0M;
      foreach (TList list1 in (IEnumerable<TList>) list)
      {
        TKey key = new TKey?(selector(list1)).Value;
        val1 = Math.Max(val1, Convert.ToDecimal((object) key));
      }
      return val1;
    }

    [DebuggerStepThrough]
    public static Decimal SumList<TList, TKey>(
      this IList<TList> list,
      Func<TList, TKey> selector)
      where TKey : struct
    {
      Decimal num = 0M;
      foreach (TList list1 in (IEnumerable<TList>) list)
      {
        TKey key = new TKey?(selector(list1)).Value;
        num += Convert.ToDecimal((object) key);
      }
      return num;
    }

    [DebuggerStepThrough]
    public static IEnumerable<TList> DistinctByField<TList, TKey>(
      this IEnumerable<TList> list,
      Func<TList, TKey> selector)
    {
      Dictionary<TKey, TList> dictionary = new Dictionary<TKey, TList>();
      foreach (TList list1 in list)
      {
        if (!dictionary.ContainsKey(selector(list1)))
          dictionary.Add(selector(list1), list1);
      }
      return (IEnumerable<TList>) dictionary.Values;
    }

    [DebuggerStepThrough]
    public static IList<T> Subset<T>(this IList<T> list, int start, int count)
    {
      if (list == null)
        throw new ArgumentNullException(nameof (list), "Must supply an instance of the list.");
      if (start < 0)
        throw new ArgumentOutOfRangeException(nameof (start), "Start must be a positive number.");
      if (start >= list.Count)
        throw new ArgumentOutOfRangeException(nameof (start), "Start must be less than the length of the list.");
      List<T> objList = count >= 0 ? new List<T>(count) : throw new ArgumentOutOfRangeException(nameof (count), "Count must be a positive number.");
      for (int index = start; index < start + count && index < list.Count; ++index)
        objList.Add(list[index]);
      return (IList<T>) objList;
    }

    [DebuggerStepThrough]
    public static IList<T> Subset<T>(this IList<T> list, int start)
    {
      if (list == null)
        throw new ArgumentNullException(nameof (list), "Must supply an instance of the list.");
      if (start < 0)
        throw new ArgumentOutOfRangeException(nameof (start), "Start must be a positive number.");
      if (start >= list.Count)
        throw new ArgumentOutOfRangeException(nameof (start), "Start must be less than the length of the list.");
      return list.Subset<T>(start, list.Count - start);
    }

    [DebuggerStepThrough]
    public static bool IsIn(this string source, ICollection<string> target) => !string.IsNullOrEmpty(target.Where<string>((Func<string, bool>) (item => source == item)).FirstOrDefault<string>());

    public static List<T> SortList<T>(
      this List<T> dataSource,
      string propertyName,
      SortDirectionValue sortDirection)
    {
      PropertyInfo propInfo = typeof (T).GetProperty(propertyName);
      Comparison<T> comparison = (Comparison<T>) ((a, b) =>
      {
        bool flag = sortDirection == SortDirectionValue.Ascending;
        object obj1 = flag ? propInfo.GetValue((object) a, (object[]) null) : propInfo.GetValue((object) b, (object[]) null);
        object obj2 = flag ? propInfo.GetValue((object) b, (object[]) null) : propInfo.GetValue((object) a, (object[]) null);
        return !(obj1 is IComparable) ? 0 : ((IComparable) obj1).CompareTo(obj2);
      });
      dataSource.Sort(comparison);
      return dataSource;
    }

    [DebuggerStepThrough]
    public static SqlParameter MakeParameter(
      this object value,
      string name,
      SqlDbType type,
      int size)
    {
      SqlParameter parameter = new SqlParameter(name, type, size);
      parameter.SetParameterValue(value);
      return parameter;
    }

    public static SqlParameter MakeParameter(
      this object value,
      string name,
      SqlDbType type)
    {
      SqlParameter parameter = new SqlParameter(name, type);
      parameter.SetParameterValue(value);
      return parameter;
    }

    public static SqlParameter MakeParameter(
      this object value,
      string name,
      SqlDbType type,
      int size,
      ParameterDirection direction)
    {
      SqlParameter parameter = new SqlParameter(name, type, size);
      parameter.Direction = direction;
      parameter.SetParameterValue(value);
      return parameter;
    }

    public static string ToPhoneNumber(this string target) => Regex.Replace(target.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", ""), "(\\d{3})(\\d{3})(\\d{4})", "($1) $2-$3");

    public static string ToFormatedString(this Exception exception, int depth)
    {
      StringBuilder stringBuilder = new StringBuilder();
      string tabs = new string('\t', depth);
      int num = (depth + 1) * 4;
      stringBuilder.Append(tabs);
      stringBuilder.Append('-', 78 - num);
      stringBuilder.AppendLine();
      stringBuilder.AppendFormat("{1}Handled {0} with the following data:\n", (object) exception.GetType().Name, (object) tabs);
      if (exception.InnerException != null)
      {
        stringBuilder.AppendFormat("{0}Begin Inner Exception:\n", (object) tabs);
        stringBuilder.Append(exception.InnerException.ToFormatedString(depth + 1));
        stringBuilder.AppendLine();
        stringBuilder.Append(tabs + (object) '\t');
        stringBuilder.Append('-', 60 - num);
        stringBuilder.AppendLine();
        stringBuilder.AppendFormat("{0}End Inner Exception:\n", (object) tabs);
      }
      if (exception.Data.Keys.Count > 0)
      {
        stringBuilder.AppendLine(tabs + "Exception Data:");
        foreach (object key in (IEnumerable) exception.Data.Keys)
          stringBuilder.AppendFormat("{2}\t{0}={1}\n", key, exception.Data[key], (object) tabs);
      }
      stringBuilder.Append(tabs + (object) '\t');
      stringBuilder.Append('-', 60 - num);
      stringBuilder.AppendLine();
      stringBuilder.AppendFormat("{2}{0}: {1}\n", (object) exception.GetType().FullName, (object) exception.Message, (object) tabs);
      if (exception.StackTrace != null)
      {
        foreach (string str in ((IEnumerable<string>) exception.StackTrace.Split('\n')).Select<string, string>((Func<string, string>) (line => tabs + line)))
          stringBuilder.AppendLine(str);
      }
      return stringBuilder.ToString();
    }

    public static string HSStringFormatter(this string rawString, string formatType)
    {
      string empty = string.Empty;
      string str;
      switch (formatType.Trim().ToLower())
      {
        case "memberid":
          switch (rawString.Trim().Length)
          {
            case 9:
              str = string.Format("{0}*01", (object) rawString.Trim());
              break;
            case 11:
              str = string.Format("{0}*{1}", (object) rawString.Trim().Substring(0, 9), (object) rawString.Trim().Substring(9, 2));
              break;
            default:
              str = rawString.Trim();
              break;
          }
          break;
        default:
          str = rawString.Trim();
          break;
      }
      return str;
    }

    public static string getSqlParameterString(this SqlParameter[] parameters)
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (SqlParameter parameter in parameters)
      {
        stringBuilder.Append("DECLARE " + parameter.ParameterName + " " + parameter.DbType.ToString() + Environment.NewLine);
        stringBuilder.Append("SET " + parameter.ParameterName + " = " + parameter.Value + Environment.NewLine);
      }
      return stringBuilder.ToString();
    }

    public static string getSqlParameterString(this SqlParameterCollection parameters)
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (SqlParameter parameter in (DbParameterCollection) parameters)
      {
        stringBuilder.Append("DECLARE " + parameter.ParameterName + " " + parameter.SqlDbType.ToString() + Environment.NewLine);
        stringBuilder.Append("SET " + parameter.ParameterName + " = '" + parameter.Value + "'" + Environment.NewLine);
      }
      return stringBuilder.ToString();
    }

    public static string getSqlParameterString(this List<SqlParameter> parameters)
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (SqlParameter parameter in parameters)
      {
        stringBuilder.Append("DECLARE " + parameter.ParameterName + " " + parameter.SqlDbType.ToString() + Environment.NewLine);
        stringBuilder.Append("SET " + parameter.ParameterName + " = '" + parameter.Value + "'" + Environment.NewLine);
      }
      return stringBuilder.ToString();
    }

    public static List<SqlParameter> CopyParameters(this List<SqlParameter> source)
    {
      List<SqlParameter> sqlParameterList = new List<SqlParameter>();
      foreach (SqlParameter source1 in source)
      {
        SqlParameter target = new SqlParameter();
        source1.CopyInto<SqlParameter>(target);
        sqlParameterList.Add(target);
      }
      return sqlParameterList;
    }

    public static List<SqlParameter> ToParameterList(
      this SqlParameterCollection source)
    {
      List<SqlParameter> parameterList = new List<SqlParameter>();
      foreach (SqlParameter sqlParameter in (DbParameterCollection) source)
        parameterList.Add(sqlParameter);
      return parameterList;
    }

    public static T CopyInto<T>(this object source, T target)
    {
      foreach (PropertyInfo property1 in source.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
      {
        PropertyInfo property2 = target.GetType().GetProperty(property1.Name, BindingFlags.Instance | BindingFlags.Public);
        if (property2 != null && property2.CanWrite)
        {
          object[] index = new object[0];
          object obj = (object) null;
          try
          {
            obj = property1.GetValue(source, index);
            property2.SetValue((object) target, obj, index);
          }
          catch (Exception ex)
          {
            if (source is ISerializable)
              ex.Data.Add((object) nameof (source), source);
            if ((object) target is ISerializable)
              ex.Data.Add((object) nameof (target), (object) target);
            if (obj is ISerializable)
              ex.Data.Add((object) "value", obj);
            ex.Data.Add((object) "vpi", (object) property2);
            ex.Data.Add((object) "pi", (object) property1);
            throw;
          }
        }
      }
      return target;
    }

    public static T CopyIntoFromCache<T>(this object source, Type sourceInterface, T target)
    {
      foreach (PropertyInfo property1 in source.GetType().GetInterface(sourceInterface.Name).GetProperties(BindingFlags.Instance | BindingFlags.Public))
      {
        PropertyInfo property2 = target.GetType().GetProperty(property1.Name, BindingFlags.Instance | BindingFlags.Public);
        if (property2 != null && property2.CanWrite)
        {
          object[] index = new object[0];
          object obj = (object) null;
          try
          {
            obj = property1.GetValue(source, index);
            property2.SetValue((object) target, obj, index);
          }
          catch (Exception ex)
          {
            if (source is ISerializable)
              ex.Data.Add((object) nameof (source), source);
            if ((object) target is ISerializable)
              ex.Data.Add((object) nameof (target), (object) target);
            if (obj is ISerializable)
              ex.Data.Add((object) "value", obj);
            ex.Data.Add((object) "vpi", (object) property2);
            ex.Data.Add((object) "pi", (object) property1);
          }
        }
      }
      return target;
    }

    public static T CopyIntoTypeSafe<T>(this object source, T target)
    {
      foreach (PropertyInfo property1 in source.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
      {
        PropertyInfo property2 = target.GetType().GetProperty(property1.Name, BindingFlags.Instance | BindingFlags.Public);
        if (property2 != null && property2.CanWrite && property2.PropertyType == property1.PropertyType)
        {
          object[] index = new object[0];
          object obj = (object) null;
          try
          {
            obj = property1.GetValue(source, index);
            property2.SetValue((object) target, obj, index);
          }
          catch (Exception ex)
          {
            if (source is ISerializable)
              ex.Data.Add((object) nameof (source), source);
            if ((object) target is ISerializable)
              ex.Data.Add((object) nameof (target), (object) target);
            if (obj is ISerializable)
              ex.Data.Add((object) "value", obj);
            ex.Data.Add((object) "vpi", (object) property2);
            ex.Data.Add((object) "pi", (object) property1);
            throw;
          }
        }
      }
      return target;
    }

    public static string SafeTrim(this string source) => source?.Trim();

    [DebuggerStepThrough]
    public static string FormatString(this string source, params object[] data) => string.Format(source, data);

    public static string FormatPhone(this string source)
    {
      string str = (string) null;
      if (string.IsNullOrEmpty(source))
      {
        str = " ";
      }
      else
      {
        string source1 = source.Replace(" ", "").Replace("-", "").Replace("(", "").Replace(")", "");
        switch (source1.Length)
        {
          case 7:
            str = source1.Left(3) + "-" + source1.Right(4);
            break;
          case 10:
            str = "(" + source1.Left(3) + ") " + source1.Substring(3, 3) + "-" + source1.Right(4);
            break;
        }
      }
      return str;
    }

    [DebuggerStepThrough]
    public static void AssertParameterNotNull<T>(
      this T source,
      string parameterName,
      string message)
      where T : class
    {
      if ((object) source == null)
        throw new ArgumentNullException(parameterName, message);
    }

    [DebuggerStepThrough]
    public static bool IsValidDate(this string source)
    {
      bool flag = false;
      try
      {
        Convert.ToDateTime(source);
        flag = true;
      }
      catch
      {
      }
      return flag;
    }

    [DebuggerStepThrough]
    public static string Left(this string source, int charsToTake) => source.IsNull<string>() || source.Length < charsToTake ? source : source.Substring(0, charsToTake);

    [DebuggerStepThrough]
    public static string Right(this string source, int charsToTake) => source.IsNull<string>() || source.Length < charsToTake ? source : source.Substring(source.Length - charsToTake);

    [DebuggerStepThrough]
    public static string[] SplitOnWidth(this string source, int width)
    {
      if (source.Length < width || source.IsNull<string>())
        return new string[1]{ source };
      List<string> stringList = new List<string>(source.Length / width + 1);
      int startIndex;
      for (startIndex = 0; startIndex + width <= source.Length; startIndex += width)
        stringList.Add(source.Substring(startIndex, width));
      stringList.Add(source.Substring(startIndex));
      return stringList.ToArray();
    }

    [DebuggerStepThrough]
    public static string ToFixedLength(
      this object source,
      int width,
      FixedLengthJustification justification)
    {
      return source.ToFixedLength("{0}", width, justification);
    }

    [DebuggerStepThrough]
    public static string ToFixedLength(
      this object source,
      string format,
      int width,
      FixedLengthJustification justification)
    {
      string fixedLength = new string(' ', width);
      if (source.IsNotNull<object>())
      {
        string str = format.FormatString(source);
        if (str.Length > width)
        {
          switch (justification)
          {
            case FixedLengthJustification.Left:
              fixedLength = str.Substring(0, width);
              break;
            case FixedLengthJustification.Right:
              fixedLength = str.Substring(str.Length - width);
              break;
            default:
              fixedLength = str.Substring((str.Length - width) / 2, width);
              break;
          }
        }
        else if (str.Length == width)
        {
          fixedLength = str;
        }
        else
        {
          switch (justification)
          {
            case FixedLengthJustification.Left:
              fixedLength = (str + fixedLength).Substring(0, width);
              break;
            case FixedLengthJustification.Right:
              fixedLength = (fixedLength + str).Substring((fixedLength + str).Length - width);
              break;
            default:
              fixedLength = (new string(' ', (width - str.Length) / 2) + str + new string(' ', (width - str.Length) / 2 + 1)).Substring(0, width);
              break;
          }
        }
      }
      return fixedLength;
    }

    [DebuggerStepThrough]
    public static void ToDebug(this string source)
    {
    }

    [DebuggerStepThrough]
    public static void ToDebug(this string source, params object[] data)
    {
    }

    [DebuggerStepThrough]
    public static void ToDebugLine(this string source)
    {
    }

    [DebuggerStepThrough]
    public static void ToDebugLine(this string source, params object[] data)
    {
    }

    [DebuggerStepThrough]
    public static void ToDebug(this Exception source)
    {
    }

    [DebuggerStepThrough]
    public static void ToDebug(this Exception source, string message) => source.ToDebug();

    [DebuggerStepThrough]
    public static void ToDebug(this Exception source, string message, params object[] data) => source.ToDebug();

    [DebuggerStepThrough]
    public static void ToDebug<T>(this ICollection<T> source)
    {
      int length = source.GetType().FullName.Length;
      source.GetType().FullName.ToDebugLine();
      new string('-', length).ToDebugLine();
      foreach (T obj in (IEnumerable<T>) source)
      {
        if ((object) obj is IConvertible)
          Convert.ToString((object) obj).ToDebugLine();
        else
          obj.ToString().ToDebugLine();
      }
      new string('-', length).ToDebugLine();
    }

    [DebuggerStepThrough]
    public static bool IsNull<T>(this T source) where T : class => (object) source == null;

    [DebuggerStepThrough]
    public static bool IsNotNull<T>(this T source) where T : class => (object) source != null;

    [DebuggerStepThrough]
    public static bool IsNullOrEmpty(this string source) => source == null || source.Length == 0;

    [DebuggerStepThrough]
    public static bool IsNotNullOrEmpty(this string source) => source != null && source.Length > 0;

    [DebuggerStepThrough]
    public static bool IsNullOrEmpty(this ICollection source) => source == null || source.Count == 0;

    [DebuggerStepThrough]
    public static bool IsNotNullOrEmpty(this ICollection source) => source != null && source.Count > 0;

    [DebuggerStepThrough]
    public static bool IsNullOrEmpty<T>(this ICollection<T> source) => source == null || source.Count == 0;

    [DebuggerStepThrough]
    public static bool IsNotNullOrEmpty<T>(this ICollection<T> source) => source != null && source.Count > 0;

    [DebuggerStepThrough]
    public static bool IsNullOrEmpty<TKey, TValue>(this IDictionary<TKey, TValue> source) => source == null || source.Count == 0;

    [DebuggerStepThrough]
    public static bool IsNotNullOrEmpty<TKey, TValue>(this IDictionary<TKey, TValue> source) => source != null && source.Count > 0;

    [DebuggerStepThrough]
    public static bool EqualsIgnoreCase(this string source, string target) => source.ToLower().Equals(target.ToLower());

    public static void AddRange<TKey, TValue>(
      this IDictionary<TKey, TValue> source,
      IEnumerable<KeyValuePair<TKey, TValue>> values)
    {
      foreach (KeyValuePair<TKey, TValue> keyValuePair in values)
        source.Add(keyValuePair);
    }

    public static TEnum ToEnum<TEnum>(this object source)
    {
      if (source == null)
        return default (TEnum);
      return (TEnum) Enum.Parse(typeof (TEnum), source.ToString());
    }
  }
}
