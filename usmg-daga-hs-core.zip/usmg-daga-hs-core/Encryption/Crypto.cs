﻿// Decompiled with JetBrains decompiler
// Type: HS.Encryption.Crypto
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

namespace HS.Encryption
{
  public static class Crypto
  {
    private const string _passPhrase = "H0J70BKN1U50140370S4J06CHVQO6ED4YJ1VS36D7R8A8L6C28YB45Q70N13388O4";
    private const string _saltValue = "B8u5h@nM@11k";
    private const int _iterations = 2;
    private const string _iv = "@1B2c3D4e5F6g7H8";
    private const int _keySize = 256;
    private const string _encType = "MD5";

    public static string Encrypt(string text) => MultiCrypt.Encrypt(text, "H0J70BKN1U50140370S4J06CHVQO6ED4YJ1VS36D7R8A8L6C28YB45Q70N13388O4", "B8u5h@nM@11k", "MD5", 2, "@1B2c3D4e5F6g7H8", 256);

    public static string DeCrypt(string text) => MultiCrypt.Decrypt(text, "H0J70BKN1U50140370S4J06CHVQO6ED4YJ1VS36D7R8A8L6C28YB45Q70N13388O4", "B8u5h@nM@11k", "MD5", 2, "@1B2c3D4e5F6g7H8", 256);
  }
}
