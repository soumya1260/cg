﻿// Decompiled with JetBrains decompiler
// Type: HS.Encryption.MultiCrypt
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace HS.Encryption
{
  internal class MultiCrypt
  {
    private static string publicKey;
    private static string privateKey;
    private static string xmlKeys;
    private byte[] key3DES = new byte[24]
    {
      (byte) 1,
      (byte) 2,
      (byte) 3,
      (byte) 4,
      (byte) 5,
      (byte) 6,
      (byte) 7,
      (byte) 8,
      (byte) 9,
      (byte) 10,
      (byte) 11,
      (byte) 12,
      (byte) 13,
      (byte) 14,
      (byte) 15,
      (byte) 16,
      (byte) 17,
      (byte) 18,
      (byte) 19,
      (byte) 20,
      (byte) 21,
      (byte) 22,
      (byte) 23,
      (byte) 24
    };
    private byte[] key = new byte[8]
    {
      (byte) 1,
      (byte) 2,
      (byte) 3,
      (byte) 4,
      (byte) 5,
      (byte) 6,
      (byte) 7,
      (byte) 8
    };
    private byte[] iv = new byte[8]
    {
      (byte) 65,
      (byte) 110,
      (byte) 68,
      (byte) 26,
      (byte) 69,
      (byte) 178,
      (byte) 200,
      (byte) 219
    };

    public MultiCrypt()
    {
      RSACryptoServiceProvider cryptoServiceProvider = new RSACryptoServiceProvider();
      MultiCrypt.xmlKeys = cryptoServiceProvider.ToXmlString(true);
      MultiCrypt.publicKey = cryptoServiceProvider.ToXmlString(false);
    }

    public MultiCrypt(string encType)
    {
      string str;
      if ((str = encType) == null || str == "3DES")
        return;
      int num = str == "RSA" ? 1 : 0;
    }

    public byte[] Encrypt(string plainText, string encType)
    {
      byte[] bytes = new UTF8Encoding().GetBytes(plainText);
      switch (encType)
      {
        case "DES":
          using (DESCryptoServiceProvider cryptoServiceProvider = new DESCryptoServiceProvider())
          {
            ICryptoTransform encryptor = cryptoServiceProvider.CreateEncryptor(this.key, this.iv);
            using (MemoryStream memoryStream = new MemoryStream())
            {
              CryptoStream cryptoStream = new CryptoStream((Stream) memoryStream, encryptor, CryptoStreamMode.Write);
              cryptoStream.Write(bytes, 0, bytes.Length);
              cryptoStream.FlushFinalBlock();
              memoryStream.Position = 0L;
              byte[] buffer = new byte[memoryStream.Length];
              memoryStream.Read(buffer, 0, (int) memoryStream.Length);
              cryptoStream.Close();
              return buffer;
            }
          }
        case "3DES":
          using (TripleDESCryptoServiceProvider cryptoServiceProvider = new TripleDESCryptoServiceProvider())
          {
            ICryptoTransform encryptor = cryptoServiceProvider.CreateEncryptor(this.key3DES, this.iv);
            using (MemoryStream memoryStream = new MemoryStream())
            {
              CryptoStream cryptoStream = new CryptoStream((Stream) memoryStream, encryptor, CryptoStreamMode.Write);
              cryptoStream.Write(bytes, 0, bytes.Length);
              cryptoStream.FlushFinalBlock();
              memoryStream.Position = 0L;
              byte[] buffer = new byte[memoryStream.Length];
              memoryStream.Read(buffer, 0, (int) memoryStream.Length);
              cryptoStream.Close();
              return buffer;
            }
          }
        default:
          return new byte[0];
      }
    }

    public string Decrypt(byte[] inputInBytes, string decType)
    {
      UTF8Encoding utF8Encoding = new UTF8Encoding();
      switch (decType)
      {
        case "DES":
          using (DESCryptoServiceProvider cryptoServiceProvider = new DESCryptoServiceProvider())
          {
            ICryptoTransform decryptor = cryptoServiceProvider.CreateDecryptor(this.key, this.iv);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream((Stream) memoryStream, decryptor, CryptoStreamMode.Write);
            cryptoStream.Write(inputInBytes, 0, inputInBytes.Length);
            cryptoStream.FlushFinalBlock();
            memoryStream.Position = 0L;
            byte[] numArray = new byte[memoryStream.Length];
            memoryStream.Read(numArray, 0, (int) memoryStream.Length);
            cryptoStream.Close();
            return new UTF8Encoding().GetString(numArray);
          }
        case "3DES":
          using (TripleDESCryptoServiceProvider cryptoServiceProvider = new TripleDESCryptoServiceProvider())
          {
            ICryptoTransform decryptor = cryptoServiceProvider.CreateDecryptor(this.key3DES, this.iv);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream((Stream) memoryStream, decryptor, CryptoStreamMode.Write);
            cryptoStream.Write(inputInBytes, 0, inputInBytes.Length);
            cryptoStream.FlushFinalBlock();
            memoryStream.Position = 0L;
            byte[] numArray = new byte[memoryStream.Length];
            memoryStream.Read(numArray, 0, (int) memoryStream.Length);
            cryptoStream.Close();
            return new UTF8Encoding().GetString(numArray);
          }
        default:
          return "";
      }
    }

    public ArrayList EncryptRSA(string plainText, string key)
    {
      RSACryptoServiceProvider cryptoServiceProvider = new RSACryptoServiceProvider();
      RSACryptoServiceProvider.UseMachineKeyStore = true;
      ArrayList arrayList = new ArrayList();
      int length = 58;
      cryptoServiceProvider.FromXmlString(key);
      if (plainText.Length > length)
      {
        for (int startIndex = 0; startIndex <= plainText.Length; startIndex = startIndex + (length - 1) + 1)
        {
          string s = plainText.Length - startIndex >= length ? plainText.Substring(startIndex, length) : plainText.Substring(startIndex, plainText.Length - startIndex);
          byte[] numArray = cryptoServiceProvider.Encrypt(Encoding.Unicode.GetBytes(s), false);
          arrayList.Add((object) numArray);
        }
      }
      else
      {
        byte[] numArray = cryptoServiceProvider.Encrypt(Encoding.Unicode.GetBytes(plainText), false);
        arrayList.Add((object) numArray);
      }
      return arrayList;
    }

    public byte[] DecryptRSA(byte[] inputBytes, string key)
    {
      RSACryptoServiceProvider cryptoServiceProvider = new RSACryptoServiceProvider();
      RSACryptoServiceProvider.UseMachineKeyStore = true;
      cryptoServiceProvider.FromXmlString(key);
      byte[] numArray = cryptoServiceProvider.Decrypt(inputBytes, false);
      MultiCrypt.publicKey = string.Empty;
      MultiCrypt.privateKey = string.Empty;
      return numArray;
    }

    public static string Encrypt(
      string plainText,
      string passPhrase,
      string saltValue,
      string hashAlgorithm,
      int passwordIterations,
      string initVector,
      int keySize)
    {
      byte[] bytes1 = Encoding.ASCII.GetBytes(initVector);
      byte[] bytes2 = Encoding.ASCII.GetBytes(saltValue);
      byte[] bytes3 = Encoding.UTF8.GetBytes(plainText);
      byte[] bytes4 = new PasswordDeriveBytes(passPhrase, bytes2, hashAlgorithm, passwordIterations).GetBytes(keySize / 8);
      RijndaelManaged rijndaelManaged = new RijndaelManaged();
      rijndaelManaged.Mode = CipherMode.CBC;
      rijndaelManaged.Padding = PaddingMode.PKCS7;
      ICryptoTransform encryptor = rijndaelManaged.CreateEncryptor(bytes4, bytes1);
      MemoryStream memoryStream = new MemoryStream();
      CryptoStream cryptoStream = new CryptoStream((Stream) memoryStream, encryptor, CryptoStreamMode.Write);
      cryptoStream.Write(bytes3, 0, bytes3.Length);
      cryptoStream.FlushFinalBlock();
      byte[] array = memoryStream.ToArray();
      memoryStream.Close();
      cryptoStream.Close();
      return Convert.ToBase64String(array);
    }

    public static string Decrypt(
      string cipherText,
      string passPhrase,
      string saltValue,
      string hashAlgorithm,
      int passwordIterations,
      string initVector,
      int keySize)
    {
      byte[] bytes1 = Encoding.ASCII.GetBytes(initVector);
      byte[] bytes2 = Encoding.ASCII.GetBytes(saltValue);
      byte[] buffer = Convert.FromBase64String(cipherText);
      byte[] bytes3 = new PasswordDeriveBytes(passPhrase, bytes2, hashAlgorithm, passwordIterations).GetBytes(keySize / 8);
      RijndaelManaged rijndaelManaged = new RijndaelManaged();
      rijndaelManaged.Mode = CipherMode.CBC;
      rijndaelManaged.Padding = PaddingMode.PKCS7;
      ICryptoTransform decryptor = rijndaelManaged.CreateDecryptor(bytes3, bytes1);
      MemoryStream memoryStream = new MemoryStream(buffer);
      CryptoStream cryptoStream = new CryptoStream((Stream) memoryStream, decryptor, CryptoStreamMode.Read);
      byte[] numArray = new byte[buffer.Length + 1];
      int count = cryptoStream.Read(numArray, 0, numArray.Length);
      memoryStream.Close();
      cryptoStream.Close();
      return Encoding.UTF8.GetString(numArray, 0, count);
    }

    public enum EncryptionType
    {
      DES_3,
      RSA,
      DES,
      RIJANDEL,
    }
  }
}
