﻿// Decompiled with JetBrains decompiler
// Type: HS.HSEmailServiceFacade
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using HS.HSEmailService;
using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;

namespace HS
{
  public class HSEmailServiceFacade
  {
    public static T UseEmailServiceClient<T>(Func<HSEmailServiceClient, T> callback)
    {
      HSEmailServiceClient emailServiceClient = (HSEmailServiceClient) null;
      try
      {
        EndpointAddress remoteAddress = new EndpointAddress(HSLoggingConfiguration.Current.EmailServiceEndpointAddress);
        BasicHttpBinding basicHttpBinding = new BasicHttpBinding()
        {
          MaxBufferPoolSize = 52428800,
          MaxBufferSize = 6553600,
          MaxReceivedMessageSize = 6553600
        };
        basicHttpBinding.ReaderQuotas = new XmlDictionaryReaderQuotas()
        {
          MaxStringContentLength = 8192000,
          MaxArrayLength = 16384,
          MaxBytesPerRead = 4096,
          MaxDepth = 32,
          MaxNameTableCharCount = 16384
        };
        emailServiceClient = new HSEmailServiceClient((Binding) basicHttpBinding, remoteAddress);
        return callback(emailServiceClient);
      }
      catch (Exception ex)
      {
        emailServiceClient?.Abort();
        throw;
      }
      finally
      {
        emailServiceClient?.Close();
      }
    }

    public static bool SendEmail(Email email)
    {
      bool mailSent = false;
      return HSEmailServiceFacade.UseEmailServiceClient<bool>((Func<HSEmailServiceClient, bool>) (client =>
      {
        try
        {
          client.Open();
          mailSent = client.sendEmail(email);
          return mailSent;
        }
        catch (Exception ex)
        {
          Log.LogException(ex);
          return false;
        }
      }));
    }
  }
}
