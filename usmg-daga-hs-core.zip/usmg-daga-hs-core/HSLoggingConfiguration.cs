﻿// Decompiled with JetBrains decompiler
// Type: HS.HSLoggingConfiguration
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.Configuration;
using System.Diagnostics;

namespace HS
{
  public class HSLoggingConfiguration : ConfigurationSection
  {
    [ConfigurationProperty("writeToDB", DefaultValue = true, IsRequired = false)]
    public bool WriteToDB
    {
      get => (bool) this["writeToDB"];
      set => this["writeToDB"] = (object) value;
    }

    [ConfigurationProperty("traceLevel", DefaultValue = TraceLevel.Off, IsRequired = false)]
    public TraceLevel TraceLevel
    {
      get => (TraceLevel) this["traceLevel"];
      set => this["traceLevel"] = (object) value;
    }

    [ConfigurationProperty("defaultApplicationName", DefaultValue = "", IsRequired = false)]
    public string DefaultApplicationName
    {
      get => (string) this["defaultApplicationName"];
      set => this["defaultApplicationName"] = (object) value;
    }

    [ConfigurationProperty("defaultToEmailForSendMail", IsRequired = false)]
    public string DefaultToEmailForSendMail
    {
      get => (string) this["defaultToEmailForSendMail"];
      set => this["defaultToEmailForSendMail"] = (object) value;
    }

    [ConfigurationProperty("useDefaultToEmailForSendMail", IsRequired = false)]
    public bool UseDefaultToEmailForSendMail
    {
      get => this["useDefaultToEmailForSendMail"] != null && (bool) this["useDefaultToEmailForSendMail"];
      set => this["useDefaultToEmailForSendMail"] = (object) value;
    }

    [ConfigurationProperty("defaultFromEmail", DefaultValue = "do.not.reply@healthspring.com", IsRequired = false)]
    public string DefaultFromEmail
    {
      get => (string) this["defaultFromEmail"];
      set => this["defaultFromEmail"] = (object) value;
    }

    [ConfigurationProperty("defaultToEmail", DefaultValue = "autowebexceptions@healthspring.com", IsRequired = false)]
    public string DefaultToEmail
    {
      get => (string) this["defaultToEmail"];
      set => this["defaultToEmail"] = (object) value;
    }

    [ConfigurationProperty("promotionEnvironment", DefaultValue = "PROD", IsRequired = false)]
    public string PromotionEnvironment
    {
      get => (string) this["promotionEnvironment"];
      set => this["promotionEnvironment"] = (object) value;
    }

    [ConfigurationProperty("overrideAppName", DefaultValue = "false", IsRequired = false)]
    private string overrideAppNameString
    {
      get => (string) this["overrideAppName"];
      set
      {
        if (bool.TryParse(value, out bool _))
          this["overrideAppName"] = (object) value;
        else
          this["overrideAppName"] = (object) "False";
      }
    }

    public bool OverrideAppName => bool.Parse(this.overrideAppNameString);

    [ConfigurationProperty("emailServiceEndpointAddress", IsRequired = false)]
    public string EmailServiceEndpointAddress
    {
      get => (string) this["emailServiceEndpointAddress"];
      set => this["emailServiceEndpointAddress"] = (object) value;
    }

    public static HSLoggingConfiguration Current
    {
      get
      {
        if (!(ConfigurationManager.GetSection("HS.logging") is HSLoggingConfiguration current))
          current = new HSLoggingConfiguration();
        return current;
      }
    }
  }
}
