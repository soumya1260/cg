﻿// Decompiled with JetBrains decompiler
// Type: HS.LogObject
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.Collections.Generic;
using System.Runtime.Serialization;

namespace HS
{
  [DataContract]
  public class LogObject
  {
    [DataMember]
    public int OriginalMessageID { get; set; }

    [DataMember]
    public string MessageTitle { get; set; }

    [DataMember]
    public string SendingApplication { get; set; }

    [DataMember]
    public MessageTypeEnum MessageType { get; set; }

    [DataMember]
    public string Message { get; set; }

    [DataMember]
    public string ExceptionMessage { get; set; }

    [DataMember]
    public string ExceptionType { get; set; }

    [DataMember]
    public string ExceptionSource { get; set; }

    [DataMember]
    public string ExceptionStackTrace { get; set; }

    [DataMember]
    public bool IsInnerException { get; set; }

    [DataMember]
    public bool ContainsException { get; set; }

    [DataMember]
    public string MessageSentFrom { get; set; }

    [DataMember]
    public string PromotionEnvironment { get; set; }

    [DataMember]
    public List<string> AdditionalMessages { get; set; }

    public LogObject()
    {
      this.AdditionalMessages = new List<string>();
      this.SendingApplication = "";
      this.Message = "";
      this.ExceptionType = "";
      this.MessageTitle = "";
      this.ExceptionMessage = "";
      this.ExceptionSource = "";
      this.ExceptionStackTrace = "";
      this.MessageSentFrom = "";
      this.PromotionEnvironment = "";
    }
  }
}
