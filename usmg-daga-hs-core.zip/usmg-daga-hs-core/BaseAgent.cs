﻿// Decompiled with JetBrains decompiler
// Type: HS.BaseAgent`1
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Diagnostics;
using System.ServiceModel;

namespace HS
{
  public class BaseAgent<ServiceInterface> : IDisposable
  {
    protected ChannelFactory<ServiceInterface> _channelFactory;

    public ServiceInterface GetServiceChannel(string endpointName)
    {
      this._channelFactory = new ChannelFactory<ServiceInterface>(endpointName);
      this._channelFactory.Faulted += new EventHandler(this._channelFactory_Faulted);
      return this._channelFactory.CreateChannel();
    }

    private void _channelFactory_Faulted(object sender, EventArgs e) => this.Abort();

    public void Abort()
    {
      this._channelFactory.Abort();
      this._channelFactory = (ChannelFactory<ServiceInterface>) null;
    }

    public void Dispose()
    {
      try
      {
        if (this._channelFactory == null)
          return;
        Trace.WriteLine((object) this._channelFactory.State);
        if (this._channelFactory.State == CommunicationState.Faulted)
          this._channelFactory.Abort();
        try
        {
          if (this._channelFactory.State == CommunicationState.Opened)
            this._channelFactory.Close();
        }
        catch
        {
          this._channelFactory.Abort();
        }
        this._channelFactory = (ChannelFactory<ServiceInterface>) null;
      }
      catch (Exception ex)
      {
        Trace.TraceError(ex.ToString());
        Log.LogException(ex);
        throw ex;
      }
    }
  }
}
