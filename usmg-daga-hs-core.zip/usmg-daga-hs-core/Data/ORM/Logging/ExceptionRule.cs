﻿// Decompiled with JetBrains decompiler
// Type: HS.Data.ORM.Logging.ExceptionRule
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

namespace HS.Data.ORM.Logging
{
  public class ExceptionRule
  {
    public bool CanISendEmail { get; set; }

    public int NumberOccurances { get; set; }

    public int WithinTimeSpan { get; set; }

    public bool IsRuleConfigured { get; set; }
  }
}
