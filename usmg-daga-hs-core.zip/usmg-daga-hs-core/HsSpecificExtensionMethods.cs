﻿// Decompiled with JetBrains decompiler
// Type: HS.HsSpecificExtensionMethods
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.Text.RegularExpressions;

namespace HS
{
  public static class HsSpecificExtensionMethods
  {
    public static string ParseCode(this string source)
    {
      Match match = new Regex("\\[[^\\]]*\\]").Match(source);
      return match.Success ? match.Value.Replace("[", "").Replace("]", "") : source;
    }

    public static string ParseDesc(this string source)
    {
      Match match = new Regex("\\[[^\\]]*\\]").Match(source);
      return match.Success ? source.Substring(match.Value.Length).Trim() : "";
    }

    public static string ParseProviderDesc(this string source)
    {
      Match match = new Regex("\\[[^\\]]*\\]").Match(source);
      return match.Success ? source.Substring(match.Value.Length).Trim() : source;
    }

    public static string FormatCodeDesc(this string code, string desc) => desc.IsNotNullOrEmpty() ? string.Format("[{0}] {1}", (object) code, (object) desc) : string.Format("{0}", (object) code);

    public static string CleanPhoneNumber(this string source) => source.IsNotNullOrEmpty() ? source.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "").Replace(" ", "") : "";

    public static string CleanString(this string source) => source.IsNotNullOrEmpty() ? source.Replace(",", "").Replace(".", "") : "";

    public static string FormatPhoneNumber(this string source)
    {
      if (!source.IsNotNullOrEmpty())
        return "";
      if (source.Length != 10)
        return source;
      return "(" + source.Substring(0, 3) + ") " + source.Substring(3, 3) + "-" + source.Right(4);
    }
  }
}
