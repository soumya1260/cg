﻿// Decompiled with JetBrains decompiler
// Type: HS.StringExtensions
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

namespace HS
{
  public static class StringExtensions
  {
    public static bool HSEquals(this string str1, string str2)
    {
      if (!string.IsNullOrEmpty(str1))
        return string.Equals(str1, str2);
      return string.IsNullOrEmpty(str2);
    }
  }
}
