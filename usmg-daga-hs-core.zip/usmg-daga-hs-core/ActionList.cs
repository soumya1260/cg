﻿// Decompiled with JetBrains decompiler
// Type: HS.ActionList
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace HS
{
  public class ActionList : Dictionary<string, WorkflowAction>
  {
    public WorkflowAction Add(string name)
    {
      WorkflowAction workflowAction = new WorkflowAction()
      {
        Name = name
      };
      this.Add(name, workflowAction);
      return workflowAction;
    }

    public void AddRange(IEnumerable<string> names)
    {
      if (names == null)
        return;
      foreach (string name in names)
        this.Add(name);
    }

    public void Deny(ServiceFault reason)
    {
      foreach (WorkflowAction workflowAction in this.Values)
        workflowAction.Deny(reason);
    }

    public void Deny(IEnumerable<ServiceFault> reasons)
    {
      foreach (WorkflowAction workflowAction in this.Values)
        workflowAction.Deny(reasons);
    }

    public void Allow()
    {
      foreach (WorkflowAction workflowAction in this.Values)
        workflowAction.Allow();
    }

    public void AllowIfNoReasons()
    {
      foreach (WorkflowAction workflowAction in this.Values)
        workflowAction.AllowIfNoReasons();
    }

    public void Deny(ServiceFault reason, params string[] actions)
    {
      foreach (string action in actions)
      {
        if (this.ContainsKey(action))
          this[action].Deny(reason);
      }
    }

    public void Deny(IEnumerable<ServiceFault> reasons, params string[] actions)
    {
      foreach (string action in actions)
      {
        if (this.ContainsKey(action))
          this[action].Deny(reasons);
      }
    }

    public void Allow(params string[] actions)
    {
      foreach (string action in actions)
      {
        if (this.ContainsKey(action))
          this[action].Allow();
      }
    }

    public void AllowIfNoReasons(params string[] actions)
    {
      foreach (string action in actions)
      {
        if (this.ContainsKey(action))
          this[action].AllowIfNoReasons();
      }
    }

    public bool Assert(Assertion test, params string[] actions)
    {
      if (!test.Test)
      {
        foreach (string action in actions)
        {
          if (this.ContainsKey(action))
            this[action].Deny(new ServiceFault()
            {
              Source = test.Source,
              Message = test.Message,
              IsLocalized = test.IsLocalized,
              FaultCode = test.FaultCode
            });
        }
      }
      return test.Test;
    }

    public bool Assert(bool test, Decimal faultCode, params string[] actions)
    {
      if (!test)
      {
        foreach (string action in actions)
        {
          if (this.ContainsKey(action))
            this[action].Deny(new ServiceFault()
            {
              Source = string.Empty,
              Message = string.Empty,
              IsLocalized = false,
              FaultCode = faultCode
            });
        }
      }
      return test;
    }

    public bool IsAllowed(string action) => this.ContainsKey(action) && this[action].Status == ActionStatus.Allow;

    public bool IsDenied(string action) => !this.ContainsKey(action) || this[action].Status == ActionStatus.Deny;

    public bool ContainsAnyKey(params string[] actions)
    {
      foreach (string action in actions)
      {
        if (this.ContainsKey(action))
          return true;
      }
      return false;
    }

    public ActionList()
    {
    }

    public ActionList(int capacity)
      : base(capacity)
    {
    }

    public ActionList(IDictionary<string, WorkflowAction> dictionary)
      : base(dictionary)
    {
    }

    public ActionList(SerializationInfo info, StreamingContext context)
      : base(info, context)
    {
    }
  }
}
