﻿// Decompiled with JetBrains decompiler
// Type: HS.Interfaces.SVC.Lookups.LookupCachingSingletonBase
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Collections.Generic;

namespace HS.Interfaces.SVC.Lookups
{
  public abstract class LookupCachingSingletonBase
  {
    private List<DiagnosisCode> _QNXTDiagnosisCodes;
    private List<DiagnosisCode> _BIDWDiagnosisCodes;
    private List<SpecialtyCode> _QNXTSpecialtyCodes;
    private List<SpecialtyCode> _BIDWSpecialtyCodes;
    private List<ProcedureCode> _QNXTProcedureCodes;
    private List<ProcedureCode> _BIDWProcedureCodes;
    private List<LeakageReason> _LeakageReasons;
    private List<ServiceCode> _PlaceOfServiceCodes;
    private List<ServiceType> _ServiceTypes;
    private List<UnitType> _UnitTypes;
    protected Func<DiagnosisCodesEnum, List<DiagnosisCode>> _funcDiagnosisCodes;
    protected Func<SpecialtyCodesEnum, List<SpecialtyCode>> _funcSpecialtyCodes;
    protected Func<ProcedureCodesEnum, List<ProcedureCode>> _funcProcedureCodes;
    protected Func<List<LeakageReason>> _funcLeakageReasons;
    protected Func<List<ServiceCode>> _funcPlaceOfServiceCodes;
    protected Func<List<ServiceType>> _funcServiceTypes;
    protected Func<List<UnitType>> _funcUnitTypes;
    private DateTime _lastRefreshed;

    public List<DiagnosisCode> QNXTDiagnosisCodes
    {
      get
      {
        this.CheckRefresh();
        return this._QNXTDiagnosisCodes;
      }
    }

    public List<DiagnosisCode> BIDWDiagnosisCodes
    {
      get
      {
        this.CheckRefresh();
        return this._BIDWDiagnosisCodes;
      }
    }

    public List<SpecialtyCode> QNXTSpecialtyCodes
    {
      get
      {
        this.CheckRefresh();
        return this._QNXTSpecialtyCodes;
      }
    }

    public List<SpecialtyCode> BIDWSpecialtyCodes
    {
      get
      {
        this.CheckRefresh();
        return this._BIDWSpecialtyCodes;
      }
    }

    public List<ProcedureCode> QNXTProcedureCodes
    {
      get
      {
        this.CheckRefresh();
        return this._QNXTProcedureCodes;
      }
    }

    public List<ProcedureCode> BIDWProcedureCodes
    {
      get
      {
        this.CheckRefresh();
        return this._BIDWProcedureCodes;
      }
    }

    public List<LeakageReason> LeakageReasons => this._LeakageReasons;

    public List<ServiceCode> PlaceOfServiceCodes => this._PlaceOfServiceCodes;

    public List<ServiceType> ServiceTypes => this._ServiceTypes;

    public List<UnitType> UnitTypes => this._UnitTypes;

    protected LookupCachingSingletonBase() => this.InitializeClass();

    protected virtual void InitializeClass()
    {
      this._lastRefreshed = DateTime.MinValue;
      this._QNXTDiagnosisCodes = new List<DiagnosisCode>();
      this._BIDWDiagnosisCodes = new List<DiagnosisCode>();
      this._QNXTSpecialtyCodes = new List<SpecialtyCode>();
      this._BIDWSpecialtyCodes = new List<SpecialtyCode>();
      this._QNXTProcedureCodes = new List<ProcedureCode>();
      this._BIDWProcedureCodes = new List<ProcedureCode>();
      this._LeakageReasons = new List<LeakageReason>();
      this._PlaceOfServiceCodes = new List<ServiceCode>();
      this._ServiceTypes = new List<ServiceType>();
      this._UnitTypes = new List<UnitType>();
      this.CheckRefresh();
    }

    protected event EventHandler<EventArgs> Refreshing;

    protected void CheckRefresh()
    {
      if (!(DateTime.Now.Subtract(this._lastRefreshed) >= new TimeSpan(0, 24, 0, 0)))
        return;
      IAsyncResult result1 = this._funcProcedureCodes.BeginInvoke(ProcedureCodesEnum.QNXT, (AsyncCallback) null, (object) null);
      IAsyncResult result2 = this._funcProcedureCodes.BeginInvoke(ProcedureCodesEnum.BIDW, (AsyncCallback) null, (object) null);
      IAsyncResult result3 = this._funcDiagnosisCodes.BeginInvoke(DiagnosisCodesEnum.QNXT, (AsyncCallback) null, (object) null);
      IAsyncResult result4 = this._funcDiagnosisCodes.BeginInvoke(DiagnosisCodesEnum.BIDW, (AsyncCallback) null, (object) null);
      IAsyncResult result5 = this._funcSpecialtyCodes.BeginInvoke(SpecialtyCodesEnum.QNXT, (AsyncCallback) null, (object) null);
      IAsyncResult result6 = this._funcSpecialtyCodes.BeginInvoke(SpecialtyCodesEnum.BIDW, (AsyncCallback) null, (object) null);
      IAsyncResult result7 = this._funcLeakageReasons.BeginInvoke((AsyncCallback) null, (object) null);
      IAsyncResult result8 = this._funcPlaceOfServiceCodes.BeginInvoke((AsyncCallback) null, (object) null);
      IAsyncResult result9 = this._funcServiceTypes.BeginInvoke((AsyncCallback) null, (object) null);
      IAsyncResult result10 = this._funcUnitTypes.BeginInvoke((AsyncCallback) null, (object) null);
      this._QNXTDiagnosisCodes = this._funcDiagnosisCodes.EndInvoke(result3);
      this._BIDWDiagnosisCodes = this._funcDiagnosisCodes.EndInvoke(result4);
      this._QNXTSpecialtyCodes = this._funcSpecialtyCodes.EndInvoke(result5);
      this._BIDWSpecialtyCodes = this._funcSpecialtyCodes.EndInvoke(result6);
      this._LeakageReasons = this._funcLeakageReasons.EndInvoke(result7);
      this._PlaceOfServiceCodes = this._funcPlaceOfServiceCodes.EndInvoke(result8);
      this._ServiceTypes = this._funcServiceTypes.EndInvoke(result9);
      this._UnitTypes = this._funcUnitTypes.EndInvoke(result10);
      this._QNXTProcedureCodes = this._funcProcedureCodes.EndInvoke(result1);
      this._BIDWProcedureCodes = this._funcProcedureCodes.EndInvoke(result2);
      if (this.Refreshing != null)
        this.Refreshing((object) this, EventArgs.Empty);
      this._lastRefreshed = DateTime.Now;
    }

    public void Invalidate() => this._lastRefreshed = DateTime.MinValue;
  }
}
