﻿// Decompiled with JetBrains decompiler
// Type: HS.ServiceResponse
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace HS
{
    [DataContract]
    public class ServiceResponse
    {
        private List<ServiceFault> _errors;
        private List<ServiceFault> _warnings;

        [DataMember]
        public ResponseResult Result { get; set; }

        [DataMember]
        public List<string> Messages { get; set; }

        [DataMember]
        public List<ServiceFault> Errors
        {
            get
            {
                if (this._errors == null)
                    this._errors = new List<ServiceFault>();
                return this._errors;
            }
            set => this._errors = value;
        }

        [DataMember]
        public List<ServiceFault> Warnings
        {
            get
            {
                if (this._warnings == null)
                    this._warnings = new List<ServiceFault>();
                return this._warnings;
            }
            set => this._warnings = value;
        }

        public void Error(ServiceFault fault)
        {
            if ((this.AssertOption & AssertOption.ErrorsAsWarnings) == AssertOption.ErrorsAsWarnings)
            {
                this.Warnings.Add(fault);
            }
            else
            {
                this.Errors.Add(fault);
                this.Result = ResponseResult.Error;
            }
        }

        public void Error(Exception ex)
        {
            this.Result = ResponseResult.Exception;
            this.Errors.Add(new ServiceFault()
            {
                Source = ex.Source,
                Message = ex.ToString(),
                FaultCode = -0.9999M,
                IsLocalized = false
            });
        }

        public void Error(IEnumerable<ServiceFault> faults)
        {
            foreach (ServiceFault fault in faults)
                this.Error(fault);
        }

        public void Warning(ServiceFault fault) => this.Warnings.Add(fault);

        public void Warning(Exception ex)
        {
            this.Result = ResponseResult.Error;
            this.Errors.Add(new ServiceFault()
            {
                Source = ex.Source,
                Message = ex.ToString(),
                FaultCode = -0.9999M,
                IsLocalized = false
            });
        }

        public void Warning(IEnumerable<ServiceFault> faults)
        {
            foreach (ServiceFault fault in faults)
                this.Warning(fault);
        }

        public AssertOption AssertOption { get; set; }

        public bool Assert(bool condition, string message, string source, Decimal faultCode)
        {
            if (!condition)
                this.Error(new ServiceFault()
                {
                    Message = message,
                    Source = source,
                    FaultCode = faultCode
                });
            return condition;
        }

        public bool AssertWarning(bool condition, string message, string source, Decimal faultCode)
        {
            if (!condition)
                this.Warning(new ServiceFault()
                {
                    Message = message,
                    Source = source,
                    FaultCode = faultCode
                });
            return condition;
        }

        public bool Assert(Assertion test)
        {
            if (!test.Test)
                this.Error(new ServiceFault()
                {
                    Source = test.Source,
                    Message = test.Message,
                    IsLocalized = test.IsLocalized,
                    FaultCode = test.FaultCode
                });
            return test.Test;
        }

        public bool AssertWarning(Assertion test)
        {
            if (!test.Test)
                this.Warning(new ServiceFault()
                {
                    Source = test.Source,
                    Message = test.Message,
                    IsLocalized = test.IsLocalized,
                    FaultCode = test.FaultCode
                });
            return test.Test;
        }

        public bool Assert(WorkflowActionResponse response, params string[] actions)
        {
            bool flag = true;
            List<string> stringList = new List<string>((IEnumerable<string>)actions);
            if (stringList.Count == 0)
                stringList = new List<string>((IEnumerable<string>)response.Actions.Keys);
            foreach (string key in stringList)
            {
                if (response.Actions[key].Status == ActionStatus.Deny)
                {
                    flag = false;
                    foreach (ServiceFault reason in response.Actions[key].Reasons)
                        this.Error(reason);
                }
            }
            return flag;
        }

        public bool AssertWarning(WorkflowActionResponse response, params string[] actions)
        {
            bool flag = true;
            List<string> stringList = new List<string>((IEnumerable<string>)actions);
            if (stringList.Count == 0)
                stringList = new List<string>((IEnumerable<string>)response.Actions.Keys);
            foreach (string key in stringList)
            {
                if (response.Actions[key].Status == ActionStatus.Deny)
                {
                    flag = false;
                    this.Warning((IEnumerable<ServiceFault>)response.Actions[key].Reasons);
                }
            }
            return flag;
        }

        public bool HasFailed => this.Result == ResponseResult.Exception || this.Result == ResponseResult.Error || this.Result == ResponseResult.SecurityViolation;

        public ServiceResponse()
        {
            this.Errors = new List<ServiceFault>();
            this.Warnings = new List<ServiceFault>();
            this.Messages = new List<string>();
        }
    }

    [DataContract]
    public class ServiceResponse<ItemType> : ServiceResponse
    {
        [DataMember]
        public ItemType Item { get; set; }
    }
}
