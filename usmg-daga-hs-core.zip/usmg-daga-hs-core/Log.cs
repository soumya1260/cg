﻿// Decompiled with JetBrains decompiler
// Type: HS.Log
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using HS.HSEmailService;
using System;
using System.Collections.Generic;
using System.Runtime.Remoting.Messaging;
using System.Web.Hosting;

namespace HS
{
  public static class Log
  {
    public static void LogMessage(string Message, MessageTypeEnum MessageType)
    {
      Log.AsyncLogMessageCaller logMessageCaller = new Log.AsyncLogMessageCaller(Log.LogMessageAsync);
      try
      {
        logMessageCaller.BeginInvoke(Message, MessageType, new AsyncCallback(Log.LogMessageCallback), new object());
      }
      catch (Exception ex)
      {
        throw;
      }
    }

    private static void LogMessageCallback(IAsyncResult result)
    {
      result.IsCompleted.ToString();
      ((Log.AsyncLogMessageCaller) ((AsyncResult) result).AsyncDelegate).EndInvoke(result);
    }

    private static void LogMessageAsync(string Message, MessageTypeEnum MessageType)
    {
      HSLoggingConfiguration current = HSLoggingConfiguration.Current;
      int levelMessageTypeEnum = (int) LogAgent.GetTraceLevelMessageTypeEnum(MessageType);
      string applicationName = Log.GetApplicationName();
      if (!current.WriteToDB)
        return;
      LogAgent.WriteMessageToLogDB(Message, applicationName, Environment.MachineName, MessageType, current.PromotionEnvironment);
    }

    public static void LogException(Exception exception) => Log.LogException(exception, (List<string>) null);

    public static void LogException(Exception exception, List<string> AdditionalMessages)
    {
      HSLoggingConfiguration current = HSLoggingConfiguration.Current;
      string applicationName = Log.GetApplicationName();
      if (AdditionalMessages.IsNull<List<string>>())
        AdditionalMessages = new List<string>();
      AdditionalMessages = Log.CleanMessages(AdditionalMessages);
      int ParentID = -1;
      if (current.WriteToDB)
        ParentID = LogAgent.WriteExceptionToLogDB(exception, applicationName, current.PromotionEnvironment, AdditionalMessages);
      if (exception.InnerException == null)
        return;
      Log.LogInnerException(exception.InnerException, ParentID, applicationName);
    }

    private static void LogInnerException(Exception ex, int ParentID, string AppName)
    {
      if (HSLoggingConfiguration.Current.WriteToDB)
        LogAgent.WriteInnerExceptionToLogDB(ex, ParentID, AppName);
      if (ex.InnerException == null)
        return;
      Log.LogInnerException(ex.InnerException, ParentID, AppName);
    }

    public static void SendEmail(Email MyEmail)
    {
      Log.AsyncEmailSendCaller asyncEmailSendCaller = new Log.AsyncEmailSendCaller(Log.SendEmailAsync);
      try
      {
        asyncEmailSendCaller.BeginInvoke(MyEmail, new AsyncCallback(Log.SendEmailCallback), new object());
      }
      catch (Exception ex)
      {
        throw;
      }
    }

    private static void SendEmailAsync(Email MyEmail)
    {
      string applicationName = Log.GetApplicationName();
      HSLoggingConfiguration current = HSLoggingConfiguration.Current;
      try
      {
        if (current.UseDefaultToEmailForSendMail)
          MyEmail.To = current.DefaultToEmailForSendMail;
        LogAgent.SendEmail(MyEmail);
      }
      catch (Exception ex)
      {
        LogAgent.WriteExceptionToLogDB(ex, applicationName, current.PromotionEnvironment, new List<string>());
      }
    }

    private static void SendEmailCallback(IAsyncResult result)
    {
      result.IsCompleted.ToString();
      ((Log.AsyncEmailSendCaller) ((AsyncResult) result).AsyncDelegate).EndInvoke(result);
    }

    internal static string GetApplicationName()
    {
      string applicationName;
      try
      {
        if (HSLoggingConfiguration.Current.OverrideAppName)
        {
          try
          {
            applicationName = HSLoggingConfiguration.Current.DefaultApplicationName;
          }
          catch
          {
            applicationName = "";
          }
        }
        else
        {
          string appName;
          try
          {
            appName = !string.IsNullOrEmpty(AppDomain.CurrentDomain.FriendlyName) ? AppDomain.CurrentDomain.FriendlyName.ToString() : HSLoggingConfiguration.Current.DefaultApplicationName;
          }
          catch
          {
            appName = HSLoggingConfiguration.Current.DefaultApplicationName;
          }
          applicationName = !Log.IsWebSite(appName) ? appName : HostingEnvironment.ApplicationHost.GetSiteName();
        }
      }
      catch
      {
        applicationName = "";
      }
      return applicationName;
    }

    private static bool IsWebSite(string appName)
    {
      try
      {
        appName = appName.ToUpper();
        bool flag1 = appName.Contains("W3SVC");
        bool flag2 = appName.EndsWith(".CONFIG");
        bool flag3 = appName.Contains(":\\");
        return flag1 || flag2 || flag3;
      }
      catch
      {
        return false;
      }
    }

    private static List<string> CleanMessages(List<string> Msgs)
    {
      List<string> stringList = new List<string>();
      foreach (string msg in Msgs)
      {
        string lower = msg.ToLower();
        if (lower.Contains("password=") || lower.Contains("password ="))
        {
          string[] separator = new string[1]{ ";" };
          string[] strArray = msg.Split(separator, StringSplitOptions.RemoveEmptyEntries);
          string str1 = "";
          foreach (string str2 in strArray)
          {
            if (!str2.ToLower().Contains("password=") && !str2.ToLower().Contains("password ="))
              str1 = str1 + str2 + "; ";
          }
          stringList.Add(str1);
        }
        else
          stringList.Add(lower);
      }
      return stringList;
    }

    public delegate void AsyncLogMessageCaller(string Message, MessageTypeEnum MessageType);

    public delegate void AsyncLogExceptionCaller(
      Exception exception,
      List<string> AdditionalMessages,
      HSLoggingConfiguration config);

    public delegate void AsyncEmailSendCaller(Email MyEmail);
  }
}
