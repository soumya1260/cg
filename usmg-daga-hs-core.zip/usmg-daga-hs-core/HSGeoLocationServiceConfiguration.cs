﻿// Decompiled with JetBrains decompiler
// Type: HS.HSGeoLocationServiceConfiguration
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace HS
{
  public class HSGeoLocationServiceConfiguration : ConfigurationSection
  {
    public static HSGeoLocationServiceConfiguration Current
    {
      get
      {
        if (!(ConfigurationManager.GetSection("HS.GeoLocationService") is HSGeoLocationServiceConfiguration current))
          current = new HSGeoLocationServiceConfiguration();
        return current;
      }
    }

    [ConfigurationProperty("bingMapsKey", DefaultValue = "", IsRequired = true)]
    public string BingMapsKey
    {
      get => (string) this["bingMapsKey"];
      set => this["bingMapsKey"] = (object) value;
    }

    [ConfigurationProperty("bingURIFormat", DefaultValue = "", IsRequired = true)]
    public string BingURIFormat
    {
      get => (string) this["bingURIFormat"];
      set => this["bingURIFormat"] = (object) value;
    }

    [ConfigurationProperty("countyAbbreviationRemovalListString", DefaultValue = "", IsRequired = true)]
    private string CountyAbbreviationRemovalListString
    {
      get => (string) this["countyAbbreviationRemovalListString"];
      set => this["countyAbbreviationRemovalListString"] = (object) value;
    }

    public List<string> CountyAbbreviationRemovalList
    {
      get => ((IEnumerable<string>) this.CountyAbbreviationRemovalListString.Split(',')).ToList<string>().FindAll((Predicate<string>) (item => !item.IsNullOrEmpty()));
      set => this.CountyAbbreviationRemovalListString = string.Join(",", value.FindAll((Predicate<string>) (item => !item.IsNullOrEmpty())).ToArray());
    }

    [ConfigurationProperty("removeInvalidSearchListString", DefaultValue = "", IsRequired = true)]
    private string RemoveInvalidSearchListString
    {
      get => (string) this["removeInvalidSearchListString"];
      set => this["removeInvalidSearchListString"] = (object) value;
    }

    public List<string> RemoveInvalidSearchStringList
    {
      get => ((IEnumerable<string>) this.RemoveInvalidSearchListString.Split(',')).ToList<string>().FindAll((Predicate<string>) (item => !item.IsNullOrEmpty()));
      set => this.RemoveInvalidSearchListString = string.Join(",", value.FindAll((Predicate<string>) (item => !item.IsNullOrEmpty())).ToArray());
    }
  }
}
