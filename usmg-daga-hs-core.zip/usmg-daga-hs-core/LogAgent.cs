﻿// Decompiled with JetBrains decompiler
// Type: HS.LogAgent
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using HS.HSEmailService;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace HS
{
  internal static class LogAgent
  {
    public static MessageTypeEnum GetMessageTypeEnumFromTraceLevel(TraceLevel tl)
    {
      switch (tl)
      {
        case TraceLevel.Off:
          return MessageTypeEnum.Informational;
        case TraceLevel.Error:
          return MessageTypeEnum.Exception;
        case TraceLevel.Warning:
          return MessageTypeEnum.Exception;
        case TraceLevel.Info:
          return MessageTypeEnum.Informational;
        case TraceLevel.Verbose:
          return MessageTypeEnum.Verbose;
        default:
          return MessageTypeEnum.Debug;
      }
    }

    public static TraceLevel GetTraceLevelMessageTypeEnum(MessageTypeEnum mt)
    {
      switch (mt)
      {
        case MessageTypeEnum.Informational:
          return TraceLevel.Info;
        case MessageTypeEnum.Debug:
          return TraceLevel.Info;
        case MessageTypeEnum.Exception:
          return TraceLevel.Error;
        case MessageTypeEnum.Verbose:
          return TraceLevel.Verbose;
        case MessageTypeEnum.SecurityMessage:
          return TraceLevel.Warning;
        default:
          return TraceLevel.Error;
      }
    }

    internal static void SendEmail(Email MyEmail)
    {
      using (BaseAgent<ILogInterface> baseAgent = new BaseAgent<ILogInterface>())
      {
        SendEmailRequest request = new SendEmailRequest();
        ILogInterface serviceChannel = baseAgent.GetServiceChannel("NetTcpBinding_ILogInterface");
        try
        {
          request.Item = MyEmail;
          request.UserID = "LoggingUser";
          request.RequestingAuthorityID = Environment.MachineName.ToString();
          serviceChannel.SendEmail(request);
        }
        catch (Exception ex)
        {
          LogAgent.HandleLoggerException(ex);
          MyEmail.Body.Insert(0, "<b/>PECIAL NOTE! The Logger was unable to send this email through the logger service.  This was sent through HSEmail directly.</b><br><br>");
          HSEmailServiceFacade.SendEmail(MyEmail);
        }
        finally
        {
          baseAgent.Dispose();
        }
      }
    }

    internal static void WriteMessageToLogDB(
      string Message,
      string SendingApplication,
      string ServerName,
      MessageTypeEnum messageType,
      string PromotionEnvironment)
    {
      using (BaseAgent<ILogInterface> baseAgent = new BaseAgent<ILogInterface>())
      {
        WriteToLogRequest writeToLogRequest = new WriteToLogRequest();
        ILogInterface serviceChannel = baseAgent.GetServiceChannel("NetTcpBinding_ILogInterface");
        try
        {
          writeToLogRequest.LogMessage = new LogObject()
          {
            MessageTitle = string.Format("Message from {0} : {1}", (object) SendingApplication, (object) Message),
            Message = Message,
            MessageType = messageType,
            SendingApplication = SendingApplication,
            ExceptionMessage = "",
            ExceptionSource = "",
            ExceptionStackTrace = "",
            ContainsException = false,
            MessageSentFrom = Environment.MachineName.ToString(),
            PromotionEnvironment = PromotionEnvironment
          };
          writeToLogRequest.UserID = "LoggingUser";
          writeToLogRequest.RequestingAuthorityID = Environment.MachineName.ToString();
          int originalExceptionId = serviceChannel.WriteMessageToLog(writeToLogRequest).OriginalExceptionID;
        }
        catch (Exception ex)
        {
          LogAgent.HandleLoggerException(ex);
          Email email = LogAgent.PopulateEmailWithDefaultAddress();
          email.Body = EmailFormatter.FormatEmailBodyForException(writeToLogRequest, false);
          HSEmailServiceFacade.SendEmail(email);
        }
        finally
        {
          baseAgent.Dispose();
        }
      }
    }

    internal static int WriteExceptionToLogDB(
      Exception ex,
      string SendingApplication,
      string PromotionEnvironment,
      List<string> Messages)
    {
      using (BaseAgent<ILogInterface> baseAgent = new BaseAgent<ILogInterface>())
      {
        WriteToLogRequest writeToLogRequest = new WriteToLogRequest();
        ILogInterface serviceChannel = baseAgent.GetServiceChannel("NetTcpBinding_ILogInterface");
        try
        {
          LogObject logObject = new LogObject();
          logObject.MessageTitle = "An Exception has occurred in Application " + SendingApplication;
          logObject.MessageType = LogAgent.GetMessageTypeEnumFromTraceLevel(TraceLevel.Error);
          if (ex != null)
            logObject.ExceptionType = ex.GetType().ToString();
          if (SendingApplication != null)
            logObject.SendingApplication = SendingApplication;
          if (ex.Message != null)
            logObject.ExceptionMessage = ex.Message;
          if (ex.Source != null)
            logObject.ExceptionSource = ex.Source;
          if (ex.StackTrace != null)
            logObject.ExceptionStackTrace = ex.StackTrace;
          logObject.ContainsException = true;
          if (Environment.MachineName != null)
            logObject.MessageSentFrom = Environment.MachineName.ToString();
          if (PromotionEnvironment != null)
            logObject.PromotionEnvironment = PromotionEnvironment;
          if (Messages != null && Messages.Count > 0)
            logObject.AdditionalMessages = Messages;
          writeToLogRequest.LogMessage = logObject;
          writeToLogRequest.UserID = "LoggingUser";
          writeToLogRequest.RequestingAuthorityID = Environment.MachineName.ToString();
          return serviceChannel.WriteMessageToLog(writeToLogRequest).OriginalExceptionID;
        }
        catch (Exception ex1)
        {
          LogAgent.HandleLoggerException(ex1);
          Email email = LogAgent.PopulateEmailWithDefaultAddress();
          email.Body = EmailFormatter.FormatEmailBodyForException(writeToLogRequest, false);
          HSEmailServiceFacade.SendEmail(email);
        }
        finally
        {
          baseAgent.Dispose();
        }
      }
      return 0;
    }

    internal static void WriteInnerExceptionToLogDB(
      Exception ex,
      int OriginalExceptionID,
      string SendingApplication)
    {
      using (BaseAgent<ILogInterface> baseAgent = new BaseAgent<ILogInterface>())
      {
        WriteToLogRequest writeToLogRequest = new WriteToLogRequest();
        ILogInterface serviceChannel = baseAgent.GetServiceChannel("NetTcpBinding_ILogInterface");
        try
        {
          writeToLogRequest.LogMessage = new LogObject()
          {
            OriginalMessageID = OriginalExceptionID,
            MessageTitle = "An Exception has occurred in Application " + SendingApplication,
            Message = ex.Message,
            MessageType = LogAgent.GetMessageTypeEnumFromTraceLevel(TraceLevel.Error),
            SendingApplication = SendingApplication,
            ExceptionMessage = ex.Message,
            ExceptionSource = ex.Source,
            ExceptionStackTrace = ex.StackTrace,
            ContainsException = true,
            MessageSentFrom = Environment.MachineName.ToString(),
            ExceptionType = ex.GetType().ToString()
          };
          writeToLogRequest.UserID = "LoggingUser";
          writeToLogRequest.RequestingAuthorityID = Environment.MachineName.ToString();
          int originalExceptionId = serviceChannel.WriteMessageToLog(writeToLogRequest).OriginalExceptionID;
        }
        catch (Exception ex1)
        {
          LogAgent.HandleLoggerException(ex1);
          Email email = LogAgent.PopulateEmailWithDefaultAddress();
          email.Body = EmailFormatter.FormatEmailBodyForException(writeToLogRequest, false);
          HSEmailServiceFacade.SendEmail(email);
        }
        finally
        {
          baseAgent.Dispose();
        }
      }
    }

    internal static Email PopulateEmailWithDefaultAddress()
    {
      string str1 = "URGENT!!! An Exception has Occurred and was NOT logged to the database";
      string str2;
      string str3;
      try
      {
        HSLoggingConfiguration current = HSLoggingConfiguration.Current;
        str2 = current.DefaultToEmail;
        str3 = current.DefaultFromEmail;
      }
      catch
      {
        str2 = "AutoWebExceptions@healthspring.com";
        str3 = "AutoWebExceptions@healthspring.com";
      }
      if (str2 == "" || str3 == "")
      {
        str2 = "AutoWebExceptions@healthspring.com";
        str3 = "AutoWebExceptions@healthspring.com";
      }
      Email email = new Email()
      {
        To = str2,
        From = str3,
        Subject = str1
      };
      email.isHTML = true;
      return email;
    }

    internal static void HandleLoggerException(Exception ex) => new EventLog()
    {
      Source = "HS.Services.Logging"
    }.WriteEntry(string.Format("An Exception has occurred : {0} : {1}", (object) ex.Message, (object) ex.StackTrace), EventLogEntryType.Error);
  }
}
