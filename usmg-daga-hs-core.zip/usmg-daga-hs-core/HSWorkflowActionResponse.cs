﻿// Decompiled with JetBrains decompiler
// Type: HS.HSWorkflowActionResponse
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.Runtime.Serialization;

namespace HS
{
  [DataContract]
  public class HSWorkflowActionResponse : WorkflowActionResponse
  {
    [DataMember]
    public bool ContainsNPII_PHI_Data { get; set; }
  }
}
