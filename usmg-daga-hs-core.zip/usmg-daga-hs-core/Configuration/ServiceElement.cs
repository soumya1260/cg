﻿// Decompiled with JetBrains decompiler
// Type: HS.Configuration.ServiceElement
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.Configuration;

namespace HS.Configuration
{
  public class ServiceElement : ConfigurationElement
  {
    [ConfigurationProperty("type", IsDefaultCollection = true, IsKey = true)]
    public string ServiceTypeName
    {
      get => (string) this["type"];
      set => this["type"] = (object) value;
    }

    [ConfigurationProperty("enabled", DefaultValue = "true", IsRequired = false)]
    public bool Enabled
    {
      get => (bool) this["enabled"];
      set => this["enabled"] = (object) value;
    }
  }
}
