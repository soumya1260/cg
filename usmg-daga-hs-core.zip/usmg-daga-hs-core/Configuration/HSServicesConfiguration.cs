﻿// Decompiled with JetBrains decompiler
// Type: HS.Configuration.HSServicesConfiguration
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.Configuration;

namespace HS.Configuration
{
  public class HSServicesConfiguration : ConfigurationSection
  {
    [ConfigurationProperty("runAsService", DefaultValue = "false", IsRequired = false)]
    public bool RunAsService
    {
      get => (bool) this["runAsService"];
      set => this["runAsService"] = (object) value;
    }

    [ConfigurationProperty("services", IsDefaultCollection = false)]
    public ServicesCollection Services
    {
      get => (ServicesCollection) this["services"];
      set => this["services"] = (object) value;
    }

    [ConfigurationProperty("maxSuccessLogDepth", DefaultValue = "1", IsRequired = false)]
    public int MaxSuccessLogDepth
    {
      get => (int) this["maxSuccessLogDepth"];
      set => this["maxSuccessLogDepth"] = (object) value;
    }

    [ConfigurationProperty("maxFailureLogDepth", DefaultValue = "40", IsRequired = false)]
    public int MaxFailureLogDepth
    {
      get => (int) this["maxFailureLogDepth"];
      set => this["maxFailureLogDepth"] = (object) value;
    }

    [ConfigurationProperty("logObjectFullName", DefaultValue = "false", IsRequired = false)]
    public bool LogObjectFullName
    {
      get => (bool) this["logObjectFullName"];
      set => this["logObjectFullName"] = (object) value;
    }

    public static HSServicesConfiguration Current => ConfigurationManager.GetSection("hs/services") as HSServicesConfiguration;
  }
}
