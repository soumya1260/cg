﻿// Decompiled with JetBrains decompiler
// Type: HS.Linq.LinqExtensions
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace HS.Linq
{
  public static class LinqExtensions
  {
    private static LambdaExpression GenerateSelector<TEntity>(
      string propertyName,
      out Type resultType)
      where TEntity : class
    {
      ParameterExpression parameterExpression = Expression.Parameter(typeof (TEntity), "Entity");
      PropertyInfo property;
      Expression expression;
      if (propertyName.Contains<char>('.'))
      {
        string[] strArray = propertyName.Split('.');
        property = typeof (TEntity).GetProperty(strArray[0]);
        expression = (Expression) Expression.MakeMemberAccess((Expression) parameterExpression, (MemberInfo) property);
        for (int index = 1; index < strArray.Length; ++index)
        {
          property = property.PropertyType.GetProperty(strArray[index]);
          expression = (Expression) Expression.MakeMemberAccess(expression, (MemberInfo) property);
        }
      }
      else
      {
        property = typeof (TEntity).GetProperty(propertyName);
        expression = (Expression) Expression.MakeMemberAccess((Expression) parameterExpression, (MemberInfo) property);
      }
      resultType = property.PropertyType;
      return Expression.Lambda(expression, parameterExpression);
    }

    private static MethodCallExpression GenerateMethodCall<TEntity>(
      IQueryable<TEntity> source,
      string methodName,
      string fieldName)
      where TEntity : class
    {
      Type type = typeof (TEntity);
      Type resultType;
      LambdaExpression selector = LinqExtensions.GenerateSelector<TEntity>(fieldName, out resultType);
      return Expression.Call(typeof (Queryable), methodName, new Type[2]
      {
        type,
        resultType
      }, source.Expression, (Expression) Expression.Quote((Expression) selector));
    }

    public static IOrderedQueryable<TEntity> OrderBy<TEntity>(
      this IQueryable<TEntity> source,
      string fieldName)
      where TEntity : class
    {
      MethodCallExpression methodCall = LinqExtensions.GenerateMethodCall<TEntity>(source, nameof (OrderBy), fieldName);
      return source.Provider.CreateQuery<TEntity>((Expression) methodCall) as IOrderedQueryable<TEntity>;
    }

    public static IOrderedQueryable<TEntity> OrderByDescending<TEntity>(
      this IQueryable<TEntity> source,
      string fieldName)
      where TEntity : class
    {
      MethodCallExpression methodCall = LinqExtensions.GenerateMethodCall<TEntity>(source, nameof (OrderByDescending), fieldName);
      return source.Provider.CreateQuery<TEntity>((Expression) methodCall) as IOrderedQueryable<TEntity>;
    }

    public static IOrderedQueryable<TEntity> ThenBy<TEntity>(
      this IOrderedQueryable<TEntity> source,
      string fieldName)
      where TEntity : class
    {
      MethodCallExpression methodCall = LinqExtensions.GenerateMethodCall<TEntity>((IQueryable<TEntity>) source, nameof (ThenBy), fieldName);
      return source.Provider.CreateQuery<TEntity>((Expression) methodCall) as IOrderedQueryable<TEntity>;
    }

    public static IOrderedQueryable<TEntity> ThenByDescending<TEntity>(
      this IOrderedQueryable<TEntity> source,
      string fieldName)
      where TEntity : class
    {
      MethodCallExpression methodCall = LinqExtensions.GenerateMethodCall<TEntity>((IQueryable<TEntity>) source, nameof (ThenByDescending), fieldName);
      return source.Provider.CreateQuery<TEntity>((Expression) methodCall) as IOrderedQueryable<TEntity>;
    }

    public static IOrderedQueryable<TEntity> OrderUsingSortExpression<TEntity>(
      this IQueryable<TEntity> source,
      string sortExpression)
      where TEntity : class
    {
      string[] strArray1 = sortExpression.Split(',');
      IOrderedQueryable<TEntity> source1 = (IOrderedQueryable<TEntity>) null;
      for (int index = 0; index < strArray1.Length; ++index)
      {
        string[] strArray2 = strArray1[index].Trim().Split(' ');
        string fieldName = strArray2[0];
        source1 = strArray2.Length != 2 || !strArray2[1].Equals("DESC", StringComparison.OrdinalIgnoreCase) ? (index == 0 ? source.OrderBy<TEntity>(fieldName) : source1.ThenBy<TEntity>(fieldName)) : (index == 0 ? source.OrderByDescending<TEntity>(fieldName) : source1.ThenByDescending<TEntity>(fieldName));
      }
      return source1;
    }
  }
}
