﻿// Decompiled with JetBrains decompiler
// Type: HS.Linq.LinqExtensions2
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace HS.Linq
{
  public static class LinqExtensions2
  {
    public static T FindNext<T>(
      this IList<T> list,
      EnumeratorDirection direction,
      T relativeTo,
      Predicate<T> func)
    {
      int num = 0;
      switch (direction)
      {
        case EnumeratorDirection.Next:
          if ((object) relativeTo != null)
            num = list.IndexOf(relativeTo) + 1;
          for (int index = num; index < list.Count; ++index)
          {
            T next = list[index];
            if (func(next))
              return next;
          }
          break;
        case EnumeratorDirection.Previous:
          if ((object) relativeTo == null)
            return default (T);
          for (int index = list.IndexOf(relativeTo) - 1; index >= 0; --index)
          {
            T next = list[index];
            if (func(next))
              return next;
          }
          break;
        case EnumeratorDirection.First:
          using (IEnumerator<T> enumerator = list.GetEnumerator())
          {
            while (enumerator.MoveNext())
            {
              T current = enumerator.Current;
              if (func(current))
                return current;
            }
            break;
          }
        case EnumeratorDirection.Last:
          for (int index = list.Count - 1; index >= 0; --index)
          {
            T next = list[index];
            if (func(next))
              return next;
          }
          break;
      }
      return default (T);
    }

    public static IEnumerable<child> Children<parent, child>(
      this IEnumerable<parent> list,
      Func<parent, IEnumerable<child>> func)
    {
      foreach (parent p in list)
      {
        foreach (child c in func(p))
          yield return c;
      }
    }

    public static IEnumerable<ParentChild<parent, child>> JoinChildren<parent, child>(
      this IEnumerable<parent> list,
      Func<parent, IEnumerable<child>> func)
    {
      foreach (parent p in list)
      {
        foreach (child c in func(p))
          yield return new ParentChild<parent, child>()
          {
            Parent = p,
            Child = c
          };
      }
    }

    public static IEnumerable<child> FindChildren<parent, child>(
      this IEnumerable<parent> list,
      Func<parent, IEnumerable<child>> func,
      Func<parent, child, bool> selector)
    {
      foreach (parent p in list)
      {
        IEnumerable<child> children = func(p);
        if (children != null)
        {
          foreach (child c in children)
          {
            if (selector(p, c))
              yield return c;
          }
        }
      }
    }

    public static Expression ReplaceParameters(this Expression e, ParameterExpression p)
    {
      Expression expression = e;
      if (expression == null)
        return (Expression) null;
      switch (expression.NodeType)
      {
        case ExpressionType.Add:
          expression = (Expression) Expression.Add(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.AddChecked:
          expression = (Expression) Expression.AddChecked(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.And:
          expression = (Expression) Expression.And(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.AndAlso:
          expression = (Expression) Expression.AndAlso(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.ArrayLength:
          expression = (Expression) Expression.ArrayLength(((UnaryExpression) expression).Operand.ReplaceParameters(p));
          break;
        case ExpressionType.ArrayIndex:
          expression = (Expression) Expression.ArrayIndex(((MethodCallExpression) expression).Object.ReplaceParameters(p), ((MethodCallExpression) expression).Arguments.Select<Expression, Expression>((Func<Expression, Expression>) (a => a.ReplaceParameters(p))).AsEnumerable<Expression>());
          break;
        case ExpressionType.Call:
          expression = (Expression) Expression.Call(((MethodCallExpression) expression).Object.ReplaceParameters(p), ((MethodCallExpression) expression).Method, ((MethodCallExpression) expression).Arguments.Select<Expression, Expression>((Func<Expression, Expression>) (a => a.ReplaceParameters(p))).AsEnumerable<Expression>());
          break;
        case ExpressionType.Coalesce:
          expression = (Expression) Expression.Coalesce(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), (LambdaExpression) ((BinaryExpression) expression).Conversion.ReplaceParameters(p));
          break;
        case ExpressionType.Conditional:
          expression = (Expression) Expression.Condition(((ConditionalExpression) expression).Test.ReplaceParameters(p), ((ConditionalExpression) expression).IfTrue.ReplaceParameters(p), ((ConditionalExpression) expression).IfFalse.ReplaceParameters(p));
          break;
        case ExpressionType.Convert:
          expression = (Expression) Expression.Convert(((UnaryExpression) expression).Operand.ReplaceParameters(p), expression.Type, ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.ConvertChecked:
          expression = (Expression) Expression.ConvertChecked(((UnaryExpression) expression).Operand.ReplaceParameters(p), expression.Type, ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.Divide:
          expression = (Expression) Expression.Divide(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Equal:
          expression = (Expression) Expression.Equal(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.ExclusiveOr:
          expression = (Expression) Expression.ExclusiveOr(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.GreaterThan:
          expression = (Expression) Expression.GreaterThan(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.GreaterThanOrEqual:
          expression = (Expression) Expression.GreaterThanOrEqual(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Invoke:
          expression = (Expression) Expression.Invoke(((InvocationExpression) expression).Expression.ReplaceParameters(p), ((InvocationExpression) expression).Arguments.Select<Expression, Expression>((Func<Expression, Expression>) (a => a.ReplaceParameters(p))).AsEnumerable<Expression>());
          break;
        case ExpressionType.Lambda:
          expression = (Expression) Expression.Lambda(((LambdaExpression) expression).Body.ReplaceParameters(p), ((LambdaExpression) expression).Parameters.Select<ParameterExpression, ParameterExpression>((Func<ParameterExpression, ParameterExpression>) (a => p)).ToArray<ParameterExpression>());
          break;
        case ExpressionType.LeftShift:
          expression = (Expression) Expression.LeftShift(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.LessThan:
          expression = (Expression) Expression.LessThan(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.LessThanOrEqual:
          expression = (Expression) Expression.LessThanOrEqual(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.ListInit:
          expression = (Expression) Expression.ListInit((NewExpression) ((ListInitExpression) expression).NewExpression.ReplaceParameters(p), ((ListInitExpression) expression).Initializers.Select<ElementInit, ElementInit>((Func<ElementInit, ElementInit>) (i => i.ReplaceParameters(p))));
          break;
        case ExpressionType.MemberAccess:
          expression = (Expression) Expression.MakeMemberAccess(((MemberExpression) expression).Expression.ReplaceParameters(p), ((MemberExpression) expression).Member);
          break;
        case ExpressionType.MemberInit:
          expression = (Expression) Expression.MemberInit((NewExpression) ((MemberInitExpression) expression).NewExpression.ReplaceParameters(p), ((MemberInitExpression) expression).Bindings.Select<MemberBinding, MemberBinding>((Func<MemberBinding, MemberBinding>) (b => b.ReplaceParameters(p))));
          break;
        case ExpressionType.Modulo:
          expression = (Expression) Expression.Modulo(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Multiply:
          expression = (Expression) Expression.Multiply(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.MultiplyChecked:
          expression = (Expression) Expression.MultiplyChecked(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Negate:
          expression = (Expression) Expression.Negate(((UnaryExpression) expression).Operand.ReplaceParameters(p), ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.UnaryPlus:
          expression = (Expression) Expression.UnaryPlus(((UnaryExpression) expression).Operand.ReplaceParameters(p), ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.NegateChecked:
          expression = (Expression) Expression.NegateChecked(((UnaryExpression) expression).Operand.ReplaceParameters(p), ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.New:
          expression = (Expression) Expression.New(((NewExpression) expression).Constructor, ((NewExpression) expression).Arguments.Select<Expression, Expression>((Func<Expression, Expression>) (a => a.ReplaceParameters(p))), (IEnumerable<MemberInfo>) ((NewExpression) expression).Members);
          break;
        case ExpressionType.NewArrayInit:
          expression = (Expression) Expression.NewArrayInit(expression.Type, ((NewArrayExpression) expression).Expressions.Select<Expression, Expression>((Func<Expression, Expression>) (x => x.ReplaceParameters(p))));
          break;
        case ExpressionType.NewArrayBounds:
          expression = (Expression) Expression.NewArrayBounds(expression.Type, ((NewArrayExpression) expression).Expressions.Select<Expression, Expression>((Func<Expression, Expression>) (x => x.ReplaceParameters(p))));
          break;
        case ExpressionType.Not:
          expression = (Expression) Expression.Not(((UnaryExpression) expression).Operand.ReplaceParameters(p), ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.NotEqual:
          expression = (Expression) Expression.NotEqual(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Or:
          expression = (Expression) Expression.Or(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.OrElse:
          expression = (Expression) Expression.OrElse(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Parameter:
          expression = (Expression) p;
          break;
        case ExpressionType.Power:
          expression = (Expression) Expression.Power(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Quote:
          expression = (Expression) Expression.Quote(((UnaryExpression) expression).Operand.ReplaceParameters(p));
          break;
        case ExpressionType.RightShift:
          expression = (Expression) Expression.RightShift(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Subtract:
          expression = (Expression) Expression.Subtract(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.SubtractChecked:
          expression = (Expression) Expression.SubtractChecked(((BinaryExpression) expression).Left.ReplaceParameters(p), ((BinaryExpression) expression).Right.ReplaceParameters(p), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.TypeAs:
          expression = (Expression) Expression.TypeAs(((UnaryExpression) expression).Operand.ReplaceParameters(p), expression.Type);
          break;
        case ExpressionType.TypeIs:
          expression = (Expression) Expression.TypeIs(((TypeBinaryExpression) expression).Expression.ReplaceParameters(p), ((TypeBinaryExpression) expression).TypeOperand);
          break;
      }
      return expression;
    }

    public static MemberBinding ReplaceParameters(
      this MemberBinding binding,
      ParameterExpression p)
    {
      if (binding == null)
        return (MemberBinding) null;
      switch (binding.BindingType)
      {
        case MemberBindingType.Assignment:
          return (MemberBinding) Expression.Bind(binding.Member, ((MemberAssignment) binding).Expression.ReplaceParameters(p));
        case MemberBindingType.MemberBinding:
          return (MemberBinding) Expression.MemberBind(binding.Member, ((MemberMemberBinding) binding).Bindings.Select<MemberBinding, MemberBinding>((Func<MemberBinding, MemberBinding>) (b => b.ReplaceParameters(p))));
        case MemberBindingType.ListBinding:
          return (MemberBinding) Expression.ListBind(binding.Member, ((MemberListBinding) binding).Initializers.Select<ElementInit, ElementInit>((Func<ElementInit, ElementInit>) (i => i.ReplaceParameters(p))));
        default:
          return (MemberBinding) null;
      }
    }

    public static ElementInit ReplaceParameters(
      this ElementInit elementInit,
      ParameterExpression p)
    {
      return elementInit == null ? (ElementInit) null : Expression.ElementInit(elementInit.AddMethod, elementInit.Arguments.Select<Expression, Expression>((Func<Expression, Expression>) (a => a.ReplaceParameters(p))));
    }

    public static Expression Transform(
      this Expression e,
      Func<Expression, Expression> transformExpression)
    {
      Expression expression = transformExpression(e);
      if (expression == null)
        return (Expression) null;
      switch (expression.NodeType)
      {
        case ExpressionType.Add:
          expression = (Expression) Expression.Add(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.AddChecked:
          expression = (Expression) Expression.AddChecked(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.And:
          expression = (Expression) Expression.And(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.AndAlso:
          expression = (Expression) Expression.AndAlso(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.ArrayLength:
          expression = (Expression) Expression.ArrayLength(((UnaryExpression) expression).Operand.Transform(transformExpression));
          break;
        case ExpressionType.ArrayIndex:
          expression = (Expression) Expression.ArrayIndex(((MethodCallExpression) expression).Object.Transform(transformExpression), ((MethodCallExpression) expression).Arguments.Select<Expression, Expression>((Func<Expression, Expression>) (a => a.Transform(transformExpression))).AsEnumerable<Expression>());
          break;
        case ExpressionType.Call:
          expression = (Expression) Expression.Call(((MethodCallExpression) expression).Object.Transform(transformExpression), ((MethodCallExpression) expression).Method, ((MethodCallExpression) expression).Arguments.Select<Expression, Expression>((Func<Expression, Expression>) (a => a.Transform(transformExpression))).AsEnumerable<Expression>());
          break;
        case ExpressionType.Coalesce:
          expression = (Expression) Expression.Coalesce(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), (LambdaExpression) ((BinaryExpression) expression).Conversion.Transform(transformExpression));
          break;
        case ExpressionType.Conditional:
          expression = (Expression) Expression.Condition(((ConditionalExpression) expression).Test.Transform(transformExpression), ((ConditionalExpression) expression).IfTrue.Transform(transformExpression), ((ConditionalExpression) expression).IfFalse.Transform(transformExpression));
          break;
        case ExpressionType.Convert:
          expression = (Expression) Expression.Convert(((UnaryExpression) expression).Operand.Transform(transformExpression), expression.Type, ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.ConvertChecked:
          expression = (Expression) Expression.ConvertChecked(((UnaryExpression) expression).Operand.Transform(transformExpression), expression.Type, ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.Divide:
          expression = (Expression) Expression.Divide(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Equal:
          expression = (Expression) Expression.Equal(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.ExclusiveOr:
          expression = (Expression) Expression.ExclusiveOr(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.GreaterThan:
          expression = (Expression) Expression.GreaterThan(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.GreaterThanOrEqual:
          expression = (Expression) Expression.GreaterThanOrEqual(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Invoke:
          expression = (Expression) Expression.Invoke(((InvocationExpression) expression).Expression.Transform(transformExpression), ((InvocationExpression) expression).Arguments.Select<Expression, Expression>((Func<Expression, Expression>) (a => a.Transform(transformExpression))).AsEnumerable<Expression>());
          break;
        case ExpressionType.Lambda:
          expression = (Expression) Expression.Lambda(((LambdaExpression) expression).Body.Transform(transformExpression), ((LambdaExpression) expression).Parameters.Select<ParameterExpression, ParameterExpression>((Func<ParameterExpression, ParameterExpression>) (a => (ParameterExpression) a.Transform(transformExpression))).ToArray<ParameterExpression>());
          break;
        case ExpressionType.LeftShift:
          expression = (Expression) Expression.LeftShift(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.LessThan:
          expression = (Expression) Expression.LessThan(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.LessThanOrEqual:
          expression = (Expression) Expression.LessThanOrEqual(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.ListInit:
          expression = (Expression) Expression.ListInit((NewExpression) ((ListInitExpression) expression).NewExpression.Transform(transformExpression), ((ListInitExpression) expression).Initializers.Select<ElementInit, ElementInit>((Func<ElementInit, ElementInit>) (i => i.Transform(transformExpression))));
          break;
        case ExpressionType.MemberAccess:
          expression = (Expression) Expression.MakeMemberAccess(((MemberExpression) expression).Expression.Transform(transformExpression), ((MemberExpression) expression).Member);
          break;
        case ExpressionType.MemberInit:
          expression = (Expression) Expression.MemberInit((NewExpression) ((MemberInitExpression) expression).NewExpression.Transform(transformExpression), ((MemberInitExpression) expression).Bindings.Select<MemberBinding, MemberBinding>((Func<MemberBinding, MemberBinding>) (b => b.Transform(transformExpression))));
          break;
        case ExpressionType.Modulo:
          expression = (Expression) Expression.Modulo(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Multiply:
          expression = (Expression) Expression.Multiply(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.MultiplyChecked:
          expression = (Expression) Expression.MultiplyChecked(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Negate:
          expression = (Expression) Expression.Negate(((UnaryExpression) expression).Operand.Transform(transformExpression), ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.UnaryPlus:
          expression = (Expression) Expression.UnaryPlus(((UnaryExpression) expression).Operand.Transform(transformExpression), ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.NegateChecked:
          expression = (Expression) Expression.NegateChecked(((UnaryExpression) expression).Operand.Transform(transformExpression), ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.New:
          expression = (Expression) Expression.New(((NewExpression) expression).Constructor, ((NewExpression) expression).Arguments.Select<Expression, Expression>((Func<Expression, Expression>) (a => a.Transform(transformExpression))), (IEnumerable<MemberInfo>) ((NewExpression) expression).Members);
          break;
        case ExpressionType.NewArrayInit:
          expression = (Expression) Expression.NewArrayInit(expression.Type, ((NewArrayExpression) expression).Expressions.Select<Expression, Expression>((Func<Expression, Expression>) (x => x.Transform(transformExpression))));
          break;
        case ExpressionType.NewArrayBounds:
          expression = (Expression) Expression.NewArrayBounds(expression.Type, ((NewArrayExpression) expression).Expressions.Select<Expression, Expression>((Func<Expression, Expression>) (x => x.Transform(transformExpression))));
          break;
        case ExpressionType.Not:
          expression = (Expression) Expression.Not(((UnaryExpression) expression).Operand.Transform(transformExpression), ((UnaryExpression) expression).Method);
          break;
        case ExpressionType.NotEqual:
          expression = (Expression) Expression.NotEqual(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).IsLiftedToNull, ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Or:
          expression = (Expression) Expression.Or(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.OrElse:
          expression = (Expression) Expression.OrElse(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Power:
          expression = (Expression) Expression.Power(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Quote:
          expression = (Expression) Expression.Quote(((UnaryExpression) expression).Operand.Transform(transformExpression));
          break;
        case ExpressionType.RightShift:
          expression = (Expression) Expression.RightShift(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.Subtract:
          expression = (Expression) Expression.Subtract(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.SubtractChecked:
          expression = (Expression) Expression.SubtractChecked(((BinaryExpression) expression).Left.Transform(transformExpression), ((BinaryExpression) expression).Right.Transform(transformExpression), ((BinaryExpression) expression).Method);
          break;
        case ExpressionType.TypeAs:
          expression = (Expression) Expression.TypeAs(((UnaryExpression) expression).Operand.Transform(transformExpression), expression.Type);
          break;
        case ExpressionType.TypeIs:
          expression = (Expression) Expression.TypeIs(((TypeBinaryExpression) expression).Expression.Transform(transformExpression), ((TypeBinaryExpression) expression).TypeOperand);
          break;
      }
      return expression;
    }

    public static MemberBinding Transform(
      this MemberBinding binding,
      Func<Expression, Expression> transformExpression)
    {
      if (binding == null)
        return (MemberBinding) null;
      switch (binding.BindingType)
      {
        case MemberBindingType.Assignment:
          return (MemberBinding) Expression.Bind(binding.Member, ((MemberAssignment) binding).Expression.Transform(transformExpression));
        case MemberBindingType.MemberBinding:
          return (MemberBinding) Expression.MemberBind(binding.Member, ((MemberMemberBinding) binding).Bindings.Select<MemberBinding, MemberBinding>((Func<MemberBinding, MemberBinding>) (b => b.Transform(transformExpression))));
        case MemberBindingType.ListBinding:
          return (MemberBinding) Expression.ListBind(binding.Member, ((MemberListBinding) binding).Initializers.Select<ElementInit, ElementInit>((Func<ElementInit, ElementInit>) (i => i.Transform(transformExpression))));
        default:
          return (MemberBinding) null;
      }
    }

    public static ElementInit Transform(
      this ElementInit elementInit,
      Func<Expression, Expression> transformExpression)
    {
      return elementInit == null ? (ElementInit) null : Expression.ElementInit(elementInit.AddMethod, elementInit.Arguments.Select<Expression, Expression>((Func<Expression, Expression>) (a => a.Transform(transformExpression))));
    }

    public static IEnumerable<T> Distinct<T>(
      this IEnumerable<T> list,
      Func<T, T, bool> comparisonExpression)
    {
      return list.Distinct<T>((IEqualityComparer<T>) new LambdaEqualityComparer<T>(comparisonExpression));
    }

    public static TResult Rollup<TItem, TResult>(
      this IEnumerable<TItem> list,
      Func<TItem, TResult> selector)
    {
      return list.Rollup<TItem, TResult>(selector, default (TResult));
    }

    public static TResult Rollup<TItem, TResult>(
      this IEnumerable<TItem> list,
      Func<TItem, TResult> selector,
      TResult conflictValue)
    {
      if (list == null)
        return conflictValue;
      TItem obj1 = list.FirstOrDefault<TItem>();
      if ((object) obj1 == null)
        return conflictValue;
      TResult result1 = selector(obj1);
      if ((object) result1 == null)
        return conflictValue;
      foreach (TItem obj2 in list)
      {
        TResult result2 = selector(obj2);
        if (!result1.Equals((object) result2))
          return conflictValue;
      }
      return result1;
    }

    public static IOrderedQueryable<TEntity> OrderBy<TEntity>(
      this IQueryable<TEntity> source,
      string fieldName,
      SortOrder sortOrder)
      where TEntity : class
    {
      switch (sortOrder)
      {
        case SortOrder.Ascending:
          return source.OrderUsingSortExpression<TEntity>(fieldName + " ASC");
        case SortOrder.Descending:
          return source.OrderUsingSortExpression<TEntity>(fieldName + " DESC");
        default:
          return source.OrderUsingSortExpression<TEntity>(fieldName);
      }
    }
  }
}
