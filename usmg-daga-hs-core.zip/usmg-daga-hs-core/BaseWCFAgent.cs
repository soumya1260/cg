﻿// Decompiled with JetBrains decompiler
// Type: HS.BaseWCFAgent`1
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Security;
using System.Text;

namespace HS
{
  public abstract class BaseWCFAgent<T> : IDisposable
  {
    protected ChannelFactory<T> _channelFactory;

    public abstract T GetServiceChannel();

    protected T GetServiceChannel(Binding binding, string svcEndpointURI)
    {
      Uri uri = new Uri(svcEndpointURI);
      this._channelFactory = new ChannelFactory<T>(binding, uri.ToString());
      T channel = this._channelFactory.CreateChannel();
      this._channelFactory.Faulted += new EventHandler(this._channelFactory_Faulted);
      return channel;
    }

    protected static Binding GetBinding(SvcBindingType bindingType)
    {
      switch (bindingType)
      {
        case SvcBindingType.Http:
          return BaseWCFAgent<T>.GetBasicHttpBinding();
        case SvcBindingType.NetTcp:
          return BaseWCFAgent<T>.GetNetTcpBinding();
        default:
          return BaseWCFAgent<T>.GetBasicHttpBinding();
      }
    }

    private static Binding GetBasicHttpBinding()
    {
      BasicHttpBinding basicHttpBinding = new BasicHttpBinding();
      basicHttpBinding.Name = "BasicHttpBinding";
      basicHttpBinding.CloseTimeout = TimeSpan.FromMinutes(1.0);
      basicHttpBinding.OpenTimeout = TimeSpan.FromMinutes(1.0);
      basicHttpBinding.ReceiveTimeout = TimeSpan.FromMinutes(10.0);
      basicHttpBinding.SendTimeout = TimeSpan.FromMinutes(1.0);
      basicHttpBinding.AllowCookies = false;
      basicHttpBinding.BypassProxyOnLocal = false;
      basicHttpBinding.HostNameComparisonMode = HostNameComparisonMode.StrongWildcard;
      basicHttpBinding.MaxBufferSize = 65536;
      basicHttpBinding.MaxBufferPoolSize = 524288L;
      basicHttpBinding.MaxReceivedMessageSize = 65536L;
      basicHttpBinding.MessageEncoding = WSMessageEncoding.Text;
      basicHttpBinding.TextEncoding = Encoding.UTF8;
      basicHttpBinding.TransferMode = TransferMode.Buffered;
      basicHttpBinding.UseDefaultWebProxy = true;
      basicHttpBinding.Security.Mode = BasicHttpSecurityMode.None;
      basicHttpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
      basicHttpBinding.Security.Transport.ProxyCredentialType = HttpProxyCredentialType.None;
      basicHttpBinding.Security.Transport.Realm = "";
      basicHttpBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.UserName;
      basicHttpBinding.Security.Message.AlgorithmSuite = SecurityAlgorithmSuite.Default;
      return (Binding) basicHttpBinding;
    }

    private static Binding GetNetTcpBinding()
    {
      NetTcpBinding netTcpBinding = new NetTcpBinding();
      netTcpBinding.Name = "NetTcpBinding";
      netTcpBinding.CloseTimeout = TimeSpan.FromMinutes(1.0);
      netTcpBinding.OpenTimeout = TimeSpan.FromMinutes(1.0);
      netTcpBinding.ReceiveTimeout = TimeSpan.FromMinutes(10.0);
      netTcpBinding.SendTimeout = TimeSpan.FromMinutes(1.0);
      netTcpBinding.HostNameComparisonMode = HostNameComparisonMode.StrongWildcard;
      netTcpBinding.MaxBufferSize = int.MaxValue;
      netTcpBinding.MaxBufferPoolSize = 52428L;
      netTcpBinding.MaxConnections = 10;
      netTcpBinding.MaxReceivedMessageSize = 65536L;
      netTcpBinding.TransferMode = TransferMode.Buffered;
      netTcpBinding.Security.Mode = SecurityMode.None;
      netTcpBinding.TransactionFlow = false;
      netTcpBinding.ListenBacklog = 10;
      return (Binding) netTcpBinding;
    }

    public void _channelFactory_Faulted(object sender, EventArgs e) => this.Abort();

    public void Abort()
    {
      this._channelFactory.Abort();
      this._channelFactory = (ChannelFactory<T>) null;
    }

    public void Dispose()
    {
      try
      {
        if (this._channelFactory == null)
          return;
        if (this._channelFactory.State == CommunicationState.Faulted)
          this._channelFactory.Abort();
        try
        {
          if (this._channelFactory.State == CommunicationState.Opened)
            this._channelFactory.Close();
        }
        catch
        {
          this._channelFactory.Abort();
        }
        this._channelFactory = (ChannelFactory<T>) null;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }
  }
}
