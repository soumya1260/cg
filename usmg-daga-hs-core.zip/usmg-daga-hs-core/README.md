# daga-hs-core

Repository for HS.Core 3.5.1

If you are looking for the source code HS.Core 4.x or later, please see the [daga-hs-framework](https://github.sys.cigna.com/cigna/daga-hs-framework) repository.
