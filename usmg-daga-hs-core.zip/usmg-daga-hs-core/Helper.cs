﻿// Decompiled with JetBrains decompiler
// Type: HS.Helper
// Assembly: HS.Core, Version=3.5.1.0, Culture=neutral, PublicKeyToken=null
// MVID: F9E3D429-C6FB-4A0A-8C72-C8CF67D0BFC3
// Assembly location: C:\Users\C67362\AppData\Local\Temp\1\Xosapoc\dd750fee3d\lib\net35\HS.Core.dll

using System.Text.RegularExpressions;

namespace HS
{
  public static class Helper
  {
    public static bool CheckPasswordIsValid(string Password)
    {
      if (Password == null)
        return false;
      bool success = Regex.Match(Password, "(^(?=.*[A-Z]+)(?=.*[a-z]+)(?=.*[0-9]+).*$)|(^(?=.*[A-Z]+)(?=.*[a-z]+)(?=.*\\W+).*$)").Success;
      return Password.Length >= 7 && Password.Length <= 100 && success;
    }
  }
}
