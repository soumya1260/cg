
[//]: # (Badge gobbledegook.  Skip this and look for the GOOD STUFF below.)

[![Build Status](https://w2-jenkins.sys.cigna.com/job/HEALTHSPRING/job/CHSDEVOPS/job/GBS-DigitalApps/job/VLR-Build/badge/icon)](https://w2-jenkins.sys.cigna.com/job/HEALTHSPRING/job/CHSDEVOPS/job/GBS-DigitalApps/job/VLR-Build/) [![Quality Gate Status](https://sonarqube.sys.cigna.com/api/project_badges/measure?project=com.cigna.CHS.InternalTools.ValidateLocalizationResources&metric=alert_status&token=sqb_2a130f79c744262087d3923dc4ce3d241b4d7082)](https://sonarqube.sys.cigna.com/dashboard?id=com.cigna.CHS.InternalTools.ValidateLocalizationResources)

[//]: # (GOOD STUFF starts here!)

# VLR (Validate Localization Resources)
VLR is a tool that keeps your localization string resources consistent across all of your
localization files.  It automatically creates entries from your culture-invariant file and 
provides warnings when localized resource files contain entries not found in the culture-invariant file.
It also provides a test culture (defaulting to Inuktitut) that can be helpful for identifying 
non-globalized strings.

See the [manual](ValidateLocalizationResources/ValidateLocalizationResources-Manual.docx "VLR Manual")
for a full description of how to use the tool and integrate it with
Visual Studio.

## Contributing

Please read [CONTRIBUTING.md](.github/CONTRIBUTING.md) for details on our code of conduct, and the process for submitting pull requests to us.

## Code Owners

Please read [CODEOWNERS](.github/CODEOWNERS) for details on the code owners of our repo

## Acknowledgments

* Based on an idea proposed by Karson Alford while at Jack Henry & Assoc.
