﻿using System.Reflection;

[assembly: AssemblyVersion("2023.1.0.0")]
[assembly: AssemblyFileVersion("2023.1.0.0")]
