﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Resources;
using System.Text.RegularExpressions;

namespace ValidateLocalizationResources
{
    public class ValidationResourceFiles
    {
        //
        // Comment tokens
        //
        private const string NoPrefixToken = "VLR_noprefix";

        private const string TestValueToken = "VLR_value";
        private const string BlanksOkayToken = "VLR_blank";

        //
        // Other constants
        //
        private const string DefaultTestResourceIndicator = "^";

        private const string NeedsLocalizationToken = "???";
        private const string TestCulture = "iu";

        private const string CaptureGroupToken = "token";
        private const string WarningToken = "warning";
        private const string MessageToken = "message";

        /// <summary>
        /// List of invariant culture files.
        /// </summary>
        private List<FileInfo> CultureInvariantResourceFiles { get; }

        /// <summary>
        /// List of resource files localized to specific (non-test) cultures.
        /// </summary>
        private List<FileInfo> LocalizableResourceFiles { get; }

        //
        // Regular expressions used to categorize files.
        //
        private static readonly Regex InvariantFileRegex = new Regex(@"^[^.]*\.resx$", RegexOptions.Compiled);

        private static readonly Regex LocalizableFileRegex = new Regex(@"^[^.]*\.[^.]*\.resx$", RegexOptions.Compiled);

        //
        // Other regular expressions that should be compiled once.
        //
        private readonly Regex _testFileRegex;

        private readonly Regex _testValueRegex;
        private readonly string _testResourceIndicator;

        //
        // Other private member variables.
        //
        private readonly string _testFileCulture;

        /// <summary>
        /// Default constructor (with overload)
        /// </summary>
        /// <param name="testFileCulture"></param>
        public ValidationResourceFiles(string testFileCulture = TestCulture)
        {
            _testFileRegex = new Regex($@".*\.{testFileCulture}\.resx$", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            _testValueRegex = new Regex($@"{TestValueToken}=""(?<{CaptureGroupToken}>.*)""", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            _testFileCulture = testFileCulture;
            _testResourceIndicator = DefaultTestResourceIndicator;

            CultureInvariantResourceFiles = new List<FileInfo>();
            LocalizableResourceFiles = new List<FileInfo>();
        }

        /// <summary>
        /// Populates the three file lists from the given folder, optionally recursing the file tree.
        /// </summary>
        /// <param name="folder">Full or relative path potentially containing resource files.</param>
        /// <param name="recurseFolders">Indicates whether the entire tree should be examined.</param>
        public void GetResourceFiles(string folder, bool recurseFolders)
        {
            List<FileInfo> files = Directory.GetFiles(folder, "*.resx").Select(file => new FileInfo(file)).ToList();

            if (files.Any())
            {
                CultureInvariantResourceFiles.AddRange(files.Where(file => InvariantFileRegex.Match(file.Name).Success));
                LocalizableResourceFiles.AddRange(files
                    .Where(file => LocalizableFileRegex.Match(file.Name).Success && !_testFileRegex.Match(file.Name).Success));
            }

            if (recurseFolders)
            {
                foreach (string directory in Directory.GetDirectories(folder))
                {
                    GetResourceFiles(directory, true);
                }
            }
        }

        /// <summary>
        /// Generates a test resource file for each invariant resource.
        /// </summary>
        public void GenerateTestResources()
        {
            foreach (FileInfo resourceFile in CultureInvariantResourceFiles)
            {
                string fileNameStub = resourceFile.Name.Substring(0, resourceFile.Name.LastIndexOf('.'));
                string testFileName = $@"{resourceFile.Directory}\{fileNameStub}.{_testFileCulture}.resx";
                GenerateTestResourceFromCultureInvariantResource(resourceFile.ToString(), testFileName);
            }
        }

        /// <summary>
        /// Given a culture-invariant resource, this method generates a test resource.
        /// </summary>
        /// <param name="cultureInvariantResourceFileName"></param>
        /// <param name="testResourceFileName"></param>
        private void GenerateTestResourceFromCultureInvariantResource(
            string cultureInvariantResourceFileName,
            string testResourceFileName)
        {
            UnlockFile(testResourceFileName);

            ResXResourceReader reader = new ResXResourceReader(cultureInvariantResourceFileName) { UseResXDataNodes = true };
            ResXResourceWriter resourceWriter = new ResXResourceWriter(testResourceFileName);

            IDictionaryEnumerator enumerator = reader.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ResXDataNode node = (ResXDataNode)enumerator.Value;
                if (node.FileRef != null)
                {
                    continue;
                }

                string name = node.Name;
                object value = node.GetValue((ITypeResolutionService)null);
                string comment = node.Comment;

                if (value is string stringValue)
                {
                    //
                    // Add test file indicator to the string as long as the "Don't Prefix" token
                    // isn't present in the comment.
                    //
                    if (!comment.Contains(NoPrefixToken))
                    {
                        value = $"{_testResourceIndicator}{stringValue}";
                    }

                    //
                    // If the comment contains VLR_Value="xxx", then we replace the string's
                    // value with xxx.
                    //
                    Match match = _testValueRegex.Match(comment);
                    if (match.Success && match.Groups.Count > 0)
                    {
                        value = match.Groups[CaptureGroupToken].Value;
                    }
                }

                //
                // Write in the same order as the items were read to preserve order for
                // source control and comparisons.
                //
                ResXDataNode testNode = new ResXDataNode(name, value) { Comment = comment };
                resourceWriter.AddResource(testNode);
            }
            reader.Close();

            resourceWriter.Generate();
            resourceWriter.Close();
        }

        /// <summary>
        /// Validates all of the localized resource files to make sure they contain all the same
        /// resource keys as the associated invariant resource.
        /// </summary>
        public void ValidateLocalizedResources()
        {
            foreach (FileInfo cultureInvariantResource in CultureInvariantResourceFiles)
            {
                Hashtable cultureInvariantEntries = ReadResource(cultureInvariantResource.ToString());

                //
                // Look for localized resources that would be associated with the
                // culture-invariant resource.
                //
                string fileSearchStub = cultureInvariantResource
                    .ToString()
                    .Substring(0, cultureInvariantResource.ToString().LastIndexOf(".", StringComparison.Ordinal))
                    .Replace(@"\", @"\\") // Escape any backslashes so they are not interpreted as escapes in the regex
                    .Replace(".", @"\."); // Escape any periods so they are not interpreted as wildcards in the regex

                //
                // Build up a regex that looks like "c:\\blah\\Resources\.[a-z0-9]{1,2}(?:-[a-z0-9]{1,2}){0,1}\.resx"
                //
                // This will find files that look like any of the following:
                //   * c:\blah\Resources.es.resx
                //   * c:\blah\Resources.US.resx
                //   * c:\blan\Resources.es-US.resx
                //
                // It will ignore files that look like:
                //   * c:\blah\Resources.resx
                //   * c:\blah\Resources.pizza.resx
                //
                Regex regex = new Regex(
                    $@"^{fileSearchStub}\.[a-z0-9]{{1,2}}(?:-[a-z0-9]{{1,2}}){{0,1}}\.resx",
                    RegexOptions.Compiled | RegexOptions.IgnoreCase);

                foreach (FileInfo localizedResource in LocalizableResourceFiles)
                {
                    if (!regex.Match(localizedResource.ToString()).Success)
                    {
                        continue;
                    }

                    Hashtable localizedEntries = ReadResource(localizedResource.ToString());
                    Hashtable missing = FindMissingEntries(cultureInvariantEntries, localizedEntries);
                    List<string> extraneous = FindExtraneousEntries(localizedEntries, cultureInvariantEntries);
                    List<string> blank = FindBlankEntries(localizedEntries);
                    List<string> unlocalized = FindUnlocalizedEntries(localizedEntries);

                    if (missing.Count > 0)
                    {
                        AddMissingLocalizationValues(localizedResource.ToString(), missing);
                    }

                    //
                    // Show warnings.  (Formatted for the Visual Studio Error List)
                    //
                    DisplayExtraneousEntryWarnings(extraneous, localizedResource);
                    DisplayBlankEntryWarnings(blank, localizedResource);
                    DisplayUnlocalizedEntryWarnings(unlocalized, localizedResource);
                }
            }
        }

#pragma warning disable S2228 // These are not log messages.  They are console interactions with Visual Studio.

        private static void DisplayUnlocalizedEntryWarnings(List<string> unlocalized, FileInfo localizedResource)
        {
            if (unlocalized.Any())
            {
                foreach (string item in unlocalized)
                {
                    Console.WriteLine($"{localizedResource} : {WarningToken} VLR0004: {item} has not been localized.");
                }
            }
        }

        private static void DisplayBlankEntryWarnings(List<string> blank, FileInfo localizedResource)
        {
            if (blank.Any())
            {
                foreach (string item in blank)
                {
                    Console.WriteLine($"{localizedResource} : {WarningToken} VLR0003: {item} is blank.");
                }
            }
        }

        private static void DisplayExtraneousEntryWarnings(List<string> extraneous, FileInfo localizedResource)
        {
            if (extraneous.Any())
            {
                foreach (string item in extraneous)
                {
                    Console.WriteLine(
                        $"{localizedResource} : {WarningToken} VLR0002: Element {item} found that is not also in the culture-invariant resource file.");
                }
            }
        }

#pragma warning restore S2228

        private Hashtable ReadResource(string resourceFilePath)
        {
            Hashtable entries = new Hashtable();
            ResXResourceReader reader = new ResXResourceReader(resourceFilePath) { UseResXDataNodes = true };

            IDictionaryEnumerator enumerator = reader.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ResXDataNode node = (ResXDataNode)enumerator.Value;
                if (node.FileRef != null) continue;

                entries.Add(node.Name, node);
            }
            reader.Close();

            return entries;
        }

        private Hashtable FindMissingEntries(Hashtable cultureInvariantEntries, Hashtable localizedEntries)
        {
            Hashtable missing = new Hashtable();

            foreach (ResXDataNode node in cultureInvariantEntries.Values)
            {
                if (node.FileRef != null) continue;

                if (!localizedEntries.ContainsKey(node.Name))
                {
                    missing.Add(node.Name, node);
                }
            }

            return missing;
        }

        private List<string> FindExtraneousEntries(Hashtable source, Hashtable entriesToCompare)
        {
            //
            // Look for items that are missing from the entries to compare.
            //
            return source.Keys
                .Cast<string>()
                .Where(key => !entriesToCompare.ContainsKey(key))
                .ToList();
        }

        private void AddMissingLocalizationValues(string localizedResourceFile, Hashtable missing)
        {
            UnlockFile(localizedResourceFile);

            ResXResourceReader reader = new ResXResourceReader(localizedResourceFile) { UseResXDataNodes = true };
            ResXResourceWriter writer = new ResXResourceWriter(localizedResourceFile);

            //
            // Double-check hash to make sure we don't add a duplicate entry.
            //
            Hashtable foundEntries = new Hashtable();

            //
            // First we write all the existing values -- resource files can't be edited.
            // I think this is due to generation of designer files.  So we read and write at
            // the same time in order to preserve the order for source control.
            //
            IDictionaryEnumerator enumerator = reader.GetEnumerator();
            while (enumerator.MoveNext())
            {
                ResXDataNode node = (ResXDataNode)enumerator.Value;
                if (node.FileRef != null) continue;

                foundEntries.Add(node.Name, node);
                writer.AddResource(node);
            }
            reader.Close();

            //
            // Now add the missing items.
            //
            foreach (ResXDataNode node in missing.Values)
            {
                if (!foundEntries.ContainsKey(node.Name))
                {
                    if (node.FileRef != null) continue;

                    string name = node.Name;
                    object value = node.GetValue((ITypeResolutionService)null);
                    string comment = node.Comment;

                    //
                    // Add unlocalized indicator to string as long as the "Don't Prefix" token
                    // isn't present in the comment.
                    //
                    if (value is string valueName && !comment.Contains(NoPrefixToken))
                    {
                        value = $"{NeedsLocalizationToken}{valueName}";
                    }

#pragma warning disable S2228 // This is a console interaction with Visual Studio.
                    Console.WriteLine($"{localizedResourceFile} : {MessageToken} VLR0001: Adding missing localization element {name}.");
#pragma warning restore S2228

                    //
                    // Write in the same order as the items were read to preserve order for
                    // source control and comparisons.
                    //
                    ResXDataNode newNode = new ResXDataNode(name, value) { Comment = comment };
                    writer.AddResource(newNode);
                }
            }
            writer.Generate();
            writer.Close();
        }

        private List<string> FindUnlocalizedEntries(Hashtable localizedEntries)
        {
            List<string> unlocalized = new List<string>();
            foreach (ResXDataNode entry in localizedEntries.Values)
            {
                if (entry.FileRef != null) continue;

                if (entry.GetValue((ITypeResolutionService)null) is string value && value.StartsWith(NeedsLocalizationToken))
                {
                    unlocalized.Add(entry.Name);
                }
            }

            return unlocalized;
        }

        private List<string> FindBlankEntries(Hashtable entries)
        {
            List<string> blankEntries = new List<string>();

            foreach (ResXDataNode entry in entries.Values)
            {
                if (entry.FileRef != null) continue;

                string value = entry.GetValue((ITypeResolutionService)null) as string;
                if (string.IsNullOrWhiteSpace(value) && !entry.Comment.Contains(BlanksOkayToken))
                {
                    blankEntries.Add(entry.Name);
                }
            }

            return blankEntries;
        }

        private void UnlockFile(string fileName)
        {
            //
            // Sometimes version control sets the read-only attribute on files that are not
            // checked out. This block checks for read-only files and resets the attribute
            // so that the file can be over-written.
            //
            if (File.Exists(fileName))
            {
                FileInfo file = new FileInfo(fileName);
                if (file.IsReadOnly)
                {
                    File.SetAttributes(fileName, File.GetAttributes(fileName) ^ FileAttributes.ReadOnly);
                }
            }
        }
    }
}