﻿using System;
using System.IO;
using System.Reflection;

namespace ValidateLocalizationResources
{
    public static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            var startFolder = string.Empty;
            if (args.Length > 0)
            {
                startFolder = args[0];
            }

            //
            // Get a list of all resource files
            //
            string topFolder = string.IsNullOrEmpty(startFolder)
                ? Path.GetDirectoryName(Assembly.GetEntryAssembly().Location)
                : startFolder;

            var files = new ValidationResourceFiles();
            files.GetResourceFiles(topFolder, true);

            files.GenerateTestResources();
            files.ValidateLocalizedResources();

            //
            // Always return zero.  The Console messages will flag as errors, if necessary, in Visual Studio.
            //
            return 0;
        }
    }
}