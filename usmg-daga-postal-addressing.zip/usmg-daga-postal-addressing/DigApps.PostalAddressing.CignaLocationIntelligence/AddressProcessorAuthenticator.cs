﻿using System.Threading.Tasks;
using DigApps.PostalAddressing.CignaLocationIntelligence.OAuth2DataTransferObjects;
using RestSharp;
using RestSharp.Authenticators;

namespace DigApps.PostalAddressing.CignaLocationIntelligence
{
    public class AddressProcessorAuthenticator : AuthenticatorBase
    {
        private readonly string _baseUrl;
        private readonly string _clientId;
        private readonly string _clientSecret;

        public AddressProcessorAuthenticator(
            string baseUrl,
            string clientId,
            string clientSecret) : base(string.Empty)
        {
            _baseUrl = baseUrl;
            _clientId = clientId;
            _clientSecret = clientSecret;
        }

        protected override async ValueTask<Parameter> GetAuthenticationParameter(
            string accessToken)
        {
            Token = string.IsNullOrEmpty(Token)
                ? await GetToken()
                : Token;

            return new HeaderParameter(KnownHeaders.Authorization, Token);
        }

        private async Task<string> GetToken()
        {
            var options = new RestClientOptions(_baseUrl)
            {
                Authenticator = new HttpBasicAuthenticator(
                    _clientId,
                    _clientSecret),
            };

            using (var client = new RestClient(options))
            {
                var request = new RestRequest("oauth2/token")
                    .AddParameter("grant_type", "client_credentials");
                var response = await client.PostAsync<TokenResponse>(request);
                return $"{response.TokenType} {response.AccessToken}";
            }
        }
    }
}