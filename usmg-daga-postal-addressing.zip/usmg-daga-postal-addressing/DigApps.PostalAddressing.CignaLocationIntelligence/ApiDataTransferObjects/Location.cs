﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// The location request object consists of the data fields that to be given
    /// in classification to receive the appropriate response.It will hold the
    /// information of the address object, position(latitude and longitude),
    /// provider organization type, FIPS codes, CBSA codes, location type,
    /// status and so on
    /// </summary>
    public class Location
    {
        /// <summary>
        /// Unique resource ID generated for each location
        /// </summary>
        [JsonPropertyName("resourceID")] public string ResourceId { get; set; }

        /// <summary>
        /// HTTP response code
        /// </summary>
        [JsonPropertyName("status")] public string Status { get; set; }

        /// <summary>
        /// This field is never populated
        /// </summary>
        [JsonPropertyName("name")] public string Name { get; set; }

        /// <summary>
        /// This field is never populated
        /// </summary>
        [JsonPropertyName("alias")] public string Alias { get; set; }

        /// <summary>
        /// This field is never populated
        /// </summary>
        [JsonPropertyName("locationType")] public string LocationType { get; set; }

        [JsonPropertyName("address")] public Address Address { get; set; }
        [JsonPropertyName("position")] public Position Position { get; set; }
        [JsonPropertyName("cbsaCodes")] public CbsaCode CbsaCodes { get; set; }
        [JsonPropertyName("fipsCodes")] public FipsCode FipsCodes { get; set; }

        /// <summary>
        /// In health insurance in the United States, a preferred provider
        /// organization (PPO), sometimes referred to as a participating
        /// provider organization or preferred provider option, is a managed
        /// care organization of medical doctors, hospitals, and other health
        /// care providers who have agreed with an insurer or a third-party
        /// administrator to provide health care
        /// </summary>
        [JsonPropertyName("providerOrganization")] public List<string> ProviderOrganization { get; set; }
        
        [JsonPropertyName("json"), Obsolete]
        public GeoJsonPoint AlternativeGeolocationData { get; set; }

        [JsonPropertyName("storeKeySet"), Obsolete]
        public StoreKeySet StoreKeySet { get; set; }

        /// <summary>
        /// DEPRECATED.  Open or closed based on expiration date.
        /// </summary>
        [JsonPropertyName("availability"), Obsolete]
        public string Availability { get; set; }
    }
}