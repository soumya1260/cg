﻿// ReSharper disable InconsistentNaming

using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// Contains the state FIPS code and name
    /// </summary>
    public class State
    {
        /// <summary>
        /// The two-character state abbreviation
        /// </summary>
        [JsonPropertyName("code")] public string Abbreviation { get; set; }

        /// <summary>
        /// The full name of the state
        /// </summary>
        [JsonPropertyName("name")] public string Name { get; set; }

        /// <summary>
        /// The two-digit FIPS state code
        /// </summary>
        [JsonPropertyName("numericalCode")] public string FipsCode { get; set; }

        public State() { }

        public State(string abbreviation)
        {
            Name = string.Empty;
            Abbreviation = abbreviation;
            FipsCode = string.Empty;
        }
    }
}