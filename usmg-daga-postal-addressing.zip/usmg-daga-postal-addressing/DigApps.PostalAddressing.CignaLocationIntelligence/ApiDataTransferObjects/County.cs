﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// Contains the county code, name and FIPS code information
    /// </summary>
    public class County
    {
        /// <summary>
        /// The three-digit FIPS county code
        /// </summary>
        [JsonPropertyName("code")] public string FipsCode { get; set; }

        /// <summary>
        /// The name of the county
        /// </summary>
        [JsonPropertyName("name")] public string Name { get; set; }

        /// <summary>
        /// The county FIPS code is a combination of the two-digit state code
        /// and the three-digit county code.
        /// </summary>
        [JsonPropertyName("fipsCode")] public string FipsCodeWithState { get; set; }
    }
}