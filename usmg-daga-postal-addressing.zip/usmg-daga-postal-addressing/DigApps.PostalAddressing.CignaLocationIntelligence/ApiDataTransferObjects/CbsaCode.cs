﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// A core-based statistical area is a U.S.geographic area defined by the
    /// Office of Management and Budget that consists of one or more counties
    /// anchored by an urban center of at least 10,000 people plus adjacent
    /// counties that are socioeconomically tied to the urban center by
    /// commuting.
    /// </summary>
    public class CbsaCode
    {
        /// <summary>
        /// The name of the Census Core-Based Statistical Area (CBSA)
        /// </summary>
        [JsonPropertyName("name")] public string Name { get; set; }

        /// <summary>
        /// The code value of the Census Core-Based Statistical Area (CBSA)
        /// </summary>
        [JsonPropertyName("code")] public string Code { get; set; }

        /// <summary>
        /// The division name of the Census Core-Based Statistical Area (CBSA)
        /// </summary>
        [JsonPropertyName("divisionName")] public string DivisionName { get; set; }

        /// <summary>
        /// The division code of the Census Core-Based Statistical Area (CBSA)
        /// </summary>
        [JsonPropertyName("divisionCode")] public string DivisionCode { get; set; }

        /// <summary>
        /// Signifies if the sus Core-Based Statistical Area is a metropolitan
        /// area or not
        /// </summary>
        /// <example>"Y"</example>
        [JsonPropertyName("metro")] public string Metro { get; set; }
    }
}