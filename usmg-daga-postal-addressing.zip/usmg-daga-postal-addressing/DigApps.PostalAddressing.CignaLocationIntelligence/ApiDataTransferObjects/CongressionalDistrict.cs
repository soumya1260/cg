﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// Contains the congressional district code
    /// </summary>
    public class CongressionalDistrict
    {
        /// <summary>
        /// The congressional district code
        /// </summary>
        [JsonPropertyName("code")] public string Code { get; set; }
    }
}