using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    public class ValidatePostalAddressesResponse
    {
        [JsonPropertyName("postalAddresses")] public List<ValidatedPostalAddress> PostalAddresses { get; set; }
    }
}