﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// This object contains information concerning the ability to deliver mail
    /// to the associated address.
    /// </summary>
    public class DeliveryPoint
    {
        /// <summary>
        /// Eleven digits with an additional check digit (12 digits total) that
        /// narrows the destination down to the delivery point. The barcode
        /// number is a value that can change over time, and should not be used
        /// as a unique identifier for an address.
        /// </summary>
        [JsonPropertyName("barcodeNumber")] public string BarcodeNumber { get; set; }

        [JsonPropertyName("confirmationInfo")] public ConfirmationInformation ConfirmationInfo { get; set; }
    }
}