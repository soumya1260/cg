﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// The address request object consists of the data fields related to
    /// physical address
    /// </summary>
    public class Address
    {
        /// <summary>
        /// Unique resource ID generated for each address
        /// </summary>
        [JsonPropertyName("relativeId")] public string RelativeId { get; set; }

        /// <summary>
        /// The street address
        /// </summary>
        [JsonPropertyName("streetAddress")] public string StreetAddress { get; set; }

        /// <summary>
        /// County
        /// </summary>
        [JsonPropertyName("county")] public string County { get; set; }

        /// <summary>
        /// City
        /// </summary>
        [JsonPropertyName("city")] public string City { get; set; }

        /// <summary>
        /// Postal code
        /// </summary>
        [JsonPropertyName("postalCode")] public string PostalCode { get; set; }

        /// <summary>
        /// State abbreviation
        /// </summary>
        [JsonPropertyName("state")] public string State { get; set; }

        /// <summary>
        /// Country
        /// </summary>
        [JsonPropertyName("country")] public string Country { get; set; }

        /// <summary>
        /// Apartment number
        /// </summary>
        [JsonPropertyName("apartmentNumber")] public string ApartmentNumber { get; set; }

        /// <summary>
        /// Suite number
        /// </summary>
        [JsonPropertyName("suiteNumber")] public string SuiteNumber { get; set; }
    }
}