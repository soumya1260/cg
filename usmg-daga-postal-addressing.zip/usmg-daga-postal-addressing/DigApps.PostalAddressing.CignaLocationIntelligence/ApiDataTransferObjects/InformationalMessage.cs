﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// Contains a code and message about an information message to the API consumer
    /// </summary>
    public class InformationalMessage
    {
        /// <summary>
        /// A code indicating the error
        /// </summary>
        [JsonPropertyName("code")] public string Code { get; set; }

        /// <summary>
        /// A message providing a description of the problem
        /// </summary>
        [JsonPropertyName("message")] public string Message { get; set; }
    }
}