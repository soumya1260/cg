﻿using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using DigApps.PostalAddressing.Abstractions.DomainObjects;

// ReSharper disable InconsistentNaming

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    public class PostalAddress
    {
        [JsonPropertyName("addressRequestMatchingId")] public int AddressRequestMatchingId { get; set; }

        [JsonPropertyName("streetAddress")] public List<string> StreetAddresses { get; set; }

        [JsonPropertyName("city")] public string City { get; set; }

        [JsonPropertyName("stateCode")] public string StateCode { get; set; }

        [JsonPropertyName("postalCode")] public string PostalCode { get; set; }

        /// <summary>
        /// Maps a VerifyAddressRequest object into the current one.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="matchingId">
        ///     Optional matching ID - only needed when sending more than one
        ///     address in a request.
        /// </param>
        public PostalAddress(
            VerifyAddressRequest request,
            int matchingId = 0)
        {
            AddressRequestMatchingId = matchingId;
            StreetAddresses = request.AddressLines.ToList();
            City = request.City;
            StateCode = request.StateAbbreviation;
            PostalCode = request.PostalCode;
        }
    }
}
