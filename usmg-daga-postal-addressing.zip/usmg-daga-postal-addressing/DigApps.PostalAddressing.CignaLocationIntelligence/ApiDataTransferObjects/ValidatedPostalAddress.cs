﻿using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using DigApps.PostalAddressing.Abstractions.DomainObjects;

// ReSharper disable InconsistentNaming

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{

    public class ValidatedPostalAddress
    {
        /// <summary>
        /// This value is used to identify/match submitted addresses with the
        /// values in the API response
        /// </summary>
        [JsonPropertyName("addressRequestMatchingId")] public int AddressRequestMatchingId { get; set; }

        [JsonPropertyName("streetAddress")] public List<string> StreetAddresses { get; set; }

        /// <summary>
        /// City name
        /// </summary>
        [JsonPropertyName("city")] public string City { get; set; }

        /// <summary>
        /// Contains the state code and name
        /// </summary>
        [JsonPropertyName("state")] public State State { get; set; }

        /// <summary>
        /// Postal code value
        /// </summary>
        [JsonPropertyName("postalCode")] public string PostalCode { get; set; }

        /// <summary>
        /// The number/identifier of the office suite
        /// </summary>
        [JsonPropertyName("officeSuite")] public string OfficeSuite { get; set; }

        /// <summary>
        /// The number/identifier of the apartment
        /// </summary>
        [JsonPropertyName("apartmentNumber")] public string ApartmentNumber { get; set; }

        /// <summary>
        /// The number/identifier of the post office box
        /// </summary>
        [JsonPropertyName("postOfficeBoxNumber")] public string PostOfficeBoxNumber { get; set; }

        /// <summary>
        /// The neighborhood or city subdivision; used with Puerto Rican addresses.
        /// </summary>
        [JsonPropertyName("urbanization")] public string Urbanization { get; set; }

        [JsonPropertyName("county")] public County County { get; set; }

        [JsonPropertyName("congressionalDistrict")] public CongressionalDistrict CongressionalDistrict { get; set; }

        /// <summary>
        /// The type of building this address represents
        /// </summary>
        [JsonPropertyName("addressType")] public string AddressType { get; set; }

        [JsonPropertyName("geoCoordinates")] public GeoCoordinates GeoCoordinates { get; set; }
        [JsonPropertyName("deliveryPoint")] public DeliveryPoint DeliveryPoint { get; set; }

        [JsonPropertyName("validationErrors")] public List<ValidationError> ValidationErrors { get; set; } = new List<ValidationError>();

        [JsonPropertyName("validationInfoMessages")] public List<InformationalMessage> ValidationInfoMessages { get; set; } = new List<InformationalMessage>();

        public VerifiedAddress ConvertToVerifiedAddress()
        {
            var response = new VerifiedAddress
            {
                AddressLines = StreetAddresses,
                City = City,
                StateOrProvince = new PlaceIdentifier
                {
                    Name = State.Name,
                    Abbreviation = State.Abbreviation,
                    PlaceCodes = new List<PlaceCode>{
                        new PlaceCode
                        {
                            Code = State.FipsCode,
                            CodeType = "fips"
                        }
                    }
                },
                PostalCode = PostalCode,
                County = new PlaceIdentifier
                {
                    Abbreviation = string.Empty,
                    Name = County.Name,
                    PlaceCodes = new List<PlaceCode>
                    {
                        new PlaceCode
                        {
                            Code = County.FipsCode,
                            CodeType = "fips-county"
                        },
                        new PlaceCode
                        {
                            Code = County.FipsCodeWithState,
                            CodeType = "fips-county-full"
                        }
                    }
                },
                // no congressional district in abstraction's DTO
                // no address type in abstraction's DTO
                Coordinates = new GeographicCoordinate(
                    GeoCoordinates.Latitude,
                    GeoCoordinates.Longitude),
                Barcoding = new PostalBarcoding
                {
                    BarcodeValue = DeliveryPoint.BarcodeNumber,
                    ConfirmationCode = DeliveryPoint.ConfirmationInfo.Code,
                    ConfirmationMessage = DeliveryPoint.ConfirmationInfo.Description,
                    AddressType = ConvertToAddressType(AddressType)
                }
            };

            if (ValidationInfoMessages.Any())
                response.ValidationMessages = ValidationInfoMessages
                    .Select((message) => new ValidationMessage(
                        message.Code,
                        message.Message))
                    .ToList();

            if (ValidationErrors.Any())
                response.ValidationErrors = ValidationErrors
                    .Select((message) => new ValidationMessage(
                            message.Code,
                            message.Message))
                    .ToList();
            return response;
        }

        private static AddressType ConvertToAddressType(string s)
        {
            switch (s.ToUpper())
            {
                case "A": return Abstractions.DomainObjects.AddressType.Alias;
                case "F": return Abstractions.DomainObjects.AddressType.Firm;
                case "G": return Abstractions.DomainObjects.AddressType.GeneralDelivery;
                case "H": return Abstractions.DomainObjects.AddressType.HighRise;
                case "P": return Abstractions.DomainObjects.AddressType.PostOfficeBox;
                case "R": return Abstractions.DomainObjects.AddressType.RuralRouteOrHighwayContract;
                case "S": return Abstractions.DomainObjects.AddressType.StreetAddress;
                default: return Abstractions.DomainObjects.AddressType.Unknown;
            }
        }
    }
}
