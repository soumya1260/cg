﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// Response object given back to the user which provides geocoded address
    /// information of a given address.
    /// </summary>
    public class LocationResponse
    {
        [JsonPropertyName("message")] public string Message { get; set; }
        [JsonPropertyName("status")] public int Status { get; set; }
        [JsonPropertyName("data")] public List<Location> Data { get; set; }
    }
}
