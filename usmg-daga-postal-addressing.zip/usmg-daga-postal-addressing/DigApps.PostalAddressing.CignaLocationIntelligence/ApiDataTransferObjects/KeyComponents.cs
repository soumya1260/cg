﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// Provides information specific to an individual pharmacy when returning
    /// pharmacy data.
    /// 
    /// EX: Effective/Expiry dates
    /// </summary>
    public class KeyComponents
    {
        [JsonPropertyName("name")] public string Name { get; set; }
        [JsonPropertyName("value")] public string Value { get; set; }
    }
}