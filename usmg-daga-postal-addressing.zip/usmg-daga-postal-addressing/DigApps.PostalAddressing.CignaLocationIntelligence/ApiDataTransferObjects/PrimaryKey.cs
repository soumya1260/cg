﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// Provides store and key names of pharmacy data.
    /// </summary>
    public class PrimaryKey
    {
        [JsonPropertyName("storeName")] public string StoreName { get; set; }
        [JsonPropertyName("keyName")] public string KeyName { get; set; }
        [JsonPropertyName("keyComponents")] public KeyComponents KeyComponents { get; set; }
    }
}