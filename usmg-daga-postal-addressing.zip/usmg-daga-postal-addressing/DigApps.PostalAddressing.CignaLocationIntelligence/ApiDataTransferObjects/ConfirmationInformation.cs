﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// Contains DPV(Delivery Point Validation) information.DPV Codes:
    ///     Y = Primary and (if present) secondary address were confirmed.
    ///     D = Primary address confirmed, secondary address was missing.
    ///     S = Primary address confirmed, secondary address was present but unconfirmed.
    ///     N = Both primary and (if present) secondary address failed DPV confirmation.
    /// </summary>
    public class ConfirmationInformation
    {
        [JsonPropertyName("code")] public string Code { get; set; }
        [JsonPropertyName("description")] public string Description { get; set; }
    }
}