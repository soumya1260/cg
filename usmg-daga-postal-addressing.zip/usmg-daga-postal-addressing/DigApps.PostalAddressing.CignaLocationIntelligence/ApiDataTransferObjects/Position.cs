﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// The position request object holds the data fields latitude and longitude.
    /// </summary>
    public class Position
    {
        [JsonPropertyName("latitude")] public decimal Latitude { get; set; }
        [JsonPropertyName("longitude")] public decimal Longitude { get; set; }
    }
}