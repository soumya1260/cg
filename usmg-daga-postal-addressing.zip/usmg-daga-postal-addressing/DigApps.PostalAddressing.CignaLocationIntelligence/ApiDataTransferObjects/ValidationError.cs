﻿// ReSharper disable InconsistentNaming

using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// Contains a code and message about a validation error to the API consumer
    /// </summary>
    public class ValidationError
    {
        /// <summary>
        /// A code indicating the error
        /// </summary>
        [JsonPropertyName("code")] public string Code { get; set; }

        /// <summary>
        /// A message providing a description of the problem
        /// </summary>
        [JsonPropertyName("message")] public string Message { get; set; }
    }
}
