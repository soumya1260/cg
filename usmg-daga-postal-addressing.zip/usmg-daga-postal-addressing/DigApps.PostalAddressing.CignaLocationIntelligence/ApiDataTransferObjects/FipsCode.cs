﻿using System;
using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// The Federal Information Processing Standard Publication was a five-digit
    /// Federal Information Processing Standards code which uniquely identified
    /// counties and county equivalents in the United States, certain U.S.
    /// possessions, and certain freely associated states.
    /// </summary>
    public class FipsCode
    {
        /// <summary>
        /// The county code is a combination of the two digit state code, and
        /// the three digit county code
        /// </summary>
        [JsonPropertyName("countyCode")] public string CountyCode { get; set; }

        /// <summary>
        /// Two digit state code
        /// </summary>
        [JsonPropertyName("stateCode")] public string StateCode { get; set; }

        /// <summary>
        /// DEPRECATED.  This value is hardcoded to be null.
        /// </summary>
        [JsonPropertyName("censusTractCode"), Obsolete]
        public string CensusTractCode { get; set; }

        /// <summary>
        /// DEPRECATED.  This value is hardcoded to be null.
        /// </summary>
        [JsonPropertyName("blockGroupCode"), Obsolete]
        public string BlockGroupCode { get; set; }

        /// <summary>
        /// DEPRECATED.  This value is hardcoded to be null.
        /// </summary>
        [JsonPropertyName("blockCode"), Obsolete]
        public string BlockCode { get; set; }
    }
}