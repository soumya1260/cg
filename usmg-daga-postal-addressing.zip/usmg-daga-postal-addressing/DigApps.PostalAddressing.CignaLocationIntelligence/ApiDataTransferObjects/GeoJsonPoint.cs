﻿using System;
using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// DEPRECATED.  Json object which holds the information of latitude and
    /// longitude for given location
    /// </summary>
    [Obsolete] public class GeoJsonPoint
    {
        [JsonPropertyName("x")] public decimal X { get; set; }
        [JsonPropertyName("y")] public decimal Y { get; set; }
        [JsonPropertyName("coordinates")] public decimal[] Coordinates { get; set; }
        [JsonPropertyName("type")] public string Type { get; set; }
    }
}