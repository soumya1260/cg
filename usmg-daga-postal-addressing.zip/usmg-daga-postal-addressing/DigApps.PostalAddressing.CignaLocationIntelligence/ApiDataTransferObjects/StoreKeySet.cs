﻿using System;
using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// DEPRECATED.  Contains unique data for a given pharmacy. Ex: PRO_EAGN_ID
    /// </summary>
    [Obsolete] public class StoreKeySet
    {
        [JsonPropertyName("primaryKey"), Obsolete]
        public PrimaryKey PrimaryKey { get; set; }
    }
}