﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

// ReSharper disable InconsistentNaming

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    public class Request
    {
        [JsonPropertyName("postalAddresses")] public List<PostalAddress> PostalAddresses;
    }
}
