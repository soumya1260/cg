﻿using System.Text.Json.Serialization;

namespace DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects
{
    /// <summary>
    /// Contains latitude and longitude values of a geospatial location.
    /// </summary>
    public class GeoCoordinates
    {
        /// <summary>
        /// The latitude value of the geospatial location
        /// </summary>
        [JsonPropertyName("latitude")] public decimal Latitude { get; set; }

        /// <summary>
        /// The longitude of the geospatial location
        /// </summary>
        [JsonPropertyName("longitude")] public decimal Longitude { get; set; }
    }
}