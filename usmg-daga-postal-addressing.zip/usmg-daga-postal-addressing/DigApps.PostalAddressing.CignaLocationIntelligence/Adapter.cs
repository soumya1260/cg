﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DigApps.PostalAddressing.Abstractions;
using DigApps.PostalAddressing.Abstractions.DomainObjects;
using DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects;
using RestSharp;
using PostalAddress = DigApps.PostalAddressing.CignaLocationIntelligence.ApiDataTransferObjects.PostalAddress;

namespace DigApps.PostalAddressing.CignaLocationIntelligence
{
    public class Adapter : Resolver, IDisposable
    {
        private readonly RestClient _client;

        public Adapter(string baseUri, string apiKey, string apiSecret)
        {
            var options = new RestClientOptions(baseUri)
            {
                Authenticator = new AddressProcessorAuthenticator(
                    baseUri,
                    apiKey,
                    apiSecret)
            };

            _client = new RestClient(options);
        }

        #region Verify Address API implementation

        /// <summary>
        /// REST resource location for address validation API
        /// </summary>
        private const string ValidateAddressResource = "/location-intelligence/v1/addresses/$validate";

        public override VerifyAddressResponse VerifyAddress(
            VerifyAddressRequest request) =>
            VerifyAddresses(new List<VerifyAddressRequest> { request });

        public override async Task<VerifyAddressResponse> VerifyAddressAsync(
            VerifyAddressRequest request) =>
            await VerifyAddressesAsync(new List<VerifyAddressRequest> { request });

        public override VerifyAddressResponse VerifyAddresses(
            List<VerifyAddressRequest> requests)
        {
            var restRequest = PrepareVerifyAddressRequest(requests);

            //var status = _client.Post(restRequest);

            var response = _client.Post<ValidatePostalAddressesResponse>(restRequest);

            var result = new VerifyAddressResponse
            {
                Successful = response.PostalAddresses.Any() &&
                             response.PostalAddresses.TrueForAll(address => address.ValidationErrors.Count == 0),
                VerifiedAddresses = ReformatVerifyAddressResponse(response)
            };

            return result;
        }


        public override async Task<VerifyAddressResponse> VerifyAddressesAsync(List<VerifyAddressRequest> requests)
        {
            var restRequest = PrepareVerifyAddressRequest(requests);
            var response = await _client.PostAsync<ValidatePostalAddressesResponse>(restRequest);

            var result = new VerifyAddressResponse
            {
                Successful = response.PostalAddresses.Any() &&
                             response.PostalAddresses.TrueForAll(address => address.ValidationErrors.Count == 0),
                VerifiedAddresses = ReformatVerifyAddressResponse(response)
            };

            return result;
        }

        #region VerifyAddress helpers

        private static List<VerifiedAddress> ReformatVerifyAddressResponse(ValidatePostalAddressesResponse responses)
        {
            return responses.PostalAddresses
                .Select(response => response.ConvertToVerifiedAddress())
                .ToList();
        }

        private static RestRequest PrepareVerifyAddressRequest(List<VerifyAddressRequest> requests)
        {
            var restRequest = new RestRequest(ValidateAddressResource, Method.Post);

            var newRequests = new Request
            {
                PostalAddresses = new List<PostalAddress>()
            };
            int matchingId = 0;
            foreach (var request in requests)
            {
                newRequests.PostalAddresses.Add(new PostalAddress(request, matchingId++));
            }

            restRequest.AddJsonBody(newRequests);
            return restRequest;
        }

        #endregion VerifyAddress helpers

        #endregion Verify Address API implementation

        #region Get Location API implementation

        private const string GetLocationResource = "/v1/locations";

        public override GetLocationResponse GetLocation(GetLocationRequest request)
        {
            var restRequest = PrepareGetLocationRequest(request);

            var status = _client.Post(restRequest);
            var response = _client.Post<LocationResponse>(restRequest);

            return ConvertToGetLocationResponse(response);
        }

        public override async Task<GetLocationResponse> GetLocationAsync(GetLocationRequest request)
        {
            var restRequest = PrepareGetLocationRequest(request);
            var response = await _client.PostAsync<LocationResponse>(restRequest);
            return ConvertToGetLocationResponse(response);
        }

        private GetLocationResponse ConvertToGetLocationResponse(LocationResponse response)
        {
            var result = new GetLocationResponse
            {
                Successful = response.Status == 200,
                Locations = new List<Abstractions.DomainObjects.Location>()
            };

            foreach (var location in response.Data)
            {
                result.Locations.Add(new Abstractions.DomainObjects.Location
                {
                    PostalAddress = new Abstractions.DomainObjects.PostalAddress
                    {
                        AddressLines = new List<string> { location.Address.StreetAddress },
                        City = location.Address.City,
                        StateOrProvince = new PlaceIdentifier
                        {
                            Abbreviation = location.Address.State
                        },
                        PostalCode = location.Address.PostalCode
                    },
                    GeographicCoordinate = new GeographicCoordinate(
                            location.Position.Latitude,
                            location.Position.Longitude)
                });
            }

            return result;
        }

        private static RestRequest PrepareGetLocationRequest(GetLocationRequest request)
        {
            var restRequest = new RestRequest(GetLocationResource, Method.Get);

            restRequest.AddQueryParameter("addressLine1", request.AddressLine1);
            restRequest.AddQueryParameter("city", request.City);
            restRequest.AddQueryParameter("stateProvince", request.StateAbbreviation);
            restRequest.AddQueryParameter("postalCode", request.PostalCode);
            restRequest.AddQueryParameter("include", null);
            restRequest.AddQueryParameter("exclude", null);
            restRequest.AddQueryParameter("expDate", null);
            return restRequest;
        }

        #endregion Get Location API implementation

        #region IDisposable implementation

        public void Dispose()
        {
            _client?.Dispose();
            GC.SuppressFinalize(this);
        }

        #endregion IDisposable implementation
    }
}