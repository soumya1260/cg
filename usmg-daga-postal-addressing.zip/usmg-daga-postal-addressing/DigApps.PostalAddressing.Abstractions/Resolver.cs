﻿using DigApps.PostalAddressing.Abstractions.DomainObjects;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DigApps.PostalAddressing.Abstractions
{
    public abstract class Resolver
    {
        #region Verify Address API

        /// <summary>
        ///     Verifies that the submitted address is valid.
        /// </summary>
        /// <param name="request">The postal address to be validated</param>
        /// <returns>
        ///     Information on the requested address if it is valid; error
        ///     information if it is not
        /// </returns>
        public abstract VerifyAddressResponse VerifyAddress(
            VerifyAddressRequest request);

        /// <summary>
        ///     Verifies that the submitted address is valid using an
        ///     asynchronous request.
        /// </summary>
        /// <param name="request">The postal address to be validated</param>
        /// <returns>
        ///     Information on the requested address if it is valid; error
        ///     information if it is not
        /// </returns>
        public abstract Task<VerifyAddressResponse> VerifyAddressAsync(
            VerifyAddressRequest request);

        /// <summary>
        ///     Verifies that the submitted addresses are valid.
        /// </summary>
        /// <param name="requests">a list of postal addresses to be validated</param>
        /// <returns>
        ///     Information on each requested address if it is valid; error
        ///     information if it is not
        /// </returns>
        public abstract VerifyAddressResponse VerifyAddresses(
            List<VerifyAddressRequest> requests);

        /// <summary>
        ///     Verifies that the submitted addresses are valid using an
        ///     asynchronous request.
        /// </summary>
        /// <param name="requests">a list of postal addresses to be validated</param>
        /// <returns>
        ///     Information on each requested address if it is valid; error
        ///     information if it is not
        /// </returns>
        public abstract Task<VerifyAddressResponse> VerifyAddressesAsync(
            List<VerifyAddressRequest> requests);

        #endregion Verify Address API

        #region Get Location API

        /// <summary>
        ///     Returns location information (primarily latitude and longitude)
        ///     for the submitted address.
        /// </summary>
        /// <param name="request">
        ///     a GetLocationRequest object containing the address to be
        ///     searched for
        /// </param>
        /// <returns>
        ///     A postal-conformed version of the address along with the
        ///     geolocation data.
        /// </returns>
        public abstract GetLocationResponse GetLocation(
            GetLocationRequest request);

        /// <summary>
        ///     Returns location information (primarily latitude and longitude)
        ///     for the submitted address using an asynchronous call
        /// </summary>
        /// <param name="request">
        ///     a GetLocationRequest object containing the address to be
        ///     searched for
        /// </param>
        /// <returns>
        ///     A postal-conformed version of the address along with the
        ///     geolocation data.
        /// </returns>
        public abstract Task<GetLocationResponse> GetLocationAsync(
            GetLocationRequest request);

        #endregion Get Location API

        #region Static helper methods

        /// <summary>
        ///     Quality of Life method to simplify calls to VerifyAddress() and
        ///     VerifyAddressAsync()
        /// </summary>
        /// <param name="addressLine">The single street address line</param>
        /// <param name="city">The city name</param>
        /// <param name="stateAbbreviation">State or province official abbreviation</param>
        /// <param name="postalCode">The postal code (ZIP Code in the USA)</param>
        /// <returns>
        ///     A valid VerifyAddressRequest object with the above elements
        ///     populated
        /// </returns>
        public static VerifyAddressRequest CreateRequest(
            string addressLine,
            string city,
            string stateAbbreviation,
            string postalCode) => CreateRequest(
                new List<string> { addressLine },
                city, stateAbbreviation, postalCode);

        /// <summary>
        ///     Quality of Life method to simplify calls to VerifyAddress() and
        ///     VerifyAddressAsync()
        /// </summary>
        /// <param name="addressLine1">The first address line</param>
        /// <param name="addressLine2">The second address line</param>
        /// <param name="city">The city name</param>
        /// <param name="stateAbbreviation">State or province official abbreviation</param>
        /// <param name="postalCode">The postal code (ZIP Code in the USA)</param>
        /// <returns>
        ///     A valid VerifyAddressRequest object with the above elements
        ///     populated
        /// </returns>
        public static VerifyAddressRequest CreateRequest(
            string addressLine1,
            string addressLine2,
            string city,
            string stateAbbreviation,
            string postalCode) => CreateRequest(
            new List<string> { addressLine1, addressLine2 },
            city, stateAbbreviation, postalCode);

        /// <summary>
        ///     Quality of Life method to simplify calls to VerifyAddress() and
        ///     VerifyAddressAsync()
        /// </summary>
        /// <param name="addressLine1">The first address line</param>
        /// <param name="addressLine2">The second address line</param>
        /// <param name="addressLine3">The third address line</param>
        /// <param name="city">The city name</param>
        /// <param name="stateAbbreviation">State or province official abbreviation</param>
        /// <param name="postalCode">The postal code (ZIP Code in the USA)</param>
        /// <returns>
        ///     A valid VerifyAddressRequest object with the above elements
        ///     populated
        /// </returns>
        public static VerifyAddressRequest CreateRequest(
            string addressLine1,
            string addressLine2,
            string addressLine3,
            string city,
            string stateAbbreviation,
            string postalCode) => CreateRequest(
            new List<string> { addressLine1, addressLine2, addressLine3 },
            city, stateAbbreviation, postalCode);


        private static VerifyAddressRequest CreateRequest(
            List<string> addressLines,
            string city,
            string stateAbbreviation,
            string postalCode) => new VerifyAddressRequest
            {
                AddressLines = addressLines.ToArray(),
                City = city,
                StateAbbreviation = stateAbbreviation,
                PostalCode = postalCode
            };

        public static GetLocationRequest CreateLocationRequest(
            string addressLine1,
            string city,
            string stateAbbreviation,
            string postalCode) => new GetLocationRequest
            {
                AddressLine1 = addressLine1,
                City = city,
                StateAbbreviation = stateAbbreviation,
                PostalCode = postalCode
            };

        #endregion
    }
}
