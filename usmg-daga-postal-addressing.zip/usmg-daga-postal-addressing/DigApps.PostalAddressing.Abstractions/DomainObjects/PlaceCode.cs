﻿using System.Runtime.Serialization;

namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    [DataContract]
    public class PlaceCode
    {
        /// <summary>
        /// A place code, such as FIPS in the USA.
        /// </summary>
        [DataMember] public string Code { get; set; }

        /// <summary>
        /// A string identifying the type of code, such as "FIPS", "FIPS-County"
        /// or "FIPS-County-Full"
        /// </summary>
        [DataMember] public string CodeType { get; set; }
    }
}