﻿namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    public class GetLocationRequest
    {
        public string AddressLine1 { get; set; }
        public string City { get; set; }
        public string StateAbbreviation { get; set; }
        public string PostalCode { get; set; }
    }
}