﻿using System.Collections.Generic;

namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    public class GetLocationResponse
    {
        public List<Location> Locations { get; set; }
        public bool Successful { get; set; }
    }
}