﻿namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    public class Location
    {
        public PostalAddress PostalAddress { get; set; }
        public GeographicCoordinate GeographicCoordinate { get; set; }

    }
}