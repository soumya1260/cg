﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    [DataContract]
    public class PlaceIdentifier
    {
        [DataMember] public string Name { get; set; }
        [DataMember] public string Abbreviation { get; set; }
        [DataMember] public List<PlaceCode> PlaceCodes { get; set; }
    }
}