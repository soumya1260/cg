﻿using System.Runtime.Serialization;

namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    [DataContract]
    public class GeographicCoordinate
    {
        [DataMember] public decimal LatitudeInDegrees { get; set; }
        [DataMember] public decimal LongitudeInDegrees { get; set; }

        public GeographicCoordinate(decimal latitude, decimal longitude)
        {
            LatitudeInDegrees = latitude;
            LongitudeInDegrees = longitude;
        }
    }
}
