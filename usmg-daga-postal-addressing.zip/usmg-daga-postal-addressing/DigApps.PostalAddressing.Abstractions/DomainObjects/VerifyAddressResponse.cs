﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    [DataContract]
    public class VerifyAddressResponse
    {
        [DataMember]
        public bool Successful { get; set; }

        [DataMember]
        public List<VerifiedAddress> VerifiedAddresses { get; set; }
    }
}
