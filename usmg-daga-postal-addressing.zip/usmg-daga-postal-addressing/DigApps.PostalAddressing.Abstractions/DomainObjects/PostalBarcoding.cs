﻿using System.Runtime.Serialization;

namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    /// <summary>
    /// Barcode value and other Delivery Point Validation data.
    /// </summary>
    [DataContract]
    public class PostalBarcoding
    {
        [DataMember] public string BarcodeValue { get; set; }
        [DataMember] public string ConfirmationCode { get; set; }
        [DataMember] public string ConfirmationMessage { get; set; }
        [DataMember] public AddressType AddressType { get; set; }
    }
}