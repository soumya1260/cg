﻿namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    public enum ZipCodeType
    {
        Unknown = 0,
        Unique,
        Military,
        PostOfficeBox,
        Standard
    }
}
