﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    [DataContract]
    public class PostalAddress
    {
        /// <summary>
        /// One or more address lines.  Can include a name line for an
        /// individual or business as the first line.
        /// </summary>
        [DataMember] public List<string> AddressLines { get; set; }

        /// <summary>
        /// City name.  Avoid abbreviations that aren't the official
        /// abbreviations provided by the country's postal authority as some
        /// address processing services may not handle them well.
        /// </summary>
        [DataMember] public string City { get; set; }

        /// <summary>
        /// First-order Administrative division of a country.  This would be a
        /// State in the USA, a Province in Canada, _etc._
        /// </summary>
        [DataMember] public PlaceIdentifier StateOrProvince { get; set; }

        /// <summary>
        /// ZIP Code in the USA, Eircode in Ireland, PIN in India, _etc._
        /// </summary>
        [DataMember] public string PostalCode { get; set; }

        /// <summary>
        /// ZIP Code type -- may only apply to USPS delivery points.
        /// </summary>
        [DataMember] public ZipCodeType PostalCodeType { get; set; }
    }
}