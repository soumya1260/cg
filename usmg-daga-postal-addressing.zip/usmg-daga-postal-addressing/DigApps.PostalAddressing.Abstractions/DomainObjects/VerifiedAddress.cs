﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{

    [DataContract]
    public class VerifiedAddress : PostalAddress
    {
        /// <summary>
        /// Second-order administrative division of a country.  This would be a
        /// County in the USA or Great Britain.
        /// </summary>
        [DataMember] public PlaceIdentifier County { get; set; }

        /// <summary>
        /// Mean geographic location of the address.
        /// </summary>
        [DataMember] public GeographicCoordinate Coordinates { get; set; }

        /// <summary>
        /// Barcode value and other Delivery Point Validation data.
        /// </summary>
        [DataMember] public PostalBarcoding Barcoding { get; set; }

        /// <summary>
        /// Validation error messages.  May be empty if there were no issues.
        /// </summary>
        [DataMember] public List<ValidationMessage> ValidationErrors { get; set; } = new List<ValidationMessage>();

        /// <summary>
        /// Informational validation messages.  May be empty.
        /// </summary>
        [DataMember] public List<ValidationMessage> ValidationMessages { get; set; } = new List<ValidationMessage>();
    }
}
