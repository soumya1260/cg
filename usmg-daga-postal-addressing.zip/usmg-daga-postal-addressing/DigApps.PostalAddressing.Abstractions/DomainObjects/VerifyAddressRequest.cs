﻿using System.Runtime.Serialization;

namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    [DataContract]
    public class VerifyAddressRequest
    {
        /// <summary>
        /// An array of address lines.  This can include the addressee or
        /// business name as well as individual lines for the apartment or suite
        /// number.
        /// 
        /// Most clients only support up to three lines.
        /// </summary>
        [DataMember] public string[] AddressLines { get; set; }

        /// <summary>
        /// The proper name of the city as listed by the country's postal
        /// authority.
        /// </summary>
        [DataMember] public string City { get; set; }

        /// <summary>
        /// Two-character state or province abbreviation
        /// </summary>
        [DataMember] public string StateAbbreviation { get; set; }

        /// <summary>
        /// ZIP Code or Postal code
        /// </summary>
        [DataMember] public string PostalCode { get; set; }
    }
}
