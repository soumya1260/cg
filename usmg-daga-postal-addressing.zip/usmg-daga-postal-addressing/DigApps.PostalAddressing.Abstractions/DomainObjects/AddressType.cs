﻿namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    public enum AddressType
    {
        Unknown = 0,
        Alias,
        Firm,
        GeneralDelivery,
        HighRise,
        PostOfficeBox,
        RuralRouteOrHighwayContract,
        StreetAddress
    }
}
