﻿using System.Runtime.Serialization;

namespace DigApps.PostalAddressing.Abstractions.DomainObjects
{
    [DataContract]
    public class ValidationMessage
    {
        [DataMember] public string Code { get; set; }
        [DataMember] public string Message { get; set; }

        public ValidationMessage(string code, string message)
        {
            Code = code;
            Message = message;
        }
    }
}