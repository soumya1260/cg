﻿using DigApps.PostalAddressing.Abstractions;
using NUnit.Framework;

namespace DigApps.PostalAddressing.CignaAddressProcessor.Tests
{
    public class AdapterTests
    {
        public AdapterTests()
        {}

        [SetUp]
        public void Setup()
        {
        }

        // 
        // KONG/SOAP INT environment base URI
        //
        private const string BaseUri =
            "https://int-usmis.api-gtwy.cigna.com/infrastructure/v3/addressprocessor";

        //
        // KONG/SOAP Production environment base URI
        //
        //private const string BaseUri =
        //  "https://prd-usmis.api-gtwy.cigna.com/infrastructure/v3/addressprocessor";

        private const string UserName = "glswss";
        private const string Password = "KSYS#i$3n";  // Password from DEV environment
        private const string UserId = "UnitTestUser";
        private const string ApplicationId = "DigApps.PostalAddressing Unit Tests";

        [Test, Category("Integration")]
        public void VerifyAddress_ReturnsSuccessOnValidAddress()
        {
            var request = Resolver.CreateRequest(
                "500 Great Circle Rd",
                "Nashville",
                "TN",
                "37228");

            var adapter = new Adapter(BaseUri, UserName, Password, UserId, ApplicationId);
            var result = adapter.VerifyAddress(request);

            Assert.That(result.Successful, Is.True);
        }

        [Test, Category("Integration")]
        public void GetLocation_ReturnsSuccessOnValidAddress()
        {
            var request = Resolver.CreateLocationRequest(
                "500 Great Circle Rd",
                "Nashville",
                "TN",
                "37228");

            var adapter = new Adapter(BaseUri, UserName, Password, UserId, ApplicationId);
            var result = adapter.GetLocation(request);

            Assert.Multiple(() =>
                {
                    Assert.That(result.Successful, Is.True);
                    Assert.That(result.Locations, Has.Count.GreaterThan(0));
                    Assert.That(result.Locations[0].GeographicCoordinate.LatitudeInDegrees, Is.Not.Zero);
                    Assert.That(result.Locations[0].GeographicCoordinate.LongitudeInDegrees, Is.Not.Zero);
                });
        }
    }
}
