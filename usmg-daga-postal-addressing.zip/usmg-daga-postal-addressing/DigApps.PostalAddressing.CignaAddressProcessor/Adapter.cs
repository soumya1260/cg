﻿using DigApps.PostalAddressing.Abstractions;
using DigApps.PostalAddressing.Abstractions.DomainObjects;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace DigApps.PostalAddressing.CignaAddressProcessor
{
    public class Adapter : Resolver
    {
        private readonly AddressProcessor _service;

        public Adapter(
            string baseUrl, 
            string userName,
            string password,
            string currentUser,
            string applicationId)
        {
            _service = new AddressProcessor(baseUrl)
            {
                Credentials = new NetworkCredential(userName, password),
                UseDefaultCredentials = false,
                PreAuthenticate = false,
                UnsafeAuthenticatedConnectionSharing = false,
                Timeout = 1_000_000, // 1 second
                UserAgent = "DigApps.PostalAddressing.CignaAddressProcessor adapter",
            };

            InitializeSecurityHeader(userName, password);
            _service.validateAddressRequestHeader = InitializeValidateRequestHeader(
                currentUser, 
                applicationId);

            _service.locateGeocodeRequestHeader = InitializeLocateGeocodeHeader(
                currentUser,
                applicationId);
        }

        #region Resolver implementation

        public override VerifyAddressResponse VerifyAddress(VerifyAddressRequest request)
        {
            var serviceRequest = FormatVerifyAddressRequest(request);
            var response = _service.validateAddress(serviceRequest);
            var result = FormatVerifyAddressResponse(response);
            return result;
        }

        public override GetLocationResponse GetLocation(GetLocationRequest request)
        {
            var serviceRequest = FormatGetLocationRequest(request);
            var response = _service.locateGeocodeForAddress(serviceRequest);
            GetLocationResponse result = FormatGetLocationResponse(response);
            return result;
        }

        public override Task<VerifyAddressResponse> VerifyAddressAsync(
            VerifyAddressRequest request)
        {
            throw new NotImplementedException("Asynchronous requests are not currently supported by this client.");
        }

        public override VerifyAddressResponse VerifyAddresses(
            List<VerifyAddressRequest> requests)
        {
            throw new NotImplementedException("Multiple addresses are not supported by this client.");
        }

        public override Task<VerifyAddressResponse> VerifyAddressesAsync(
            List<VerifyAddressRequest> requests)
        {
            throw new NotImplementedException("Multiple addresses are not supported by this client.");
        }

        public override Task<GetLocationResponse> GetLocationAsync(GetLocationRequest request)
        {
            throw new NotImplementedException(
                "Asynchronous requests are not supported by this client.");
        }

        #endregion

        #region Private helper methods

        private void InitializeSecurityHeader(string userName, string password)
        {
            _service.aSecurityHeader = new AddressProcessor.Security
            {
                UsernameToken = new AddressProcessor.UsernameToken
                {
                    Username = userName,
                    Password = password
                }
            };
        }

        private AddressProcessor.requestHeader InitializeValidateRequestHeader(
            string currentUser,
            string applicationId)
        {
            var header = new AddressProcessor.requestHeader
            {
                serviceReferenceId = Guid.NewGuid().ToString(),
                functionalContext = new AddressProcessor.functionalContext
                {
                    consumerName = applicationId,
                    target = new AddressProcessor.target
                    {
                        serviceName = "AddressProcessor",
                        serviceOperation = "validateAddress"
                    },
                    userPrincipal = new AddressProcessor.userPrincipal
                    {
                        appRole = "UNAUTHENTICATED",
                        orgRole = "UNAUTHENTICATED",
                        userId = currentUser
                    }
                }
            };

            return header;
        }

        private AddressProcessor.requestHeader InitializeLocateGeocodeHeader(
            string currentUser,
            string applicationId)
        {
            //
            // The only difference between these two headers is the
            // serviceOperation value.
            //
            var header = InitializeValidateRequestHeader(currentUser, applicationId);
            header.functionalContext.target.serviceOperation = "locateGeocodeForAddress";
            return header;
        }

        private static ValidateAddressRequestType FormatVerifyAddressRequest(
            VerifyAddressRequest request)
        {
            _ = Enum.TryParse(request.StateAbbreviation, out StateCodeType stateCodeType);

            var serviceRequest = new ValidateAddressRequestType()
            {
                addressRequest = new MultiLineAddressRequestType1
                {
                    addressLine1 = request.AddressLines[0],
                    addressLine2 = request.AddressLines.Length > 1
                        ? request.AddressLines[1]
                        : string.Empty,
                    addressLine3 = request.AddressLines.Length > 2
                        ? request.AddressLines[2]
                        : string.Empty,
                    addressLine4 = request.AddressLines.Length > 3
                        ? request.AddressLines[3]
                        : string.Empty,
                    city = request.City,
                    stateCode = stateCodeType,
                    stateCodeSpecified = true,
                    zipCode = request.PostalCode,
                    includeGeocodeForAddress = true,
                }
            };
            return serviceRequest;
        }

        private VerifyAddressResponse FormatVerifyAddressResponse(
            ValidateAddressResponseType response)
        {
            var result = new VerifyAddressResponse
            {
                Successful = response.invocationOutcome.code == 0,
                VerifiedAddresses = new List<VerifiedAddress>
                {
                    //
                    // AddressProcessor only returns one address.
                    //
                    new VerifiedAddress
                    {
                        AddressLines = new List<string>
                        {
                            response.addressDetail?.mailingAddress?.firstLineAddress ?? string.Empty,
                            response.addressDetail?.mailingAddress?.secondLineAddress
                        },
                        City = response.addressDetail?.mailingAddress?.city ?? string.Empty,
                        County = new PlaceIdentifier
                        {
                            Name = response.addressDetail?.countyName ?? string.Empty,
                            Abbreviation = string.Empty,
                            PlaceCodes = new List<PlaceCode>()
                        },
                        PostalCode = response.addressDetail?.mailingAddress?.zipCode
                                     ?? string.Empty,
                        StateOrProvince = new PlaceIdentifier
                        {
                            Abbreviation = response.addressDetail?.mailingAddress?.state ?? string.Empty,
                            Name = string.Empty,
                            PlaceCodes = new List<PlaceCode>()
                        },
                        Barcoding = new PostalBarcoding
                        {
                            BarcodeValue = response.barCodeDetail?.deliveryPointBarCode?.postalBarCode
                            ?? string.Empty
                        },
                        ValidationErrors = new List<ValidationMessage>(),
                        ValidationMessages = new List<ValidationMessage>()
                    }
                }
            };

            if (result.Successful)
            {
                result.VerifiedAddresses[0].ValidationMessages.Add(new ValidationMessage(
                    response.invocationOutcome.code.ToString(),
                    response.invocationOutcome.message));
            }
            else
            {
                result.VerifiedAddresses[0].ValidationErrors.Add(new ValidationMessage(
                    response.invocationOutcome.code.ToString(),
                    response.invocationOutcome.message));
            }

            return result;
        }

        private LocateGeocodeForAddressRequestType FormatGetLocationRequest(GetLocationRequest request)
        {
            _ = Enum.TryParse(request.StateAbbreviation, out StateCodeType stateCodeType);

            var serviceRequest = new LocateGeocodeForAddressRequestType
            {
                geocodeRequest = new MultiLineAddressRequestType()
                {
                    addressLine1 = request.AddressLine1,
                    addressLine2 = null,
                    addressLine3 = null,
                    addressLine4 = null,
                    city = request.City,
                    stateCode = stateCodeType,
                    stateCodeSpecified = true,
                    zipCode = request.PostalCode
                }
            };
            return serviceRequest;
        }

        private GetLocationResponse FormatGetLocationResponse(
            LocateGeocodeForAddressResponseType response)
        {
            _ = decimal.TryParse(response.location?.latitude ?? "0.00", out var latitude);
            _ = decimal.TryParse(response.location?.longitude ?? "0.00", out var longitude);

            var result = new GetLocationResponse
            {
                Successful = response.invocationOutcome.code == 0,
                Locations = new List<Location>
                {
                    new Location
                    {
                        GeographicCoordinate = new GeographicCoordinate(
                            latitude,
                            longitude),
                        PostalAddress = new PostalAddress {
                            AddressLines = new List<string>
                            {
                                response.location?.address?.firstLineAddress ?? string.Empty
                            },
                            City = response.location?.address?.city ?? string.Empty,
                            StateOrProvince = new PlaceIdentifier
                            {
                                Abbreviation = response.location?.address?.state ?? string.Empty
                            },
                            PostalCode = response.location?.address?.zipCode ?? string.Empty,
                            PostalCodeType = ZipCodeType.Standard
                        }
                    }
                }
            };

            return result;
        }

        #endregion
    }
}
