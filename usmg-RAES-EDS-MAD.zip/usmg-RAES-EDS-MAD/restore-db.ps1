param (
    $dbServer = 'localhost', 
    $runBuild = 1
)

$dacs = @(
    @{ 
        'dbName' = 'EDPS_Data'
        'dacpac' = "$PSScriptRoot/EDPS_Data.SQL/bin/debug/EDPS_Data.SQL.dacpac"
        'publishProfile' = "$PSScriptRoot/EDPS_Data.SQL/EDPS_Data.SQL.publish.xml"
        'projectFle'  = "$PSScriptRoot/EDPS_Data.SQL/EDPS_Data.SQL.sqlproj"
    }
    @{ 
        'dbName' = 'WIPRO_Staging'
        'dacpac' = "$PSScriptRoot/WIPRO_Staging.SQL/bin/debug/WIPRO_Staging.SQL.dacpac"
        'publishProfile' = "$PSScriptRoot/WIPRO_Staging.SQL/WIPRO_Staging.SQL.publish.xml"
        'projectFle'  = "$PSScriptRoot/WIPRO_Staging.SQL/WIPRO_Staging.SQL.sqlproj"
    },
    @{ 
        'dbName' = 'EDIFECS'
        'dacpac' = "$PSScriptRoot/EDIFECS.SQL/bin/debug/EDIFECS.SQL.dacpac"
        'publishProfile' = "$PSScriptRoot/EDIFECS.SQL/EDIFECS.SQL.publish.xml"
        'projectFle'  = "$PSScriptRoot/EDIFECS.SQL/EDIFECS.SQL.sqlproj"
    },
    @{ 
        'dbName' = 'WIPRO'
        'dacpac' = "$PSScriptRoot/WIPRO.SQL/bin/debug/WIPRO.SQL.dacpac"
        'publishProfile' = "$PSScriptRoot/WIPRO.SQL/WIPRO.SQL.publish.xml"
        'projectFle'  = "$PSScriptRoot/WIPRO.SQL/WIPRO.SQL.sqlproj"
    }
    @{ 
        'dbName' = 'EDIFECS'
        'dacpac' = "$PSScriptRoot/EDIFECS.SQL/bin/debug/EDIFECS.SQL.dacpac"
        'publishProfile' = "$PSScriptRoot/EDIFECS.SQL/EDIFECS.SQL.publish.xml"
        'projectFle'  = "$PSScriptRoot/EDIFECS.SQL/EDIFECS.SQL.sqlproj"
    },
    @{ 
        'dbName' = 'EDPS_Data'
        'dacpac' = "$PSScriptRoot/EDPS_Data.SQL/bin/debug/EDPS_Data.SQL.dacpac"
        'publishProfile' = "$PSScriptRoot/EDPS_Data.SQL/EDPS_Data.SQL.publish.xml"
        'projectFle'  = "$PSScriptRoot/EDPS_Data.SQL/EDPS_Data.SQL.sqlproj"
    }

)

write-host "-------------------------------"
write-host "Inorder to run the script below be sure to:  "
write-host "     #1 install SqlPackage using the powershell command:  choco install sqlpackage"
write-host "     #2 add msbuild to your path environment"
write-host "-------------------------------"

foreach($dac in $dacs) {

    if ($runBuild -eq $true) {
        # build and create a dacpac
        msbuild $dac.projectFle
    }

    # publish dacpac
    sqlpackage /action:Publish /SourceFile:$($dac.dacpac) /Profile:$($dac.publishProfile) /TargetDatabaseName:$($dac.dbName) /TargetServerName:$dbServer
    # sqlpackage /action:Script /SourceFile:$dacpac /Profile:$publishProfile /TargetDatabaseName:$dbName /TargetServerName:$dbServer /OutputPath:temp.sql
}