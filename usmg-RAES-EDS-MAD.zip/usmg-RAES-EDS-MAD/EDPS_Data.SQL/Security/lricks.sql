﻿CREATE SCHEMA [lricks]
    AUTHORIZATION [dbo];

