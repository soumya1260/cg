﻿CREATE SCHEMA [obsolete]
    AUTHORIZATION [dbo];

