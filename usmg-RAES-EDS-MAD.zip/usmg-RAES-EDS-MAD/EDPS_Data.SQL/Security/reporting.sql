﻿CREATE SCHEMA [reporting]
    AUTHORIZATION [dbo];

