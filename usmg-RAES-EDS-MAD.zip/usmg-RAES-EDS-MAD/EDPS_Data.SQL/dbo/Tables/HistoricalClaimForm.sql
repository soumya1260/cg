﻿CREATE TABLE [dbo].[HistoricalClaimForm] (
    [HistoricalClaimFormID] INT          IDENTITY (1, 1) NOT NULL,
    [HistoricalClaimID]     INT          NOT NULL,
    [ClaimID]               VARCHAR (50) NULL,
    [QuestionNumber_Letter] VARCHAR (20) NULL,
    [Condition]             VARCHAR (1)  NULL,
    [Response]              VARCHAR (50) NULL,
    [Date]                  VARCHAR (8)  NULL,
    [Percent]               NUMERIC (18) NULL,
    PRIMARY KEY CLUSTERED ([HistoricalClaimFormID] ASC)
);

