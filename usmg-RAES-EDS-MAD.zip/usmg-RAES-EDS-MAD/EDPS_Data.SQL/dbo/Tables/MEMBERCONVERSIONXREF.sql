﻿CREATE TABLE [dbo].[MEMBERCONVERSIONXREF] (
    [SourceDataKey] INT          NULL,
    [MemberID]      VARCHAR (16) NULL,
    [OldMemberID]   VARCHAR (16) NULL
);

