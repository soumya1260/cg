﻿CREATE TABLE [dbo].[EDS_ProviderAddressDim] (
    [SourceDataKey]   INT            NULL,
    [ProviderID]      VARCHAR (20)   NULL,
    [AddressTypeCode] VARCHAR (2)    NULL,
    [AddressLine1]    VARCHAR (60)   NULL,
    [AddressLine2]    VARCHAR (60)   NULL,
    [City]            VARCHAR (30)   NULL,
    [State]           CHAR (2)       NULL,
    [ZipCode9]        VARCHAR (9)    NULL,
    [MultiAddressInd] INT            NULL,
    [Latitude]        DECIMAL (9, 6) NULL,
    [Longitude]       DECIMAL (9, 6) NULL
);

