﻿CREATE TABLE [dbo].[UB921ADMISSIONDIM] (
    [claimid]                    VARCHAR (20) NULL,
    [admissionhour]              VARCHAR (4)  NULL,
    [dischargehour]              VARCHAR (4)  NULL,
    [admissioncode]              VARCHAR (1)  NULL,
    [injurycode]                 VARCHAR (10) NULL,
    [procedurecodemethodcode]    VARCHAR (1)  NULL,
    [billtypecode]               VARCHAR (4)  NULL,
    [diagnosiscode]              VARCHAR (10) NULL,
    [admissiondiagnosistypecode] VARCHAR (6)  NULL,
    [SourceDataKey]              INT          NULL
);


GO
CREATE NONCLUSTERED INDEX [NIX_UB921AdmissionDim_Submissions_1]
    ON [dbo].[UB921ADMISSIONDIM]([claimid] ASC)
    INCLUDE([billtypecode]);

