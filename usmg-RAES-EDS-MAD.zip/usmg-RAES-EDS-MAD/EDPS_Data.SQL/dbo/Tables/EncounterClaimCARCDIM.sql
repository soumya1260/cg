﻿CREATE TABLE [dbo].[EncounterClaimCARCDIM] (
    [EncounterClaimCARCID]     INT          NOT NULL,
    [EnterpriseID]             VARCHAR (50) NOT NULL,
    [ID]                       VARCHAR (50) NOT NULL,
    [ClaimNum]                 VARCHAR (50) NULL,
    [ClaimLineNumber]          NUMERIC (18) NULL,
    [ClaimAdjustmentGroupCode] VARCHAR (2)  NULL,
    [ClaimAdjustmentReason]    VARCHAR (50) NULL,
    [ClaimAdjustmentAmount]    REAL         NULL,
    [ClaimAdjustmentQty]       NUMERIC (18) NULL,
    [ClaimAdjustmentReason2]   VARCHAR (50) NULL,
    [ClaimAdjustmentAmount2]   REAL         NULL,
    [ClaimAdjustmentQty2]      NUMERIC (18) NULL,
    [ClaimAdjustmentReason3]   VARCHAR (50) NULL,
    [ClaimAdjustmentAmount3]   REAL         NULL,
    [ClaimAdjustmentQty3]      NUMERIC (18) NULL,
    [ClaimAdjustmentReason4]   VARCHAR (50) NULL,
    [ClaimAdjustmentAmount4]   REAL         NULL,
    [ClaimAdjustmentQty4]      NUMERIC (18) NULL,
    [ClaimAdjustmentReason5]   VARCHAR (50) NULL,
    [ClaimAdjustmentAmount5]   REAL         NULL,
    [ClaimAdjustmentQty5]      NUMERIC (18) NULL,
    [ClaimAdjustmentReason6]   VARCHAR (50) NULL,
    [ClaimAdjustmentAmount6]   REAL         NULL,
    [ClaimAdjustmentQty6]      NUMERIC (18) NULL
);


GO
CREATE NONCLUSTERED INDEX [Idx_EncounterClaimCARCDIM_EOB]
    ON [dbo].[EncounterClaimCARCDIM]([ClaimNum] ASC, [ClaimLineNumber] ASC, [ClaimAdjustmentGroupCode] ASC)
    INCLUDE([ClaimAdjustmentReason], [ClaimAdjustmentReason2], [ClaimAdjustmentReason3], [ClaimAdjustmentReason4], [ClaimAdjustmentReason5], [ClaimAdjustmentReason6]);

