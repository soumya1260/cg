﻿CREATE TABLE [dbo].[PROCEDURECODEDIM_hold] (
    [ProcedureCodeKey]     INT              NULL,
    [ProcedureCode]        VARCHAR (10)     NULL,
    [EffectiveDateKey]     INT              NOT NULL,
    [EndDateKey]           INT              NOT NULL,
    [ProcedureDesc]        VARCHAR (255)    NOT NULL,
    [DiagnosisCodeVersion] VARCHAR (1)      NOT NULL,
    [Accomodation]         VARCHAR (1)      NOT NULL,
    [ProcedureTypeCode]    CHAR (1)         NOT NULL,
    [ProcedureGroup]       VARCHAR (30)     NOT NULL,
    [LastUpdateDateKey]    INT              NOT NULL,
    [SourceDataKey]        INT              NOT NULL,
    [Active]               BIT              NOT NULL,
    [Deleted]              BIT              NOT NULL,
    [LoadDateKey]          INT              NOT NULL,
    [EnterpriseID]         UNIQUEIDENTIFIER NOT NULL
);

