﻿CREATE TABLE [dbo].[CLAIMLINEADJUSTMENTDIM] (
    [CLAIMID]                VARCHAR (20)     NULL,
    [SOURCEDATAKEY]          INT              NULL,
    [CLAIMLINEADJUSTMENTKEY] INT              NULL,
    [CLAIMLINEID]            VARCHAR (5)      NULL,
    [ADJUSTMENTCODE]         VARCHAR (15)     NULL,
    [DENIEDREASONCODE]       VARCHAR (15)     NULL,
    [SEQUENCE]               INT              NULL,
    [ACTIVE]                 BIT              NULL,
    [DELETED]                BIT              NULL,
    [LOADDATEKEY]            INT              NULL,
    [ENTERPRISEID]           UNIQUEIDENTIFIER NULL
);

