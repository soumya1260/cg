﻿CREATE TABLE [dbo].[EncounterRecordCounts] (
    [LoadDate]             VARCHAR (12) NULL,
    [EncounterClaimDim]    INT          NULL,
    [EncounterProviderDim] INT          NULL,
    [EDI_Detail_5010]      INT          NULL,
    [EDI_Prof_5010]        INT          NULL,
    [EDI_Reqd_5010]        INT          NULL,
    [EDI_Inst_5010]        INT          NULL
);

