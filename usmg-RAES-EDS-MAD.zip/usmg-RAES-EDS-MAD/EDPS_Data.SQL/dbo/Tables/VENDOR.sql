﻿CREATE TABLE [dbo].[VENDOR] (
    [VendorKey]          INT              NULL,
    [VendorID]           VARCHAR (20)     NULL,
    [VendorTypeCode]     VARCHAR (15)     NULL,
    [VendorCategory]     VARCHAR (4)      NULL,
    [NationalProviderID] VARCHAR (10)     NULL,
    [FederalID]          VARCHAR (25)     NULL,
    [VendorName]         VARCHAR (100)    NULL,
    [LastName]           VARCHAR (60)     NULL,
    [FirstName]          VARCHAR (70)     NULL,
    [AddressLine1]       VARCHAR (60)     NULL,
    [AddressLine2]       VARCHAR (60)     NULL,
    [Phone]              VARCHAR (20)     NULL,
    [City]               VARCHAR (40)     NULL,
    [State]              VARCHAR (2)      NULL,
    [Zip]                VARCHAR (11)     NULL,
    [SourceDataKey]      INT              NULL,
    [Active]             BIT              NULL,
    [Deleted]            BIT              NULL,
    [LoadDateKey]        INT              NULL,
    [EnterpriseID]       UNIQUEIDENTIFIER NULL
);

