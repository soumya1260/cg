﻿CREATE TABLE [dbo].[MemberMedicareIDHistoryXref] (
    [MemberMedicareIDHistoryXrefKey] INT              NOT NULL,
    [MemberID]                       VARCHAR (16)     NOT NULL,
    [MedicareIDOld]                  VARCHAR (14)     NOT NULL,
    [MedicareIDNew]                  VARCHAR (14)     NOT NULL,
    [EffectiveDateKey]               INT              NOT NULL,
    [Active]                         BIT              NOT NULL,
    [Deleted]                        BIT              NOT NULL,
    [LoadDateKey]                    INT              NOT NULL,
    [EnterpriseID]                   UNIQUEIDENTIFIER NOT NULL
);

