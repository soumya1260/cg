﻿CREATE TABLE [dbo].[CLAIMDIAGNOSISDIM] (
    [CLAIMID]               VARCHAR (20)     NULL,
    [DIAGNOSISCODE]         VARCHAR (10)     NULL,
    [DIAGNOSISTYPECODE]     VARCHAR (1)      NULL,
    [DIAGNOSISDESC]         VARCHAR (2500)   NULL,
    [SEQUENCE]              VARCHAR (2)      NULL,
    [POAIND]                VARCHAR (1)      NULL,
    [SourceDataKey]         INT              NULL,
    [DiagnosisCodeVersion]  VARCHAR (2)      NULL,
    [LoadDateKey]           INT              NULL,
    [Active]                BIT              NULL,
    [Deleted]               BIT              NULL,
    [EnterpriseID]          UNIQUEIDENTIFIER NULL,
    [DiagnosisTypeCodeDesc] VARCHAR (30)     NULL
);
GO

CREATE CLUSTERED INDEX IDXC_CLAIMID
ON dbo.CLAIMDIAGNOSISDIM(
	CLAIMID ASC )
WITH (DATA_COMPRESSION = PAGE, FILLFACTOR = 95, PAD_INDEX = ON);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDiagnosisDim_Submissions_1]
    ON [dbo].[CLAIMDIAGNOSISDIM]([SEQUENCE] ASC)
    INCLUDE([CLAIMID], [DIAGNOSISCODE], [POAIND]);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDiagnosisDim_Submissions_2]
    ON [dbo].[CLAIMDIAGNOSISDIM]([DIAGNOSISTYPECODE] ASC)
    INCLUDE([CLAIMID], [DIAGNOSISCODE], [POAIND]);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDiagnosisDim_Submissions_3]
    ON [dbo].[CLAIMDIAGNOSISDIM]([CLAIMID] ASC, [DIAGNOSISTYPECODE] ASC)
    INCLUDE([DIAGNOSISCODE], [POAIND]);

