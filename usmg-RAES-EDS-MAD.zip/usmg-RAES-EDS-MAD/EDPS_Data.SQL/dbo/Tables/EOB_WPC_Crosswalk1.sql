﻿CREATE TABLE [dbo].[EOB_WPC_Crosswalk1] (
    [EOB]              VARCHAR (50) NULL,
    [EXCD_SHORT_TEXT]  VARCHAR (50) NULL,
    [CARC_Code]        VARCHAR (50) NULL,
    [RARC_Remit_Code]  VARCHAR (50) NULL,
    [EXCD_PT_LIAB_IND] VARCHAR (50) NULL,
    [Category]         VARCHAR (50) NULL,
    [Category1]        VARCHAR (50) NULL
);

