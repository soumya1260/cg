﻿CREATE TABLE [dbo].[Fix_NPI] (
    [ClaimID] VARCHAR (20) NULL,
    [NPI]     VARCHAR (20) NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20210603-085058]
    ON [dbo].[Fix_NPI]([ClaimID] ASC, [NPI] ASC);

