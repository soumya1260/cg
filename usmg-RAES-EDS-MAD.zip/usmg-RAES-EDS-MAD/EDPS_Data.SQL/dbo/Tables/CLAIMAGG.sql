﻿CREATE TABLE [dbo].[CLAIMAGG] (
    [CLAIMID]                 VARCHAR (100) NULL,
    [SOURCEDATAKEY]           INT           NULL,
    [PREVIOUSCLAIMID]         VARCHAR (100) NULL,
    [MEMBERID]                VARCHAR (100) NULL,
    [SUBSCRIBERID]            VARCHAR (100) NULL,
    [PATIENTID]               VARCHAR (100) NULL,
    [MEMBERREGIONCODE]        VARCHAR (100) NULL,
    [PROVIDERREGIONCODE]      VARCHAR (100) NULL,
    [GROUPID]                 VARCHAR (100) NULL,
    [AUTHORIZATIONID]         VARCHAR (100) NULL,
    [PCPID]                   VARCHAR (100) NULL,
    [PAYTOVENDORORFAMILYFLAG] VARCHAR (100) NULL,
    [PAIDDATEKEY]             INT           NULL,
    [ADMISSIONDATEKEY]        INT           NULL,
    [DISCHARGEDATEKEY]        INT           NULL,
    [DATERECEIVEDKEY]         INT           NULL,
    [BEGINSERVICEDATEKEY]     INT           NULL,
    [ENDSERVICEDATEKEY]       INT           NULL,
    [DISPOSITIONCODE]         VARCHAR (100) NULL,
    [FORMTYPECODE]            VARCHAR (100) NULL,
    [CURRENTSTATUSCODE]       VARCHAR (100) NULL,
    [TYPECODE]                VARCHAR (100) NULL,
    [VISITSCOUNT]             INT           NULL,
    [REFERRINGPHYSICIANID]    VARCHAR (100) NULL,
    [ATTENDINGPHYSICIANID]    VARCHAR (100) NULL,
    [LOBCODE]                 VARCHAR (100) NULL,
    [DRGCODE]                 VARCHAR (100) NULL,
    [PROVIDERID]              VARCHAR (100) NULL,
    [PROVIDERNPI]             VARCHAR (100) NULL,
    [REQUESTEDAMT]            MONEY         NULL,
    [MAXFEEAMT]               MONEY         NULL,
    [ELIGIBLEFEEAMT]          MONEY         NULL,
    [COBAMT]                  MONEY         NULL,
    [DEDUCTIBLEAMT]           MONEY         NULL,
    [COPAYAMT]                MONEY         NULL,
    [COINSURANCEAMT]          MONEY         NULL,
    [WITHHOLDAMT]             MONEY         NULL,
    [PAIDAMT]                 MONEY         NULL,
    [COMPANYID]               VARCHAR (100) NULL
);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimAgg_Submissions_1]
    ON [dbo].[CLAIMAGG]([CURRENTSTATUSCODE] ASC, [PREVIOUSCLAIMID] ASC)
    INCLUDE([CLAIMID]);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimAgg_Submissions_2]
    ON [dbo].[CLAIMAGG]([CLAIMID] ASC)
    INCLUDE([PAIDDATEKEY]);

