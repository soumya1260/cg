﻿CREATE TABLE [dbo].[CLAIMDETAILDIAGNOSISDIM] (
    [CLAIMID]                 VARCHAR (20)     NULL,
    [SOURCEDATAKEY]           INT              NULL,
    [CLAIMDETAILDIAGNOSISKEY] NUMERIC (18)     NULL,
    [CLAIMLINEID]             VARCHAR (5)      NULL,
    [DIAGNOSISCODE]           VARCHAR (10)     NULL,
    [SEQUENCE]                INT              NULL,
    [ACTIVE]                  BIT              NULL,
    [DELETED]                 BIT              NULL,
    [LOADDATEKEY]             INT              NULL,
    [ENTERPRISEID]            UNIQUEIDENTIFIER NULL,
    [DiagnosisCodeVersion]    CHAR (1)         NULL
);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDiagnosisDim_Submissions_1]
    ON [dbo].[CLAIMDETAILDIAGNOSISDIM]([SEQUENCE] ASC)
    INCLUDE([CLAIMID], [CLAIMLINEID], [DIAGNOSISCODE]);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDiagnosisDim_Submissions_2]
    ON [dbo].[CLAIMDETAILDIAGNOSISDIM]([CLAIMID] ASC)
    INCLUDE([SOURCEDATAKEY], [CLAIMDETAILDIAGNOSISKEY], [CLAIMLINEID], [DIAGNOSISCODE], [SEQUENCE]);

