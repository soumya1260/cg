﻿CREATE TABLE [dbo].[DiagnosisCodeDim] (
    [DiagnosisCodeKey]     INT              NULL,
    [DiagnosisCode]        VARCHAR (10)     NOT NULL,
    [DiagnosisCodeNoDec]   VARCHAR (10)     NOT NULL,
    [DiagnosisCodeDesc]    VARCHAR (255)    NULL,
    [StartDateKey]         INT              NOT NULL,
    [EndDateKey]           INT              NOT NULL,
    [CodeGroup]            VARCHAR (6)      NOT NULL,
    [RequirePOS]           VARCHAR (1)      NULL,
    [DiagnosisCodeVersion] VARCHAR (1)      NOT NULL,
    [LastUpdateDateKey]    INT              NOT NULL,
    [SourceDataKey]        INT              NOT NULL,
    [Active]               BIT              NOT NULL,
    [Deleted]              BIT              NOT NULL,
    [LoadDateKey]          INT              NOT NULL,
    [EnterpriseID]         UNIQUEIDENTIFIER NOT NULL
);

