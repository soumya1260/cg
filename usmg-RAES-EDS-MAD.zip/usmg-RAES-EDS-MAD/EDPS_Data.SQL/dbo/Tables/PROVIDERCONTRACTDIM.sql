﻿CREATE TABLE [dbo].[PROVIDERCONTRACTDIM] (
    [ProviderContractKey] INT              NULL,
    [ProviderID]          VARCHAR (20)     NULL,
    [VendorID]            VARCHAR (20)     NULL,
    [LobCode]             VARCHAR (15)     NULL,
    [RegionCode]          VARCHAR (15)     NULL,
    [EffectiveDateKey]    INT              NULL,
    [EndDateKey]          INT              NULL,
    [ProvActiveFlag]      VARCHAR (1)      NULL,
    [ParFlag]             VARCHAR (1)      NULL,
    [SourceDataKey]       INT              NULL,
    [Active]              BIT              NULL,
    [Deleted]             BIT              NULL,
    [LoadDateKey]         INT              NULL,
    [EnterpriseID]        UNIQUEIDENTIFIER NULL
);

