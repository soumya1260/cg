﻿CREATE TABLE [dbo].[MemberEligibility] (
    [Memberid]       VARCHAR (50) NULL,
    [PCPID]          VARCHAR (50) NULL,
    [ContractNumber] VARCHAR (50) NULL,
    [EligStartDate]  DATE         NULL,
    [EligEndDate]    DATE         NULL,
    [PCPStartDate]   DATE         NULL,
    [PCPEndDate]     DATE         NULL,
    [LoadDate]       DATE         NULL,
    [OperMkt]        VARCHAR (50) NULL,
    [Deleted]        BIT          NULL,
    [ModifiedDate]   DATE         NULL,
    [MarketID]       INT          NULL
);

