﻿CREATE TABLE [dbo].[CMSMemberMedicareIDXref] (
    [CMSMemberMedicareIDXrefKey] INT          NOT NULL,
    [MemberID]                   VARCHAR (20) NULL,
    [HCFACode]                   VARCHAR (5)  NULL,
    [PBPCode]                    VARCHAR (3)  NULL,
    [HICN]                       VARCHAR (12) NULL,
    [MBI]                        VARCHAR (11) NULL,
    [LastName]                   VARCHAR (30) NULL,
    [FirstName]                  VARCHAR (12) NULL,
    [DateOfBirthKey]             INT          NULL,
    [DateOfDeathKey]             INT          NULL,
    [Gender]                     CHAR (1)     NULL,
    [RecentEnrollmentDateKey]    INT          NULL,
    [RecentDisenrollmentDateKey] INT          NULL,
    [SequenceCode]               INT          NULL,
    [LoadDateKey]                INT          NULL,
    [Active]                     INT          NULL,
    [Deleted]                    INT          NULL,
    [SourceDataKey]              INT          NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-MemberID]
    ON [dbo].[CMSMemberMedicareIDXref]([MemberID] ASC);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-MBI]
    ON [dbo].[CMSMemberMedicareIDXref]([MBI] ASC);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-HICN]
    ON [dbo].[CMSMemberMedicareIDXref]([HICN] ASC);

