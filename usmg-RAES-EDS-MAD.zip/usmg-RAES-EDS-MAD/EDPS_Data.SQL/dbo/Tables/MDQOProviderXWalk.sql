﻿CREATE TABLE [dbo].[MDQOProviderXWalk] (
    [MDQOProviderXWalkID]      INT           NOT NULL,
    [MDQOProviderID]           VARCHAR (20)  NOT NULL,
    [SourceProviderID]         VARCHAR (30)  NOT NULL,
    [SourceDataKey]            INT           NOT NULL,
    [SourceDOB]                INT           NOT NULL,
    [SourceNPID]               VARCHAR (10)  NOT NULL,
    [SourceUPIN]               VARCHAR (20)  NOT NULL,
    [SourceFIDN]               VARCHAR (25)  NOT NULL,
    [SourceDEAN]               VARCHAR (10)  NOT NULL,
    [SourceMedicaidID]         VARCHAR (20)  NOT NULL,
    [SourceMedicareID]         VARCHAR (20)  NOT NULL,
    [ReportingProviderID]      VARCHAR (30)  NULL,
    [RecordEffectiveBeginDate] DATETIME      NOT NULL,
    [RecordEffectiveEndDate]   DATETIME      NOT NULL,
    [CreatedBy]                VARCHAR (100) NOT NULL,
    [IsActive]                 BIT           NOT NULL,
    [Override]                 BIT           NOT NULL
);

