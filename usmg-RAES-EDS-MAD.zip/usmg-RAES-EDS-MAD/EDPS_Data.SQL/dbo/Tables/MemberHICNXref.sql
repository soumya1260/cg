﻿CREATE TABLE [dbo].[MemberHICNXref] (
    [MemberHICNXrefKey] INT              NOT NULL,
    [MemberID]          VARCHAR (20)     NULL,
    [MedicareID]        VARCHAR (30)     NULL,
    [StartDateKey]      INT              NULL,
    [EndDateKey]        INT              NULL,
    [SequenceCode]      VARCHAR (3)      NULL,
    [LoadDateKey]       INT              NULL,
    [Active]            INT              NULL,
    [Deleted]           INT              NULL,
    [EnterpriseID]      UNIQUEIDENTIFIER NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-MemberID]
    ON [dbo].[MemberHICNXref]([MemberID] ASC);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-MedicareID]
    ON [dbo].[MemberHICNXref]([MedicareID] ASC);

