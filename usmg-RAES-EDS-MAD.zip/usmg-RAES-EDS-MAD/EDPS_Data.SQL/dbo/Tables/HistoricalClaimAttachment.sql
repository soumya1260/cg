﻿CREATE TABLE [dbo].[HistoricalClaimAttachment] (
    [HistoricalClaimAttachmentID] INT          NOT NULL,
    [HistoricalClaimID]           INT          NOT NULL,
    [ClaimID]                     VARCHAR (50) NOT NULL,
    [ClaimNo]                     VARCHAR (50) NULL,
    [LineID]                      VARCHAR (50) NULL,
    [ReportType]                  VARCHAR (2)  NULL,
    [ReportAttachmentCode]        VARCHAR (2)  NULL,
    [AttachmentQualifier]         VARCHAR (2)  NULL,
    [AttachmentCtlNbr]            VARCHAR (80) NULL
);

