CREATE TABLE [dbo].[encounterclaimdim] (
    [EncounterClaimKey]          INT              NOT NULL,
    [ProviderID]                 VARCHAR (80)     NOT NULL,
    [ReferringProviderID]        VARCHAR (80)     NULL,
    [MemberID]                   VARCHAR (80)     NULL,
    [MedicareID]                 VARCHAR (12)     NULL,
    [PCPID]                      VARCHAR (80)     NULL,
    [PCPLastName]                VARCHAR (60)     NULL,
    [PCPFirstName]               VARCHAR (40)     NULL,
    [PCPMiddleName]              CHAR (30)        NULL,
    [ClaimNum]                   VARCHAR (50)     NULL,
    [ProvTaxonomyCode]           VARCHAR (50)     NULL,
    [ProvSpecialtyCode]          VARCHAR (50)     NULL,
    [BillTypeCode]               VARCHAR (3)      NULL,
    [DateReceivedKey]            INT              NULL,
    [DateEnteredKey]             INT              NULL,
    [AdmissionTypeCode]          CHAR (1)         NULL,
    [AdmissionSourceCode]        CHAR (1)         NULL,
    [DischargeStatusCode]        CHAR (2)         NULL,
    [BeginServiceDateKey]        INT              NULL,
    [EndServiceDateKey]          INT              NULL,
    [PaidDateKey]                VARCHAR (10)     NULL,
    [ReversedClaimNum]           VARCHAR (50)     NULL,
    [Quantity]                   INT              NULL,
    [DeniedServiceQuantity]      INT              NULL,
    [PlaceOfServiceCode]         VARCHAR (50)     NULL,
    [RequestedAmt]               MONEY            NOT NULL,
    [EligibleFeeAmt]             MONEY            NOT NULL,
    [CoPayAmt]                   MONEY            NOT NULL,
    [CoInsuranceAmt]             MONEY            NOT NULL,
    [DeductibleAmt]              MONEY            NOT NULL,
    [COBAmt]                     MONEY            NOT NULL,
    [PaidAmt]                    DECIMAL (9, 2)   NULL,
    [WithholdAmt]                MONEY            NOT NULL,
    [MaxFeeAmt]                  MONEY            NOT NULL,
    [AdmissionDateKey]           INT              NULL,
    [AdmissionDiagnosisTypeCode] VARCHAR (10)     NULL,
    [ProcedureCode]              VARCHAR (50)     NULL,
    [ModifierCode1]              VARCHAR (50)     NULL,
    [ModifierCode2]              VARCHAR (50)     NULL,
    [ModifierCode3]              VARCHAR (50)     NULL,
    [ModifierCode4]              VARCHAR (50)     NULL,
    [FederalTaxID]               VARCHAR (50)     NULL,
    [VendorID]                   VARCHAR (80)     NULL,
    [VendorLastName]             VARCHAR (60)     NULL,
    [VendorFirstName]            VARCHAR (40)     NULL,
    [AdjustmentCode]             VARCHAR (50)     NULL,
    [CheckNum]                   VARCHAR (10)     NULL,
    [RevenueCode]                VARCHAR (48)     NULL,
    [DeniedReasonCode]           VARCHAR (10)     NULL,
    [ICD9ProcedureCode1]         VARCHAR (30)     NULL,
    [ICD9ProcedureDateKey1]      INT              NULL,
    [ICD9ProcedureCode2]         VARCHAR (30)     NULL,
    [ICD9ProcedureDateKey2]      INT              NULL,
    [ICD9ProcedureCode3]         VARCHAR (30)     NULL,
    [ICD9ProcedureDateKey3]      INT              NULL,
    [AuthorizationID]            VARCHAR (100)    NULL,
    [ClaimLineNum]               VARCHAR (4)      NULL,
    [DX1]                        VARCHAR (30)     NULL,
    [DiagQual1]                  VARCHAR (1)      NULL,
    [DX2]                        VARCHAR (30)     NULL,
    [DiagQual2]                  VARCHAR (1)      NULL,
    [DX3]                        VARCHAR (30)     NULL,
    [DiagQual3]                  VARCHAR (1)      NULL,
    [DX4]                        VARCHAR (30)     NULL,
    [DiagQual4]                  VARCHAR (1)      NULL,
    [DX5]                        VARCHAR (30)     NULL,
    [DiagQual5]                  VARCHAR (1)      NULL,
    [DX6]                        VARCHAR (30)     NULL,
    [DiagQual6]                  VARCHAR (1)      NULL,
    [DX7]                        VARCHAR (30)     NULL,
    [DiagQual7]                  VARCHAR (1)      NULL,
    [DX8]                        VARCHAR (30)     NULL,
    [DiagQual8]                  VARCHAR (1)      NULL,
    [DX9]                        VARCHAR (30)     NULL,
    [DiagQual9]                  VARCHAR (1)      NULL,
    [DX10]                       VARCHAR (30)     NULL,
    [DiagQual10]                 VARCHAR (1)      NULL,
    [TaxonomyCode]               INT              NULL,
    [ClaimLineStatus]            INT              NULL,
    [FileName]                   VARCHAR (256)    NULL,
    [SourceDesc]                 VARCHAR (60)     NOT NULL,
    [SourceDataKey]              INT              NOT NULL,
    [Active]                     BIT              NOT NULL,
    [Deleted]                    BIT              NOT NULL,
    [LoadDateKey]                INT              NOT NULL,
    [EnterpriseID]               UNIQUEIDENTIFIER NOT NULL,
    [ClaimType]                  VARCHAR (50)     NULL,
    [InpatientInd]               VARCHAR (1)      NULL,
    [ClaimFrequencyCode]         VARCHAR (30)     NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20160929-185828]
    ON [dbo].[encounterclaimdim]([ClaimNum] ASC, [SourceDesc] ASC);


GO
CREATE NONCLUSTERED INDEX [IDX_BeginDOS_ProviderID_RefProvID_MemberID_ClaimNum_EndDOS_ReqAmt_PaidAmt_VendorID_Source_ClaimType]
    ON [dbo].[encounterclaimdim]([BeginServiceDateKey] ASC)
    INCLUDE([ProviderID], [ReferringProviderID], [MemberID], [ClaimNum], [EndServiceDateKey], [RequestedAmt], [PaidAmt], [VendorID], [SourceDesc], [SourceDataKey], [ClaimType]);


GO
CREATE NONCLUSTERED INDEX [IDX_BeginServiceDateKey]
    ON [dbo].[encounterclaimdim]([BeginServiceDateKey] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_ProviderID_MemberID_SourceDataKey_EndServiceDateKey]
    ON [dbo].[encounterclaimdim]([ProviderID] ASC, [MemberID] ASC, [SourceDataKey] ASC, [EndServiceDateKey] ASC)
    INCLUDE([ClaimNum], [BeginServiceDateKey], [ProcedureCode], [DX1], [DX2], [DX3], [DX4], [DX5], [DX6], [DX7], [DX8], [DX9], [DX10]);


GO
CREATE NONCLUSTERED INDEX [idx_encounter_test_ONLY]
    ON [dbo].[encounterclaimdim]([SourceDesc] ASC, [ClaimType] ASC, [ClaimFrequencyCode] ASC)
    INCLUDE([EncounterClaimKey], [ProviderID], [ReferringProviderID], [MemberID], [MedicareID], [PCPID], [PCPLastName], [PCPFirstName], [PCPMiddleName], [ClaimNum], [ProvTaxonomyCode], [ProvSpecialtyCode], [BillTypeCode], [DateReceivedKey], [DateEnteredKey], [AdmissionTypeCode], [AdmissionSourceCode], [DischargeStatusCode], [BeginServiceDateKey], [EndServiceDateKey], [PaidDateKey], [ReversedClaimNum], [Quantity], [DeniedServiceQuantity], [PlaceOfServiceCode], [RequestedAmt], [EligibleFeeAmt], [CoPayAmt], [CoInsuranceAmt], [DeductibleAmt], [COBAmt], [PaidAmt], [WithholdAmt], [MaxFeeAmt], [AdmissionDateKey], [AdmissionDiagnosisTypeCode], [ProcedureCode], [ModifierCode1], [ModifierCode2], [ModifierCode3], [ModifierCode4], [FederalTaxID], [VendorID], [VendorLastName], [VendorFirstName], [AdjustmentCode], [CheckNum], [RevenueCode], [DeniedReasonCode], [ICD9ProcedureCode1], [ICD9ProcedureDateKey1], [ICD9ProcedureCode2], [ICD9ProcedureDateKey2], [ICD9ProcedureCode3], [ICD9ProcedureDateKey3], [AuthorizationID], [ClaimLineNum], [DX1], [DiagQual1], [DX2], [DiagQual2], [DX3], [DiagQual3], [DX4], [DiagQual4], [DX5], [DiagQual5], [DX6], [DiagQual6], [DX7], [DiagQual7], [DX8], [DiagQual8], [DX9], [DiagQual9], [DX10], [DiagQual10], [TaxonomyCode], [ClaimLineStatus], [FileName], [SourceDataKey], [Active], [Deleted], [LoadDateKey], [EnterpriseID], [InpatientInd]);

