﻿CREATE TABLE [dbo].[CLAIMDETAILDIM] (
    [CLAIMID]                     VARCHAR (20)     NULL,
    [SOURCEDATAKEY]               INT              NULL,
    [ACTIVE]                      BIT              NULL,
    [DELETED]                     BIT              NULL,
    [LOADDATEKEY]                 INT              NULL,
    [ENTERPRISEID]                UNIQUEIDENTIFIER NULL,
    [CLAIMDETAILKEY]              BIGINT           NULL,
    [CLAIMLINEID]                 VARCHAR (5)      NULL,
    [VENDORTYPE]                  VARCHAR (15)     NULL,
    [VENDORID]                    VARCHAR (20)     NULL,
    [GLNUMBER]                    VARCHAR (10)     NULL,
    [FEECALCULATIONCODE]          VARCHAR (4)      NULL,
    [FEECALCULATIONDESC]          VARCHAR (100)    NULL,
    [PROCEDUREFEETABLE]           VARCHAR (6)      NULL,
    [PROVIDERPARTICIPATIONSTATUS] VARCHAR (1)      NULL,
    [PROVIDERCAPITATIONSTATUS]    VARCHAR (6)      NULL,
    [NONCAPPROCEDURELISTCODE]     VARCHAR (6)      NULL,
    [CPTGROUPCODE]                VARCHAR (7)      NULL,
    [DISCOUNTTABLEID]             VARCHAR (10)     NULL,
    [DISCOUNTAMT]                 MONEY            NULL,
    [DISCOUNTAMTINDICATOR]        VARCHAR (1)      NULL,
    [PRIMARYSPECIALTYCODE]        VARCHAR (15)     NULL,
    [CAPITATEDLINEFLAG]           VARCHAR (1)      NULL,
    [BENEFITCODE]                 VARCHAR (15)     NULL,
    [PAIDDATEKEY]                 INT              NULL,
    [BEGINSERVICEDATEKEY]         INT              NULL,
    [ENDSERVICEDATEKEY]           INT              NULL,
    [PAYMENTAMOUNT]               MONEY            NULL,
    [ORIGINALENTRYDATEKEY]        INT              NULL,
    [CHECKNUM]                    VARCHAR (12)     NULL,
    [CREDITSAVINGSAMT]            MONEY            NULL,
    [ITEMDISCOUNTAMT]             MONEY            NULL,
    [PROCEDURECODE]               VARCHAR (15)     NULL,
    [SERVICEPLACECODE]            VARCHAR (4)      NULL,
    [SERVICETYPECODE]             VARCHAR (4)      NULL,
    [QUANTITY]                    INT              NULL,
    [REQUESTEDAMT]                MONEY            NULL,
    [MAXFEEAMT]                   MONEY            NULL,
    [ELIGIBLEFEEAMT]              MONEY            NULL,
    [COBAMT]                      MONEY            NULL,
    [DEDUCTIBLEAMT]               MONEY            NULL,
    [COPAYAMT]                    MONEY            NULL,
    [MEMBERAGE]                   INT              NULL,
    [PROVIDERID]                  VARCHAR (20)     NULL,
    [PROVIDERNPI]                 VARCHAR (10)     NULL,
    [COINSURANCEAMT]              MONEY            NULL,
    [WITHHOLDAMT]                 MONEY            NULL,
    [MemberPaidAmt]               MONEY            NULL,
    [ClaimLineStatus]             VARCHAR (15)     NULL,
    [ContractID]                  VARCHAR (15)     NULL,
    [CoverageCodeID]              VARCHAR (15)     NULL,
    [FundID]                      VARCHAR (15)     NULL,
    [FundIDDesc]                  VARCHAR (60)     NULL,
    [LastUpdateDateKey]           INT              NULL,
    [ProductType]                 VARCHAR (10)     NULL,
    [DetailSourceType]            VARCHAR (1)      NULL
);




GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDim_Submissions_1]
    ON [dbo].[CLAIMDETAILDIM]([PROCEDURECODE] ASC)
    INCLUDE([CLAIMID]);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDim_Submissions_2]
    ON [dbo].[CLAIMDETAILDIM]([CLAIMID] ASC)
    INCLUDE([CLAIMLINEID], [PAYMENTAMOUNT], [QUANTITY], [REQUESTEDAMT], [COBAMT], [DEDUCTIBLEAMT], [COPAYAMT], [COINSURANCEAMT]);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDim_Submissions_3]
    ON [dbo].[CLAIMDETAILDIM]([COPAYAMT] ASC)
    INCLUDE([CLAIMID], [CLAIMLINEID], [QUANTITY]);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDim_Submissions_4]
    ON [dbo].[CLAIMDETAILDIM]([COINSURANCEAMT] ASC)
    INCLUDE([CLAIMID], [CLAIMLINEID], [QUANTITY]);


GO
CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDim_ClaimID_SDK_ClaimLineID]
    ON [dbo].[CLAIMDETAILDIM]([CLAIMID] ASC, [SOURCEDATAKEY] ASC, [CLAIMLINEID] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_NPI_CLAIMID_SOURCEDATAKEY]
    ON [dbo].[CLAIMDETAILDIM]([CLAIMID] ASC, [SOURCEDATAKEY] ASC, [PROVIDERNPI] ASC);

