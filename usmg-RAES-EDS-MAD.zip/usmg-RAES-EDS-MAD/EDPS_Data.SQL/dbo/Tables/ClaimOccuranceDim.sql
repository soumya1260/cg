﻿CREATE TABLE [dbo].[ClaimOccuranceDim] (
    [UB923OccuranceKey]    INT              NOT NULL,
    [ClaimID]              VARCHAR (20)     NOT NULL,
    [OccuranceCode]        VARCHAR (3)      NOT NULL,
    [OccuranceFromDateKey] INT              NOT NULL,
    [OccuranceToDateKey]   INT              NOT NULL,
    [LastUpdateDateKey]    INT              NOT NULL,
    [SourceDataKey]        INT              NOT NULL,
    [Active]               BIT              NOT NULL,
    [Deleted]              BIT              NOT NULL,
    [LoadDateKey]          INT              NOT NULL,
    [EnterpriseID]         UNIQUEIDENTIFIER NOT NULL,
    [SpanRecord]           CHAR (1)         NULL
);

