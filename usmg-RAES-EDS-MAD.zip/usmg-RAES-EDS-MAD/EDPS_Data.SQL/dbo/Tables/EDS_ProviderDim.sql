﻿CREATE TABLE [dbo].[EDS_ProviderDim] (
    [RecordSource]                  CHAR (1)      NULL,
    [ProviderID]                    VARCHAR (20)  NULL,
    [ProviderGroupID]               VARCHAR (20)  NULL,
    [ProviderTypeCode]              VARCHAR (15)  NULL,
    [ProviderStatus]                VARCHAR (10)  NULL,
    [GlobalCurrentPatientLoad]      VARCHAR (5)   NULL,
    [AdditionalBusinessName]        VARCHAR (35)  NULL,
    [PrimaryBusinessName]           VARCHAR (90)  NULL,
    [FullName]                      VARCHAR (95)  NULL,
    [ReverseFullName]               VARCHAR (95)  NULL,
    [LastName]                      VARCHAR (60)  NULL,
    [FirstName]                     VARCHAR (40)  NULL,
    [MiddleName]                    VARCHAR (30)  NULL,
    [Title]                         VARCHAR (15)  NULL,
    [GlobalPanelSize]               VARCHAR (5)   NULL,
    [NewPatientFlag]                CHAR (1)      NULL,
    [DeaNumber]                     VARCHAR (10)  NULL,
    [Gender]                        CHAR (1)      NULL,
    [DOBDateKey]                    INT           NULL,
    [UPIN]                          VARCHAR (20)  NULL,
    [FIDN]                          VARCHAR (25)  NULL,
    [NPID]                          VARCHAR (10)  NULL,
    [MedicaidID]                    VARCHAR (20)  NULL,
    [MedicareID]                    VARCHAR (20)  NULL,
    [HandicapAccess]                VARCHAR (1)   NULL,
    [CredentialingStatus]           VARCHAR (15)  NULL,
    [ProvCategory]                  VARCHAR (15)  NULL,
    [LicenseTypeCode]               CHAR (1)      NULL,
    [LeasedStatusCode]              CHAR (1)      NULL,
    [PreferredStatusCode]           CHAR (1)      NULL,
    [ChildFlg]                      CHAR (1)      NULL,
    [YouthFlg]                      CHAR (1)      NULL,
    [AdultFlg]                      CHAR (1)      NULL,
    [StandardHoursInd]              CHAR (1)      NULL,
    [AfterHoursInd]                 CHAR (1)      NULL,
    [WeekendHoursInd]               CHAR (1)      NULL,
    [SourceDataKey]                 INT           NULL,
    [ProviderType_ProviderTypeDesc] VARCHAR (60)  NULL,
    [Ingenix_TaxonomyCode]          VARCHAR (10)  NULL,
    [Ingenix_SpecialtyName]         VARCHAR (60)  NULL,
    [Ingenix_SpecialtyGroupName]    VARCHAR (60)  NULL,
    [Vendor_VendorID]               VARCHAR (20)  NULL,
    [Vendor_VendorTypeCode]         VARCHAR (15)  NULL,
    [Vendor_VendorCategory]         VARCHAR (4)   NULL,
    [Vendor_NationalProviderID]     VARCHAR (10)  NULL,
    [Vendor_FederalID]              VARCHAR (25)  NULL,
    [Vendor_VendorName]             VARCHAR (100) NULL,
    [Vendor_LastName]               VARCHAR (60)  NULL,
    [Vendor_FirstName]              VARCHAR (70)  NULL,
    [Vendor_AddressLine1]           VARCHAR (60)  NULL,
    [Vendor_AddressLine2]           VARCHAR (60)  NULL,
    [Vendor_Phone]                  VARCHAR (20)  NULL,
    [Vendor_City]                   VARCHAR (40)  NULL,
    [Vendor_State]                  VARCHAR (2)   NULL,
    [Vendor_Zip]                    VARCHAR (11)  NULL
);


GO
CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_FIDN_NPID]
    ON [dbo].[EDS_ProviderDim]([FIDN] ASC, [NPID] ASC);


GO
CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_NPID_DeaNumber]
    ON [dbo].[EDS_ProviderDim]([NPID] ASC, [DeaNumber] ASC);


GO
CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_NPID_INC_UPINFullReverseLastFirstMiddleNames]
    ON [dbo].[EDS_ProviderDim]([NPID] ASC)
    INCLUDE([FirstName], [FullName], [LastName], [MiddleName], [ReverseFullName], [UPIN]);


GO
CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_NPID_UPIN]
    ON [dbo].[EDS_ProviderDim]([NPID] ASC, [UPIN] ASC);


GO
CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_ProviderExtract1]
    ON [dbo].[EDS_ProviderDim]([ProviderTypeCode] ASC)
    INCLUDE([ProviderID], [SourceDataKey], [Vendor_AddressLine1], [Vendor_AddressLine2], [Vendor_City], [Vendor_State], [Vendor_Zip]);


GO
CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_ProviderID_SourceDataKey_INC_FullReverseLastFirstMiddleNames]
    ON [dbo].[EDS_ProviderDim]([ProviderID] ASC, [SourceDataKey] ASC)
    INCLUDE([FirstName], [FullName], [LastName], [MiddleName], [ReverseFullName]);


GO
CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_Vendor_FederalID_INC_FIDN]
    ON [dbo].[EDS_ProviderDim]([Vendor_FederalID] ASC)
    INCLUDE([FIDN]);

