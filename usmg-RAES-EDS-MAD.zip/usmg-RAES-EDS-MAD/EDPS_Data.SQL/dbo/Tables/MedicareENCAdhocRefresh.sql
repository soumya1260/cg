﻿CREATE TABLE [dbo].[MedicareENCAdhocRefresh] (
    [ClaimID]       VARCHAR (50) NULL,
    [SourceDataKey] INT          NULL
);


GO
CREATE CLUSTERED INDEX [ENCAdhoc_ClaimSDK]
    ON [dbo].[MedicareENCAdhocRefresh]([ClaimID] ASC, [SourceDataKey] ASC);

