﻿CREATE TABLE [dbo].[ProviderDim] (
    [ProviderID]                          VARCHAR (20) NULL,
    [ProviderTypeCode]                    VARCHAR (15) NULL,
    [ProviderStatus]                      VARCHAR (10) NULL,
    [GlobalCurrentPatientLoad]            VARCHAR (5)  NULL,
    [AdditionalBusinessName]              VARCHAR (35) NULL,
    [PrimaryBusinessName]                 VARCHAR (90) NULL,
    [FullName]                            VARCHAR (95) NULL,
    [ReverseFullName]                     VARCHAR (95) NULL,
    [LastName]                            VARCHAR (60) NULL,
    [FirstName]                           VARCHAR (40) NULL,
    [MiddleName]                          VARCHAR (30) NULL,
    [Title]                               VARCHAR (15) NULL,
    [GlobalPanelSize]                     VARCHAR (5)  NULL,
    [NewPatientFlag]                      CHAR (1)     NULL,
    [DeaNumber]                           VARCHAR (10) NULL,
    [Gender]                              CHAR (1)     NULL,
    [DOBDateKey]                          INT          NULL,
    [UPIN]                                VARCHAR (20) NULL,
    [FIDN]                                VARCHAR (25) NULL,
    [NPID]                                VARCHAR (10) NULL,
    [MedicaidID]                          VARCHAR (20) NULL,
    [MedicareID]                          VARCHAR (20) NULL,
    [HandicapAccess]                      VARCHAR (1)  NULL,
    [CredentialingStatus]                 VARCHAR (15) NULL,
    [ProvCategory]                        VARCHAR (15) NULL,
    [LicenseTypeCode]                     CHAR (1)     NULL,
    [LeasedStatusCode]                    CHAR (1)     NULL,
    [PreferredStatusCode]                 CHAR (1)     NULL,
    [ChildFlg]                            CHAR (1)     NULL,
    [YouthFlg]                            CHAR (1)     NULL,
    [AdultFlg]                            CHAR (1)     NULL,
    [StandardHoursInd]                    CHAR (1)     NULL,
    [AfterHoursInd]                       CHAR (1)     NULL,
    [WeekendHoursInd]                     CHAR (1)     NULL,
    [SourceDataKey]                       INT          NULL,
    [ProviderType_ProviderTypeDesc]       VARCHAR (60) NULL,
    [ProviderGroup_ProviderGroupID]       VARCHAR (20) NULL,
    [ProviderGroup_ProviderTypeCode]      VARCHAR (4)  NULL,
    [ProviderGroup_BeginCoverageDateKey]  INT          NULL,
    [ProviderGroup_EndCoverageDateKey]    INT          NULL,
    [ProviderGroup_TerminationReasonCode] VARCHAR (4)  NULL
);




GO
CREATE NONCLUSTERED INDEX [idx_Filter_ProviderStatus]
    ON [dbo].[ProviderDim]([ProviderStatus] ASC)
    INCLUDE([NPID], [ProviderID]) WHERE ([ProviderStatus]='Active');


GO
CREATE CLUSTERED INDEX [idx_ProviderID_NPID]
    ON [dbo].[ProviderDim]([ProviderID] ASC, [NPID] ASC);

