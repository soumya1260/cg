﻿CREATE TABLE [dbo].[MIPSAdjustmentValuesClaimDim] (
    [claimid]       CHAR (15)     NULL,
    [claimline]     INT           NULL,
    [contractpaid]  MONEY         NULL,
    [MIPS_Amount]   MONEY         NULL,
    [createid]      VARCHAR (120) NULL,
    [createdate]    DATETIME      NULL,
    [updateid]      VARCHAR (120) NULL,
    [lastupdate]    DATETIME      NULL,
    [SourceDatakey] INT           NULL,
    [ACTIVE]        BIT           NULL,
    [DELETED]       BIT           NULL,
    [LoadDateKey]   INT           NULL
);


GO
CREATE NONCLUSTERED INDEX [NIX_MIPSAdjustmentValuesClaimDim_1]
    ON [dbo].[MIPSAdjustmentValuesClaimDim]([claimid] ASC, [SourceDatakey] ASC);

