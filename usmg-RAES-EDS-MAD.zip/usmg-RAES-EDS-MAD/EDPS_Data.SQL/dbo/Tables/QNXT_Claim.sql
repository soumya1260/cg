﻿CREATE TABLE [dbo].[QNXT_Claim] (
    [claimid]       CHAR (15)     NOT NULL,
    [reason]        CHAR (30)     NULL,
    [Frequencycode] CHAR (1)      NULL,
    [Plancrn]       CHAR (30)     NULL,
    [Adjuddate]     SMALLDATETIME NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20171128-161345]
    ON [dbo].[QNXT_Claim]([claimid] ASC);

