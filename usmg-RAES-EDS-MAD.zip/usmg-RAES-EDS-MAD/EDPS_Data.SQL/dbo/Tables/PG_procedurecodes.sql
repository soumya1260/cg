﻿CREATE TABLE [dbo].[PG_procedurecodes] (
    [ProcedureCode] VARCHAR (MAX) NULL,
    [cnt]           INT           NULL
);

