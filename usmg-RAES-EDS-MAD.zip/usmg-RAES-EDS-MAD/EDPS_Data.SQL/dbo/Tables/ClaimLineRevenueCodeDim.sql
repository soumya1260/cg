﻿CREATE TABLE [dbo].[ClaimLineRevenueCodeDim] (
    [ClaimLineRevenueCodeKey] BIGINT           NULL,
    [ClaimID]                 VARCHAR (20)     NULL,
    [ClaimLineID]             VARCHAR (5)      NULL,
    [RevenueCode]             VARCHAR (5)      NULL,
    [ProcedureCode]           VARCHAR (15)     NULL,
    [ServiceDateKey]          INT              NULL,
    [Quantity]                INT              NULL,
    [Charges]                 MONEY            NULL,
    [LastUpdateKey]           INT              NULL,
    [SourceDataKey]           INT              NULL,
    [Active]                  BIT              NULL,
    [Deleted]                 BIT              NULL,
    [LoadDateKey]             INT              NULL,
    [EnterpriseID]            UNIQUEIDENTIFIER NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20180111-141414]
    ON [dbo].[ClaimLineRevenueCodeDim]([ClaimID] ASC);

