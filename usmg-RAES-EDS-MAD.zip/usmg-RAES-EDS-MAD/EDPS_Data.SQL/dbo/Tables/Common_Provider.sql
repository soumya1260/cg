﻿CREATE TABLE [dbo].[Common_Provider] (
    [ProviderID]    VARCHAR (50)  NOT NULL,
    [FullName]      VARCHAR (100) NULL,
    [LastName]      VARCHAR (75)  NULL,
    [FirstName]     VARCHAR (50)  NULL,
    [Title]         VARCHAR (50)  NULL,
    [MarketID]      INT           NULL,
    [ReportAreaKey] INT           NULL,
    [Par]           BIT           NULL,
    [POD]           VARCHAR (50)  NULL,
    [Phone]         VARCHAR (50)  NULL,
    [Fax]           VARCHAR (50)  NULL,
    [IsPCP]         BIT           NULL,
    [SpecCode]      VARCHAR (50)  NULL,
    [Keep]          VARCHAR (50)  NULL,
    [LoadDate]      DATETIME      NULL,
    [IsP4Q]         BIT           NULL,
    [ReportPOD]     VARCHAR (50)  NULL,
    [ModifiedDate]  DATETIME      NULL,
    [ProviderNPI]   VARCHAR (50)  NULL,
    [Source]        VARCHAR (50)  NULL,
    CONSTRAINT [PK_Common_Provider] PRIMARY KEY CLUSTERED ([ProviderID] ASC) WITH (FILLFACTOR = 90)
);

