﻿CREATE TABLE [dbo].[ProviderPodDim] (
    [ProviderPodKey]    INT          NULL,
    [ProviderID]        VARCHAR (20) NULL,
    [PodCode]           VARCHAR (15) NULL,
    [EffectiveDateKey]  INT          NULL,
    [ExpirationDateKey] INT          NULL,
    [RegionCode]        VARCHAR (10) NULL,
    [ProviderTypeCode]  VARCHAR (15) NULL,
    [VendorID]          VARCHAR (20) NULL,
    [Description]       VARCHAR (95) NULL,
    [RptPodDesc]        VARCHAR (50) NULL,
    [SourceDataKey]     INT          NULL,
    [Active]            BIT          NULL,
    [Deleted]           BIT          NULL,
    [LoadDateKey]       INT          NULL
);


GO
CREATE NONCLUSTERED INDEX [IDX_ProviderPodDim]
    ON [dbo].[ProviderPodDim]([ProviderID] ASC);


GO
CREATE NONCLUSTERED INDEX [idx_PodCode]
    ON [dbo].[ProviderPodDim]([PodCode] ASC)
    INCLUDE([ProviderID], [EffectiveDateKey], [ExpirationDateKey], [VendorID]);

