﻿CREATE TABLE [dbo].[EDS_ENCOUNTERS_CLAIMSTARTDATE] (
    [ClaimStartDate] VARCHAR (8)  NULL,
    [LastUpdateDate] VARCHAR (8)  NULL,
    [UpDateBy]       VARCHAR (15) NULL
);

