﻿CREATE TABLE [dbo].[SourceDataDim] (
    [SourceDataKey] INT              NOT NULL,
    [SourceDesc]    VARCHAR (350)    NOT NULL,
    [Active]        BIT              NOT NULL,
    [Deleted]       BIT              NOT NULL,
    [LoadDateKey]   INT              NOT NULL,
    [EnterpriseID]  UNIQUEIDENTIFIER NOT NULL
);

