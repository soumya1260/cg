﻿CREATE TABLE [dbo].[MDQOMemberXWalk] (
    [MDQOMemberXWalkID]          INT           NOT NULL,
    [MDQOMemberID]               VARCHAR (20)  NOT NULL,
    [SourceMemberID]             VARCHAR (30)  NOT NULL,
    [SourceDataKey]              INT           NOT NULL,
    [SourceRecordTypeID]         INT           NOT NULL,
    [SourceHICNo]                VARCHAR (25)  NULL,
    [SourceDOB]                  INT           NULL,
    [SourceBeginCoverageDateKey] INT           NULL,
    [ReportingMemberID]          VARCHAR (30)  NULL,
    [RecordEffectiveBeginDate]   DATETIME      NULL,
    [RecordEffectiveEndDate]     DATETIME      NULL,
    [CreatedBy]                  VARCHAR (100) NOT NULL,
    [IsActive]                   BIT           NULL
);

