﻿
 
 
	CREATE PROCEDURE [dbo].[usp_CMSMemberMedicareIDXref_Load] 
 
	AS
 
	/*********************************************************************************************************************************************
		Created Date: 09/01/2020
		Author: Noe E Leiva
		Description: Load CMSMemberMedicareIDXref_Load Table
		Parameters: 
		Modification History:
		Date            Developer            Description
		2020-09-01      Noe Leiva            TETDM 2317 SP Creation
		2022-09-13      Henry Faust          RETM-120 correct login FOR
		                    INSERT INTO WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG
	*********************************************************************************************************************************************/
 
	BEGIN
 
		SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
		SET NOCOUNT ON
 		
		DECLARE @SOURCE VARCHAR(4)
				,@PROCNAME VARCHAR(100)
				,@STEPNAME VARCHAR(100)
				,@DASH VARCHAR(3)
				,@TOTAL_RECORDS INT
				,@CURRENT_DT DATETIME -- this might need to be datetime
				,@STEP_CNT INT = 0


		SET @CURRENT_DT = GETDATE() 

		SET @PROCNAME = 'usp_CMSMemberMedicareIDXref_Load'
		SET @DASH = ' - '
		SET @STEPNAME = ':BEGIN'

		
		DECLARE @SYS_RUNLOG TABLE			-- RTD 3374
		(
			[PROC_NAME] [varchar](75) NULL,
			[STEP] [varchar](15) NULL,
			[START_DT] [datetime] NULL,
			[END_DT] [datetime] NULL,
			[RUN_MINUTES] [int] NULL,
			[TOTAL_RECORDS] [int] NULL,
			[ENTRYDT] [datetime] NULL
		)

	
		BEGIN TRY
		BEGIN TRANSACTION 


			SET @STEP_CNT = @STEP_CNT + 1

			INSERT INTO @SYS_RUNLOG
			(
				PROC_NAME
				,STEP
				,START_DT
				,END_DT
				,RUN_MINUTES
				,TOTAL_RECORDS
				,ENTRYDT
			)
			VALUES
			(
				(@PROCNAME+@STEPNAME)
				,CONVERT(VARCHAR(2),@STEP_CNT)
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
			)


			IF OBJECT_ID('DBO.CMSMemberMedicareIDXref') IS NOT NULL
				TRUNCATE TABLE DBO.CMSMemberMedicareIDXref;


			IF OBJECT_ID('WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG') IS NOT NULL
				TRUNCATE TABLE WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG;



--RETM-120 begin
 		--	INSERT INTO WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG
			--(
			--	MemberID,
			--	HCFACode,
			--	HICN,
			--	MBI,
			--	LastName,
			--	FirstName,
			--	DateOfBirthKey,
			--	DateOfDeathKey,
			--	Gender,
			--	RecentEnrollmentDateKey,
			--	RecentDisenrollmentDateKey,
			--	SequenceCode,
			--	LoadDateKey,
			--	Active,
			--	Deleted,
			--	SourceDataKey,
			--	ValidateColStartsWithZero
			--) 




			--SELECT RETM-120 old
			--	DISTINCT
			--	A.MemberID,
			--	B.ContractNumber HCFACode,

			--	-- Validate the second character is not a letter
			--	CASE WHEN ( SUBSTRING(A.MedicareID,2,1) NOT LIKE '[a-zA-Z]' AND COALESCE(A.MedicareID, '') NOT IN ('','THAT','UNKNOWN') ) THEN A.MedicareID ELSE '' END HICN,

			--	-- Validate the second character is a letter
			--	CASE WHEN ( SUBSTRING(A.MedicareID,2,1) LIKE '[a-zA-Z]' AND COALESCE(A.MedicareID, '') NOT IN ('','THAT','UNKNOWN') ) THEN A.MedicareID ELSE '' END MBI,

			--	LTRIM(RTRIM(A.LastName)) LastName,
			--	LTRIM(RTRIM(A.FirstName)) FirstName,
			--	CONVERT(INT,CONVERT(VARCHAR(8),A.DOBDateKey,112)) DateOfBirthKey,
			--	0 DateOfDeathKey,
			--	A.Gender,

			--	MIN(CONVERT(INT,CONVERT(VARCHAR(8),B.EligStartDate,112))) OVER (PARTITION BY B.MEMBERID, B.CONTRACTNUMBER) RecentEnrollmentDateKey,
			--	MAX(CONVERT(INT,CONVERT(VARCHAR(8),B.EligEndDate,112))) OVER (PARTITION BY B.MEMBERID, B.CONTRACTNUMBER) RecentDisenrollmentDateKey,

			--	CASE WHEN A.ACTIVE = 1 THEN A.ACTIVE ELSE 2 END SequenceCode,
			--	CONVERT(INT,CONVERT(VARCHAR(8),GETDATE(),112)) LoadDateKey,
			--	A.Active,
			--	A.Deleted,
			--	SourceDataKey, 

			--	 -- Logic to validate if Member ID starts with 0
			--	CASE 
			--		WHEN ISNUMERIC(REPLACE(A.MEMBERID,'*','')) = 1 THEN CONVERT(INT,LEFT(A.MEMBERID, 1))
			--		ELSE 5 -- Non Numeric as default to 5
			--	END ValidateColStartsWithZero -- We will exclude anything that comes back with a 0

			--FROM [MDQOLib].[dbo].[MemberDim] A
			--LEFT JOIN MDQOLib.DBO.MemberEligibility B
			--	ON B.Memberid = A.MemberID
			--	AND B.ContractNumber LIKE 'H%'
			--WHERE A.DELETED = 0 -- 20200811 Request
---------------
	IF OBJECT_ID('TEMPDB..#MBI_cte') <> 0
	DROP TABLE #MBI_cte
	IF OBJECT_ID('TEMPDB..#HICN_cte') <> 0
	DROP TABLE #HICN_cte
-------------------------
--	DROP TABLE #MBI_cte
create  TABLE #MBI_cte
		(
			[MemberID] [varchar](16) NULL,
			[MBI] [varchar](20) NULL
		)
CREATE NONCLUSTERED INDEX [IDX_MBI_cte] ON #MBI_cte
(
	[MemberID] ASC,
	[MBI] ASC
)

create TABLE  #HICN_cte			
		(
			[MemberID] [varchar](16) NULL,
			[HICN] [varchar](20) NULL
		)
CREATE NONCLUSTERED INDEX [IDX_HICN_cte] ON #HICN_cte
(
	[MemberID] ASC,
	[HICN] ASC
)


insert into #MBI_cte
select distinct a.MemberID,  A.MedicareID as MBI
 
	  from [MDQOLib].[dbo].[MemberDim] A
				LEFT JOIN MDQOLib.DBO.MemberEligibility B
					ON B.Memberid = A.MemberID
					AND B.ContractNumber LIKE 'H%'
				WHERE A.DELETED = 0 
				and substring(a.medicareid,1,1) between '0' and '9'
				 and SUBSTRING(a.MedicareID,2,1) LIKE '[a-zA-Z]'

--select * from #MBI_cte
insert into #HICN_cte
select distinct a.MemberID,  A.MedicareID as HICN--, len(A.MedicareID) lenx, substring(a.medicareid,1,1), ISNUMERIC(substring(a.medicareid,1,1))
  from [MDQOLib].[dbo].[MemberDim] A
			LEFT JOIN MDQOLib.DBO.MemberEligibility B
				ON B.Memberid = A.MemberID
				AND B.ContractNumber LIKE 'H%'
			WHERE A.DELETED = 0 
			 and SUBSTRING(a.MedicareID,2,1) not LIKE '[a-zA-Z]'

----------------------------------------------------------------------

INSERT INTO WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG
(
	MemberID,
	HCFACode,
	HICN,
	MBI,
	LastName,
	FirstName,
	DateOfBirthKey,
	DateOfDeathKey,
	Gender,
	RecentEnrollmentDateKey,
	RecentDisenrollmentDateKey,
	SequenceCode,
	LoadDateKey,
	Active,
	Deleted,
	SourceDataKey,
	ValidateColStartsWithZero
) 
		select distinct -- * 
						A.MemberID,
						B.ContractNumber as HCFACode,
						 --Validate the second character is not a letter
						case when h.hicn is NULL then '' else h.hicn end as HICN,
						 --Validate the second character is a letter
						case when m.mbi is null then '' else m.mbi end as MBI,
						LTRIM(RTRIM(A.LastName)) LastName,
						LTRIM(RTRIM(A.FirstName)) FirstName
						,
						CONVERT(INT,CONVERT(VARCHAR(8),A.DOBDateKey,112)) DateOfBirthKey,
						0 DateOfDeathKey,
						A.Gender,

						MIN(CONVERT(INT,CONVERT(VARCHAR(8),B.EligStartDate,112))) OVER (PARTITION BY B.MEMBERID, B.CONTRACTNUMBER) RecentEnrollmentDateKey,
						MAX(CONVERT(INT,CONVERT(VARCHAR(8),B.EligEndDate,112))) OVER (PARTITION BY B.MEMBERID, B.CONTRACTNUMBER) RecentDisenrollmentDateKey,

						CASE WHEN A.ACTIVE = 1 THEN A.ACTIVE ELSE 2 END SequenceCode,
						CONVERT(INT,CONVERT(VARCHAR(8),GETDATE(),112)) LoadDateKey,
						A.Active,
						A.Deleted,
						SourceDataKey, 

						  --Logic to validate if Member ID starts with 0
						CASE 
							WHEN ISNUMERIC(REPLACE(A.MEMBERID,'*','')) = 1 THEN CONVERT(INT,LEFT(A.MEMBERID, 1))
							ELSE 5 -- Non Numeric as default to 5
						END ValidateColStartsWithZero -- We will exclude anything that comes back with a 0

		FROM [MDQOLib].[dbo].[MemberDim] A
		LEFT JOIN MDQOLib.DBO.MemberEligibility B
			ON B.Memberid = A.MemberID
			AND B.ContractNumber LIKE 'H%'
		left join #MBI_cte m on m.memberid = a.MemberID
		left join #HICN_cte h on h.memberid = a.MemberID





--RETM-120 end
------------------------------------------------------------------------------------------------------------------------
			SET @TOTAL_RECORDS = (SELECT COUNT(1) FROM WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG)

			UPDATE A
				SET END_DT = GETDATE()	
					,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
					,TOTAL_RECORDS = @TOTAL_RECORDS
					,ENTRYDT = GETDATE()
			FROM @SYS_RUNLOG A
			WHERE PROC_NAME = @PROCNAME+@STEPNAME
			AND END_DT IS NULL	


			SET @STEPNAME = ':Update_PBPCode'

			SET @STEP_CNT = @STEP_CNT + 1

			INSERT INTO @SYS_RUNLOG
			(
				PROC_NAME
				,STEP
				,START_DT
				,END_DT
				,RUN_MINUTES
				,TOTAL_RECORDS
				,ENTRYDT
			)
			VALUES
			(
				(@PROCNAME+@STEPNAME)
				,CONVERT(VARCHAR(2),@STEP_CNT)
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
			)

			-- Update PBPCode
			UPDATE A
				SET PBPCode = B.PBP
			FROM WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG A
			JOIN MDQOLib.DBO.MMR B
				ON B.MEM_ID = A.MemberID
				AND B.[Plan] = A.HCFACode


			SET @TOTAL_RECORDS = @@ROWCOUNT

			UPDATE A
				SET END_DT = GETDATE()	
					,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
					,TOTAL_RECORDS = @TOTAL_RECORDS
					,ENTRYDT = GETDATE()
			FROM @SYS_RUNLOG A
			WHERE PROC_NAME = @PROCNAME+@STEPNAME
			AND END_DT IS NULL	



			-- HICN update where Medicare Number is not THAT or UNKNOWN
			-- and if second character is not a Letter

			SET @STEPNAME = ':Update_HICN'

			SET @STEP_CNT = @STEP_CNT + 1

			INSERT INTO @SYS_RUNLOG
			(
				PROC_NAME
				,STEP
				,START_DT
				,END_DT
				,RUN_MINUTES
				,TOTAL_RECORDS
				,ENTRYDT
			)
			VALUES
			(
				(@PROCNAME+@STEPNAME)
				,CONVERT(VARCHAR(2),@STEP_CNT)
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
			)


			UPDATE A
				SET HICN = B.Medicare
			FROM WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG A
			JOIN [MDQOLib]. [dbo].[MMR] B
				ON B.MEM_ID = A.MemberID
				AND B.[Plan] = A.HCFACode
				-- Disenrollment and not End Date
				AND B.Pymt_Adj_Beg BETWEEN A.RecentEnrollmentDateKey AND A.RecentDisenrollmentDateKey 
			WHERE COALESCE(A.HICN,'') = ''
			AND SUBSTRING(B.Medicare,2,1) NOT LIKE '[a-zA-Z]'
			AND COALESCE(B.Medicare, '') NOT IN ('','THAT','UNKNOWN')


			UPDATE A
				SET HICN = B.MedicareID
			FROM WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG A
			JOIN [EDPS_Data].[dbo].[MemberHICNXref] B
				ON B.MemberID = A.MemberID
			WHERE COALESCE(A.HICN,'') = ''
			AND SUBSTRING(B.MedicareID,2,1) NOT LIKE '[a-zA-Z]'
			AND COALESCE(B.MedicareId, '') NOT IN ('','THAT','UNKNOWN')


			SET @TOTAL_RECORDS = @@ROWCOUNT

			UPDATE A
				SET END_DT = GETDATE()	
					,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
					,TOTAL_RECORDS = @TOTAL_RECORDS
					,ENTRYDT = GETDATE()
			FROM @SYS_RUNLOG A
			WHERE PROC_NAME = @PROCNAME+@STEPNAME
			AND END_DT IS NULL	


			-- MBI update where Medicare Number is not THAT or UNKNOWN
			-- and if second character is a Letter
			SET @STEPNAME = ':Update_HICN'

			SET @STEP_CNT = @STEP_CNT + 1

			INSERT INTO @SYS_RUNLOG
			(
				PROC_NAME
				,STEP
				,START_DT
				,END_DT
				,RUN_MINUTES
				,TOTAL_RECORDS
				,ENTRYDT
			)
			VALUES
			(
				(@PROCNAME+@STEPNAME)
				,CONVERT(VARCHAR(2),@STEP_CNT)
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
			)


			UPDATE A
				SET MBI = B.Medicare
			FROM WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG A
			JOIN [MDQOLib]. [dbo].[MMR] B
				ON B.MEM_ID = A.MemberID
				AND B.[Plan] = A.HCFACode
				-- Disenrollment and not End Date
				AND B.Pymt_Adj_Beg BETWEEN A.RecentEnrollmentDateKey AND A.RecentDisenrollmentDateKey 
			WHERE COALESCE(A.MBI,'') = ''
			AND SUBSTRING(B.Medicare,2,1) LIKE '[a-zA-Z]'
			AND COALESCE(B.Medicare, '') NOT IN ('','THAT','UNKNOWN')


			UPDATE A
				SET MBI = B.MedicareID
			FROM WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG A
			JOIN [EDPS_Data].[dbo].[MemberHICNXref] B
				ON B.MemberID = A.MemberID
			WHERE COALESCE(A.MBI,'') = ''
			AND SUBSTRING(B.MedicareID,2,1) LIKE '[a-zA-Z]'
			AND COALESCE(B.MedicareId, '') NOT IN ('','THAT','UNKNOWN')


			SET @TOTAL_RECORDS = @@ROWCOUNT

			UPDATE A
				SET END_DT = GETDATE()	
					,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
					,TOTAL_RECORDS = @TOTAL_RECORDS
					,ENTRYDT = GETDATE()
			FROM @SYS_RUNLOG A
			WHERE PROC_NAME = @PROCNAME+@STEPNAME
			AND END_DT IS NULL	


			-- Capture only the Member ID and HCFA Code with the Oldest Enrollment Date and Latest Disenrollment Date
			;WITH CTE AS
			(
				SELECT 
					ROW_NUMBER() OVER (PARTITION BY MemberID, HCFACode ORDER BY RecentEnrollmentDateKey DESC,RecentDisenrollmentDateKey DESC) ROWNUM,
					MemberID
					,HCFACode
					,PBPCode
					,HICN
					,MBI
					,LastName
					,FirstName
					,DateOfBirthKey
					,DateOfDeathKey
					,Gender
					,RecentEnrollmentDateKey
					,RecentDisenrollmentDateKey
					,SequenceCode
					,LoadDateKey
					,Active
					,Deleted
					,CASE WHEN SourceDataKey = 2 THEN 50 ELSE SourceDataKey END SourceDataKey
				FROM WIPRO_STAGING.STAGING.CMSMemberMedicareIDXref_STG
				WHERE validateColStartsWithZero <> 0 -- Need to only include anything that is not a ValidateColStartsWithZero 0

			)
			INSERT INTO [dbo].CMSMemberMedicareIDXref
			(
				CMSMemberMedicareIDXrefKey
				,[MemberID]
				,[HCFACode]
				,[PBPCode]
				,[HICN]
				,[MBI]
				,[LastName]
				,[FirstName]
				,[DateOfBirthKey]
				,[DateOfDeathKey]
				,[Gender]
				,[RecentEnrollmentDateKey]
				,[RecentDisenrollmentDateKey]
				,[SequenceCode]
				,[LoadDateKey]
				,[Active]
				,[Deleted]
				,[SourceDataKey]
			)
			SELECT
				ROW_NUMBER() OVER(ORDER BY MemberID) CMSMemberMedicareIDXrefKey
				,[MemberID]
				,[HCFACode]
				,[PBPCode]
				,CONVERT(VARCHAR(12),[HICN]) HICN
				,CONVERT(VARCHAR(11),[MBI]) MBI
				,CONVERT(VARCHAR(30),[LastName]) LastName
				,CONVERT(VARCHAR(12),[FirstName]) FirstName
				,[DateOfBirthKey]
				,[DateOfDeathKey]
				,[Gender]
				,[RecentEnrollmentDateKey]
				,[RecentDisenrollmentDateKey]
				,[SequenceCode]
				,[LoadDateKey]
				,[Active]
				,[Deleted]
				,SourceDataKey
			FROM CTE
			WHERE ROWNUM = 1


			INSERT INTO dbo.EXT_SYS_RUNLOG
			(
				[PROC_NAME]
				,[STEP]
				,[START_DT]
				,[END_DT]
				,[RUN_MINUTES]
				,[TOTAL_RECORDS]
				,[ENTRYDT]
			)
			SELECT
				[PROC_NAME]
				,[STEP]
				,[START_DT]
				,[END_DT]
				,[RUN_MINUTES]
				,[TOTAL_RECORDS]
				,[ENTRYDT]
			FROM @SYS_RUNLOG

			COMMIT TRANSACTION

		END TRY

		BEGIN CATCH

			IF @@TRANCOUNT > 0
			BEGIN
			
				ROLLBACK

				SET @STEPNAME = ':SP_Failed'

				INSERT INTO @SYS_RUNLOG
				(
					PROC_NAME
					,STEP
					,START_DT
					,END_DT
					,RUN_MINUTES
					,TOTAL_RECORDS
					,ENTRYDT
				)
				VALUES
				(
					(@PROCNAME+@STEPNAME)
					,'0'
					,GETDATE()
					,GETDATE()
					,NULL
					,0
					,GETDATE()
				)


				INSERT INTO dbo.EXT_SYS_RUNLOG
				(
					[PROC_NAME]
					,[STEP]
					,[START_DT]
					,[END_DT]
					,[RUN_MINUTES]
					,[TOTAL_RECORDS]
					,[ENTRYDT]
				)
				SELECT
					[PROC_NAME]
					,[STEP]
					,[START_DT]
					,[END_DT]
					,[RUN_MINUTES]
					,[TOTAL_RECORDS]
					,[ENTRYDT]
				FROM @SYS_RUNLOG


				DECLARE @MESSAGE VARCHAR(MAX)

				SET @MESSAGE = (
									SELECT  
										'Error Number: ' + CONVERT(VARCHAR(MAX),ERROR_NUMBER()) +
										'. Error Severity: ' + CONVERT(VARCHAR(MAX),ERROR_SEVERITY()) +  
										'. Error State: ' + CONVERT(VARCHAR(MAX),ERROR_STATE()) + 
										'. Error Procedure: ' + ERROR_PROCEDURE() + 
										'. Error Line: ' + CONVERT(VARCHAR(MAX),ERROR_LINE()) + 
										'. Error Message: ' + ERROR_MESSAGE() 
								)

				-- Raise Error will ensure the SQL Agent Job fails.  The message above will get passed to the SQL Agent Log. 
				-- Severity 11 - 20 will ensure the SQL Agent Job Fails successfully.
				RAISERROR (@MESSAGE,16,1)

			END

		END CATCH


	END



	/*

		EXEC usp_CMSMemberMedicareIDXref_Load

		SELECT TOP 10 * FROM dbo.EXT_SYS_RUNLOG ORDER BY ENTRYDT DESC

	*/











