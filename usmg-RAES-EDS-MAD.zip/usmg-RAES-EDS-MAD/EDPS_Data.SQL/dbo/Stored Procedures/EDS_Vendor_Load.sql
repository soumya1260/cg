﻿

CREATE  PROCEDURE [dbo].[EDS_Vendor_Load]

/**********************************************************************************************
PROCEDURE:	[dbo].[EDS_Vendor_Load]
PURPOSE:	Build the EDS-specific Vendor table from MDQOLib
			
NOTES:		Only loads MDQOLib.dbo.VendorDim records where Active = 1
			
CREATED:	2013-01-30, Dwight Staggs
REVISIONS:
Date		Author			Description
------------------------------------------------------------------------------------------------
*************************************************************************************************/
AS

BEGIN

	SET NOCOUNT ON;

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_Vendor_Load sproc'
		,'1', GETDATE(), NULL, NULL, 0, GETDATE() )
		
	DECLARE @CatchErrorMessage VARCHAR(2200);
	
	TRUNCATE TABLE dbo.Vendor


BEGIN TRY
	
	INSERT INTO
		dbo.vendor
	( 
		VendorKey ,
		VendorID ,
		VendorTypeCode ,
		VendorCategory ,
		NationalProviderID ,
		FederalID ,
		VendorName ,
		LastName ,
		FirstName ,
		AddressLine1 ,
		AddressLine2 ,
		Phone ,
		City ,
		State ,
		Zip ,
		SourceDataKey ,
		Active ,
		Deleted ,
		LoadDateKey ,
		EnterpriseID
	)
	SELECT
		VendorKey ,
		VendorID ,
		VendorTypeCode ,
		VendorCategory ,
		NationalProviderID ,
		FederalID ,
		VendorName ,
		LastName ,
		FirstName ,
		AddressLine1 ,
		AddressLine2 ,
		Phone ,
		City ,
		State ,
		Zip ,
		SourceDataKey ,
		Active ,
		Deleted ,
		LoadDateKey ,
		EnterpriseID
	FROM
		MDQOLib.dbo.VendorDim
	WHERE	
		Active = 1
		
	UPDATE dbo.EXT_SYS_RUNLOG
		SET END_DT		= GETDATE(),
		RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
		TOTAL_RECORDS	= @@ROWCOUNT,
		ENTRYDT			= GETDATE()
	WHERE	PROC_NAME	= 'EDS_Vendor_Load sproc'
	AND		END_DT		IS NULL
	AND		STEP		= '1'

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


	IF @@TRANCOUNT > 0
	COMMIT TRANSACTION

END
