﻿CREATE  PROCEDURE [dbo].[EDS_ProviderContractDim_Load]

/**********************************************************************************************
PROCEDURE:	[dbo].[EDS_ProviderContractDim_Load]
PURPOSE:	Build the EDS-specific ProviderContractDim table from MDQOLib.
			EDS only requires ProviderContract info related to current claims (ClaimDim)
			
NOTES:		This stored procedure is executed as part of the monthly BIDW --> EDS load process
			and needs to be executed AFTER the ClaimDim table has been populated from BIDW
CREATED:	2013-01-30, Dwight Staggs
REVISIONS:
Date		Author			Description
------------------------------------------------------------------------------------------------
2013-01-31	Dwight Staggs	Include Active = 0 from MDQOLib, but eliminate Inactive rows where
							there is a corresponding Active row;  ane eliminiate multiple Inactive 
							rows where there is no correspoinding Active row.

2024-01-25	Scott Waller	Adding INSERT/UPDATE(s) to the EDPS_Data.dbo.EXT_SYS_RUNLOG table
							to help in tracking the process's performance.

2024-04-12	Scott Waller	RETM-639   When we moved from the 2012 servers to the 2019 servers, 
							this sproc's run times went from 10-20 mins to 3 hours.
							Adding a couple small enhancements to improve this back to it's
							10 - 20 min run time.

*************************************************************************************************/
AS

BEGIN

	SET NOCOUNT ON;
	
	DECLARE @CatchErrorMessage VARCHAR(2200);

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderContractDim_Load sproc'
		,'1', GETDATE(), NULL, NULL, 0, GETDATE() )
	
	TRUNCATE TABLE dbo.providercontractdim

	WAITFOR DELAY '00:00:05'

	IF OBJECT_ID('TEMPDB..#tempPCPIDs') <> 0
	DROP TABLE #tempPCPIDs

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderContractDim_Load - INSERT'
		,'2', GETDATE(), NULL, NULL, 0, GETDATE() )

BEGIN TRY
	--
	--	Find all PCPID's in ClaimDim
	--
	SELECT DISTINCT
		c.SOURCEDATAKEY, 
		c.PCPID
	INTO					 
		#tempPCPIDs
	FROM 
		dbo.CLAIMDIM		c
	WHERE	
		PCPID NOT LIKE '%UNK%'
	ORDER BY 
		c.SOURCEDATAKEY, PCPID

-- RETM-639 add index to this temp table
	CREATE NONCLUSTERED INDEX tIndex ON #tempPCPIDs (SOURCEDATAKEY ASC, PCPID ASC)
-- end RETM-639

	--
	--	Get the required MDQOLib.dbo.ProviderContractDim records
	--
	;WITH cteMaxDates AS 
	(
	SELECT 
		pcd.SourceDataKey,
		pcd.ProviderID,
		pcd.LobCode,
		MAX(pcd.EndDateKey) 'MaxEndDateKey'
	FROM
		MDQOLib.dbo.ProviderContractDim  pcd
-- RETM-639 begin
	INNER JOIN #tempPCPIDs							t
		ON	pcd.SourceDataKey = t.SOURCEDATAKEY
		AND pcd.ProviderID = t.PCPID
-- RETM-639 end
	INNER JOIN
		MDQOLib.dbo.LineofBusinessDim	 lb
		ON pcd.SourceDataKey = lb.SourceDataKey
		AND pcd.LobCode = lb.LOBCode
		AND lb.ProductType = 'Medicare'
	GROUP BY
		pcd.SourceDataKey,
		pcd.ProviderID,
		pcd.LobCode
	)
		INSERT INTO
			dbo.providercontractdim
		SELECT DISTINCT 
			 pc.ProviderContractKey ,
			        pc.ProviderID ,
			        pc.VendorID ,
			        pc.LobCode ,
			        pc.RegionCode ,
			        pc.EffectiveDateKey ,
			        pc.EndDateKey ,
			        pc.ProvActiveFlag ,
			        pc.ParFlag ,
			        pc.SourceDataKey ,
			        pc.Active ,
			        pc.Deleted ,
			        pc.LoadDateKey ,
			        pc.EnterpriseID 
			        --,
			        --pc.ProviderContractDimID						
		FROM 
			MDQOLib.dbo.ProviderContractDim		pc
		INNER JOIN
			#tempPCPIDs							t
			ON	pc.SourceDataKey = t.SOURCEDATAKEY
			AND pc.ProviderID = t.PCPID
		INNER JOIN
			cteMaxDates							cte
			ON pc.SourceDataKey = cte.SourceDataKey
			AND pc.ProviderID = cte.ProviderID
			AND pc.LobCode = cte.LobCode
			AND pc.EndDateKey = cte.MaxEndDateKey
		ORDER BY 
			pc.ProviderID,
			pc.LobCode

		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= @@ROWCOUNT,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderContractDim_Load - INSERT'
		AND		END_DT		IS NULL
		AND		STEP		= '2'		


	--
	--	Delete InActive rows where there is a corresponding Active row
	--	for the ProviderID/VendorID/LOBCode/RegionCode combination
	--

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderContractDim_Load - DELETE'
		,'3', GETDATE(), NULL, NULL, 0, GETDATE() )

	;WITH cteRecsToDelete AS
	(
		SELECT	
			ProviderContractKey,
			SourceDataKey,
			ProviderID,
			VendorID,
			LobCode,
			RegionCode
		FROM
			dbo.providercontractdim		t1
		WHERE 
			Active = 0
		AND EXISTS (SELECT * FROM dbo.providercontractdim
					WHERE SourceDataKey = t1.SourceDataKey
					AND ProviderID = t1.ProviderID
					AND VendorID = t1.VendorID
					AND LobCode = t1.LobCode
					AND Active = 1)
	)
	DELETE
		pc
	FROM
		dbo.providercontractdim		pc
	INNER JOIN
		cteRecsToDelete cte
		ON pc.ProviderContractKey = cte.ProviderContractKey;
		
	UPDATE dbo.EXT_SYS_RUNLOG
		SET END_DT		= GETDATE(),
		RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
		TOTAL_RECORDS	= @@ROWCOUNT,
		ENTRYDT			= GETDATE()
	WHERE	PROC_NAME	= 'EDS_ProviderContractDim_Load - DELETE'
	AND		END_DT		IS NULL
	AND		STEP		= '3'		

	--
	--	For ProviderID/VendorID/LOBCode/RegionCode combinations
	--	where there was NO Active row, just keep the most recent
	--	Inactive row
	--	

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('DEL except most recent Inactive rows'
		,'4', GETDATE(), NULL, NULL, 0, GETDATE() )

	;WITH cteRecsToKeep AS
	(
		SELECT		
			SourceDataKey,
			ProviderID,
			VendorID,
			LobCode,
			RegionCode,
			MAX(ProviderContractKey) 'Max_ProviderContractKey'
		FROM
			dbo.providercontractdim	
		WHERE 
			Active = 0
		GROUP BY
			SourceDataKey,
			ProviderID,
			VendorID,
			LobCode,
			RegionCode
	)
	DELETE
		pc 
	FROM
		dbo.providercontractdim		pc
	WHERE
		pc.Active = 0	
	AND pc.ProviderContractKey NOT IN (SELECT Max_ProviderContractKey FROM cteRecsToKeep);

	UPDATE dbo.EXT_SYS_RUNLOG
		SET END_DT		= GETDATE(),
		RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
		TOTAL_RECORDS	= @@ROWCOUNT,
		ENTRYDT			= GETDATE()
	WHERE	PROC_NAME	= 'DEL except most recent Inactive rows'
	AND		END_DT		IS NULL
	AND		STEP		= '4'		
	
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


	IF @@TRANCOUNT > 0
	COMMIT TRANSACTION


	IF OBJECT_ID('TEMPDB..#tempPCPIDs') <> 0
	DROP TABLE #tempPCPIDs

	UPDATE dbo.EXT_SYS_RUNLOG
		SET END_DT		= GETDATE(),
		RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
		TOTAL_RECORDS	= 0,
		ENTRYDT			= GETDATE()
	WHERE	PROC_NAME	= 'EDS_ProviderContractDim_Load sproc'
	AND		END_DT		IS NULL
	AND		STEP		= '1'		

END
