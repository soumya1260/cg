﻿

CREATE  PROCEDURE [dbo].[EDS_ProviderDim_Load]

/**********************************************************************************************
PROCEDURE:	[dbo].[EDS_ProviderDim_Load]
PURPOSE:	Build the EDS-specific ProviderDim table.  Source data is obtained from BIDW, missing
			elements are updated from other sources.
NOTES:		This stored procedure is executed as part of the monthly BIDW --> EDS load process
CREATED:	2013-01-22, Dwight Staggs
REVISIONS:
Date		Author			Description
------------------------------------------------------------------------------------------------
2013-01-23	Dwight Staggs	Added logic to pick up missing TaxIDs and UPINs from IngenixProviderDim table
2013-01-24	Dwight Staggs	Added calls to "EDS_ProviderDim_Validation" (Pre-scrub & Post_scrub), and
							also code to "clean up" known bad values (scrubbing routines)
2013-01-31	Dwight Staggs	Added logic for initial update to TaxID via Group logic (get info from
							ProviderContractDim and Vendor)	
2013-02-01	Dwight Staggs	Added Vendor columns to EDS_ProviderDim table, populate from Vendor table	
2013-02-05	Dwight Staggs	Modified update to Vendor info - JOIN on these columns to get all info:  
								SourceDataKey = SourceDataKey
								ProviderID = VendorID
								ProviderTypeCode = VendorTypeCode
2013-03-22	Dwight Staggs	Point to EDPS_Staging DB for staging tables; point to MDQOLib for IngenixProviderDim
2013-03-30	Dwight Staggs	Now adds records from VendorDim;  additional column RecordSource (P/V)
2013-04-15	Dwight Staggs	Was not checking for invalid values on the "ProviderPhone_xxx" and "ProviderAddress_xxx" colummns
2013-04-26	Dwight Staggs	Removed the logic for resolving names via "cross-walking" pointers in that 
							column to other records.  Per Anita's team, sometimes the reference is to
							a contract, plan number, etc. rather than to a specific ProviderID - 
							cannot reliably follow those pointers
2013-04-26	Dwight Staggs	Added logic to update the ProviderTypeDesc column from MDQOLib		
2013-05-30	Dwight Staggs	Added logic to check MDQOLib.dbo.ProviderGroupDim for GroupID's		
2013-06-06	Dwight Staggs	At end, set the ProviderGroupID = ProviderID for all ProviderTypeCode = "01" 
							or ProvCategory = "G"	
2013-06-25	Dwight Staggs	Revised logic for adding VendorDim records	
2013-08-15	Dwight Staggs	Removed Address and Phone columns from EDS_ProviderDim;  new tables
							EDS_ProviderAddressDim and EDS_ProviderPhoneDim	
2013-11-04	Dwight Staggs	Added code at end to replace all NULL column valuse with '' in the 3 Provider tables.
							NULL values were causing problems in building EXT_HRP_CLAIM_MAP records														
2013-11-21	Dwight Staggs	Removed obsolete (commented out) code
2013-12-04	Dwight Staggs	Corrected logic when trying to update NPI from Ingenix, joining on
							(1) UPIN and FIDN and (2) DEANumber and FIDN					

2019-05-17	Scott Waller	TETDM-	Hitting ClaimDetailDim 3 times causes this to hang.  
							Rewritten to help prevent.

2024-01-25	Scott Waller	RETM-576	The DBA team identified a statement in the sproc that could benefit
							from using this statement:     OPTION (MAXDOP 1) 

*************************************************************************************************/
AS

BEGIN

	SET NOCOUNT ON;

		INSERT INTO dbo.EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT)
		VALUES('EDS_ProviderDim_Load EDPS_Data'
			,'1'
			,GETDATE()
			,NULL
			,NULL
			,0
			,GETDATE() )
				
	DECLARE @CatchErrorMessage VARCHAR(2200);
	DECLARE @TodayINT INT = CAST(REPLACE(CAST(CAST(GETDATE() AS DATE) AS CHAR(10)), '-', '') AS INT)
	
	TRUNCATE TABLE dbo.EDS_ProviderDim
	
	EXEC [dbo].[ut_EDS_ProviderDim_Indexes]
		@DropCreate	 = 'D'
		
BEGIN TRY
--
	--	Only populate with ProviderID's used in current
	--	ClaimDim and ClaimDetailDim tables...
	--
	IF OBJECT_ID('TEMPDB..#ClaimProviders') <> 0
	DROP TABLE #ClaimProviders
		
	CREATE TABLE #ClaimProviders
	(
		SourceDataKey		INT,
		ProviderID			VARCHAR(50)
	)

	IF OBJECT_ID('TEMPDB..#cteDistProviderNPI') <> 0
	DROP TABLE #cteDistProviderNPI

	CREATE TABLE #cteDistProviderNPI
	(
		SourceDataKey		INT,
		ProviderID			VARCHAR(50)
	)

	IF OBJECT_ID('TEMPDB..#cteProviderID') <> 0
	DROP TABLE #cteProviderID

		CREATE TABLE #cteProviderID
	(
		SourceDataKey		INT,
		ProviderID			VARCHAR(50)
	)

	IF OBJECT_ID('TEMPDB..#cteVENDORID') <> 0
	DROP TABLE #cteVENDORID

		CREATE TABLE #cteVENDORID
	(
		SourceDataKey		INT,
		VendorID			VARCHAR(50)
	)

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load #cteDistProviderNPI table'
		,'2', GETDATE(), NULL, NULL, 0, GETDATE() )

--	;WITH 
--	cteDistProviderNPI AS
--	(
	INSERT INTO #cteDistProviderNPI
		SELECT DISTINCT
			SOURCEDATAKEY, PROVIDERNPI
		FROM
			dbo.CLAIMDETAILDIM
		WHERE
			PROVIDERNPI NOT IN ('UNKNOWN', '0000000000')

		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= @@ROWCOUNT,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderDim_Load #cteDistProviderNPI table'
		AND		END_DT		IS NULL
		AND		STEP		= '2'

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load #ctePROVIDERID table'
		,'3', GETDATE(), NULL, NULL, 0, GETDATE() )

--	ctePROVIDERID AS
	INSERT INTO #ctePROVIDERID
		SELECT DISTINCT
			SOURCEDATAKEY,
			PROVIDERID
		FROM
		dbo.CLAIMDETAILDIM

		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= @@ROWCOUNT,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderDim_Load #ctePROVIDERID table'
		AND		END_DT		IS NULL
		AND		STEP		= '3'

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load #cteVENDORID table'
		,'4', GETDATE(), NULL, NULL, 0, GETDATE() )

--	cteVENDORID AS
	INSERT INTO #cteVENDORID
		SELECT DISTINCT
			SOURCEDATAKEY,
			VENDORID
		FROM
		dbo.CLAIMDETAILDIM

		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= @@ROWCOUNT,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderDim_Load #cteVENDORID table'
		AND		END_DT		IS NULL
		AND		STEP		= '4'

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load UNIONed INSERT'
		,'5', GETDATE(), NULL, NULL, 0, GETDATE() )

	;WITH
	cteProviderNPI AS
	(
		SELECT DISTINCT
			p.SourceDataKey,
			p.ProviderID
		FROM
			MDQOLib.dbo.ProviderDim	p
		INNER JOIN
			#cteDistProviderNPI		cd
			ON p.SourceDataKey = cd.SOURCEDATAKEY
			AND p.NPID = cd.ProviderID	--cd.PROVIDERNPI
		WHERE
			p.Active = 1
		AND p.Deleted = 0
	),
	cteDistVendorNPI AS
	(
		SELECT DISTINCT
			SOURCEDATAKEY, VendorNPI
		FROM
			dbo.CLAIMDIM
		WHERE
			VendorNPI NOT IN ('UNKNOWN', '0000000000')
	),
	cteVendorNPI AS
	(
		SELECT DISTINCT
			p.SourceDataKey,
			p.ProviderID
		FROM
			MDQOLib.dbo.ProviderDim	p
		INNER JOIN
			cteDistVendorNPI		cd
			ON p.SourceDataKey = cd.SOURCEDATAKEY
			AND p.NPID = cd.VendorNPI
		WHERE
			p.Active = 1
		AND p.Deleted = 0
	),
	ctePCPID AS
	(
		SELECT DISTINCT
			SOURCEDATAKEY,
			PCPID
		FROM
		dbo.CLAIMDIM
	),
	ctePCPVENDOR AS
	(
		SELECT DISTINCT
			SOURCEDATAKEY,
			PCPVENDOR
		FROM
		dbo.CLAIMDIM
	),
	cteREFERRINGPHYSICIANID AS
	(
		SELECT DISTINCT
			SOURCEDATAKEY,
			REFERRINGPHYSICIANID
		FROM
		dbo.CLAIMDIM
	),
	cteATTENDINGPHYSICIANID AS
	(
		SELECT DISTINCT
			SOURCEDATAKEY,
			ATTENDINGPHYSICIANID
		FROM
		dbo.CLAIMDIM
	)

	INSERT INTO
		#ClaimProviders
	(
		SourceDataKey,
		ProviderID
	)
	SELECT
		SourceDataKey,
		ProviderID
	FROM	
		cteProviderNPI
	UNION
	SELECT
		SourceDataKey,
		ProviderID
	FROM
		cteVendorNPI
	UNION	

	SELECT
		SOURCEDATAKEY,
		PCPID
	FROM ctePCPID
	UNION	
	SELECT
		SOURCEDATAKEY,
		PCPVENDOR
	FROM ctePCPVENDOR
	UNION	

	SELECT
		SOURCEDATAKEY,
		REFERRINGPHYSICIANID
	FROM cteREFERRINGPHYSICIANID
	UNION	
	SELECT
		SOURCEDATAKEY,
		ATTENDINGPHYSICIANID
	FROM cteATTENDINGPHYSICIANID
	UNION	
	SELECT
		SOURCEDATAKEY,
		PROVIDERID
	FROM #ctePROVIDERID
	UNION	
	SELECT
		SOURCEDATAKEY,
		VENDORID
	FROM #cteVENDORID

		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= @@ROWCOUNT,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderDim_Load UNIONed INSERT'
		AND		END_DT		IS NULL
		AND		STEP		= '5'

	DELETE #ClaimProviders
	WHERE
		ProviderID IN ('', ' ')
	OR ProviderID IS NULL
	OR ProviderID LIKE ('%UNKNO%')
	
	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load EDS_ProviderDim'
		,'6', GETDATE(), NULL, NULL, 0, GETDATE() )

	INSERT INTO	
		dbo.EDS_ProviderDim
	( 
		RecordSource ,
		ProviderID ,
		ProviderGroupID ,
		ProviderTypeCode ,
		ProviderStatus ,
		GlobalCurrentPatientLoad ,
		AdditionalBusinessName ,
		PrimaryBusinessName ,
		FullName ,
		ReverseFullName ,
		LastName ,
		FirstName ,
		MiddleName ,
		Title ,
		GlobalPanelSize ,
		NewPatientFlag ,
		DeaNumber ,
		Gender ,
		DOBDateKey ,
		UPIN ,
		FIDN ,
		NPID ,
		MedicaidID ,
		MedicareID ,
		HandicapAccess ,
		CredentialingStatus ,
		ProvCategory ,
		LicenseTypeCode ,
		LeasedStatusCode ,
		PreferredStatusCode ,
		ChildFlg ,
		YouthFlg ,
		AdultFlg ,
		StandardHoursInd ,
		AfterHoursInd ,
		WeekendHoursInd ,
		SourceDataKey ,
		ProviderType_ProviderTypeDesc ,
		--ProviderPhone_PhoneTypeCode ,
		--ProviderPhone_PhoneNumber ,
		--ProviderPhone_FaxNumber ,
		--ProviderPhone_MultiPhoneInd ,
		--ProviderAddress_AddressTypeCode ,
		--ProviderAddress_AddressLine1 ,
		--ProviderAddress_AddressLine2 ,
		--ProviderAddress_City ,
		--ProviderAddress_State ,
		--ProviderAddress_ZipCode9 ,
		--ProviderAddress_MultiAddressInd ,
		--ProviderAddress_Latitude ,
		--ProviderAddress_Longitude ,
		--ProviderAddress_AddressTypeDesc ,
		Ingenix_TaxonomyCode ,
		Ingenix_SpecialtyName ,
		Ingenix_SpecialtyGroupName ,
		Vendor_VendorID ,
		Vendor_VendorTypeCode ,
		Vendor_VendorCategory ,
		Vendor_NationalProviderID ,
		Vendor_FederalID ,
		Vendor_VendorName ,
		Vendor_LastName ,
		Vendor_FirstName ,
		Vendor_AddressLine1 ,
		Vendor_AddressLine2 ,
		Vendor_Phone ,
		Vendor_City ,
		Vendor_State ,
		Vendor_Zip
	)
	SELECT DISTINCT
		 'P'
		,pd.ProviderID
		,NULL					--	ProviderGroupID
		,pd.ProviderTypeCode
		,pd.ProviderStatus
		,pd.GlobalCurrentPatientLoad
		,pd.AdditionalBusinessName
		,pd.PrimaryBusinessName
		,pd.FullName
		,pd.ReverseFullName
		,pd.LastName
		,pd.FirstName
		,pd.MiddleName
		,pd.Title
		,pd.GlobalPanelSize
		,pd.NewPatientFlag
		,pd.DeaNumber
		,pd.Gender
		,pd.DOBDateKey
		,pd.UPIN
		,pd.FIDN
		,pd.NPID
		,pd.MedicaidID
		,pd.MedicareID
		,pd.HandicapAccess
		,NULL						--,pd.CredentialingStatus
		,pd.ProvCategory
		,pd.LicenseTypeCode
		,pd.LeasedStatusCode
		,pd.PreferredStatusCode
		,pd.ChildFlg
		,pd.YouthFlg
		,pd.AdultFlg
		,pd.StandardHoursInd
		,pd.AfterHoursInd
		,pd.WeekendHoursInd
		,pd.SourceDataKey
		,pt.ProviderTypeDesc	
		--,NULL				--	ppd.PhoneTypeCode
		--,NULL				--	ppd.PhoneNumber
		--,NULL				--	ppd.FaxNumber
		--,NULL				--	ppd.MultiPhoneInd
		--,NULL				--	pa.AddressTypeCode
		--,NULL				--	pa.AddressLine1
		--,NULL				--	pa.AddressLine2
		--,NULL				--	pa.City
		--,NULL				--	pa.State
		--,NULL				--	pa.ZipCode9
		--,NULL				--	pa.MultiAddressInd
		--,NULL				--	pa.Latitude
		--,NULL				--	pa.Longitude
		--,NULL				--	at.AddressTypeDesc
		
		,NULL				--	Ingenix_TaxonomyCode
		,NULL				--	Ingenix_SpecialtyName
		,NULL				--	Ingenix_SpecialtyGroupName

		,NULL				--	Vendor_VendorID
		,NULL				--	Vendor_VendorTypeCode
		,NULL				--	Vendor_VendorCategory
		,NULL				--	Vendor_NationalProviderID
		,NULL				--	Vendor_FederalID
		,NULL				--	Vendor_VendorName
		,NULL				--	Vendor_LastName
		,NULL				--	Vendor_FirstName
		,NULL				--	Vendor_AddressLine1
		,NULL				--	Vendor_AddressLine2
		,NULL				--	Vendor_Phone
		,NULL				--	Vendor_City
		,NULL				--	Vendor_State
		,NULL				--	Vendor_Zip
	FROM 
		MDQOLib.dbo.ProviderDim							pd
	INNER JOIN
		#ClaimProviders									cp
		ON pd.SourceDataKey = cp.SourceDataKey
		AND pd.ProviderID = cp.ProviderID
	LEFT OUTER JOIN 
		MDQOLib.dbo.ProviderTypeDim						pt
		ON pd.SourceDataKey = pt.SourceDataKey
		AND	pd.ProviderTypeCode = pt.ProviderTypeCode
	LEFT OUTER JOIN
		MDQOLib.dbo.ProviderGroupDim					pg
		ON pd.SourceDataKey = pg.SourceDataKey
		AND pd.ProviderID = pg.ProviderID
		
		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= @@ROWCOUNT,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderDim_Load EDS_ProviderDim'
		AND		END_DT		IS NULL
		AND		STEP		= '6'

	--
	--	Update ProviderGroupID from MDQOLib.dbo.ProviderGroupDim
	--
	--	*** Note:  As of 5-3-2013, ProviderGroupDim contains only SourceDataKey = 30
	--

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load Between 6 and 7'
		,'6.1', GETDATE(), NULL, NULL, 0, GETDATE() )

	UPDATE
		p
	SET
		ProviderGroupID = pg.ProviderGroupID 
	FROM
		dbo.EDS_ProviderDim				p
	INNER JOIN
		MDQOLib.dbo.ProviderGroupDim	pg
		ON p.SourceDataKey = pg.SourceDataKey
		AND p.ProviderID = pg.ProviderID
	WHERE 
		EndCoverageDateKey>= @TodayINT

	UPDATE dbo.EXT_SYS_RUNLOG
		SET END_DT		= GETDATE(),
		RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
		TOTAL_RECORDS	= @@ROWCOUNT,
		ENTRYDT			= GETDATE()
	WHERE	PROC_NAME	= 'EDS_ProviderDim_Load Between 6 and 7'
	AND		END_DT		IS NULL
	AND		STEP		= '6.1'

	--
	--	Fill in the GroupID if PrimaryBusinessName  = one of the other names of a "group" record
	--	for ProvCategory = "P" providers...	
	--
	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load Between 6 and 7'
		,'6.2', GETDATE(), NULL, NULL, 0, GETDATE() )

	UPDATE
		d1
	SET
		ProviderGroupID = d2.ProviderID
	FROM
		dbo.EDS_ProviderDim			d1
	INNER JOIN
		dbo.EDS_ProviderDim			d2
		ON d1.SourceDataKey = d2.SourceDataKey
		AND d1.PrimaryBusinessName != 'UNKNOWN'
		AND d1.ProviderGroupID IS NULL
		AND d1.ProviderID != d2.ProviderID
		AND (
				d1.PrimaryBusinessName = d2.FullName
				OR
				d1.PrimaryBusinessName = d2.ReverseFullName
				OR
				d1.PrimaryBusinessName = d2.LastName
			)		
		AND d1.ProvCategory = 'P'
		AND d2.ProvCategory = 'G'
		AND d1.SourceDataKey IN (SELECT DISTINCT SourceDataKey FROM MDQOLib.dbo.ProviderGroupDim)

	UPDATE dbo.EXT_SYS_RUNLOG
		SET END_DT		= GETDATE(),
		RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
		TOTAL_RECORDS	= @@ROWCOUNT,
		ENTRYDT			= GETDATE()
	WHERE	PROC_NAME	= 'EDS_ProviderDim_Load Between 6 and 7'
	AND		END_DT		IS NULL
	AND		STEP		= '6.2'

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH
	


BEGIN TRY
	--
	--	Add Vendor records ("Billing"/"Pay To"/etc.)
	--

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load EDS_ProviderDim Vendors'
		,'7', GETDATE(), NULL, NULL, 0, GETDATE() )

	INSERT INTO
		dbo.EDS_ProviderDim
	( 
		RecordSource,
		ProviderID ,
		Vendor_VendorID,
		SourceDataKey,
		Vendor_VendorTypeCode,
		Vendor_VendorCategory,
		Vendor_NationalProviderID,
		Vendor_FederalID,
		Vendor_VendorName,
		Vendor_LastName,
		Vendor_FirstName,
		Vendor_AddressLine1,
		Vendor_AddressLine2,
		Vendor_Phone,
		Vendor_City,
		Vendor_State,
		Vendor_Zip
		
	)
	SELECT DISTINCT
		'V'								--	RecordSource
		,VendorID						--	ProviderID
		,VendorID						--	Vendor_VendorID
		,SourceDataKey					--	SourceDataKey
		,VendorTypeCode					--	Vendor_VendorTypeCode
		,VendorCategory					--	Vendor_VendorCategory
		,NationalProviderID				--	Vendor_NationalProviderID
		,FederalID						--	Vendor_FederalID
		,VendorName						--	Vendor_VendorName
		,LastName						--	Vendor_LastName
		,FirstName						--	Vendor_FirstName
		,AddressLine1					--	Vendor_AddressLine1
		,AddressLine2					--	Vendor_AddressLine2
		,REPLACE(REPLACE(REPLACE(Phone,'-',''), '/',''),'\','')	--	Vendor_Phone	
		,City							--	Vendor_City
		,State							--	Vendor_State
		,REPLACE(Zip,'-','')			--	Vendor_Zip
	FROM
		MDQOLib.dbo.VendorDim
	WHERE Deleted = 0

		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= @@ROWCOUNT,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderDim_Load EDS_ProviderDim Vendors'
		AND		END_DT		IS NULL
		AND		STEP		= '7'

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY
	--
	--	Add columns that exist in Ingenix table only...
	--

	UPDATE	
		eds 
	SET
		Ingenix_TaxonomyCode = i.TaxonomyCode,
		Ingenix_SpecialtyName = i.SpecialtyName,
		Ingenix_SpecialtyGroupName = i.SpecialtyGroupName
	FROM	
		dbo.EDS_ProviderDim		eds
	INNER JOIN
		MDQOLib.dbo.IngenixProviderDim	i
		ON eds.NPID = i.NPI
		AND eds.NPID NOT IN ('UNKNOWN', 'N/A', '', ' ') 
		AND eds.NPID IS NOT NULL 
	--
	--	Do not update "V" Providers...
	--
		AND eds.RecordSource != 'V' 
		
	UPDATE
		dbo.EDS_ProviderDim
	SET
		Ingenix_TaxonomyCode = CASE WHEN Ingenix_TaxonomyCode LIKE 'UNK%' THEN '' ELSE Ingenix_TaxonomyCode END,
		Ingenix_SpecialtyName = CASE WHEN Ingenix_SpecialtyName LIKE 'UNK%' THEN '' ELSE Ingenix_SpecialtyName END,
		Ingenix_SpecialtyGroupName = CASE WHEN Ingenix_SpecialtyGroupName LIKE 'UNK%' THEN '' ELSE Ingenix_SpecialtyGroupName END
		
	--SELECT @@ROWCOUNT 'Updated_Ingenix_Only_Columms'		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY
	--
	--	Update Vendor TaxIDs from Ingenix based on NPI...
	--
	UPDATE
		p 
	SET
		Vendor_FederalID = i.TaxID
	FROM
		dbo.EDS_ProviderDim				p
	INNER JOIN
		MDQOLib.dbo.IngenixProviderDim	i
		ON p.Vendor_NationalProviderID = i.NPI
	WHERE
		p.Vendor_FederalID IS NULL
		AND ISNUMERIC(i.TaxID) = 1
		AND p.RecordSource = 'V'

	--SELECT @@ROWCOUNT 'Updated_Vendor_TaxID_From_Ingenix (NPI)'	
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH




BEGIN TRY
	--
	--	Update Vendor Phone from Ingenix based on NPI...
	--

	UPDATE
		p
	SET
		Vendor_Phone = REPLACE(REPLACE(REPLACE(i.OfficePhone, '/', ''), '-', ''), '\', '')
	FROM
		dbo.EDS_ProviderDim				p
	INNER JOIN
		MDQOLib.dbo.IngenixProviderDim	i
		ON p.Vendor_NationalProviderID = i.NPI
	WHERE
		p.Vendor_Phone IS NULL
	AND p.RecordSource = 'V'
	AND i.OfficePhone IS NOT NULL
	AND i.OfficePhone NOT LIKE '%unknow%'
	AND i.OfficePhone NOT IN ('', ' ')


	--SELECT @@ROWCOUNT 'Updated_Vendor_Phone_From_Ingenix (NPI)'	
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY	

		--EXEC [dbo].[EDS_ProviderDim_Validation] @PreOrPostScrub = 'PRE'

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load EDS_ProviderDim Cleanup'
		,'8', GETDATE(), NULL, NULL, 0, GETDATE() )

	--	"Bad" ProviderID values are useless...
	
		DELETE FROM dbo.EDS_ProviderDim WHERE 
			ProviderID LIKE '%UNK%'
		OR	CHARINDEX( '~',ProviderID) > 0
		OR	CHARINDEX( '`',ProviderID) > 0
		OR	CHARINDEX( '*',ProviderID) > 0
		OR	CHARINDEX( ':',ProviderID) > 0
		OR	CHARINDEX( '^',ProviderID) > 0
		OR	CHARINDEX( '"',ProviderID) > 0
		OR	CHARINDEX( '|',ProviderID) > 0
		--	7 above are Verisk restrictions...
		OR	CHARINDEX( '/',ProviderID) > 0
		OR	CHARINDEX( '\',ProviderID) > 0
		OR	CHARINDEX( ';',ProviderID) > 0
		OR	CHARINDEX( '?',ProviderID) > 0
		OR	CHARINDEX( '!',ProviderID) > 0
		OR	CHARINDEX( '@',ProviderID) > 0
		OR	CHARINDEX( '#',ProviderID) > 0
		OR	CHARINDEX( '$',ProviderID) > 0
		OR	CHARINDEX( '%',ProviderID) > 0
		OR	CHARINDEX( '&',ProviderID) > 0

	--
	--	Clean up garbage FIDN and NPI numbers, may be able to update later...
	--
		
	--
	--	FIDNs must be numeric
	--
	UPDATE dbo.EDS_ProviderDim SET FIDN = NULL WHERE ISNUMERIC(FIDN) = 0
	
	--
	--	Valid NPIs are 10-digit numbers
	--
	UPDATE dbo.EDS_ProviderDim SET NPID = NULL WHERE ISNUMERIC(NPID) = 0 OR LEN(NPID) != 10
	
END TRY	


BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY		
	--
	--	See if any missing Provider NPI's are in Ingenix (JOIN on UPIN and DEANumber)...
	--
	UPDATE
		eds 
	SET	
		NPID = i.NPI
	FROM
		dbo.EDS_ProviderDim			eds
	INNER JOIN
		MDQOLib.dbo.IngenixProviderDim		i
		ON eds.UPIN = i.UPIN
		AND eds.DeaNumber = i.DEANumber
		AND eds.NPID IN ('UNKNOWN', 'N/A', '', ' ', '0000000000')
	WHERE
	--
	--	Do not update "V" records...
	--
		eds.RecordSource != 'V'
	AND
		(eds.UPIN NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.upin IS NOT NULL)
	AND
		(eds.DeaNumber NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.DeaNumber IS NOT NULL)
	AND
		(i.UPIN NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.upin IS NOT NULL)
	AND
		(i.DEANumber NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.DEANumber IS NOT NULL)


	--SELECT @@ROWCOUNT 'Provider_NPI_Updated_From_Ingenix(UPIN/DEANumber)'		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY

	--
	--	See if any missing Provider NPI's are in Ingenix (JOIN on UPIN and TaxId)...
	--
	--UPDATE
	--	eds 
	--SET	
	--	NPID = i.NPI
	--FROM
	--	dbo.EDS_ProviderDim			eds
	--INNER JOIN
	--	MDQOLib.dbo.IngenixProviderDim		i
	--	ON eds.UPIN = i.UPIN
	--	AND eds.FIDN = i.TaxID
	--	AND eds.NPID IN ('UNKNOWN', 'N/A', '', ' ', '0000000000')
	--WHERE
	----
	----	Do not update "V" records...
	----
	--	eds.RecordSource != 'V'
	--AND
	--	(eds.UPIN NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.upin IS NOT NULL)
	--AND
	--	(eds.NPID NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.NPID IS NOT NULL)
	--AND
	--	(i.UPIN NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.upin IS NOT NULL)
	--AND
	--	(i.TaxID NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.TaxID IS NOT NULL)



	UPDATE
		eds 
	SET	
		NPID = i.NPI
	FROM
		dbo.EDS_ProviderDim			eds
	INNER JOIN
		MDQOLib.dbo.IngenixProviderDim		i
		ON eds.UPIN = i.UPIN
		AND eds.FIDN = i.TaxID
		AND eds.NPID IN ('UNKNOWN', 'N/A', '', ' ', '0000000000')
	WHERE
	--
	--	Do not update "V" records...
	--
		eds.RecordSource != 'V'
	AND
		(eds.UPIN NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.upin IS NOT NULL)
	AND
		(eds.FIDN NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.FIDN IS NOT NULL)
	AND
		(i.UPIN NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.upin IS NOT NULL)
	AND
		(i.TaxID NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.TaxID IS NOT NULL)


	--SELECT @@ROWCOUNT 'Provider_NPI_Updated_From_Ingenix(UPIN/TaxID)'		

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY

	--
	--	See if any missing Provider NPI's are in Ingenix (JOIN on DEANumber and TaxId)...
	--
	--UPDATE
	--	eds 
	--SET	
	--	NPID = i.NPI
	--FROM
	--	dbo.EDS_ProviderDim			eds
	--INNER JOIN
	--	MDQOLib.dbo.IngenixProviderDim		i
	--	ON eds.DeaNumber = i.DEANumber
	--	AND eds.FIDN = i.TaxID
	--	AND eds.NPID IN ('UNKNOWN', 'N/A', '', ' ', '0000000000')
	--WHERE
	----
	----	Do not update "V" records...
	----
	--	eds.RecordSource != 'V'
	--AND
	--	(eds.DeaNumber NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.DeaNumber IS NOT NULL)
	--AND
	--	(eds.NPID NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.NPID IS NOT NULL)
	--AND
	--	(i.DeaNumber NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.DeaNumber IS NOT NULL)
	--AND
	--	(i.TaxID NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.TaxID IS NOT NULL)

	UPDATE
		eds 
	SET	
		NPID = i.NPI
	FROM
		dbo.EDS_ProviderDim			eds
	INNER JOIN
		MDQOLib.dbo.IngenixProviderDim		i
		ON eds.DeaNumber = i.DEANumber
		AND eds.FIDN = i.TaxID
		AND eds.NPID IN ('UNKNOWN', 'N/A', '', ' ', '0000000000')
	WHERE
	--
	--	Do not update "V" records...
	--
		eds.RecordSource != 'V'
	AND
		(eds.DeaNumber NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.DeaNumber IS NOT NULL)
	AND
		(eds.FIDN NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.FIDN IS NOT NULL)
	AND
		(i.DeaNumber NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.DeaNumber IS NOT NULL)
	AND
		(i.TaxID NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.TaxID IS NOT NULL)



	--SELECT @@ROWCOUNT 'Provider_NPI_Updated_From_Ingenix(DeaNumber/TaxID)'		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY	
	--
	--	See if any missing Provider TaxIDs are in Ingenix (JOIN on NPI)...
	--
	UPDATE 
		eds 
	SET
		FIDN = i.TaxID
	FROM
		dbo.EDS_ProviderDim			eds
	INNER JOIN
		MDQOLib.dbo.IngenixProviderDim		i
		ON eds.NPID = i.NPI
	WHERE
	--
	--	Do not update "V" records...
	--
		eds.RecordSource != 'V'

	AND (eds.NPID NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.NPID IS NOT NULL)
	AND (i.NPI NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.NPI IS NOT NULL)
	AND (i.TaxID NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.TaxID IS NOT NULL)
	AND (eds.FIDN IN ('UNKNOWN', 'N/A', '', ' ', '0000000000', 'MEMBER', '999999999')
		 OR 
		 eds.FIDN IS NULL
		)

	--SELECT @@ROWCOUNT 'Provider_TaxID_Updated_From_Ingenix(NPI)'		

END TRY	

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY	
	--
	--	See if any missing Provider UPINs are in Ingenix (JOIN on NPI)...
	--
	UPDATE 
		eds 
	SET
		UPIN = i.UPIN
	FROM
		dbo.EDS_ProviderDim			eds
	INNER JOIN
		MDQOLib.dbo.IngenixProviderDim		i
		ON eds.NPID = i.NPI
	WHERE
	--
	--	Do not update "V" records...
	--
		eds.RecordSource != 'V'
	AND (eds.NPID NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.NPID IS NOT NULL)
	AND (i.NPI NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.NPI IS NOT NULL)
	AND (i.UPIN NOT IN ('UNKNOWN', 'N/A', '', ' ') AND i.UPIN IS NOT NULL)
	AND LEN(eds.UPIN) != 6
		
	--SELECT @@ROWCOUNT 'Provider_UPIN_Updated_From_Ingenix(NPI)'		

END TRY	

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY

	--
	--	Try to get "better" names from IngenixProviderDim where NPIs match...
	--
		
	UPDATE
		eds 
	SET
		 FirstName = i.FirstName
		,LastName = i.LastName
		,MiddleName = i.MiddleName
		,FullName = i.FirstName + ' ' + i.LastName
		,ReverseFullName = i.LastName + ', ' + i.FirstName
	FROM	
		dbo.EDS_ProviderDim			eds
	INNER JOIN
		MDQOLib.dbo.IngenixProviderDim		i
		ON eds.NPID = i.NPI
	WHERE
	--
	--	Do not update "V" records...
	--
		eds.RecordSource != 'V'
	AND
			( eds.NPID NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.NPID IS NOT NULL )
	AND
	(
			eds.LastName LIKE '%*%'
		 OR eds.FullName LIKE '%*%'
		 OR eds.FirstName  LIKE '%*%'
		 OR eds.ReverseFullName  LIKE '%*%'
	)

		
	--SELECT @@ROWCOUNT 'Updated_Names_From_IngenixProviderDim(NPI)'		

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY

	--
	--	Try to get "better" names from IngenixProviderDim where UPINs match...
	--
		
	UPDATE
		eds 
	SET
		 FirstName = i.FirstName
		,LastName = i.LastName
		,MiddleName = i.MiddleName
		,FullName = i.FirstName + ' ' + i.LastName
		,ReverseFullName = i.LastName + ', ' + i.FirstName
	FROM	
		dbo.EDS_ProviderDim			eds
	INNER JOIN
		MDQOLib.dbo.IngenixProviderDim		i
		ON eds.UPIN = i.UPIN
	WHERE
	--
	--	Do not update "V" records...
	--
		eds.RecordSource!= 'V'
	AND 
			( eds.UPIN NOT IN ('UNKNOWN', 'N/A', '', ' ') AND eds.UPIN IS NOT NULL )
	AND
	(
			eds.LastName LIKE '%*%'
		 OR eds.FullName LIKE '%*%'
		 OR eds.FirstName  LIKE '%*%'
		 OR eds.ReverseFullName  LIKE '%*%'
	)

		
	--SELECT @@ROWCOUNT 'Updated_Names_From_IngenixProviderDim(UPIN)'		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH
	
	--
	--	Update the ProviderTypeDesc column from MDQOLib...
	--

/* Scott Waller March 29, 2024	RETM-564

		This is the code that hangs in PROD for 12+ hours.
		Replace it, but leaving this code here for a reference
*/
/*
BEGIN TRY
		UPDATE			
			P
		SET
			ProviderType_ProviderTypeDesc = COALESCE(LEFT(STD.SpecialtyTypeDesc, 60), '')
		FROM	
			dbo.EDS_ProviderDim							P
		INNER JOIN
			MDQOLib.dbo.ProviderDim						PD
			ON PD.SourceDataKey = P.SourceDataKey
			AND PD.ProviderID = P.ProviderID
		INNER JOIN
			MDQOLib.dbo.ProviderSpecialtyXref			PSX
			ON PD.ProviderKey = PSX.ProviderKey
			AND PD.SourceDataKey = PSX.SourceDataKey
		INNER JOIN
			MDQOLib.dbo.SpecialtyTypeDim				STD
			ON PSX.SourceDataKey = STD.SourceDataKey
			AND PSX.SpecialtyTypeKey = STD.SpecialtyTypeKey
		WHERE
			P.ProviderType_ProviderTypeDesc IS NULL
		AND STD.SpecialtyTypeDesc NOT IN ('', ' ', 'UNKNOWN', 'NA', 'N/A')
		AND STD.SpecialtyTypeDesc NOT LIKE '%DO NOT%'
		AND STD.SpecialtyTypeDesc NOT LIKE 'Z%'
		OPTION (MAXDOP 1)	
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH
*/

-- RETM-564 new logic
BEGIN TRY

		IF OBJECT_ID('TEMPDB..##hold_eds_providerdim') <> 0
			DROP TABLE ##hold_eds_providerdim
 
		SELECT DISTINCT SourceDataKey, Providerid, ProviderType_ProviderTypeDesc
		INTO	##hold_eds_providerdim
		FROM	EDPS_Data.dbo.EDS_ProviderDim
 
		CREATE NONCLUSTERED INDEX tIndex ON ##hold_eds_providerdim (providerid)
 
		IF OBJECT_ID('TEMPDB..##hold_mdqolib_providerdim') <> 0
			DROP TABLE ##hold_mdqolib_providerdim
 
		SELECT	PD.SourceDataKey, pd.ProviderID, std.SpecialtyTypeDesc, 
				COALESCE(LEFT(STD.SpecialtyTypeDesc, 60), '') as coalesce_SpecialtyTypeDesc
		INTO	##hold_mdqolib_providerdim
		FROM	MDQOLib.dbo.ProviderDim	PD
		INNER JOIN	MDQOLib.dbo.ProviderSpecialtyXref PSX
			ON	PD.ProviderKey			= PSX.ProviderKey
			AND PD.SourceDataKey		= PSX.SourceDataKey
		INNER JOIN	MDQOLib.dbo.SpecialtyTypeDim STD
			ON	PSX.SourceDataKey		= STD.SourceDataKey
			AND PSX.SpecialtyTypeKey	= STD.SpecialtyTypeKey
		WHERE	pd.ProviderID IN (SELECT providerid from ##hold_eds_providerdim)
		AND		STD.SpecialtyTypeDesc NOT IN ('', ' ', 'UNKNOWN', 'NA', 'N/A')
		AND		STD.SpecialtyTypeDesc NOT LIKE '%DO NOT%'
		AND		STD.SpecialtyTypeDesc NOT LIKE 'Z%'
 
		IF OBJECT_ID('TEMPDB..##hold_final_results') <> 0
			DROP TABLE ##hold_final_results
 
		SELECT	a.SourceDataKey, a.ProviderID, a.ProviderType_ProviderTypeDesc, 
				b.coalesce_SpecialtyTypeDesc,
				CASE
					WHEN	a.ProviderType_ProviderTypeDesc <> b.coalesce_SpecialtyTypeDesc
					THEN	'NOT EQUAL'
					ELSE	'EQUAL'
				END	as ARE_THEY_EQUAL
		INTO	##hold_final_results
		FROM	##hold_eds_providerdim a
		INNER JOIN	##hold_mdqolib_providerdim b
			ON	b.SourceDataKey		= a.SourceDataKey
			AND	b.ProviderID		= a.ProviderID
		ORDER BY 5 DESC, a.SourceDataKey, a.ProviderID
 
		UPDATE	p
		SET		p.ProviderType_ProviderTypeDesc = hfr.coalesce_SpecialtyTypeDesc
		FROM	EDPS_Data.dbo.EDS_ProviderDim	p
		INNER JOIN ##hold_final_results		hfr
			ON	hfr.SourceDataKey		= p.SourceDataKey
			AND	hfr.ProviderID			= p.ProviderID
		WHERE	hfr.ARE_THEY_EQUAL	= 'NOT EQUAL'

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


	
BEGIN TRY	

	--
	--	Set known bad values to NULL...
	--
	
	UPDATE dbo.EDS_ProviderDim SET ProviderTypeCode = NULL WHERE ProviderTypeCode LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET ProviderStatus = NULL WHERE ProviderStatus LIKE '%UNKNOW%'

	UPDATE dbo.EDS_ProviderDim SET GlobalCurrentPatientLoad = NULL WHERE ISNUMERIC(GlobalCurrentPatientLoad) = 0
	
	UPDATE dbo.EDS_ProviderDim SET PrimaryBusinessName = NULL WHERE PrimaryBusinessName LIKE '%UNKNOW%'

	UPDATE dbo.EDS_ProviderDim SET AdditionalBusinessName = NULL WHERE AdditionalBusinessName LIKE '%UNKNOW%'

	UPDATE dbo.EDS_ProviderDim SET FullName = NULL WHERE FullName LIKE '%UNKNOW%'

	UPDATE dbo.EDS_ProviderDim SET ReverseFullName = NULL WHERE ReverseFullName LIKE '%UNKNOW%'

	UPDATE dbo.EDS_ProviderDim SET LastName = NULL WHERE LastName LIKE '%UNKNOW%'

	UPDATE dbo.EDS_ProviderDim SET FirstName = NULL WHERE FirstName LIKE '%UNKNOW%'

	UPDATE dbo.EDS_ProviderDim SET MiddleName = NULL WHERE MiddleName LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET Title = NULL WHERE Title LIKE '%--%'
	
	UPDATE dbo.EDS_ProviderDim SET GlobalPanelSize = NULL WHERE GlobalPanelSize LIKE '%--%'
	
	UPDATE dbo.EDS_ProviderDim SET NewPatientFlag = NULL WHERE NewPatientFlag NOT IN ('Y', 'N')
	
	UPDATE dbo.EDS_ProviderDim SET DeaNumber = NULL WHERE LEN(DeaNumber) != 9
	
	UPDATE dbo.EDS_ProviderDim SET Gender = NULL WHERE Gender NOT IN ('M', 'F', 'U')
	
	UPDATE dbo.EDS_ProviderDim SET DOBDateKey = 0
	WHERE
			DOBDateKey < 19000101
			OR	DOBDateKey >= CAST(REPLACE(CAST(GETDATE() AS DATE), '-', '') AS INT)
			OR	DOBDateKey IS NULL

	UPDATE dbo.EDS_ProviderDim SET UPIN = NULL WHERE UPIN LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET FIDN = NULL WHERE ISNUMERIC(FIDN) = 0
	
	UPDATE dbo.EDS_ProviderDim SET NPID = NULL WHERE ISNUMERIC(NPID) = 0 OR LEN(NPID) != 10
	
	UPDATE dbo.EDS_ProviderDim SET MedicaidID = NULL WHERE MedicaidID LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET MedicareID = NULL WHERE MedicareID LIKE '%UNKNOW%'

	UPDATE dbo.EDS_ProviderDim SET HandicapAccess = NULL WHERE HandicapAccess NOT IN ('Y', 'N')
	
	UPDATE dbo.EDS_ProviderDim SET CredentialingStatus = NULL WHERE CredentialingStatus NOT IN ('CREDENTIALED', 'UNCREDENTIALED')
	
	UPDATE dbo.EDS_ProviderDim SET ProvCategory = NULL WHERE ProvCategory NOT IN ('A','F','G','I','N','P','U','Z')

	UPDATE dbo.EDS_ProviderDim SET LicenseTypeCode = NULL WHERE LicenseTypeCode LIKE '%-%'

	UPDATE dbo.EDS_ProviderDim SET LeasedStatusCode = NULL WHERE LeasedStatusCode LIKE '%-%'

	UPDATE dbo.EDS_ProviderDim SET PreferredStatusCode = NULL WHERE PreferredStatusCode LIKE '%-%'

	UPDATE dbo.EDS_ProviderDim SET ChildFlg = NULL WHERE ChildFlg NOT IN ('Y', 'N')

	UPDATE dbo.EDS_ProviderDim SET YouthFlg = NULL WHERE YouthFlg NOT IN ('Y', 'N')

	UPDATE dbo.EDS_ProviderDim SET AdultFlg = NULL WHERE AdultFlg NOT IN ('Y', 'N')

	UPDATE dbo.EDS_ProviderDim SET StandardHoursInd = NULL WHERE StandardHoursInd NOT IN ('Y', 'N')

	UPDATE dbo.EDS_ProviderDim SET AfterHoursInd = NULL WHERE AfterHoursInd NOT IN ('Y', 'N')
	
	UPDATE dbo.EDS_ProviderDim SET WeekendHoursInd = NULL WHERE WeekendHoursInd NOT IN ('Y', 'N')

	UPDATE dbo.EDS_ProviderDim SET ProviderType_ProviderTypeDesc = NULL WHERE ProviderType_ProviderTypeDesc LIKE '%UNKNOW%'
	
	--UPDATE dbo.EDS_ProviderDim SET ProviderPhone_PhoneNumber = NULL WHERE ProviderPhone_PhoneNumber LIKE '%UNKNOW%'
	
	--UPDATE dbo.EDS_ProviderDim SET ProviderPhone_FaxNumber = NULL WHERE ProviderPhone_FaxNumber LIKE '%UNKNOW%'
	
	--UPDATE dbo.EDS_ProviderDim SET ProviderAddress_AddressLine1 = NULL WHERE ProviderAddress_AddressLine1 LIKE '%UNKNOW%'
	
	--UPDATE dbo.EDS_ProviderDim SET ProviderAddress_AddressLine2 = NULL WHERE ProviderAddress_AddressLine2 LIKE '%UNKNOW%'
	
	--UPDATE dbo.EDS_ProviderDim SET ProviderAddress_City = NULL WHERE ProviderAddress_City LIKE '%UNKNOW%'
	
	--UPDATE dbo.EDS_ProviderDim SET ProviderAddress_State = NULL WHERE ProviderAddress_State IN ('', ' ', '--')
	
	--UPDATE dbo.EDS_ProviderDim SET ProviderAddress_ZipCode9 = NULL WHERE ProviderAddress_ZipCode9 LIKE '%UNKNOW%'
	
	--UPDATE dbo.EDS_ProviderDim SET ProviderAddress_AddressTypeDesc = NULL WHERE ProviderAddress_AddressTypeDesc LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET Ingenix_TaxonomyCode = NULL WHERE Ingenix_TaxonomyCode LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_NationalProviderID = NULL 
		WHERE ISNUMERIC(Vendor_NationalProviderID) = 0  
		OR	LEN(Vendor_NationalProviderID) < 10		
		OR Vendor_NationalProviderID = '9999999999'
		OR Vendor_NationalProviderID = '0000000000'
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_FederalID = NULL 
		WHERE ISNUMERIC(Vendor_FederalID) = 0
		OR	LEN(Vendor_FederalID) > 9
		OR	LEN(Vendor_FederalID) < 9		
		OR Vendor_FederalID = '999999999'
		OR Vendor_FederalID = '000000000'
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_VendorName = NULL WHERE Vendor_VendorName LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_LastName = NULL WHERE Vendor_LastName LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_FirstName = NULL WHERE Vendor_FirstName LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_AddressLine1 = NULL WHERE Vendor_AddressLine1 LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_AddressLine2 = NULL WHERE Vendor_AddressLine2 LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_Phone = NULL WHERE Vendor_Phone LIKE '%UNKNOW%' OR Vendor_Phone = '9999999999'
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_City = NULL WHERE Vendor_City LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_State = NULL WHERE Vendor_State IN ('', ' ', '--')
	
	UPDATE dbo.EDS_ProviderDim SET Vendor_Zip = NULL WHERE Vendor_Zip LIKE '%UNKNOW%'
	
	--
	--	Replace all Verisk-reserved characters...
	--
	
	UPDATE
		dbo.EDS_ProviderDim
	SET
		ProviderTypeCode = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProviderTypeCode, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		ProviderStatus = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProviderStatus, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		GlobalCurrentPatientLoad = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(GlobalCurrentPatientLoad, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		AdditionalBusinessName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(AdditionalBusinessName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		PrimaryBusinessName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(PrimaryBusinessName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		FullName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(FullName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		ReverseFullName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ReverseFullName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		LastName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LastName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		FirstName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(FirstName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		MiddleName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MiddleName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		Title = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Title, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		GlobalPanelSize = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(GlobalPanelSize, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		NewPatientFlag = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(NewPatientFlag, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		DeaNumber = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(DeaNumber, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		Gender = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Gender, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		UPIN = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(UPIN, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		FIDN = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(FIDN, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		NPID = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(NPID, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		MedicaidID = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MedicaidID, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		MedicareID = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MedicareID, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		HandicapAccess = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(HandicapAccess, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		CredentialingStatus = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(CredentialingStatus, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		ProvCategory = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProvCategory, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		LicenseTypeCode = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LicenseTypeCode, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		LeasedStatusCode = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LeasedStatusCode, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		PreferredStatusCode = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(PreferredStatusCode, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		ChildFlg = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ChildFlg, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		YouthFlg = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(YouthFlg, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		AdultFlg = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(AdultFlg, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		StandardHoursInd = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(StandardHoursInd, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		AfterHoursInd = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(AfterHoursInd, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		WeekendHoursInd = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(WeekendHoursInd, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		ProviderType_ProviderTypeDesc = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ProviderType_ProviderTypeDesc, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),


		Ingenix_TaxonomyCode = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Ingenix_TaxonomyCode, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		Ingenix_SpecialtyName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Ingenix_SpecialtyName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		Ingenix_SpecialtyGroupName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Ingenix_SpecialtyGroupName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
		

		Vendor_NationalProviderID  = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_NationalProviderID, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		Vendor_FederalID = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_FederalID, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		Vendor_VendorName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_VendorName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
		
		Vendor_LastName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_LastName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
		
		Vendor_FirstName = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_FirstName, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
		
		Vendor_AddressLine1 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_AddressLine1, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
		
		Vendor_AddressLine2 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_AddressLine2, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
		
		Vendor_Phone = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_Phone, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
		
		Vendor_City = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_City, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
		
		Vendor_State = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_State, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
		
		Vendor_Zip = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Vendor_Zip, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^','')
	

	--
		--EXEC [dbo].[EDS_ProviderDim_Validation] @PreOrPostScrub = 'POST'
	--


END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY
	--
	--	For all ProviderTypeCode = 01 or ProvCategory = G, set the ProviderGroupId = ProviderID
	--
	UPDATE
		dbo.EDS_ProviderDim
	SET
		ProviderGroupID = ProviderID
	WHERE
		RecordSource = 'P'
	AND	(ProvCategory = 'G' OR ProviderTypeCode = '01')
	AND ProviderGroupID IS NULL
	
	
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= 0,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderDim_Load EDS_ProviderDim Cleanup'
		AND		END_DT		IS NULL
		AND		STEP		= '8'

--
--	Build EDS_ProviderAddressDim table
--
BEGIN TRY

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load EDS_ProviderAddressDim'
		,'9', GETDATE(), NULL, NULL, 0, GETDATE() )

	TRUNCATE TABLE dbo.EDS_ProviderAddressDim

	INSERT INTO	
		dbo.EDS_ProviderAddressDim
				( SourceDataKey ,
				  ProviderID ,
				  AddressTypeCode ,
				  AddressLine1 ,
				  AddressLine2 ,
				  City ,
				  State ,
				  ZipCode9 ,
				  MultiAddressInd ,
				  Latitude ,
				  Longitude
				)

	SELECT
		p.SourceDataKey,
		p.ProviderID,
		pa.AddressTypeCode,
		pa.AddressLine1,
		pa.AddressLine2,
		pa.City,
		pa.State,
		pa.ZipCode9,
		pa.MultiAddressInd,
		pa.Latitude,
		pa.Longitude
	FROM 
		dbo.EDS_ProviderDim	p
	INNER JOIN
		MDQOLib.dbo.ProviderAddressDim	pa
		ON p.SourceDataKey = pa.SourceDataKey
		AND p.ProviderID = pa.ProviderID
		AND pa.Deleted = 0
		AND pa.ProviderAddressKey = (SELECT MAX(ProviderAddressKey) FROM MDQOLib.dbo.ProviderAddressDim
								WHERE SourceDataKey = pa.SourceDataKey
								AND ProviderID = pa.ProviderID
								AND AddressTypeCode = pa.AddressTypeCode
								AND MultiAddressInd = pa.MultiAddressInd
								AND Deleted = 0
							 )
	WHERE 
		p.RecordSource = 'P'

		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= @@ROWCOUNT,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderDim_Load EDS_ProviderAddressDim'
		AND		END_DT		IS NULL
		AND		STEP		= '9'
	--
	--	Remove all '0000' Zip-4 values
	--

	UPDATE
	dbo.EDS_ProviderAddressDim
	SET ZipCode9 = LEFT(ZipCode9, 5)
	WHERE SUBSTRING(ZipCode9, 6, 4) = '0000'


	UPDATE dbo.EDS_ProviderAddressDim SET AddressLine1 = NULL WHERE AddressLine1 LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderAddressDim SET AddressLine2 = NULL WHERE AddressLine2 LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderAddressDim SET City = NULL WHERE City LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderAddressDim SET State = NULL WHERE State IN ('', ' ', '--')
	
	UPDATE dbo.EDS_ProviderAddressDim SET ZipCode9 = NULL WHERE ZipCode9 LIKE '%UNKNOW%'


	UPDATE dbo.EDS_ProviderAddressDim 
	SET
		AddressLine1 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(AddressLine1, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		AddressLine2 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(AddressLine2, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		City = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(City, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		State = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(State, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),

		ZipCode9 = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ZipCode9, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^','')

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

--
--	Build ProviderPhoneDim table
--
BEGIN TRY

	INSERT INTO dbo.EXT_SYS_RUNLOG
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
	VALUES('EDS_ProviderDim_Load EDS_ProviderPhoneDim'
		,'10', GETDATE(), NULL, NULL, 0, GETDATE() )

	TRUNCATE TABLE dbo.EDS_ProviderPhoneDim

	INSERT INTO						--	237391
		dbo.EDS_ProviderPhoneDim
				( SourceDataKey ,
				  ProviderID ,
				  PhoneTypeCode ,
				  PhoneNumber ,
				  FaxNumber ,
				  MultiPhoneInd
				)
	SELECT
		pd.SourceDataKey,
		pd.ProviderID,
		pp.PhoneTypeCode,
		pp.PhoneNumber,
		pp.FaxNumber,
		pp.MultiPhoneInd
	FROM
		dbo.EDS_ProviderDim	pd
	INNER JOIN	
		MDQOLib.dbo.ProviderPhoneDim  pp
		ON pd.SourceDataKey = pp.SourceDataKey
		AND pd.ProviderID = pp.ProviderID
		AND pp.Deleted = 0
		AND pp.ProviderPhoneKey = (SELECT MAX(ProviderPhoneKey) FROM MDQOLib.dbo.ProviderPhoneDim
								WHERE SourceDataKey = pp.SourceDataKey
								AND ProviderID = pp.ProviderID
								AND PhoneTypeCode = pp.PhoneTypeCode
								AND MultiPhoneInd = pp.MultiPhoneInd
								AND Deleted = 0
							 )
	WHERE
		pd.RecordSource = 'P'

		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= @@ROWCOUNT,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderDim_Load EDS_ProviderPhoneDim'
		AND		END_DT		IS NULL
		AND		STEP		= '10'		

	--	Scrub data

	UPDATE
		dbo.EDS_ProviderPhoneDim
		SET
			PhoneNumber = REPLACE(REPLACE(PhoneNumber, '-', ''), '/', ''),
			FaxNumber = REPLACE(REPLACE(FaxNumber, '-', ''), '/', '')

	UPDATE dbo.EDS_ProviderPhoneDim SET PhoneNumber = NULL WHERE PhoneNumber LIKE '%UNKNOW%'
	
	UPDATE dbo.EDS_ProviderPhoneDim SET FaxNumber = NULL WHERE FaxNumber LIKE '%UNKNOW%'

	UPDATE
		dbo.EDS_ProviderPhoneDim
		SET
			PhoneTypeCode = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(PhoneTypeCode, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
			PhoneNumber = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(PhoneNumber, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^',''),
			FaxNumber = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(FaxNumber, '~', ''), '`', ''),'*',''),':',''),'"',''),'|',''),'^','')


END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY
	--
	--	Replace all NULL values with '' to avoid problems in creating EXT_HRP_CLAIM_MAP records
	--
	
	--	dbo.EDS_ProviderDim
	UPDATE 
		dbo.EDS_ProviderDim
	SET
		ProviderGroupID = CASE WHEN ProviderGroupID IS NULL THEN '' ELSE ProviderGroupID END ,
		ProviderTypeCode = CASE WHEN ProviderTypeCode IS NULL THEN '' ELSE ProviderTypeCode END ,
		ProviderStatus = CASE WHEN ProviderStatus IS NULL THEN '' ELSE ProviderStatus END ,
		GlobalCurrentPatientLoad = CASE WHEN GlobalCurrentPatientLoad IS NULL THEN '' ELSE GlobalCurrentPatientLoad END ,
		AdditionalBusinessName = CASE WHEN AdditionalBusinessName IS NULL THEN '' ELSE AdditionalBusinessName END ,
		PrimaryBusinessName = CASE WHEN PrimaryBusinessName IS NULL THEN '' ELSE PrimaryBusinessName END ,
		FullName = CASE WHEN FullName IS NULL THEN '' ELSE FullName END ,
		ReverseFullName = CASE WHEN ReverseFullName IS NULL THEN '' ELSE ReverseFullName END ,
		LastName = CASE WHEN LastName IS NULL THEN '' ELSE LastName END ,
		FirstName = CASE WHEN FirstName IS NULL THEN '' ELSE FirstName END ,
		MiddleName = CASE WHEN MiddleName IS NULL THEN '' ELSE MiddleName END ,
		Title = CASE WHEN Title IS NULL THEN '' ELSE Title END ,
		GlobalPanelSize = CASE WHEN GlobalPanelSize IS NULL THEN '' ELSE GlobalPanelSize END ,
		NewPatientFlag = CASE WHEN NewPatientFlag IS NULL THEN '' ELSE NewPatientFlag END ,
		DeaNumber = CASE WHEN DeaNumber IS NULL THEN '' ELSE DeaNumber END ,
		Gender = CASE WHEN Gender IS NULL THEN '' ELSE Gender END ,
		DOBDateKey = CASE WHEN DOBDateKey IS NULL THEN '' ELSE DOBDateKey END ,
		UPIN = CASE WHEN UPIN IS NULL THEN '' ELSE UPIN END ,
		FIDN = CASE WHEN FIDN IS NULL THEN '' ELSE FIDN END ,
		NPID = CASE WHEN NPID IS NULL THEN '' ELSE NPID END ,
		MedicaidID = CASE WHEN MedicaidID IS NULL THEN '' ELSE MedicaidID END ,
		MedicareID = CASE WHEN MedicareID IS NULL THEN '' ELSE MedicareID END ,
		HandicapAccess = CASE WHEN HandicapAccess IS NULL THEN '' ELSE HandicapAccess END ,
		CredentialingStatus = CASE WHEN CredentialingStatus IS NULL THEN '' ELSE CredentialingStatus END ,
		ProvCategory = CASE WHEN ProvCategory IS NULL THEN '' ELSE ProvCategory END ,
		LicenseTypeCode = CASE WHEN LicenseTypeCode IS NULL THEN '' ELSE LicenseTypeCode END ,
		LeasedStatusCode = CASE WHEN LeasedStatusCode IS NULL THEN '' ELSE LeasedStatusCode END ,
		PreferredStatusCode = CASE WHEN PreferredStatusCode IS NULL THEN '' ELSE PreferredStatusCode END ,
		ChildFlg = CASE WHEN ChildFlg IS NULL THEN '' ELSE ChildFlg END ,
		YouthFlg = CASE WHEN YouthFlg IS NULL THEN '' ELSE YouthFlg END ,
		AdultFlg = CASE WHEN AdultFlg IS NULL THEN '' ELSE AdultFlg END ,
		StandardHoursInd = CASE WHEN StandardHoursInd IS NULL THEN '' ELSE StandardHoursInd END ,
		AfterHoursInd = CASE WHEN AfterHoursInd IS NULL THEN '' ELSE AfterHoursInd END ,
		WeekendHoursInd = CASE WHEN WeekendHoursInd IS NULL THEN '' ELSE WeekendHoursInd END ,
		ProviderType_ProviderTypeDesc = CASE WHEN ProviderType_ProviderTypeDesc IS NULL THEN '' ELSE ProviderType_ProviderTypeDesc END ,
		Ingenix_TaxonomyCode = CASE WHEN Ingenix_TaxonomyCode IS NULL THEN '' ELSE Ingenix_TaxonomyCode END ,
		Ingenix_SpecialtyName = CASE WHEN Ingenix_SpecialtyName IS NULL THEN '' ELSE Ingenix_SpecialtyName END ,
		Ingenix_SpecialtyGroupName = CASE WHEN Ingenix_SpecialtyGroupName IS NULL THEN '' ELSE Ingenix_SpecialtyGroupName END ,
		Vendor_VendorID = CASE WHEN Vendor_VendorID IS NULL THEN '' ELSE Vendor_VendorID END ,
		Vendor_VendorTypeCode = CASE WHEN Vendor_VendorTypeCode IS NULL THEN '' ELSE Vendor_VendorTypeCode END ,
		Vendor_VendorCategory = CASE WHEN Vendor_VendorCategory IS NULL THEN '' ELSE Vendor_VendorCategory END ,
		Vendor_NationalProviderID = CASE WHEN Vendor_NationalProviderID IS NULL THEN '' ELSE Vendor_NationalProviderID END ,
		Vendor_FederalID = CASE WHEN Vendor_FederalID IS NULL THEN '' ELSE Vendor_FederalID END ,
		Vendor_VendorName = CASE WHEN Vendor_VendorName IS NULL THEN '' ELSE Vendor_VendorName END ,
		Vendor_LastName = CASE WHEN Vendor_LastName IS NULL THEN '' ELSE Vendor_LastName END ,
		Vendor_FirstName = CASE WHEN Vendor_FirstName IS NULL THEN '' ELSE Vendor_FirstName END ,
		Vendor_AddressLine1 = CASE WHEN Vendor_AddressLine1 IS NULL THEN '' ELSE Vendor_AddressLine1 END ,
		Vendor_AddressLine2 = CASE WHEN Vendor_AddressLine2 IS NULL THEN '' ELSE Vendor_AddressLine2 END ,
		Vendor_Phone = CASE WHEN Vendor_Phone IS NULL THEN '' ELSE Vendor_Phone END ,
		Vendor_City = CASE WHEN Vendor_City IS NULL THEN '' ELSE Vendor_City END ,
		Vendor_State = CASE WHEN Vendor_State IS NULL THEN '' ELSE Vendor_State END ,
		Vendor_Zip = CASE WHEN Vendor_Zip IS NULL THEN '' ELSE Vendor_Zip END
	

	--	dbo.EDS_ProviderAddressDim
	UPDATE 
		dbo.EDS_ProviderAddressDim
	SET
		AddressTypeCode = CASE WHEN AddressTypeCode IS NULL THEN '' ELSE AddressTypeCode END,
		AddressLine1 = CASE WHEN AddressLine1 IS NULL THEN '' ELSE AddressLine1 END,
		AddressLine2 = CASE WHEN AddressLine2 IS NULL THEN '' ELSE AddressLine2 END,
		City = CASE WHEN City IS NULL THEN '' ELSE City END,
		State = CASE WHEN State IS NULL THEN '' ELSE State END,
		ZipCode9 = CASE WHEN ZipCode9 IS NULL THEN '' ELSE ZipCode9 END,
		MultiAddressInd = CASE WHEN MultiAddressInd IS NULL THEN '' ELSE MultiAddressInd END,
		Latitude = CASE WHEN Latitude IS NULL THEN '' ELSE Latitude END,
		Longitude = CASE WHEN Longitude IS NULL THEN '' ELSE Longitude END


	--	dbo.EDS_ProviderPhoneDim	
	UPDATE
		dbo.EDS_ProviderPhoneDim
	SET
		PhoneTypeCode = CASE WHEN PhoneTypeCode IS NULL THEN '' ELSE PhoneTypeCode END,
		PhoneNumber = CASE WHEN PhoneNumber IS NULL THEN '' ELSE PhoneNumber END,
		FaxNumber = CASE WHEN FaxNumber IS NULL THEN '' ELSE FaxNumber END,
		MultiPhoneInd = CASE WHEN MultiPhoneInd IS NULL THEN '' ELSE MultiPhoneInd END
	

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH



	IF @@TRANCOUNT > 0
	COMMIT TRANSACTION
/*
	IF OBJECT_ID('TEMPDB..#ClaimProviders') <> 0
	DROP TABLE #ClaimProviders

	IF OBJECT_ID('TEMPDB..#cteDistProviderNPI') <> 0
	DROP TABLE #cteDistProviderNPI

	IF OBJECT_ID('TEMPDB..#cteProviderID') <> 0
	DROP TABLE #cteProviderNPI

	IF OBJECT_ID('TEMPDB..#cteVENDORID') <> 0
	DROP TABLE #cteVENDORID
*/
	EXEC [dbo].[ut_EDS_ProviderDim_Indexes]
		@DropCreate	 = 'C'

		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= 0,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDS_ProviderDim_Load EDPS_Data'
		AND		END_DT		IS NULL
		AND		STEP		= '1'
	
END

/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()

BEGIN TRANSACTION

	EXEC [dbo].[EDS_ProviderDim_Load]
		
ROLLBACK TRANSACTION

SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/

