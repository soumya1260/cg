﻿

CREATE  PROCEDURE [dbo].[ut_EDS_ProviderDim_Indexes]
(
	@DropCreate					CHAR(1)			--	"D" or "C"
)
/**********************************************************************************************
PROCEDURE:	[dbo].[ut_EDS_ProviderDim_Indexes]
PURPOSE:	Drops or Creates the indexes on [dbo].[EDS_ProviderDim]
NOTES:		
CREATED:	2013-05-22, Dwight Staggs
REVISIONS:
Date		Author			Description
------------------------------------------------------------------------------------------------
	
						
*************************************************************************************************/
AS

BEGIN

	SET NOCOUNT ON;
	
	DECLARE @CatchErrorMessage VARCHAR(2200);
	

BEGIN TRY
	IF @DropCreate = 'D'
	BEGIN

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_FIDN_NPID')
		DROP INDEX [NIX_EDS_ProviderDim_FIDN_NPID] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_DeaNumber')
		DROP INDEX [NIX_EDS_ProviderDim_NPID_DeaNumber] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_INC_UPINFullReverseLastFirstMiddleNames')
		DROP INDEX [NIX_EDS_ProviderDim_NPID_INC_UPINFullReverseLastFirstMiddleNames] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_UPIN')
		DROP INDEX [NIX_EDS_ProviderDim_NPID_UPIN] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_ProviderExtract1')
		DROP INDEX [NIX_EDS_ProviderDim_ProviderExtract1] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_ProviderID_SourceDataKey_INC_FullReverseLastFirstMiddleNames')
		DROP INDEX [NIX_EDS_ProviderDim_ProviderID_SourceDataKey_INC_FullReverseLastFirstMiddleNames] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_Vendor_FederalID_INC_FIDN')
		DROP INDEX [NIX_EDS_ProviderDim_Vendor_FederalID_INC_FIDN] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

	
	END
	ELSE	
	BEGIN 
	
		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_FIDN_NPID')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_FIDN_NPID] ON [dbo].[EDS_ProviderDim] 
		(
			[FIDN] ASC,
			[NPID] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_DeaNumber')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_NPID_DeaNumber] ON [dbo].[EDS_ProviderDim] 
		(
			[NPID] ASC,
			[DeaNumber] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_INC_UPINFullReverseLastFirstMiddleNames')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_NPID_INC_UPINFullReverseLastFirstMiddleNames] ON [dbo].[EDS_ProviderDim] 
		(
			[NPID] ASC
		)
		INCLUDE ( [FirstName],
		[FullName],
		[LastName],
		[MiddleName],
		[ReverseFullName],
		[UPIN]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_UPIN')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_NPID_UPIN] ON [dbo].[EDS_ProviderDim] 
		(
			[NPID] ASC,
			[UPIN] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_ProviderExtract1')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_ProviderExtract1] ON [dbo].[EDS_ProviderDim] 
		(
			[ProviderTypeCode] ASC
		)
		INCLUDE ( [ProviderID],
		[SourceDataKey],
		[Vendor_AddressLine1],
		[Vendor_AddressLine2],
		[Vendor_City],
		[Vendor_State],
		[Vendor_Zip]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_ProviderID_SourceDataKey_INC_FullReverseLastFirstMiddleNames')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_ProviderID_SourceDataKey_INC_FullReverseLastFirstMiddleNames] ON [dbo].[EDS_ProviderDim] 
		(
			[ProviderID] ASC,
			[SourceDataKey] ASC
		)
		INCLUDE ( [FirstName],
		[FullName],
		[LastName],
		[MiddleName],
		[ReverseFullName]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_Vendor_FederalID_INC_FIDN')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_Vendor_FederalID_INC_FIDN] ON [dbo].[EDS_ProviderDim] 
		(
			[Vendor_FederalID] ASC
		)
		INCLUDE ( [FIDN]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	END


END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH
	

END



/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()

BEGIN TRANSACTION

	EXEC [dbo].[ut_EDS_ProviderDim_Indexes]
		@DropCreate	 = 'C'
		
ROLLBACK TRANSACTION

SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/














