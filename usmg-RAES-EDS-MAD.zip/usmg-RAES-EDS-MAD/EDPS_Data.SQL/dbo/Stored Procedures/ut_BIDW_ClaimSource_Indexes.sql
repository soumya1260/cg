﻿

CREATE  PROCEDURE [dbo].[ut_BIDW_ClaimSource_Indexes]
(
	@DropCreate					CHAR(1)			--	"D" or "C"
)
/**********************************************************************************************
PROCEDURE:	[dbo].[ut_BIDW_ClaimSource_Indexes]
PURPOSE:	Drops or Creates the indexes on ALL of the Claims source tables imported from BIDW
			and also the EDS_ProviderDim table
NOTES:		This SP is executed before and after each dbo from BIDW (in SSIS package)
CREATED:	2013-05-22, Dwight Staggs
REVISIONS:
Date		Author			Description
------------------------------------------------------------------------------------------------
05/05/15	Scott Waller	Add updates to EXT_SYS_RUNLOG for troubleshooting purposes, and keeping
							track of runtimes.	
						
*************************************************************************************************/
AS

BEGIN

	SET NOCOUNT ON;
	
	DECLARE @CatchErrorMessage VARCHAR(2200);
	

BEGIN TRY
	IF @DropCreate = 'D'
	BEGIN

-- Scott Waller 05/05/15
		INSERT INTO dbo.EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT)
		VALUES('EDPS_Data ut_BIDW_ClaimSource_Indexes - DROP'
			,'1'
			,GETDATE()
			,NULL
			,NULL
			,0
			,GETDATE() )
--end Scott Waller

		--	[CLAIMDETAILDIM]
		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIM]') AND name = N'NIX_ClaimDetailDim_Submissions_1')
		DROP INDEX [NIX_ClaimDetailDim_Submissions_1] ON [dbo].[CLAIMDETAILDIM] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIM]') AND name = N'NIX_ClaimDetailDim_Submissions_2')
		DROP INDEX [NIX_ClaimDetailDim_Submissions_2] ON [dbo].[CLAIMDETAILDIM] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIM]') AND name = N'NIX_ClaimDetailDim_Submissions_3')
		DROP INDEX [NIX_ClaimDetailDim_Submissions_3] ON [dbo].[CLAIMDETAILDIM] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIM]') AND name = N'NIX_ClaimDetailDim_Submissions_4')
		DROP INDEX [NIX_ClaimDetailDim_Submissions_4] ON [dbo].[CLAIMDETAILDIM] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIM]') AND name = N'NIX_ClaimDetailDim_ClaimID_SDK_ClaimLineID')
		DROP INDEX [NIX_ClaimDetailDim_ClaimID_SDK_ClaimLineID] ON [dbo].[CLAIMDETAILDIM] WITH ( ONLINE = OFF )

		--	[CLAIMDIM]
		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDIM]') AND name = N'NIX_ClaimDim_ExclusionProcessing_1')
		DROP INDEX [NIX_ClaimDim_ExclusionProcessing_1] ON [dbo].[CLAIMDIM] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDIM]') AND name = N'NIX_ClaimDim_ExtractProcessing_1')
		DROP INDEX [NIX_ClaimDim_ExtractProcessing_1] ON [dbo].[CLAIMDIM] WITH ( ONLINE = OFF )


		--	[CLAIMAGG]
		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMAGG]') AND name = N'NIX_ClaimAgg_Submissions_1')
		DROP INDEX [NIX_ClaimAgg_Submissions_1] ON [dbo].[CLAIMAGG] WITH ( ONLINE = OFF )	

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMAGG]') AND name = N'NIX_ClaimAgg_Submissions_2')
		DROP INDEX [NIX_ClaimAgg_Submissions_2] ON [dbo].[CLAIMAGG] WITH ( ONLINE = OFF )


		--	[CLAIMDIAGNOSISDIM]
		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDIAGNOSISDIM]') AND name = N'NIX_ClaimDiagnosisDim_Submissions_1')
		DROP INDEX [NIX_ClaimDiagnosisDim_Submissions_1] ON [dbo].[CLAIMDIAGNOSISDIM] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDIAGNOSISDIM]') AND name = N'NIX_ClaimDiagnosisDim_Submissions_2')
		DROP INDEX [NIX_ClaimDiagnosisDim_Submissions_2] ON [dbo].[CLAIMDIAGNOSISDIM] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDIAGNOSISDIM]') AND name = N'NIX_ClaimDiagnosisDim_Submissions_3')
		DROP INDEX [NIX_ClaimDiagnosisDim_Submissions_3] ON [dbo].[CLAIMDIAGNOSISDIM] WITH ( ONLINE = OFF )

		--	[CLAIMDETAILDIAGNOSISDIM]
		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIAGNOSISDIM]') AND name = N'NIX_ClaimDetailDiagnosisDim_Submissions_1')
		DROP INDEX [NIX_ClaimDetailDiagnosisDim_Submissions_1] ON [dbo].[CLAIMDETAILDIAGNOSISDIM] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIAGNOSISDIM]') AND name = N'NIX_ClaimDetailDiagnosisDim_Submissions_2')
		DROP INDEX [NIX_ClaimDetailDiagnosisDim_Submissions_2] ON [dbo].[CLAIMDETAILDIAGNOSISDIM] WITH ( ONLINE = OFF )

		--	[ClaimModifierDim]
		
		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMMODIFIERDIM]') AND name = N'NIX_ClaimModifierDim_Submissions_1')
		DROP INDEX [NIX_ClaimModifierDim_Submissions_1] ON [dbo].[CLAIMMODIFIERDIM] WITH ( ONLINE = OFF )
		
		--	[UB921AdmissionDim]
		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UB921ADMISSIONDIM]') AND name = N'NIX_UB921AdmissionDim_Submissions_1')
		DROP INDEX [NIX_UB921AdmissionDim_Submissions_1] ON [dbo].[UB921ADMISSIONDIM] WITH ( ONLINE = OFF )
		

		--
		--	EDS_ProviderDim
		--

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_FIDN_NPID')
		DROP INDEX [NIX_EDS_ProviderDim_FIDN_NPID] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_DeaNumber')
		DROP INDEX [NIX_EDS_ProviderDim_NPID_DeaNumber] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_INC_UPINFullReverseLastFirstMiddleNames')
		DROP INDEX [NIX_EDS_ProviderDim_NPID_INC_UPINFullReverseLastFirstMiddleNames] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_UPIN')
		DROP INDEX [NIX_EDS_ProviderDim_NPID_UPIN] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_ProviderExtract1')
		DROP INDEX [NIX_EDS_ProviderDim_ProviderExtract1] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_ProviderID_SourceDataKey_INC_FullReverseLastFirstMiddleNames')
		DROP INDEX [NIX_EDS_ProviderDim_ProviderID_SourceDataKey_INC_FullReverseLastFirstMiddleNames] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

		IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_Vendor_FederalID_INC_FIDN')
		DROP INDEX [NIX_EDS_ProviderDim_Vendor_FederalID_INC_FIDN] ON [dbo].[EDS_ProviderDim] WITH ( ONLINE = OFF )

-- Scott Waller 05/05/2015
-- update Run Controls
		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= 0,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDPS_Data ut_BIDW_ClaimSource_Indexes - DROP'
		AND		END_DT		IS NULL
		AND		STEP		= '1'
-- end Scott Waller	
			
	END
	ELSE	
	BEGIN 

-- Scott Waller 05/05/15
		INSERT INTO dbo.EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT)
		VALUES('EDPS_Data ut_BIDW_ClaimSource_Indexes - CREATE'
			,'1'
			,GETDATE()
			,NULL
			,NULL
			,0
			,GETDATE() )
--end Scott Waller
	--	[CLAIMDETAILDIM]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIM]') AND name = N'NIX_ClaimDetailDim_Submissions_1')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDim_Submissions_1] ON [dbo].[CLAIMDETAILDIM] 
		(
			[PROCEDURECODE] ASC
		)
		INCLUDE ( [CLAIMID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIM]') AND name = N'NIX_ClaimDetailDim_Submissions_2')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDim_Submissions_2] ON [dbo].[CLAIMDETAILDIM] 
		(
			[CLAIMID] ASC
		)
		INCLUDE ( [CLAIMLINEID],
		[PAYMENTAMOUNT],
		[QUANTITY],
		[REQUESTEDAMT],
		[COBAMT],
		[DEDUCTIBLEAMT],
		[COPAYAMT],
		[COINSURANCEAMT]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIM]') AND name = N'NIX_ClaimDetailDim_Submissions_3')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDim_Submissions_3] ON [dbo].[CLAIMDETAILDIM] 
		(
			[COPAYAMT] ASC
		)
		INCLUDE ( [CLAIMID],
		[CLAIMLINEID],
		[QUANTITY]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIM]') AND name = N'NIX_ClaimDetailDim_Submissions_4')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDim_Submissions_4] ON [dbo].[CLAIMDETAILDIM] 
		(
			[COINSURANCEAMT] ASC
		)
		INCLUDE ( [CLAIMID],
		[CLAIMLINEID],
		[QUANTITY]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIM]') AND name = N'NIX_ClaimDetailDim_ClaimID_SDK_ClaimLineID')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDim_ClaimID_SDK_ClaimLineID] ON [dbo].[CLAIMDETAILDIM] 
		(
			[CLAIMID] ASC,
			[SOURCEDATAKEY] ASC,
			[CLAIMLINEID] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]


	--	[CLAIMDIM]
		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDIM]') AND name = N'NIX_ClaimDim_ExclusionProcessing_1')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDim_ExclusionProcessing_1] ON [dbo].[CLAIMDIM] 
		(
			[CLAIMID] ASC,
			[SOURCEDATAKEY] ASC
		)
		INCLUDE ( [FORMTYPECODE]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDIM]') AND name = N'NIX_ClaimDim_ExtractProcessing_1')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDim_ExtractProcessing_1] ON [dbo].[CLAIMDIM] 
		(
			[FORMTYPECODE] ASC,
			[SOURCEDATAKEY] ASC
		)
		INCLUDE ( [CLAIMID],
		[DENIEDFLAG],
		[LOBCODE]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--	[CLAIMAGG]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMAGG]') AND name = N'NIX_ClaimAgg_Submissions_1')
		CREATE NONCLUSTERED INDEX [NIX_ClaimAgg_Submissions_1] ON [dbo].[CLAIMAGG] 
		(
			[CURRENTSTATUSCODE] ASC,
			[PREVIOUSCLAIMID] ASC
		)
		INCLUDE ( [CLAIMID]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMAGG]') AND name = N'NIX_ClaimAgg_Submissions_2')
		CREATE NONCLUSTERED INDEX [NIX_ClaimAgg_Submissions_2] ON [dbo].[CLAIMAGG] 
		(
			[CLAIMID] ASC
		)
		INCLUDE ( [PAIDDATEKEY]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--	[CLAIMDIAGNOSISDIM]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDIAGNOSISDIM]') AND name = N'NIX_ClaimDiagnosisDim_Submissions_1')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDiagnosisDim_Submissions_1] ON [dbo].[CLAIMDIAGNOSISDIM] 
		(
			[SEQUENCE] ASC
		)
		INCLUDE ( [CLAIMID],
		[DIAGNOSISCODE],
		[POAIND]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDIAGNOSISDIM]') AND name = N'NIX_ClaimDiagnosisDim_Submissions_2')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDiagnosisDim_Submissions_2] ON [dbo].[CLAIMDIAGNOSISDIM] 
		(
			[DIAGNOSISTYPECODE] ASC
		)
		INCLUDE ( [CLAIMID],
		[DIAGNOSISCODE],
		[POAIND]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDIAGNOSISDIM]') AND name = N'NIX_ClaimDiagnosisDim_Submissions_3')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDiagnosisDim_Submissions_3] ON [dbo].[CLAIMDIAGNOSISDIM] 
		(
			[CLAIMID] ASC,
			[DIAGNOSISTYPECODE] ASC
		)
		INCLUDE ( [DIAGNOSISCODE],
		[POAIND]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		
	--	[CLAIMDETAILDIAGNOSISDIM]
		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIAGNOSISDIM]') AND name = N'NIX_ClaimDetailDiagnosisDim_Submissions_1')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDiagnosisDim_Submissions_1] ON [dbo].[CLAIMDETAILDIAGNOSISDIM] 
		(
			[SEQUENCE] ASC
		)
		INCLUDE ( [CLAIMID],
		[CLAIMLINEID],
		[DIAGNOSISCODE]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMDETAILDIAGNOSISDIM]') AND name = N'NIX_ClaimDetailDiagnosisDim_Submissions_2')
		CREATE NONCLUSTERED INDEX [NIX_ClaimDetailDiagnosisDim_Submissions_2] ON [dbo].[CLAIMDETAILDIAGNOSISDIM] 
		(
			[CLAIMID] ASC
		)
		INCLUDE ( [SOURCEDATAKEY],
		[CLAIMDETAILDIAGNOSISKEY],
		[CLAIMLINEID],
		[DIAGNOSISCODE],
		[SEQUENCE]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

	--	[ClaimModifierDim]
		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[CLAIMMODIFIERDIM]') AND name = N'NIX_ClaimModifierDim_Submissions_1')
		CREATE NONCLUSTERED INDEX [NIX_ClaimModifierDim_Submissions_1] ON [dbo].[CLAIMMODIFIERDIM] 
		(
			[SEQUENCE] ASC
		)
		INCLUDE ( [CLAIMID],
		[CLAIMLINEID],
		[MODIFIERCODE]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]


	--	UB921AdmissionDim
		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[UB921ADMISSIONDIM]') AND name = N'NIX_UB921AdmissionDim_Submissions_1')
		CREATE NONCLUSTERED INDEX [NIX_UB921AdmissionDim_Submissions_1] ON [dbo].[UB921ADMISSIONDIM] 
		(
			[CLAIMID] ASC
		)
		INCLUDE ( [BILLTYPECODE]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		
		--
		--	EDS_ProviderDim
		--

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_FIDN_NPID')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_FIDN_NPID] ON [dbo].[EDS_ProviderDim] 
		(
			[FIDN] ASC,
			[NPID] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_DeaNumber')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_NPID_DeaNumber] ON [dbo].[EDS_ProviderDim] 
		(
			[NPID] ASC,
			[DeaNumber] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_INC_UPINFullReverseLastFirstMiddleNames')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_NPID_INC_UPINFullReverseLastFirstMiddleNames] ON [dbo].[EDS_ProviderDim] 
		(
			[NPID] ASC
		)
		INCLUDE ( [UPIN],
		[FullName],
		[ReverseFullName],
		[LastName],
		[FirstName],
		[MiddleName]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_NPID_UPIN')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_NPID_UPIN] ON [dbo].[EDS_ProviderDim] 
		(
			[NPID] ASC,
			[UPIN] ASC
		)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_ProviderExtract1')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_ProviderExtract1] ON [dbo].[EDS_ProviderDim] 
		(
			[ProviderTypeCode] ASC
		)
		INCLUDE ( [ProviderID],
		[SourceDataKey],
		[Vendor_AddressLine1],
		[Vendor_AddressLine2],
		[Vendor_City],
		[Vendor_State],
		[Vendor_Zip]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_ProviderID_SourceDataKey_INC_FullReverseLastFirstMiddleNames')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_ProviderID_SourceDataKey_INC_FullReverseLastFirstMiddleNames] ON [dbo].[EDS_ProviderDim] 
		(
			[ProviderID] ASC,
			[SourceDataKey] ASC
		)
		INCLUDE ( [FullName],
		[ReverseFullName],
		[LastName],
		[FirstName],
		[MiddleName]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

		IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[EDS_ProviderDim]') AND name = N'NIX_EDS_ProviderDim_Vendor_FederalID_INC_FIDN')
		CREATE NONCLUSTERED INDEX [NIX_EDS_ProviderDim_Vendor_FederalID_INC_FIDN] ON [dbo].[EDS_ProviderDim] 
		(
			[Vendor_FederalID] ASC
		)
		INCLUDE ( [FIDN]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

-- Scott Waller 05/05/2015
-- update Run Controls
		UPDATE dbo.EXT_SYS_RUNLOG
			SET END_DT		= GETDATE(),
			RUN_MINUTES		= DATEDIFF(MI,START_DT,GETDATE()),
			TOTAL_RECORDS	= 0,
			ENTRYDT			= GETDATE()
		WHERE	PROC_NAME	= 'EDPS_Data ut_BIDW_ClaimSource_Indexes - CREATE'
		AND		END_DT		IS NULL
		AND		STEP		= '1'
-- end Scott Waller	

	END


END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH
	

END



/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()

BEGIN TRANSACTION

	EXEC [dbo].[ut_BIDW_ClaimSource_Indexes]
		@DropCreate	 = 'C'
		
ROLLBACK TRANSACTION

SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/













