﻿CREATE TABLE [IDQ].[CMSTaxonomy] (
    [CMSTaxonomyID]                           INT          IDENTITY (1, 1) NOT NULL,
    [CMSTaxonomySK]                           INT          NOT NULL,
    [NPI]                                     VARCHAR (10) NULL,
    [HealthcareProviderPrimaryTaxonomySwitch] VARCHAR (1)  NULL,
    [HealthcareProviderTaxonomyCode]          VARCHAR (10) NULL,
    [HealthcareProviderTaxonomyGroup]         VARCHAR (50) NULL,
    [SourceDataKey]                           INT          NULL,
    [LoadDateTime]                            DATETIME     NULL,
    CONSTRAINT [PK__CMSTaxon__ABB400D28B4E6EA3] PRIMARY KEY CLUSTERED ([CMSTaxonomyID] ASC)
);

