﻿CREATE TABLE [IDQ].[CMSStateCodes] (
    [cmdStateCodesID]          INT          IDENTITY (1, 1) NOT NULL,
    [CMSStatecodesSK]          INT          NOT NULL,
    [StateCode]                VARCHAR (2)  NULL,
    [StateDescription]         VARCHAR (50) NULL,
    [StateTypeCode]            VARCHAR (1)  NULL,
    [StateTypeCodeDescription] VARCHAR (10) NULL,
    [SourceDataKey]            INT          NULL,
    [LoadDateTime]             INT          NULL,
    CONSTRAINT [PK__CMSState__8AAAF3A7B1391140] PRIMARY KEY CLUSTERED ([cmdStateCodesID] ASC)
);

