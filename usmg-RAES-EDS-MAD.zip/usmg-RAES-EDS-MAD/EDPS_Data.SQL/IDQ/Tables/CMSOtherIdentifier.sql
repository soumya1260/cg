﻿CREATE TABLE [IDQ].[CMSOtherIdentifier] (
    [cmdOtherIdentifierID]            INT          IDENTITY (1, 1) NOT NULL,
    [CMSOtherIdentifierSK]            INT          NOT NULL,
    [NPI]                             VARCHAR (10) NULL,
    [OtherProviderIdentifier]         VARCHAR (20) NULL,
    [OtherProviderIdentifierTypeCode] VARCHAR (2)  NULL,
    [OtherProviderIdentifierState]    VARCHAR (2)  NULL,
    [OtherProviderIdentifierIssuer]   VARCHAR (80) NULL,
    [SourceDataKey]                   INT          NULL,
    [LoadDateTime]                    INT          NULL,
    CONSTRAINT [PK__CMSOther__2E57C2F23231D182] PRIMARY KEY CLUSTERED ([cmdOtherIdentifierID] ASC)
);

