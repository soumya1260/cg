﻿CREATE TABLE [IDQ].[CMSReferenceCodes] (
    [cmdReferenceCodesID] INT          IDENTITY (1, 1) NOT NULL,
    [CMSReferenceCodesSK] INT          NOT NULL,
    [Typecode]            VARCHAR (50) NULL,
    [CodeID]              VARCHAR (20) NULL,
    [CodeDescription]     VARCHAR (50) NULL,
    [SourceDataKey]       INT          NULL,
    [LoadDateTime]        INT          NULL,
    CONSTRAINT [PK__CMSRefer__CB22CC4FAE798522] PRIMARY KEY CLUSTERED ([cmdReferenceCodesID] ASC)
);

