﻿CREATE TABLE [IDQ].[CMSLicense] (
    [cmsLicenseID]                   INT          IDENTITY (1, 1) NOT NULL,
    [CMSLicenseSK]                   INT          NOT NULL,
    [NPI]                            VARCHAR (10) NULL,
    [ProviderLicenseNumber]          VARCHAR (20) NULL,
    [ProviderLicenseNumberStateCode] VARCHAR (2)  NULL,
    [SourceDataKey]                  INT          NULL,
    [LoadDateTime]                   INT          NULL,
    CONSTRAINT [PK__CMSLicen__4158A07B247FB5A7] PRIMARY KEY CLUSTERED ([cmsLicenseID] ASC)
);

