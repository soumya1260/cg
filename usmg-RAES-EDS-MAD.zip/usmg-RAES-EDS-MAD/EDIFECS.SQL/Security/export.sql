﻿CREATE SCHEMA [export]
    AUTHORIZATION [dbo];

