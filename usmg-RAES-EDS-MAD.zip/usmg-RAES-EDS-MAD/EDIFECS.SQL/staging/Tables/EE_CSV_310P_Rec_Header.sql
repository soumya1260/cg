﻿CREATE TABLE [staging].[EE_CSV_310P_Rec_Header](
	[ClaimID] [varchar](20) NULL,
	[SourceDataKey] [int] NULL,
	[SourceDesc] [varchar](60) NULL,
	[CreateDate] [datetime] NULL,
	[2320_SBR01_PayerResponsibilitySequence] [varchar](100) NULL,
	[2320_SBR02_SubscriberRelationship] [varchar](100) NULL,
	[2320_SBR03_PolicyNumber] [varchar](100) NULL,
	[310_ProductIDNumber] [varchar](100) NULL,
	[310_DelegatedBenefitAdminOrgID] [varchar](100) NULL,
	[2320_SBR04_InsuredGroupName] [varchar](100) NULL,
	[2320_SBR05_InsuranceType] [varchar](100) NULL,
	[2320_SBR09_ClaimFilingIndicator] [varchar](100) NULL,
	[310_ClaimDisposition] [varchar](100) NULL,
	[310_RiskAssessmentCode_1] [varchar](100) NULL,
	[310_RiskAssessmentCode_2] [varchar](100) NULL,
	[310_RiskAssessmentCode_3] [varchar](100) NULL,
	[310_RiskAssessmentCode_4] [varchar](100) NULL,
	[310_RiskAssessmentCode_5] [varchar](100) NULL,
	[310_RiskAssessmentCode_6] [varchar](100) NULL,
	[310_RiskAssessmentCode_7] [varchar](100) NULL,
	[310_RiskAssessmentCode_8] [varchar](100) NULL,
	[310_RiskAssessmentCode_9] [varchar](100) NULL,
	[310_RiskAssessmentCode_10] [varchar](100) NULL,
	[310_RiskAssessmentCode_11] [varchar](100) NULL,
	[310_RiskAssessmentCode_12] [varchar](100) NULL,
	[310_RiskAssessmentCode_13] [varchar](100) NULL,
	[310_RiskAssessmentCode_14] [varchar](100) NULL,
	[310_RiskAssessmentCode_15] [varchar](100) NULL,
	[310_RiskAssessmentCode_16] [varchar](100) NULL,
	[310_RiskAssessmentCode_17] [varchar](100) NULL,
	[310_RiskAssessmentCode_18] [varchar](100) NULL,
	[310_RiskAssessmentCode_19] [varchar](100) NULL,
	[310_RiskAssessmentCode_20] [varchar](100) NULL,
	[310_RiskAssessmentCode_21] [varchar](100) NULL,
	[310_RiskAssessmentCode_22] [varchar](100) NULL,
	[310_RiskAssessmentCode_23] [varchar](100) NULL,
	[310_RiskAssessmentCode_24] [varchar](100) NULL,
	[2320_ClaimLevelDenial_1] [varchar](100) NULL,
	[2320_ClaimLevelDenial_2] [varchar](100) NULL,
	[2320_ClaimLevelDenial_3] [varchar](100) NULL,
	[2320_ClaimLevelDenial_4] [varchar](100) NULL,
	[2320_ClaimLevelDenial_5] [varchar](100) NULL,
	[2320_ClaimLevelDenial_6] [varchar](100) NULL,
	[2320_ClaimLevelDenial_7] [varchar](100) NULL,
	[2320_ClaimLevelDenial_8] [varchar](100) NULL,
	[2320_ClaimLevelDenial_9] [varchar](100) NULL,
	[2320_ClaimLevelDenial_10] [varchar](100) NULL,
	[2320_CAS01_ClaimAdjustmentGroup_1] [varchar](100) NULL,
	[2320_CAS02_ClaimAdjustmentReason_1] [varchar](100) NULL,
	[2320_CAS03_ClaimAdjustmentAmount_1] [varchar](100) NULL,
	[2320_CAS04_ClaimAdjustmentquantity_1] [varchar](100) NULL,
	[2320_CAS05_ClaimAdjustmentReason_1] [varchar](100) NULL,
	[2320_CAS06_ClaimAdjustmentAmount_1] [varchar](100) NULL,
	[2320_CAS07_ClaimAdjustmentquantity_1] [varchar](100) NULL,
	[2320_CAS08_ClaimAdjustmentReason_1] [varchar](100) NULL,
	[2320_CAS09_ClaimAdjustmentAmount_1] [varchar](100) NULL,
	[2320_CAS10_ClaimAdjustmentquantity_1] [varchar](100) NULL,
	[2320_CAS11_ClaimAdjustmentReason_1] [varchar](100) NULL,
	[2320_CAS12_ClaimAdjustmentAmount_1] [varchar](100) NULL,
	[2320_CAS12_ClaimAdjustmentquantity_1] [varchar](100) NULL,
	[2320_CAS14_ClaimAdjustmentReason_1] [varchar](100) NULL,
	[2320_CAS15_ClaimAdjustmentAmount_1] [varchar](100) NULL,
	[2320_CAS16_ClaimAdjustmentquantity_1] [varchar](100) NULL,
	[2320_CAS17_ClaimAdjustmentReason_1] [varchar](100) NULL,
	[2320_CAS18_ClaimAdjustmentAmount_1] [varchar](100) NULL,
	[2320_CAS19_ClaimAdjustmentquantity_1] [varchar](100) NULL,
	[2320_CAS01_ClaimAdjustmentGroup_2] [varchar](100) NULL,
	[2320_CAS02_ClaimAdjustmentReason_2] [varchar](100) NULL,
	[2320_CAS03_ClaimAdjustmentAmount_2] [varchar](100) NULL,
	[2320_CAS04_ClaimAdjustmentquantity_2] [varchar](100) NULL,
	[2320_CAS05_ClaimAdjustmentReason_2] [varchar](100) NULL,
	[2320_CAS06_ClaimAdjustmentAmount_2] [varchar](100) NULL,
	[2320_CAS07_ClaimAdjustmentquantity_2] [varchar](100) NULL,
	[2320_CAS08_ClaimAdjustmentReason_2] [varchar](100) NULL,
	[2320_CAS09_ClaimAdjustmentAmount_2] [varchar](100) NULL,
	[2320_CAS10_ClaimAdjustmentquantity_2] [varchar](100) NULL,
	[2320_CAS11_ClaimAdjustmentReason_2] [varchar](100) NULL,
	[2320_CAS12_ClaimAdjustmentAmount_2] [varchar](100) NULL,
	[2320_CAS12_ClaimAdjustmentquantity_2] [varchar](100) NULL,
	[2320_CAS14_ClaimAdjustmentReason_2] [varchar](100) NULL,
	[2320_CAS15_ClaimAdjustmentAmount_2] [varchar](100) NULL,
	[2320_CAS16_ClaimAdjustmentquantity_2] [varchar](100) NULL,
	[2320_CAS17_ClaimAdjustmentReason_2] [varchar](100) NULL,
	[2320_CAS18_ClaimAdjustmentAmount_2] [varchar](100) NULL,
	[2320_CAS19_ClaimAdjustmentquantity_2] [varchar](100) NULL,
	[2320_CAS01_ClaimAdjustmentGroup_3] [varchar](100) NULL,
	[2320_CAS02_ClaimAdjustmentReason_3] [varchar](100) NULL,
	[2320_CAS03_ClaimAdjustmentAmount_3] [varchar](100) NULL,
	[2320_CAS04_ClaimAdjustmentquantity_3] [varchar](100) NULL,
	[2320_CAS05_ClaimAdjustmentReason_3] [varchar](100) NULL,
	[2320_CAS06_ClaimAdjustmentAmount_3] [varchar](100) NULL,
	[2320_CAS07_ClaimAdjustmentquantity_3] [varchar](100) NULL,
	[2320_CAS08_ClaimAdjustmentReason_3] [varchar](100) NULL,
	[2320_CAS09_ClaimAdjustmentAmount_3] [varchar](100) NULL,
	[2320_CAS10_ClaimAdjustmentquantity_3] [varchar](100) NULL,
	[2320_CAS11_ClaimAdjustmentReason_3] [varchar](100) NULL,
	[2320_CAS12_ClaimAdjustmentAmount_3] [varchar](100) NULL,
	[2320_CAS12_ClaimAdjustmentquantity_3] [varchar](100) NULL,
	[2320_CAS14_ClaimAdjustmentReason_3] [varchar](100) NULL,
	[2320_CAS15_ClaimAdjustmentAmount_3] [varchar](100) NULL,
	[2320_CAS16_ClaimAdjustmentquantity_3] [varchar](100) NULL,
	[2320_CAS17_ClaimAdjustmentReason_3] [varchar](100) NULL,
	[2320_CAS18_ClaimAdjustmentAmount_3] [varchar](100) NULL,
	[2320_CAS19_ClaimAdjustmentquantity_3] [varchar](100) NULL,
	[2320_CAS01_ClaimAdjustmentGroup_4] [varchar](100) NULL,
	[2320_CAS02_ClaimAdjustmentReason_4] [varchar](100) NULL,
	[2320_CAS03_ClaimAdjustmentAmount_4] [varchar](100) NULL,
	[2320_CAS04_ClaimAdjustmentquantity_4] [varchar](100) NULL,
	[2320_CAS05_ClaimAdjustmentReason_4] [varchar](100) NULL,
	[2320_CAS06_ClaimAdjustmentAmount_4] [varchar](100) NULL,
	[2320_CAS07_ClaimAdjustmentquantity_4] [varchar](100) NULL,
	[2320_CAS08_ClaimAdjustmentReason_4] [varchar](100) NULL,
	[2320_CAS09_ClaimAdjustmentAmount_4] [varchar](100) NULL,
	[2320_CAS10_ClaimAdjustmentquantity_4] [varchar](100) NULL,
	[2320_CAS11_ClaimAdjustmentReason_4] [varchar](100) NULL,
	[2320_CAS12_ClaimAdjustmentAmount_4] [varchar](100) NULL,
	[2320_CAS12_ClaimAdjustmentquantity_4] [varchar](100) NULL,
	[2320_CAS14_ClaimAdjustmentReason_4] [varchar](100) NULL,
	[2320_CAS15_ClaimAdjustmentAmount_4] [varchar](100) NULL,
	[2320_CAS16_ClaimAdjustmentquantity_4] [varchar](100) NULL,
	[2320_CAS17_ClaimAdjustmentReason_4] [varchar](100) NULL,
	[2320_CAS18_ClaimAdjustmentAmount_4] [varchar](100) NULL,
	[2320_CAS19_ClaimAdjustmentquantity_4] [varchar](100) NULL,
	[2320_CAS01_ClaimAdjustmentGroup_5] [varchar](100) NULL,
	[2320_CAS02_ClaimAdjustmentReason_5] [varchar](100) NULL,
	[2320_CAS03_ClaimAdjustmentAmount_5] [varchar](100) NULL,
	[2320_CAS04_ClaimAdjustmentquantity_5] [varchar](100) NULL,
	[2320_CAS05_ClaimAdjustmentReason_5] [varchar](100) NULL,
	[2320_CAS06_ClaimAdjustmentAmount_5] [varchar](100) NULL,
	[2320_CAS07_ClaimAdjustmentquantity_5] [varchar](100) NULL,
	[2320_CAS08_ClaimAdjustmentReason_5] [varchar](100) NULL,
	[2320_CAS09_ClaimAdjustmentAmount_5] [varchar](100) NULL,
	[2320_CAS10_ClaimAdjustmentquantity_5] [varchar](100) NULL,
	[2320_CAS11_ClaimAdjustmentReason_5] [varchar](100) NULL,
	[2320_CAS12_ClaimAdjustmentAmount_5] [varchar](100) NULL,
	[2320_CAS12_ClaimAdjustmentquantity_5] [varchar](100) NULL,
	[2320_CAS14_ClaimAdjustmentReason_5] [varchar](100) NULL,
	[2320_CAS15_ClaimAdjustmentAmount_5] [varchar](100) NULL,
	[2320_CAS16_ClaimAdjustmentquantity_5] [varchar](100) NULL,
	[2320_CAS17_ClaimAdjustmentReason_5] [varchar](100) NULL,
	[2320_CAS18_ClaimAdjustmentAmount_5] [varchar](100) NULL,
	[2320_CAS19_ClaimAdjustmentquantity_5] [varchar](100) NULL,
	[2320_AMT01_AmountQualifier_1] [varchar](100) NULL,
	[2320_AMT02_COBAmount_1] [varchar](100) NULL,
	[2320_AMT01_AmountQualifier_2] [varchar](100) NULL,
	[2320_AMT02_COBAmount_2] [varchar](100) NULL,
	[2320_AMT01_AmountQualifier_3] [varchar](100) NULL,
	[2320_AMT02_COBAmount_3] [varchar](100) NULL,
	[2320_OI03_AssignBenefitsIndicator] [varchar](100) NULL,
	[2320_OI04_PatientSignature] [varchar](100) NULL,
	[2320_OI06_ReleaseOfInformation] [varchar](100) NULL,
	[2320_MIA01_AdjudQuantity] [varchar](100) NULL,
	[2320_MIA03_AdjudQuantity] [varchar](100) NULL,
	[2320_MIA04_AdjudAmount] [varchar](100) NULL,
	[2320_MIA05_RemarkCode] [varchar](100) NULL,
	[2320_MIA06_AdjudAmount] [varchar](100) NULL,
	[2320_MIA07_AdjudAmount] [varchar](100) NULL,
	[2320_MIA08_AdjudAmount] [varchar](100) NULL,
	[2320_MIA09_AdjudAmount] [varchar](100) NULL,
	[2320_MIA10_AdjudAmount] [varchar](100) NULL,
	[2320_MIA11_AdjudAmount] [varchar](100) NULL,
	[2320_MIA12_AdjudAmount] [varchar](100) NULL,
	[2320_MIA13_AdjudAmount] [varchar](100) NULL,
	[2320_MIA14_AdjudAmount] [varchar](100) NULL,
	[2320_MIA15_AdjudQuantity] [varchar](100) NULL,
	[2320_MIA16_AdjudAmount] [varchar](100) NULL,
	[2320_MIA17_AdjudAmount] [varchar](100) NULL,
	[2320_MIA18_AdjudAmount] [varchar](100) NULL,
	[2320_MIA19_AdjudAmount] [varchar](100) NULL,
	[2320_MIA20_RemarkCode] [varchar](100) NULL,
	[2320_MIA21_RemarkCode] [varchar](100) NULL,
	[2320_MIA22_RemarkCode] [varchar](100) NULL,
	[2320_MIA23_RemarkCode] [varchar](100) NULL,
	[2320_MIA24_AdjudAmount] [varchar](100) NULL,
	[2320_MOA01_AdjudAmount] [varchar](100) NULL,
	[2320_MOA02_AdjudAmount] [varchar](100) NULL,
	[2320_MOA03_RemarkCode] [varchar](100) NULL,
	[2320_MOA04_RemarkCode] [varchar](100) NULL,
	[2320_MOA05_RemarkCode] [varchar](100) NULL,
	[2320_MOA06_RemarkCode] [varchar](100) NULL,
	[2320_MOA07_RemarkCode] [varchar](100) NULL,
	[2320_MOA08_AdjudAmount] [varchar](100) NULL,
	[2320_MOA09_AdjudAmount] [varchar](100) NULL,
	[2330A_NM101_PersonRole] [varchar](100) NULL,
	[2330A_NM102_PersonIndicator] [varchar](100) NULL,
	[2330A_NM103_LastName] [varchar](100) NULL,
	[2330A_NM104_FirstName] [varchar](100) NULL,
	[2330A_NM105_MiddleName] [varchar](100) NULL,
	[2330A_NM107_Suffix] [varchar](100) NULL,
	[2330A_NM108_PersonIdentifierQualifier] [varchar](100) NULL,
	[2330A_NM109_PersonIdentifier] [varchar](100) NULL,
	[2330A_N301_AddressLine1] [varchar](100) NULL,
	[2330A_N302_AddressLine2] [varchar](100) NULL,
	[2330A_N401_City] [varchar](100) NULL,
	[2330A_N402_State] [varchar](100) NULL,
	[2330A_N403_PostalCode] [varchar](100) NULL,
	[2330A_N404_Country] [varchar](100) NULL,
	[2330B_NM101_OrganizationRole] [varchar](100) NULL,
	[2330B_NM102_PersonIndicator] [varchar](100) NULL,
	[2330B_NM103_Name] [varchar](100) NULL,
	[2330B_NM108_OrganizationIdQualifier] [varchar](100) NULL,
	[2330B_NM109_OrganizationIdentifier] [varchar](100) NULL,
	[2330B_N301_AddressLine1] [varchar](100) NULL,
	[2330B_N302_AddressLine2] [varchar](100) NULL,
	[2330B_N401_City] [varchar](100) NULL,
	[2330B_N402_State] [varchar](100) NULL,
	[2330B_N403_PostalCode] [varchar](100) NULL,
	[2330B_N404_Country] [varchar](100) NULL,
	[2330B_DTP01_DateTimeQualifier] [varchar](100) NULL,
	[2330B_DTP02_DateTimeFormat] [varchar](100) NULL,
	[2330B_DTP03_ClaimPaidDate] [varchar](100) NULL,
	[310_OverPaymentID] [varchar](100) NULL,
	[2330B_REF01_OrganizationIdQualifier_1] [varchar](100) NULL,
	[2330B_REF01_OrganizationIdentifier_1] [varchar](100) NULL,
	[2330B_REF01_OrganizationIdQualifier_2] [varchar](100) NULL,
	[2330B_REF01_OrganizationIdentifier_2] [varchar](100) NULL,
	[2330B_REF01_OrganizationIdQualifier_3] [varchar](100) NULL,
	[2330B_REF01_OrganizationIdentifier_3] [varchar](100) NULL,
	[2330B_REF01_OrganizationIdQualifier_4] [varchar](100) NULL,
	[2330B_REF01_OrganizationIdentifier_4] [varchar](100) NULL,
	[2330B_REF01_OrganizationIdQualifier_5] [varchar](100) NULL,
	[2330B_REF01_OrganizationIdentifier_5] [varchar](100) NULL,
	[310_ReportBeginDate] [varchar](100) NULL,
	[310_ReportEndDate] [varchar](100) NULL,
	[310_PaymentYear] [varchar](100) NULL,
	[2330B_REF01_AdjudicatedDRGQualifier] [varchar](100) NULL,
	[2330B_REF02_AdjudicatedDRG] [varchar](100) NULL,
	[2330B_REF04-01_ReferenceIdentificationQualifier] [varchar](100) NULL,
	[2330B_REF04-02_DRGGrouperVersion] [varchar](100) NULL,
	[310_Rate_Increase_Indicator] [varchar](100) NULL,
	[310_Bundle_Indicator] [varchar](100) NULL,
	[310_Bundle_Claim_Number] [varchar](100) NULL,
	[ClaimApprovedAmount] [varchar](100) NULL,
	[310_PaymentCheckDate] [varchar](100) NULL,
	[310-Filler_03] [varchar](100) NULL,
	[310-Filler_04] [varchar](100) NULL,
	[310-Filler_05] [varchar](100) NULL,
	[310-Filler_06] [varchar](100) NULL,
	[310-Filler_07] [varchar](100) NULL,
	[310-Filler_08] [varchar](100) NULL,
	[310-Filler_09] [varchar](100) NULL,
	[310-Filler_10] [varchar](100) NULL,
	[310-Filler_11] [varchar](100) NULL,
	[310-Filler_12] [varchar](100) NULL,
	[310-Filler_13] [varchar](100) NULL,
	[310-Filler_14] [varchar](100) NULL,
	[310-Filler_15] [varchar](100) NULL,
	[310_RecipientAidCategory] [varchar](100) NULL
) ON [PRIMARY]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [ClaimID]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ((0)) FOR [SourceDataKey]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [SourceDesc]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_SBR01_PayerResponsibilitySequence]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_SBR02_SubscriberRelationship]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_SBR03_PolicyNumber]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_ProductIDNumber]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_DelegatedBenefitAdminOrgID]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_SBR04_InsuredGroupName]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_SBR05_InsuranceType]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_SBR09_ClaimFilingIndicator]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_ClaimDisposition]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_6]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_7]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_8]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_9]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_10]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_11]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_12]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_13]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_14]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_15]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_16]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_17]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_18]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_19]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_20]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_21]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_22]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_23]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RiskAssessmentCode_24]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_ClaimLevelDenial_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_ClaimLevelDenial_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_ClaimLevelDenial_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_ClaimLevelDenial_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_ClaimLevelDenial_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_ClaimLevelDenial_6]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_ClaimLevelDenial_7]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_ClaimLevelDenial_8]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_ClaimLevelDenial_9]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_ClaimLevelDenial_10]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS01_ClaimAdjustmentGroup_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS02_ClaimAdjustmentReason_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS03_ClaimAdjustmentAmount_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS04_ClaimAdjustmentquantity_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS05_ClaimAdjustmentReason_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS06_ClaimAdjustmentAmount_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS07_ClaimAdjustmentquantity_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS08_ClaimAdjustmentReason_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS09_ClaimAdjustmentAmount_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS10_ClaimAdjustmentquantity_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS11_ClaimAdjustmentReason_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS12_ClaimAdjustmentAmount_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS12_ClaimAdjustmentquantity_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS14_ClaimAdjustmentReason_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS15_ClaimAdjustmentAmount_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS16_ClaimAdjustmentquantity_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS17_ClaimAdjustmentReason_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS18_ClaimAdjustmentAmount_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS19_ClaimAdjustmentquantity_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS01_ClaimAdjustmentGroup_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS02_ClaimAdjustmentReason_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS03_ClaimAdjustmentAmount_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS04_ClaimAdjustmentquantity_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS05_ClaimAdjustmentReason_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS06_ClaimAdjustmentAmount_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS07_ClaimAdjustmentquantity_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS08_ClaimAdjustmentReason_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS09_ClaimAdjustmentAmount_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS10_ClaimAdjustmentquantity_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS11_ClaimAdjustmentReason_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS12_ClaimAdjustmentAmount_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS12_ClaimAdjustmentquantity_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS14_ClaimAdjustmentReason_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS15_ClaimAdjustmentAmount_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS16_ClaimAdjustmentquantity_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS17_ClaimAdjustmentReason_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS18_ClaimAdjustmentAmount_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS19_ClaimAdjustmentquantity_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS01_ClaimAdjustmentGroup_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS02_ClaimAdjustmentReason_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS03_ClaimAdjustmentAmount_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS04_ClaimAdjustmentquantity_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS05_ClaimAdjustmentReason_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS06_ClaimAdjustmentAmount_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS07_ClaimAdjustmentquantity_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS08_ClaimAdjustmentReason_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS09_ClaimAdjustmentAmount_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS10_ClaimAdjustmentquantity_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS11_ClaimAdjustmentReason_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS12_ClaimAdjustmentAmount_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS12_ClaimAdjustmentquantity_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS14_ClaimAdjustmentReason_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS15_ClaimAdjustmentAmount_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS16_ClaimAdjustmentquantity_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS17_ClaimAdjustmentReason_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS18_ClaimAdjustmentAmount_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS19_ClaimAdjustmentquantity_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS01_ClaimAdjustmentGroup_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS02_ClaimAdjustmentReason_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS03_ClaimAdjustmentAmount_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS04_ClaimAdjustmentquantity_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS05_ClaimAdjustmentReason_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS06_ClaimAdjustmentAmount_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS07_ClaimAdjustmentquantity_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS08_ClaimAdjustmentReason_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS09_ClaimAdjustmentAmount_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS10_ClaimAdjustmentquantity_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS11_ClaimAdjustmentReason_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS12_ClaimAdjustmentAmount_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS12_ClaimAdjustmentquantity_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS14_ClaimAdjustmentReason_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS15_ClaimAdjustmentAmount_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS16_ClaimAdjustmentquantity_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS17_ClaimAdjustmentReason_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS18_ClaimAdjustmentAmount_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS19_ClaimAdjustmentquantity_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS01_ClaimAdjustmentGroup_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS02_ClaimAdjustmentReason_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS03_ClaimAdjustmentAmount_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS04_ClaimAdjustmentquantity_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS05_ClaimAdjustmentReason_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS06_ClaimAdjustmentAmount_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS07_ClaimAdjustmentquantity_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS08_ClaimAdjustmentReason_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS09_ClaimAdjustmentAmount_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS10_ClaimAdjustmentquantity_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS11_ClaimAdjustmentReason_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS12_ClaimAdjustmentAmount_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS12_ClaimAdjustmentquantity_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS14_ClaimAdjustmentReason_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS15_ClaimAdjustmentAmount_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS16_ClaimAdjustmentquantity_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS17_ClaimAdjustmentReason_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS18_ClaimAdjustmentAmount_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_CAS19_ClaimAdjustmentquantity_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_AMT01_AmountQualifier_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_AMT02_COBAmount_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_AMT01_AmountQualifier_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_AMT02_COBAmount_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_AMT01_AmountQualifier_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_AMT02_COBAmount_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_OI03_AssignBenefitsIndicator]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_OI04_PatientSignature]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_OI06_ReleaseOfInformation]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA01_AdjudQuantity]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA03_AdjudQuantity]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA04_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA05_RemarkCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA06_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA07_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA08_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA09_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA10_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA11_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA12_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA13_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA14_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA15_AdjudQuantity]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA16_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA17_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA18_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA19_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA20_RemarkCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA21_RemarkCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA22_RemarkCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA23_RemarkCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MIA24_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MOA01_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MOA02_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MOA03_RemarkCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MOA04_RemarkCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MOA05_RemarkCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MOA06_RemarkCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MOA07_RemarkCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MOA08_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2320_MOA09_AdjudAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_NM101_PersonRole]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_NM102_PersonIndicator]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_NM103_LastName]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_NM104_FirstName]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_NM105_MiddleName]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_NM107_Suffix]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_NM108_PersonIdentifierQualifier]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_NM109_PersonIdentifier]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_N301_AddressLine1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_N302_AddressLine2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_N401_City]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_N402_State]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_N403_PostalCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330A_N404_Country]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_NM101_OrganizationRole]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_NM102_PersonIndicator]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_NM103_Name]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_NM108_OrganizationIdQualifier]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_NM109_OrganizationIdentifier]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_N301_AddressLine1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_N302_AddressLine2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_N401_City]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_N402_State]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_N403_PostalCode]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_N404_Country]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_DTP01_DateTimeQualifier]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_DTP02_DateTimeFormat]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_DTP03_ClaimPaidDate]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_OverPaymentID]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_OrganizationIdQualifier_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_OrganizationIdentifier_1]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_OrganizationIdQualifier_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_OrganizationIdentifier_2]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_OrganizationIdQualifier_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_OrganizationIdentifier_3]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_OrganizationIdQualifier_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_OrganizationIdentifier_4]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_OrganizationIdQualifier_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_OrganizationIdentifier_5]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_ReportBeginDate]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_ReportEndDate]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_PaymentYear]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF01_AdjudicatedDRGQualifier]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF02_AdjudicatedDRG]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF04-01_ReferenceIdentificationQualifier]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [2330B_REF04-02_DRGGrouperVersion]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_Rate_Increase_Indicator]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_Bundle_Indicator]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_Bundle_Claim_Number]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [ClaimApprovedAmount]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_PaymentCheckDate]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_03]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_04]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_05]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_06]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_07]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_08]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_09]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_10]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_11]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_12]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_13]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_14]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310-Filler_15]
GO

ALTER TABLE [staging].[EE_CSV_310P_Rec_Header] ADD  DEFAULT ('') FOR [310_RecipientAidCategory]
GO



