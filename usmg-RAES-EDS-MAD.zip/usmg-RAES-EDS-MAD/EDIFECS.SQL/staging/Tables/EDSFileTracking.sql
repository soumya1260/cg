﻿CREATE TABLE [staging].[EDSFileTracking] (
    [InternalClaimID]            VARCHAR (50)  NULL,
    [EncounterClaimID]           VARCHAR (50)  NULL,
    [VendorClaimID]              VARCHAR (50)  NULL,
    [Vendor_Source]              VARCHAR (15)  NULL,
    [Supplmental_Flag_Indicator] VARCHAR (6)   NULL,
    [DOSYear]                    DATE          NULL,
    [ClaimStatFilename]          VARCHAR (100) NULL,
    [Hplan_Extract_File_Name]    VARCHAR (100) NULL,
    [raw999Filename]             VARCHAR (100) NULL,
    [raw277Filename]             VARCHAR (100) NULL,
    [prop999Filename]            VARCHAR (100) NULL,
    [prop277Filename]            VARCHAR (100) NULL,
    [raw837Filename]             VARCHAR (100) NULL,
    [propSupp999Filename]        VARCHAR (100) NULL,
    [propSuppMAO002Filename]     VARCHAR (100) NULL,
    [rawMAO002Filename]          VARCHAR (100) NULL,
    [propSupp277Filename]        VARCHAR (100) NULL,
    [propMAO002Filename]         VARCHAR (100) NULL
);


GO
CREATE CLUSTERED INDEX [ClusteredIndex-20220519-085314]
    ON [staging].[EDSFileTracking]([InternalClaimID] ASC, [EncounterClaimID] ASC, [VendorClaimID] ASC);

