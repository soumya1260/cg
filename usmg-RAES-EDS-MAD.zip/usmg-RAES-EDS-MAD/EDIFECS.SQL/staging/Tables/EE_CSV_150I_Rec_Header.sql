﻿CREATE TABLE [staging].[EE_CSV_150I_Rec_Header](
	[ClaimID] [varchar](20) NULL,
	[SourceDataKey] [int] NULL,
	[SourceDesc] [varchar](60) NULL,
	[CreateDate] [datetime] NULL,
	[2000B_SBR01_SubscriberPayerResponsibilitySequence] [varchar](100) NULL,
	[2000B_SBR02_SubscriberRelationship] [varchar](100) NULL,
	[2000B_SBR03_SubscriberPolicyNumber] [varchar](100) NULL,
	[2000B_SBR04_InsuredGroupName] [varchar](100) NULL,
	[2000B_SBR09_ClaimFilingIndicator] [varchar](100) NULL,
	[2010BA_NM101_SubscriberPersonRole] [varchar](100) NULL,
	[2010BA_NM102_SubscriberPersonIndicator] [varchar](100) NULL,
	[2010BA_NM103_SubscriberLastName] [varchar](100) NULL,
	[2010BA_NM104_SubscriberFirstName] [varchar](100) NULL,
	[2010BA_NM105_SubscriberMiddleName] [varchar](100) NULL,
	[2010BA_NM107_SubscriberSuffix] [varchar](100) NULL,
	[2010BA_NM108_SubscriberIdentifierQualifer] [varchar](100) NULL,
	[2010BA_NM109_SubscriberIdentifier] [varchar](100) NULL,
	[2010BA_REF01_SubscriberSSNQualifier] [varchar](100) NULL,
	[2010BA_REF02_Subscriber_Identifier_SSN] [varchar](100) NULL,
	[2010BA_REF01_PropertyandCasualty_Qualifier] [varchar](100) NULL,
	[2010BA_REF02_PropertyandCasualty_Identifier] [varchar](100) NULL,
	[2010BA_N301_SubscriberAddressLine1] [varchar](100) NULL,
	[2010BA_N302_SubscriberAddressLine2] [varchar](100) NULL,
	[2010BA_N401_SubscriberCity] [varchar](100) NULL,
	[2010BA_N402_SubscriberState] [varchar](100) NULL,
	[2010BA_N403_SubscriberPostalCode] [varchar](100) NULL,
	[2010BA_N404_SubscriberCountry] [varchar](100) NULL,
	[2010BA_DMG01_DateQualifer] [varchar](100) NULL,
	[2010BA_DMG02_DateOfBirth] [varchar](100) NULL,
	[2010BA_DMG03_Gender] [varchar](100) NULL,
	[2010BA_REF01_SubscriberIdentifierQualifier_1] [varchar](100) NULL,
	[2010BA_REF02_SubscriberIdentifier_1] [varchar](100) NULL,
	[2010BA_REF01_SubscriberIdentifierQualifer_2] [varchar](100) NULL,
	[2010BA_REF02_SubscriberIdentifier_2] [varchar](100) NULL,
	[2010BB_NM101_Payer_OrganizationRole] [varchar](100) NULL,
	[2010BB_NM102_PayerPersonIndicator] [varchar](100) NULL,
	[2010BB_NM103_PayerName] [varchar](100) NULL,
	[2010BB_NM108_PayerOrganizationIDQualifier] [varchar](100) NULL,
	[2010BB_NM109_PayerOrganizationIdentifier] [varchar](100) NULL,
	[2010BB_N301_PayerAddressLine1] [varchar](100) NULL,
	[2010BB_N302_PayerAddressLine2] [varchar](100) NULL,
	[2010BB_N401_PayerCity] [varchar](100) NULL,
	[2010BB_N402_PayerState] [varchar](100) NULL,
	[2010BB_N403_PayerPostalCode] [varchar](100) NULL,
	[2010BB_N404_PayerCountry] [varchar](100) NULL,
	[2010BB_REF01_PayerOrganizationIDQualifier_1] [varchar](100) NULL,
	[2010BB_REF02_PayerOrganizationIdentifier_1] [varchar](100) NULL,
	[2010BB_REF01_ProviderIDQualifier_1] [varchar](100) NULL,
	[2010BB_REF02_BillingProviderIdentifier_1] [varchar](100) NULL,
	[2010BB_REF01_BillingProviderIDQualifier_2] [varchar](100) NULL,
	[2010BB_REF02_BillingProviderIdentifier_2] [varchar](100) NULL,
	[2010BB_REF01_BillingProviderIDQualifier_3] [varchar](100) NULL,
	[2010BB_REF02_ProviderIdentifier_3] [varchar](100) NULL,
	[2010BB_REF01_BillingProviderIDQualifier_4] [varchar](100) NULL,
	[2010BB_REF02_BillingProviderIdentifier_4] [varchar](100) NULL,
	[150_Patient_Last_Name] [varchar](100) NULL,
	[150_Patient_First_Name] [varchar](100) NULL,
	[150_Patient_Middle_Name] [varchar](100) NULL,
	[150_Patient_SSN] [varchar](100) NULL,
	[150_Patient_Member_ID] [varchar](100) NULL,
	[150_Patient_Gender] [varchar](100) NULL,
	[150_Patient_DOB] [varchar](100) NULL,
	[150_Patient_Address_Line1] [varchar](100) NULL,
	[150_Patient_Address_Line2] [varchar](100) NULL,
	[150_Patient_Address_City] [varchar](100) NULL,
	[150_Patient_Address_State] [varchar](100) NULL,
	[150_Patient_Address_Zip] [varchar](100) NULL,
	[150_PCP_ID_Qual] [varchar](100) NULL,
	[150_PCP_ID] [varchar](100) NULL,
	[150_PCP_Group_Identifier] [varchar](100) NULL,
	[150_PDP_IPA_PMG_Type] [varchar](100) NULL,
	[150_PDP_IPA_PMG_ID] [varchar](100) NULL,
	[150_PCP_Open_Indic] [varchar](100) NULL,
	[150_PCP_Eligibility_Ind] [varchar](100) NULL,
	[150_COS] [varchar](100) NULL,
	[150_Service_Category_Type] [varchar](100) NULL,
	[150_Rendering_Prov_Eff_Date] [varchar](100) NULL,
	[150_Rendering_Prov_Term_Date] [varchar](100) NULL,
	[150_Rendering_Prov_DEA_ID] [varchar](100) NULL,
	[150_Rendering_Prov_Gender] [varchar](100) NULL,
	[150_Provider_Par_Non_Par] [varchar](100) NULL,
	[Care_Plan_Option_Indicator] [varchar](100) NULL,
	[Group_Indentifier] [varchar](100) NULL,
	[Care_Type_Code] [varchar](100) NULL,
	[Financial_Arrangement_Code] [varchar](100) NULL,
	[150_Filler_05] [varchar](100) NULL,
	[2000B_SBR05_InsuranceTypeCode] [varchar](100) NULL,
	[2000B_PAT09_PregnancyIndicator] [varchar](100) NULL,
	[150_Filler_6] [varchar](100) NULL,
	[150_Filler_7] [varchar](100) NULL,
	[150_Filler_8] [varchar](100) NULL,
	[150_Filler_9] [varchar](100) NULL,
	[150_Filler_10] [varchar](100) NULL,
	[150_Filler_11] [varchar](100) NULL,
	[150_Filler_12] [varchar](100) NULL,
	[150_Filler_13] [varchar](100) NULL,
	[150_Filler_14] [varchar](100) NULL,
	[150_Filler_15] [varchar](100) NULL,
	[2000B_PAT06_PatientDeathDate] [varchar](100) NULL,
	[2000C_PAT01_PatientRelationship] [varchar](100) NULL,
	[2000C_PAT06_PatientDeathDate] [varchar](100) NULL,
	[2000C_PAT08_PatientWeight] [varchar](100) NULL,
	[2000C_PAT09_PregnancyIndicator] [varchar](100) NULL,
	[150_SubscriberRegionCode] [varchar](100) NULL,
	[150_SubscriberOtherInsuranceCoverage] [varchar](100) NULL,
	[150_PurchasedIndicator] [varchar](100) NULL,
	[150_BehavioralHealth_COS] [varchar](100) NULL
) ON [PRIMARY]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [ClaimID]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ((0)) FOR [SourceDataKey]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [SourceDesc]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000B_SBR01_SubscriberPayerResponsibilitySequence]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000B_SBR02_SubscriberRelationship]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000B_SBR03_SubscriberPolicyNumber]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000B_SBR04_InsuredGroupName]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000B_SBR09_ClaimFilingIndicator]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_NM101_SubscriberPersonRole]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_NM102_SubscriberPersonIndicator]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_NM103_SubscriberLastName]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_NM104_SubscriberFirstName]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_NM105_SubscriberMiddleName]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_NM107_SubscriberSuffix]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_NM108_SubscriberIdentifierQualifer]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_NM109_SubscriberIdentifier]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_REF01_SubscriberSSNQualifier]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_REF02_Subscriber_Identifier_SSN]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_REF01_PropertyandCasualty_Qualifier]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_REF02_PropertyandCasualty_Identifier]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_N301_SubscriberAddressLine1]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_N302_SubscriberAddressLine2]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_N401_SubscriberCity]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_N402_SubscriberState]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_N403_SubscriberPostalCode]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_N404_SubscriberCountry]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_DMG01_DateQualifer]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_DMG02_DateOfBirth]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_DMG03_Gender]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_REF01_SubscriberIdentifierQualifier_1]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_REF02_SubscriberIdentifier_1]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_REF01_SubscriberIdentifierQualifer_2]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BA_REF02_SubscriberIdentifier_2]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_NM101_Payer_OrganizationRole]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_NM102_PayerPersonIndicator]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_NM103_PayerName]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_NM108_PayerOrganizationIDQualifier]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_NM109_PayerOrganizationIdentifier]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_N301_PayerAddressLine1]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_N302_PayerAddressLine2]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_N401_PayerCity]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_N402_PayerState]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_N403_PayerPostalCode]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_N404_PayerCountry]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_REF01_PayerOrganizationIDQualifier_1]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_REF02_PayerOrganizationIdentifier_1]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_REF01_ProviderIDQualifier_1]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_REF02_BillingProviderIdentifier_1]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_REF01_BillingProviderIDQualifier_2]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_REF02_BillingProviderIdentifier_2]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_REF01_BillingProviderIDQualifier_3]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_REF02_ProviderIdentifier_3]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_REF01_BillingProviderIDQualifier_4]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2010BB_REF02_BillingProviderIdentifier_4]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_Last_Name]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_First_Name]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_Middle_Name]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_SSN]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_Member_ID]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_Gender]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_DOB]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_Address_Line1]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_Address_Line2]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_Address_City]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_Address_State]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Patient_Address_Zip]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_PCP_ID_Qual]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_PCP_ID]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_PCP_Group_Identifier]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_PDP_IPA_PMG_Type]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_PDP_IPA_PMG_ID]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_PCP_Open_Indic]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_PCP_Eligibility_Ind]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_COS]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Service_Category_Type]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Rendering_Prov_Eff_Date]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Rendering_Prov_Term_Date]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Rendering_Prov_DEA_ID]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Rendering_Prov_Gender]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Provider_Par_Non_Par]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [Care_Plan_Option_Indicator]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [Group_Indentifier]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [Care_Type_Code]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [Financial_Arrangement_Code]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_05]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000B_SBR05_InsuranceTypeCode]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000B_PAT09_PregnancyIndicator]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_6]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_7]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_8]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_9]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_10]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_11]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_12]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_13]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_14]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_Filler_15]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000B_PAT06_PatientDeathDate]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000C_PAT01_PatientRelationship]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000C_PAT06_PatientDeathDate]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000C_PAT08_PatientWeight]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [2000C_PAT09_PregnancyIndicator]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_SubscriberRegionCode]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_SubscriberOtherInsuranceCoverage]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_PurchasedIndicator]
GO

ALTER TABLE [staging].[EE_CSV_150I_Rec_Header] ADD  DEFAULT ('') FOR [150_BehavioralHealth_COS]
GO



