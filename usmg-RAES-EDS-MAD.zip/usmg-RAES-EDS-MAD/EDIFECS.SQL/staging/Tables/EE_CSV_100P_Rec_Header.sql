﻿CREATE TABLE [staging].[EE_CSV_100P_Rec_Header](
	[ClaimID] [varchar](20) NULL,
	[SourceDataKey] [int] NULL,
	[SourceDesc] [varchar](60) NULL,
	[CreateDate] [datetime] NULL,
	[ClaimStatus] [varchar](100) NULL,
	[ClaimType] [varchar](100) NULL,
	[SenderID] [varchar](100) NULL,
	[Receiver_ID_] [varchar](100) NULL,
	[OriginatorID] [varchar](100) NULL,
	[Contract_ID] [varchar](100) NULL,
	[DestinationID] [varchar](100) NULL,
	[HistoricalIndicator] [varchar](100) NULL,
	[HistoricalDispositionStatus] [varchar](100) NULL,
	[HistoricalEncounterICN] [varchar](100) NULL,
	[HistoricalEncounterID] [varchar](100) NULL,
	[Paper] [varchar](100) NULL,
	[DME] [varchar](100) NULL,
	[Administrative_Denial] [varchar](100) NULL,
	[Chart_Review_Data] [varchar](100) NULL,
	[Source_] [varchar](100) NULL,
	[Filler] [varchar](100) NULL,
	[TraceNumber] [varchar](100) NULL,
	[1000A_NM101_SubmitterEntityRole] [varchar](100) NULL,
	[1000A_NM102_SubmitterPersonIndicator] [varchar](100) NULL,
	[1000A_NM103_SubmitterLastName] [varchar](100) NULL,
	[1000A_NM108_SubmitterIdentifierQualifier] [varchar](100) NULL,
	[1000A_NM109_SubmitterIdentifier] [varchar](100) NULL,
	[1000A_PER01_01_SubmitterContactIdentifier] [varchar](100) NULL,
	[1000A_PER02_01_SubmitterContactName] [varchar](100) NULL,
	[1000A_PER03_01_SubmitterContactQualifier1] [varchar](100) NULL,
	[1000A_PER04_01_SubmitterContact1] [varchar](100) NULL,
	[1000A_PER05_01_SubmitterContacQualifier2] [varchar](100) NULL,
	[1000A_PER06_01_SubmitterContact2] [varchar](100) NULL,
	[1000B_NM101_ReceiverEntityRole_] [varchar](100) NULL,
	[1000B_NM102_PersonIndicator] [varchar](100) NULL,
	[1000B_NM103_ReceiverName] [varchar](100) NULL,
	[1000B_NM108_ReceiverIdentifierQualifier] [varchar](100) NULL,
	[1000B_NM109_ReceiverIdentifier] [varchar](100) NULL,
	[2000A_PRV01_BillingProviderCode] [varchar](100) NULL,
	[2000A_PRV02_BillingProviderCodeQualifier] [varchar](100) NULL,
	[2000A_PRV03_BillingProviderTaxonomy] [varchar](100) NULL,
	[2010AA_NM101_BillingProviderRole] [varchar](100) NULL,
	[2010AA_NM102_BillingPersonIndicator] [varchar](100) NULL,
	[2010AA_NM103_BillingOrg_LastName] [varchar](100) NULL,
	[2010AA_NM104_BillingFirstName] [varchar](100) NULL,
	[2010AA_NM105_BillingMiddleName] [varchar](100) NULL,
	[2010AA_NM107_BillingSuffix] [varchar](100) NULL,
	[2010AA_NM108_BillingProviderIdentifierQualifier] [varchar](100) NULL,
	[2010AA_NM109_BillingProviderIdentifier] [varchar](100) NULL,
	[2010AA_N301_BillingAddressLine1] [varchar](100) NULL,
	[2010AA_N302_BillingAddressLine2] [varchar](100) NULL,
	[2010AA_N401_BillingCity] [varchar](100) NULL,
	[2010AA_N402_BillingState] [varchar](100) NULL,
	[2010AA_N403_BillingPostalCode] [varchar](100) NULL,
	[2010AA_N404_BillingCountry] [varchar](100) NULL,
	[2010AA_REF01_BillingProviderIdentifierQualifier_1] [varchar](100) NULL,
	[2010AA_REF02_BillingProviderIdentifier_1] [varchar](100) NULL,
	[2010AA_REF01_BillingProviderIdentifierQualifier_2] [varchar](100) NULL,
	[2010AA_REF02_BillingProviderIdentifier_2] [varchar](100) NULL,
	[2010AA_BillingProviderSpeciality] [varchar](100) NULL,
	[2010AA_BillingProviderType_] [varchar](100) NULL,
	[2010AA_PER01_BillingProviderContactFunction_1] [varchar](100) NULL,
	[2010AA_PER02_BillingProviderContactName_1] [varchar](100) NULL,
	[2010AA_PER03_BillingProviderCommunicationNumberQualifier_1] [varchar](100) NULL,
	[2010AA_PER04_BillingProviderCommunicationNumber_1] [varchar](100) NULL,
	[2010AA_PER05_BillingProviderCommunicatioNumberQualifier_1] [varchar](100) NULL,
	[2010AA_PER06_BillingProviderCommunicationNumber_1] [varchar](100) NULL,
	[2010AA_PER07_BillingProviderCommunicatioNumberQualifier_1] [varchar](100) NULL,
	[2010AA_PER08_BillingProviderCommunicationNumber_1] [varchar](100) NULL,
	[2010AA_PER01_BillingProviderContactFunction_2] [varchar](100) NULL,
	[2010AA_PER02_BillingProviderContactName_2] [varchar](100) NULL,
	[2010AA_PER03_CommunicatioNumberQualifier_2] [varchar](100) NULL,
	[2010AA_PER04_BillingProviderCommunicationNumber_2] [varchar](100) NULL,
	[2010AA_PER05_BillingProviderCommunicatioNumberQualifier_2] [varchar](100) NULL,
	[2010AA_PER06_BillingProviderCommunicationNumber_2] [varchar](100) NULL,
	[2010AA_PER07_BillingProviderCommunicatioNumberQualifier_2] [varchar](100) NULL,
	[2010AA_PER08_BillingProviderCommunicationNumber_2] [varchar](100) NULL,
	[2010AB_NM101_PayToProviderRole] [varchar](100) NULL,
	[2010AB_NM102_PayToPersonIndicator] [varchar](100) NULL,
	[2010AB_N301_PayToAddressLine1] [varchar](100) NULL,
	[2010AB_N302_PayToAddressLine2] [varchar](100) NULL,
	[2010AB_N401_PayToCity] [varchar](100) NULL,
	[2010AB_N402_PayToState] [varchar](100) NULL,
	[2010AB_N403_PayToPostalCode] [varchar](100) NULL,
	[2010AB_N404_PayToCountry] [varchar](100) NULL,
	[2010AC_NM101_PayToPlanOrganizationRole] [varchar](100) NULL,
	[2010AC_NM102_PayToPlanPersonIndicator] [varchar](100) NULL,
	[2010AC_NM103_PayToPlanName] [varchar](100) NULL,
	[2010AC_NM108_PayToPlanOrganizationIDQualifier] [varchar](100) NULL,
	[2010AC_NM109_PayToPlanOrganizationIdentifier] [varchar](100) NULL,
	[2010AC_N301_PayToPlanAddressLine1] [varchar](100) NULL,
	[2010AC_N302_PayToPlanAddressLine2] [varchar](100) NULL,
	[2010AC_N401_PayToPlanCity] [varchar](100) NULL,
	[2010AC_N402_PayToPlanState] [varchar](100) NULL,
	[2010AC_N403_PayToPlanPostalCode] [varchar](100) NULL,
	[2010AC_N404_PayToPlanCountry] [varchar](100) NULL,
	[2010AC_REF01_OrganizationIDQualifier_1] [varchar](100) NULL,
	[2010AC_REF02_OrganizationIdentifier_1] [varchar](100) NULL,
	[2010AC_REF01_OrganizationIDQualifier_2] [varchar](100) NULL,
	[2010AC_REF02_OrganizationIdentifier_2] [varchar](100) NULL,
	[Claim_Encounter_Cleanup] [varchar](100) NULL,
	[Atypical_Provider_Flag] [varchar](100) NULL,
	[Supplemental_Interim_Flag] [varchar](100) NULL,
	[Interim_Late_Charge_Flag] [varchar](100) NULL,
	[IssuerIdentifier] [varchar](100) NULL,
	[100_Filler_05] [varchar](100) NULL,
	[100R_MonetaryAmountChangeFlag] [varchar](100) NULL,
	[1000A_NM104_SubmitterFirstName] [varchar](100) NULL,
	[BillingCountyCode] [varchar](100) NULL,
	[100_Filler_06] [varchar](100) NULL,
	[ClaimInputMethod] [varchar](100) NULL,
	[Rehab_Flag] [varchar](100) NULL,
	[PS_Custom_Field_1] [varchar](100) NULL,
	[Void_Reason] [varchar](100) NULL,
	[PS_Custom_Field_2] [varchar](100) NULL,
	[100_Filler_12] [varchar](100) NULL,
	[100_Filler_13] [varchar](100) NULL,
	[100_Filler_14] [varchar](100) NULL,
	[100_Filler_15] [varchar](100) NULL,
	[100_Filler_16] [varchar](100) NULL,
	[100_Filler_17] [varchar](100) NULL
) ON [PRIMARY]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [ClaimID]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ((0)) FOR [SourceDataKey]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [SourceDesc]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [ClaimStatus]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [ClaimType]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [SenderID]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Receiver_ID_]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [OriginatorID]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Contract_ID]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [DestinationID]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [HistoricalIndicator]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [HistoricalDispositionStatus]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [HistoricalEncounterICN]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [HistoricalEncounterID]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Paper]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [DME]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Administrative_Denial]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Chart_Review_Data]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Source_]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Filler]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [TraceNumber]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_NM101_SubmitterEntityRole]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_NM102_SubmitterPersonIndicator]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_NM103_SubmitterLastName]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_NM108_SubmitterIdentifierQualifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_NM109_SubmitterIdentifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_PER01_01_SubmitterContactIdentifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_PER02_01_SubmitterContactName]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_PER03_01_SubmitterContactQualifier1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_PER04_01_SubmitterContact1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_PER05_01_SubmitterContacQualifier2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_PER06_01_SubmitterContact2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000B_NM101_ReceiverEntityRole_]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000B_NM102_PersonIndicator]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000B_NM103_ReceiverName]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000B_NM108_ReceiverIdentifierQualifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000B_NM109_ReceiverIdentifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2000A_PRV01_BillingProviderCode]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2000A_PRV02_BillingProviderCodeQualifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2000A_PRV03_BillingProviderTaxonomy]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_NM101_BillingProviderRole]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_NM102_BillingPersonIndicator]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_NM103_BillingOrg_LastName]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_NM104_BillingFirstName]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_NM105_BillingMiddleName]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_NM107_BillingSuffix]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_NM108_BillingProviderIdentifierQualifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_NM109_BillingProviderIdentifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_N301_BillingAddressLine1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_N302_BillingAddressLine2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_N401_BillingCity]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_N402_BillingState]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_N403_BillingPostalCode]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_N404_BillingCountry]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_REF01_BillingProviderIdentifierQualifier_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_REF02_BillingProviderIdentifier_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_REF01_BillingProviderIdentifierQualifier_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_REF02_BillingProviderIdentifier_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_BillingProviderSpeciality]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_BillingProviderType_]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER01_BillingProviderContactFunction_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER02_BillingProviderContactName_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER03_BillingProviderCommunicationNumberQualifier_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER04_BillingProviderCommunicationNumber_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER05_BillingProviderCommunicatioNumberQualifier_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER06_BillingProviderCommunicationNumber_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER07_BillingProviderCommunicatioNumberQualifier_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER08_BillingProviderCommunicationNumber_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER01_BillingProviderContactFunction_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER02_BillingProviderContactName_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER03_CommunicatioNumberQualifier_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER04_BillingProviderCommunicationNumber_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER05_BillingProviderCommunicatioNumberQualifier_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER06_BillingProviderCommunicationNumber_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER07_BillingProviderCommunicatioNumberQualifier_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AA_PER08_BillingProviderCommunicationNumber_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AB_NM101_PayToProviderRole]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AB_NM102_PayToPersonIndicator]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AB_N301_PayToAddressLine1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AB_N302_PayToAddressLine2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AB_N401_PayToCity]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AB_N402_PayToState]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AB_N403_PayToPostalCode]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AB_N404_PayToCountry]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_NM101_PayToPlanOrganizationRole]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_NM102_PayToPlanPersonIndicator]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_NM103_PayToPlanName]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_NM108_PayToPlanOrganizationIDQualifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_NM109_PayToPlanOrganizationIdentifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_N301_PayToPlanAddressLine1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_N302_PayToPlanAddressLine2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_N401_PayToPlanCity]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_N402_PayToPlanState]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_N403_PayToPlanPostalCode]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_N404_PayToPlanCountry]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_REF01_OrganizationIDQualifier_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_REF02_OrganizationIdentifier_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_REF01_OrganizationIDQualifier_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [2010AC_REF02_OrganizationIdentifier_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Claim_Encounter_Cleanup]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Atypical_Provider_Flag]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Supplemental_Interim_Flag]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Interim_Late_Charge_Flag]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [IssuerIdentifier]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [100_Filler_05]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [100R_MonetaryAmountChangeFlag]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [1000A_NM104_SubmitterFirstName]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [BillingCountyCode]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [100_Filler_06]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [ClaimInputMethod]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Rehab_Flag]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [PS_Custom_Field_1]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [Void_Reason]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [PS_Custom_Field_2]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [100_Filler_12]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [100_Filler_13]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [100_Filler_14]
GO

ALTER TABLE [staging].[EE_CSV_100P_Rec_Header] ADD  DEFAULT ('') FOR [100_Filler_15]
GO


