CREATE PROCEDURE [dbo].[OSS_PROF_SDO_to_CSV_MAP]
(@IsResub BIT = 0 --default to regular run
,@IsRetraction BIT = 0)

AS
/********************************************************************************************************************************************************************
  HISTORY: 
  07-02-2024		Aaron Ridley    Created to map finalized claims in the OSS.dbo.SDO* tables into preliminary CSV staging schema

*********************************************************************************************************************************************************************/
/* Modifications 
ASU 2024-09-19 RETM-721
	Added optional parameter @IsResub to handle submission of resub items
--
*/

DECLARE @TOTAL_RECORDS INT
		,@Procedure_Name VARCHAR(75) = 'EDIFECS.dbo.OSS_PROF_SDO_to_CSV_MAP';
	
	--SYSLOG INSERT INITIATING PROCESS 
	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG (PROC_NAME
	, START_DT
	, END_DT
	, RUN_MINUTES
	, TOTAL_RECORDS
	, ENTRYDT)
		VALUES (@Procedure_Name, GETDATE(), NULL, NULL, 0, GETDATE());  


/********************************************************************************************************************************************************************
  100 RECORD INSERT 
*********************************************************************************************************************************************************************/

TRUNCATE TABLE EDIFECS.staging.EE_CSV_100P_Rec_Header; 
INSERT INTO EDIFECS.staging.EE_CSV_100P_Rec_Header  
SELECT DISTINCT 
	CLMHDR.CLM_ID,
	CLMHDR.SRC_DATA_KEY,
	CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END,--sourcedesc - Need mapping -Aaron 3/26 - There are Z's for the Encounter Source Data (148)
	getdate(),
	'',
	--CLMHDR.CLM_TY,
	CASE WHEN CLMHDR.CLM_FRM_TY_CD = 'H' THEN 'P' ELSE 'I' END,
	'CHSAZCLP' ,
	'CHSAZAPP', --ReceiverID
	'', --OriginatorID
	CLMHDR.[CNTRCT_NUM],--CNTRCT_NUM,
	'EDSCMS',
	'',     --    HistoricalIndicator
	'',     --    HistoricalDispositionStatus
	'',     -- HistoricalICN
	'',     --HistoricalEncounterID
	CASE WHEN CLM_SBMSN_TY = 'PAPER' THEN CLM_SBMSN_TY ELSE '' END AS PaperFlag, 
	CASE WHEN ECP.[ISDME] = 1  THEN 'TRUE' ELSE 'FALSE' END as DME,
	'',		-- AdministrativeDenial
	'',		-- ChartReviewData
	CLMHDR.SRC_DATA_KEY,
	CASE WHEN FREQ_CD IN ('7','8') THEN 'Y' ELSE 'N' END,
	'',     --    TraceNumber
	'',     --    NM1010A_SubmitterEntityRole
	'',     --    NM1020A_SubmitterPersonIndicator
	'',     --    NM1030A_SubmitterLastName
	'',     --    NM1080A_SubmitterIdentifierQualifier
	'',     --    NM1090A_SubmitterIdentifier
	'',     --    PER010A_01_SubmitterContactIdentifier
	'',     --    PER020A_01_SubmitterContactName
	'',     --    PER030A_01_SubmitterContactQualifier1 TE,EM,FX
	'',     --    PER040A_01_SubmitterContact1
	'',     --    PER050A_01_SubmitterContacQualifier2 TE,EM,FX, EX
	'',     --    PER060A_01_SubmitterContact2
	'',     --    NM1010B_ReceiverEntityRole
	'',     --    NM1020B_PersonIndicator
	'',     --    NM1030B_ReceiverName
	'',     --    NM1080B_ReceiverIdentifierQualifier
	'',     --    NM1090B_ReceiverIdentifier
	'',     --    PRV01A_BillingProviderCode
	'',     --    PRV02A_BillingProviderCodeQualifier
	CLMHDR.PROV_TAXNMY_CD,
	'',     --    NM101AA_BillingProviderRole
	'',
	CASE WHEN PROV.LAST_NM IS NULL THEN PROV.PROV_NM ELSE PROV.LAST_NM END,
	CASE WHEN PROV.FRST_NM IS NULL THEN '' ELSE PROV.FRST_NM END,
	CASE WHEN PROV.MID_NM IS NULL THEN '' ELSE PROV.MID_NM END,
	'',     --    NM107AA_BillingSuffix
	'',     --    NM108AA_BillingProviderIdentifierQualifier
	CLMHDR.[PROV_BILL_ENTTY_NPI],
	COALESCE(PROV.MAIL_SRC_ADDR_LN_1, PROV.BUS_SRC_ADDR_LN_1),
	COALESCE(PROV.MAIL_SRC_ADDR_LN_2, PROV.BUS_SRC_ADDR_LN_2),
	COALESCE(PROV.MAIL_SRC_CITY,PROV.BUS_SRC_CITY),
	COALESCE(PROV.MAIL_SRC_STE,PROV.BUS_SRC_STE),
	COALESCE(PROV.MAIL_SRC_ZIP_CD, PROV.BUS_SRC_ZIP_CD),
	'',     --    N404AA_BillingCountry
	'',     --    REF01AA_BillingProviderIdentifierQualifier01
	PROV.PROV_TIN
		,''     --    REF01AA_BillingProviderIdentifierQualifier02
		,''     --    REF02AA_BillingProviderIdentifier02
		,''     --    BillingProviderSpecialityAA
		,''     --    BillingProviderTypeAA
		,''     --    PER0AA1_BillingProviderContactFunction_1
		,''     --    PER02AA_BillingProviderContactName_1
		,''     --    PER03AA_BillingProviderCommunicationNumberQualifier_1
		,''     --    PER04AA_BillingProviderCommunicationNumber_1
		,''     --    PER05AA_BillingProviderCommunicatioNumberQualifier_1
		,''     --    PER06AA_BillingProviderCommunicationNumber_1
		,''     --    PER07AA_BillingProviderCommunicatioNumberQualifier_1
		,''     --    PER08AA_BillingProviderCommunicationNumber_1
		,''     --    PER01AA_BillingProviderContactFunction_2
		,''     --    PER02AA_BillingProviderContactName_2
		,''     --    PER03AA_CommunicatioNumberQualifier_2
		,''     --    PER04AA_BillingProviderCommunicationNumber_2
		,''     --    PER05AA_BillingProviderCommunicatioNumberQualifier_2
		,''     --    PER06AA_BillingProviderCommunicationNumber_2
		,''     --    PER07AA_BillingProviderCommunicatioNumberQualifier_2
		,''     --    PER08AA_BillingProviderCommunicationNumber_2
		,''     --    NM101AB_PayToProviderRole
		,''     --    NM102AB_PayToPersonIndicator
		,''     --    N301AB_PayToAddressLine1
		,''     --    N302AB_PayToAddressLine2
		,''     --    N401AB_PayToCity
		,''     --    N402AB_PayToState
		,''     --    N403AB_PayToPostalCode
		,''     --    N404AB_PayToCountry
		,''     --    NM101AC_PayToPlanOrganizationRole
		,''     --    NM102AC_PayToPlanPersonIndicator
		,''     --    NM103AC_PayToPlanName
		,''     --    NM108AC_PayToPlanOrganizationIDQualifier
		,''     --    NM109AC_PayToPlanOrganizationIdentifier
		,''     --    N301AC_PayToPlanAddressLine1
		,''     --    N302AC_PayToPlanAddressLine2
		,''     --    N401AC_PayToPlanCity
		,''     --    N402AC_PayToPlanState
		,''     --    N403AC_PayToPlanPostalCode
		,''     --    N404AC_PayToPlanCountry
		,''     --    REF01AC_OrganizationIDQualifier_1
		,''     --    REF02AC_OrganizationIdentifier_1
		,''     --    REF01AC_OrganizationIDQualifier_2
		,''     --    REF02AC_OrganizationIdentifier_2
		,''     --    ClaimEncounterCleanup
		,''     --    AtypicalProviderFlag  -- Update (Need criteria to identify default NPI - NPI or TaxID) 'Y' DDRC (048/052) 19999
		,''     --    SupplementalInterimFlag
		,''     --    InterimLateChargeFlag
		,''     --    IssuerIdentifier
		,''     --    Filler05
		,''     --    R_MonetaryAmountChangeFlag
		,''     --    NM1040ASubmitterFirstName
		,''     --    BillingCountyCode
		,''     --    Filler06
		,''     --    ClaimInputMethod
		,''     --    RehabFlag
		,''     --    PSCustomField01
		,''     --    VoidReason
		,''     --    PSCustomField02
		,''     --    Filler12
		,''     --    Filler13
		,CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END    --    Filler14 
		,''     --    Filler15	
		,CASE WHEN FREQ_CD ='7' THEN 'TRUE' ELSE 'FALSE' END
	  ,CASE 
				 WHEN CLMHDR.PREV_CLM_ID = '' OR CLMHDR.PREV_CLM_ID IS NULL THEN ''
				 WHEN FREQ_CD IN ('7','8') AND CLMHDR.[IS_ENCNTR_IND] <> 'Y' THEN CAST(CLMHDR.SRC_DATA_KEY AS VARCHAR) + CLMHDR.PREV_CLM_ID
	   --Remove above  WHEN ECP.ISENCOUNTER = 0 AND ECP.LOB_CODE <> 'C54581391' THEN CAST(CLMHDR.SRC_DATA_KEY AS VARCHAR) + CLMHDR.[PATNT_CTL_NUM
		--  		 WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLMHDR.[PATNT_CTL_NUM]
				 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLMHDR.[PATNT_CTL_NUM]	
				 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLMHDR.[PATNT_CTL_NUM]	
				 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLMHDR.[PATNT_CTL_NUM] -- 2300P_CLM01_ClaimNumber
		   -- 	 WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391'  AND ECP.LOB = 'MMAI' AND CLMHDR.ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLMHDR.[PATNT_CTL_NUM]
				 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391'  AND ECP.LOB = 'CAID' AND CLMHDR.ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLMHDR.[PATNT_CTL_NUM]
				 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391' AND ECP.LOB = 'MMAI' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLMHDR.[PATNT_CTL_NUM]
				 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391' AND ECP.LOB = 'CAID' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLMHDR.[PATNT_CTL_NUM]
				 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '45' + CLMHDR.CLM_ID -- RETM-11
				 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391' AND ECP.LOB = 'MMAI' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '451' + CLMHDR.CLM_ID -- RETM-11
				 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391' AND ECP.LOB = 'CAID' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '452' + CLMHDR.CLM_ID -- RETM-11
				 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM  IN ('Catasys', 'EDPS-Catasys') THEN '46' + CLMHDR.[PATNT_CTL_NUM]
				 --WHEN ECP.LOB = 'MMAI' AND ECP.LOB_CODE = 'C54581391' THEN '51' + CLMHDR.[PATNT_CTL_NUM]
		   --      WHEN ECP.LOB = 'CAID' AND ECP.LOB_CODE = 'C54581391' THEN '52' + CLMHDR.[PATNT_CTL_NUM]

			 END --Filler17
FROM  OSS.dbo.[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR 
INNER JOIN WIPRO.[dbo].[EDS_Claims_Processing] ECP ON CLMHDR.CLM_ID = ECP.CLAIMID
LEFT OUTER JOIN OSS.staging.[CDO_PROV_DEMG] PROV ON CLMHDR.[PROV_BILL_ENTTY_ID] = PROV.[PROV_ID] 
LEFT JOIN WIPRO.dbo.Retraction_Input_Interim RII ON ECP.CLAIMID = RII.CLAIMID
WHERE 1 = 1
	AND CLMHDR.CLM_TY = 'PROFESSIONAL'
	AND (	   (IsResub = CASE WHEN @IsResub = 0 AND @ISRETRACTION = 0 THEN 0 END AND ECP.MEDICARESUBMISSIONDATE IS NULL AND CLMHDR.SRC_DATA_KEY = ECP.SOURCEDATAKEY) --regular run
			OR (IsResub = CASE WHEN @IsResub = 1 THEN 1 END AND CLMHDR.SRC_DATA_KEY = ECP.SOURCEDATAKEY) --resub run
			OR (IsRetraction = CASE WHEN @IsRetraction = 1 THEN 1 END AND RII.CLAIMID IS NOT NULL) --Retraction Run
		)
OPTION (OPTIMIZE FOR (@IsResub = 0)); --optimize for non-resub runs

 /********************************************************************************************************************************************************************
  150 RECORD INSERT 
*********************************************************************************************************************************************************************/

TRUNCATE TABLE EDIFECS.staging.EE_CSV_150P_Rec_Header;

INSERT INTO EDIFECS.staging.EE_CSV_150P_Rec_Header  
SELECT DISTINCT  
	CLMHDR.CLM_ID,
	CLMHDR.SRC_DATA_KEY,
	CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END, --System_Source (Data Gap)
	GETDATE(), 
		'',        -- SBR01BSubscriberPayerResponsibilitySequence - varchar(100)
		'',        -- SBR02BSubscriberRelationship - varchar(100)
		'',        -- SBR03BSubscriberPolicyNumber - varchar(100)
		'',        -- SBR04BInsuredGroupName - varchar(100)
		'16' as SBR09BClaimFilingIndicator,		-- SBR09BClaimFilingIndicator (Data Gap)
		'',        -- NM101BASubscriberPersonRole - varchar(100)
		'',        -- NM102BASubscriberPersonIndicator - varchar(100)
	CLMHDR.[MBR_LAST_NM],
	CLMHDR.[MBR_FRST_NM],
	CLMHDR.[MBR_MID_NM],
	   '' as NM107BASubscriberSuffix,			-- NM107BASubscriberSuffix (Data Gap) Not needed 
	   '',        -- NM108BASubscriberIdentifierQualifer - varchar(100)
	CLMHDR.MBR_ID,
	  '',        -- REF01BASubscriberSSNQualifier - varchar(100)
	MEM.SSN,
		'',        -- REF01BAPropertyandCasualtyQualifier - varchar(100)
		'',        -- REF02BAPropertyandCasualtyIdentifier - varchar(100)
	COALESCE([MAIL_SRC_ADDR_LN_1],MEM.PHY_SRC_ADDR_LN_1),
	COALESCE([MAIL_SRC_ADDR_LN_2],MEM.PHY_SRC_ADDR_LN_2),
	COALESCE([MAIL_SRC_CITY],MEM.PHY_SRC_CITY),
	COALESCE([MAIL_SRC_STE],MEM.PHY_SRC_STE), 
	COALESCE([MAIL_SRC_ZIP_CD],MEM.PHY_SRC_ZIP_CD),
		 '',        -- N404BASubscriberCountry - varchar(100)
		'',        -- DMG01BADateQualifer - varchar(100)
	CONVERT(CHAR(8),MEM.DT_OF_BRTH,112), -- Aaron - Change format CCYYMMDD)
	MEM.GENDR, 
		'',        -- REF01BASubscriberIdentifierQualifier01 - varchar(100)
		'',        -- REF02BASubscriberIdentifier01 - varchar(100)
		'',        -- REF01BASubscriberIdentifierQualifer02 - varchar(100)
	MEM.MEDCR_ID,
		 '',        -- NM101BBPayerOrganizationRole - varchar(100)
		'',        -- NM102BBPayerPersonIndicator - varchar(100)
		'', -- Commented out EDS-2185 oph.OTH_PAYER1_NAME,        -- NM103BBPayerName - varchar(100)
		'',        -- NM108BBPayerOrganizationIDQualifier - varchar(100)
		'',        -- NM109BBPayerOrganizationIdentifier - varchar(100)
		'' as N301BBPayerAddressLine1,         -- N301BBPayerAddressLine1 - varchar(100) (Data Gap)
		'' as N302BBPayerAddressLine2,        -- N302BBPayerAddressLine2 - varchar(100) (Data Gap)
		'' as N42010BB_N401_PayerCity,        --[2010BB_N401_PayerCity]  [VARCHAR] (100)   Default '', (Data Gap)
		'' as N401BBPayerState,        -- N401BBPayerState - varchar(100) (Data Gap)
		'' as N403BBPayerPostalCode,        -- N403BBPayerPostalCode - varchar(100) (Data Gap)
		'',        -- N404BBPayerCountry - varchar(100)
		'',        -- REF01BBPayerOrganizationIDQualifier01 - varchar(100)
		'',        -- REF02BBPayerOrganizationIdentifier01 - varchar(100)
		'',        -- REF01BBProviderIDQualifier01 - varchar(100)
		'',        -- REF02BBBillingProviderIdentifier01 - varchar(100)
		'',        -- REF01BBBillingProviderIDQualifier02 - varchar(100)
		'',        -- REF02BBBillingProviderIdentifier02 - varchar(100)
		'',        -- REF01BBBillingProviderIDQualifier03 - varchar(100)
		'',        -- REF02BBProviderIdentifier03 - varchar(100)
		'',        -- REF01BBBillingProviderIDQualifier04 - varchar(100)
		'',        -- REF02BBBillingProviderIdentifier04 - varchar(100)
		'',        -- PatientLastName - varchar(100)
		'',        -- PatientFirstName - varchar(100)
		'',        -- PatientMiddleName - varchar(100)
		'',        -- PatientSSN - varchar(100)
		'',        -- PatientMemberID - varchar(100)
		'',        -- PatientGender - varchar(100)
		'',        -- PatientDOB - varchar(100)
		'',        -- PatientAddressLine1 - varchar(100)
		'',        -- PatientAddressLine2 - varchar(100)
		'',        -- PatientAddressCity - varchar(100)
		'',        -- PatientAddressState - varchar(100)
		'',        -- PatientAddressZip - varchar(100)
		'',        -- PCPIDQual - varchar(100)
		'',        -- PCPID - varchar(100)
		'',        -- PCPGroupIdentifier - varchar(100)
		'',        -- PDPIPAPMGType - varchar(100)
		'',        -- PDPIPAPMGID - varchar(100)
		'',        -- PCPOpenIndic - varchar(100)
		'',        -- PCPEligibilityInd - varchar(100)
		'',        -- COS - varchar(100)
		'',        -- ServiceCategoryType - varchar(100)
		'',        -- RenderingProvEffDate - varchar(100)
		'',        -- RenderingProvTermDate - varchar(100)
		'',        -- RenderingProvDEAID - varchar(100)
		'',        -- RenderingProvGender - varchar(100)
		'',        -- ProviderParNonPar - varchar(100)
		'',        -- CarePlanOptionIndicator - varchar(100)
		'',        -- GroupIndicator - varchar(100)
		'',        -- CareTypeCode - varchar(100)
		'',        -- FinancialArrangementCode - varchar(100)
		'',        -- Filler05 - varchar(100) -- Aaron -- Utilize for Member Reimbursement Flag (only for Professional)  Y -SDK=30 only
		'',        --oph.OTH_INSR_TYPECD1,  iNSURANCETYPECODE
		'',        -- PAT09BPregnancyIndicator - varchar(100)
		'',        -- Filler06 - varchar(100)
		'',        -- Filler07 - varchar(100)
		'',        -- Filler08 - varchar(100)
		'',        -- Filler09 - varchar(100)
		'',        -- Filler10 - varchar(100)
		'',        -- Filler11 - varchar(100)
		'',        -- Filler12 - varchar(100)
		'',        -- Filler13 - varchar(100)
		'',        -- Filler14 - varchar(100)
		'',        -- Filler15 - varchar(100)
		'',        -- PAT06BPatientDeathDate - varchar(100)
		'',        -- PAT01CPatientRelationship - varchar(100)
		'',        -- PAT06CPatientDeathDate - varchar(100)
		'',        -- PAT08CPatientWeight - varchar(100)
		'',        -- PAT09CPregnancyIndicator - varchar(100)
		'',        -- SubscriberRegionCode - varchar(100)
		'',        -- SubscriberOtherInsuranceCoverage - varchar(100)
		'',        -- PurchasedIndicator - varchar(100)
		''         -- BehavioralHealthCOS - varchar(100)
from OSS.dbo.[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR
INNER JOIN EDIFECS.staging.EE_CSV_100P_Rec_Header CSVP ON CLMHDR.CLM_ID = CSVP.ClaimID AND CLMHDR.SRC_DATA_KEY = CSVP.SOURCEDATAKEY
left join OSS.staging.[CDO_MBR_DEMG] MEM ON CLMHDR.MBR_ID = MEM.MBR_ID AND CLMHDR.SRC_DATA_KEY = MEM.SRC_DATA_KEY;

 /********************************************************************************************************************************************************************
 UDPATE MEMBER DATA FOR MEMBERS INFO NOT UPDATED DUE TO SDK MISMATCH
*********************************************************************************************************************************************************************/
UPDATE EDIFECS.staging.EE_CSV_150P_Rec_Header
SET 
[2010BA_REF02_Subscriber_Identifier_SSN] = SSN,
[2010BA_N301_SubscriberAddressLine1] = COALESCE([MAIL_SRC_ADDR_LN_1],MEM.PHY_SRC_ADDR_LN_1),
[2010BA_N302_SubscriberAddressLine2] = COALESCE([MAIL_SRC_ADDR_LN_2],MEM.PHY_SRC_ADDR_LN_2),
[2010BA_N401_SubscriberCity] = COALESCE([MAIL_SRC_CITY],MEM.PHY_SRC_CITY),
[2010BA_N402_SubscriberState] = COALESCE([MAIL_SRC_STE],MEM.PHY_SRC_STE),
[2010BA_N403_SubscriberPostalCode] = COALESCE([MAIL_SRC_ZIP_CD],MEM.PHY_SRC_ZIP_CD),
[2010BA_DMG02_DateOfBirth] = CONVERT(CHAR(8),MEM.DT_OF_BRTH,112),
[2010BA_DMG03_Gender] = GENDR,
[2010BA_REF02_SubscriberIdentifier_1] = MEDCR_ID
FROM EDIFECS.staging.EE_CSV_150P_Rec_Header CSVP
left join OSS.staging.[CDO_MBR_DEMG] MEM ON CSVP.[2010BA_NM109_SubscriberIdentifier] = MEM.MBR_ID  
WHERE [2010BA_DMG03_Gender] IS NULL OR [2010BA_DMG03_Gender] =''

/*---------------------------------------------------------------------*/
/* POPULATE 20 REC TABLE                                                */
/*---------------------------------------------------------------------*/


TRUNCATE TABLE EDIFECS.staging.EE_CSV_20P_Rec_Header;

INSERT INTO EDIFECS.staging.EE_CSV_20P_Rec_Header	   
	   ([ClaimID]
      ,[SourceDataKey]
      ,[SourceDesc]
      ,[CreateDate]
      ,[2300P_CLM01_ClaimNumber]
      ,[2300P_CLM02_TotalClaimCharge]
      ,[2300P_CLM05-01_PlaceOfService]
      ,[2300P_CLM05-02_BillTypeQualifier]
      ,[2300P_CLM05-03_ClaimFrequencyCode]
      ,[2300P_CLM06_ProviderSignature]
      ,[2300P_CLM07_MedicareAssignment]
      ,[2300P_CLM08_BenefitAssignmentIndicator]
      ,[2300P_CLM09_ReleaseOfInformation]
      ,[2300P_CLM10_PatientSignatureSource]
      ,[2300P_CLM11-01_RelatedCausesCode]
      ,[2300P_CLM11-02_RelatedCausesCode]
      ,[2300P_CLM11-04_AccidentState]
      ,[2300P_CLM11-05_AccidentCountry]
      ,[2300P_CLM12_SpecialProgramIndicator]
      ,[2300P_CLM20_DelayReason]
      ,[2300P_DTP01_DateTimeQualifier_1]
      ,[2300P_DTP02_FormatQualifier_1]
      ,[2300P_DTP03_DateTime_1]
      ,[2300P_DTP01_DateTimeQualifier_2]
      ,[2300P_DTP02_FormatQualifier_2]
      ,[2300P_DTP03_DateTime_2]
      ,[2300P_DTP01_DateTimeQualifier_3]
      ,[2300P_DTP02_FormatQualifier_3]
      ,[2300P_DTP03_DateTime_3]
      ,[2300P_DTP01_DateTimeQualifier_4]
      ,[2300P_DTP02_FormatQualifier_4]
      ,[2300P_DTP03_DateTime_4]
      ,[2300P_DTP01_DateTimeQualifier_5]
      ,[2300P_DTP02_FormatQualifier_5]
      ,[2300P_DTP03_DateTime_5]
      ,[2300P_DTP01_DateTimeQualifier_6]
      ,[2300P_DTP02_FormatQualifier_6]
      ,[2300P_DTP03_DateTime_6]
      ,[2300P_DTP01_DateTimeQualifier_7]
      ,[2300P_DTP02_FormatQualifier_7]
      ,[2300P_DTP03_DateTime_7]
      ,[2300P_CN101_ContractTypeCode]
      ,[2300P_CN102_MonetaryAmount]
      ,[2300P_CN103_ContractPercentage]
      ,[2300P_CN104_ContractCode]
      ,[2300P_CN105_TermsDiscountPercent]
      ,[2300P_CN106_ContractVersionIdentifier]
      ,[2300P_AMT01_AmountQualifier]
      ,[2300P_AMT02_PatientAmountPaid]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_1]
      ,[2300P_REF02_ClaimReferenceNumber_1]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_2]
      ,[2300P_REF02_ClaimReferenceNumber_2]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_3]
      ,[2300P_REF02_ClaimReferenceNumber_3]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_4]
      ,[2300P_REF02_ClaimReferenceNumber_4]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_5]
      ,[2300P_REF02_ClaimReferenceNumber_5]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_6]
      ,[2300P_REF02_ClaimReferenceNumber_6]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_7]
      ,[2300P_REF02_ClaimReferenceNumber_7]
      ,[2300P_REF01_ClaimReferenceNumberQualifier_8]
      ,[2300P_REF02_ClaimReferenceNumber_8]
      ,[2300P_NTE01_ClaimNoteType]
      ,[2300P_NTE02_ClaimNote]
      ,[20P_Ambulance_Transport_Count]
      ,[2300P_CR101_AmbPatientWeightQualifier]
      ,[2300P_CR102_AmbulancePatientWeight]
      ,[2300P_CR104_AmbulanceTransportReason]
      ,[2300P_CR105_AmbulanceMeasure]
      ,[2300P_CR106_AmbulanceDistance]
      ,[2300P_CR109_AmbulanceRoundTripDesc]
      ,[2300P_CR110_StretcherPurposeDescription]
      ,[2300P_CRC01_ServiceCertificationCategory]
      ,[2300P_CRC02_ServiceCertificationIndicator]
      ,[2300P_CRC03_ConditionIndicatorCode]
      ,[2300P_CRC04_ConditionIndicatorCode]
      ,[2300P_CRC05_ConditionIndicatorCode]
      ,[2300P_CRC06_ConditionIndicatorCode]
      ,[2300P_CRC07_ConditionIndicatorCode]
      ,[2300P_HI01-01_DXType_1]
      ,[2300P_HI01-02_DXCode_1]
      ,[2300P_HI02-01_DXType_1]
      ,[2300P_HI02-02_DXCode_1]
      ,[2300P_HI03-01_DXType_1]
      ,[2300P_HI03-02_DXCode_1]
      ,[2300P_HI04-01_DXType_1]
      ,[2300P_HI04-02_DXCode_1]
      ,[2300P_HI05-01_DXType_1]
      ,[2300P_HI05-02_DXCode_1]
      ,[2300P_HI06-01_DXType_1]
      ,[2300P_HI06-02_DXCode_1]
      ,[2300P_HI07-01_DXType_1]
      ,[2300P_HI07-02_DXCode_1]
      ,[2300P_HI08-01_DXType_1]
      ,[2300P_HI08-02_DXCode_1]
      ,[2300P_HI09-01_DXType_1]
      ,[2300P_HI09-02_DXCode_1]
      ,[2300P_HI10-01_DXType_1]
      ,[2300P_HI10-02_DXCode_1]
      ,[2300P_HI11-01_DXType_1]
      ,[2300P_HI11-02_DXCode_1]
      ,[2300P_HI12-01_DXType_1]
      ,[2300P_HI12-02_DXCode_1]
      ,[2310AP_NM101_ProviderRole]
      ,[2310AP_NM102_PersonIndicator]
      ,[2310AP_NM103_LastName]
      ,[2310AP_NM104_FirstName]
      ,[2310AP_NM105_MiddleName]
      ,[2310AP_NM107_Suffix]
      ,[2310AP_NM108_ProviderIdentifierQualifer]
      ,[2310AP_NM109_ProviderIdentifier]
      ,[2310AP_REF01_ProviderIdentifierQualifer]
      ,[2310AP_REF02_ProviderIdentifier]
      ,[2310AP_REF01_ProviderIdentifierQualifer_02]
      ,[2310AP_REF02_ProviderIdentifier_02]
      ,[2310BP_NM101_ProviderRole]
      ,[2310BP_NM102_PersonIndicator]
      ,[2310BP_NM103_LastName]
      ,[2310BP_NM104_FirstName]
      ,[2310BP_NM105_MiddleName]
      ,[2310BP_NM107_Suffix]
      ,[2310BP_NM108_ProviderIdentifierQualifer]
      ,[2310BP_NM109_ProviderIdentifier]
      ,[2310BP_PRV01_ProviderCode]
      ,[2310BP_PRV02_ProviderCodeQualifer]
      ,[2310BP_PRV03_ProviderTaxonomy]
      ,[2310BP_REF01_ProviderIdentifierQualifer_1]
      ,[2310BP_REF02_ProviderIdentifier_1]
      ,[2310BP_REF01_ProviderIdentifierQualifer_2]
      ,[2310BP_REF02_ProviderIdentifier_2]
      ,[20P_RenderingProviderAddress1]
      ,[20P_RenderingProviderAddress2]
      ,[20P_RenderingProviderCity]
      ,[20P_RenderingProviderState]
      ,[20P_RenderingProviderZip]
      ,[2310CP_NM101_ProviderRole]
      ,[2310CP_NM102_PersonIndicator]
      ,[2310CP_NM103_LastName]
      ,[2310CP_NM108_ProviderIdentifierQualifer]
      ,[2310CP_NM109_ProviderIdentifier]
      ,[2310CP_N301_AddressLine1]
      ,[2310CP_N302_AddressLine2]
      ,[2310CP_N401_City]
      ,[2310CP_N402_State]
      ,[2310CP_N403_PostalCode]
      ,[2310CP_N404_Country]
      ,[2310CP_REF01_ProviderIdentifierQualifer]
      ,[2310CP_REF02_ProviderIdentifier]
      ,[2310DP_NM101_ProviderRole]
      ,[2310DP_NM102_PersonIndicator]
      ,[2310DP_NM103_LastName]
      ,[2310DP_NM104_FirstName]
      ,[2310DP_NM105_MiddleName]
      ,[2310DP_NM107_Suffix]
      ,[2310DP_NM108_ProviderIdentifierQualifer]
      ,[2310DP_NM109_ProviderIdentifier]
      ,[2310DP_REF01_ProviderIdentifierQualifer]
      ,[2310DP_REF02_ProviderIdentifier]
      ,[2310EP_NM101_ProviderRole]
      ,[2310EP_NM102_PersonIndicator]
      ,[2310EP_N301_AddressLine1]
      ,[2310EP_N302_AddressLine2]
      ,[2310EP_N401_City]
      ,[2310EP_N402_State]
      ,[2310EP_N403_PostalCode]
      ,[2310EP_N404_Country]
      ,[2310EP_REF01_ProviderIdentifierQualifer]
      ,[2310EP_REF02_ProviderIdentifier]
      ,[2310FP_NM101_ProviderRole]
      ,[2310FP_NM102_PersonIndicator]
      ,[2310FP_NM103_ORG_LastName]
      ,[2310FP_N301_AddressLine1]
      ,[2310FP_N302_AddressLine2]
      ,[2310FP_N401_City]
      ,[2310FP_N402_State]
      ,[2310FP_N403_PostalCode]
      ,[2310FP_N404_Country]
      ,[2310FP_REF01_ProviderIdentifierQualifer]
      ,[2310FP_REF02_ProviderIdentifier]
      ,[2300P_PWK01_AttachmentReportType]
      ,[2300P_PWK02_AttachmentTransmissionCode]
      ,[2300P_PWK06_AttachmentControlNumber]
      ,[2300P_REF01_InvestigationalDeviceExemptionNumber_Qualifier]
      ,[2300P_REF02_InvestigationalDeviceExemptionNumber]
      ,[2300P_REF01_ServiceAuthorizationExceptionCode_Qualifier]
      ,[2300P_REF02_ServiceAuthorizationExceptionCode]
      ,[2300P_REF01_MammographyCertificationNumber_Qualifier]
      ,[2300P_REF01_MammographyCertificationNumber]
      ,[2300P_CR208_PatientConditionCode]
      ,[2300P_CR210_PatientDescription]
      ,[2300P_CR211_PatientDescription]
      ,[2300P_HI101-2_AnesthesiaRelatedSurgicalProcedure]
      ,[2300P_HI102-2_AnesthesiaRelatedSurgicalProcedure]
      ,[2300P_DTP01_DateTimeQualifier_7_02]
      ,[2300P_DTP02_FormatQualifier_7_02]
      ,[2300P_DTP03_DateTime_7_02]
      ,[2300P_DTP01_DateTimeQualifier_8]
      ,[2300P_DTP02_FormatQualifier_8]
      ,[2300P_DTP03_DateTime_8]
      ,[2300P_DTP01_DateTimeQualifier_9]
      ,[2300P_DTP02_FormatQualifier_9]
      ,[2300P_DTP03_DateTime_9]
      ,[2300P_DTP01_DateTimeQualifier_10]
      ,[2300P_DTP02_FormatQualifier_10]
      ,[2300P_DTP03_DateTime_10]
      ,[2300P_DTP01_DateTimeQualifier_11]
      ,[2300P_DTP02_FormatQualifier_11]
      ,[2300P_DTP03_DateTime_11]
      ,[2300P_DTP01_DateTimeQualifier_12]
      ,[2300P_DTP02_FormatQualifier_12]
      ,[2300P_DTP03_DateTime_12]
      ,[2300P_DTP01_DateTimeQualifier_13]
      ,[2300P_DTP02_FormatQualifier_13]
      ,[2300P_DTP03_DateTime_13]
      ,[2300P_DTP01_DateTimeQualifier_14]
      ,[2300P_DTP02_FormatQualifier_14]
      ,[2300P_DTP03_DateTime_14]
      ,[2300P_DTP01_DateTimeQualifier_15]
      ,[2300P_DTP02_FormatQualifier_15]
      ,[2300P_DTP03_DateTime_15]
      ,[2300P_DTP01_DateTimeQualifier_16]
      ,[2300P_DTP02_FormatQualifier_16]
      ,[2300P_DTP03_DateTime_16]
      ,[2300P_HCP01_PricingMethodology]
      ,[2300P_HCP02_RepricedAllowedAmount]
      ,[2300P_HCP03_RepricedSavingAmount]
      ,[2300P_HCP04_RepricingOrganizationIdentifier]
      ,[2300P_HCP05_RepricingPerDiemAmount]
      ,[2300P_HCP06_RepricedApprovedAmbulatoryPatientGroupCode]
      ,[2300P_HCP07_RepricedApprovedAmbulatoryPatientGroupAmount]
      ,[2300P_HCP13_RejectReasonCode]
      ,[2300P_HCP14_PolicyComplianceCode]
      ,[2300P_HCP15_ExceptionCode]
      ,[2300P_HI01-01_ConditionCodeQualifier]
      ,[2300P_HI01-02_ConditionCode ]
      ,[2300P_HI02-01_ConditionCodeQualifier]
      ,[2300P_HI02-02_ConditionCode ]
      ,[2300P_HI03-01_ConditionCodeQualifier]
      ,[2300P_HI03-02_ConditionCode ]
      ,[2300P_HI04-01_ConditionCodeQualifier]
      ,[2300P_HI04-02_ConditionCode ]
      ,[2300P_HI05-01_ConditionCodeQualifier]
      ,[2300P_HI05-02_ConditionCode ]
      ,[2300P_HI06-01_ConditionCodeQualifier]
      ,[2300P_HI06-02_ConditionCode ]
      ,[2300P_HI07-01_ConditionCodeQualifier]
      ,[2300P_HI07-02_ConditionCode ]
      ,[2300P_HI08-01_ConditionCodeQualifier]
      ,[2300P_HI08-02_ConditionCode ]
      ,[2300P_HI09-01_ConditionCodeQualifier]
      ,[2300P_HI09-02_ConditionCode ]
      ,[2300P_HI10-01_ConditionCodeQualifier]
      ,[2300P_HI10-02_ConditionCode ]
      ,[2300P_HI11-01_ConditionCodeQualifier]
      ,[2300P_HI11-02_ConditionCode ]
      ,[2300P_HI12-01_ConditionCodeQualifier]
      ,[2300P_HI12-02_ConditionCode ]
      ,[2300P_REF01_FileInformation_Qualifier]
      ,[2300P_REF01_FileInformation]
      ,[Claim Processor Receiver Date]
      ,[InNetworkIndicator ]
      ,[PatientControlNumber]
      ,[20P-Filler 04]
      ,[20P-Filler 05]
      ,[20P-Filler 06]
      ,[20P-Filler 07]
      ,[20P-Filler 08]
      ,[20P-Filler 09]
      ,[20P-Filler 10]
      ,[20P-Filler 11]
      ,[20P-Filler 12]
      ,[20P-Filler 13]
      ,[20P-Filler 14]
      ,[20P-Filler 15]
      ,[2300P_HI13-01_ConditionCodeQualifier]
      ,[2300P_HI13-02_ConditionCode ]
      ,[2300P_HI14-01_ConditionCodeQualifier]
      ,[2300P_HI14-02_ConditionCode ]
      ,[2300P_HI15-01_ConditionCodeQualifier]
      ,[2300P_HI15-02_ConditionCode ]
      ,[2300P_HI16-01_ConditionCodeQualifier]
      ,[2300P_HI16-02_ConditionCode ]
      ,[2300P_HI17-01_ConditionCodeQualifier]
      ,[2300P_HI17-02_ConditionCode ]
      ,[2300P_HI18-01_ConditionCodeQualifier]
      ,[2300P_HI18-02_ConditionCode ]
      ,[2300P_HI19-01_ConditionCodeQualifier]
      ,[2300P_HI19-02_ConditionCode ]
      ,[2300P_HI20-01_ConditionCodeQualifier]
      ,[2300P_HI20-02_ConditionCode ]
      ,[2300P_HI21-01_ConditionCodeQualifier]
      ,[2300P_HI21-02_ConditionCode ]
      ,[2300P_HI22-01_ConditionCodeQualifier]
      ,[2300P_HI22-02_ConditionCode ]
      ,[2300P_HI23-01_ConditionCodeQualifier]
      ,[2300P_HI23-02_ConditionCode ]
      ,[2300P_HI24-01_ConditionCodeQualifier]
      ,[2300P_HI24-02_ConditionCode ]
      ,[2300P_REF01_FileInformation2]
      ,[2300P_REF01_FileInformation3]
      ,[2300P_REF01_FileInformation4]
      ,[2300P_REF01_FileInformation5]
      ,[2300P_REF01_FileInformation6]
      ,[2300P_REF01_FileInformation7]
      ,[2300P_REF01_FileInformation8]
      ,[2300P_REF01_FileInformation9]
      ,[2300P_REF01_FileInformation10]
      ,[RenderingProviderSpecialty]
	  )
SELECT	distinct
   	CLMHDR.CLM_ID,
	CLMHDR.src_data_key,
	CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END,--CASE WHEN SYSTEM_SOURCE IN ('50','30') THEN '' ELSE SYSTEM_SOURCE END,-- SourceDesc,
	GETDATE(), -- CreateDate
		--CASE WHEN CLMHDR.src_data_key IN ('50','30') AND @LOBCODE <> 'C54581391' THEN CAST(CLMHDR.src_data_key AS VARCHAR) + CLMHDR.CLM_ID
  --    		 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE <> 'C54581391' AND ENCNTR_SRC_VENDR_NM IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLMHDR.CLM_ID
		--	 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE <> 'C54581391' AND ENCNTR_SRC_VENDR_NM in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLMHDR.CLM_ID	
		--	 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE <> 'C54581391' AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLMHDR.CLM_ID	
		--	 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE <> 'C54581391' AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLMHDR.CLM_ID -- 2300P_CLM01_ClaimNumber
		--	 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'MMAI' AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLMHDR.CLM_ID
		--	 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'CAID' AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLMHDR.CLM_ID
		--	 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'MMAI' AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLMHDR.CLM_ID
		--	 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'CAID' AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLMHDR.CLM_ID
		--	 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE <> 'C54581391' AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '45' + claim_id -- RETM-11
		--	 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'MMAI' AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '451' + CLMHDR.CLM_ID -- RETM-11
		--	 WHEN CLMHDR.src_data_key = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'CAID' AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '452' + CLMHDR.CLM_ID -- RETM-11
	 --   	 WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN '51' + CLAIM_ID
	 --        WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN '52' + CLAIM_ID
	 --    END, -- 2300P_CLM01_ClaimNumber - Align with 100
		CASE WHEN CLMHDR.src_data_key IN ('50','30','210','40')  THEN CAST(CLMHDR.src_data_key AS VARCHAR) + CLMHDR.CLM_ID
    --  		 WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLMHDR.CLM_ID
			 --WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLMHDR.CLM_ID	
			 --WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLMHDR.CLM_ID	
			 --WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLMHDR.CLM_ID -- 2300P_CLM01_ClaimNumber
			 --WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLMHDR.CLM_ID
			 --WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLMHDR.CLM_ID
			 --WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLMHDR.CLM_ID
			 --WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLMHDR.CLM_ID
			 --WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '45' + CLMHDR.CLM_ID -- RETM-11
			 --WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '451' + CLMHDR.CLM_ID -- RETM-11
			 --WHEN CLMHDR.src_data_key in ('140','142','144')   AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '452' + CLMHDR.CLM_ID -- RETM-11
	    	 --WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN '51' + CLAIM_ID
	      --   WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN '52' + CLAIM_ID
	     END, 
		CLMHDR.TOTL_BILLD_AMT,					-- 2300P_CLM02_TotalClaimCharge
		ISNULL(CLMDTL.POS_CD,''), --Aaron POS,							-- 2300P_CLM05-01_PlaceOfService
		'',								-- 2300P_CLM05-02_BillTypeQualifier
		ISNULL(CLMHDR.FREQ_CD,''),						-- 2300P_CLM05-03_ClaimFrequencyCode -Aaron - Should not be NULLS 
		CASE WHEN [PROV_SIG_IND] IS NULL THEN 'Y'
			  ELSE 
        [PROV_SIG_IND] end, --2300P_CLM06_ProviderSignature
		 --[PROV_SIG_IND],			-- 2300P_CLM06_ProviderSignature
		ISNULL([PROV_ASGNMT_STAT_CD],'A'),--[PROV_ASGNMT_STAT_CD],							-- 2300P_CLM07_MedicareAssignment
		ISNULL([BEN_ASGNMT_CERT_CD],'Y'),--[BEN_ASGNMT_CERT_CD],				-- 2300P_CLM08_BenefitAssignmentIndicator
		ISNULL([RELS_OF_INFO_CD],'Y'),--[RELS_OF_INFO_CD],								--[2300P_CLM09_ReleaseOfInformation]
		'',								--[2300P_CLM10_PatientSignatureSource]
		'',								--[2300P_CLM11-01_RelatedCausesCode]
		'',								--[2300P_CLM11-02_RelatedCausesCode]
		'',								--[2300P_CLM11-04_AccidentState]
		'',								--[2300P_CLM11-05_AccidentCountry]
		'',								--[2300P_CLM12_SpecialProgramIndicator]
		'',								--[2300P_CLM20_DelayReason]
		'',								-- 2300P_DTP01_DateTimeQualifier_1
		'',								-- 2300P_DTP02_FormatQualifier_1
		'',								-- 2300P_DTP03_DateTime_1
		'',								-- 2300P_DTP01_DateTimeQualifier_2
		'',								-- 2300P_DTP02_FormatQualifier_2
		'',								-- 2300P_DTP03_DateTime_2
		'',								-- 2300P_DTP01_DateTimeQualifier_3
		'',								-- 2300P_DTP02_FormatQualifier_3
		'',								-- 2300P_DTP03_DateTime_3
		'',								-- 2300P_DTP01_DateTimeQualifier_4]
		'',								-- 2300P_DTP02_FormatQualifier_4
		'',								-- 2300P_DTP03_DateTime_4
		'',								-- 2300P_DTP01_DateTimeQualifier_5
		'',								-- 2300P_DTP02_FormatQualifier_5
		CASE WHEN CLMDTL.POS_CD IN (21,51,61) THEN  REPLACE(ISNULL(CLMHDR.[ADMSN_DT],CLMHDR.SVC_START_DT),'-','') ELSE '' END,							-- 2300P_DTP03_DateTime_5 - Aaron check NULL - Default to DOS POS - 21,51,61 - CLMDTL.POS_CD
		'',								-- 2300P_DTP01_DateTimeQualifier_6
		'',								-- 2300P_DTP02_FormatQualifier_6
		CASE WHEN CLMDTL.POS_CD IN (21,51,61) THEN ISNULL(REPLACE(CLMHDR.[DISCHRG_DT],'-',''),'') ELSE '' END,
		--REPLACE(CASE  WHEN CLMHDR.[DISCHRG_DT] IS NOT NULL THEN CLMHDR.[DISCHRG_DT]
		--			  WHEN CLMHDR.[DISCHRG_DT] IS NULL THEN '' 
		--	  		  ELSE '' END,'-','') ,						-- 2300P_DTP03_DateTime_6 -  Aaron check NULL
		'',								-- 2300P_DTP01_DateTimeQualifier_7
		'',								-- 2300P_DTP02_FormatQualifier_7
		'',								-- 2300P_DTP03_DateTime_7
		'',								-- 2300P_CN101_ContractTypeCode
	    '',                               -- [2300P_CN102_MonetaryAmount]
        '',                               -- [2300P_CN103_ContractPercentage]
        '',                               -- [2300P_CN104_ContractCode]
        '',                               -- [2300P_CN105_TermsDiscountPercent]
        '',                               -- [2300P_CN106_ContractVersionIdentifier]
        '',                               -- [2300P_AMT01_AmountQualifier]
        '',                               -- [2300P_AMT02_PatientAmountPaid]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_1]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_1]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_2]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_2]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_3]
		/*CASE 
		     WHEN PAYER_CLAIM_CNTRL_NUM = '' OR PAYER_CLAIM_CNTRL_NUM IS NULL THEN ''
			 WHEN SOURCEDATAKEY IN ('50','30') AND @LOBCODE <> 'C54581391' THEN CAST(SOURCEDATAKEY AS VARCHAR) + PAYER_CLAIM_CNTRL_NUM
      		 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + PAYER_CLAIM_CNTRL_NUM
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + PAYER_CLAIM_CNTRL_NUM	
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + PAYER_CLAIM_CNTRL_NUM	
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + PAYER_CLAIM_CNTRL_NUM -- 2300P_CLM01_ClaimNumber
	    	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'MMAI' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + PAYER_CLAIM_CNTRL_NUM
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'CAID' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + PAYER_CLAIM_CNTRL_NUM
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'MMAI' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + PAYER_CLAIM_CNTRL_NUM
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'CAID' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + PAYER_CLAIM_CNTRL_NUM
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in  ('EDPS-EyeMed') THEN '45' + claim_id -- RETM-11
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'MMAI' AND SYSTEM_SOURCE in  ('EDPS-EyeMed') THEN '451' + claim_id -- RETM-11
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'CAID' AND SYSTEM_SOURCE in  ('EDPS-EyeMed') THEN '452' + claim_id -- RETM-11
			 WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN '51' + PAYER_CLAIM_CNTRL_NUM
	         WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN '52' + PAYER_CLAIM_CNTRL_NUM
	     END,                             -- [2300P_REF02_ClaimReferenceNumber_3]
       */
	   	CASE 
			 WHEN CLMHDR.PREV_CLM_ID IS NULL OR CLMHDR.PREV_CLM_ID = '' THEN ''
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key IN ('50','30','210','40') THEN CAST(CLMHDR.src_data_key AS VARCHAR) + CLMHDR.PREV_CLM_ID
    --  		 WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLMHDR.PREV_CLM_ID
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLMHDR.PREV_CLM_ID
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLMHDR.PREV_CLM_ID
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLMHDR.PREV_CLM_ID -- 2300P_CLM01_ClaimNumber
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLMHDR.PREV_CLM_ID
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLMHDR.PREV_CLM_ID
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLMHDR.PREV_CLM_ID
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLMHDR.PREV_CLM_ID
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '45' + CLMHDR.PREV_CLM_ID -- RETM-11
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '451' + CLMHDR.PREV_CLM_ID -- RETM-11
			 --WHEN CLMHDR.FREQ_CD IN ('7','8') AND CLMHDR.src_data_key in ('140','142','144')   AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '452' + CLMHDR.PREV_CLM_ID -- RETM-11
	    	 --WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN '51' + CLAIM_ID
	      --   WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN '52' + CLAIM_ID
	     END, 
	    '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_4]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_4]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_5]
        CLMHDR.[PATNT_CTL_NUM],                -- [2300P_REF02_ClaimReferenceNumber_5]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_6]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_6]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_7]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_7]
        '',                               -- [2300P_REF01_ClaimReferenceNumberQualifier_8]
        '',                               -- [2300P_REF02_ClaimReferenceNumber_8]
        '',                               -- [2300P_NTE01_ClaimNoteType]
        '',                               -- [2300P_NTE02_ClaimNote]
        '',                               -- [20P_Ambulance_Transport_Count]
        '',                               -- [2300P_CR101_AmbPatientWeightQualifier]
        '',                               -- [2300P_CR102_AmbulancePatientWeight]
        '',                               -- [2300P_CR104_AmbulanceTransportReason]
        '',                               -- [2300P_CR105_AmbulanceMeasure]
        '',                               -- [2300P_CR106_AmbulanceDistance]
        '',                               -- [2300P_CR109_AmbulanceRoundTripDesc]
        '',                               -- [2300P_CR110_StretcherPurposeDescription]
        '',                               -- [2300P_CRC01_ServiceCertificationCategory]
        '',                               -- [2300P_CRC02_ServiceCertificationIndicator]
        '',                               -- [2300P_CRC03_ConditionIndicatorCode]
        '',                               -- [2300P_CRC04_ConditionIndicatorCode]
        '',                               -- [2300P_CRC05_ConditionIndicatorCode]
        '',     	                      -- [2300P_CRC06_ConditionIndicatorCode]
        '',                               -- [2300P_CRC07_ConditionIndicatorCode]
		'',
        '',--CASE WHEN [DIAGS_TY_CD] = 'P' AND DIAGS_SEQ = '1' THEN [ICD_DIAGS_CD] END,                               -- [2300P_HI01-01_DXType_1]
       -- '', --INST_PRINCIPAL_DIAG_CD,                       -- [2300P_HI01-02_DXCode_1]
       '',-- 'ABF', -- DIAG_CD_QUAL2,                               -- [2300P_HI02-01_DXType_1]
       '',-- CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '2' THEN [ICD_DIAGS_CD] END,                            -- [2300P_HI02-02_DXCode_1]
        '',--'ABF', ----DIAG_CD_QUAL3,                               -- [2300P_HI03-01_DXType_1]
        '',--CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '3' THEN [ICD_DIAGS_CD] END,                               -- [2300P_HI03-02_DXCode_1]
        '',--'ABF', ----DIAG_CD_QUAL4,                               -- [2300P_HI04-01_DXType_1]
        '',--CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '4' THEN [ICD_DIAGS_CD] END,                               -- [2300P_HI04-02_DXCode_1]
        '',--'ABF', --DIAG_CD_QUAL5,                               -- [2300P_HI05-01_DXType_1]
        '',--CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '5' THEN [ICD_DIAGS_CD] END ,                               -- [2300P_HI05-02_DXCode_1]
        '',--'ABF', --DIAG_CD_QUAL6,                               -- [2300P_HI06-01_DXType_1]
        '',--CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '6' THEN [ICD_DIAGS_CD] END,                               -- [2300P_HI06-02_DXCode_1]
        '',--'ABF', --DIAG_CD_QUAL7,                               -- [2300P_HI07-01_DXType_1]
        '',--CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '7' THEN [ICD_DIAGS_CD] END ,                               -- [2300P_HI07-02_DXCode_1]
        '',--'ABF',--DIAG_CD_QUAL8,                               -- [2300P_HI08-01_DXType_1]
        '',--CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '8' THEN [ICD_DIAGS_CD] END ,                               -- [2300P_HI08-02_DXCode_1]
        '',--'ABF',--DIAG_CD_QUAL9,                               -- [2300P_HI09-01_DXType_1]
        '',--CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '9' THEN [ICD_DIAGS_CD] END,                               -- [2300P_HI09-02_DXCode_1]
       '',-- 'ABF', --DIAG_CD_QUAL10,                               -- [2300P_HI10-01_DXType_1]
       '',-- CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '10' THEN [ICD_DIAGS_CD] END,                               -- [2300P_HI10-02_DXCode_1]
       '',-- 'ABF', --DIAG_CD_QUAL11,                               -- [2300P_HI11-01_DXType_1]
       '',-- CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '11' THEN [ICD_DIAGS_CD] END,                               -- [2300P_HI11-02_DXCode_1]
        '',--'ABF', --DIAG_CD_QUAL12,                               -- [2300P_HI12-01_DXType_1]
       '',-- CASE WHEN [DIAGS_TY_CD] = 'S' AND DIAGS_SEQ = '12' THEN [ICD_DIAGS_CD] END,                               -- [2300P_HI12-02_DXCode_1]
        '',                               -- [2310AP_NM101_ProviderRole]
        '',                               -- [2310AP_NM102_PersonIndicator]
		'',
		--CASE WHEN CLMHDR.SRC_DATA_KEY <> '40' THEN  COALESCE(REFPROV.[LAST_NM],REFRG_PROV_LAST_ORG_NM)
		--                                  ELSE COALESCE(REFPROV40.[LAST_NM],REFRG_PROV_LAST_ORG_NM) 
		--								  END,
        --[REFRG_PROV_LAST_ORG_NM],                               -- [2310AP_NM103_LastName]
        --CASE WHEN CLMHDR.SRC_DATA_KEY <>'40' THEN  COALESCE(REFPROV.[FRST_NM],[REFRG_PROV_FRST_NM])
		      --                          ELSE COALESCE(REFPROV40.[FRST_NM],[REFRG_PROV_FRST_NM]) END,
	    '',                               -- [2310AP_NM104_FirstName]
        '',--REF_PROV_MID_INIT,                               -- [2310AP_NM105_MiddleName]
        '', --REF_PROV_SFX,                               -- [2310AP_NM107_Suffix]
        '',                               -- [2310AP_NM108_ProviderIdentifierQualifer]
        CLMHDR.[REFRG_PROV_NPI],                               -- [2310AP_NM109_ProviderIdentifier]
        '',                               -- [2310AP_REF01_ProviderIdentifierQualifer]
        [REFRG_PROV_SEC_CD],                               -- [2310AP_REF02_ProviderIdentifier]
        '',                               -- [2310AP_REF01_ProviderIdentifierQualifer_02]
        [REFRG_PROV_SEC_ID],                               -- [2310AP_REF02_ProviderIdentifier_02]
        '',                               -- [2310BP_NM101_ProviderRole]
        '',                               -- [2310BP_NM102_PersonIndicator]
		--COALESCE(RENDPROV.[LAST_NM],[RNDRG_PROV_FRST_NM])
    --    CASE WHEN CLMHDR.SRC_DATA_KEY <>'40' AND [RNDRG_PROV_FRST_NM] IS NULL AND RENDPROV.[LAST_NM] <> '' THEN RENDPROV.[LAST_NM] 
		  --   WHEN CLMHDR.SRC_DATA_KEY <>'40' AND [RNDRG_PROV_FRST_NM] IS NULL AND [RNDRG_PROV_LAST_ORG_NM] IS NULL THEN RENDPROV.[PROV_NM]	
			 --WHEN CLMHDR.SRC_DATA_KEY ='40' AND [RNDRG_PROV_FRST_NM] IS NULL AND RENDPROV40.[LAST_NM] <> '' THEN RENDPROV40.[LAST_NM] 
		  --   WHEN CLMHDR.SRC_DATA_KEY ='40' AND [RNDRG_PROV_FRST_NM] IS NULL AND [RNDRG_PROV_LAST_ORG_NM] IS NULL THEN RENDPROV40.[PROV_NM]	
				--ELSE [RNDRG_PROV_LAST_ORG_NM]  END,   --    [2310BP_NM103_LastName]
        '',
		'',
        --CASE WHEN CLMHDR.SRC_DATA_KEY <>'40'  THEN COALESCE(RENDPROV.[FRST_NM],[RNDRG_PROV_FRST_NM])
		      --ELSE COALESCE(RENDPROV40.[FRST_NM],[RNDRG_PROV_FRST_NM]) END,                               -- [2310BP_NM104_FirstName]
		'',--RENDERING_PROV_MID_INIT,                               -- [2310BP_NM105_MiddleName]
        '',--RENDERING_PROV_SFX,                               -- [2310BP_NM107_Suffix]
        '',                               -- [2310BP_NM108_ProviderIdentifierQualifer]
        '', --RENDPROV.[PROV_NPI],--CLMHDR.[RNDRG_PROV_NPI]),                               -- [2310BP_NM109_ProviderIdentifier]
        '',                               -- [2310BP_PRV01_ProviderCode]
        '',                               -- [2310BP_PRV02_ProviderCodeQualifer]
        [RNDRG_PROV_TAXNMY_CD],                               -- [2310BP_PRV03_ProviderTaxonomy]
        '',                               -- [2310BP_REF01_ProviderIdentifierQualifer_1]
        [RNDRG_PROV_SEC_CD],                               -- [2310BP_REF02_ProviderIdentifier_1]
        '',                               -- [2310BP_REF01_ProviderIdentifierQualifer_2]
        '',                               -- [2310BP_REF02_ProviderIdentifier_2]
        '',                               -- [20P_RenderingProviderAddress1]
        '',                               -- [20P_RenderingProviderAddress2]
        '',                               -- [20P_RenderingProviderCity]
        '',                               -- [20P_RenderingProviderState]
        '',                               -- [20P_RenderingProviderZip]
        '',                               -- [2310CP_NM101_ProviderRole]
        '',                               -- [2310CP_NM102_PersonIndicator]
        '',                               -- [2310CP_NM103_LastName]
        '',                               -- [2310CP_NM108_ProviderIdentifierQualifer]
        '',                               -- [2310CP_NM109_ProviderIdentifier]
        '',                               -- [2310CP_N301_AddressLine1]
        '',                               -- [2310CP_N302_AddressLine2]
        '',                               -- [2310CP_N401_City]
        '',                               -- [2310CP_N402_State]
        '',                               -- [2310CP_N403_PostalCode]
        '',                               -- [2310CP_N404_Country]
        '',                               -- [2310CP_REF01_ProviderIdentifierQualifer]
        '',                               -- [2310CP_REF02_ProviderIdentifier]
        '',                               -- [2310DP_NM101_ProviderRole]
        '',                               -- [2310DP_NM102_PersonIndicator]
        '',                               -- [2310DP_NM103_LastName]
        '',                               -- [2310DP_NM104_FirstName]
        '',                               -- [2310DP_NM105_MiddleName]
        '',                               -- [2310DP_NM107_Suffix]
        '',                               -- [2310DP_NM108_ProviderIdentifierQualifer]
        '',                               -- [2310DP_NM109_ProviderIdentifier]
        '',                               -- [2310DP_REF01_ProviderIdentifierQualifer]
        '',                               -- [2310DP_REF02_ProviderIdentifier]
        '',                               -- [2310EP_NM101_ProviderRole]
        '',                               -- [2310EP_NM102_PersonIndicator]
        AMB.MBR_PICK_UP_ADDR_TXT as TRANS_PICKUP_ADDR1,                               -- [2310EP_N301_AddressLine1]
        '' as [2310EP_N302_AddressLine2],
        [MBR_PICK_UP_CITY_NM] as TRANS_PICKUP_CITY,                               -- [2310EP_N401_City]
        [MBR_PICK_UP_ST_CD] as TRANS_PICKUP_STATE,                               -- [2310EP_N402_State]
        [MBR_PICK_UP_ZIP_CD] as TRANS_PICKUP_ZIP_TRANS_PICKUP_ZIP4,             -- [2310EP_N403_PostalCode]
        '',                               -- [2310EP_N404_Country]
        '',                               -- [2310EP_REF01_ProviderIdentifierQualifer]
        '',                               -- [2310EP_REF02_ProviderIdentifier]
        '',                               -- [2310FP_NM101_ProviderRole]
        '',                               -- [2310FP_NM102_PersonIndicator]
        '',                               -- [2310FP_NM103_ORG_LastName]
       [MBR_DROP_OFF_ADDR_TXT] as TRANS_DROPOFF_ADDR1,                               -- [2310FP_N301_AddressLine1]
        '',                               -- [2310FP_N302_AddressLine2]
       [MBR_DROP_OFF_CITY_NM] as TRANS_DROPOFF_CITY,                               -- [2310FP_N401_City]
       [MBR_DROP_OFF_ST_CD] as TRANS_DROPOFF_STATE,                               -- [2310FP_N402_State]
       [MBR_DROP_OFF_ZIP_CD] as TRANS_DROPOFF_ZIP_TRANS_DROPOFF_ZIP4,           -- [2310FP_N403_PostalCode]
        '',                               -- [2310FP_N404_Country]
        '',                               -- [2310FP_REF01_ProviderIdentifierQualifer]
        '',                               -- [2310FP_REF02_ProviderIdentifier]
        '',                               -- [2300P_PWK01_AttachmentReportType]
        '',                               -- [2300P_PWK02_AttachmentTransmissionCode]
        '',                               -- [2300P_PWK06_AttachmentControlNumber]
        '',                               -- [2300P_REF01_InvestigationalDeviceExemptionNumber_Qualifier]
        '',                               -- [2300P_REF02_InvestigationalDeviceExemptionNumber]
        '',                               -- [2300P_REF01_ServiceAuthorizationExceptionCode_Qualifier]
        '',                               -- [2300P_REF02_ServiceAuthorizationExceptionCode]
        '',                               -- [2300P_REF01_MammographyCertificationNumber_Qualifier]
        '',                               -- [2300P_REF01_MammographyCertificationNumber]
        '',                               -- [2300P_CR208_PatientConditionCode]
        '',                               -- [2300P_CR210_PatientDescription]
        '',                               -- [2300P_CR211_PatientDescription]
        '',                               -- [2300P_HI101-2_AnesthesiaRelatedSurgicalProcedure]
        '',                               -- [2300P_HI102-2_AnesthesiaRelatedSurgicalProcedure]
        '',                               -- [2300P_DTP01_DateTimeQualifier_7_02]
        '',                               -- [2300P_DTP02_FormatQualifier_7_02]
        '',                               -- [2300P_DTP03_DateTime_7_02]
        '',                               -- [2300P_DTP01_DateTimeQualifier_8]
        '',                               -- [2300P_DTP02_FormatQualifier_8]
        '',                               -- [2300P_DTP03_DateTime_8]
        '',                               -- [2300P_DTP01_DateTimeQualifier_9]
        '',                               -- [2300P_DTP02_FormatQualifier_9]
        '',                               -- [2300P_DTP03_DateTime_9]
        '',                               -- [2300P_DTP01_DateTimeQualifier_10]
        '',                               -- [2300P_DTP02_FormatQualifier_10]
        '',                               -- [2300P_DTP03_DateTime_10]
        '',                               -- [2300P_DTP01_DateTimeQualifier_11]
        '',                               -- [2300P_DTP02_FormatQualifier_11]
        '',                               -- [2300P_DTP03_DateTime_11]
        '',                               -- [2300P_DTP01_DateTimeQualifier_12]
        '',                               -- [2300P_DTP02_FormatQualifier_12]
        '',                               -- [2300P_DTP03_DateTime_12]
        '',                               -- [2300P_DTP01_DateTimeQualifier_13]
        '',                               -- [2300P_DTP02_FormatQualifier_13]
        '',                               -- [2300P_DTP03_DateTime_13]
        '',                               -- [2300P_DTP01_DateTimeQualifier_14]
        '',                               -- [2300P_DTP02_FormatQualifier_14]
        '',                               -- [2300P_DTP03_DateTime_14]
        '',                               -- [2300P_DTP01_DateTimeQualifier_15]
        '',                               -- [2300P_DTP02_FormatQualifier_15]
        '',                               -- [2300P_DTP03_DateTime_15]
        '',                               -- [2300P_DTP01_DateTimeQualifier_16]
        '',                               -- [2300P_DTP02_FormatQualifier_16]
        '',                               -- [2300P_DTP03_DateTime_16]
        '',                               -- [2300P_HCP01_PricingMethodology]
        '',                               -- [2300P_HCP02_RepricedAllowedAmount]
        '',                               -- [2300P_HCP03_RepricedSavingAmount]
        '',                               -- [2300P_HCP04_RepricingOrganizationIdentifier]
        '',                               -- [2300P_HCP05_RepricingPerDiemAmount]
        '',                               -- [2300P_HCP06_RepricedApprovedAmbulatoryPatientGroupCode]
        '',                               -- [2300P_HCP07_RepricedApprovedAmbulatoryPatientGroupAmount]
        '',                               -- [2300P_HCP13_RejectReasonCode]
        '',                               -- [2300P_HCP14_PolicyComplianceCode]
        '',                               -- [2300P_HCP15_ExceptionCode]
        '',                               -- [2300P_HI01-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI01-02_ConditionCode ]
        '',                               -- [2300P_HI02-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI02-02_ConditionCode ]
        '',                               -- [2300P_HI03-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI03-02_ConditionCode ]
        '',                               -- [2300P_HI04-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI04-02_ConditionCode ]
        '',                               -- [2300P_HI05-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI05-02_ConditionCode ]
        '',                               -- [2300P_HI06-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI06-02_ConditionCode ]
        '',                               -- [2300P_HI07-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI07-02_ConditionCode ]
        '',                               -- [2300P_HI08-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI08-02_ConditionCode ]
        '',                               -- [2300P_HI09-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI09-02_ConditionCode ]
        '',                               -- [2300P_HI10-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI10-02_ConditionCode ]
        '',                               -- [2300P_HI11-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI11-02_ConditionCode ]
        '',                               -- [2300P_HI12-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI12-02_ConditionCode ]
        '',                               -- [2300P_REF01_FileInformation_Qualifier]
        '',                               -- [2300P_REF01_FileInformation]
        '',                               -- [Claim Processor Receiver Date]
        '',                               -- [InNetworkIndicator ]
        '',                               -- [PatientControlNumber]
        '',                               -- [20P-Filler 04]
        '',                               -- [20P-Filler 05]
        '',                               -- [20P-Filler 06]
        '',                               -- [20P-Filler 07]
        '',                               -- [20P-Filler 08]
        '',                               -- [20P-Filler 09]
        '',                               -- [20P-Filler 10]
        '',                               -- [20P-Filler 11]
        '',                               -- [20P-Filler 12]
        '',                               -- [20P-Filler 13]
        '',                               -- [20P-Filler 14]
        '',                               -- [20P-Filler 15]
        '',                               -- [2300P_HI13-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI13-02_ConditionCode ]
        '',                               -- [2300P_HI14-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI14-02_ConditionCode ]
        '',                               -- [2300P_HI15-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI15-02_ConditionCode ]
        '',                               -- [2300P_HI16-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI16-02_ConditionCode ]
        '',                               -- [2300P_HI17-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI17-02_ConditionCode ]
        '',                               -- [2300P_HI18-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI18-02_ConditionCode ]
        '',                               -- [2300P_HI19-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI19-02_ConditionCode ]
        '',                               -- [2300P_HI20-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI20-02_ConditionCode ]
        '',                               -- [2300P_HI21-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI21-02_ConditionCode ]
        '',                               -- [2300P_HI22-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI22-02_ConditionCode ]
        '',                               -- [2300P_HI23-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI23-02_ConditionCode ]
        '',                               -- [2300P_HI24-01_ConditionCodeQualifier]
        '',                               -- [2300P_HI24-02_ConditionCode ]
        '',                               -- [2300P_REF01_FileInformation2]
        '',                               -- [2300P_REF01_FileInformation3]
        '',                               -- [2300P_REF01_FileInformation4]
        '',                               -- [2300P_REF01_FileInformation5]
        '',                               -- [2300P_REF01_FileInformation6]
        '',                               -- [2300P_REF01_FileInformation7]
        '',                               -- [2300P_REF01_FileInformation8]
        '',                               -- [2300P_REF01_FileInformation9]
        '',                               -- [2300P_REF01_FileInformation10]
        ''	                              -- [RenderingProviderSpecialty]
FROM	OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CLMHDR
INNER JOIN EDIFECS.staging.EE_CSV_100P_Rec_Header CSVP ON CLMHDR.CLM_ID = CSVP.ClaimID AND CLMHDR.SRC_DATA_KEY = CSVP.SOURCEDATAKEY
LEFT join OSS.dbo.[SDO_MDQO_MED_CLM_HDR_PRE_ADJUD] PRECLMHDR ON CLMHDR.CLM_ID = PRECLMHDR.CLM_ID AND CLMHDR.SRC_DATA_KEY = PRECLMHDR.SRC_DATA_KEY
LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_PROV_PRE_ADJUD] PRECLMPROV on CLMHDR.CLM_ID = PRECLMPROV.CLM_ID   AND CLMHDR.SRC_DATA_KEY = PRECLMPROV.SRC_DATA_KEY
LEFT JOIN OSS.[dbo].[SDO_MDQO_MED_CLM_AMBLC_INFO] AMB ON CSVP.ClaimID = AMB.CLM_ID AND CLMHDR.SRC_DATA_KEY = AMB.SRC_DATA_KEY
LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_DTL_ADJUD CLMDTL ON CSVP.ClaimID = CLMDTL.CLM_ID AND CLMHDR.SRC_DATA_KEY = CLMDTL.SRC_DATA_KEY AND CLMDTL.CLM_LN_ID = '1';

/********************************************************************************************************************************************************************
  20P Place of Service Code Update 
********************************************************************************************************************************************/

UPDATE EDIFECS.staging.EE_CSV_20P_Rec_Header
SET
[2300P_CLM05-01_PlaceOfService] = POS_CD, 
[2300P_DTP03_DateTime_5] = CASE WHEN CLMDTL.POS_CD IN (21,51,61) THEN  REPLACE(ISNULL([ADMSN_DT],CLMHDR.SVC_START_DT),'-','') ELSE '' END,
[2300P_DTP03_DateTime_6] = CASE WHEN CLMDTL.POS_CD IN (21,51,61) THEN ISNULL(REPLACE([DISCHRG_DT],'-',''),'') ELSE '' END
FROM EDIFECS.staging.EE_CSV_20P_Rec_Header CSVP
LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CLMHDR ON CSVP.ClaimID = CLMHDR.CLM_ID AND CSVP.sourcedatakey = CLMHDR.SRC_DATA_KEY 
LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_DTL_ADJUD CLMDTL ON CSVP.ClaimID = CLMDTL.CLM_ID AND CSVP.sourcedatakey = CLMDTL.SRC_DATA_KEY 
WHERE [2300P_CLM05-01_PlaceOfService] = '' AND POS_CD IS NOT NULL 

/********************************************************************************************************************************************************************
  STARTING PROVIDER DATA UDPATES 
*********************************************************************************************************************************************************************/

IF OBJECT_ID('tempdb.dbo.#TMREFRGPROV') IS NOT NULL
        	DROP TABLE #TMREFRGPROV;

SELECT DISTINCT A.CLM_ID, C.FRST_NM, C.LAST_NM, C.PROV_NM, C.PROV_NPI
INTO #TMREFRGPROV
FROM OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD A
INNER JOIN EDIFECS.staging.EE_CSV_20P_Rec_Header B ON A.CLM_ID = B.ClaimID 
JOIN OSS.staging.CDO_PROV_DEMG C ON A.REFRG_PROV_NPI = C.PROV_NPI AND A.SRC_DATA_KEY = C.SRC_DATA_KEY
WHERE A.SRC_DATA_KEY <> '40'
UNION 
SELECT DISTINCT A.CLM_ID, C.FRST_NM, C.LAST_NM, C.PROV_NM, C.PROV_NPI
FROM OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD A
INNER JOIN EDIFECS.staging.EE_CSV_20P_Rec_Header B ON A.CLM_ID = B.ClaimID 
JOIN OSS.staging.CDO_PROV_DEMG C ON A.REFRG_PROV_ID = C.PROV_ID AND A.SRC_DATA_KEY = C.SRC_DATA_KEY
WHERE A.SRC_DATA_KEY = '40';

IF OBJECT_ID('tempdb.dbo.#TMRENDPROV') IS NOT NULL
        	DROP TABLE #TMRENDPROV;

SELECT DISTINCT A.CLM_ID, C.FRST_NM, C.LAST_NM, C.PROV_NM, C.PROV_NPI
INTO #TMRENDPROV
FROM OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD A
INNER JOIN EDIFECS.staging.EE_CSV_20P_Rec_Header B ON A.CLM_ID = B.ClaimID AND A.SRC_DATA_KEY = B.SOURCEDATAKEY
JOIN OSS.staging.CDO_PROV_DEMG C ON A.RNDRG_PROV_NPI = C.PROV_NPI AND A.SRC_DATA_KEY = C.SRC_DATA_KEY
WHERE A.SRC_DATA_KEY <> '40'
UNION 
SELECT DISTINCT A.CLM_ID, C.FRST_NM, C.LAST_NM, C.PROV_NM, C.PROV_NPI
FROM OSS.[staging].SDO_MDQO_MED_CLM_HDR_ADJUD A
INNER JOIN EDIFECS.staging.EE_CSV_20P_Rec_Header B ON A.CLM_ID = B.ClaimID AND A.SRC_DATA_KEY = B.SOURCEDATAKEY
JOIN OSS.staging.CDO_PROV_DEMG C ON A.RNDRG_PROV_ID = C.PROV_ID AND A.SRC_DATA_KEY = C.SRC_DATA_KEY
WHERE A.SRC_DATA_KEY = '40';

UPDATE CSV20P
SET [2310AP_NM104_FirstName] = REFPROV.FRST_NM,
    [2310AP_NM103_LastName] = REFPROV.LAST_NM,
	[2310AP_NM109_ProviderIdentifier] = CASE WHEN REFPROV.CLM_ID IS NULL THEN '' ELSE REFPROV.PROV_NPI END,
	[2310AP_REF02_ProviderIdentifier]  = CASE WHEN REFPROV.CLM_ID IS NULL THEN '' ELSE [2310AP_REF02_ProviderIdentifier] END,
	[2310AP_REF02_ProviderIdentifier_02] = CASE WHEN REFPROV.CLM_ID IS NULL THEN '' ELSE [2310AP_REF02_ProviderIdentifier] END
FROM EDIFECS.staging.EE_CSV_20P_Rec_Header CSV20P
LEFT JOIN #TMREFRGPROV REFPROV ON CSV20p.ClaimID = REFPROV.CLM_ID; 

UPDATE CSV20P
SET [2310BP_NM104_FirstName] = CASE WHEN RENDPROV.FRST_NM = '' OR RENDPROV.FRST_NM IS NULL THEN '' ELSE RENDPROV.FRST_NM END,
    [2310BP_NM103_LastName]  = CASE WHEN RENDPROV.FRST_NM = '' OR RENDPROV.FRST_NM IS NOT NULL THEN RENDPROV.LAST_NM ELSE RENDPROV.PROV_NM END,
	[2310BP_NM109_ProviderIdentifier] = CASE WHEN RENDPROV.CLM_ID IS NULL THEN '' ELSE RENDPROV.PROV_NPI END
FROM EDIFECS.staging.EE_CSV_20P_Rec_Header CSV20P
LEFT JOIN #TMRENDPROV RENDPROV ON CSV20p.ClaimID = RENDPROV.CLM_ID;


/* Rendering Provider Update when same as Billing Provider */
UPDATE CSV20
SET [2310BP_NM109_ProviderIdentifier] = '',
    [2310BP_NM103_LastName] = '',
	[2310BP_NM104_FirstName]  = '',
	[2310BP_NM105_MiddleName] = '',
	[2310BP_PRV01_ProviderCode] = '',
	[2310BP_PRV03_ProviderTaxonomy] = '',
	[20P_RenderingProviderAddress1] = '',
	[20P_RenderingProviderAddress2] = '',
	[20P_RenderingProviderCity] = '',
	[20P_RenderingProviderState] = '',
	[20P_RenderingProviderZip] = ''
FROM EDIFECS.staging.EE_CSV_20P_Rec_Header CSV20	
JOIN EDIFECS.staging.EE_CSV_100P_Rec_Header CSV100 ON CSV20.ClaimID = CSV100.ClaimID
WHERE CSV20.[2310BP_NM109_ProviderIdentifier] = CSV100.[2010AA_NM109_BillingProviderIdentifier];


/********************************************************************************************************************************************************************
  PIVOT DIAGNOSIS CODES FOR INSERT INTO 20 RECORD
*********************************************************************************************************************************************************************/
IF OBJECT_ID('tempdb.dbo.#TMPDIAGS') IS NOT NULL
        	DROP TABLE #TMPDIAGS;

IF OBJECT_ID('tempdb.dbo.#TMPDIAGSRET') IS NOT NULL
        	DROP TABLE #TMPDIAGSRET;

IF @IsRetraction = 0 
BEGIN 
WITH diags AS (
    SELECT
        CD.CLM_ID
        ,ICD_DIAGS_CD
        ,DX_Label = 
            REPLACE('DX' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY DIAGS_SEQ)) % 12 AS VARCHAR) --end rownumber
            , 'DX0', 'DX12')
    FROM OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CD
	INNER JOIN EDIFECS.staging.EE_CSV_100P_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID 
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CSVP.ClaimID = CDHDR.CLM_ID
    WHERE 1 = 1
    AND CDHDR.CLM_TY = 'PROFESSIONAL' 
    AND CD.DIAGS_SEQ < 13
	)
SELECT
    CLM_ID
   ,pt.[DX1]
   ,pt.[DX2]
   ,pt.[DX3]
   ,pt.[DX4]
   ,pt.[DX5]
   ,pt.[DX6]
   ,pt.[DX7]
   ,pt.[DX8]
   ,pt.[DX9]
   ,pt.[DX10]
   ,pt.[DX11]
   ,pt.[DX12] 
INTO #TMPDIAGS
FROM  DIAGS
PIVOT
(
MIN(ICD_DIAGS_CD)
FOR DIAGS.DX_Label IN ([DX1], [DX2], [DX3], [DX4], [DX5], [DX6], [DX7], [DX8], [DX9], [DX10], [DX11], [DX12])
) AS pt;
END;

IF @IsRetraction = 1 
BEGIN 
WITH diags AS (
    SELECT
        CD.CLM_ID
        ,ICD_DIAGS_CD
        ,DX_Label = 
            REPLACE('DX' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY DIAGS_SEQ)) % 12 AS VARCHAR) --end rownumber
            , 'DX0', 'DX12')
    FROM OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CD
	INNER JOIN EDIFECS.staging.EE_CSV_100P_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID 
	INNER JOIN WIPRO.dbo.Retraction_Input_Interim RII ON RII.CLAIMID = CD.CLM_ID AND RII.DXCode = CD.ICD_DIAGS_CD
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CSVP.ClaimID = CDHDR.CLM_ID
    WHERE 1 = 1
    AND CDHDR.CLM_TY = 'PROFESSIONAL' 
    AND CD.DIAGS_SEQ < 13
	)
SELECT
    CLM_ID
   ,pt.[DX1]
   ,pt.[DX2]
   ,pt.[DX3]
   ,pt.[DX4]
   ,pt.[DX5]
   ,pt.[DX6]
   ,pt.[DX7]
   ,pt.[DX8]
   ,pt.[DX9]
   ,pt.[DX10]
   ,pt.[DX11]
   ,pt.[DX12] 
INTO #TMPDIAGSRET
FROM  DIAGS
PIVOT
(
MIN(ICD_DIAGS_CD)
FOR DIAGS.DX_Label IN ([DX1], [DX2], [DX3], [DX4], [DX5], [DX6], [DX7], [DX8], [DX9], [DX10], [DX11], [DX12])
) AS pt;
END;

IF @IsRetraction = 0
BEGIN 
UPDATE CSV_PROF
SET 
[2300P_HI01-01_DXType_1] = CASE WHEN DX1 IS NOT NULL THEN 'ABK' ELSE '' END,
[2300P_HI01-02_DXCode_1] = CASE WHEN DX1 IS NOT NULL THEN DX1 ELSE '' END,
[2300P_HI02-01_DXType_1] = CASE WHEN DX2 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI02-02_DXCode_1] = CASE WHEN DX2 IS NOT NULL THEN DX2 ELSE '' END,
[2300P_HI03-01_DXType_1] = CASE WHEN DX3 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI03-02_DXCode_1] = CASE WHEN DX3 IS NOT NULL THEN DX3 ELSE '' END,
[2300P_HI04-01_DXType_1] = CASE WHEN DX4 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI04-02_DXCode_1] = CASE WHEN DX4 IS NOT NULL THEN DX4 ELSE '' END,
[2300P_HI05-01_DXType_1] = CASE WHEN DX5 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI05-02_DXCode_1] = CASE WHEN DX5 IS NOT NULL THEN DX5 ELSE '' END,
[2300P_HI06-01_DXType_1] = CASE WHEN DX6 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI06-02_DXCode_1] = CASE WHEN DX6 IS NOT NULL THEN DX6 ELSE '' END,
[2300P_HI07-01_DXType_1] = CASE WHEN DX7 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI07-02_DXCode_1] = CASE WHEN DX7 IS NOT NULL THEN DX7 ELSE '' END,
[2300P_HI08-01_DXType_1] = CASE WHEN DX8 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI08-02_DXCode_1] = CASE WHEN DX8 IS NOT NULL THEN DX8 ELSE '' END,
[2300P_HI09-01_DXType_1] = CASE WHEN DX9 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI09-02_DXCode_1] = CASE WHEN DX9 IS NOT NULL THEN DX9 ELSE '' END,
[2300P_HI10-01_DXType_1] = CASE WHEN DX10 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI10-02_DXCode_1] = CASE WHEN DX10 IS NOT NULL THEN DX10 ELSE '' END,
[2300P_HI11-01_DXType_1] = CASE WHEN DX11 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI11-02_DXCode_1] = CASE WHEN DX11 IS NOT NULL THEN DX11 ELSE '' END,
[2300P_HI12-01_DXType_1] = CASE WHEN DX12 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI12-02_DXCode_1] = CASE WHEN DX12 IS NOT NULL THEN DX12 ELSE '' END
FROM EDIFECS.staging.EE_CSV_20P_Rec_Header CSV_PROF
INNER JOIN #TMPDIAGS TMP ON CSV_PROF.CLAIMID = TMP.CLM_ID
END;

IF @IsRetraction = 1
BEGIN 
UPDATE CSV_PROF
SET 
[2300P_HI01-01_DXType_1] = CASE WHEN DX1 IS NOT NULL THEN 'ABK' ELSE '' END,
[2300P_HI01-02_DXCode_1] = CASE WHEN DX1 IS NOT NULL THEN DX1 ELSE '' END,
[2300P_HI02-01_DXType_1] = CASE WHEN DX2 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI02-02_DXCode_1] = CASE WHEN DX2 IS NOT NULL THEN DX2 ELSE '' END,
[2300P_HI03-01_DXType_1] = CASE WHEN DX3 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI03-02_DXCode_1] = CASE WHEN DX3 IS NOT NULL THEN DX3 ELSE '' END,
[2300P_HI04-01_DXType_1] = CASE WHEN DX4 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI04-02_DXCode_1] = CASE WHEN DX4 IS NOT NULL THEN DX4 ELSE '' END,
[2300P_HI05-01_DXType_1] = CASE WHEN DX5 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI05-02_DXCode_1] = CASE WHEN DX5 IS NOT NULL THEN DX5 ELSE '' END,
[2300P_HI06-01_DXType_1] = CASE WHEN DX6 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI06-02_DXCode_1] = CASE WHEN DX6 IS NOT NULL THEN DX6 ELSE '' END,
[2300P_HI07-01_DXType_1] = CASE WHEN DX7 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI07-02_DXCode_1] = CASE WHEN DX7 IS NOT NULL THEN DX7 ELSE '' END,
[2300P_HI08-01_DXType_1] = CASE WHEN DX8 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI08-02_DXCode_1] = CASE WHEN DX8 IS NOT NULL THEN DX8 ELSE '' END,
[2300P_HI09-01_DXType_1] = CASE WHEN DX9 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI09-02_DXCode_1] = CASE WHEN DX9 IS NOT NULL THEN DX9 ELSE '' END,
[2300P_HI10-01_DXType_1] = CASE WHEN DX10 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI10-02_DXCode_1] = CASE WHEN DX10 IS NOT NULL THEN DX10 ELSE '' END,
[2300P_HI11-01_DXType_1] = CASE WHEN DX11 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI11-02_DXCode_1] = CASE WHEN DX11 IS NOT NULL THEN DX11 ELSE '' END,
[2300P_HI12-01_DXType_1] = CASE WHEN DX12 IS NOT NULL THEN 'ABF' ELSE '' END,
[2300P_HI12-02_DXCode_1] = CASE WHEN DX12 IS NOT NULL THEN DX12 ELSE '' END
FROM EDIFECS.staging.EE_CSV_20P_Rec_Header CSV_PROF
INNER JOIN #TMPDIAGSRET TMP ON CSV_PROF.CLAIMID = TMP.CLM_ID
END;

/*---------------------------------------------------------------------*/
/* POPULATE 310 REC TABLE                                                */
/*---------------------------------------------------------------------*/

 
TRUNCATE TABLE EDIFECS.staging.EE_CSV_310P_Rec_Header;
INSERT INTO EDIFECS.staging.EE_CSV_310P_Rec_Header (
[ClaimID],
[SourceDataKey],
[SourceDesc],
[CreateDate],
[2320_SBR01_PayerResponsibilitySequence],
[2320_SBR02_SubscriberRelationship],
[2320_SBR09_ClaimFilingIndicator],
[2320_AMT02_COBAmount_1],
[2320_OI03_AssignBenefitsIndicator],
[2330A_NM103_LastName],
[2330A_NM104_FirstName],
[2330A_N301_AddressLine1],
[2330A_N302_AddressLine2],
[2330A_N401_City],
[2330A_N402_State],
[2330A_N403_PostalCode],
[2330B_NM103_Name],
[2330B_NM109_OrganizationIdentifier],
[2330B_N301_AddressLine1],
[2330B_N302_AddressLine2],
[2330B_N401_City],
[2330B_N402_State],
[2330B_N403_PostalCode]
)
SELECT 
CLMHDR.[CLM_ID],        -- ClaimID - varchar(20)
CLMHDR.[SRC_DATA_KEY],         -- SourceDataKey - int
CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END,        -- SourceDesc - varchar(60)
GETDATE(), -- CreateDate - datetime
'P',--PAYER_RESP, -- PayerResponsibilityCode
'18',--REL_CD1, --RelationshipCode
'16',--CLM_FIL_INDCD1,
[TOTL_PD_AMT],
'Y',--[BEN_ASGNMT_CERT_CD],
MEM.LAST_NM,
MEM.FRST_NM,
MEM.PHY_SRC_ADDR_LN_1,
MEM.PHY_SRC_ADDR_LN_2, 
MEM.PHY_SRC_CITY,
MEM.PHY_SRC_STE,
MEM.PHY_SRC_ZIP_CD,
'HealthSpring', --OTH_PAYER1_NAME,
[CNTRCT_NUM], --OTH_PAYER1_PLANID,
'530 GREAT CIRCLE', --OTH_PAYER1_ADDRESS1,
'', --OTH_PAYER1_ADDRESS2,
'NASHVILLE', --OTH_PAYER1_CITY,
'TN' , --OTH_PAYER1_STATE,
'372289999'--[OTH_PAYER1_ZIP] + [OTH_PAYER1_ZIP4]
FROM OSS.dbo.[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR
--join OSS.[staging].[SDO_MDQO_MED_CLM_HDR_PRE_ADJUD] PRECLMHDR ON CLMHDR.CLM_ID = PRECLMHDR.CLM_ID
INNER JOIN EDIFECS.staging.EE_CSV_100P_Rec_Header CSVP ON CLMHDR.CLM_ID = CSVP.ClaimID
LEFT JOIN OSS.staging.CDO_MBR_DEMG MEM ON CLMHDR.MBR_ID = MEM.MBR_ID AND CLMHDR.SRC_DATA_KEY = MEM.SRC_DATA_KEY;

/* ----------------------------------------------------------------------------------
INSERT RECORDS INTO THE 40P SERVICE LINE RECS
                                                                                   *
-----------------------------------------------------------------------------------*/ 

TRUNCATE TABLE EDIFECS.staging.EE_CSV_40P_Rec_Detail;

INSERT INTO EDIFECS.staging.EE_CSV_40P_Rec_Detail
SELECT  DISTINCT 
				   CLMDTL.[CLM_ID]
				  ,CLMDTL.SRC_DATA_KEY
				  ,CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END AS SourceDesc --Aaron update mapping 
				  ,GETDATE() AS CreateDate 
				  ,CLMDTL.[CLM_LN_ID]
				  ,CLMDTL.[CLM_LN_ID]
				  ,'HC' --ISNULL(SVC_TY_CD,'')  AS	[2400P_SV101-01_ServiceCodeType]
				  ,ISNULL(CPT_PROC_CD,'')
				  ,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
							CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_1
						WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> ''  and isnull(CPT_MODFR_CD_1,'') = '' and ( isnull(CPT_MODFR_CD_2,'') <> '59' or isnull(CPT_MODFR_CD_3,'') <> '59' or isnull(CPT_MODFR_CD_4,'') <> '59') THEN '59'
						ELSE CPT_MODFR_CD_1 END AS	[2400P_SV101-03_ServiceModifier1]
				  ,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
							CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_2
						WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_2,'') = '' and isnull(CPT_MODFR_CD_1,'') <> ''))
										THEN '59'
						ELSE CPT_MODFR_CD_2 END	AS	[2400P_SV101-04_ServiceModifier2]
				  ,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
							CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_3
						WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_3,'') = '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '')
											THEN '59'
						ELSE CPT_MODFR_CD_3 END AS	[2400P_SV101-05_ServiceModifier3]
				  ,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
							CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_4
						WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_4,'') = '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '' and isnull(CPT_MODFR_CD_3,'') <> '')
											THEN '59'
						WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_4,'') <> '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '' and isnull(CPT_MODFR_CD_3,'') <> '')
											THEN '59'
						ELSE CPT_MODFR_CD_4 END  AS	[2400P_SV101-06_ServiceModifier4]										
				  ,LEFT(CPT_PROC_CD_DESC,100) 
				  ,REQD_AMT
				  --,'Data Gap' as ANES_FLAG --ANES_FLAG (Data Gap)	Aaron FROM WIPRO.[dbo].[ANES_2018]4
				  ,CASE WHEN ANES_CODE IS NOT NULL THEN 'MJ' ELSE 'UN' END  --ANES_FLAG 
				  ,[SVC_UNITS]	
				  ,[POS_CD]	
				  ,ISNULL([DIAGS_SEQ],'') as PRIMDIAG-- 
				  ,'' 	AS	[2400P_SV107-02_DiagnosisPointer]	--Subhash Acharya  [DIAGS_SEQ] = 2 -  Flatten and use sequence from the table 
				  ,'' AS	[2400P_SV107-03_DiagnosisPointer]	--Subhash Acharya DIAGS_SEQ = 3 
				  ,'' AS  	[2400P_SV107-04_DiagnosisPointer] -- DIAGS_SEQ = 4
				  ,CASE WHEN EMER_CLM_IND = 'Y' THEN  EMER_CLM_IND ELSE '' END as EMER_FLAG	
				  ,''											AS	[2400P_SV111_EPSDTService]
				  ,''											AS	[2400P_SV112_FamilyPlanningService]
				  ,'' as COPAY_EX_FLAG -- Possibly ''
				  ,'HC' as SERV_ID_QUAL
				  ,CPT_PROC_CD
				  ,CASE WHEN ANES_CODE IS NOT NULL THEN 'MJ' ELSE 'UN' END --ANES_FLAG
			,''											AS	[2400P_SV503_LengthMedicalNecessity]
			,''											AS	[2400P_SV504_RentalPrice]
			,''											AS	[2400P_SV505_PurchasePrice]
			,''											AS	[2400P_SV506_RentalUnitPrice]
			,''											AS	[2400P_PWK01_ReportType]
			,''											AS	[2400P_PWK02_TransmissionCode]
			,''											AS	[2400P_PWK05_CodeQualifier]
			,''											AS	[2400P_PWK06_ControlNumber]
			,''											AS	[2400P_CR101_PatientWeightQualifier]
			,''											AS	[2400P_CR102_PatientWeight]
			,''											AS	[2400P_CR104_TransportReason]
			,''											AS	[2400P_CR105_ServiceMeasureCode]
			,''											AS	[2400P_CR106_Distance]
			,''											AS	[2400P_CR109_RoundTripDesc]
			,''											AS	[2400P_CR110_StretcherPurpose]
			,''											AS	[2400P_DTP01_DateTimeQualifier_1]
			,''											AS	[2400P_DTP02_FormatQualifier_1]
			, CASE WHEN [SVC_LN_START_DT] = [SVC_LN_END_DT] THEN REPLACE([SVC_LN_END_DT],'-','')
				   WHEN ISNULL([SVC_LN_END_DT],'') = '' THEN REPLACE([SVC_LN_START_DT],'-','')
				ELSE CONCAT(REPLACE([SVC_LN_START_DT],'-',''),'-',REPLACE([SVC_LN_END_DT],'-','')) END AS	[2400P_DTP03_Date_1]
			,''											AS	[2400P_DTP01_DateTimeQualifier_2]
			,''											AS	[2400P_DTP02_FormatQualifier-2]
			,''											AS	[2400P_DTP03_Date-2]
			,''											AS	[2400P_DTP01_DateTimeQualifier_3]
			,''											AS	[2400P_DTP02_FormatQualifier_3]
			,''											AS	[2400P_DTP03_Date_3]
			,''											AS	[2400P_DTP01_DateTimeQualifier_4]
			,''											AS	[2400P_DTP02_FormatQualifier-4]
			,''											AS	[2400P_DTP03_Date-4]
			,''											AS	[2400P_DTP01_DateTimeQualifier_5]
			,''											AS	[2400P_DTP02_FormatQualifier_5]
			,''											AS	[2400P_DTP03_Date_5]
			,''											AS	[2400P_DTP01_DateTimeQualifier_6]
			,''											AS	[2400P_DTP02_FormatQualifier-6]
			,''											AS	[2400P_DTP03_Date-6]
			,''											AS	[2400P_DTP01_DateTimeQualifier_7]
			,''											AS	[2400P_DTP02_FormatQualifier_7]
			,''											AS	[2400P_DTP03_Date_7]
			,''											AS	[2400P_DTP01_DateTimeQualifier_8]
			,''											AS	[2400P_DTP02_FormatQualifier-8]
			,''											AS	[2400P_DTP03_Date-8]
			,''											AS	[2400P_DTP01_DateTimeQualifier_9]
			,''											AS	[2400P_DTP02_FormatQualifier-9]
			,''											AS	[2400P_DTP03_Date-9]
			,''											AS	[2400P_DTP01_DateTimeQualifier_10]
			,''											AS	[2400P_DTP02_FormatQualifier_10]
			,''											AS	[2400P_DTP03_Date_10]
			,''											AS	[2400P_DTP01_DateTimeQualifier_11]
			,''											AS	[2400P_DTP02_FormatQualifier-11]
			,''											AS	[2400P_DTP03_Date-11]
			,''											AS	[2400P_QTY01_QuantityQuakiferID_1]
			,''											AS	[2400P_QTY02_Quantity_1]
			,''											AS	[2400P_QTY01_QuantityQualiferID_2]
			,''											AS	[2400P_QTY02_Quantity_2]
			,''											AS	[2400P_MEA01_MeasurementIdentifierCode_1]
			,''											AS	[2400P_MEA02_MeasurementQualifier_1]
			,''											AS	[2400P_MEA03_MeasurementValue_1]
			,''											AS	[2400P_MEA01_MeasurementIdentifierCode_2]
			,''											AS	[2400P_MEA02_MeasurementQualifier_2]
			,''											AS	[2400P_MEA03_MeasurementValue_2]
			,''											AS	[2400P_MEA01_MeasurementIdentifierCode_3]
			,''											AS	[2400P_MEA02_MeasurementQualifier_3]
			,''											AS	[2400P_MEA03_MeasurementValue_3]
			,''											AS	[2400P_MEA01_MeasurementIdentifierCode_4]
			,''											AS	[2400P_MEA02_MeasurementQualifier_4]
			,''											AS	[2400P_MEA03_MeasurementValue_4]
			,''											AS	[2400P_MEA01_MeasurementIdentifierCode_5]
			,''											AS	[2400P_MEA02_MeasurementQualifier_5]
			,''											AS	[2400P_MEA03_MeasurementValue_5]
			,CASE [CAPITATED_LN_FLG] WHEN 'Y' THEN  '05' ELSE ' ' END as Contract_Type
			,''											AS	[2400P_CN102_ContractAmount]
			,''											AS	[2400P_CN103_ContractPercentage]
			,''											AS  Contract_Code 
			,''											AS	[2400P_CN105_TermsDiscountPercent]
			,''											AS	[2400P_CN106_ContractVersionIdentifier]
			,''											AS	[2400P_REF01_ServiceRefNumberQualifier_1]
			,''											AS	[2400P_REF02_ServiceRefNumber_1]
			,''											AS	[2400P_REF01_ServiceRefNumberQualifier_2]
			,''											AS	[2400P_REF02_ServiceRefNumber_2]
			,''											AS	[2400P_REF01_ServiceRefNumberQualifier_3]
			,''											AS	[2400P_REF02_ServiceRefNumber_3]
			,''											AS	[2400P_REF01_ServiceRefNumberQualifier_4]
			,CASE WHEN LEN(CLMDTL.[CLM_LN_ID]) = 1 THEN '000' + CLMDTL.[CLM_LN_ID]
				  WHEN LEN(CLMDTL.[CLM_LN_ID]) = 2 THEN '00' + CLMDTL.[CLM_LN_ID]
				  WHEN LEN(CLMDTL.[CLM_LN_ID]) = 3 THEN '0' + CLMDTL.[CLM_LN_ID]
			END
			,''											AS	[2400P_REF01_ServiceRefNumberQualifier_5]
			,''											AS	[2400P_REF02_ServiceRefNumber_5]
			,''											AS	[2400P_REF01_ServiceRefNumberQualifier_6]
			,''											AS	[2400P_REF02_ServiceRefNumber_6]
			,''											AS	[2400P_REF01_ServiceRefNumberQualifier_7]
			,''											AS	[2400P_REF02_ServiceRefNumber_7]
			,''											AS	[2400P_REF01_ServiceRefNumberQualifier_8]
			,''											AS	[2400P_REF02_ServiceRefNumber_8]
			,''											AS	[2400P_REF04-01_AssignedByQualifier_8]
			,''											AS	[2400P_REF04-02_AssignedBy_8]
			,''											AS	[2400P_REF01_ServiceRefNumberQualifier_9]
			,''											AS	[2400P_REF02_ServiceRefNumber_9]
			,''											AS	[2400P_REF04-01_AssignedByQualifier_9]
			,''											AS	[2400P_REF04-02_AssignedBy_9]
			,''											AS	[2400P_AMT01_AmountQualfier_1]
			,''											AS	[2400P_AMT02_Amount_1]
			,''											AS	[2400P_AMT01_AmountQualfier_2]
			,''											AS	[2400P_AMT02_Amount_2]
			,''											AS	[2400P_K301_FixedFormatInformation_1]
			,''											AS	[2400P_K301_FixedFormatInformation_2]
			,''											AS	[2400P_K301_FixedFormatInformation_3]
			,''											AS	[2400P_K301_FixedFormatInformation_4]
			,''											AS	[2400P_K301_FixedFormatInformation_5]
			,''											AS	[2400P_K301_FixedFormatInformation_6]
			,''											AS	[2400P_K301_FixedFormatInformation_7]
			,''											AS	[2400P_K301_FixedFormatInformation_8]
			,''											AS	[2400P_K301_FixedFormatInformation_9]
			,''											AS	[2400P_K301_FixedFormatInformation_10]
			,''											AS	[2400P_NTE01_NoteType_1]
			,''											AS	[2400P_NTE02_Note_1]
			,''											AS	[2400P_NTE01_NoteType_2]
			,''											AS	[2400P_NTE02_Note_2]
			,'' 										AS	[2400P_HCP01_PricingMethod]
			,''											AS	[2400P_HCP02_RepricedAllowedAmt]
			,''											AS	[2400P_HCP03_RepricedSavingAmt]
			,''											AS	[2400P_HCP04_RepricingOrdID]
			,''											AS	[2400P_HCP05_PricingRange]
			,''											AS	[2400P_HCP06_APGPricingCode]
			,''											AS	[2400P_HCP07_APGPricingAmt]
			,''											AS	[2400P_HCP09_ServiceType]
			,''											AS	[2400P_HCP10_ApprovedServiceCode]
			,''											AS	[2400P_HCP11_RepricingUnits]
			,''											AS	[2400P_HCP12_RepricingQuantity]
			,''											AS	[2400P_HCP13_RejectReasonCode]
			,''											AS	[2400P_HCP14_PolicyComplianceCode]
			,''											AS	[2400P_HCP15_ExceptionCode]
			,''											AS	[2410P_LIN02_DrugCodeType]
			,''											AS	[2410P_LIN03_NationalDrugCode]
			,''											AS	[2410P_CTP04_Quantity]
			,''											AS	[2410P_CTP05-01_Units]
			,''											AS	[2410P_REF01_ReferenceIDQualifier]
			,''											AS	[2410P_REF02_ReferenceIdentifier]
			,''											AS	[2420GP_NM101_ProviderRole]
			,''											AS	[2420GP_NM102_PersonIndicator]
			,''											AS	[2420GP_N301_AddressLine1]
			,''											AS	[2420GP_N302_AddressLine2]
			,''											AS	[2420GP_N401_City]
			,''											AS	[2420GP_N402_State]
			,''											AS	[2420GP_N403_PostalCode]
			,''											AS	[2420GP_N404_Country]
			,''											AS	[2420HP_NM101_ProviderRole]
			,''											AS	[2420HP_NM102_PersonIndicator]
			,''											AS	[2420HP_NM103_ORG_LastName]
			,''											AS	[2420HP_N301_AddressLine1]
			,''											AS	[2420HP_N302_AddressLine2]
			,''											AS	[2420HP_N401_City]
			,''											AS	[2420HP_N402_State]
			,''											AS	[2420HP_N403_PostalCode]
			,''											AS	[2420HP_N404_Country]
			,''											AS	[2400P_PWK02_DMEAttachmentTransmissionCode]
			,''											AS	[2400P_CR301_CertificationTypeCode]
			,''											AS	[2400P_CR303_DurableMedicalEquipmentDuration]
			,''											AS	[2400P_CRC02_CertificationConditionIndicator]
			,''											AS	[2400P_CRC03_ConditionCode]
			,''											AS	[2400P_CRC04_ConditionCode]
			,''											AS	[2400P_CRC05_ConditionCode]
			,''											AS	[2400P_CRC06_ConditionCode]
			,''											AS	[2400P_CRC07_ConditionCode]
			,''											AS	[2400P_REF01_RepricedLineItemReferenceQualifier]
			,''											AS	[2400P_REF02_RepricedLineItemReferenceNumber]
			,''											AS	[2400P_PS101_PurchasedSerivceProviderIdentifier]
			,''											AS	[2400P_PS102_PurchasedServiceChargeAmount]
			,''											AS	[40P-Filler 01]
			,CASE WHEN CLMDTL.POS_CD = '34' then 'Y' else '' END	AS	[40P-Filler 02] 
			,''											AS	[40P-Filler 03]
			,''											AS	[40P-Filler 04]
			,''											AS	[40P-Filler 05]
			,''											AS	[2420AP_NM101_ProviderRole]
			,''											AS	[2420AP_NM102_PersonIndicator]
			,''											AS	[2420AP_NM103_LastName]
			,''											AS	[2420AP_NM104_FirstName]
			,''											AS	[2420AP_NM105_MiddleName]
			,''											AS	[2420AP_NM107_Suffix]
			,''											AS	[2420AP_NM108_ProviderIdentifierQualifer]
			,''											AS	[2420AP_NM109_ProviderIdentifier]
			,''											AS	[2420AP_PRV03_ProviderTaxonomy]
			,''											AS	[2420AP_REF01_ProviderIdentifierQualifer_1]
			,''											AS	[2420AP_REF02_ProviderIdentifier_1]
			,''											AS	[2420AP_REF01_ProviderIdentifierQualifer_2]
			,''											AS	[2420AP_REF02_ProviderIdentifier_2]
			,''											AS	[2420AP_REF01_ProviderIdentifierQualifer_3]
			,''											AS	[2420AP_REF02_ProviderIdentifier_3]
			,''											AS	[2420BP_NM101_ProviderRole]
			,''											AS	[2420BP_NM102_PersonIndicator]
			,''											AS	[2420BP_NM108_ProviderIdentifierQualifer]
			,''											AS	[2420BP_NM109_ProviderIdentifier]
			,''											AS	[2420BP_REF01_ProviderIdentifierQualifer_1]
			,''											AS	[2420BP_REF02_ProviderIdentifier_1]
			,''											AS	[2420BP_REF01_ProviderIdentifierQualifer_2]
			,''											AS	[2420BP_REF02_ProviderIdentifier_2]
			,''											AS	[2420CP_NM101_ProviderRole]
			,''											AS	[2420CP_NM102_PersonIndicator]
			,''											AS	[2420CP_NM103_LastName]
			,''											AS	[2420CP_NM108_ProviderIdentifierQualifer]
			,''											AS	[2420CP_NM109_ProviderIdentifier]
			,''											AS	[2420CP_N301_AddressLine1]
			,''											AS	[2420CP_N302_AddressLine2]
			,''											AS	[2420CP_N401_City]
			,''											AS	[2420CP_N402_State]
			,''											AS	[2420CP_N403_PostalCode]
			,''											AS	[2420CP_N404_Country]
			,''											AS	[2420CP_REF01_ProviderIdentifierQualifer_1]
			,''											AS	[2420CP_REF02_ProviderIdentifier_1]
			,''											AS	[2420CP_REF01_ProviderIdentifierQualifer_2]
			,''											AS	[2420CP_REF02_ProviderIdentifier_2]
			,''											AS	[2420DP_NM101_ProviderRole]
			,''											AS	[2420DP_NM102_PersonIndicator]
			,''											AS	[2420DP_NM103_LastName]
			,''											AS	[2420DP_NM104_FirstName]
			,''											AS	[2420DP_NM105_MiddleName]
			,''											AS	[2420DP_NM107_Suffix]
			,''											AS	[2420DP_NM108_ProviderIdentifierQualifer]
			,''											AS	[2420DP_NM109_ProviderIdentifier]
			,''											AS	[2420DP_REF01_ProviderIdentifierQualifer_1]
			,''											AS	[2420DP_REF02_ProviderIdentifier_1]
			,''											AS	[2420DP_REF01_ProviderIdentifierQualifer_2]
			,''											AS	[2420DP_REF02_ProviderIdentifier_2]
			,''											AS	[2420DP_REF01_ProviderIdentifierQualifer_3]
			,''											AS	[2420DP_REF02_ProviderIdentifier_3]
			,''											AS	[2420EP_NM101_ProviderRole]
			,''											AS	[2420EP_NM102_PersonIndicator]
			,''											AS	[2420EP_NM103_LastName]
			,''											AS	[2420EP_NM104_FirstName]
			,''											AS	[2420EP_NM105_MiddleName]
			,''											AS	[2420EP_NM107_Suffix]
			,''											AS	[2420EP_NM108_ProviderIdentifierQualifer]
			,''											AS	[2420EP_NM109_ProviderIdentifier]
			,''											AS	[2420EP_N301_AddressLine1]
			,''											AS	[2420EP_N302_AddressLine2]
			,''											AS	[2420EP_N401_City]
			,''											AS	[2420EP_N402_State]
			,''											AS	[2420EP_N403_PostalCode]
			,''											AS	[2420EP_N404_Country]
			,''											AS	[2420EP_REF01_ProviderIdentifierQualifer_1]
			,''											AS	[2420EP_REF02_ProviderIdentifier_1]
			,''											AS	[2420EP_REF01_ProviderIdentifierQualifer_2]
			,''											AS	[2420EP_REF02_ProviderIdentifier_2]
			,''											AS	[2420FP_NM101_ProviderRole]
			,''											AS	[2420FP_NM102_PersonIndicator]
			,''											AS	[2420FP_NM103_LastName]
			,''											AS	[2420FP_NM104_FirstName]
			,''											AS	[2420FP_NM105_MiddleName]
			,''											AS	[2420FP_NM107_Suffix]
			,''											AS	[2420FP_NM108_ProviderIdentifierQualifer]
			,''											AS	[2420FP_NM109_ProviderIdentifier]
			,''											AS	[2420FP_REF01_ProviderIdentifierQualifer_1]
			,''											AS	[2420FP_REF02_ProviderIdentifier_1]
			,''											AS	[2420FP_REF01_ProviderIdentifierQualifer_2]
			,''											AS	[2420FP_REF02_ProviderIdentifier_2]
			,''											AS	[InNetworkIndicator] 
			,''											AS	[ServiceLineContractID]
			,''											AS	[TPLPaidAmount]
			,''											AS	[40P-Filler 9]
			,''											AS	[40P-Filler 10]
			,''											AS	[40P-Filler 11]
			,''											AS	[40P-Filler 12]
			,''											AS	[40P-Filler 13]
			,''											AS	[40P-Filler 14]
			,''											AS	[40P-Filler 15]
			,''											AS	[ServiceHealthPlan]
			,''											AS	[ServiceBenefitPlan]
			,''											AS	[ServiceAdministrativeCounty]
			,''											AS	[ServiceResidenceCounty]
			,''											AS	[ServiceEligibilityCode]
			,''											AS	[ServiceSubProgram1]
			,''											AS	[ServiceSubProgram2]
			,''											AS	[ServiceSubProgram3]
			,''											AS	[ServiceSubProgram4]
			,''											AS	[ServiceArrangementCode]
			,''											AS	[ServiceTribalCode]
			,''											AS	[CategoryOfService] 
			,''											AS	[RenderingProviderSpeciality] 
			,''											AS	[PurchasedIndicator]
			,''											AS	[BH_ESPDTIndicator]
			,''											AS	[MPIServiceLocation]
			,''											AS	[EBPPCode01]
			,''											AS	[EBPPCode02] 
			,''											AS	[EBPPCode03]
			,''											AS	[EBPPCode04]
			,''											AS	[EBPPCode05]
			,''											AS	[Ordering Provider Location Code]
			,''											AS	[40P_MediaType]
			,''											AS	[Beneficiary Cost Sharing Status]
			,''											AS	[Out of Pocket Maximum]
			,''											AS	[Beneficiary Lock-In STATUS]
    FROM [OSS].dbo.[SDO_MDQO_MED_CLM_DTL_ADJUD] CLMDTL
	INNER JOIN EDIFECS.staging.EE_CSV_100P_Rec_Header CSVP ON CLMDTL.CLM_ID = CSVP.ClaimID
	JOIN OSS.dbo.[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR ON CSVP.ClaimID = CLMHDR.CLM_ID
	LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_LN_DIAG_CD_ADJUD] CLMDIAG ON CLMHDR.CLM_ID = CLMDIAG.CLM_ID AND CLMDTL.[CLM_LN_ID] = CLMDIAG.[CLM_LN_ID] AND DIAGS_SEQ = '1'
	LEFT JOIN WIPRO.[dbo].[ANES_2018] CLMANES ON CLMDTL.CPT_PROC_CD = CLMANES.ANES_CODE
	LEFT JOIN WIPRO.dbo.Service_Line_Dup_Processing SLDP ON CLMDTL.CLM_ID = SLDP.claim_id
						   AND CLMDTL.src_data_key = SLDP.sourcedatakey
						   AND SLDP.Is_Resubmission_Eligible = '1'
						   AND SLDP.Has_Been_Resubmitted = '0'
						   AND SLDP.claim_type IN ('PRO', 'DME' ) 
						   AND SLDP.Error_Code = '98325';


/* ----------------------------------------------------------------------------------
          PIVOT ON DIAGNOSIS CODE POPULATION AT SERVICE LINE 
                                                                                   *
-----------------------------------------------------------------------------------*/ 
IF OBJECT_ID('tempdb.dbo.#TMPDIAGP') IS NOT NULL
        	DROP TABLE #TMPDIAGP;

IF OBJECT_ID('tempdb.dbo.#TMPDIAGPRET') IS NOT NULL
        	DROP TABLE #TMPDIAGPRET;

IF @IsRetraction = 0
BEGIN 
WITH diags AS (
    SELECT  
        CLMDIAG.CLM_ID
		,[CLM_LN_ID]
        ,COALESCE(CLMDIAGHDR.DIAGS_SEQ,CLMDIAG.DIAGS_SEQ) AS DIAGS_SEQ
        ,DX_Label = 
            REPLACE('DP' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CLMDIAG.CLM_ID,[CLM_LN_ID] ORDER BY CLMDIAG.DIAGS_SEQ)) % 4 AS VARCHAR) --end rownumber
            , 'DP0', 'DP4')
    FROM OSS.dbo.[SDO_MDQO_CLM_LN_DIAG_CD_ADJUD] CLMDIAG
	INNER JOIN EDIFECS.staging.EE_CSV_100P_Rec_Header CSVP ON CLMDIAG.CLM_ID = CSVP.ClaimID
	JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CLMDIAG.CLM_ID = CDHDR.CLM_ID AND CLMDIAG.SRC_DATA_KEY = CDHDR.SRC_DATA_KEY
	LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CLMDIAGHDR ON CLMDIAG.CLM_ID = CLMDIAGHDR.CLM_ID AND CLMDIAGHDR.SRC_DATA_KEY = CLMDIAG.SRC_DATA_KEY AND CLMDIAG.ICD_DIAGS_CD = CLMDIAGHDR.ICD_DIAGS_CD
    WHERE 1 = 1
    AND CDHDR.CLM_TY = 'PROFESSIONAL' 
	)
SELECT
    CLM_ID,
	[CLM_LN_ID]
   ,pt.[DP1]
   ,pt.[DP2]
   ,pt.[DP3]
   ,pt.[DP4]
INTO #TMPDIAGP
FROM  DIAGS
PIVOT
(
MIN([DIAGS_SEQ])
FOR DIAGS.DX_Label IN ([DP1], [DP2], [DP3], [DP4])
) AS pt;
END;

IF @IsRetraction = 1
BEGIN 
WITH diags AS (
    SELECT  
        CLMDIAG.CLM_ID
		,[CLM_LN_ID]
        ,COALESCE(CLMDIAGHDR.DIAGS_SEQ,CLMDIAG.DIAGS_SEQ) AS DIAGS_SEQ
        ,DX_Label = 
            REPLACE('DP' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CLMDIAG.CLM_ID,[CLM_LN_ID] ORDER BY CLMDIAG.DIAGS_SEQ)) % 4 AS VARCHAR) --end rownumber
            , 'DP0', 'DP4')
    FROM OSS.dbo.[SDO_MDQO_CLM_LN_DIAG_CD_ADJUD] CLMDIAG
	INNER JOIN EDIFECS.staging.EE_CSV_100P_Rec_Header CSVP ON CLMDIAG.CLM_ID = CSVP.ClaimID
	INNER JOIN WIPRO.dbo.Retraction_Input_Interim RII ON CLMDIAG.CLM_ID = RII.CLAIMID AND CLMDIAG.[ICD_DIAGS_CD] = RII.DXCODE
	JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CLMDIAG.CLM_ID = CDHDR.CLM_ID AND CLMDIAG.SRC_DATA_KEY = CDHDR.SRC_DATA_KEY
	LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CLMDIAGHDR ON CLMDIAG.CLM_ID = CLMDIAGHDR.CLM_ID AND CLMDIAGHDR.SRC_DATA_KEY = CLMDIAG.SRC_DATA_KEY AND CLMDIAG.ICD_DIAGS_CD = CLMDIAGHDR.ICD_DIAGS_CD
    WHERE 1 = 1
    AND CDHDR.CLM_TY = 'PROFESSIONAL' 
	)
SELECT
    CLM_ID,
	[CLM_LN_ID]
   ,pt.[DP1]
   ,pt.[DP2]
   ,pt.[DP3]
   ,pt.[DP4]
INTO #TMPDIAGPRET
FROM  DIAGS
PIVOT
(
MIN([DIAGS_SEQ])
FOR DIAGS.DX_Label IN ([DP1], [DP2], [DP3], [DP4])
) AS pt;
END;


IF @IsRetraction = 0
BEGIN
UPDATE CSV_PROF
SET 
[2400P_SV107_01_DiagnosisPointer] =  DP1,
[2400P_SV107_02_DiagnosisPointer] =  DP2,
[2400P_SV107_03_DiagnosisPointer] =  DP3,
[2400P_SV107_04_DiagnosisPointer] =  DP4
FROM EDIFECS.staging.EE_CSV_40P_Rec_Detail CSV_PROF
LEFT JOIN #TMPDIAGP TMP ON CSV_PROF.CLAIMID = TMP.CLM_ID AND CSV_PROF.ClaimLineNumber = TMP.CLM_LN_ID
END;

IF @IsRetraction = 1
BEGIN
UPDATE CSV_PROF
SET 
[2400P_SV107_01_DiagnosisPointer] =  DP1,
[2400P_SV107_02_DiagnosisPointer] =  DP2,
[2400P_SV107_03_DiagnosisPointer] =  DP3,
[2400P_SV107_04_DiagnosisPointer] =  DP4
FROM EDIFECS.staging.EE_CSV_40P_Rec_Detail CSV_PROF
INNER JOIN #TMPDIAGPRET TMP ON CSV_PROF.CLAIMID = TMP.CLM_ID AND CSV_PROF.ClaimLineNumber = TMP.CLM_LN_ID
END;
/*--------------------------------------------------------------------------------
            40p - overlay -  QCARE - Hardcode service lines to 1 -
---------------------------------------------------------------------------------*/

UPDATE EDIFECS.staging.EE_CSV_40P_Rec_Detail
SET ClaimLineNumber = '1', 
[2400P_LX01_LineCounter] = '1',
[2400P_REF02_ServiceRefNumber_4] = '0001' 
FROM EDIFECS.staging.EE_CSV_40P_Rec_Detail
WHERE SourceDataKey = '40'


/*---------------------------------------------------------------------*/
/* POPULATE 431P TABLE                                                */
/*---------------------------------------------------------------------*/

TRUNCATE TABLE EDIFECS.staging.EE_CSV_431P_Rec_Detail;

INSERT INTO EDIFECS.staging.EE_CSV_431P_Rec_Detail
	(
		[ClaimID]
		,[SourceDataKey]
		,[SourceDesc]
		,[CreateDate]
		,ClaimLineNumber
		,[2430_SVD01_COBPrimaryPayerID]
		,[2430_SVD02_COBServicePaidAmount]
		,[431_ClaimLineDisposition]
		,[2430_SVD03_01_ServiceCodeType]
		,[2430_SVD03_02_ServiceCode]
		,[2430_SVD03_03_ServiceModifier1]
		,[2430_SVD03_04_ServiceModifier2]
		,[2430_SVD03_05_ServiceModifier3]
		,[2430_SVD03_06_ServiceModifier4]
		,[2430_SVD03_07_ServiceCodeDescription]
		,[2430_SVD04_RevenueCode]
		,[2430_SVD05_Quantity]
		,[2430_SVD06_BundledLineNumber]
		,[2430_LineLevelDenial_1]
		,[2430_LineLevelDenial_2]
		,[2430_LineLevelDenial_3]
		,[2430_LineLevelDenial_4]
		,[2430_LineLevelDenial_5]
		,[2430_LineLevelDenial_6]
		,[2430_LineLevelDenial_7]
		,[2430_LineLevelDenial_8]
		,[2430_LineLevelDenial_9]
		,[2430_LineLevelDenial_10]
		,[2430_CAS01_ClaimAdjustmentGroup_1]
		,[2430_CAS02_ClaimAdjustmentReason_1]
		,[2430_CAS03_ClaimAdjustmentAmount_1]
		,[2430_CAS04_ClaimAdjustmentquantity_1]
		,[2430_CAS05_ClaimAdjustmentReason_1]
		,[2430_CAS06_ClaimAdjustmentAmount_1]
		,[2430_CAS07_ClaimAdjustmentquantity_1]
		,[2430_CAS08_ClaimAdjustmentReason_1]
		,[2430_CAS09_ClaimAdjustmentAmount_1]
		,[2430_CAS10_ClaimAdjustmentquantity_1]
		,[2430_CAS11_ClaimAdjustmentReason_1]
		,[2430_CAS12_ClaimAdjustmentAmount_1]
		,[2430_CAS13_ClaimAdjustmentquantity_1]
		,[2430_CAS14_ClaimAdjustmentReason_1]
		,[2430_CAS15_ClaimAdjustmentAmount_1]
		,[2430_CAS16_ClaimAdjustmentquantity_1]
		,[2430_CAS17_ClaimAdjustmentReason_1]
		,[2430_CAS18_ClaimAdjustmentAmount_1]
		,[2430_CAS19_ClaimAdjustmentquantity_1]
		,[2430_CAS01_ClaimAdjustmentGroup_2]
		,[2430_CAS02_ClaimAdjustmentReason_2]
		,[2430_CAS03_ClaimAdjustmentAmount_2]
		,[2430_CAS04_ClaimAdjustmentquantity_2]
		,[2430_CAS05_ClaimAdjustmentReason_2]
		,[2430_CAS06_ClaimAdjustmentAmount_2]
		,[2430_CAS07_ClaimAdjustmentquantity_2]
		,[2430_CAS08_ClaimAdjustmentReason_2]
		,[2430_CAS09_ClaimAdjustmentAmount_2]
		,[2430_CAS10_ClaimAdjustmentquantity_2]
		,[2430_CAS11_ClaimAdjustmentReason_2]
		,[2430_CAS12_ClaimAdjustmentAmount_2]
		,[2430_CAS13_ClaimAdjustmentquantity_2]
		,[2430_CAS14_ClaimAdjustmentReason_2]
		,[2430_CAS15_ClaimAdjustmentAmount_2]
		,[2430_CAS16_ClaimAdjustmentquantity_2]
		,[2430_CAS17_ClaimAdjustmentReason_2]
		,[2430_CAS18_ClaimAdjustmentAmount_2]
		,[2430_CAS19_ClaimAdjustmentquantity_2]
		,[2430_CAS01_ClaimAdjustmentGroup_3]
		,[2430_CAS02_ClaimAdjustmentReason_3]
		,[2430_CAS03_ClaimAdjustmentAmount_3]
		,[2430_CAS04_ClaimAdjustmentquantity_3]
		,[2430_CAS05_ClaimAdjustmentReason_3]
		,[2430_CAS06_ClaimAdjustmentAmount_3]
		,[2430_CAS07_ClaimAdjustmentquantity_3]
		,[2430_CAS08_ClaimAdjustmentReason_3]
		,[2430_CAS09_ClaimAdjustmentAmount_3]
		,[2430_CAS10_ClaimAdjustmentquantity_3]
		,[2430_CAS11_ClaimAdjustmentReason_3]
		,[2430_CAS12_ClaimAdjustmentAmount_3]
		,[2430_CAS13_ClaimAdjustmentquantity_3]
		,[2430_CAS14_ClaimAdjustmentReason_3]
		,[2430_CAS15_ClaimAdjustmentAmount_3]
		,[2430_CAS16_ClaimAdjustmentquantity_3]
		,[2430_CAS17_ClaimAdjustmentReason_3]
		,[2430_CAS18_ClaimAdjustmentAmount_3]
		,[2430_CAS19_ClaimAdjustmentquantity_3]
		,[2430_CAS01_ClaimAdjustmentGroup_4]
		,[2430_CAS02_ClaimAdjustmentReason_4]
		,[2430_CAS03_ClaimAdjustmentAmount_4]
		,[2430_CAS04_ClaimAdjustmentquantity_4]
		,[2430_CAS05_ClaimAdjustmentReason_4]
		,[2430_CAS06_ClaimAdjustmentAmount_4]
		,[2430_CAS07_ClaimAdjustmentquantity_4]
		,[2430_CAS08_ClaimAdjustmentReason_4]
		,[2430_CAS09_ClaimAdjustmentAmount_4]
		,[2430_CAS10_ClaimAdjustmentquantity_4]
		,[2430_CAS11_ClaimAdjustmentReason_4]
		,[2430_CAS12_ClaimAdjustmentAmount_4]
		,[2430_CAS13_ClaimAdjustmentquantity_4]
		,[2430_CAS14_ClaimAdjustmentReason_4]
		,[2430_CAS15_ClaimAdjustmentAmount_4]
		,[2430_CAS16_ClaimAdjustmentquantity_4]
		,[2430_CAS17_ClaimAdjustmentReason_4]
		,[2430_CAS18_ClaimAdjustmentAmount_4]
		,[2430_CAS19_ClaimAdjustmentquantity_4]
		,[2430_CAS01_ClaimAdjustmentGroup_5]
		,[2430_CAS02_ClaimAdjustmentReason_5]
		,[2430_CAS03_ClaimAdjustmentAmount_5]
		,[2430_CAS04_ClaimAdjustmentquantity_5]
		,[2430_CAS05_ClaimAdjustmentReason_5]
		,[2430_CAS06_ClaimAdjustmentAmount_5]
		,[2430_CAS07_ClaimAdjustmentquantity_5]
		,[2430_CAS08_ClaimAdjustmentReason_5]
		,[2430_CAS09_ClaimAdjustmentAmount_5]
		,[2430_CAS10_ClaimAdjustmentquantity_5]
		,[2430_CAS11_ClaimAdjustmentReason_5]
		,[2430_CAS12_ClaimAdjustmentAmount_5]
		,[2430_CAS13_ClaimAdjustmentquantity_5]
		,[2430_CAS14_ClaimAdjustmentReason_5]
		,[2430_CAS15_ClaimAdjustmentAmount_5]
		,[2430_CAS16_ClaimAdjustmentquantity_5]
		,[2430_CAS17_ClaimAdjustmentReason_5]
		,[2430_CAS18_ClaimAdjustmentAmount_5]
		,[2430_CAS19_ClaimAdjustmentquantity_5]
		,[2430_DTP01_DateTimeQualifier]
		,[2430_DTP02_DateTimeFormat]
		,[2430_DTP03_ServicePaidDate]
		,[2430_AMT01_AmountQualifier]
		,[2430_AMT02_PatientLiabilityAmount]
		,[431_Allowed_Amount]
		,[EOB_CODE]
		,[AccommodationCode]
		,[431_Filler_03]
		,[431_Filler_04]
		,[431_Filler_05]
		,[431_Filler_06]
		,[431_Filler_07]
		,[431_Filler_08]
		,[431_Filler_09]
		,[431_Filler_10]
		,[431_Filler_11]
		,[431_Filler_12]
		,[431_Filler_13]
		,[431_Filler_14]
		,[431_Filler_15]
		,[431_RecipientAidCategory]
	)
	SELECT 
		DISTINCT
		A.CLM_ID					--[ClaimID]
		,A.SRC_DATA_KEY			--[SourceDataKey]
		,CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END				--SourceDesc
		,GETDATE()					--[CreateDate]
		,A.CLM_LN_ID AS ClaimLineNumber --ClaimLineNumber	
		,CASE WHEN Contract_ID IS NOT NULL THEN Contract_ID ELSE '' END  --A.OTH_PAYER1_PRIMEID		-- 2430_SVD01_COBPrimaryPayerID  - HPLAN - Fill 
		,A.PD_AMT   --A.OTH_PAYER1_PAID_AMT		-- 2430_SVD02_COBServicePaidAmount
		,CASE						--431_ClaimLineDisposition
			WHEN 1 = 1 THEN '1'		--Processed as Primary
			WHEN 1 = 1 THEN '2'		--Processed as Secondar
			WHEN 1 = 1 THEN '3'		--Processed as Tertiary
			WHEN 1 = 1 THEN '4'		--Denied
			WHEN 1 = 1 THEN '19'	--Processed as Primary, forwarded to additional Payers
			WHEN 1 = 1 THEN '20'	--Processed as Secondary, forwarded to additional Payers
			WHEN 1 = 1 THEN '21'	--Processed as Tertiary, forwarded to additional Payers
			WHEN 1 = 1 THEN '22'	--Processed as Reversal of Previous Payment
			WHEN 1 = 1 THEN '23'	--Not our claim, forwarded to additional Payers
			WHEN 1 = 1 THEN '25'	--Predetermination Pricing Only - No Payment
		END
		,'HC' AS SERV_ID_QUAL -- Updated EDS-2188 'HC'	--2430_SVD03_01_ServiceCodeType
		,ISNULL(A.CPT_PROC_CD,'')					--2430_SVD03_02_ServiceCode
		--,A.PROC_MOD1				--2430_SVD03_03_ServiceModifier1
		--,A.PROC_MOD2				--2430_SVD03_04_ServiceModifier2
		--,A.PROC_MOD3				--2430_SVD03_05_ServiceModifier3
		--,A.PROC_MOD4				--2430_SVD03_06_ServiceModifier4
	  ,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_1
     WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> ''  and isnull(CPT_MODFR_CD_1,'') = '' and ( isnull(CPT_MODFR_CD_2,'') <> '59' or isnull(CPT_MODFR_CD_3,'') <> '59' or isnull(CPT_MODFR_CD_4,'') <> '59') THEN '59'
	  ELSE CPT_MODFR_CD_1 END
										
																AS	[2400P_SV101-03_ServiceModifier1]
,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_2
     WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_2,'') = '' and isnull(CPT_MODFR_CD_1,'') <> ''))
						THEN '59'
	  ELSE CPT_MODFR_CD_2 END													
																AS	[2400P_SV101-04_ServiceModifier2]
,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_3
	  WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_3,'') = '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '')
	                     THEN '59'
	  else CPT_MODFR_CD_3 END												
																 AS	[2400P_SV101-05_ServiceModifier3]
,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_4
		WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_4,'') = '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '' and isnull(CPT_MODFR_CD_3,'') <> '')
	                     THEN '59'
		WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_4,'') <> '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '' and isnull(CPT_MODFR_CD_3,'') <> '')
	                     THEN '59'
	  ELSE CPT_MODFR_CD_4 END AS	[2400P_SV101-06_ServiceModifier4]												

		,LEFT(A.CPT_PROC_CD_DESC,100) --2430_SVD03_07_ServiceCodeDescription
		,''							--2430_SVD04_RevenueCode (Yes on Institutional side and not on Professional) 
		,A.SVC_UNITS  --A.OTH_PAYER1_PAID_QTY		--2430_SVD05_Quantity
		,''    --A.OTH_PAYER1_ADJ_BUNDLE	--2430_SVD06_BundledLineNumber
		,''							--2430_LineLevelDenial_1
		,''							--2430_LineLevelDenial_2
		,''							--2430_LineLevelDenial_3
		,''							--2430_LineLevelDenial_4
		,''							--2430_LineLevelDenial_5
		,''							--2430_LineLevelDenial_6
		,''							--2430_LineLevelDenial_7
		,''							--2430_LineLevelDenial_8
		,''							--2430_LineLevelDenial_9
		,''							--2430_LineLevelDenial_10
		-- REPLACED BELOW,A.CLM_ADJ_GRP111			--2430_CAS01_ClaimAdjustmentGroup_1 - CO - Sequence 1 (CASE WHEN DISALW_AMT > 0 AND ADJ_GRP_CD IS NULL THEN 'CO' 
		                                                                                      --WHEN DISALW_AMT > 0 AND ADJ_GRP_CD = 'CO' THEN ADJ_GRP_CD
		,CASE WHEN DISALW_AMT > 0 AND ADJ_GRP_CD IS NULL THEN 'CO' 
			  WHEN DISALW_AMT > 0 AND ADJ_GRP_CD ='PR' THEN 'CO'
			  WHEN DISALW_AMT > 0 AND ADJ_GRP_CD ='OA' THEN 'CO'
			  WHEN DISALW_AMT > 0 AND ADJ_GRP_CD = 'CO' THEN ADJ_GRP_CD
			  WHEN DISALW_AMT > 0 AND ADJ_GRP_CD IS NOT NULL THEN ADJ_GRP_CD
			  ELSE NULL END AS CLM_ADJ_GRP111																			   
		-- replaced below,A.CLM_ADJ_REASON111		--2430_CAS02_ClaimAdjustmentReason_1 - 45 - CASE WHEN DISALW_AMT > 0 AND ADJ_RSN_CD IS NULL THEN '45' 
		                                                                       --WHEN DISALW_AMT > 0 AND ADJ_RSN_CD IS NOT NULL THEN ADJ_RSN_CD 
																			   --ELSE ''
		,CASE WHEN DISALW_AMT > 0 AND ADJ_RSN_CD IS NULL THEN '45' 
		      WHEN DISALW_AMT > 0 AND ADJ_GRP_CD ='PR' THEN '45'
			  WHEN DISALW_AMT > 0 AND ADJ_RSN_CD IS NOT NULL THEN ADJ_RSN_CD 
			  ELSE NULL END AS CLM_ADJ_REASON111
		-- REPLACED BELOW,A.CLM_ADJ_AMT111			--2430_CAS03_ClaimAdjustmentAmount_1 - REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT]) - CASE WHEN DISALW_AMT > 0 THEN DISALW_AMT ELSE ''
		                                                                                                                                               --CASE WHEN DISALW_AMT > 0 AND REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT]) <> DISALW_AMT
	    ,CASE WHEN DISALW_AMT > 0 AND REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT]) <> DISALW_AMT
					THEN REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT])
			  WHEN DISALW_AMT > 0 THEN DISALW_AMT
			ELSE NULL END AS 	CLM_ADJ_AMT111																																     
		,''			--2430_CAS04_ClaimAdjustmentquantity_1
		,''		--2430_CAS05_ClaimAdjustmentReason_1 - Sequence 2 
		,''		--2430_CAS06_ClaimAdjustmentAmount_1
		,''			--2430_CAS07_ClaimAdjustmentquantity_1
		,''		--2430_CAS08_ClaimAdjustmentReason_1- Sequence 3 
		,''			--2430_CAS09_ClaimAdjustmentAmount_1
		,''			--2430_CAS10_ClaimAdjustmentquantity_1
		,''		--2430_CAS11_ClaimAdjustmentReason_1 - Sequence 4
		,''		--2430_CAS12_ClaimAdjustmentAmount_1
		,''		--2430_CAS13_ClaimAdjustmentquantity_1
		,''		--2430_CAS14_ClaimAdjustmentReason_1 - Sequence 5 
		,''			--2430_CAS15_ClaimAdjustmentAmount_1
		,''		--2430_CAS16_ClaimAdjustmentquantity_1
		,''		--2430_CAS17_ClaimAdjustmentReason_1 - Sequence  6
		,''	--2430_CAS18_ClaimAdjustmentAmount_1
		,''		--2430_CAS19_ClaimAdjustmentquantity_1
		-- REPLACE BELOW ,A.CLM_ADJ_GRP12			--2430_CAS01_ClaimAdjustmentGroup_2 - OA 
		,CASE WHEN ADJ_GRP_CD = 'OA' AND DISALW_AMT = '0' THEN ADJ_GRP_CD ELSE NULL END AS CLM_ADJ_GRP12
		--REPLACED WITH BELOW ,A.CLM_ADJ_REASON121		--2430_CAS02_ClaimAdjustmentReason_2 - Sequence 1 
		,CASE WHEN ADJ_GRP_CD = 'OA' AND DISALW_AMT = '0' THEN ADJ_RSN_CD ELSE NULL END AS CLM_ADJ_REASON121
		--replaced with below,A.CLM_ADJ_AMT121			--2430_CAS03_ClaimAdjustmentAmount_2 -  REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT])
		,CASE WHEN ADJ_GRP_CD = 'OA' AND DISALW_AMT = '0' 
		      THEN REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT]) 
			  --WHEN ADJ_GRP_CD = 'OA' AND DISALW_AMT > 0 THEN DISALW_AMT
			  ELSE NULL END AS CLM_ADJ_AMT121
		,''			--2430_CAS04_ClaimAdjustmentquantity_2
		,''		--2430_CAS05_ClaimAdjustmentReason_2 - Sequence 2
		,''		--2430_CAS06_ClaimAdjustmentAmount_2
		,''		--2430_CAS07_ClaimAdjustmentquantity_2
		,''		--2430_CAS08_ClaimAdjustmentReason_2 - Sequence 3
		,''		--2430_CAS09_ClaimAdjustmentAmount_2
		,''			--2430_CAS10_ClaimAdjustmentquantity_2
		,''		--2430_CAS11_ClaimAdjustmentReason_2 - Sequence 4
		,''			--2430_CAS12_ClaimAdjustmentAmount_2
		,''			--2430_CAS13_ClaimAdjustmentquantity_2
		,''		--2430_CAS14_ClaimAdjustmentReason_2 - Sequence 5
		,''			--2430_CAS15_ClaimAdjustmentAmount_2
		,''			--2430_CAS16_ClaimAdjustmentquantity_2
		,''		--2430_CAS17_ClaimAdjustmentReason_2 - Sequence 6
		,''			--2430_CAS18_ClaimAdjustmentAmount_2
		,''			--2430_CAS19_ClaimAdjustmentquantity_2
		,CASE WHEN ( [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT]) > 0 THEN 'PR' ELSE '' END AS CLM_ADJ_GRP13			--2430_CAS01_ClaimAdjustmentGroup_3 - PR - 
		,CASE WHEN COPAY_AMT > 0 THEN '3' --ELSE NULL END AS CLM_ADJ_REASON131		--2430_CAS02_ClaimAdjustmentReason_3 - 3  - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		      WHEN COPAY_AMT = 0 AND DEDUCT_AMT > 0 THEN '1' 
			  WHEN COPAY_AMT = 0 AND DEDUCT_AMT = 0 AND COINS_AMT > 0  THEN '2' 
			  ELSE NULL END AS CLM_ADJ_REASON131
		,CASE WHEN COPAY_AMT > 0 THEN COPAY_AMT 
			  WHEN COPAY_AMT = 0 AND DEDUCT_AMT > 0 THEN DEDUCT_AMT
			  WHEN COPAY_AMT = 0 AND DEDUCT_AMT = 0 AND COINS_AMT > 0  THEN COINS_AMT
			  ELSE NULL END AS CLM_ADJ_AMT131			--2430_CAS03_ClaimAdjustmentAmount_3 - [COPAY_AMT]
		,''			--2430_CAS04_ClaimAdjustmentquantity_3
		,CASE WHEN COPAY_AMT > 0 AND DEDUCT_AMT > 0 THEN '1' 
		      WHEN COPAY_AMT > 0 AND DEDUCT_AMT = 0 AND COINS_AMT > 0  THEN '2' 
			  WHEN COPAY_AMT = 0 AND  DEDUCT_AMT > 0 AND COINS_AMT > 0  THEN '2' 
		    ELSE NULL END AS CLM_ADJ_REASON132		--2430_CAS05_ClaimAdjustmentReason_3 - 1 - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		,CASE WHEN COPAY_AMT > 0 AND DEDUCT_AMT > 0 THEN DEDUCT_AMT 
		      WHEN COPAY_AMT > 0 AND DEDUCT_AMT = 0 AND COINS_AMT > 0 THEN COINS_AMT
			  WHEN COPAY_AMT = 0 AND  DEDUCT_AMT > 0 AND COINS_AMT > 0  THEN COINS_AMT
		      ELSE NULL END  AS CLM_ADJ_AMT132			--2430_CAS06_ClaimAdjustmentAmount_3 - [DEDUCT_AMT]
		,''			--2430_CAS07_ClaimAdjustmentquantity_3 - QUANTITY NEEDED
		,CASE --WHEN COINS_AMT > 0 THEN '2' 
		      WHEN COPAY_AMT > 0 AND DEDUCT_AMT > 0 AND COINS_AMT > 0 THEN '2' 
			  ELSE NULL END AS CLM_ADJ_REASON133		--2430_CAS08_ClaimAdjustmentReason_3 - 2  - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		,CASE --WHEN COINS_AMT > 0 THEN COINS_AMT 
		      WHEN COPAY_AMT > 0 AND DEDUCT_AMT > 0 AND COINS_AMT > 0 THEN COINS_AMT
		     ELSE NULL END AS CLM_ADJ_AMT133
		,''			--2430_CAS10_ClaimAdjustmentquantity_3
		,''		--2430_CAS11_ClaimAdjustmentReason_3 - PR - Sequence 4 - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		,''			--2430_CAS12_ClaimAdjustmentAmount_3
		,''			--2430_CAS13_ClaimAdjustmentquantity_3
		,''		--2430_CAS14_ClaimAdjustmentReason_3- PR - Sequence 5 - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		,''			--2430_CAS15_ClaimAdjustmentAmount_3
		,''			--2430_CAS16_ClaimAdjustmentquantity_3
		,''		--2430_CAS17_ClaimAdjustmentReason_3 - PR - Sequence 6 - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		,''			--2430_CAS18_ClaimAdjustmentAmount_3
		,''			--2430_CAS19_ClaimAdjustmentquantity_3
		,CASE WHEN ADJ_GRP_CD = 'PI' AND DISALW_AMT = '0' THEN ADJ_GRP_CD ELSE NULL END  AS CLM_ADJ_GRP141			--2430_CAS01_ClaimAdjustmentGroup_4 - PI
		,CASE WHEN ADJ_GRP_CD = 'PI' AND DISALW_AMT = '0' THEN ADJ_RSN_CD ELSE NULL END AS CLM_ADJ_REASON141		--2430_CAS02_ClaimAdjustmentReason_4 - Sequence 1 
		,CASE WHEN ADJ_GRP_CD = 'PI' AND DISALW_AMT = '0' THEN REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT]) 
		      WHEN ADJ_GRP_CD = 'PI' AND DISALW_AMT = '0'  THEN DISALW_AMT ELSE NULL END AS CLM_ADJ_AMT141			--2430_CAS03_ClaimAdjustmentAmount_4 
		,''		--2430_CAS04_ClaimAdjustmentquantity_4
		,''		--2430_CAS05_ClaimAdjustmentReason_4 - Sequence 2
		,''		--2430_CAS06_ClaimAdjustmentAmount_4
		,''		--2430_CAS07_ClaimAdjustmentquantity_4
		,''		--2430_CAS08_ClaimAdjustmentReason_4 - Sequence 3
		,''		--2430_CAS09_ClaimAdjustmentAmount_4
		,''		--2430_CAS10_ClaimAdjustmentquantity_4
		,''		--2430_CAS11_ClaimAdjustmentReason_4 - Sequence 4 
		,''		--2430_CAS12_ClaimAdjustmentAmount_4
		,''		--2430_CAS13_ClaimAdjustmentquantity_4
		,''		--2430_CAS14_ClaimAdjustmentReason_4 - Sequence 5 
		,''		--2430_CAS15_ClaimAdjustmentAmount_4
		,''		--2430_CAS16_ClaimAdjustmentquantity_4
		,''		--2430_CAS17_ClaimAdjustmentReason_4 - Sequence 6
		,''		--2430_CAS18_ClaimAdjustmentAmount_4
		,''		--2430_CAS19_ClaimAdjustmentquantity_4
		,''		--2430_CAS01_ClaimAdjustmentGroup_5
		,''		--2430_CAS02_ClaimAdjustmentReason_5
		,''		--2430_CAS03_ClaimAdjustmentAmount_5
		,''		--2430_CAS04_ClaimAdjustmentquantity_5
		,''		--2430_CAS05_ClaimAdjustmentReason_5
		,''		--2430_CAS06_ClaimAdjustmentAmount_5
		,''		--2430_CAS07_ClaimAdjustmentquantity_5
		,''		--2430_CAS08_ClaimAdjustmentReason_5
		,''		--2430_CAS09_ClaimAdjustmentAmount_5
		,''		--2430_CAS10_ClaimAdjustmentquantity_5
		,''		--2430_CAS11_ClaimAdjustmentReason_5
		,''		--2430_CAS12_ClaimAdjustmentAmount_5
		,''		--2430_CAS13_ClaimAdjustmentquantity_5
		,''		--2430_CAS14_ClaimAdjustmentReason_5
		,''		--2430_CAS15_ClaimAdjustmentAmount_5
		,''		--2430_CAS16_ClaimAdjustmentquantity_5
		,''		--2430_CAS17_ClaimAdjustmentReason_5
		,''		--2430_CAS18_ClaimAdjustmentAmount_5
		,''		--2430_CAS19_ClaimAdjustmentquantity_5
		,''						--2430_DTP01_DateTimeQualifier
		,''						--2430_DTP02_DateTimeFormat
		,REPLACE(CLMHDR.PD_DT,'-','') --A.OTH_PAYER1_ADJ_DT			--2430_DTP03_ServicePaidDate  ONLY FOR PROFESSIONAL CLAIMS
		,''						--2430_AMT01_AmountQualifier
		,'' --B.PATIENT_EST_AMT_DUE		--2430_AMT02_PatientLiabilityAmount  ONLY FOR PROFESSIONAL CLAIMS
		,'' 						--431_Allowed_Amount
		,''							--EOB_CODE
		,''							--AccommodationCode
		,''							--431_Filler_03
		,''							--431_Filler_04
		,''							--431_Filler_05
		,''							--431_Filler_06
		,''							--431_Filler_07
		,''							--431_Filler_08
		,''							--431_Filler_09
		,''							--431_Filler_10
		,''							--431_Filler_11
		,''							--431_Filler_12
		,''							--431_Filler_13
		,''							--431_Filler_14
		,''							--431_Filler_15
		,''							--431_RecipientAidCategory
FROM OSS.dbo.[SDO_MDQO_MED_CLM_DTL_ADJUD] A
INNER JOIN EDIFECS.staging.EE_CSV_100P_Rec_Header CSVP ON A.CLM_ID = CSVP.ClaimID
LEFT JOIN OSS.dbo.[SDO_MDQO_MED_CLM_LN_PROV_DENL_LANG] B ON A.CLM_ID = B.CLM_ID AND RTRIM(LTRIM(A.CLM_LN_ID)) = RTRIM(LTRIM(B.CLM_LN_ID)) AND B.EOB_SEQ = '1'
LEFT JOIN OSS.dbo.[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR ON A.CLM_ID = CLMHDR.CLM_ID
LEFT JOIN WIPRO.dbo.Service_Line_Dup_Processing SLDP ON A.CLM_ID = SLDP.claim_id
						   AND A.src_data_key = SLDP.sourcedatakey
						   AND SLDP.Is_Resubmission_Eligible = '1'
						   AND SLDP.Has_Been_Resubmitted = '0'
						   AND SLDP.claim_type IN ('PRO', 'DME' ) 
						   AND SLDP.Error_Code = '98325';

/*--------------------------------------------------------------------------------
            431 - overlay -  QCARE - Hardcode service lines to 1 -
---------------------------------------------------------------------------------*/

UPDATE EDIFECS.staging.EE_CSV_431P_Rec_Detail
SET ClaimLineNumber = '1'
FROM EDIFECS.staging.EE_CSV_431P_Rec_Detail
WHERE SourceDataKey = '40'

/*----------------------------------------------------------------------------------
        Retraction Process Overlays 
-----------------------------------------------------------------------------------*/

IF @IsRetraction = 1 
   BEGIN 
	UPDATE CSVP100
	 SET 
		 Chart_Review_Data = 'TRUE',
		 [PS_Custom_Field_2]   = RII.CMSICN,
		 [100_Filler_17]   = RII.EncounterID   
	 FROM EDIFECS.staging.EE_CSV_100P_Rec_Header CSVP100
	 INNER JOIN WIPRO.dbo.Retraction_Input_Interim RII ON CSVP100.CLAIMID = RII.CLAIMID;

	 UPDATE CSVP20
	 SET 
		 [2300P_CLM01_ClaimNumber] = RII.Retraction_Unique_ID,
		 [2300P_REF02_ClaimReferenceNumber_3] = RII.ENCOUNTERID,
		 [2300P_REF02_ClaimReferenceNumber_7] = RII.CLAIMID, 
		 [2300P_REF02_ClaimReferenceNumber_8] = CASE WHEN RETRACTION_TYPE IN ('CLM_DELETE','CR_DELETE') THEN 'DEL' 
		                                             WHEN RETRACTION_TYPE IN ('CLM_VOID','CR_VOID') THEN 'EA'
												ELSE [2300P_REF02_ClaimReferenceNumber_8] END,
		 [2300P_CLM05-03_ClaimFrequencyCode]  = CASE WHEN RETRACTION_TYPE IN ('CLM_DELETE','CR_DELETE') THEN '1' 
		                                            WHEN RETRACTION_TYPE IN ('CLM_VOID','CR_VOID') THEN '8'
												ELSE '' END,
		 [2300P_HI01-01_DXType_1]		      = CASE WHEN ISNULL([2300P_HI01-01_DXType_1],'') = '' THEN 'ABK' ELSE [2300P_HI01-01_DXType_1] END, 
		 [2300P_HI01-02_DXCode_1]             = CASE WHEN ISNULL([2300P_HI01-02_DXCode_1],'') = '' THEN RII.DXCODE ELSE [2300P_HI01-02_DXCode_1] END
	 FROM EDIFECS.staging.EE_CSV_20P_Rec_Header CSVP20
	 INNER JOIN WIPRO.dbo.Retraction_Input_Interim RII ON CSVP20.CLAIMID = RII.CLAIMID;

	 UPDATE CSVP40
	 SET
		 [2400P_SV107_01_DiagnosisPointer]   = CASE WHEN ISNULL([2400P_SV107_01_DiagnosisPointer],'') = '' THEN '1' ELSE [2400P_SV107_01_DiagnosisPointer] END
	 FROM EDIFECS.staging.EE_CSV_40P_Rec_Detail CSVP40
	 INNER JOIN WIPRO.dbo.Retraction_Input_Interim RII ON CSVP40.CLAIMID = RII.CLAIMID;

	END;


 /********************************************************************************************************************************************************************
  END PROCESS SYSLOG 
*********************************************************************************************************************************************************************/
SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EDIFECS.staging.EE_CSV_100I_Rec_Header)	    

	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @TOTAL_RECORDS    
		,ENTRYDT = GETDATE()    
	WHERE PROC_NAME = 'EDIFECS.dbo.OSS_PROF_SDO_to_CSV_MAP'    
			AND END_DT IS NULL;

/********************************************************************************************************************************************************************
END PROCESS 
*********************************************************************************************************************************************************************/