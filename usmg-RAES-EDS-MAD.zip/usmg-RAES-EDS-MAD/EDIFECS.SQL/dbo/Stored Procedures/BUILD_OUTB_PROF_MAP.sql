﻿


CREATE PROCEDURE [dbo].[BUILD_OUTB_PROF_MAP]
( @LOB CHAR(10),
@LOBCODE VARCHAR(15),
@JOBID INT
)
AS
/********************************************************************************************************************************************************************
 01-17-2020		Anthony Ulmer	Created based on [BUILD_OUTB_PROF_MAP] procedure contained in WIPRO database
 08/25/2020        Aaron Ridley    TETDM-2337 Added logic to accommodate MMP file naming convention
 02/24/2020        Aaron Ridley    TETDM-2359 - FileID updated to accommodate Adjustment file generation 
 02/20/2022      Henry Faust     RETM-55 Change Filename from Adjustment to Adj
 02/21/2023		   Aaron Ridley	   RETM-203 Exclusion 9054 - Suppress update to OBCS
 09/06/2023		Anthony Ulmer	Updated production server names for migration (Use -->> RETM-356 <<-- in find)
*********************************************************************************************************************************************************************/
/* Modifications

07/14/2020	Scott Waller	EDS-2343	Correct the TOTAL_CLAIM and FILEDESC values in the OUTB_FILE_HIST table

*/


SET NOCOUNT ON;
		DECLARE @TOTAL_RECORDS INT
			   ,
				--FILE FOOTER	
				@TOTAL_CLAIM INT
			   ,@TOTAL_PROF_CLM INT
			   ,@TOTAL_DME_CLM INT
			   ,@TOTAL_INST_CLM INT
			   ,@TOTAL_DENTAL_CLM INT
			   ,@TOTAL_LINES INT
			   ,@SUM_TOTAL_CHARGES MONEY
			   ,@SUM_LINE_CHARGES MONEY
			   ,@SUM_TOTAL_CHARGES2 MONEY
			   ,@SUM_LINE_CHARGES2 MONEY
			   ,@TOTAL_EOF_COUNT INT
			   ,@CREATEDT CHAR(14)
			   ,@FILEID CHAR(50)
			   ,@FOOTER CHAR(255)
			   ,@HEADER_CNTRL INT
			   ,@FOOTER_CNTRL INT
			   ,@RECHEADER_CNTRL INT
			   ,@RECDTL_CNTRL INT
			   ,@RECOTH_CNTRL INT
			   ,@FILE_TYPE CHAR(50) = 'Claim Encounter'
			   ,@VERSION CHAR(10) = '1.5.3'
			   ,@SOURCEDATAKEY INT
			   ,@FILEDESC VARCHAR(35)
			   ,@CLAIMTYPE VARCHAR(1)
			   ,@PRODUCTINDICATOR VARCHAR(4) = NULL
			   ,@FILESUBTYPE VARCHAR(15)
			   ,@SUBMITTERID VARCHAR(15)
			   ,@PRODUCTNODE VARCHAR(5)
			   ,@MISSINGDTLCTR INT
			   ,@HSPE_IND VARCHAR(1) --TETDM-1852
			   ,@Procedure_Name VARCHAR(75) = 'EDIFECS.dbo.pr_BUILD_OUTB_PROF_MAP'
			   ,@Sender_ID VARCHAR(15) = 'CHSMAOCLP'
		       ,@Receiver_ID VARCHAR(7) = 'ENC0159';



		--HRP_CLAIM_FILE Run controls
		INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG (PROC_NAME
		, STEP
		, START_DT
		, END_DT
		, RUN_MINUTES
		, TOTAL_RECORDS
		, ENTRYDT)
			VALUES (@Procedure_Name, '11', GETDATE(), NULL, NULL, 0, GETDATE());

-- 03/15/2018 Scott Waller  TETDM-1758
		IF @JOBID BETWEEN 2000 AND 2050
		BEGIN
			SELECT TOP 1
				@LOBCODE = TB.LOBCODE
			FROM WIPRO.dbo.OUTB_WIPRO_TEST_BED TB
			WHERE tb.TESTID = @JOBID;

			-- TETDM-1770
			SELECT TOP 1
				@LOB = TB.typecode
			FROM WIPRO.dbo.OUTB_WIPRO_TEST_BED TB
			WHERE tb.TESTID = @JOBID;
		END;	


	-->> RETM-356 <<-- 
	--PROCEDURE VARIABLES
	--This should only ever return one value.  if multiple are returned here, table is broken.	
		SELECT
			@PRODUCTINDICATOR = IIF(re.Enviornment != 'PROD','TEST',TRIM(re.Enviornment)),
			@FILEID = CONCAT('HSCE.',TRIM(re.Enviornment),'.')
		FROM dbo.Resolve_Environment re
		WHERE @@servername = re.Server_Name;		

		IF @PRODUCTINDICATOR IS NULL BEGIN;
    		THROW 51000, 'The Product Indicator cannot be NULL.  Check that the Resolve_Environment table is updated for the server running this script.', 1; 
		END; 

		--File naming convention Submitterid node assignment
		--remove default @LOBCODE Value used by SSIS package
		if @LOBCODE = '0'
			BEGIN 
				SET @LOBCODE = ' ';
			END;
			--MMAI IL
		ELSE if @LOBCODE = 'UMISC0028041899'
			BEGIN 
				SET @SUBMITTERID = 'DILT09.';
			END;
			--MMAI TX
		ELSE if @LOBCODE = 'C54581391'
			BEGIN 
				SET @SUBMITTERID = 'DTXT11.';   --EDS-2313 - Update TX submitter ID DTX08 to DXT11
			END;

		-----06/08/16 MMAI CAID PRODUCTNODE 

		SET @PRODUCTNODE = 'CARE';

		IF @LOB = 'CAID'
			BEGIN 
				SET @PRODUCTNODE = 'CAID';
				SET @LOB = 'MMAI';
			END;

		IF @JOBID ='2024' 
		   BEGIN 
		       SET  @PRODUCTNODE = 'CAID';
			   SET @LOB = 'CAID';
			END;

		IF @LOBCODE = 'C54581391' AND @PRODUCTNODE = 'CARE'
		   BEGIN 
		       SET @LOB = 'MMPCARE' 
			END;

		IF @LOBCODE = 'C54581391' AND @PRODUCTNODE = 'CAID'
		   BEGIN 
		       SET @LOB = 'MMPCAID' 
			END;

		IF @LOB = 'MMPCARE' AND @LOBCODE = 'C54581391'
		   BEGIN 
		       SET @Sender_ID = 'CHSMMPCARECLP'
			END;

		IF @LOB = 'MMPCAID' AND @LOBCODE = 'C54581391'
		   BEGIN 
		       SET @Sender_ID = 'CHSMMPCAIDCLP'
			END;
		
        IF @LOBCODE  = 'C54581391'
		   BEGIN
		        SET @Receiver_ID = 'DTXT11'
           END;

		SET @SOURCEDATAKEY = (SELECT DISTINCT SOURCEDATAKEY FROM WIPRO.dbo.OUTB_PROF_HEADER);
		SET @CLAIMTYPE = (select distinct claim_type from WIPRO.dbo.OUTB_PROF_HEADER);
		
		IF @JOBID NOT BETWEEN 3000 AND 3050  -- TETDM-2359 Adjustment process accommodation
			BEGIN SET @FILEID = CONCAT(RTRIM(@FILEID),'',rtrim(@LOB),'.',ISNULL(RTRIM(@SUBMITTERID),''),'',RTRIM(@sourcedatakey),'.',@CLAIMTYPE,'.',@PRODUCTNODE,'.',FORMAT(GETDATE(),'yyyyMMddhhmmss'));
		END;		
-- RETM-55 cnage Adjustment to Adj in file name			
		--IF @JOBID BETWEEN 3000 AND 3050 AND @LOB <> 'MMPCARE' -- TETDM-2359 Adjustment process accommodation
		--	BEGIN SET @FILEID = CONCAT(RTRIM(@FILEID),'',rtrim(@LOB),'.',ISNULL(RTRIM(@SUBMITTERID),''),'',RTRIM(@sourcedatakey),'.',@CLAIMTYPE,'.',@PRODUCTNODE,'.Adjustment.',FORMAT(GETDATE(),'yyyyMMddhhmmss'));
		--END; 
		
		--IF @JOBID BETWEEN 3000 AND 3050 AND @LOB = 'MMPCARE' -- TETDM-2359 Adjustment process accommodation
		--	BEGIN SET @FILEID = CONCAT(RTRIM(@FILEID),'',rtrim(@LOB),'.',ISNULL(RTRIM(@SUBMITTERID),''),'',RTRIM(@sourcedatakey),'.',@CLAIMTYPE,'.Adjustment.',FORMAT(GETDATE(),'yyyyMMddhhmmss'))
		--END; 
		IF @JOBID BETWEEN 3000 AND 3050 AND @LOB <> 'MMPCARE' -- TETDM-2359 Adjustment process accommodation
			BEGIN SET @FILEID = CONCAT(RTRIM(@FILEID),'',rtrim(@LOB),'.',ISNULL(RTRIM(@SUBMITTERID),''),'',RTRIM(@sourcedatakey),'.',@CLAIMTYPE,'.',@PRODUCTNODE,'.Adj.',FORMAT(GETDATE(),'yyyyMMddhhmmss'));
		END; 
		
		IF @JOBID BETWEEN 3000 AND 3050 AND @LOB = 'MMPCARE' -- TETDM-2359 Adjustment process accommodation
			BEGIN SET @FILEID = CONCAT(RTRIM(@FILEID),'',rtrim(@LOB),'.',ISNULL(RTRIM(@SUBMITTERID),''),'',RTRIM(@sourcedatakey),'.',@CLAIMTYPE,'.Adj.',FORMAT(GETDATE(),'yyyyMMddhhmmss'))
		END; 

		SET @CREATEDT = FORMAT(GETDATE(),'yyyyMMddhhmmss');
		SET @FILESUBTYPE = CASE @CLAIMTYPE WHEN 'P' THEN 'Professional' WHEN 'E' THEN 'DME' ELSE ' ' END;		
		SET @FILEDESC   = CONCAT( (SELECT RTRIM(SOURCEDESC) FROM WIPRO.dbo.SourceDataDim WHERE SourceDataKey = @SOURCEDATAKEY), '-', @CLAIMTYPE, '-', RTRIM(@LOB));

-- EDS-2343
		SET @TOTAL_CLAIM = (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_PROF_HEADER);		
-- end
				
	   IF OBJECT_ID('tempdb.dbo.#data_rows') IS NOT NULL
			DROP TABLE #data_rows;		

		CREATE TABLE #data_rows
		(
			ID BIGINT PRIMARY KEY IDENTITY(1,1),
			Record_Type varchar(3),
			Record_Order INT,
			Claim_ID VARCHAR(50), --claimid in claimdim = 20, claimid in encounterclaimdim = 50
			Claim_Line_Number INT,
			Records VARCHAR(8000)	
		) WITH (DATA_COMPRESSION = ROW);



		DECLARE @header_record_counts INT;
		--100
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID, Records)
		SELECT
			Record_Type = '100'
		   ,Record_Order = 1
		   ,ecprh.ClaimID
		   ,Records =	CONCAT( '100','|'
					   ,LTRIM(RTRIM(ecprh.ClaimID										 )),'|'
					   ,LTRIM(RTRIM(ecprh.ClaimStatus									 )),'|'
					   ,LTRIM(RTRIM(ecprh.ClaimType										 )),'|'
					   ,LTRIM(RTRIM(ecprh.SenderID										 )),'|'
					   ,LTRIM(RTRIM(ecprh.Receiver_ID_									 )),'|'
					   ,LTRIM(RTRIM(ecprh.OriginatorID									 )),'|'
					   ,LTRIM(RTRIM(ecprh.Contract_ID									 )),'|'
					   ,LTRIM(RTRIM(ecprh.DestinationID									 )),'|'
					   ,LTRIM(RTRIM(ecprh.HistoricalIndicator							 )),'|'
					   ,LTRIM(RTRIM(ecprh.HistoricalDispositionStatus					 )),'|'
					   ,LTRIM(RTRIM(ecprh.HistoricalEncounterICN						 )),'|'
					   ,LTRIM(RTRIM(ecprh.HistoricalEncounterID							 )),'|'
					   ,LTRIM(RTRIM(ecprh.Paper											 )),'|'
					   ,LTRIM(RTRIM(ecprh.DME											 )),'|'
					   ,LTRIM(RTRIM(ecprh.Administrative_Denial							 )),'|'
					   ,LTRIM(RTRIM(ecprh.Chart_Review_Data								 )),'|'
					   ,LTRIM(RTRIM(ecprh.Source_										 )),'|'
					   ,LTRIM(RTRIM(ecprh.Filler										 )),'|'
					   ,LTRIM(RTRIM(ecprh.TraceNumber									 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_NM101_SubmitterEntityRole]				 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_NM102_SubmitterPersonIndicator]		 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_NM103_SubmitterLastName]				 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_NM108_SubmitterIdentifierQualifier]	 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_NM109_SubmitterIdentifier]				 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_PER01_01_SubmitterContactIdentifier]	 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_PER02_01_SubmitterContactName]			 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_PER03_01_SubmitterContactQualifier1]	 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_PER04_01_SubmitterContact1]			 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_PER05_01_SubmitterContacQualifier2]	 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_PER06_01_SubmitterContact2]			 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000B_NM101_ReceiverEntityRole_]				 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000B_NM102_PersonIndicator]					 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000B_NM103_ReceiverName]					 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000B_NM108_ReceiverIdentifierQualifier]		 )),'|'
					   ,LTRIM(RTRIM(ecprh.[1000B_NM109_ReceiverIdentifier]				 )),'|'
					   ,LTRIM(RTRIM(ecprh.[2000A_PRV01_BillingProviderCode]				 )),'|'
					   ,LTRIM(RTRIM(ecprh.[2000A_PRV02_BillingProviderCodeQualifier]     )),'|'
					   ,LTRIM(RTRIM(ecprh.[2000A_PRV03_BillingProviderTaxonomy]				 )),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_NM101_BillingProviderRole]				 )),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_NM102_BillingPersonIndicator]				 )),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_NM103_BillingOrg_LastName]				 )),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_NM104_BillingFirstName]					 )),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_NM105_BillingMiddleName]					 )),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_NM107_BillingSuffix]						 )),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_NM108_BillingProviderIdentifierQualifier]  )),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_NM109_BillingProviderIdentifier]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_N301_BillingAddressLine1]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_N302_BillingAddressLine2]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_N401_BillingCity]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_N402_BillingState]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_N403_BillingPostalCode]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_N404_BillingCountry]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_REF01_BillingProviderIdentifierQualifier_1]			)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_REF02_BillingProviderIdentifier_1]					)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_REF01_BillingProviderIdentifierQualifier_2]			)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_REF02_BillingProviderIdentifier_2]					)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_BillingProviderSpeciality]							)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_BillingProviderType_]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER01_BillingProviderContactFunction_1]				)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER02_BillingProviderContactName_1]					)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER03_BillingProviderCommunicationNumberQualifier_1]	)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER04_BillingProviderCommunicationNumber_1]			)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER05_BillingProviderCommunicatioNumberQualifier_1]	)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER06_BillingProviderCommunicationNumber_1]			)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER07_BillingProviderCommunicatioNumberQualifier_1]	)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER08_BillingProviderCommunicationNumber_1]			)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER01_BillingProviderContactFunction_2]				)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER02_BillingProviderContactName_2]					)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER03_CommunicatioNumberQualifier_2]					)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER04_BillingProviderCommunicationNumber_2]			)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER05_BillingProviderCommunicatioNumberQualifier_2]	)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER06_BillingProviderCommunicationNumber_2]			)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER07_BillingProviderCommunicatioNumberQualifier_2]   )),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AA_PER08_BillingProviderCommunicationNumber_2]           )),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AB_NM101_PayToProviderRole]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AB_NM102_PayToPersonIndicator]							)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AB_N301_PayToAddressLine1]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AB_N302_PayToAddressLine2]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AB_N401_PayToCity]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AB_N402_PayToState]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AB_N403_PayToPostalCode]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AB_N404_PayToCountry]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_NM101_PayToPlanOrganizationRole]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_NM102_PayToPlanPersonIndicator]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_NM103_PayToPlanName]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_NM108_PayToPlanOrganizationIDQualifier]				)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_NM109_PayToPlanOrganizationIdentifier]				)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_N301_PayToPlanAddressLine1]							)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_N302_PayToPlanAddressLine2]							)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_N401_PayToPlanCity]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_N402_PayToPlanState]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_N403_PayToPlanPostalCode]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_N404_PayToPlanCountry]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_REF01_OrganizationIDQualifier_1]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_REF02_OrganizationIdentifier_1]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_REF01_OrganizationIDQualifier_2]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010AC_REF02_OrganizationIdentifier_2]						)),'|'
					   ,LTRIM(RTRIM(ecprh.Claim_Encounter_Cleanup										)),'|'
					   ,LTRIM(RTRIM(ecprh.Atypical_Provider_Flag										)),'|'
					   ,LTRIM(RTRIM(ecprh.Supplemental_Interim_Flag										)),'|'
					   ,LTRIM(RTRIM(ecprh.Interim_Late_Charge_Flag										)),'|'
					   ,LTRIM(RTRIM(ecprh.IssuerIdentifier												)),'|'
					   ,LTRIM(RTRIM(ecprh.[100_Filler_05]												)),'|'
					   ,LTRIM(RTRIM(ecprh.[100R_MonetaryAmountChangeFlag]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[1000A_NM104_SubmitterFirstName]								)),'|'
					   ,LTRIM(RTRIM(ecprh.BillingCountyCode												)),'|'
					   ,LTRIM(RTRIM(ecprh.[100_Filler_06]												)),'|'
					   ,LTRIM(RTRIM(ecprh.ClaimInputMethod												)),'|'
					   ,LTRIM(RTRIM(ecprh.Rehab_Flag													)),'|'
					   ,LTRIM(RTRIM(ecprh.PS_Custom_Field_1												)),'|'
					   ,LTRIM(RTRIM(ecprh.Void_Reason													)),'|'
					   ,LTRIM(RTRIM(ecprh.PS_Custom_Field_2												)),'|'
					   ,LTRIM(RTRIM(ecprh.[100_Filler_12]												)),'|'
					   ,LTRIM(RTRIM(ecprh.[100_Filler_13]												)),'|'
					   ,LTRIM(RTRIM(ecprh.[100_Filler_14]												)),'|'
					   ,LTRIM(RTRIM(ecprh.[100_Filler_15]												)),'|'
					   ,LTRIM(RTRIM(ecprh.[100_Filler_16]												)),'|'
					   ,LTRIM(RTRIM(ecprh.[100_Filler_17]												)))
		FROM EE_CSV_100P_Rec_Header ecprh;

		--SELECT @header_record_counts = @@rowcount; --count of this should be the total record count in file
		--Commented out RETM-203

		--150
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID, Records)
		SELECT
			Record_Type = '150'
		   ,Record_Order = 2
		   ,ecprh.ClaimID
		   ,Records =	CONCAT('150','|'
					   ,LTRIM(RTRIM(ecprh.ClaimID															)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000B_SBR01_SubscriberPayerResponsibilitySequence]				)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000B_SBR02_SubscriberRelationship]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000B_SBR03_SubscriberPolicyNumber]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000B_SBR04_InsuredGroupName]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000B_SBR09_ClaimFilingIndicator]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_NM101_SubscriberPersonRole]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_NM102_SubscriberPersonIndicator]							)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_NM103_SubscriberLastName]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_NM104_SubscriberFirstName]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_NM105_SubscriberMiddleName]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_NM107_SubscriberSuffix]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_NM108_SubscriberIdentifierQualifer]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_NM109_SubscriberIdentifier]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_REF01_SubscriberSSNQualifier]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_REF02_Subscriber_Identifier_SSN]							)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_REF01_PropertyandCasualty_Qualifier]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_REF02_PropertyandCasualty_Identifier]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_N301_SubscriberAddressLine1]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_N302_SubscriberAddressLine2]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_N401_SubscriberCity]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_N402_SubscriberState]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_N403_SubscriberPostalCode]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_N404_SubscriberCountry]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_DMG01_DateQualifer]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_DMG02_DateOfBirth]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_DMG03_Gender]												)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_REF01_SubscriberIdentifierQualifier_1]					)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_REF02_SubscriberIdentifier_1]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_REF01_SubscriberIdentifierQualifer_2]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BA_REF02_SubscriberIdentifier_2]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_NM101_Payer_OrganizationRole]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_NM102_PayerPersonIndicator]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_NM103_PayerName]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_NM108_PayerOrganizationIDQualifier]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_NM109_PayerOrganizationIdentifier]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_N301_PayerAddressLine1]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_N302_PayerAddressLine2]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_N401_PayerCity]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_N402_PayerState]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_N403_PayerPostalCode]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_N404_PayerCountry]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_REF01_PayerOrganizationIDQualifier_1]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_REF02_PayerOrganizationIdentifier_1]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_REF01_ProviderIDQualifier_1]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_REF02_BillingProviderIdentifier_1]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_REF01_BillingProviderIDQualifier_2]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_REF02_BillingProviderIdentifier_2]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_REF01_BillingProviderIDQualifier_3]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_REF02_ProviderIdentifier_3]								)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_REF01_BillingProviderIDQualifier_4]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[2010BB_REF02_BillingProviderIdentifier_4]						)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_Last_Name]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_First_Name]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_Middle_Name]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_SSN]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_Member_ID]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_Gender]												)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_DOB]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_Address_Line1]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_Address_Line2]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_Address_City]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_Address_State]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Patient_Address_Zip]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_PCP_ID_Qual]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_PCP_ID]														)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_PCP_Group_Identifier]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_PDP_IPA_PMG_Type]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_PDP_IPA_PMG_ID]												)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_PCP_Open_Indic]												)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_PCP_Eligibility_Ind]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_COS]															)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Service_Category_Type]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Rendering_Prov_Eff_Date]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Rendering_Prov_Term_Date]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Rendering_Prov_DEA_ID]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Rendering_Prov_Gender]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Provider_Par_Non_Par]										)),'|'
					   ,LTRIM(RTRIM(ecprh.Care_Plan_Option_Indicator										)),'|'
					   ,LTRIM(RTRIM(ecprh.Group_Indentifier													)),'|'
					   ,LTRIM(RTRIM(ecprh.Care_Type_Code													)),'|'
					   ,LTRIM(RTRIM(ecprh.Financial_Arrangement_Code										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_05]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000B_SBR05_InsuranceTypeCode]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000B_PAT09_PregnancyIndicator]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_6]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_7]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_8]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_9]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_10]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_11]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_12]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_13]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_14]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_Filler_15]													)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000B_PAT06_PatientDeathDate]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000C_PAT01_PatientRelationship]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000C_PAT06_PatientDeathDate]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000C_PAT08_PatientWeight]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[2000C_PAT09_PregnancyIndicator]									)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_SubscriberRegionCode]										)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_SubscriberOtherInsuranceCoverage]							)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_PurchasedIndicator]											)),'|'
					   ,LTRIM(RTRIM(ecprh.[150_BehavioralHealth_COS]										)))
		FROM EE_CSV_150P_Rec_Header ecprh;

		--20P
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID, Records)
		SELECT
			Record_Type = '20P'
		   ,Record_Order = 3
		   ,ecprh.ClaimID
		   ,records = CONCAT( --had to break up concat as it only accepts a max of 254 values
						CONCAT('20P','|'				
						,LTRIM(RTRIM(ecprh.[ClaimID]													)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM01_ClaimNumber]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM02_TotalClaimCharge]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM05-01_PlaceOfService]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM05-02_BillTypeQualifier]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM05-03_ClaimFrequencyCode]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM06_ProviderSignature]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM07_MedicareAssignment]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM08_BenefitAssignmentIndicator]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM09_ReleaseOfInformation]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM10_PatientSignatureSource]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM11-01_RelatedCausesCode]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM11-02_RelatedCausesCode]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM11-04_AccidentState]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM11-05_AccidentCountry]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM12_SpecialProgramIndicator]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CLM20_DelayReason]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_1]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_1]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_2]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_2]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_2]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_3]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_3]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_3]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_4]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_4]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_4]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_5]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_5]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_5]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_6]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_6]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_6]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_7]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_7]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_7]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CN101_ContractTypeCode]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CN102_MonetaryAmount]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CN103_ContractPercentage]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CN104_ContractCode]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CN105_TermsDiscountPercent]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CN106_ContractVersionIdentifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_AMT01_AmountQualifier]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_AMT02_PatientAmountPaid]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_ClaimReferenceNumberQualifier_1]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF02_ClaimReferenceNumber_1]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_ClaimReferenceNumberQualifier_2]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF02_ClaimReferenceNumber_2]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_ClaimReferenceNumberQualifier_3]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF02_ClaimReferenceNumber_3]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_ClaimReferenceNumberQualifier_4]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF02_ClaimReferenceNumber_4]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_ClaimReferenceNumberQualifier_5]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF02_ClaimReferenceNumber_5]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_ClaimReferenceNumberQualifier_6]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF02_ClaimReferenceNumber_6]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_ClaimReferenceNumberQualifier_7]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF02_ClaimReferenceNumber_7]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_ClaimReferenceNumberQualifier_8]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF02_ClaimReferenceNumber_8]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_NTE01_ClaimNoteType]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_NTE02_ClaimNote]										)),'|'
						,LTRIM(RTRIM(ecprh.[20P_Ambulance_Transport_Count]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CR101_AmbPatientWeightQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CR102_AmbulancePatientWeight]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CR104_AmbulanceTransportReason]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CR105_AmbulanceMeasure]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CR106_AmbulanceDistance]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CR109_AmbulanceRoundTripDesc]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CR110_StretcherPurposeDescription]					)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CRC01_ServiceCertificationCategory]					)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CRC02_ServiceCertificationIndicator]					)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CRC03_ConditionIndicatorCode]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CRC04_ConditionIndicatorCode]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CRC05_ConditionIndicatorCode]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CRC06_ConditionIndicatorCode]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CRC07_ConditionIndicatorCode]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI01-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI01-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI02-01_DXType_1]										)),'|')--Break concat
						,CONCAT(LTRIM(RTRIM(ecprh.[2300P_HI02-02_DXCode_1]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI03-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI03-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI04-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI04-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI05-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI05-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI06-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI06-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI07-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI07-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI08-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI08-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI09-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI09-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI10-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI10-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI11-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI11-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI12-01_DXType_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI12-02_DXCode_1]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_NM101_ProviderRole]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_NM102_PersonIndicator]								)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_NM103_LastName]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_NM104_FirstName]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_NM105_MiddleName]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_NM107_Suffix]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_NM108_ProviderIdentifierQualifer]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_NM109_ProviderIdentifier]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_REF01_ProviderIdentifierQualifer]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_REF02_ProviderIdentifier]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_REF01_ProviderIdentifierQualifer_02]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310AP_REF02_ProviderIdentifier_02]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_NM101_ProviderRole]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_NM102_PersonIndicator]								)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_NM103_LastName]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_NM104_FirstName]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_NM105_MiddleName]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_NM107_Suffix]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_NM108_ProviderIdentifierQualifer]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_NM109_ProviderIdentifier]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_PRV01_ProviderCode]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_PRV02_ProviderCodeQualifer]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_PRV03_ProviderTaxonomy]								)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_REF01_ProviderIdentifierQualifer_1]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_REF02_ProviderIdentifier_1]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_REF01_ProviderIdentifierQualifer_2]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310BP_REF02_ProviderIdentifier_2]							)),'|'
						,LTRIM(RTRIM(ecprh.[20P_RenderingProviderAddress1]								)),'|'
						,LTRIM(RTRIM(ecprh.[20P_RenderingProviderAddress2]								)),'|'
						,LTRIM(RTRIM(ecprh.[20P_RenderingProviderCity]									)),'|'
						,LTRIM(RTRIM(ecprh.[20P_RenderingProviderState]									)),'|'
						,LTRIM(RTRIM(ecprh.[20P_RenderingProviderZip]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_NM101_ProviderRole]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_NM102_PersonIndicator]								)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_NM103_LastName]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_NM108_ProviderIdentifierQualifer]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_NM109_ProviderIdentifier]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_N301_AddressLine1]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_N302_AddressLine2]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_N401_City]											)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_N402_State]											)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_N403_PostalCode]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_N404_Country]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_REF01_ProviderIdentifierQualifer]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310CP_REF02_ProviderIdentifier]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310DP_NM101_ProviderRole]									)),'|')--Break concat
						,CONCAT(LTRIM(RTRIM(ecprh.[2310DP_NM102_PersonIndicator]						)),'|'
						,LTRIM(RTRIM(ecprh.[2310DP_NM103_LastName]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310DP_NM104_FirstName]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310DP_NM105_MiddleName]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310DP_NM107_Suffix]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310DP_NM108_ProviderIdentifierQualifer]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310DP_NM109_ProviderIdentifier]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310DP_REF01_ProviderIdentifierQualifer]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310DP_REF02_ProviderIdentifier]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310EP_NM101_ProviderRole]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310EP_NM102_PersonIndicator]								)),'|'
						,LTRIM(RTRIM(ecprh.[2310EP_N301_AddressLine1]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310EP_N302_AddressLine2]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310EP_N401_City]											)),'|'
						,LTRIM(RTRIM(ecprh.[2310EP_N402_State]											)),'|'
						,LTRIM(RTRIM(ecprh.[2310EP_N403_PostalCode]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310EP_N404_Country]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310EP_REF01_ProviderIdentifierQualifer]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310EP_REF02_ProviderIdentifier]							)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_NM101_ProviderRole]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_NM102_PersonIndicator]								)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_NM103_ORG_LastName]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_N301_AddressLine1]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_N302_AddressLine2]									)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_N401_City]											)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_N402_State]											)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_N403_PostalCode]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_N404_Country]										)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_REF01_ProviderIdentifierQualifer]					)),'|'
						,LTRIM(RTRIM(ecprh.[2310FP_REF02_ProviderIdentifier]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_PWK01_AttachmentReportType]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_PWK02_AttachmentTransmissionCode]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_PWK06_AttachmentControlNumber]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_InvestigationalDeviceExemptionNumber_Qualifier]	)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF02_InvestigationalDeviceExemptionNumber]			)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_ServiceAuthorizationExceptionCode_Qualifier]	)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF02_ServiceAuthorizationExceptionCode]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_MammographyCertificationNumber_Qualifier]		)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_MammographyCertificationNumber]					)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CR208_PatientConditionCode]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CR210_PatientDescription]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_CR211_PatientDescription]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI101-2_AnesthesiaRelatedSurgicalProcedure]			)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI102-2_AnesthesiaRelatedSurgicalProcedure]			)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_7_02]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_7_02]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_7_02]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_8]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_8]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_8]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_9]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_9]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_9]										)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_10]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_10]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_10]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_11]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_11]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_11]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_12]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_12]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_12]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_13]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_13]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_13]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_14]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_14]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_14]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_15]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_15]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_15]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP01_DateTimeQualifier_16]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP02_FormatQualifier_16]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_DTP03_DateTime_16]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HCP01_PricingMethodology]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HCP02_RepricedAllowedAmount]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HCP03_RepricedSavingAmount]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HCP04_RepricingOrganizationIdentifier]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HCP05_RepricingPerDiemAmount]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HCP06_RepricedApprovedAmbulatoryPatientGroupCode]		)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HCP07_RepricedApprovedAmbulatoryPatientGroupAmount]	)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HCP13_RejectReasonCode]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HCP14_PolicyComplianceCode]							)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HCP15_ExceptionCode]									)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI01-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI01-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI02-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI02-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI03-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI03-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI04-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI04-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI05-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI05-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI06-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI06-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI07-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI07-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI08-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI08-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI09-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI09-02_ConditionCode ]								)),'|')--Break concat
						,CONCAT(LTRIM(RTRIM(ecprh.[2300P_HI10-01_ConditionCodeQualifier]				)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI10-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI11-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI11-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI12-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI12-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation_Qualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation]								)),'|'
						,LTRIM(RTRIM(ecprh.[Claim Processor Receiver Date]								)),'|'
						,LTRIM(RTRIM(ecprh.[InNetworkIndicator ]										)),'|'
						,LTRIM(RTRIM(ecprh.PatientControlNumber											)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 04]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 05]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 06]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 07]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 08]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 09]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 10]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 11]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 12]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 13]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 14]												)),'|'
						,LTRIM(RTRIM(ecprh.[20P-Filler 15]												)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI13-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI13-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI14-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI14-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI15-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI15-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI16-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI16-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI17-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI17-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI18-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI18-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI19-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI19-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI20-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI20-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI21-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI21-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI22-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI22-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI23-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI23-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI24-01_ConditionCodeQualifier]						)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_HI24-02_ConditionCode ]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation2]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation3]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation4]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation5]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation6]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation7]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation8]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation9]								)),'|'
						,LTRIM(RTRIM(ecprh.[2300P_REF01_FileInformation10]								)),'|'
						,LTRIM(RTRIM(ecprh.RenderingProviderSpecialty									))))
		FROM EE_CSV_20P_Rec_Header ecprh;

		--310
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID, Records)
		SELECT
			Record_Type = '310'
		   ,Record_Order = 4
		   ,ecprha.ClaimID
		   ,Records = CONCAT(CONCAT('310','|'
		   ,LTRIM(RTRIM(ecprha.ClaimID												)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_SBR01_PayerResponsibilitySequence]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_SBR02_SubscriberRelationship]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_SBR03_PolicyNumber]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_ProductIDNumber]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_DelegatedBenefitAdminOrgID]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_SBR04_InsuredGroupName]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_SBR05_InsuranceType]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_SBR09_ClaimFilingIndicator]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_ClaimDisposition]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_1]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_2]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_3]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_4]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_5]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_6]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_7]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_8]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_9]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_10]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_11]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_12]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_13]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_14]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_15]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_16]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_17]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_18]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_19]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_20]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_21]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_22]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_23]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RiskAssessmentCode_24]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_ClaimLevelDenial_1]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_ClaimLevelDenial_2]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_ClaimLevelDenial_3]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_ClaimLevelDenial_4]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_ClaimLevelDenial_5]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_ClaimLevelDenial_6]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_ClaimLevelDenial_7]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_ClaimLevelDenial_8]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_ClaimLevelDenial_9]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_ClaimLevelDenial_10]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS01_ClaimAdjustmentGroup_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS02_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS03_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS04_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS05_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS06_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS07_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS08_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS09_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS10_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS11_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS12_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS12_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS14_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS15_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS16_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS17_ClaimAdjustmentReason_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS18_ClaimAdjustmentAmount_1]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS19_ClaimAdjustmentquantity_1]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS01_ClaimAdjustmentGroup_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS02_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS03_ClaimAdjustmentAmount_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS04_ClaimAdjustmentquantity_2]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS05_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS06_ClaimAdjustmentAmount_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS07_ClaimAdjustmentquantity_2]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS08_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS09_ClaimAdjustmentAmount_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS10_ClaimAdjustmentquantity_2]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS11_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS12_ClaimAdjustmentAmount_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS12_ClaimAdjustmentquantity_2]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS14_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS15_ClaimAdjustmentAmount_2]					)),'|') --break concat
		   ,CONCAT(LTRIM(RTRIM(ecprha.[2320_CAS16_ClaimAdjustmentquantity_2]		)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS17_ClaimAdjustmentReason_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS18_ClaimAdjustmentAmount_2]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS19_ClaimAdjustmentquantity_2]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS01_ClaimAdjustmentGroup_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS02_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS03_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS04_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS05_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS06_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS07_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS08_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS09_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS10_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS11_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS12_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS12_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS14_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS15_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS16_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS17_ClaimAdjustmentReason_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS18_ClaimAdjustmentAmount_3]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS19_ClaimAdjustmentquantity_3]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS01_ClaimAdjustmentGroup_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS02_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS03_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS04_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS05_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS06_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS07_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS08_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS09_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS10_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS11_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS12_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS12_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS14_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS15_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS16_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS17_ClaimAdjustmentReason_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS18_ClaimAdjustmentAmount_4]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS19_ClaimAdjustmentquantity_4]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS01_ClaimAdjustmentGroup_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS02_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS03_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS04_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS05_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS06_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS07_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS08_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS09_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS10_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS11_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS12_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS12_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS14_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS15_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS16_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS17_ClaimAdjustmentReason_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS18_ClaimAdjustmentAmount_5]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_CAS19_ClaimAdjustmentquantity_5]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_AMT01_AmountQualifier_1]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_AMT02_COBAmount_1]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_AMT01_AmountQualifier_2]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_AMT02_COBAmount_2]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_AMT01_AmountQualifier_3]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_AMT02_COBAmount_3]								)),'|')--Break Concat
		   ,CONCAT(LTRIM(RTRIM(ecprha.[2320_OI03_AssignBenefitsIndicator]			)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_OI04_PatientSignature]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_OI06_ReleaseOfInformation]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA01_AdjudQuantity]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA03_AdjudQuantity]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA04_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA05_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA06_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA07_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA08_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA09_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA10_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA11_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA12_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA13_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA14_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA15_AdjudQuantity]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA16_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA17_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA18_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA19_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA20_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA21_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA22_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA23_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MIA24_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MOA01_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MOA02_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MOA03_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MOA04_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MOA05_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MOA06_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MOA07_RemarkCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MOA08_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2320_MOA09_AdjudAmount]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_NM101_PersonRole]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_NM102_PersonIndicator]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_NM103_LastName]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_NM104_FirstName]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_NM105_MiddleName]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_NM107_Suffix]									)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_NM108_PersonIdentifierQualifier]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_NM109_PersonIdentifier]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_N301_AddressLine1]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_N302_AddressLine2]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_N401_City]									)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_N402_State]									)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_N403_PostalCode]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330A_N404_Country]									)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_NM101_OrganizationRole]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_NM102_PersonIndicator]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_NM103_Name]									)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_NM108_OrganizationIdQualifier]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_NM109_OrganizationIdentifier]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_N301_AddressLine1]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_N302_AddressLine2]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_N401_City]									)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_N402_State]									)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_N403_PostalCode]								)),'|') --Break concat
		   ,CONCAT(LTRIM(RTRIM(ecprha.[2330B_N404_Country]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_DTP01_DateTimeQualifier]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_DTP02_DateTimeFormat]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_DTP03_ClaimPaidDate]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_OverPaymentID]									)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_OrganizationIdQualifier_1]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_OrganizationIdentifier_1]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_OrganizationIdQualifier_2]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_OrganizationIdentifier_2]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_OrganizationIdQualifier_3]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_OrganizationIdentifier_3]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_OrganizationIdQualifier_4]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_OrganizationIdentifier_4]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_OrganizationIdQualifier_5]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_OrganizationIdentifier_5]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_ReportBeginDate]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_ReportEndDate]									)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_PaymentYear]									)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF01_AdjudicatedDRGQualifier]				)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF02_AdjudicatedDRG]							)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF04-01_ReferenceIdentificationQualifier]	)),'|'
		   ,LTRIM(RTRIM(ecprha.[2330B_REF04-02_DRGGrouperVersion]					)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_Rate_Increase_Indicator]						)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_Bundle_Indicator]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_Bundle_Claim_Number]							)),'|'
		   ,LTRIM(RTRIM(ecprha.ClaimApprovedAmount									)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_PaymentCheckDate]								)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_03]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_04]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_05]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_06]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_07]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_08]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_09]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_10]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_11]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_12]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_13]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_14]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310-Filler_15]										)),'|'
		   ,LTRIM(RTRIM(ecprha.[310_RecipientAidCategory]							))))
		FROM EDIFECS.dbo.EE_CSV_310P_Rec_Header ecprha;

		--40P
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID,Claim_Line_Number, Records)
		SELECT
			Record_Type = '40P'
		   ,Record_Order = 5
		   ,ecprd.ClaimID
		   ,ClaimLineNumber = CAST(ecprd.ClaimLineNumber AS INT)
		   ,Records = CONCAT(CONCAT('40P','|'	
		   ,LTRIM(RTRIM(ecprd.ClaimID															)),'|'		   		   
		   ,TRY_CAST(ecprd.[2400P_LX01_LineCounter] AS INT)										  ,'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV101_01_ServiceCodeType]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV101_02_ServiceCode]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV101_03_ServiceModifier1]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV101_04_ServiceModifier2]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV101_05_ServiceModifier3]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV101_06_ServiceModifier4]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV101_07_ServiceCodeDescription]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV102_LineCharge]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV103_ServiceUnitMeasure]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV104_Quantity]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV105_PlaceOfService]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV107_01_DiagnosisPointer]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV107_02_DiagnosisPointer]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV107_03_DiagnosisPointer]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV107_04_DiagnosisPointer]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV109_EmergencyService]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV111_EPSDTService]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV112_FamilyPlanningService]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV115_CoPayExempt]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV501_01_ServiceCodeType]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV501_02_ServiceCode]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV502_ServiceUnitMeasure]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV503_LengthMedicalNecessity]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV504_RentalPrice]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV505_PurchasePrice]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_SV506_RentalUnitPrice]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_PWK01_ReportType]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_PWK02_TransmissionCode]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_PWK05_CodeQualifier]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_PWK06_ControlNumber]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CR101_PatientWeightQualifier]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CR102_PatientWeight]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CR104_TransportReason]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CR105_ServiceMeasureCode]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CR106_Distance]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CR109_RoundTripDesc]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CR110_StretcherPurpose]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_1]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_1]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_1]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_2]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_2]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_2]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_3]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_3]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_3]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_4]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_4]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_4]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_5]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_5]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_5]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_6]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_6]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_6]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_7]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_7]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_7]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_8]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_8]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_8]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_9]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_9]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_9]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_10]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_10]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_10]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP01_DateTimeQualifier_11]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_DTP02_FormatQualifier_11]									)),'|')--break concat
		   ,CONCAT(LTRIM(RTRIM(ecprd.[2400P_DTP03_Date_11]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_QTY01_QuantityQualiferID_1]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_QTY02_Quantity_1]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_QTY01_QuantityQualifierID_2]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_QTY02_Quantity_2]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA01_MeasurementIdentifierCode_1]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA02_MeasurementQualifier_1]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA03_MeasurementValue_1]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA01_MeasurementIdentifierCode_2]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA02_MeasurementQualifier_2]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA03_MeasurementValue_2]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA01_MeasurementIdentifierCode_3]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA02_MeasurementQualifier_3]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA03_MeasurementValue_3]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA01_MeasurementIdentifierCode_4]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA02_MeasurementQualifier_4]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA03_MeasurementValue_4]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA01_MeasurementIdentifierCode_5]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA02_MeasurementQualifier_5]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_MEA03_MeasurementValue_5]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CN101_ContractType]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CN102_ContractAmount]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CN103_ContractPercentage]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CN104_ContractCode]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CN105_TermsDiscountPercent]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CN106_ContractVersionIdentifier]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF01_ServiceRefNumberQualifier_1]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF02_ServiceRefNumber_1]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF01_ServiceRefNumberQualifier_2]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF02_ServiceRefNumber_2]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF01_ServiceRefNumberQualifier_3]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF02_ServiceRefNumber_3]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF01_ServiceRefNumberQualifier_4]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF02_ServiceRefNumber_4]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF01_ServiceRefNumberQualifier_5]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF02_ServiceRefNumber_5]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF01_ServiceRefNumberQualifier_6]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF02_ServiceRefNumber_6]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF01_ServiceRefNumberQualifier_7]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF02_ServiceRefNumber_7]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF01_ServiceRefNumberQualifier_8]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF02_ServiceRefNumber_8]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF04_01_AssignedByQualifier_8]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF04_02_AssignedBy_8]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF01_ServiceRefNumberQualifier_9]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF02_ServiceRefNumber_9]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF04_01_AssignedByQualifier_9]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF04_02_AssignedBy_9]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_AMT01_AmountQualfier_1]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_AMT02_Amount_1]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_AMT01_AmountQualfier_2]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_AMT02_Amount_2]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_K301_FixedFormatInformation_1]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_K301_FixedFormatInformation_2]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_K301_FixedFormatInformation_3]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_K301_FixedFormatInformation_4]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_K301_FixedFormatInformation_5]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_K301_FixedFormatInformation_6]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_K301_FixedFormatInformation_7]								)),'|')--break concat
		   ,CONCAT(LTRIM(RTRIM(ecprd.[2400P_K301_FixedFormatInformation_8]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_K301_FixedFormatInformation_9]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_K301_FixedFormatInformation_10]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_NTE01_NoteType_1]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_NTE02_Note_1]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_NTE01_NoteType_2]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_NTE02_Note_2]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP01_PricingMethod]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP02_RepricedAllowedAmt]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP03_RepricedSavingAmt]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP04_RepricingOrdID]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP05_PricingRange]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP06_APGPricingCode]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP07_APGPricingAmt]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP09_ServiceType]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP10_ApprovedServiceCode]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP11_RepricingUnits]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP12_RepricingQuantity]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP13_RejectReasonCode]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP14_PolicyComplianceCode]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_HCP15_ExceptionCode]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2410P_LIN02_DrugCodeType]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2410P_LIN03_NationalDrugCode]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2410P_CTP04_Quantity]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2410P_CTP05_01_Units]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2410P_REF01_ReferenceIDQualifier]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2410P_REF02_ReferenceIdentifier]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420GP_NM101_ProviderRole]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420GP_NM102_PersonIndicator]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420GP_N301_AddressLine1]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420GP_N302_AddressLine2]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420GP_N401_City]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420GP_N402_State]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420GP_N403_PostalCode]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420GP_N404_Country]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420HP_NM101_ProviderRole]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420HP_NM102_PersonIndicator]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420HP_NM103_ORG_LastName]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420HP_N301_AddressLine1]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420HP_N302_AddressLine2]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420HP_N401_City]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420HP_N402_State]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420HP_N403_PostalCode]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420HP_N404_Country]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_PWK02_DMEAttachmentTransmissionCode]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CR301_CertificationTypeCode]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CR303_DurableMedicalEquipmentDuration]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CRC02_CertificationConditionIndicator]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CRC03_ConditionCode]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CRC04_ConditionCode]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CRC05_ConditionCode]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CRC06_ConditionCode]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_CRC07_ConditionCode]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF01_RepricedLineItemReferenceQualifier]					)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_REF02_RepricedLineItemReferenceNumber]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_PS101_PurchasedSerivceProviderIdentifier]					)),'|'
		   ,LTRIM(RTRIM(ecprd.[2400P_PS102_PurchasedServiceChargeAmount]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_01]													)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_02]													)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_03]													)),'|')--break concat
		   ,CONCAT(LTRIM(RTRIM(ecprd.[40P_Filler_04]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_05]													)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_NM101_ProviderRole]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_NM102_PersonIndicator]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_NM103_LastName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_NM104_FirstName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_NM105_MiddleName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_NM107_Suffix]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_NM108_ProviderIdentifierQualifer]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_NM109_ProviderIdentifier]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_PRV03_ProviderTaxonomy]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_REF01_ProviderIdentifierQualifer_1]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_REF02_ProviderIdentifier_1]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_REF01_ProviderIdentifierQualifer_2]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_REF02_ProviderIdentifier_2]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_REF01_ProviderIdentifierQualifer_3]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420AP_REF02_ProviderIdentifier_3]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420BP_NM101_ProviderRole]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420BP_NM102_PersonIndicator]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420BP_NM108_ProviderIdentifierQualifer]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420BP_NM109_ProviderIdentifier]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420BP_REF01_ProviderIdentifierQualifer_1]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420BP_REF02_ProviderIdentifier_1]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420BP_REF01_ProviderIdentifierQualifer_2]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420BP_REF02_ProviderIdentifier_2]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_NM101_ProviderRole]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_NM102_PersonIndicator]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_NM103_LastName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_NM108_ProviderIdentifierQualifer]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_NM109_ProviderIdentifier]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_N301_AddressLine1]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_N302_AddressLine2]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_N401_City]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_N402_State]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_N403_PostalCode]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_N404_Country]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_REF01_ProviderIdentifierQualifer_1]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_REF02_ProviderIdentifier_1]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_REF01_ProviderIdentifierQualifer_2]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420CP_REF02_ProviderIdentifier_2]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_NM101_ProviderRole]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_NM102_PersonIndicator]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_NM103_LastName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_NM104_FirstName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_NM105_MiddleName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_NM107_Suffix]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_NM108_ProviderIdentifierQualifer]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_NM109_ProviderIdentifier]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_REF01_ProviderIdentifierQualifer_1]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_REF02_ProviderIdentifier_1]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_REF01_ProviderIdentifierQualifer_2]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_REF02_ProviderIdentifier_2]								)),'|')--break concat
		   ,CONCAT(LTRIM(RTRIM(ecprd.[2420DP_REF01_ProviderIdentifierQualifer_3]				)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420DP_REF02_ProviderIdentifier_3]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_NM101_ProviderRole]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_NM102_PersonIndicator]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_NM103_LastName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_NM104_FirstName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_NM105_MiddleName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_NM107_Suffix]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_NM108_ProviderIdentifierQualifer]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_NM109_ProviderIdentifier]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_N301_AddressLine1]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_N302_AddressLine2]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_N401_City]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_N402_State]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_N403_PostalCode]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_N404_Country]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_REF01_ProviderIdentifierQualifer_1]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_REF02_ProviderIdentifier_1]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_REF01_ProviderIdentifierQualifer_2]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420EP_REF02_ProviderIdentifier_2]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_NM101_ProviderRole]										)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_NM102_PersonIndicator]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_NM103_LastName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_NM104_FirstName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_NM105_MiddleName]											)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_NM107_Suffix]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_NM108_ProviderIdentifierQualifer]							)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_NM109_ProviderIdentifier]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_REF01_ProviderIdentifierQualifer_1]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_REF02_ProviderIdentifier_1]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_REF01_ProviderIdentifierQualifer_2]						)),'|'
		   ,LTRIM(RTRIM(ecprd.[2420FP_REF02_ProviderIdentifier_2]								)),'|'
		   ,LTRIM(RTRIM(ecprd.[InNetworkIndicator ]												)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceLineContractID												)),'|'
		   ,LTRIM(RTRIM(ecprd.TPLPaidAmount														)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_9]													)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_10]													)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_11]													)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_12]													)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_13]													)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_14]													)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_Filler_15]													)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceHealthPlan													)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceBenefitPlan												)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceAdministrativeCounty										)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceResidenceCounty											)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceEligibilityCode											)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceSubProgram1												)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceSubProgram2												)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceSubProgram3												)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceSubProgram4												)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceArrangementCode											)),'|'
		   ,LTRIM(RTRIM(ecprd.ServiceTribalCode													)),'|'
		   ,LTRIM(RTRIM(ecprd.[CategoryOfService ]												)),'|'
		   ,LTRIM(RTRIM(ecprd.[RenderingProviderSpeciality ]									)),'|'
		   ,LTRIM(RTRIM(ecprd.[PurchasedIndicator ]												)),'|'
		   ,LTRIM(RTRIM(ecprd.BH_ESPDTIndicator													)),'|'
		   ,LTRIM(RTRIM(ecprd.MPIServiceLocation												)),'|'
		   ,LTRIM(RTRIM(ecprd.EBPPCode01														)),'|'
		   ,LTRIM(RTRIM(ecprd.[EBPPCode02 ]														)),'|'
		   ,LTRIM(RTRIM(ecprd.[EBPPCode03 ]														)),'|'
		   ,LTRIM(RTRIM(ecprd.EBPPCode04														)),'|'
		   ,LTRIM(RTRIM(ecprd.EBPPCode05														)),'|'
		   ,LTRIM(RTRIM(ecprd.OrderingProviderLocationCode										)),'|'
		   ,LTRIM(RTRIM(ecprd.[40P_MediaType]													)),'|'
		   ,LTRIM(RTRIM(ecprd.BeneficiaryCostSharingStatus										)),'|'
		   ,LTRIM(RTRIM(ecprd.OutofPocketMaximum												)),'|'
		   ,LTRIM(RTRIM(ecprd.BeneficiaryLockInStatus											))))
		FROM EE_CSV_40P_Rec_Detail ecprd;

		--431		
		INSERT INTO #data_rows (Record_Type, Record_Order, Claim_ID, Claim_Line_Number, Records)
		SELECT
			Record_Type = '431'
		   ,Record_Order = 6
		   ,ecprd.ClaimID
		   ,ClaimLineNumber = CAST(ecprd.ClaimLineNumber AS INT)
		   ,Records = CONCAT(CONCAT('431','|'								
							,LTRIM(RTRIM(ecprd.ClaimID										)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD01_COBPrimaryPayerID]				)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD02_COBServicePaidAmount]			)),'|'
							,LTRIM(RTRIM(ecprd.[431_ClaimLineDisposition]					)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD03_01_ServiceCodeType]				)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD03_02_ServiceCode]					)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD03_03_ServiceModifier1]				)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD03_04_ServiceModifier2]				)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD03_05_ServiceModifier3]				)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD03_06_ServiceModifier4]				)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD03_07_ServiceCodeDescription]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD04_RevenueCode]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD05_Quantity]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_SVD06_BundledLineNumber]				)),'|'
							,LTRIM(RTRIM(ecprd.[2430_LineLevelDenial_1]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_LineLevelDenial_2]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_LineLevelDenial_3]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_LineLevelDenial_4]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_LineLevelDenial_5]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_LineLevelDenial_6]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_LineLevelDenial_7]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_LineLevelDenial_8]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_LineLevelDenial_9]						)),'|'
							,LTRIM(RTRIM(ecprd.[2430_LineLevelDenial_10]					)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS01_ClaimAdjustmentGroup_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS02_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS03_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS04_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS05_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS06_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS07_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS08_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS09_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS10_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS11_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS12_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS13_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS14_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS15_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS16_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS17_ClaimAdjustmentReason_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS18_ClaimAdjustmentAmount_1]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS19_ClaimAdjustmentquantity_1]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS01_ClaimAdjustmentGroup_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS02_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS03_ClaimAdjustmentAmount_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS04_ClaimAdjustmentquantity_2]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS05_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS06_ClaimAdjustmentAmount_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS07_ClaimAdjustmentquantity_2]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS08_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS09_ClaimAdjustmentAmount_2]			)),'|') --break concat
							,CONCAT(LTRIM(RTRIM(ecprd.[2430_CAS10_ClaimAdjustmentquantity_2])),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS11_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS12_ClaimAdjustmentAmount_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS13_ClaimAdjustmentquantity_2]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS14_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS15_ClaimAdjustmentAmount_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS16_ClaimAdjustmentquantity_2]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS17_ClaimAdjustmentReason_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS18_ClaimAdjustmentAmount_2]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS19_ClaimAdjustmentquantity_2]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS01_ClaimAdjustmentGroup_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS02_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS03_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS04_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS05_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS06_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS07_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS08_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS09_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS10_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS11_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS12_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS13_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS14_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS15_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS16_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS17_ClaimAdjustmentReason_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS18_ClaimAdjustmentAmount_3]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS19_ClaimAdjustmentquantity_3]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS01_ClaimAdjustmentGroup_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS02_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS03_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS04_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS05_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS06_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS07_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS08_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS09_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS10_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS11_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS12_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS13_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS14_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS15_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS16_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS17_ClaimAdjustmentReason_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS18_ClaimAdjustmentAmount_4]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS19_ClaimAdjustmentquantity_4]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS01_ClaimAdjustmentGroup_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS02_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS03_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS04_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS05_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS06_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS07_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS08_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS09_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS10_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS11_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS12_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS13_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS14_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS15_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS16_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS17_ClaimAdjustmentReason_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS18_ClaimAdjustmentAmount_5]			)),'|'
							,LTRIM(RTRIM(ecprd.[2430_CAS19_ClaimAdjustmentquantity_5]		)),'|'
							,LTRIM(RTRIM(ecprd.[2430_DTP01_DateTimeQualifier]				)),'|'
							,LTRIM(RTRIM(ecprd.[2430_DTP02_DateTimeFormat]					)),'|'
							,LTRIM(RTRIM(ecprd.[2430_DTP03_ServicePaidDate]					)),'|'
							,LTRIM(RTRIM(ecprd.[2430_AMT01_AmountQualifier]					)),'|'
							,LTRIM(RTRIM(ecprd.[2430_AMT02_PatientLiabilityAmount]			)),'|'
							,LTRIM(RTRIM(ecprd.[431_Allowed_Amount]							)),'|'
							,LTRIM(RTRIM(ecprd.EOB_CODE										)),'|'
							,LTRIM(RTRIM(ecprd.AccommodationCode							)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_03]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_04]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_05]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_06]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_07]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_08]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_09]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_10]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_11]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_12]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_13]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_14]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_Filler_15]								)),'|'
							,LTRIM(RTRIM(ecprd.[431_RecipientAidCategory]					))))
		FROM EE_CSV_431P_Rec_Detail ecprd;


		IF OBJECT_ID('tempdb.dbo.#sorted_data_rows') IS NOT NULL
		DROP TABLE #sorted_data_rows;		

		CREATE TABLE #sorted_data_rows --final sort order
		(
			ID BIGINT PRIMARY KEY IDENTITY(1,1),
			Records VARCHAR(8000)	
		) WITH (DATA_COMPRESSION = ROW);


		INSERT INTO #sorted_data_rows (Records)
		SELECT Records = CONCAT('00|EMCSV|',LTRIM(RTRIM(@VERSION)),'|',LTRIM(RTRIM(@FILEID)),'|Medical|',FORMAT(GETDATE(),'yyyyMMddhhmmss'),'|',@Sender_ID,'|',@Receiver_ID);

		IF OBJECT_ID('tempdb.dbo.#Claim_Hold') IS NOT NULL
        	DROP TABLE #Claim_Hold;

		--Taken from EXSP_CLAIM_EXCLUSION_MISSING_DETAIL to partially mimic exclusion behavior		
		SELECT DISTINCT
				Claim_ID = oph.CLAIM_ID,
				SourceDataKey = oph.SOURCEDATAKEY,
				BATCH_RUNDT = GETDATE(),
				EXCL_ID = 9054,
				CLAIM_TYPE = oph.CLAIM_TYPE
		INTO #Claim_Hold
		FROM WIPRO.dbo.OUTB_PROF_HEADER oph
			left join WIPRO.dbo.OUTB_PROF_DETAIL opd on opd.claim_id = oph.claim_id
			left join edps_data.dbo.claimdim cd on cd.claimid = oph.claim_id
		WHERE 1 = 1
			AND opd.claim_id is NULL
			AND NOT EXISTS (SELECT --filter claims alread seen
								1
							FROM WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST eceh
							WHERE 1 = 1
								AND oph.Claim_ID = eceh.Claim_ID
								AND eceh.CLAIM_TYPE = @CLAIMTYPE
								AND eceh.EXCL_ID = 9054);

		-- RETM-203 Delete Header record for EXCL 9054
		DELETE oph
		FROM WIPRO.dbo.OUTB_PROF_HEADER oph 
		INNER JOIN #Claim_Hold ch on oph.CLAIM_ID = ch.CLAIM_ID;

		INSERT INTO #sorted_data_rows (Records)
		SELECT
			dr.Records
		FROM #data_rows dr
		WHERE NOT EXISTS (SELECT 1 FROM #Claim_Hold ch WHERE ch.Claim_ID = dr.Claim_ID)
		ORDER BY 
			dr.Claim_ID,			
			dr.Claim_Line_Number,
			dr.Record_Order;


		--trailer record
		/****************************************
		Field #	Column Name	Field		Values
			1	00 Trailer Record		  01
			2	TRT Record				  TRT			
			3	Total_Professional		
			4	Total_Institutional		
			5	Total_Dental			
			6	Total_Claim_Count
		*****************************************/
		SET @header_record_counts = (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_PROF_HEADER); -- Moved for RETM-203
		INSERT INTO #sorted_data_rows (Records)
		SELECT Records = CONCAT('01|TRT|',@header_record_counts,'|0|0|',@header_record_counts);
		--For our files we only send one type in each file so if that changes, the above needs to change too
		
				TRUNCATE TABLE EDIFECS.dbo.OUTB_PROF_CLAIM_MAP;
		
		SET XACT_ABORT ON;
		--begin dangerous stuff.....
		BEGIN TRY			
			BEGIN TRANSACTION;

			--datapoints from legacy wipro process
			SET @HEADER_CNTRL = (select  distinct dbo.countrecorddelimter(dr.Records,'|') from #data_rows dr Where Record_Type = '00');  
			SET @FOOTER_CNTRL = (select  distinct dbo.countrecorddelimter(dr.Records,'|') from #data_rows dr Where Record_Type = '01');  
			SET @RECHEADER_CNTRL = (select  distinct dbo.countrecorddelimter(dr.Records,'|') from #data_rows dr Where Record_Type = '100');  
			SET @RECDTL_CNTRL = (select  distinct dbo.countrecorddelimter(dr.Records,'|') from #data_rows dr Where Record_Type = '431');
			-- EDS-2343 - Moved for RETM-203
		    SET @TOTAL_CLAIM = (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_PROF_HEADER);

			INSERT INTO WIPRO.dbo.OUTB_FILE_HIST (FILEID, FILEDATE, FILENAME, FILEHEADER, FILEFOOTER, ENTRYDT,
													FILEHEADER_AUD_CNTRL, FILEFOOTER_AUD_CNTRL, RECTYPEHEADER_AUD_CNTRL, RECTYPEDETAIL_AUD_CNTRL,
													RECTYPEOTHER_AUD_CNTRL, FILE_TYPE, FILE_VERSION, REJ_FILE_ID, REJ_FILE_DT, REJ_REA_CD,
													REJ_REA_MSG, REJ_TRAILER, REJ_VAL_RPTD, REJ_VAL_CALC, ACK_FILE_ID, ACK_FILE_DT, ACK_TOTALREC_REC_AMT,
													ACK_HDR_REC_AMT, ACK_LINE_REC_AMT, ACK_SUPL_REC_AMT, STAT_FILE_ID, STAT_FILE_DT, STAT_REC_AMT,
													STAT_ACCPT_AMT, STAT_REJ_AMT, LAST_UPD_DT, TOTAL_CLM, SOURCEDATAKEY, STAT_FATAL_ERR_AMT,
													STAT_DUP_CLM_AMT, STAT_INV_DOS_AMT, FILEDESC)
			SELECT	@FILEID,GETDATE(),NULL
					,RTRIM((SELECT TOP 1 dr.Records FROM #data_rows dr WHERE dr.Record_Type = '00'))		
					,RTRIM((SELECT TOP 1 dr.Records FROM #data_rows dr WHERE dr.Record_Type = '01'))
					,GETDATE(),@HEADER_CNTRL  
					,@FOOTER_CNTRL,@RECHEADER_CNTRL,@RECDTL_CNTRL,NULL,@FILE_TYPE,@VERSION  
					,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL  
					,NULL,NULL,NULL,NULL,@TOTAL_CLAIM,@SOURCEDATAKEY,NULL,NULL,NULL,CONCAT(@FILEDESC,'-JobId-',@JOBID);	
			--end legacy wipro datapoints


			INSERT INTO EDIFECS.dbo.OUTB_PROF_CLAIM_MAP (DATAROW)
			SELECT
				sdr.Records
			FROM #sorted_data_rows sdr
			ORDER BY sdr.ID

			--insert claims found for exclusion into exclusion history table
			INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST (Claim_ID, SourceDataKey, BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE)
			SELECT
				ch.Claim_ID
			   ,ch.SourceDataKey
			   ,ch.BATCH_RUNDT
			   ,ch.EXCL_ID
			   ,ch.CLAIM_TYPE
			FROM #Claim_Hold ch;		

			--legacy wipro tracking table
			INSERT INTO WIPRO.dbo.OUTB_CLAIM_STATUS  
			SELECT CLAIM_ID,CLAIM_TYPE,@FILEID,CLM_IND,SOURCEDATAKEY,MEMBER_ID  
					,HICN_NUM,BILL_PROV_GRP_ID,BILL_PROV_ID,REF_PROV_ID,' '  
					,ATTN_PROV_ID,NULL,NULL,NULL,NULL,NULL  
					,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,@CREATEDT,GETDATE(),SUBSTRING(STATE_BEGIN_DT,1,6)  
					,null,null,null  
			FROM WIPRO.dbo.OUTB_PROF_HEADER;

			EXEC wipro.dbo.pr_ClaimProfessionalExtractHistoryInsert @FILEID;

			COMMIT TRANSACTION;

		END TRY
		BEGIN CATCH
			DECLARE @error NVARCHAR(MAX) = ERROR_MESSAGE();

			UPDATE WIPRO.dbo.EXT_SYS_RUNLOG
			SET END_DT = GETDATE()
			   ,RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE())
			   ,TOTAL_RECORDS = @header_record_counts
			   ,ENTRYDT = GETDATE()
			WHERE PROC_NAME = @Procedure_Name
			AND END_DT IS NULL;

			IF (XACT_STATE() = 1) BEGIN  
    			ROLLBACK TRANSACTION;
			END;
    
			SET XACT_ABORT OFF;
			RAISERROR(@error,15,-1);
		END CATCH;

		SET XACT_ABORT OFF;

		UPDATE WIPRO.dbo.EXT_SYS_RUNLOG
		SET END_DT = GETDATE()
		   ,RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE())
		   ,TOTAL_RECORDS = @header_record_counts
		   ,ENTRYDT = GETDATE()
		WHERE PROC_NAME = @Procedure_Name
		AND END_DT IS NULL;



SET NOCOUNT OFF;
