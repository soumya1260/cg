﻿CREATE PROCEDURE [dbo].[OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL]
	@TYPE_OF_RUN	CHAR(12) = 'ALL'	-- values 'ALL' or 'INCREMENTAL'
AS
/************************************************************************************************************************
CREATE DATE:	05/01/2024

AUTHOR:			Scott Waller

DESCRIPTION:	Collect all claims that fit into all the different types of Exclusions we have, and insert them into
				EDIFECS.dbo.OSS_CLAIM_EXCLUSION_HIST
				'ALL'			runs for ALL Claims.  It truncates the OSS_CLAIM_EXCLUSION_HIST table, and reviews ALL claims
				'INCREMENTAL'	runs for just the claims that have been modified or added to the Claims Header table
									since the last run date, which is stored in this table:
									EDIFECS.dbo.OSS_EXCLUSION_INCREMENTAL_DATES
				Lastly, there is a config table, EDIFECS.dbo.OSS_EXCLUSION_CONFIG.   In this table we store all 
					Soure Data Keys, and a binary flag for Acitive or Inactive.   Process only the SDK's flagged as active.

Modification History
====================
Date			Who				Description
--------------------------------------------------------------------------------------------------------------------------
08/20/2024		Scott Waller	RETM-732 Fix OSS Exclusions 9064 and 9074
								Excl 9064 is missing a inner join to EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS
									so it was including claims that belonged to non-active SDKs
								Excl 9076 needs to be changed to only INSTITUTIONAL claims

09/02/2024		Scott Waller	RETM-749 New Exclusion for SDK 40 Claims
								New Exclusion to capture SDK 40 P claims with a paid date prior to 4/26/2024 
								and Service Date of 2023.
								New Exclusion ID:  9077

09/03/2024		Scott Waller	RETM-741	Minor fix to the 9064 Exclusion.  The date comparison of 
								ClaimDim.BeginServiceDateKey to ProviderPreclusionList.ReinDate, and the problem lies with 
								some 3400 claims that have a NULL value for REINDATE.  The comparison is FALSE but should
								be true.   Adding a ISNULL(REINDATE, '21991231') to resolve.

09/12/2024		Scott Waller	RETM-753	Final fixes to the 9064 Exclusion.  Couldnt get them done in RETM-741 because 
								that ticket was bundled with RETM-749 and 749 had priority and had to be deployed before
								we got everything done for 741.   That is what RETM-753 is for.

**************************************************************************************************************************/	

	DECLARE	@TOTAL_RECORDS	INT    
			,@9070_ROWS		INT
			,@EXCL_DAYS		INT    
			,@REJ_EXCL_DAYS	INT    
			,@CURRENTDATE	DATETIME 
			,@PROC_NAME_STR	varchar(75)
	--DECLARE	@CURRENTDATE	varchar(8) = select CONVERT(VARCHAR, getdate(), 112)

	IF ( @TYPE_OF_RUN NOT IN ('ALL', 'INCREMENTAL') )
	BEGIN
		SET @TYPE_OF_RUN	= 'ALL'
	END

	SET	@PROC_NAME_STR = 'OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - ' + @TYPE_OF_RUN

	SELECT @CURRENTDATE = getdate()

	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES
		(@PROC_NAME_STR, '1', GETDATE(), NULL, NULL, 0,GETDATE() )    
		    
	TRUNCATE TABLE	EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS	-- this table contains all the claims that will be considered to be assigned to an Exclusion
	TRUNCATE TABLE	EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS		-- this table contains all the claims that are to be put into an exclusion
																			-- this sproc will MERGE the contents of this table into the OSS_CLAIM_EXCLUSION_HIST
																			--		table if we are doing an INCREMENTAL update


	IF @TYPE_OF_RUN = 'ALL'		-- running for ALL claims
	BEGIN	
		--TRUNCATE TABLE  EDIFECS.dbo.OSS_CLAIM_EXCLUSION_HIST		Moving this to the end of the process, before we insert into this table
		--															in case any part of this logic fails, we will still have all the 
		--															existing Exclusions in this table.

		INSERT INTO EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS
		SELECT	ch.SRC_DATA_KEY, ch.CLM_ID
		FROM	OSS.Staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
		WHERE	ch.FNLZ_CLM_IND = 'Y'
		AND		ch.SRC_DATA_KEY IN (SELECT SRC_DATA_KEY FROM EDIFECS.dbo.OSS_EXCLUSION_CONFIG WHERE ACTIVE = 1)	-- active SDK's only
	END

	IF @TYPE_OF_RUN = 'INCREMENTAL'
	BEGIN	
		INSERT	INTO EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS
		SELECT	ch.SRC_DATA_KEY, ch.CLM_ID
		FROM	OSS.Staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
		WHERE	ch.FNLZ_CLM_IND = 'Y'
		AND		ch.ETL_LOAD_DT_TM >= (SELECT LAST_INCREMENTAL_RUN_DATE FROM EDIFECS.dbo.OSS_EXCLUSION_INCREMENTAL_DATES)
		AND		ch.SRC_DATA_KEY IN (SELECT SRC_DATA_KEY FROM EDIFECS.dbo.OSS_EXCLUSION_CONFIG WHERE ACTIVE = 1)	-- active SDK's only
	END

	-- log the number of claims being considered
	SET @TOTAL_RECORDS = (SELECT	COUNT(*)	FROM EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS)

	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES
		('OSS_Exclusion_Build - #Claims being Considered', '1.1', GETDATE(), GETDATE(), 0, @TOTAL_RECORDS, GETDATE() )

	WAITFOR DELAY '00:00:10'	-- wait for 10 seconds so that the STEP 1.1 comes before STEP 2

-- update EXT_SYS_RUNLOG to help monitor progress
	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES
		('OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block', '2', GETDATE(), NULL, NULL, 0, GETDATE() )





-- Exclusion 9002
	INSERT INTO	EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9002,
			CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END 
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD	ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_DTL_ADJUD cd
		ON	cd.CLM_ID				= ch.CLM_ID
		AND	cd.SRC_DATA_KEY			= ch.SRC_DATA_KEY
	--where	ch.FNLZ_CLM_IND = 'Y'
	WHERE	cd.CPT_PROC_CD in ('0L6','$INT')    



											    
													    
-- Exclusion 9003	Invalid diagnsos code for     
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT DISTINCT cd.CLM_ID, cd.SRC_DATA_KEY, @CURRENTDATE, 9003, ' '     
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN	EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN	OSS.staging.SDO_MDQO_CLM_LN_DIAG_CD_ADJUD cd
		ON	cd.SRC_DATA_KEY			= ch.SRC_DATA_KEY
		AND	cd.CLM_ID				= ch.CLM_ID
	WHERE	cd.ICD_DIAGS_CD_DESC = 'INVALID DIAGNOSIS CODE'    
	OR		CHARINDEX('ZZZ', cd.ICD_DIAGS_CD) > 0 




---------------------------------------------------------------------------------
-- Discontinue Pursuit Exclusions    
--		Using the existing DP Excluions that are setup for 2012 and greater.
--		Using the new DP Exclusion, 9010, for all claims that are prior to 2012
	IF OBJECT_ID('TEMPDB..#DP_YR') <> 0    
		DROP TABLE #DP_YR    
															    
	CREATE TABLE #DP_YR (
		DP_YR CHAR(4),    
		EXCL_ID INT    	)    
											    
	INSERT INTO #DP_YR    
	SELECT  SUBSTRING(RTRIM(cntrl_txt),1,4),    
			CONVERT(INT,SUBSTRING(RTRIM(cntrl_txt),6,4))    
	FROM	WIPRO.dbo.EXT_SYS_CLM_JOBCNTRL    
	WHERE	SOURCEDATAKEY = 999999999    
	AND		CNTRL_STATUS = 'A'    
	AND		SUBSTRING(RTRIM(cntrl_txt),1,4) >= '2012'		-- new 04/2024 so that we can put all claims prior to 2012, into a single DP Exclusion 9010    
											    
	-- Append all claims where BeginServiceDatekey meets DP parameters    
	INSERT	INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT	ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, EXCL_ID, -- ' '     
			CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END 
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD	ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN #DP_YR D    
		ON	SUBSTRING(CONVERT(VARCHAR, ch.svc_start_dt, 112), 1, 4)		= D.DP_YR
		--ON SUBSTRING(CONVERT(CHAR, ch.SVC_START_DT),1,4) = D.DP_YR    
	WHERE	ch.FNLZ_CLM_IND = 'Y'

-- new 04/2024 so that we can put all claims prior to 2012, into a single DP Exclusion 9010 
	INSERT	INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT	ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9010, --' '    
			CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END 
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD	ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN #DP_YR D    
		ON	SUBSTRING(CONVERT(VARCHAR, ch.svc_start_dt, 112), 1, 4)		< '2012'
	WHERE	ch.FNLZ_CLM_IND = 'Y'




	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @@ROWCOUNT
	WHERE	PROC_NAME = 'OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block'
	AND		STEP = '2'
	AND		END_DT IS NULL

	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES
		('OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block', '3', GETDATE(), NULL, NULL, 0, GETDATE() )





-- Exclusion 9019
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS  
	SELECT	CLAIMID, SOURCEDATAKEY, cdate , excl,  claimtp 
	FROM   (SELECT	DISTINCT ch.CLM_ID as CLAIMID, ch.SRC_DATA_KEY as SOURCEDATAKEY, 
					@CURRENTDATE as cdate, 9019 as excl , ' ' as claimtp, ocs.claim_id as clmid  
			FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
			INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
				ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
				AND	claims.CLM_ID			= ch.CLM_ID
			LEFT JOIN WIPRO.dbo.outb_claim_status ocs 
				ON	ocs.claim_id	= ch.clm_id    
			WHERE	ch.FNLZ_CLM_IND = 'Y'
			AND		ch.SRC_DATA_KEY	= 50	-- Aug 2024
			AND		charindex('R',ch.CLM_ID) > 0    
			OR		charindex('A',ch.CLM_ID) > 0	) x
	WHERE x.clmid is null
 
 /* Aug 2024 commenting out - removing all SDK 30-specific logic
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT	CLAIMID, SOURCEDATAKEY, cdate , excl,  claimtp  
	FROM   (SELECT  DISTINCT ch.CLM_ID AS CLAIMID, ch.SRC_DATA_KEY AS SOURCEDATAKEY, 
					@CURRENTDATE as cdate, 9019 as excl, ' ' as claimtp , ocs.CLAIM_ID as clmid
			FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
			INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
				ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
				AND	claims.CLM_ID			= ch.CLM_ID
			LEFT JOIN WIPRO.dbo.outb_claim_status ocs 
				ON	ocs.CLAIM_ID	= ch.CLM_ID
	WHERE	ch.SRC_DATA_KEY		= 30 
	AND		ch.FNLZ_CLM_IND		= 'Y'
	AND		substring(ch.CLM_ID, 11, 2) <> '00') x
	WHERE	x.clmid is NULL
*/

	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	CLAIMID, SOURCEDATAKEY, cdate , excl,  claimtp  
	FROM   (SELECT  DISTINCT ch.CLM_ID as CLAIMID, ch.SRC_DATA_KEY as SOURCEDATAKEY,
					@CURRENTDATE as cdate, 9019 as excl, ' ' as claimtp , ocs.CLAIM_ID as clmid
			FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
			INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
				ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
				AND	claims.CLM_ID			= ch.CLM_ID
			LEFT JOIN WIPRO.dbo.outb_claim_status ocs 
				ON	ocs.CLAIM_ID	= ch.CLM_ID
			WHERE	ch.FREQ_CD		in ('7','8') ) x		
	WHERE	x.clmid is NULL





-- Exclusion 9026		dashes in diagnosis code resulting in wipro pointer bad files    
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT	DISTINCT ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9026, ' '     
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN	OSS.STAGING.SDO_MDQO_CLM_LN_DIAG_CD_ADJUD cd
		ON	cd.SRC_DATA_KEY			= ch.SRC_DATA_KEY
		AND	cd.CLM_ID				= ch.CLM_ID
	WHERE	CHARINDEX('-', cd.ICD_DIAGS_CD) > 0     

							    
    

-- Exclusion 9028		Institutional Bill Type 75X AND REVCD exists    
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT DISTINCT ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9028, ' '    
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_DTL_ADJUD cd
		ON	cd.src_data_key				= ch.SRC_DATA_KEY
		AND	cd.clm_id					= ch.CLM_ID
	WHERE	SUBSTRING(ch.FREQ_CD,1,2)	= '75'     
	AND		cd.CPT_PROC_CD				= 'R'    





-- Exclusion 9038		 Have header data but missing Claim detail data
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9038,
		CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
		END 
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD as ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	LEFT OUTER JOIN OSS.staging.SDO_MDQO_MED_CLM_DTL_ADJUD cd
		ON	cd.SRC_DATA_KEY			= ch.SRC_DATA_KEY
		AND	cd.CLM_ID				= ch.CLM_ID
	WHERE	cd.CLM_ID IS NULL    

-- was told to replace ClaimLineRevenueCodeDim table, and use the REVNU_CD column from the OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD
-- table.   But what is the condtion?   WHERE REVNU_CD IS NULL   ??
	INSERT INTO	EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT	c.CLM_ID, c.SRC_DATA_KEY, @CURRENTDATE, 9038,
			CASE c.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END    
	FROM OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD as C    
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= c.SRC_DATA_KEY
		AND	claims.CLM_ID			= c.CLM_ID
	INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_DTL_ADJUD as CD
		ON	CD.SRC_DATA_KEY		= C.SRC_DATA_KEY
		AND CD.CLM_ID			= C.CLM_ID
	LEFT OUTER JOIN EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS E
		on	E.SOURCEDATAKEY		= c.SRC_DATA_KEY
		and	E.claim_id			= C.CLM_ID
	WHERE	C.CLM_TY			= 'INSTITUTIONAL'
	AND		CD.REVNU_CD			IS NULL
	AND		E.claim_id			IS NULL		-- this is used so that we only insert these claims into 9038 Exclusion if they aren't already assigned another exclusion




-- update EXT_SYS_RUNLOG to help monitor progress
	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @@ROWCOUNT
	WHERE	PROC_NAME = 'OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block'
	AND		STEP = '3'
	AND		END_DT IS NULL

	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES
		('OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block', '4', GETDATE(), NULL, NULL, 0, GETDATE() )


								   
/* AUGUST 2024 commenting out - remove completely if this all tests successfully                          
-- Exclusion 9045		TETDM-753 Facets Claims - Claimdiagnosisdim - Multiple Primary DiagnosisCodes records    
--						NOTE:	the server struggled with the use of TEMP tables for this, so a temporary permanent
--								is being used.
	IF OBJECT_ID('dbo.excl_TETDM753', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_TETDM753
	END
				    
	CREATE TABLE dbo.excl_TETDM753    
	(  claimid varchar(20)    
		,sourcedatakey int    
		,DIAGNOSISTYPECODE char(5)    
		,SEQ_no int    
	)    
    
	INSERT INTO dbo.excl_TETDM753    
	SELECT cdiag.CLM_ID, cdiag.SRC_DATA_KEY, cdiag.CLM_LN_ID,
			ROW_NUMBER() OVER ( PARTITION BY cdiag.CLM_ID, cdiag.CLM_LN_ID ORDER BY cdiag.CLM_ID, cdiag.CLM_LN_ID)    
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN	OSS.staging.SDO_MDQO_CLM_LN_DIAG_CD_ADJUD cdiag
		ON	cdiag.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	cdiag.CLM_ID			= ch.CLM_ID
	WHERE	cdiag.SRC_DATA_KEY	= 30	    
	AND		cdiag.CLM_LN_ID		= 1 
																    
	CREATE NONCLUSTERED INDEX IDX_tetdm753_01
		ON dbo.excl_tetdm753 (SOURCEDATAKEY, CLAIMID) 
    
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT  DISTINCT C.CLM_ID, C.SRC_DATA_KEY, @CURRENTDATE, 9045, 
		CASE C.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
		END 
	FROM	dbo.excl_TETDM753 T    
	INNER JOIN	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD C
		ON	C.SRC_DATA_KEY	= T.sourcedatakey
		AND C.CLM_ID		= T.claimid
	WHERE	t.SEQ_NO > 1    
	AND		c.FNLZ_CLM_IND = 'Y'
*/   




-- Exclusion 9047		TETDM-850
	IF OBJECT_ID('TEMPDB..#tmplob_excl') <> 0    
			DROP TABLE #tmplob_excl    
    
	CREATE TABLE #tmplob_excl    
		(	LOBCode			VARCHAR(15)    )    
    
	INSERT INTO #tmplob_excl    
			(LOBCode)    
		SELECT  LOBCode    
		FROM    MDQOLib.dbo.LineofBusinessDim    
		WHERE	ProductType IN ('Commercial','RX','PDP')    
		AND		Active = 1    
		ORDER BY LOBCode    
    
	INSERT INTO #tmplob_excl    
		(LOBCode)    
		SELECT	LOBCode    
		FROM    MDQOLib.dbo.LineofBusinessDim    
		WHERE	substring(HCFACODE,1,1) = 'S'    
		AND		Active = 1    
		ORDER BY LOBCode    

	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT  DISTINCT ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9047,
		CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
		END 
	FROM #tmplob_excl T    
	INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
		ON	ch.MBR_ID = T.LOBCODE    
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID



							    

-- Exclusion Cleanup
/*	Scott Waller Jan 2021
	This logic was causing this to run for 16+ hours.
	I removed the concatenation logic of claimid + sdk, and separated them.
	Also switched from #temp tables to permanent "temp" tables also helped this process.
*/
	IF OBJECT_ID('dbo.excl_clm_adj', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_clm_adj
	END

	CREATE TABLE dbo.excl_clm_adj (    
		claim_id			varchar(20) NULL,
		sourcedatakey		int			NULL  )    

	INSERT INTO dbo.excl_clm_adj
	SELECT	claim_id, sourcedatakey
	FROM	EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	WHERE	excl_id = 9019    

	CREATE NONCLUSTERED INDEX IDX_clm_adj ON excl_clm_adj
		(claim_id asc, sourcedatakey asc)  ON [PRIMARY]
    
	DELETE	eceh     
	FROM	EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS eceh
	INNER JOIN excl_clm_adj a
		ON	a.claim_id		= eceh.claim_id
		AND	a.sourcedatakey	= eceh.SOURCEDATAKEY
	--where claim_id+'-'+convert(char,sourcedatakey) in (select claim_id from #clm_adj)    
	where	eceh.excl_id <> 9019    





-- Exclusion 8012		TETDM-1787	New exclusion 8012 for claims with LOB's 
--						TETDM-2298  'C54240970', 'C42644396', 'C45137428', 'UMISC0028042858'
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
		(claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type)
	SELECT	ch.clm_id, ch.src_data_key, @CURRENTDATE, 8012, 
		CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
		END 
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN MDQOLib.dbo.LineofBusinessDim lbd
		on	lbd.ProductType		= ch.PRODT_TY
		and	lbd.SourceDataKey	= ch.SRC_DATA_KEY
	WHERE	lbd.LOBCode			IN ('C54240970', 'C42644396', 'C45137428', 'UMISC0028042858')




-- update EXT_SYS_RUNLOG to help monitor progress
	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @@ROWCOUNT
	WHERE	PROC_NAME = 'OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block'
	AND		STEP = '4'
	AND		END_DT IS NULL

	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES
		('OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block', '5', GETDATE(), NULL, NULL, 0, GETDATE() )





-- Exclusion 9053		Termed Members with no Hplan.  
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9053, 
		CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
		END 
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
--	LEFT OUTER JOIN	edps_data.dbo.monthlymembershipdim b  
--		on	b.memberid				= c.MBR_ID 
--		and	b.SourceDataKey			= c.SRC_DATA_KEY
--		AND	c.SVC_START_DT			between	CAST(Convert(CHAR(8),b.BeginCoverageDateKey,112) as DATETIME) 
--									and		CAST(Convert(CHAR(8),b.EndCoverageDateKey,112) as DATETIME) 
--			b.begincoveragedatekey and b.endcoveragedatekey   
	WHERE	ch.SRC_DATA_KEY			= 50
	and		ch.CLM_STAT				= 'DENIED'
	AND		ch.CNTRCT_NUM			IS NULL
--	AND		b.HCFACode	IS NULL 

	UNION

	SELECT	ch.clm_id, ch.SRC_DATA_KEY, @CURRENTDATE, 9053, 
		CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
		END
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN MDQOLib.dbo.LineofBusinessDim lbd
		ON	lbd.ProductType		= ch.PRODT_TY
		AND	lbd.SourceDataKey	= ch.SRC_DATA_KEY
	WHERE	ch.SRC_DATA_KEY			= 50
	and		ch.CLM_STAT				= 'DENIED'
	AND		lbd.LOBCode NOT IN ('C54240970', 'C42644396', 'C45137428', 'UMISC0028042858')
	AND		( ch.CNTRCT_NUM	= 'UNKNOWN' OR ch.CNTRCT_NUM	LIKE '%-%' )

    UNION 

   	SELECT	ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9053, 
		CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
		END
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD	ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN MDQOLib.dbo.LineofBusinessDim lbd
		ON	lbd.ProductType		= ch.PRODT_TY
		AND	lbd.SourceDataKey	= ch.SRC_DATA_KEY
    WHERE	lbd.LOBCode			LIKE '%UNKNOWN%'






-- Exclusion 9056			TETDM-1827	Build New Exclusion for Member reimbursement claims for 4
--							specific providers  and SDK 50
	IF OBJECT_ID('dbo.excl_CDD_Providers', 'U') IS NOT NULL 
		DROP TABLE dbo.excl_CDD_Providers;

		
	CREATE TABLE dbo.excl_CDD_Providers
		(	SOURCEDATAKEY	INT,
			CLAIMID			VARCHAR(20) )

	INSERT INTO dbo.excl_CDD_Providers
	SELECT	ch.SRC_DATA_KEY, ch.CLM_ID
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	WHERE	ch.RNDRG_PROV_ID	IN ('QMP000003530784','QMP000003530785','QMP000004300591','QMP000003578016', 'DEFAULT00001')	-- this is the ProviderID
	        OR ch.RNDRG_PROV_ID LIKE '999999999%'

	CREATE NONCLUSTERED INDEX IDX_CDD_Providers ON	dbo.excl_CDD_Providers	--#CDD_Providers
		(sourcedatakey asc, claimid asc)  ON [PRIMARY]

/*	IF OBJECT_ID('dbo.excl_CDD_Vendors', 'U') IS NOT NULL 
		DROP TABLE dbo.excl_CDD_Vendors;

	CREATE TABLE dbo.excl_CDD_Vendors
		(	SOURCEDATAKEY	INT,
			CLAIMID			VARCHAR(20)		)

	INSERT INTO dbo.excl_CDD_Vendors
	SELECT	SOURCEDATAKEY,	CLAIMID
	FROM	EDPS_Data.dbo.CLAIMDETAILDIM
	WHERE	SOURCEDATAKEY	= 50
	AND		CLAIMLINEID		= '0001'
	AND		VENDORID		IN ('QMP000003530784', 'QMP000003530785', 'QMP000004300591', 'QMP000003578016')

	CREATE NONCLUSTERED INDEX IDX_CDD_Vendors ON	dbo.excl_CDD_Vendors	--#CDD_Vendors
		(sourcedatakey asc, claimid asc)  ON [PRIMARY]
*/
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT distinct	ch.CLM_ID, cdd.SOURCEDATAKEY, @CURRENTDATE, '9056',
					CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
										WHEN 'PROFESSIONAL'		THEN 'P' 
										ELSE 'D'
					END
		 FROM	dbo.excl_CDD_Providers cdd		
		 INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch 
			ON	ch.src_data_key		= cdd.SOURCEDATAKEY
			AND	ch.CLM_ID			= cdd.CLAIMID 
		INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
			ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
			AND	claims.CLM_ID			= ch.CLM_ID
/*	UNION
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
			 SELECT  DISTINCT
				  A.CLAIM_ID, A.SOURCEDATAKEY, @CURRENTDATE,   '9056' , a.CLAIM_TYPE
			 FROM WIPRO.dbo.OUTB_CLAIM_STATUS AS A 
			 INNER JOIN	dbo.excl_CDD_Vendors B		--#CDD_Vendors AS B 
				ON	B.SOURCEDATAKEY		= A.SOURCEDATAKEY 
				AND B.CLAIMID			= A.CLAIM_ID
			 WHERE	A.STAT_REJ_REA_ID = '90170'
			 AND	A.SOURCEDATAKEY = 50
*/	
	IF OBJECT_ID('dbo.excl_CDD_Vendors', 'U') IS NOT NULL 
		DROP TABLE dbo.excl_CDD_Vendors;

	IF OBJECT_ID('dbo.excl_CDD_Providers', 'U') IS NOT NULL 
		DROP TABLE dbo.excl_CDD_Providers;

/* Aug 2024 remove any SDK 30 specific logic
-- Exclusion 9056 con't			Exclusion for member reimbursement claims SDK30
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	DISTINCT ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9056, 'P'
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	WHERE	ch.src_data_key		= 30
	AND		ch.CLM_TY			= 'PROFESSIONAL'
	AND		ch.RNDRG_PROV_ID	= 'DMR000000001'
*/



-- update EXT_SYS_RUNLOG to help monitor progress
	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @@ROWCOUNT
	WHERE	PROC_NAME = 'OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block'
	AND		STEP = '5'
	AND		END_DT IS NULL






-- Exclusion 8020

-- Scott Waller Sept 30, 2021  (as part of TETDM-2587)
--		added the temp table logic due to terrible performance
--		I know it looks hideous, but having all 3 conditions in the WHERE clause was 
--		causing this to run for 24+ hours
--		The LEN function, any function for that matter, in WHERE clauses causes SQL Server to ignore indexes

	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
			(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES('OSS_CLAIM_EXCLUSION - insert 8020 (bottleneck)'    
			, '5.1', GETDATE(), NULL, NULL, 0, GETDATE() ) 

-- RETM-160	we keep filling the tempdb, so I am switching from temp to perm tables
	IF OBJECT_ID('dbo.hold_claimdetaildim_8020', 'U') IS NOT NULL 
		DROP TABLE dbo.hold_claimdetaildim_8020; 

	SELECT	distinct cdd.SRC_DATA_KEY as SOURCEDATAKEY, cdd.CLM_ID as CLAIMID, cdd.CLM_LN_ID as CLAIMLINEID, 
			cdd.CPT_PROC_CD as PROCEDURECODE, 0 as LEN_PROCEDURECODE
	INTO	hold_claimdetaildim_8020
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_DTL_ADJUD cdd 
		ON	cdd.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	cdd.CLM_ID				= ch.CLM_ID
--	INNER JOIN	OSS.staging.SDO_MDQO_CLM_ICD_PROC_CD_ADJUD cpc		No need to join.  Tracy says to use cpt_proc_cd in the DTL table
--		ON	cpc.SRC_DATA_KEY		= cdd.SRC_DATA_KEY
--		AND	cpc.CLM_ID				= cdd.CLM_ID
	WHERE	ch.SRC_DATA_KEY			= 50	--IN (30,50)	Aug 2024
	AND		cdd.CLM_LN_ID			= '1'

	UPDATE	hold_claimdetaildim_8020
	SET		LEN_PROCEDURECODE = ISNULL(LEN(PROCEDURECODE), 0)

	DELETE	FROM hold_claimdetaildim_8020
	WHERE	LEN_PROCEDURECODE <= 5

	--CREATE NONCLUSTERED INDEX IDX_On_Temp_Table ON #hold_claimdetaildim_8020
	CREATE NONCLUSTERED INDEX IDX_On_Temp_Table ON hold_claimdetaildim_8020
		(sourcedatakey asc, claimid asc)  ON [PRIMARY]

	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT DISTINCT ch.CLM_ID, ch.SRC_DATA_KEY , @CURRENTDATE, 8020, 
			CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END
	FROM OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	JOIN hold_claimdetaildim_8020 cdd 
		ON	cdd.CLAIMID			= ch.CLM_ID
		AND cdd.SOURCEDATAKEY	= ch.SRC_DATA_KEY
	WHERE	ch.FNLZ_CLM_IND = 'Y'

	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @@ROWCOUNT
		,ENTRYDT = GETDATE()    
	WHERE	PROC_NAME = 'OSS_CLAIM_EXCLUSION - insert 8020 (bottleneck)'  
	AND		STEP = '5.1'
	AND		END_DT IS NULL

	IF OBJECT_ID('dbo.hold_claimdetaildim_8020', 'U') IS NOT NULL 
		DROP TABLE dbo.hold_claimdetaildim_8020; 
  -- end of rewrite for 8020 Exclusion as part of the TETDM-2587 ticket.




-- Exclusion 8022
--				This logic is used incase we start bringing recently changed claims (aka adjustments) (Kevin usually wants these)
--				that have a beginservicedatekey earlier than our ClaimStartDate in the EDPS_Data.dbo.eds_bidw_claimstartdate
--				We want them in our system, but in an Exclusion so that they dont get submitted.
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT DISTINCT ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 8022, 
			CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	WHERE	ch.SVC_START_DT < (	SELECT	claimstartdate	FROM EDPS_Data.dbo.eds_bidw_claimstartdate )





-----------------------------------------------------------------------------------------------------------------
-- Exclusion 9064			RETM-53 Preclusion Provider Exclusion
--							Again, temp tables were struggling, so permanent "temp" tables are being used.
--
-- need a OSS version of PROVIDERPRECLUSIONLIST table
-----------------------------------------------------------------------------------------------------------------
	IF OBJECT_ID('dbo.excl_hold_providerpreclusionlist', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_providerpreclusionlist
	END

	-- I am doing this because the PROVIDERPRECLUSIONLIST does not have any indexes;  it'll table scan and run forever

-- RETM-753	additional 9064 fixes	Sept 2024 Scott Waller
--	SELECT	*
	SELECT	NPI, ACTIVE, CLMREJECTDATE, ISNULL(REINDATE, '21991231') AS REINDATE
	INTO	dbo.excl_hold_providerpreclusionlist
	FROM	edps_data.dbo.PROVIDERPRECLUSIONLIST
	WHERE	ACTIVE = 1

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_providerpreclusionlist (NPI ASC)

	IF OBJECT_ID('TEMPDB..#hold_claimstoexclude') <> 0
		DROP TABLE #hold_claimstoexclude

	IF OBJECT_ID('dbo.excl_hold_claimstoexclude', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_claimstoexclude
	END

-- first use the RNDRG_PROV_NPI column value
	SELECT	DISTINCT a.SRC_DATA_KEY, a.CLM_ID, a.FRM_TY_CD as FORMTYPECODE
	INTO	dbo.excl_hold_claimstoexclude
	FROM	OSS.Staging.SDO_MDQO_MED_CLM_HDR_ADJUD a	
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= a.SRC_DATA_KEY
		AND	claims.CLM_ID			= a.CLM_ID
	INNER JOIN dbo.excl_hold_providerpreclusionlist b
		ON	b.NPI					= a.RNDRG_PROV_NPI	
	WHERE	( (a.SVC_START_DT		>= b.CLMREJECTDATE) AND	
			  (a.SVC_START_DT		< b.REINDATE) )			

-- next, use the PROV_BILL_ENTITY_NPI column value
	INSERT INTO dbo.excl_hold_claimstoexclude
	SELECT	DISTINCT a.SRC_DATA_KEY, a.CLM_ID, a.FRM_TY_CD as FORMTYPECODE
	FROM	OSS.Staging.SDO_MDQO_MED_CLM_HDR_ADJUD a	
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= a.SRC_DATA_KEY
		AND	claims.CLM_ID			= a.CLM_ID
	INNER JOIN dbo.excl_hold_providerpreclusionlist b
		ON	b.NPI					= a.PROV_BILL_ENTTY_NPI	
	WHERE	( (a.SVC_START_DT		>= b.CLMREJECTDATE) AND	
			  (a.SVC_START_DT		< b.REINDATE) )	

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_claimstoexclude (SRC_DATA_KEY ASC, CLM_ID ASC)

--	RETM-753 DTL level data no longer needed;  the logic was below, but has been removed.

	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT DISTINCT e.CLM_ID, e.SRC_DATA_KEY, @CURRENTDATE, 9064 as EXCL_ID, 
					CASE e.FORMTYPECODE 
						WHEN 'H'	THEN 'P' 
						WHEN 'U'	THEN 'I' 
						ELSE formtypecode 
					END AS ClaimType
	FROM   dbo.excl_hold_claimstoexclude e

/*	leave the tables so that we can review the contents post-run for troubleshooting
	IF OBJECT_ID('dbo.excl_hold_providerpreclusionlist', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_providerpreclusionlist
	END

	IF OBJECT_ID('dbo.excl_hold_claimstoexclude', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_claimstoexclude
	END
*/
-- end RETM-53







-- Exclusion 9070			RETM-154 identify all claims with NO PRIMARY DX CODES
--							these need to be put in some exclusion, using 9070 
--							(using perm temp tables again, in place of actual #temp tables)
	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES('OSS_CLAIM_EXCLUSION - Exclude Claims with no Prim DX'    
		, '5.2', GETDATE(), NULL, NULL, 0, GETDATE() ) 

-- we are out of tempdb disk space for 4+ weeks now, so I am creating a work around, using physical tables instead of temp tables
	IF OBJECT_ID('dbo.excl_hold_claims', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_claims
	END

-- first, collect all claims that aren't in an exclusion already, and available for submission.
	SELECT	ch.SRC_DATA_KEY as sourcedatakey, ch.CLM_ID as claimid, 0 as PRIMDIAGCODES, 0 as OTHERDIAGCODES
	INTO	dbo.excl_hold_claims
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	LEFT OUTER JOIN EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS b
		ON	b.SourceDataKey		= ch.SRC_DATA_KEY
		AND	b.claim_id			= ch.CLM_ID
-- RETM-160
	AND		((b.claim_id	IS NULL) OR (b.claim_id IS NOT NULL) AND (b.EXCL_ID = 9019) )
-- end RETM-160
	GROUP BY ch.SRC_DATA_KEY, ch.CLM_ID

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_claims (sourcedatakey ASC, claimid ASC)

	IF OBJECT_ID('dbo.excl_hold_primdiagcodes', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_primdiagcodes
	END
	
	SELECT	a.SOURCEDATAKEY, a.CLAIMID, ISNULL(count(*), 0) as PRIMDIAGCODES
	INTO	dbo.excl_hold_primdiagcodes
	FROM	dbo.excl_hold_claims a
	INNER JOIN OSS.staging.SDO_MDQO_CLM_DIAG_CD_ADJUD b
		on	b.SRC_DATA_KEY		= a.SOURCEDATAKEY
		and	b.CLM_ID			= a.CLAIMID
	WHERE	b.DIAGS_TY_CD		= 'P'
	group by a.SOURCEDATAKEY, a.CLAIMID

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_primdiagcodes (sourcedatakey ASC, claimid ASC)

	IF OBJECT_ID('dbo.excl_hold_otherdiagcodes', 'U') IS NOT NULL 
	BEGIN	
		DROP TABLE dbo.excl_hold_otherdiagcodes
	END

	SELECT	a.SOURCEDATAKEY, a.CLAIMID, ISNULL(count(*), 0) as OTHERDIAGCODES
	INTO	dbo.excl_hold_otherdiagcodes
	FROM	dbo.excl_hold_claims a
	INNER JOIN OSS.staging.SDO_MDQO_CLM_DIAG_CD_ADJUD b
		on	b.SRC_DATA_KEY		= a.SOURCEDATAKEY
		and	b.CLM_ID			= a.CLAIMID
	WHERE	b.DIAGS_TY_CD		<> 'P'
	GROUP BY a.SOURCEDATAKEY, a.CLAIMID

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_otherdiagcodes (sourcedatakey ASC, claimid ASC)

-- update with Primary Diag Code counts
	UPDATE	dbo.excl_hold_claims
	SET		dbo.excl_hold_claims.PRIMDIAGCODES = b.PRIMDIAGCODES
	FROM	dbo.excl_hold_claims a
	INNER JOIN dbo.excl_hold_primdiagcodes b
		on	b.SOURCEDATAKEY		= a.SOURCEDATAKEY
		and	b.CLAIMID			= a.CLAIMID

-- update with Other Diag Code counts
	UPDATE	dbo.excl_hold_claims
	SET		dbo.excl_hold_claims.OTHERDIAGCODES = b.OTHERDIAGCODES
	FROM	dbo.excl_hold_claims a
	INNER JOIN dbo.excl_hold_otherdiagcodes b
		on	b.SOURCEDATAKEY		= a.SOURCEDATAKEY
		and	b.CLAIMID			= a.CLAIMID

-- finally, the INSERT statements
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	DISTINCT a.CLAIMID, a.SOURCEDATAKEY, @CURRENTDATE, 9070,
			CASE b.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END
	FROM	dbo.excl_hold_claims a
	INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD b
		on	b.SRC_DATA_KEY		= a.SOURCEDATAKEY
		and b.CLM_ID			= a.CLAIMID
	WHERE	a.PRIMDIAGCODES		= 0
	AND		a.OTHERDIAGCODES	<> 0
	ORDER BY a.SOURCEDATAKEY, a.CLAIMID

	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	DISTINCT a.CLAIMID, a.SOURCEDATAKEY, @CURRENTDATE, 9070,
			CASE b.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END
	FROM	dbo.excl_hold_claims a
	INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD b
		on	b.SRC_DATA_KEY		= a.SOURCEDATAKEY
		and b.CLM_ID			= a.CLAIMID
	WHERE	PRIMDIAGCODES		= 0
	AND		OTHERDIAGCODES		= 0 
	ORDER BY a.SOURCEDATAKEY, a.CLAIMID

-- RETM-206 begin
	IF OBJECT_ID('dbo.excl_hold_claim_lines', 'U') IS NOT NULL 
	BEGIN	
		DROP TABLE dbo.excl_hold_claim_lines
	END

	SELECT	a.SRC_DATA_KEY as SOURCEDATAKEY, a.CLM_ID as CLAIMID, a.CLM_LN_ID as CLAIMLINEID, 0 as LINEDXCODES
	INTO	dbo.excl_hold_claim_lines	
	FROM	OSS.dbo.SDO_MDQO_MED_CLM_DTL_ADJUD a
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= a.SRC_DATA_KEY
		AND	claims.CLM_ID			= a.CLM_ID
	INNER JOIN dbo.excl_hold_claims b
		ON	b.sourcedatakey			= a.SRC_DATA_KEY
		AND	b.claimid				= a.CLM_ID
	GROUP BY a.SRC_DATA_KEY, a.CLM_ID, a.CLM_LN_ID

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_claim_lines (sourcedatakey ASC, claimid ASC, claimlineid ASC)

	IF OBJECT_ID('dbo.excl_hold_claim_lines_dxs', 'U') IS NOT NULL 
	BEGIN	
		DROP TABLE dbo.excl_hold_claim_lines_dxs
	END

	SELECT	a.SRC_DATA_KEY as SOURCEDATAKEY, a.CLM_ID as CLAIMID, a.CLM_LN_ID as CLAIMLINEID, COUNT(a.ICD_DIAGS_CD) AS LINEDXCODES
	INTO	dbo.excl_hold_claim_lines_dxs	
	FROM	OSS.staging.SDO_MDQO_CLM_LN_DIAG_CD_ADJUD a
	INNER JOIN dbo.excl_hold_claims b
		ON	b.sourcedatakey			= a.SRC_DATA_KEY
		AND	b.claimid				= a.CLM_ID
	GROUP BY a.SRC_DATA_KEY, a.CLM_ID, a.CLM_LN_ID

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_claim_lines_dxs (sourcedatakey ASC, claimid ASC, claimlineid ASC)

	UPDATE	dbo.excl_hold_claim_lines
	SET		LINEDXCODES		= b.LINEDXCODES
	FROM dbo.excl_hold_claim_lines a 
	JOIN dbo.excl_hold_claim_lines_dxs b
		ON	b.SOURCEDATAKEY		= a.SOURCEDATAKEY
		AND b.CLAIMID			= a.CLAIMID
		AND	b.CLAIMLINEID		= a.CLAIMLINEID

	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	DISTINCT a.CLAIMID, a.SOURCEDATAKEY,  @CURRENTDATE, 9070,
			CASE b.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END
	FROM	dbo.excl_hold_claim_lines a
	INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD b
		on	b.SRC_DATA_KEY		= a.SOURCEDATAKEY
		and b.CLM_ID			= a.CLAIMID
	WHERE	a.LINEDXCODES		= 0
	AND		b.CLM_TY		= 'PROFESSIONAL'	-- currently Tracy requested JUST Professional claims be put into the exclusion
												-- technically, we should eliminate the non-PROF claims upstream, but i suspect
												-- they are going to eventually want the non-PROF claims in this exclusion
-- RETM-206 end

-- we are out of tempdb disk space for 4+ weeks now, so I am creating a work around, using physical tables instead of temp tables
	IF OBJECT_ID('dbo.excl_hold_claims', 'U') IS NOT NULL 
	BEGIN	
		DROP TABLE dbo.excl_hold_claims
	END

	IF OBJECT_ID('dbo.excl_hold_primdiagcodes', 'U') IS NOT NULL 
	BEGIN	
		DROP TABLE dbo.excl_hold_primdiagcodes
	END

	IF OBJECT_ID('dbo.excl_hold_otherdiagcodes', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_otherdiagcodes
	END

	IF OBJECT_ID('dbo.excl_hold_claim_lines', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_claim_lines
	END

	IF OBJECT_ID('dbo.excl_hold_claim_lines_dxs', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_claim_lines_dxs
	END

	SET @9070_ROWS	= (	  SELECT	COUNT(*)	
						  FROM		EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
						  WHERE		EXCL_ID = 9070)

	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT			= GETDATE()	    
		,RUN_MINUTES	= DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS	= @9070_ROWS
		,ENTRYDT		= GETDATE()    
	WHERE PROC_NAME = 'OSS_CLAIM_EXCLUSION - Exclude Claims with no Prim DX'    
	AND		STEP = '5.2'
	AND		END_DT IS NULL
-- end RETM-154, RETM-160




-- update EXT_SYS_RUNLOG to help monitor progress
	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES
		('OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block', '6', GETDATE(), NULL, NULL, 0, GETDATE() )





-- Exclusion 9071				RETM-435  identify all claims with no Primary DX codes in Sequence 01, 
--								but have primary dx codes in any other Sequence
	IF OBJECT_ID('TEMPDB..#hold_retm_435_claims') <> 0    
		DROP TABLE #hold_retm_435_claims  

	SELECT	DISTINCT a.CLM_ID as CLAIMID, a.ICD_DIAGS_CD as DIAGNOSISCODE, a.ICD_DIAGS_CD_VRSN as DIAGNOSISTYPECODE, a.DIAGS_SEQ as SEQUENCE, 
			a.ICD_DIAGS_CD_DESC as DIAGNOSISDESC, a.SRC_DATA_KEY as SourceDataKey, a.ETL_LOAD_DT_TM as LoadDateKey, 
			' ' as Active, ' ' as Deleted
	INTO	#hold_retm_435_claims
	FROM	OSS.staging.SDO_MDQO_CLM_DIAG_CD_ADJUD a
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= a.SRC_DATA_KEY
		AND	claims.CLM_ID			= a.CLM_ID
	LEFT OUTER JOIN EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS b
		ON	b.claim_id			= a.CLM_ID
		AND	b.SOURCEDATAKEY		= a.SRC_DATA_KEY
	WHERE	b.claim_id IS NULL
	AND		a.SRC_DATA_KEY		= 50
	AND		(a.DIAGS_SEQ <> 1 and a.DIAGS_TY_CD = 'P')  

	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	DISTINCT a.CLAIMID, a.SOURCEDATAKEY,  @CURRENTDATE, 9071,
			CASE b.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END
	FROM	#hold_retm_435_claims a
	INNER JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD b
		ON	b.CLM_ID			= a.CLAIMID
		AND	b.SRC_DATA_KEY		= a.SourceDataKey
-- end RETM-435

/* Aug 2024 remove SDK 30 specific logic
-- Exclusion 9071 con't			RETM-179 Exclude >= 2023 Leon claims  (SDK 30)
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	DISTINCT ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9071,
		CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
		END 
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	WHERE	ch.SRC_DATA_KEY			= 30
	AND		ch.SVC_START_DT			>= '20230101'
-- end RETM-179
*/



-- Exclusion 9073		OSS Claims with CLM_TY = U-UNK
	INSERT INTO	EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	ch.CLM_ID, ch.SRC_DATA_KEY, @CURRENTDATE, 9073,
			CASE ch.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END 
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD	ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	WHERE	ch.CLM_TY			= 'U-UNK'





/*	--------------------------------------------------------------------------------------------------
	--------------------------------------------------------------------------------------------------
	The next Exclusions:  9019, 9060 and the complex 9067
	were all part of the Encounter Exclusion sproc, EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS sproc
	that ran separately from the "main" Exclusion sproc.  
	It's not worth having the 2 separate sprocs.    I have combined them into this single one.
    --------------------------------------------------------------------------------------------------
	--------------------------------------------------------------------------------------------------
*/
-- Encounter Exclusion 9019			Adjustment claim exclusions
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
		(claim_id, SOURCEDATAKEY, BATCH_RUN_DT,EXCL_ID, claim_type)
	SELECT claimnum, sdk, cdate,excl, ClaimType 
    FROM ( 	SELECT	DISTINCT ecd.CLM_ID as claimnum, ecd.SRC_DATA_KEY as sdk, @CURRENTDATE as cdate, 
				'9019' as excl, 
				CASE ecd.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
									WHEN 'PROFESSIONAL'		THEN 'P' 
									ELSE 'D'
				END AS ClaimType, 
				ocs.CLAIM_ID  
			FROM OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD	ecd
			INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
				ON	claims.SRC_DATA_KEY		= ecd.SRC_DATA_KEY
				AND	claims.CLM_ID			= ecd.CLM_ID
			LEFT JOIN WIPRO.dbo.OUTB_CLAIM_STATUS ocs 
				ON	ocs.CLAIM_ID			= ecd.CLM_ID
				AND ocs.SOURCEDATAKEY		= ecd.SRC_DATA_KEY
			WHERE	ecd.SRC_DATA_KEY		IN (140, 142, 144)
			AND		ecd.FREQ_CD				IN ('7','8')
			AND		ecd.CLM_TY				IN ('PROFESSIONAL','INSTITUTIONAL') ) x
	WHERE	x.CLAIM_ID				IS NULL





-- Encounter Exclusion 9060			Exlcusion for Encounter Claim lines that don't have a Line 1 in the detail table
	IF OBJECT_ID('TEMPDB..#hold_encounter_claims') <> 0    
		DROP TABLE #hold_encounter_claims   

	IF OBJECT_ID('TEMPDB..#hold_encounter_claims_l1') <> 0    
		DROP TABLE #hold_encounter_claims_l1

	SELECT	DISTINCT ch.CLM_ID as claimnum, 
			CASE ch.CLM_TY	WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
			END AS ClaimType,
			ch.SRC_DATA_KEY as SOURCEDATAKEY
	INTO	#hold_encounter_claims
	FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= ch.SRC_DATA_KEY
		AND	claims.CLM_ID			= ch.CLM_ID
	WHERE	ch.SRC_DATA_KEY			IN (140, 142, 144)
	AND		ch.ENCNTR_SRC_VENDR_NM	IN ('WELLMED', 'ADVOCATE', 'SUPERIORVISION')

	CREATE NONCLUSTERED INDEX tIndex ON #hold_encounter_claims (claimnum ASC)

	SELECT	DISTINCT a.CLM_ID as claimnum, a.CLM_LN_ID as ClaimLineNum, 
			CASE b.CLM_TY	WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
			END AS ClaimType,
			a.SRC_DATA_KEY as SOURCEDATAKEY
	INTO	#hold_encounter_claims_l1
	FROM	OSS.staging.SDO_MDQO_MED_CLM_DTL_ADJUD a
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= a.SRC_DATA_KEY
		AND	claims.CLM_ID			= a.CLM_ID
	INNER JOIN	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD b
		ON	b.SRC_DATA_KEY			= a.SRC_DATA_KEY
		AND	b.CLM_ID				= a.CLM_ID
	WHERE	a.SRC_DATA_KEY			in (140, 142, 144)
	AND		b.ENCNTR_SRC_VENDR_NM	in ('WELLMED', 'ADVOCATE', 'SUPERIORVISION')
	AND		a.CLM_LN_ID				= 1

	CREATE NONCLUSTERED INDEX tIndex ON #hold_encounter_claims_l1 (claimnum ASC)

	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT DISTINCT a.ClaimNum, a.SOURCEDATAKEY,  @CURRENTDATE, '9060', a.ClaimType
	FROM	#hold_encounter_claims a
	WHERE	a.ClaimNum not in (	SELECT	b.ClaimNum
								FROM	#hold_encounter_claims_l1 b )



-- update EXT_SYS_RUNLOG to help monitor progress
	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
		,TOTAL_RECORDS = @@ROWCOUNT
	WHERE	PROC_NAME = 'OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block'
	AND		STEP = '6'
	AND		END_DT IS NULL

	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES
		('OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block', '7', GETDATE(), NULL, NULL, 0, GETDATE() )




-- Encounter Exclusion 9067
---------------------------------------------------------------------------------------------------------------------------------------
-- RETM-135 Identify encounter claims with duplicate claim line rows
--		1. Collect Encounter claim headers into a temp table
--		2. create another temp table that holds the claim headers that ARENT already in an Exclusion
--		*** NOTE:   Tracy Black advised that we want these claims in an EXCLUSION even if they are already in another exclusion
--					so I will put the same claims into the #hold_encounters_not_excluded table, but I'll comment out 
--					the logic and leave it here, incase we come back to it and need to put it in.
--		3. create a temp table for all claim headers in the Step 2 temp table, whose claimlinenum has 2 or more occurrances
--		4. For the distinct ClaimNum's in the temp table from Step 3, insert these claims into the Exclusion table for 9067 exclusion
---------------------------------------------------------------------------------------------------------------------------------------
	IF OBJECT_ID('tempDB..#hold_encounter_headers') IS NOT NULL
		DROP TABLE #hold_encounter_headers

    ;WITH EncounterClaimBasket AS 
    (	SELECT	*
		FROM ( SELECT
					e.CLM_ID				as ClaimNum , 
                    e.SRC_DATA_KEY			as sourcedatakey , 
					e.ENCNTR_SRC_VENDR_NM	as Sourcedesc,
					e.MBR_ID				as memberid,
					1						as claimlinenum,
					e.SVC_START_DT			as beginservicedatekey,
					CASE e.CLM_TY	WHEN 'INSTITUTIONAL'	THEN 'I' 
									WHEN 'PROFESSIONAL'		THEN 'P' 
									ELSE 'D'
					END AS ClaimType,
                    latest = ROW_NUMBER() OVER (PARTITION BY e.clm_id, e.mbr_id, e.src_data_key ORDER BY  e.clm_id DESC, e.src_data_key)
                FROM	OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD e
				INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
					ON	claims.SRC_DATA_KEY		= e.SRC_DATA_KEY
					AND	claims.CLM_ID			= e.CLM_ID
				INNER JOIN EDS_Audit.dbo.EDS_Encounter_SourceDesc s
					ON	e.ENCNTR_SRC_VENDR_NM = s.SourceDesc
					AND CONVERT(VARCHAR, e.SVC_START_DT, 112) BETWEEN startdate AND enddate
                WHERE	1 = 1
				AND		e.SRC_DATA_KEY	IN (140, 142, 144) ) sub
            WHERE sub.latest = 1
    )

	SELECT	SUBSTRING(CONVERT(VARCHAR, a.BeginServiceDateKey, 112), 1, 4) as BeginServiceDateKeyYear,
			--SUBSTRING(CONVERT(CHAR, a.BeginServiceDateKey),1,4) as BeginServiceDateKeyYear,
			a.sourcedatakey, a.claimnum, a.SourceDesc,
			a.beginservicedatekey, a.ClaimType
	INTO	#hold_encounter_headers
	FROM	EncounterClaimBasket a

	IF OBJECT_ID('tempDB..#hold_encounters_not_excluded') IS NOT NULL
	BEGIN
		DROP TABLE #hold_encounters_not_excluded
	END

	-- do not join to the EXT_CLAIM_EXCLUSION_HIST table for now, per Tracy Black
	-- what this means is that some claims that are already in the EXT_CLAIM_EXCLUSION_HIST table
	-- under  a different exclsuion id, will be put in again under the new 9066 exclusion.
	-- This is needed and requested by the BA team (Tracy Black)
	SELECT	a.*
	INTO	#hold_encounters_not_excluded
	FROM	#hold_encounter_headers	a
--		LEFT OUTER JOIN WIPRO.dbo.ext_claim_exclusion_hist b
--			ON	b.sourcedatakey		= a.sourcedatakey
--			AND	b.claim_id			= a.ClaimNum
--		WHERE	b.claim_id IS NULL
-- with the LEFT OUTER JOIN and the WHERE claus removed, ALL the claims in #hold_encounters_headers will
-- be put into #hold_encounters_not_excluded.
	CREATE NONCLUSTERED INDEX tIndex ON #hold_encounters_not_excluded (claimnum)

	IF OBJECT_ID('tempDB..#hold_encounters_w_dup_lines') IS NOT NULL
	BEGIN
		DROP TABLE #hold_encounters_w_dup_lines
	END

	SELECT	a.SRC_DATA_KEY as SourceDataKey, ch.ENCNTR_SRC_VENDR_NM as SourceDesc, a.clm_id as ClaimNum, a.CLM_LN_ID as ClaimLineNum, 
			CASE ch.CLM_TY	WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
			END AS ClaimType,
			count(*) as LineNumCount
	INTO	#hold_encounters_w_dup_lines
	FROM	OSS.staging.SDO_MDQO_MED_CLM_DTL_ADJUD a
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= a.SRC_DATA_KEY
		AND	claims.CLM_ID			= a.CLM_ID
	INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD ch
		ON	ch.SRC_DATA_KEY			= a.SRC_DATA_KEY
		AND	ch.CLM_ID				= a.CLM_ID
	INNER JOIN #hold_encounters_not_excluded b
		on	b.SourceDataKey		= a.SRC_DATA_KEY
		and	b.ClaimNum			= a.CLM_ID
	GROUP BY a.SRC_DATA_KEY, ch.ENCNTR_SRC_VENDR_NM, a.clm_id, a.CLM_LN_ID, ch.CLM_TY
	HAVING	count(*) > 1

	CREATE NONCLUSTERED INDEX tIndex ON #hold_encounters_w_dup_lines (claimnum)

	INSERT INTO		EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT DISTINCT a.ClaimNum, 4 ,  @CURRENTDATE, '9067', a.ClaimType
	FROM	#hold_encounters_w_dup_lines a
-- end RETM-135
/*	--------------------------------------------------------------------------------------------------
	--------------------------------------------------------------------------------------------------
	end of Exclusion Logic that used to be in the separate EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS sproc
    --------------------------------------------------------------------------------------------------
	-------------------------------------------------------------------------------------------------- 
*/



-- update EXT_SYS_RUNLOG to help monitor progress
	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @@ROWCOUNT
	WHERE	PROC_NAME = 'OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block'
	AND		STEP = '7'
	AND		END_DT IS NULL

	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES
		('OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block', '8', GETDATE(), NULL, NULL, 0, GETDATE() )




--------------------------------------------------------------------------------------------------
-- Exclusion 9074 / 9075 / 9076
-- New for Aug 2024.	Exclude claims that do not have any rows of data in 5 key tables.
--------------------------------------------------------------------------------------------------
	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG    
		(PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
	VALUES
		('OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Tables with missing data', '7.1', GETDATE(), NULL, NULL, 0, GETDATE() )


	IF OBJECT_ID('TEMPDB..#hold_claim_table_row_counts') <> 0
		DROP TABLE #hold_claim_table_row_counts

		-- 
	SELECT	DISTINCT	a.SRC_DATA_KEY, a.CLM_ID, CONVERT(VARCHAR(15),b.CLM_TY) as CLM_TY,
			(SELECT COUNT(*) FROM OSS.STAGING.SDO_MDQO_MED_CLM_DTL_ADJUD b WHERE b.CLM_ID = a.CLM_ID) as sdo_mdqo_med_clm_dtl_adjud,
			(SELECT COUNT(*) FROM OSS.STAGING.SDO_MDQO_CLM_DIAG_CD_ADJUD b WHERE b.CLM_ID = a.CLM_ID) as sdo_mdqo_clm_diag_cd_adjud,
			(SELECT COUNT(*) FROM OSS.STAGING.SDO_MDQO_CLM_LN_DIAG_CD_ADJUD b WHERE	b.CLM_ID = a.CLM_ID) as sdo_mdqo_clm_ln_diag_cd_adjud
	INTO	#hold_claim_table_row_counts
	FROM	EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS a
	INNER JOIN	OSS.Staging.SDO_MDQO_MED_CLM_HDR_ADJUD b
		ON	b.SRC_DATA_KEY		= a.SRC_DATA_KEY
		AND	b.CLM_ID			= a.CLM_ID

	CREATE NONCLUSTERED INDEX tIndex ON #hold_claim_table_row_counts (CLM_ID ASC, SRC_DATA_KEY ASC)

-- Excl 9074	OSS.STAGING.SDO_MDQO_MED_CLM_DTL_ADJUD
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	a.CLM_ID, a.SRC_DATA_KEY, @CURRENTDATE, '9074', 
			CASE a.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END 
	FROM	#hold_claim_table_row_counts a
	WHERE	a.sdo_mdqo_med_clm_dtl_adjud = 0

-- Excl 9075	OSS.STAGING.SDO_MDQO_CLM_DIAG_CD_ADJUD
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	a.CLM_ID, a.SRC_DATA_KEY, @CURRENTDATE, '9075',
			CASE a.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END 
	FROM	#hold_claim_table_row_counts a
	WHERE	a.sdo_mdqo_clm_diag_cd_adjud = 0

-- Excl 9076	OSS.STAGING.SDO_MDQO_CLM_LN_DIAG_CD_ADJUD
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	a.CLM_ID, a.SRC_DATA_KEY, @CURRENTDATE, '9076', 
			CASE a.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
			END 
	FROM	#hold_claim_table_row_counts a
	WHERE	a.sdo_mdqo_clm_ln_diag_cd_adjud = 0
	AND		a.CLM_TY <> 'INSTITUTIONAL'


	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @@ROWCOUNT
	WHERE	PROC_NAME = 'OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Tables with missing data'
	AND		STEP = '7.1'
	AND		END_DT IS NULL

	IF OBJECT_ID('TEMPDB..#hold_claim_table_row_counts') <> 0
		DROP TABLE #hold_claim_table_row_counts
-- end Exclusion 9074 / 9075 / 9076




-- RETM-749 New 9077 Exclusion for SDK 40 claims
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	SELECT	DISTINCT a.CLM_ID, a.SRC_DATA_KEY, @CURRENTDATE, '9077', 
			CASE b.FRM_TY_CD	WHEN 'H' THEN  'P' 
								ELSE 'I'
			END
	FROM	EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS a
	INNER JOIN	OSS.Staging.SDO_MDQO_MED_CLM_HDR_ADJUD b
		ON	b.SRC_DATA_KEY		= a.SRC_DATA_KEY
		AND	b.CLM_ID			= a.CLM_ID
	WHERE	a.SRC_DATA_KEY		= 40
	AND		b.FRM_TY_CD			IN ('H', 'U')
	AND		b.PD_DT				<= '2024-04-26'
	AND		b.SVC_START_DT		BETWEEN '2023-01-01' and '2023-12-31'

-- end RETM-749





-- Exclusion Clean Up		TETDM-1197 Delete all other exclusions for DP claims    
	IF OBJECT_ID('TEMPDB..#OSS_CLAIM_EXCLUSION_HIST_DP') <> 0    
		drop table 	#OSS_CLAIM_EXCLUSION_HIST_DP    

	CREATE TABLE #OSS_CLAIM_EXCLUSION_HIST_DP(    
		[claim_id] [varchar](20) NULL,    
		[SOURCEDATAKEY] [int] NULL,    
		[BATCH_RUN_DT] [datetime] NOT NULL,    
		[EXCL_ID] [int] NULL,    
		[claim_type] [char](5) NULL	)    
    
	INSERT INTO #OSS_CLAIM_EXCLUSION_HIST_DP    
	SELECT  c.CLM_ID, c.SRC_DATA_KEY, @CURRENTDATE , EXCL_ID,
		CASE c.CLM_TY		WHEN 'INSTITUTIONAL'	THEN 'I' 
							WHEN 'PROFESSIONAL'		THEN 'P' 
							ELSE 'D'
		END 
	FROM OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD C
	INNER JOIN EDIFECS.dbo.OSS_CLAIMS_CONSIDERED_FOR_EXCLUSIONS claims
		ON	claims.SRC_DATA_KEY		= C.SRC_DATA_KEY
		AND	claims.CLM_ID			= C.CLM_ID
	INNER JOIN #DP_YR D    
		ON SUBSTRING(CONVERT(CHAR, c.SVC_START_DT),1,4) = D.DP_YR    
--	WHERE	c.SRC_DATA_KEY IN (30, 50)    
-- Scott Waller 5/9/24 removing ... I think this logic should apply for ALL SDK's

-- Scott Waller 04/06/19	TETDM-1995
	CREATE NONCLUSTERED INDEX IDX_OSS_CLAIM_EXCLUSION_HIST_DP_01
		ON #OSS_CLAIM_EXCLUSION_HIST_DP (SOURCEDATAKEY, CLAIM_ID) 
-- end									    

	DELETE     
	FROM	EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	WHERE	CLAIM_ID IN (SELECT CLAIM_ID FROM #OSS_CLAIM_EXCLUSION_HIST_DP)    
    
	INSERT INTO EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SELECT	*     
	FROM	#OSS_CLAIM_EXCLUSION_HIST_DP    






--	Update the OSS_CLAIM_EXCLUSION_HIST table's ClaimType column
--	In many cases we could have joined to the header table from the other tables that were being processed,
--	but it would have made many of those inserts run much slower.  I think this is why this was done.
--	Or the original developers were lazy.  
--	Moving this to the bottom of the sproc.
	UPDATE	EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS    
	SET		CLAIM_TYPE	= CASE C.CLM_TY		
								WHEN 'INSTITUTIONAL'	THEN 'I' 
								WHEN 'PROFESSIONAL'		THEN 'P' 
								ELSE 'D'
							END    
	FROM	EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS H    
	INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD C    
		ON	C.SRC_DATA_KEY		= H.sourcedatakey
		AND c.CLM_ID			= H.claim_id
	WHERE	H.claim_type IS NULL
	OR		H.claim_type = ''
	OR		H.claim_type = ' '




--  Now either insert ALL the rows if an 'ALL' run, else MERGE the data
	IF @TYPE_OF_RUN = 'ALL'	
	BEGIN	
		TRUNCATE TABLE  EDIFECS.dbo.OSS_CLAIM_EXCLUSION_HIST

		INSERT INTO		EDIFECS.dbo.OSS_CLAIM_EXCLUSION_HIST
		SELECT	DISTINCT *	
		FROM	EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS
	END

	IF @TYPE_OF_RUN = 'INCREMENTAL'
	BEGIN	
		WITH stage AS ( SELECT DISTINCT * FROM EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS )
		MERGE
			INTO EDIFECS.dbo.OSS_CLAIM_EXCLUSION_HIST AS TARGET 
		USING stage AS SOURCE
			ON	SOURCE.claim_id			= TARGET.claim_id
			AND SOURCE.SOURCEDATAKEY	= TARGET.SOURCEDATAKEY
			AND SOURCE.CLAIM_TYPE		= TARGET.claim_type
			AND SOURCE.EXCL_ID			= TARGET.EXCL_ID 
		WHEN MATCHED 
			THEN UPDATE
				SET		TARGET.claim_id			= SOURCE.claim_id,
						TARGET.SOURCEDATAKEY	= SOURCE.SOURCEDATAKEY,
						TARGET.BATCH_RUN_DT		= SOURCE.BATCH_RUN_DT,
						TARGET.EXCL_ID			= SOURCE.EXCL_ID,
						TARGET.claim_type		= SOURCE.claim_type
		WHEN NOT MATCHED BY TARGET THEN
			INSERT (claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type)
			VALUES (SOURCE.claim_id, SOURCE.SOURCEDATAKEY, SOURCE.BATCH_RUN_DT, SOURCE.EXCL_ID, SOURCE.claim_type);
	END

	-- update the LAST_INCREMENTAL_RUN_DATE column in the OSS_EXCLUSION_INCREMENTAL_DATES table
	UPDATE	EDIFECS.dbo.OSS_EXCLUSION_INCREMENTAL_DATES
	SET		LAST_INCREMENTAL_RUN_DATE = GETDATE()


-- update EXT_SYS_RUNLOG to help monitor progress
	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @@ROWCOUNT
	WHERE	PROC_NAME = 'OSS_CLAIM_EXCLUSIONS_ALL_OR_INCREMENTAL - Block'
	AND		STEP = '8'
	AND		END_DT IS NULL




-- Final Tasks
	IF OBJECT_ID('TEMPDB..#OSS_CLAIM_EXCLUSION_HIST_DP') <> 0    
		DROP TABLE 	#OSS_CLAIM_EXCLUSION_HIST_DP   

	IF OBJECT_ID('dbo.excl_TETDM753', 'U') IS NOT NULL 
		DROP TABLE dbo.excl_TETDM753

	SET @TOTAL_RECORDS = (SELECT DISTINCT COUNT(*) FROM EDIFECS.dbo.OSS_CLAIMS_STAGED_FOR_EXCLUSIONS)	    
							    
	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @TOTAL_RECORDS    
		,ENTRYDT = GETDATE()    
	WHERE	PROC_NAME = @PROC_NAME_STR
	AND		END_DT IS NULL

GO