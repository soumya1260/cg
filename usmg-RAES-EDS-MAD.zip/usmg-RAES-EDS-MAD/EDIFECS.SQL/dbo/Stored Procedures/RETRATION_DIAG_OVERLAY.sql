﻿
CREATE PROCEDURE [dbo].[RETRATION_DIAG_OVERLAY]
AS  
/***************************************************************************************************  
** CREATE DATE: 03/2023  
**  
** AUTHOR: Subhash Acharya 
**  
** DESCRIPTION: 
**                
Modification History  
====================  
Date		Who				Description  
-----------------------------------------------------------------------------------------------------  
2023-06-12  Subhash Acharya Initial Creation  

job: [EDS EDIFECS - Claim Adjustment Submission JOBS]

claims has to be on the outbound adjustment table
*****************************************************************************************************/  




/************************************ 30 and 50 starts here************************************************************/

--INST 

--drop table  #AllClaims
--drop table  #AllPClaims
select 
distinct claim_id, system_source, SOURCEDATAKEY
into #AllPClaims
from wipro..outb_prof_header


select  
distinct claim_id, system_source, SOURCEDATAKEY
into #AllIClaims
from  wipro..outb_inst_header



select distinct  a.CLAIMID, a.SOURCEDATAKEY, a.DIAGNOSISCODE ,a.DIAGNOSISTYPECODE ,a.DiagnosisTypeCodeDesc
,a.SEQUENCE	as SEQ ,a.POAIND
into #All3050PClaimDiags
from wipro.[dbo].[CLAIMDIAGNOSISDIM_OVERLAY] a	 --where a.CLAIMID = '22187E013208'	 --30,50
join #AllPClaims b 
		on a.CLAIMID = b.CLAIM_ID and a.SOURCEDATAKEY = b.SOURCEDATAKEY
where a.SourceDataKey in (30,50) and b.SourceDataKey in (30,50)
--and claimid = '22290E025162'

--drop table #All3050IClaimDiags

select distinct  a.CLAIMID, a.SOURCEDATAKEY, a.DIAGNOSISCODE ,a.DIAGNOSISTYPECODE ,a.DiagnosisTypeCodeDesc
,a.SEQUENCE	as SEQ ,a.POAIND
into #All3050IClaimDiags
from wipro.[dbo].[CLAIMDIAGNOSISDIM_OVERLAY] a	 	 --30,50
join #AllIClaims b 
		on a.CLAIMID = b.CLAIM_ID and a.SOURCEDATAKEY = b.SOURCEDATAKEY
where a.SourceDataKey in (30,50) and b.SourceDataKey in (30,50)
--and claimid = '22290E025162'


update a
set 
 a.INST_PRINCIPAL_DIAG_CD	= ''
,a.INST_PRINCIPAL_POA_CD    = ''
,a.PRINCIPAL_DIAG_QUAL = ''
,a.INST_ADM_DIAG_CD	= ''
,a.ADMIT_DIAG_QUAL = ''
from wipro..outb_inst_header a 
join #All3050IClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey


update a
set 
a.INST_PRINCIPAL_DIAG_CD	= b.DIAGNOSISCODE
,a.INST_PRINCIPAL_POA_CD    = case when b.POAIND = 'Y' then 'Y' else 'N' END
,a.PRINCIPAL_DIAG_QUAL = 'ABK'
from wipro..outb_inst_header a 
join #All3050IClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where b.DiagnosisTypeCodeDesc = 'Admit'


update a
set 
a.INST_PRINCIPAL_DIAG_CD	= b.DIAGNOSISCODE
,a.INST_PRINCIPAL_POA_CD    = case when b.POAIND = 'Y' then 'Y' else 'N' END
,a.PRINCIPAL_DIAG_QUAL = 'ABK'
from wipro..outb_inst_header a 
join #All3050IClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where b.DiagnosisTypeCodeDesc = 'Primary'

/*
update a
set 
a.INST_ADM_DIAG_CD	= b.DIAGNOSISCODE
,a.ADMIT_DIAG_QUAL = 'ABJ'
from wipro..outb_inst_header a 
join #All3050IClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where b.DiagnosisTypeCodeDesc = 'Primary'
*/
        
update a
set 
a.INST_ADM_DIAG_CD	= b.DIAGNOSISCODE
,a.ADMIT_DIAG_QUAL = 'ABJ'
from wipro..outb_inst_header a 
join #All3050IClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where b.DiagnosisTypeCodeDesc = 'Admit'

--drop table #All3050ISClaimDiags


select * , row_number() over(partition by CLAIMID, SourceDataKey order by 
													case 
													     when DiagnosisTypeCodeDesc = 'Secondary' then 1
													     when DiagnosisTypeCodeDesc = 'PRV' then 2
														 when DiagnosisTypeCodeDesc = 'Trauma' then 3
														 else 4 end , SEQ ) as RW 
into #All3050ISClaimDiags
from #All3050IClaimDiags
where DiagnosisTypeCodeDesc not in ('Primary','Admit') 


 
update a
set 
 a.DIAG_CD1	    =    ''
,a.POA_IND1     =  	 ''
,a.DIAG_CD_QUAL1=  	 ''
,a.DIAG_CD2	    =	 ''
,a.DIAG_CD3	    =	 ''
,a.DIAG_CD4	    =	 ''
,a.DIAG_CD5	    =	 ''
,a.DIAG_CD6	    =	 ''
,a.DIAG_CD7	    =	 ''
,a.DIAG_CD8	    =	 ''
,a.DIAG_CD9	    =	 ''
,a.DIAG_CD10	=	 ''
,a.DIAG_CD11	=	 ''
,a.DIAG_CD12	=	 ''
,a.DIAG_CD13	=	 ''
,a.DIAG_CD14	=	 ''
,a.DIAG_CD15	=	 ''
,a.DIAG_CD16	=	 ''
,a.DIAG_CD17	=	 ''
,a.DIAG_CD18	=	 ''
,a.DIAG_CD19	=	 ''
,a.DIAG_CD20	=	 ''
,a.DIAG_CD21	=	 ''
,a.DIAG_CD22	=	 ''
,a.DIAG_CD23	=	 ''
,a.DIAG_CD24	=	 ''
,a.DIAG_CD25	=	 ''
,a.DIAG_CD26	=	 ''
,a.DIAG_CD27	=	 ''
,a.DIAG_CD28	=	 ''
,a.DIAG_CD29	=	 ''
,a.DIAG_CD30	=	 ''
,a.POA_IND2	    =	 ''
,a.POA_IND3	    =	 ''
,a.POA_IND4	    =	 ''
,a.POA_IND5	    =	 ''
,a.POA_IND6	    =	 ''
,a.POA_IND7	    =	 ''
,a.POA_IND8	    =	 ''
,a.POA_IND9	    =	 ''
,a.POA_IND10    =	 ''
,a.POA_IND11    =	 ''
,a.POA_IND12    =	 ''
,a.POA_IND13    =	 ''
,a.POA_IND14    =	 ''
,a.POA_IND15    =	 ''
,a.POA_IND16    =	 ''
,a.POA_IND17    =	 ''
,a.POA_IND18    =	 ''
,a.POA_IND19    =	 ''
,a.POA_IND20    =	 ''
,a.POA_IND21    =	 ''
,a.POA_IND22    =	 ''
,a.POA_IND23    =	 ''
,a.POA_IND24    =	 ''
,a.POA_IND25    =	 ''
,a.POA_IND26    =	 ''
,a.POA_IND27    =	 ''
,a.POA_IND28    =	 ''
,a.POA_IND29    =	 ''
,a.POA_IND30    =	 ''
,a.DIAG_CD_QUAL2   = ''
,a.DIAG_CD_QUAL3   = ''
,a.DIAG_CD_QUAL4   = ''
,a.DIAG_CD_QUAL5   = ''
,a.DIAG_CD_QUAL6   = ''
,a.DIAG_CD_QUAL7   = ''
,a.DIAG_CD_QUAL8   = ''
,a.DIAG_CD_QUAL9   = ''
,a.DIAG_CD_QUAL10  = ''
,a.DIAG_CD_QUAL11  = ''
,a.DIAG_CD_QUAL12  = ''
,a.DIAG_CD_QUAL13  = ''
,a.DIAG_CD_QUAL14  = ''
,a.DIAG_CD_QUAL15  = ''
,a.DIAG_CD_QUAL16  = ''
,a.DIAG_CD_QUAL17  = ''
,a.DIAG_CD_QUAL18  = ''
,a.DIAG_CD_QUAL19  = ''
,a.DIAG_CD_QUAL20  = ''
,a.DIAG_CD_QUAL21  = ''
,a.DIAG_CD_QUAL22  = ''
,a.DIAG_CD_QUAL23  = ''
,a.DIAG_CD_QUAL24  = ''
,a.DIAG_CD_QUAL25  = ''
,a.DIAG_CD_QUAL26  = ''
,a.DIAG_CD_QUAL27  = ''
,a.DIAG_CD_QUAL28  = ''
,a.DIAG_CD_QUAL29  = ''
,a.DIAG_CD_QUAL30  = ''
, a.INST_VISIT_DIAG_CD1		   = ''
,a.INST_VISIT_DIAG_CD2		   = ''
,a.INST_VISIT_DIAG_CD3		   = ''
,a.INST_EXT_INJ_POA_IND1	   = ''
,a.INST_EXT_INJ_DIAG_CD1	   = ''
,a.INST_EXT_INJ_POA_IND2	   = ''
,a.INST_EXT_INJ_DIAG_CD2	   = ''
,a.INST_EXT_INJ_POA_IND3	   = ''
,a.INST_EXT_INJ_DIAG_CD3	   = ''
,a.INST_EXT_INJ_POA_IND4	   = ''
,a.INST_EXT_INJ_DIAG_CD4	   = ''
,a.INST_EXT_INJ_POA_IND5	   = ''
,a.INST_EXT_INJ_DIAG_CD5	   = ''
,a.INST_EXT_INJ_POA_IND6	   = ''
,a.INST_EXT_INJ_DIAG_CD6	   = ''
,a.INST_EXT_INJ_POA_IND7	   = ''
,a.INST_EXT_INJ_DIAG_CD7	   = ''
,a.INST_EXT_INJ_POA_IND8	   = ''
,a.INST_EXT_INJ_DIAG_CD8	   = ''
,a.INST_EXT_INJ_POA_IND9	   = ''
,a.INST_EXT_INJ_DIAG_CD9	   = ''
,a.INST_EXT_INJ_POA_IND10	   = ''
,a.INST_EXT_INJ_DIAG_CD10	   = ''
,a.INST_EXT_INJ_POA_IND11	   = ''
,a.INST_EXT_INJ_DIAG_CD11	   = ''
,a.INST_EXT_INJ_POA_IND12	   = ''
,a.INST_EXT_INJ_DIAG_CD12	   = ''
,a.INST_DIAG_DRG_CD			   = ''
,a.REA_VISIT_DIAG_QUAL1		   = ''
,a.REA_VISIT_DIAG_QUAL2		   = ''
,a.REA_VISIT_DIAG_QUAL3		   = ''
,a.INST_EXT_INJ_QUAL1		   = ''
,a.INST_EXT_INJ_QUAL2		   = ''
,a.INST_EXT_INJ_QUAL3		   = ''
,a.INST_EXT_INJ_QUAL4		   = ''
,a.INST_EXT_INJ_QUAL5		   = ''
,a.INST_EXT_INJ_QUAL6		   = ''
,a.INST_EXT_INJ_QUAL7		   = ''
,a.INST_EXT_INJ_QUAL8		   = ''
,a.INST_EXT_INJ_QUAL9		   = ''
,a.INST_EXT_INJ_QUAL10		   = ''
,a.INST_EXT_INJ_QUAL11		   = ''
,a.INST_EXT_INJ_QUAL12		   = ''
 from wipro..outb_inst_header a 
join #All3050ISClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
	 

update a
set 
 a.DIAG_CD1	  = case when rw = 1 then b.DIAGNOSISCODE else '' end
,a.POA_IND1    = case when rw = 1 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL1 = case when rw = 1  then 'ABF' else '' END
from wipro..outb_inst_header a 
join #All3050ISClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 1


update a
set 
 a.DIAG_CD2	     = case when rw = 2 then b.DIAGNOSISCODE else '' end
,a.POA_IND2      = case when rw = 2 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL2 = case when rw = 2  then 'ABF' else '' END
from wipro..outb_inst_header a 
join #All3050ISClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 2


update a
set 
 a.DIAG_CD3	     = case when rw = 3 then b.DIAGNOSISCODE else '' end
,a.POA_IND3      = case when rw = 3 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL3 = case when rw = 3  then 'ABF' else '' END
from wipro..outb_inst_header a 
join #All3050ISClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 3


update a set 
 a.DIAG_CD4	     = case when rw = 4 then b.DIAGNOSISCODE else '' end
,a.POA_IND4      = case when rw = 4 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL4 = case when rw = 4  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 4


update a set 
 a.DIAG_CD5	     = case when rw = 5 then b.DIAGNOSISCODE else '' end
,a.POA_IND5      = case when rw = 5 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL5 = case when rw = 5  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 5


update a set 
 a.DIAG_CD6	     = case when rw = 6 then b.DIAGNOSISCODE else '' end
,a.POA_IND6      = case when rw = 6 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL6 = case when rw = 6  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 6

update a set 
 a.DIAG_CD7	     = case when rw = 7 then b.DIAGNOSISCODE else '' end
,a.POA_IND7      = case when rw = 7 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL7 = case when rw = 7  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 7

update a set 
 a.DIAG_CD8	     = case when rw = 8 then b.DIAGNOSISCODE else '' end
,a.POA_IND8      = case when rw = 8 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL8 = case when rw = 8  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 8

update a set 
 a.DIAG_CD9	     = case when rw = 9 then b.DIAGNOSISCODE else '' end
,a.POA_IND9      = case when rw = 9 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL9 = case when rw = 9  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 9

update a set 
 a.DIAG_CD10	     = case when rw = 10 then b.DIAGNOSISCODE else '' end
,a.POA_IND10      = case when rw = 10 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL10 = case when rw = 10 then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 10

update a set 
 a.DIAG_CD11	     = case when rw = 11 then b.DIAGNOSISCODE else '' end
,a.POA_IND11      = case when rw = 11 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL11 = case when rw = 11  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 11

update a set 
 a.DIAG_CD12	     = case when rw = 12 then b.DIAGNOSISCODE else '' end
,a.POA_IND12      = case when rw = 12 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL12 = case when rw = 12  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 12

update a set 
 a.DIAG_CD13	     = case when rw = 13 then b.DIAGNOSISCODE else '' end
,a.POA_IND13      = case when rw = 13 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL13 = case when rw = 13  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 13

update a set 
 a.DIAG_CD14	     = case when rw = 14 then b.DIAGNOSISCODE else '' end
,a.POA_IND14      = case when rw = 14 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL14 = case when rw = 14  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 14

update a set 
 a.DIAG_CD15	     = case when rw = 15 then b.DIAGNOSISCODE else '' end
,a.POA_IND15      = case when rw = 15 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL15 = case when rw = 15  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 15

update a set 
 a.DIAG_CD16	     = case when rw = 16 then b.DIAGNOSISCODE else '' end
,a.POA_IND16      = case when rw = 16 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL16 = case when rw = 16  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 16

update a set 
 a.DIAG_CD17	     = case when rw = 17 then b.DIAGNOSISCODE else '' end
,a.POA_IND17      = case when rw = 17 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL17 = case when rw = 17  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 17

update a set 
 a.DIAG_CD18	     = case when rw = 18 then b.DIAGNOSISCODE else '' end
,a.POA_IND18      = case when rw = 18 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL18 = case when rw = 18  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 18

update a set 
 a.DIAG_CD19	     = case when rw = 19 then b.DIAGNOSISCODE else '' end
,a.POA_IND19      = case when rw = 19 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL19 = case when rw = 19  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 19

update a set 
 a.DIAG_CD20	     = case when rw = 20 then b.DIAGNOSISCODE else '' end
,a.POA_IND20      = case when rw = 20 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL20 = case when rw = 20  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 20

update a set 
 a.DIAG_CD21	     = case when rw = 21 then b.DIAGNOSISCODE else '' end
,a.POA_IND21      = case when rw = 21 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL21 = case when rw = 21  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 21

update a set 
 a.DIAG_CD22	     = case when rw = 22 then b.DIAGNOSISCODE else '' end
,a.POA_IND22      = case when rw = 22 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL22 = case when rw = 22  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 22


update a set 
 a.DIAG_CD23	  = case when rw = 23 then b.DIAGNOSISCODE else '' end
,a.POA_IND23      = case when rw = 23 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL23 = case when rw = 23  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 23


update a set 
 a.DIAG_CD24	  = case when rw = 24 then b.DIAGNOSISCODE else '' end
,a.POA_IND24      = case when rw = 24 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL24 = case when rw = 24  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 24


update a set 
 a.DIAG_CD25	  = case when rw = 25 then b.DIAGNOSISCODE else '' end
,a.POA_IND25      = case when rw = 25 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL25 = case when rw = 25  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 25


update a set 
 a.DIAG_CD26	  = case when rw = 26 then b.DIAGNOSISCODE else '' end
,a.POA_IND26      = case when rw = 26 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL26 = case when rw = 26  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 26

update a set 
 a.DIAG_CD26	  = case when rw = 26 then b.DIAGNOSISCODE else '' end
,a.POA_IND26      = case when rw = 26 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL26 = case when rw = 26  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 26

update a set 
 a.DIAG_CD27	  = case when rw = 27 then b.DIAGNOSISCODE else '' end
,a.POA_IND27      = case when rw = 27 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL27 = case when rw = 27  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 27


update a set 
 a.DIAG_CD28	  = case when rw = 28 then b.DIAGNOSISCODE else '' end
,a.POA_IND28      = case when rw = 28 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL28 = case when rw = 28  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 28

update a set 
 a.DIAG_CD29	  = case when rw = 29 then b.DIAGNOSISCODE else '' end
,a.POA_IND29      = case when rw = 29 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL29 = case when rw = 29  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 29

update a set 
 a.DIAG_CD30	  = case when rw = 30 then b.DIAGNOSISCODE else '' end
,a.POA_IND30      = case when rw = 30 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL23 = case when rw = 30  then 'ABF' else '' END
from wipro..outb_inst_header a join #All3050ISClaimDiags b 	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where rw = 30


---PROF---
--limit to 13



update a
set 
a.INST_PRINCIPAL_DIAG_CD	= b.DIAGNOSISCODE
,a.INST_PRINCIPAL_POA_CD    = case when b.POAIND = 'Y' then 'Y' else 'N' END
,a.PRINCIPAL_DIAG_QUAL = 'ABK'
--select *  
from wipro..outb_prof_header a 
join #All3050PClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where b.DiagnosisTypeCodeDesc = 'Primary'

--and a.CLAIM_ID = '22187E013208'  

update a
set 
a.INST_ADM_DIAG_CD	= ''
,a.ADMITDIAG_QUAL = ''
from wipro..outb_prof_header a 
join #All3050PClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey


        
update a
set 
a.INST_ADM_DIAG_CD	= b.DIAGNOSISCODE
,a.ADMITDIAG_QUAL = 'ABJ'
from wipro..outb_prof_header a 
join #All3050PClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where b.DiagnosisTypeCodeDesc = 'Admit'


--drop table #All3050PSClaimDiags
select * , row_number() over(partition by CLAIMID, SourceDataKey order by 
													case when DiagnosisTypeCodeDesc = 'Primary' then 0
													     when DiagnosisTypeCodeDesc = 'Secondary' then 1
													     when DiagnosisTypeCodeDesc = 'PRV' then 2
														 when DiagnosisTypeCodeDesc = 'Trauma' then 3
														 else 4 end , SEQ ) as RW 
into #All3050PSClaimDiags
from #All3050PClaimDiags
--where DiagnosisTypeCodeDesc not in ('Primary','Admit') 


update a
SET
 a.DIAG_CD1	         = ''
,a.POA_IND1          = ''
,a.DIAG_CD_QUAL1 	 = ''

,a.DIAG_CD2	         = ''
,a.DIAG_CD3	         = ''
,a.DIAG_CD4	         = ''
,a.DIAG_CD5	         = ''
,a.DIAG_CD6	         = ''
,a.DIAG_CD7	         = ''
,a.DIAG_CD8	         = ''
,a.DIAG_CD9	         = ''
,a.DIAG_CD10	     = ''
,a.DIAG_CD11	     = ''
,a.DIAG_CD12	     = ''
,a.DIAG_CD13	     = ''
,a.POA_IND2	         = ''
,a.POA_IND3	         = ''
,a.POA_IND4	         = ''
,a.POA_IND5	         = ''
,a.POA_IND6	         = ''
,a.POA_IND7	         = ''
,a.POA_IND8	         = ''
,a.POA_IND9	         = ''
,a.POA_IND10         = ''
,a.POA_IND11         = ''
,a.POA_IND12         = ''
,a.POA_IND13         = ''
,a.DIAG_CD_QUAL2	 = ''
,a.DIAG_CD_QUAL3	 = ''
,a.DIAG_CD_QUAL4	 = ''
,a.DIAG_CD_QUAL5	 = ''
,a.DIAG_CD_QUAL6	 = ''
,a.DIAG_CD_QUAL7	 = ''
,a.DIAG_CD_QUAL8	 = ''
,a.DIAG_CD_QUAL9	 = ''
,a.DIAG_CD_QUAL10    = ''
,a.DIAG_CD_QUAL11    = ''
,a.DIAG_CD_QUAL12    = ''
,a.DIAG_CD_QUAL13    = ''

--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 3 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey


       
update a
set 
--select 
 a.DIAG_CD1	         = case when rw = 1 then b.DIAGNOSISCODE else '' end 
,a.POA_IND1          = case when rw = 1 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL1     = case when rw = 1  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 1 --and a.claim_id = '22187E013208'  


update a
set 
--select 
 a.DIAG_CD2	         = case when rw = 2 then b.DIAGNOSISCODE else '' end 
,a.POA_IND2          = case when rw = 2 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL2     = case when rw = 2  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw =2 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 2 --and a.claim_id = '22187E013208'  

update a
set 
--select 
 a.DIAG_CD3	         = case when rw = 3 then b.DIAGNOSISCODE else '' end 
,a.POA_IND3          = case when rw = 3 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL3     = case when rw = 3  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 3 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 3 --and a.claim_id = '22187E013208'  

update a
set 
--select 
 a.DIAG_CD4	         = case when rw = 4 then b.DIAGNOSISCODE else '' end 
,a.POA_IND4          = case when rw = 4 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL4     = case when rw = 4  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 4 --and a.claim_id = '22187E013208'  

update a
set 
--select 
 a.DIAG_CD5	         = case when rw = 5 then b.DIAGNOSISCODE else '' end 
,a.POA_IND5          = case when rw = 5 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL5     = case when rw = 5  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 5 --and a.claim_id = '22187E013208'  

update a
set 
--select 
 a.DIAG_CD6	         = case when rw = 6 then b.DIAGNOSISCODE else '' end 
,a.POA_IND6          = case when rw = 6 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL6     = case when rw = 6  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 6 --and a.claim_id = '22187E013208'  

update a
set 
--select 
 a.DIAG_CD7	         = case when rw = 7 then b.DIAGNOSISCODE else '' end 
,a.POA_IND7          = case when rw = 7 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL7     = case when rw = 7  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 7 --and a.claim_id = '22187E013208'  

update a
set 
--select 
 a.DIAG_CD8	         = case when rw = 8 then b.DIAGNOSISCODE else '' end 
,a.POA_IND8          = case when rw = 8 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL8     = case when rw = 8  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 8 --and a.claim_id = '22187E013208'  


update a
set 
--select 
 a.DIAG_CD9	         = case when rw = 9 then b.DIAGNOSISCODE else '' end 
,a.POA_IND9          = case when rw = 9 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL9     = case when rw = 9  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 9 --and a.claim_id = '22187E013208'  

update a
set 
--select 
 a.DIAG_CD10	         = case when rw = 10 then b.DIAGNOSISCODE else '' end 
,a.POA_IND10          = case when rw = 10 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL10     = case when rw = 10  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 10 --and a.claim_id = '22187E013208'  

update a
set 
--select 
 a.DIAG_CD11	         = case when rw = 11 then b.DIAGNOSISCODE else '' end 
,a.POA_IND11          = case when rw = 11 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL11     = case when rw = 11  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 11 --and a.claim_id = '22187E013208'  

update a
set 
--select 
 a.DIAG_CD12	         = case when rw = 12 then b.DIAGNOSISCODE else '' end 
,a.POA_IND12          = case when rw = 12 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL12     = case when rw = 12  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 12 --and a.claim_id = '22187E013208'  


update a
set 
--select 
 a.DIAG_CD13	         = case when rw = 13 then b.DIAGNOSISCODE else '' end 
,a.POA_IND13          = case when rw = 13 then case when b.POAIND = 'Y' then 'Y' else 'N' END else '' END
,a.DIAG_CD_QUAL13     = case when rw = 13  then 'ABF' else '' END
--select a.claim_id ,b.claimid ,a.SourceDataKey ,b.SourceDataKey,a.DIAG_CD2	         , case when rw = 1 then b.DIAGNOSISCODE else '' end 
from wipro..outb_prof_header a 
left join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
where RW = 13 --and a.claim_id = '22187E013208' 




update a
set 
 a.REA_VISITDIAG_QUAL1		   = ''
,a.REA_VISITDIAG_QUAL2		   = ''
,a.REA_VISITDIAG_QUAL3		   = ''

 from wipro..OUTB_PROF_HEADER a 
join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey


  update a
set 
 a.PRIM_DIAG_CD      = case when rw = 1  then 1  else '' END  
    from wipro..outb_prof_detail a 
join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey
	where rw = 1


	update a 
	set 
	 a.DIAG_CD2  = '' 
	,a.DIAG_CD3  = ''
	,a.DIAG_CD4  = ''
	,a.DIAG_CD5  = ''
	,a.DIAG_CD6  = ''
	,a.DIAG_CD7  = ''
	,a.DIAG_CD8  = ''
	,a.DIAG_CD9  = ''
	,a.DIAG_CD10 = ''
	,a.DIAG_CD11 = ''
	,a.DIAG_CD12 = ''
	,a.DIAG_CD13 = ''
	from wipro..outb_prof_detail a 
	join #All3050PSClaimDiags b 
	on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	

update a set a.DIAG_CD2  = case when rw = 2   then 2 	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 2 
update a set a.DIAG_CD3  = case when rw = 3   then 3 	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 3 
update a set a.DIAG_CD4  = case when rw = 4   then 4 	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 4 
update a set a.DIAG_CD5  = case when rw = 5   then 5 	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 5 
update a set a.DIAG_CD6  = case when rw = 6   then 6 	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 6 
update a set a.DIAG_CD7  = case when rw = 7   then 7 	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 7 
update a set a.DIAG_CD8  = case when rw = 8   then 8 	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 8 
update a set a.DIAG_CD9  = case when rw = 9   then 9 	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 9 
update a set a.DIAG_CD10 = case when rw = 10  then 10	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 10
update a set a.DIAG_CD11 = case when rw = 11  then 11	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 11
update a set a.DIAG_CD12 = case when rw = 12  then 12	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 12
update a set a.DIAG_CD13 = case when rw = 13  then 13	 else '' END    from wipro..outb_prof_detail a join #All3050PSClaimDiags b on a.claim_id = b.claimid and a.SourceDataKey = b.SourceDataKey	where rw = 13




/************************************4 starts here************************************************************/


/*
select claimnum as ClaimID,SourceDataKey,
DX1,DX2,DX3,DX4,DX5,DX6,DX7,DX8,DX9,DX10
from wipro.[dbo].[encounterclaimdim_Overlay] --4
where SourceDataKey = 4
*/