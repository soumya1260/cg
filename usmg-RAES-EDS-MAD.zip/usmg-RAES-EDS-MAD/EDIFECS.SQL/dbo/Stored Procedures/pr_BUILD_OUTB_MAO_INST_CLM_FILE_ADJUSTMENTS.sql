﻿
  
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_MAO_INST_CLM_FILE_ADJUSTMENTS]  
(@SOURCEDATAKEY INT, @LOB CHAR(10), @JOBID INT, @LOBCODE VARCHAR(15) = ' ')--, @REJ_REA_ID CHAR(8) = ' ')--,@BEGIN_BILLTYPECODE CHAR(5) , @END_BILLTYPECODE CHAR(5))  
AS  
/***************************************************************************************************  
** CREATE DATE: 08/2012  
**  
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM  
**  
** DESCRIPTION: PROCEDURE WILL EXECUTE REQUIRD STEPS FOR COMPILING HRP MHC CLAIM SUBMISSIONS.  
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.2. THE SOURCE    
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES.   
**  
Modification History  
====================  
Date   Who    Description  
-----------------------------------------------------------------------------------------------------  
09/25/13  Loyal Ricks  Replaced call to EXSP_HRP_CLAIM_EDSPROVIDER_INST with call to   
        EXSP_HRP_CLAIM_INST_EDSPROVIDER  
11/08/13  Loyal Ricks  Add bed type range input parameters  
06/19/14  Loyal Ricks  Upgrade Verisk Map from V3.2 to V4.0 - EXSP_HRP_CLAIM_INST_MAP_V40  
------------------------------------------------------------------------------------------------------  
08/2014   Loyal Ricks  WIPRO Implementation  
09/10/14  Loyal Ricks  EDS-396 - Add sp - pr_BUILD_OUTB_INST_WIPRO_DATASCRUB  
09/23/14  Loyal Ricks  Add @LOB to be used during BUILD_OUTB_INST_MAP  
07/10/15  Loyal Ricks  Add @LOBCODE to comply with SSIS package requirements supporting all   
        EDS lob. @LOBCODE required for MMAI submissions.  
2015-07-23  Loyal Ricks  TETDM-276 Add JOBID to filedesc   
2016-02-18  Loyal Ricks  TETDM-643 Add claim header diagnosis codes   
2016-03-14  Loyal Ricks  TETDM-673 Add procedure BUILD_OUTB_INST_DIAG_ADJ_WIPRO  
2016-09-12  Loyal Ricks  TETDM-987 - Denied Claim Adjustments Added - BUILD_OUTB_INST_DENIED_ADJUSTMENTS_WIPRO  
2016-10-18  Loyal Ricks  Add procedure - BUILD_OUTB_INST_DENIED_LINE_ADJUSTMENTS_WIPRO for 1 claim testbed test of prod submission  
2016-12-13  Loyal Ricks  TETDM-644 - Add procedure - pr_BUILD_OUTB_INST_OTH_PROC_CD  
2017-10-20     John Bartholomay TETDM-1645  Remove Dup Adjustments on OA segment  
2021-02-24      Aaron Ridley    TETDM-2359 Added logic to pass LOBCODE to the Header sprocs  
2022-09-12  Aaron Ridley RETM-137 Added EXECUTE EDIFECS.dbo.CSV_DUPE_CLAIM_DELETE  
2023-06-10  Subhash Acharya RETM-209 added new proc [dbo].[RETRATION_DIAG_OVERLAY]
*****************************************************************************************************/   
--DECLARE VARIABLES  
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND  
   DECLARE  
     
   @TOTAL_RECORDS INT  
    
  
--HRP_CLAIM_FILE Run controls  
   BEGIN TRANSACTION   
     INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG  
       (PROC_NAME  
       ,STEP  
       ,START_DT  
       ,END_DT  
       ,RUN_MINUTES  
       ,TOTAL_RECORDS  
       ,ENTRYDT  
       )  
     VALUES('EDIFECS.dbo.pr_BUILD_OUTB_MAO_INST_CLM_FILE_ADJUSTMENTS' + '-' +CONVERT(CHAR,@JOBID)  
       ,'1'  
       ,GETDATE()  
       ,NULL  
       ,NULL  
       ,0  
       ,GETDATE()  
       )  
     if @@ERROR <> 0  
       begin  
        rollback   
       end  
    commit  
     ----JOBID = 9000 is the EDS Exclusion submission job. Exclusion history build should not be excuted for JOBID 9000  
     IF @JOBID in (3000,3060)   
     EXECUTE WIPRO.dbo.pr_BUILD_OUTB_MAO_INST_CLAIM_HEADER_ADJUSTMENTS @SOURCEDATAKEY,@JOBID, @LOB--,@REJ_REA_ID  
     --EXECUTE EXSP_HRP_CLAIM_INST_CLMHEADER @SOURCEDATAKEY,@BEGIN_BILLTYPECODE  , @END_BILLTYPECODE   
     EXECUTE WIPRO.dbo.pr_BUILD_OUTB_INST_CLM_DETAIL  
     EXECUTE WIPRO.dbo.BUILD_OUTB_INST_DIAG_WIPRO @SOURCEDATAKEY  
     EXECUTE WIPRO.dbo.BUILD_OUTB_INST_DIAG_ADJ_WIPRO @SOURCEDATAKEY  
     --EXECUTE EXSP_HRP_CLAIM_PROF_DIAG_POINTERS  
     EXECUTE WIPRO.dbo.pr_BUILD_OUTB_INST_EDSPROVIDER  
     EXECUTE WIPRO.dbo.pr_BUILD_OUTB_INST_ADJUSTMENTS  
     EXECUTE WIPRO.dbo.BUILD_OUTB_INST_DENIED_ADJUSTMENTS_WIPRO  
     EXECUTE WIPRO.dbo.BUILD_OUTB_INST_DENIED_LINE_ADJUSTMENTS_WIPRO  
     ----EXECUTE EXSP_HRP_CLAIM_INST_REQ5010  
     EXECUTE WIPRO.dbo.pr_BUILD_OUTB_INST_OCCURANCECODE  
     EXECUTE WIPRO.dbo.pr_BUILD_OUTB_INST_CONDITIONCODE  
     EXECUTE WIPRO.dbo.pr_BUILD_OUTB_INST_OTH_PROC_CD  
        EXECUTE WIPRO.dbo.pr_BUILD_OUTB_INST_REMOVE_DUP_ADJUSTMENTS --TETDM-1645  
     EXECUTE WIPRO.dbo.pr_BUILD_OUTB_INST_WIPRO_DATASCRUB  
     ----MAP CLAIM DATA FOR FILE PREPARATION  
     ----EXECUTE pr_BUILD_OUTB_INST_MAP @LOB,@LOBCODE,@JOBID  
     ----TETDM-643 Testing Only  
     EXECUTE WIPRO.dbo.BUILD_OUTB_INSERT_OCC_DATES  
	   --EXECUTE EDIFECS.[dbo].[RETRATION_DIAG_OVERLAY] --RETM--209  
     EXECUTE EDIFECS.[dbo].[pr_EDIFECS_INST_CSV_100I_150I_20I_310I_Header] @LOB, @LOBCODE, @JOBID  
     EXECUTE EDIFECS.[dbo].[pr_EDIFECS_INST_CSV_40I_431I_Detail]  
     EXECUTE EDIFECS.dbo.CSV_DUPE_CLAIM_DELETE  
     EXECUTE EDIFECS.dbo.BUILD_OUTB_INST_MAP  @LOB,@LOBCODE,@JOBID  
      
     
   
     
   --ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM  
          
   SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_INST_HEADER)  
   SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_INST_DETAIL)  
           
  ----HRP_CLAIM_FILE Update Run Controls  
    BEGIN TRANSACTION  
      UPDATE WIPRO.dbo.EXT_SYS_RUNLOG  
      SET END_DT = GETDATE()   
       ,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
       ,TOTAL_RECORDS = @TOTAL_RECORDS  
       ,ENTRYDT = GETDATE()  
      WHERE PROC_NAME = 'EDIFECS.dbo.pr_BUILD_OUTB_MAO_INST_CLM_FILE_ADJUSTMENTS' + '-' +CONVERT(CHAR,@JOBID)  
          and END_DT is null  
       IF @@ERROR <> 0  
          BEGIN   
            ROLLBACK   
          END  
      COMMIT

						
