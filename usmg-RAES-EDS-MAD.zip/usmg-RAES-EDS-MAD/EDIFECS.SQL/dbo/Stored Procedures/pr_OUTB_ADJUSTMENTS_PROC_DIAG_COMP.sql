﻿CREATE PROCEDURE [dbo].[pr_OUTB_ADJUSTMENTS_PROC_DIAG_COMP]
AS
/***************************************************************************************************
** CREATE DATE: 02/24/2021 
**
** AUTHOR: AARON RIDLEY 
**
** DESCRIPTION: PROCEDURE RETRIEVES ADJUSTMENT '9019' EXCLUSIONS FOR THE PURPOSE OF IDENTIFING 
  ADJUSTMENTS WITH PROCEDURE OR DIAGNOSIS CODE CHANGES. COMPARING THE ADJUSTED CLAIMS TO THE 
  PREVIOUS/ORIGINAL CLAIMID'S 
**              
Modification History
====================
Date			Who				Description
02-24-2021      Aaron Ridley    TETDM-2359 
-----------------------------------------------------------------------------------------------------*/



/* ---------------------------------------------------------
General Temporary table maintenance to ensure all temp files are dropped prior to execution
-------------------------------------------------------------*/ 

--DROP TABLE #TMPADJCLAIMS
--DROP TABLE #TMPADJALL
--DROP TABLE #TMPPREVCLAIMDIAG
--DROP TABLE #TMPORIGCLAIMGIAG
--DROP TABLE #TMPPREVCLAIMPROC
--DROP TABLE #TMPORIGCLAIMPROC

/* ---------------------------------------------------------
SYSLOG UPDATES 
-------------------------------------------------------------*/ 
			 
					INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,ENTRYDT
							)
					VALUES('EDIFECS.dbo.pr_OUTB_ADJUSTMENTS_PROC_DIAG_COMP' 
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,GETDATE()
							)

							select * from WIPRO.dbo.EXT_SYS_RUNLOG where PROC_NAME ='EDIFECS.dbo.pr_OUTB_ADJUSTMENTS_PROC_DIAG_COMP'
/*-------------------------------------------------------------------------------------
Retreive all Adjustments based on the 9019 exclusion ID
----------------------------------------------------------------------------------------*/
SELECT CLAIM_ID 
INTO #TMPADJCLAIMS
FROM WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST WHERE EXCL_ID = '9019' AND SOURCEDATAKEY ='50'  --and CLAIM_ID in ('17166E028737A3','16298E019577A1','17265E038633A1','17293E027689A8')

DELETE a
from #TMPADJCLAIMS a 
INNER JOIN WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST b on a.claim_id = b.claim_id 
 WHERE EXCL_ID = '8012' AND SOURCEDATAKEY ='50'

/*----------------------------------------------------------------------------------------
Populate the temporary table with Adjusted claim and the Previous Claim populated in the QNXT claims table
-----------------------------------------------------------------------------------------*/
SELECT a.CLAIM_ID, PLANCRN , b.Frequencycode, b.Adjuddate
INTO #TMPADJALL 
FROM #TMPADJCLAIMS a
 JOIN EDPS_Data.[dbo].[QNXT_Claim] b on a.CLAIM_ID = B.CLAIMID 
 AND B.CLAIMID <>''

 UPDATE a 
 set plancrn = b.previousclaimid 
 FROM #TMPADJALL a
 LEFT JOIN EDPS_Data.[dbo].[ClaimDim] b on a.CLAIM_ID = B.CLAIMID 
 AND B.PREVIOUSCLAIMID <>'UNKNOWN'


 /*----------------------------------------------------------------------------------------
Identify Procedure Codes assciated with the adjusted and Previous claim ID 
-----------------------------------------------------------------------------------------*/

SELECT DISTINCT CLAIMID, C.Plancrn, C.Frequencycode, C.Adjuddate,
SUBSTRING	(
(
	SELECT +a.procedurecode AS [text()]
	 FROM EDPS_DATA.[dbo].[CLAIMDETAILDIM] a
		 
	      WHERE a.CLAIMID = b.CLAIMID 
		  ORDER BY a.CLAIMID, a.PROCEDURECODE
		  FOR XML PATH ('')
	),1, 1000) [codes] 
INTO #TMPORIGCLAIMPROC
FROM EDPS_DATA.[dbo].[CLAIMDETAILDIM] b
 INNER JOIN #TMPADJALL c on b.claimid = c.claim_id 


 SELECT DISTINCT CLAIMID, C.Plancrn, C.Frequencycode, C.Adjuddate,
SUBSTRING	(
(
	SELECT +a.procedurecode AS [text()]
	 FROM EDPS_DATA.[dbo].[CLAIMDETAILDIM] a
		 
	      WHERE a.CLAIMID = b.CLAIMID 
		  ORDER BY a.CLAIMID, a.PROCEDURECODE
		  FOR XML PATH ('')
	),1, 1000) [codes] 
INTO #TMPPREVCLAIMPROC
FROM EDPS_DATA.[dbo].[CLAIMDETAILDIM] b
 INNER JOIN #TMPADJALL c on b.claimid = c.PLANCRN  


 SELECT a.*
INTO #TMPPROCEDURECHANGES
 FROM #TMPORIGCLAIMPROC a
 JOIN #TMPPREVCLAIMPROC b on a.Plancrn = b.Plancrn
 and a.codes <> b.codes


  /*----------------------------------------------------------------------------------------
Identify Diagnosis Codes assciated with the adjusted and Previous claim ID 
-----------------------------------------------------------------------------------------*/
 

SELECT DISTINCT CLAIMID, C.Plancrn, C.Frequencycode, C.Adjuddate,
SUBSTRING	(
(
	SELECT +a.[DIAGNOSISCODE] AS [text()]
	 FROM EDPS_DATA.[dbo].[CLAIMDIAGNOSISDIM] a
		 
	      WHERE a.CLAIMID = b.CLAIMID AND diagnosistypecodeDESC in ('Primary','Secondary')
		  ORDER BY a.CLAIMID, a.[DIAGNOSISCODE]
		  FOR XML PATH ('')
	),1, 1000) [codes]
INTO #TMPORIGCLAIMDIAG
FROM EDPS_DATA.[dbo].[CLAIMDIAGNOSISDIM] b
 INNER JOIN #TMPADJALL c on b.claimid = c.claim_id
 WHERE  diagnosistypecodeDESC in ('Primary','Secondary')

 SELECT DISTINCT CLAIMID, C.Plancrn, C.Frequencycode, C.Adjuddate,
SUBSTRING	(
(
	SELECT +a.[DIAGNOSISCODE] AS [text()]
	 FROM EDPS_DATA.[dbo].[CLAIMDIAGNOSISDIM] a
		 
	      WHERE a.CLAIMID = b.CLAIMID AND diagnosistypecodeDESC in ('Primary','Secondary')
		  ORDER BY a.CLAIMID, a.[DIAGNOSISCODE]
		  FOR XML PATH ('')
	),1, 1000) [codes]
INTO #TMPPREVCLAIMDIAG
FROM EDPS_DATA.[dbo].[CLAIMDIAGNOSISDIM] b
 INNER JOIN #TMPADJALL c on b.claimid = c.PLANCRN
 WHERE diagnosistypecodeDESC in ('Primary','Secondary')
 
 SELECT a.*
INTO #TMPDIAGCHANGES
 FROM #TMPORIGCLAIMDIAG a
 JOIN #TMPPREVCLAIMDIAG b on a.Plancrn = b.Plancrn
 and a.codes <> b.codes

 
 SELECT *, 'PROC' AS CHANGETYPE
 INTO #TMPCHANGES
 FROM #TMPPROCEDURECHANGES
 UNION 
 SELECT *, 'DIAG' AS CHANGETYPE FROM #TMPDIAGCHANGES

IF OBJECT_ID('EDIFECS.dbo.ADJUSTMENT_SUBMISSION_CHANGEINPUT') IS NOT NULL
TRUNCATE TABLE EDIFECS.dbo.ADJUSTMENT_SUBMISSION_CHANGEINPUT


 INSERT INTO EDIFECS.dbo.ADJUSTMENT_SUBMISSION_CHANGEINPUT
 SELECT *, getdate() FROM #TMPCHANGES

/* ---------------------------------------------------------
SYSLOG UPDATES - END
-------------------------------------------------------------*/ 
				
UPDATE WIPRO.dbo.EXT_SYS_RUNLOG
SET  END_DT = GETDATE()	
	,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
	,ENTRYDT = GETDATE()
WHERE PROC_NAME = 'EDIFECS.dbo.pr_OUTB_ADJUSTMENTS_PROC_DIAG_COMP' 
				and END_DT is null
/*-------------------------------------------------------------------------------------------------------------------------------------------------------------------*/ 
