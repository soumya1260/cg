﻿CREATE PROCEDURE [dbo].[pr_EDIFECS_PROF_CSV_40P_431P_Detail]
AS
/***************************************************************************************************
** CREATE DATE: 02/18/2020
**
** AUTHOR: Aaron Ridley 
**
** DESCRIPTION: PROCEDURE WILL POPULATE CSV DETAIL TABLES (40P,431P)
**              UTILIZING THE OUTB_PROF_DETAIL AS SOURCE
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
02/18/20		Aaron Ridley		Version 1
05/15/21		Subhash Acharya		TETDM-2460 Service Line Duplicates resubmission - Updating Modifiers for claims populated 
									in the Service Line Dupe table 

*****************************************************************************************************/	

--DECLARE VARIABLES

			DECLARE
			
			@TOTAL_RECORDS INT
		
			BEGIN TRANSACTION 
					INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_EDIFECS_PROF_CSV_40P_431P_Detail'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					if @@ERROR <> 0
							begin
								rollback 
							end
				commit

/*---------------------------------------------------------------------*/
/* POPULATE 40P TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_40P_Rec_Detail_Archive 
SELECT *, getdate()  FROM dbo.EE_CSV_40P_Rec_Detail

TRUNCATE TABLE dbo.EE_CSV_40P_Rec_Detail

INSERT INTO dbo.EE_CSV_40P_Rec_Detail
SELECT distinct  
 b.Claim_ID AS ClaimID 
,b.SourceDataKey 
,'' AS SourceDesc 
,GETDATE() AS CreateDate 
,CLAIM_LINE_NO AS ClaimLineNumber
,CLAIM_LINE_NO													AS	[2400P_LX01_LineCounter]
,SERV_ID_QUAL													AS	[2400P_SV101-01_ServiceCodeType]
,PROC_CD														AS	[2400P_SV101-02_ServiceCode]

/*
if 59 exists already on one out of 4 - ignore
if none are 59 make the first that is null or blank to 59
if all are populated and none are 59 make the last one 59
*/
,CASE WHEN a.claim_id is NOT NULL and isnull(PROC_CD,'') <> '' and 
		  PROC_MOD1 = '59' OR PROC_MOD2 = '59' or PROC_MOD3 = '59' or PROC_MOD3 = '59'	or PROC_MOD4 = '59'  THEN PROC_MOD1
     WHEN a.claim_id is NOT NULL and isnull(PROC_CD,'') <> ''  and isnull(PROC_MOD1,'') = '' and ( isnull(PROC_MOD2,'') <> '59' or isnull(PROC_MOD3,'') <> '59' or isnull(PROC_MOD4,'') <> '59') THEN '59'
	  ELSE PROC_MOD1 END
										
																AS	[2400P_SV101-03_ServiceModifier1]
,CASE WHEN a.claim_id is NOT NULL and isnull(PROC_CD,'') <> '' and 
		  PROC_MOD1 = '59' OR PROC_MOD2 = '59' or PROC_MOD3 = '59' or PROC_MOD3 = '59'	or PROC_MOD4 = '59'  THEN PROC_MOD2
     WHEN a.claim_id is NOT NULL and (isnull(PROC_CD,'') <> '' and (isnull(PROC_MOD2,'') = '' and isnull(PROC_MOD1,'') <> ''))
						THEN '59'
	  ELSE PROC_MOD2 END													
																AS	[2400P_SV101-04_ServiceModifier2]
,CASE WHEN a.claim_id is NOT NULL and isnull(PROC_CD,'') <> '' and 
		  PROC_MOD1 = '59' OR PROC_MOD2 = '59' or PROC_MOD3 = '59' or PROC_MOD3 = '59'	or PROC_MOD4 = '59'  THEN PROC_MOD3
	  WHEN a.claim_id is NOT NULL and (isnull(PROC_CD,'') <> '' and (isnull(PROC_MOD3,'') = '' and isnull(PROC_MOD1,'') <> '') and isnull(PROC_MOD2,'') <> '')
	                     THEN '59'
	  else PROC_MOD3 END												
																 AS	[2400P_SV101-05_ServiceModifier3]
,CASE WHEN a.claim_id is NOT NULL and isnull(PROC_CD,'') <> '' and 
		  PROC_MOD1 = '59' OR PROC_MOD2 = '59' or PROC_MOD3 = '59' or PROC_MOD3 = '59'	or PROC_MOD4 = '59'  THEN PROC_MOD4
		WHEN a.claim_id is NOT NULL and (isnull(PROC_CD,'') <> '' and (isnull(PROC_MOD4,'') = '' and isnull(PROC_MOD1,'') <> '') and isnull(PROC_MOD2,'') <> '' and isnull(PROC_MOD3,'') <> '')
	                     THEN '59'
		WHEN a.claim_id is NOT NULL and (isnull(PROC_CD,'') <> '' and (isnull(PROC_MOD4,'') <> '' and isnull(PROC_MOD1,'') <> '') and isnull(PROC_MOD2,'') <> '' and isnull(PROC_MOD3,'') <> '')
	                     THEN '59'
	  ELSE PROC_MOD4 END										
																						
																AS	[2400P_SV101-06_ServiceModifier4]	
,PROC_DESC														AS	[2400P_SV101-07_ServiceCodeDescription]
,TOTAL_CHRG_AMT													AS	[2400P_SV102_LineCharge]
,ANES_FLAG														AS	[2400P_SV103_ServiceUnitMeasure]
,QTY_UNITS														AS	[2400P_SV104_Quantity]
,POS															AS	[2400P_SV105_PlaceOfService]		--Subhash Acharya
,PRIM_DIAG_CD													AS	[2400P_SV107-01_DiagnosisPointer]	--Subhash Acharya
,COALESCE(DIAG_CD2,DIAG_CD3,DIAG_CD4,DIAG_CD5,DIAG_CD6,DIAG_CD7,DIAG_CD8,DIAG_CD9,
			DIAG_CD10,DIAG_CD11,DIAG_CD12,DIAG_CD13,DIAG_CD14,DIAG_CD15,DIAG_CD16,DIAG_CD17,
			DIAG_CD18,DIAG_CD19,DIAG_CD20,DIAG_CD21,DIAG_CD22,DIAG_CD23,DIAG_CD24,DIAG_CD25,
			DIAG_CD26,DIAG_CD27,DIAG_CD28,DIAG_CD29,DIAG_CD30)		
																AS	[2400P_SV107-02_DiagnosisPointer]	--Subhash Acharya

,COALESCE(DIAG_CD3,DIAG_CD4,DIAG_CD5,DIAG_CD6,DIAG_CD7,DIAG_CD8,DIAG_CD9,
			DIAG_CD10,DIAG_CD11,DIAG_CD12,DIAG_CD13,DIAG_CD14,DIAG_CD15,DIAG_CD16,DIAG_CD17,
			DIAG_CD18,DIAG_CD19,DIAG_CD20,DIAG_CD21,DIAG_CD22,DIAG_CD23,DIAG_CD24,DIAG_CD25,
			DIAG_CD26,DIAG_CD27,DIAG_CD28,DIAG_CD29,DIAG_CD30)										

																AS	[2400P_SV107-03_DiagnosisPointer]	--Subhash Acharya

,COALESCE(DIAG_CD4,DIAG_CD5,DIAG_CD6,DIAG_CD7,DIAG_CD8,DIAG_CD9,
			DIAG_CD10,DIAG_CD11,DIAG_CD12,DIAG_CD13,DIAG_CD14,DIAG_CD15,DIAG_CD16,DIAG_CD17,
			DIAG_CD18,DIAG_CD19,DIAG_CD20,DIAG_CD21,DIAG_CD22,DIAG_CD23,DIAG_CD24,DIAG_CD25,
			DIAG_CD26,DIAG_CD27,DIAG_CD28,DIAG_CD29,DIAG_CD30)									

																AS	[2400P_SV107-04_DiagnosisPointer]	--Subhash Acharya
,EMER_FLAG														AS	[2400P_SV109_EmergencyService]
,''											AS	[2400P_SV111_EPSDTService]
,''											AS	[2400P_SV112_FamilyPlanningService]
,COPAY_EX_FLAG													AS	[2400P_SV115_CoPayExempt]
,SERV_ID_QUAL													AS	[2400P_SV501-01_ServiceCodeType]
,PROC_CD     													AS	[2400P_SV501-02_ServiceCode]
,ANES_FLAG														AS	[2400P_SV502_ServiceUnitMeasure]
,''											AS	[2400P_SV503_LengthMedicalNecessity]
,''											AS	[2400P_SV504_RentalPrice]
,''											AS	[2400P_SV505_PurchasePrice]
,''											AS	[2400P_SV506_RentalUnitPrice]
,''											AS	[2400P_PWK01_ReportType]
,''											AS	[2400P_PWK02_TransmissionCode]
,''											AS	[2400P_PWK05_CodeQualifier]
,''											AS	[2400P_PWK06_ControlNumber]
,''											AS	[2400P_CR101_PatientWeightQualifier]
,''											AS	[2400P_CR102_PatientWeight]
,''											AS	[2400P_CR104_TransportReason]
,''											AS	[2400P_CR105_ServiceMeasureCode]
,''											AS	[2400P_CR106_Distance]
,''											AS	[2400P_CR109_RoundTripDesc]
,''											AS	[2400P_CR110_StretcherPurpose]
,''											AS	[2400P_DTP01_DateTimeQualifier_1]
,''											AS	[2400P_DTP02_FormatQualifier_1]
, CASE WHEN [SERV_START_DT] = SERV_END_DT THEN 	[SERV_START_DT]
	   WHEN ISNULL(SERV_END_DT,'') = '' THEN [SERV_START_DT]
	   ELSE CONCAT([SERV_START_DT],'-',SERV_END_DT) END
																AS	[2400P_DTP03_Date_1]
,''											AS	[2400P_DTP01_DateTimeQualifier_2]
,''											AS	[2400P_DTP02_FormatQualifier-2]
,''											AS	[2400P_DTP03_Date-2]
,''											AS	[2400P_DTP01_DateTimeQualifier_3]
,''											AS	[2400P_DTP02_FormatQualifier_3]
,''											AS	[2400P_DTP03_Date_3]
,''											AS	[2400P_DTP01_DateTimeQualifier_4]
,''											AS	[2400P_DTP02_FormatQualifier-4]
,''											AS	[2400P_DTP03_Date-4]
,''											AS	[2400P_DTP01_DateTimeQualifier_5]
,''											AS	[2400P_DTP02_FormatQualifier_5]
,''											AS	[2400P_DTP03_Date_5]
,''											AS	[2400P_DTP01_DateTimeQualifier_6]
,''											AS	[2400P_DTP02_FormatQualifier-6]
,''											AS	[2400P_DTP03_Date-6]
,''											AS	[2400P_DTP01_DateTimeQualifier_7]
,''											AS	[2400P_DTP02_FormatQualifier_7]
,''											AS	[2400P_DTP03_Date_7]
,''											AS	[2400P_DTP01_DateTimeQualifier_8]
,''											AS	[2400P_DTP02_FormatQualifier-8]
,''											AS	[2400P_DTP03_Date-8]
,''											AS	[2400P_DTP01_DateTimeQualifier_9]
,''											AS	[2400P_DTP02_FormatQualifier-9]
,''											AS	[2400P_DTP03_Date-9]
,''											AS	[2400P_DTP01_DateTimeQualifier_10]
,''											AS	[2400P_DTP02_FormatQualifier_10]
,''											AS	[2400P_DTP03_Date_10]
,''											AS	[2400P_DTP01_DateTimeQualifier_11]
,''											AS	[2400P_DTP02_FormatQualifier-11]
,''											AS	[2400P_DTP03_Date-11]
,''											AS	[2400P_QTY01_QuantityQuakiferID_1]
,''											AS	[2400P_QTY02_Quantity_1]
,''											AS	[2400P_QTY01_QuantityQualiferID_2]
,''											AS	[2400P_QTY02_Quantity_2]
,''											AS	[2400P_MEA01_MeasurementIdentifierCode_1]
,''											AS	[2400P_MEA02_MeasurementQualifier_1]
,''											AS	[2400P_MEA03_MeasurementValue_1]
,''											AS	[2400P_MEA01_MeasurementIdentifierCode_2]
,''											AS	[2400P_MEA02_MeasurementQualifier_2]
,''											AS	[2400P_MEA03_MeasurementValue_2]
,''											AS	[2400P_MEA01_MeasurementIdentifierCode_3]
,''											AS	[2400P_MEA02_MeasurementQualifier_3]
,''											AS	[2400P_MEA03_MeasurementValue_3]
,''											AS	[2400P_MEA01_MeasurementIdentifierCode_4]
,''											AS	[2400P_MEA02_MeasurementQualifier_4]
,''											AS	[2400P_MEA03_MeasurementValue_4]
,''											AS	[2400P_MEA01_MeasurementIdentifierCode_5]
,''											AS	[2400P_MEA02_MeasurementQualifier_5]
,''											AS	[2400P_MEA03_MeasurementValue_5]
,CONTRACT_TYPE													AS	[2400P_CN101_ContractType]
,''											AS	[2400P_CN102_ContractAmount]
,''											AS	[2400P_CN103_ContractPercentage]
,CONTRACT_CODE													AS	[2400P_CN104_ContractCode]
,''											AS	[2400P_CN105_TermsDiscountPercent]
,''											AS	[2400P_CN106_ContractVersionIdentifier]
,''											AS	[2400P_REF01_ServiceRefNumberQualifier_1]
,''											AS	[2400P_REF02_ServiceRefNumber_1]
,''											AS	[2400P_REF01_ServiceRefNumberQualifier_2]
,''											AS	[2400P_REF02_ServiceRefNumber_2]
,''											AS	[2400P_REF01_ServiceRefNumberQualifier_3]
,''											AS	[2400P_REF02_ServiceRefNumber_3]
,''						AS	[2400P_REF01_ServiceRefNumberQualifier_4]
,CLAIM_LINE_NO													AS	[2400P_REF02_ServiceRefNumber_4]
,''											AS	[2400P_REF01_ServiceRefNumberQualifier_5]
,''											AS	[2400P_REF02_ServiceRefNumber_5]
,''											AS	[2400P_REF01_ServiceRefNumberQualifier_6]
,''						AS	[2400P_REF02_ServiceRefNumber_6]
,''	AS	[2400P_REF01_ServiceRefNumberQualifier_7]
,''	AS	[2400P_REF02_ServiceRefNumber_7]
,''											AS	[2400P_REF01_ServiceRefNumberQualifier_8]
,''											AS	[2400P_REF02_ServiceRefNumber_8]
,''											AS	[2400P_REF04-01_AssignedByQualifier_8]
,''											AS	[2400P_REF04-02_AssignedBy_8]
,''											AS	[2400P_REF01_ServiceRefNumberQualifier_9]
,''											AS	[2400P_REF02_ServiceRefNumber_9]
,''											AS	[2400P_REF04-01_AssignedByQualifier_9]
,''											AS	[2400P_REF04-02_AssignedBy_9]
,''											AS	[2400P_AMT01_AmountQualfier_1]
,''											AS	[2400P_AMT02_Amount_1]
,''											AS	[2400P_AMT01_AmountQualfier_2]
,''											AS	[2400P_AMT02_Amount_2]
,''											AS	[2400P_K301_FixedFormatInformation_1]
,''											AS	[2400P_K301_FixedFormatInformation_2]
,''											AS	[2400P_K301_FixedFormatInformation_3]
,''											AS	[2400P_K301_FixedFormatInformation_4]
,''											AS	[2400P_K301_FixedFormatInformation_5]
,''											AS	[2400P_K301_FixedFormatInformation_6]
,''											AS	[2400P_K301_FixedFormatInformation_7]
,''											AS	[2400P_K301_FixedFormatInformation_8]
,''											AS	[2400P_K301_FixedFormatInformation_9]
,''											AS	[2400P_K301_FixedFormatInformation_10]
,''											AS	[2400P_NTE01_NoteType_1]
,''											AS	[2400P_NTE02_Note_1]
,''											AS	[2400P_NTE01_NoteType_2]
,''											AS	[2400P_NTE02_Note_2]
,'' 								AS	[2400P_HCP01_PricingMethod]
,''											AS	[2400P_HCP02_RepricedAllowedAmt]
,''											AS	[2400P_HCP03_RepricedSavingAmt]
,''											AS	[2400P_HCP04_RepricingOrdID]
,''											AS	[2400P_HCP05_PricingRange]
,''											AS	[2400P_HCP06_APGPricingCode]
,''											AS	[2400P_HCP07_APGPricingAmt]
,''											AS	[2400P_HCP09_ServiceType]
,''											AS	[2400P_HCP10_ApprovedServiceCode]
,''											AS	[2400P_HCP11_RepricingUnits]
,''											AS	[2400P_HCP12_RepricingQuantity]
,''											AS	[2400P_HCP13_RejectReasonCode]
,''											AS	[2400P_HCP14_PolicyComplianceCode]
,''											AS	[2400P_HCP15_ExceptionCode]
,''											AS	[2410P_LIN02_DrugCodeType]
,''											AS	[2410P_LIN03_NationalDrugCode]
,''											AS	[2410P_CTP04_Quantity]
,''											AS	[2410P_CTP05-01_Units]
,''											AS	[2410P_REF01_ReferenceIDQualifier]
,''											AS	[2410P_REF02_ReferenceIdentifier]
,''											AS	[2420GP_NM101_ProviderRole]
,''											AS	[2420GP_NM102_PersonIndicator]
,''											AS	[2420GP_N301_AddressLine1]
,''											AS	[2420GP_N302_AddressLine2]
,''											AS	[2420GP_N401_City]
,''											AS	[2420GP_N402_State]
,''											AS	[2420GP_N403_PostalCode]
,''											AS	[2420GP_N404_Country]
,''											AS	[2420HP_NM101_ProviderRole]
,''											AS	[2420HP_NM102_PersonIndicator]
,''											AS	[2420HP_NM103_ORG_LastName]
,''											AS	[2420HP_N301_AddressLine1]
,''											AS	[2420HP_N302_AddressLine2]
,''											AS	[2420HP_N401_City]
,''											AS	[2420HP_N402_State]
,''											AS	[2420HP_N403_PostalCode]
,''											AS	[2420HP_N404_Country]
,''											AS	[2400P_PWK02_DMEAttachmentTransmissionCode]
,''											AS	[2400P_CR301_CertificationTypeCode]
,''											AS	[2400P_CR303_DurableMedicalEquipmentDuration]
,''											AS	[2400P_CRC02_CertificationConditionIndicator]
,''											AS	[2400P_CRC03_ConditionCode]
,''											AS	[2400P_CRC04_ConditionCode]
,''											AS	[2400P_CRC05_ConditionCode]
,''											AS	[2400P_CRC06_ConditionCode]
,''											AS	[2400P_CRC07_ConditionCode]
,''											AS	[2400P_REF01_RepricedLineItemReferenceQualifier]
,''											AS	[2400P_REF02_RepricedLineItemReferenceNumber]
,''											AS	[2400P_PS101_PurchasedSerivceProviderIdentifier]
,''											AS	[2400P_PS102_PurchasedServiceChargeAmount]
,''											AS	[40P-Filler 01]
,CASE WHEN POS = '34' then 'N' else '' END	AS	[40P-Filler 02]  --Subhash Acharya
,''											AS	[40P-Filler 03]
,''											AS	[40P-Filler 04]
,''											AS	[40P-Filler 05]
,''											AS	[2420AP_NM101_ProviderRole]
,''											AS	[2420AP_NM102_PersonIndicator]
,''											AS	[2420AP_NM103_LastName]
,''											AS	[2420AP_NM104_FirstName]
,''											AS	[2420AP_NM105_MiddleName]
,''											AS	[2420AP_NM107_Suffix]
,''											AS	[2420AP_NM108_ProviderIdentifierQualifer]
,''											AS	[2420AP_NM109_ProviderIdentifier]
,''											AS	[2420AP_PRV03_ProviderTaxonomy]
,''											AS	[2420AP_REF01_ProviderIdentifierQualifer_1]
,''											AS	[2420AP_REF02_ProviderIdentifier_1]
,''											AS	[2420AP_REF01_ProviderIdentifierQualifer_2]
,''											AS	[2420AP_REF02_ProviderIdentifier_2]
,''											AS	[2420AP_REF01_ProviderIdentifierQualifer_3]
,''											AS	[2420AP_REF02_ProviderIdentifier_3]
,''											AS	[2420BP_NM101_ProviderRole]
,''											AS	[2420BP_NM102_PersonIndicator]
,''											AS	[2420BP_NM108_ProviderIdentifierQualifer]
,''											AS	[2420BP_NM109_ProviderIdentifier]
,''											AS	[2420BP_REF01_ProviderIdentifierQualifer_1]
,''											AS	[2420BP_REF02_ProviderIdentifier_1]
,''											AS	[2420BP_REF01_ProviderIdentifierQualifer_2]
,''											AS	[2420BP_REF02_ProviderIdentifier_2]
,''											AS	[2420CP_NM101_ProviderRole]
,''											AS	[2420CP_NM102_PersonIndicator]
,''											AS	[2420CP_NM103_LastName]
,''											AS	[2420CP_NM108_ProviderIdentifierQualifer]
,''											AS	[2420CP_NM109_ProviderIdentifier]
,''											AS	[2420CP_N301_AddressLine1]
,''											AS	[2420CP_N302_AddressLine2]
,''											AS	[2420CP_N401_City]
,''											AS	[2420CP_N402_State]
,''											AS	[2420CP_N403_PostalCode]
,''											AS	[2420CP_N404_Country]
,''											AS	[2420CP_REF01_ProviderIdentifierQualifer_1]
,''											AS	[2420CP_REF02_ProviderIdentifier_1]
,''											AS	[2420CP_REF01_ProviderIdentifierQualifer_2]
,''											AS	[2420CP_REF02_ProviderIdentifier_2]
,''											AS	[2420DP_NM101_ProviderRole]
,''											AS	[2420DP_NM102_PersonIndicator]
,''											AS	[2420DP_NM103_LastName]
,''											AS	[2420DP_NM104_FirstName]
,''											AS	[2420DP_NM105_MiddleName]
,''											AS	[2420DP_NM107_Suffix]
,''											AS	[2420DP_NM108_ProviderIdentifierQualifer]
,''											AS	[2420DP_NM109_ProviderIdentifier]
,''											AS	[2420DP_REF01_ProviderIdentifierQualifer_1]
,''											AS	[2420DP_REF02_ProviderIdentifier_1]
,''											AS	[2420DP_REF01_ProviderIdentifierQualifer_2]
,''											AS	[2420DP_REF02_ProviderIdentifier_2]
,''											AS	[2420DP_REF01_ProviderIdentifierQualifer_3]
,''											AS	[2420DP_REF02_ProviderIdentifier_3]
,''											AS	[2420EP_NM101_ProviderRole]
,''											AS	[2420EP_NM102_PersonIndicator]
,''											AS	[2420EP_NM103_LastName]
,''											AS	[2420EP_NM104_FirstName]
,''											AS	[2420EP_NM105_MiddleName]
,''											AS	[2420EP_NM107_Suffix]
,''											AS	[2420EP_NM108_ProviderIdentifierQualifer]
,''											AS	[2420EP_NM109_ProviderIdentifier]
,''											AS	[2420EP_N301_AddressLine1]
,''											AS	[2420EP_N302_AddressLine2]
,''											AS	[2420EP_N401_City]
,''											AS	[2420EP_N402_State]
,''											AS	[2420EP_N403_PostalCode]
,''											AS	[2420EP_N404_Country]
,''											AS	[2420EP_REF01_ProviderIdentifierQualifer_1]
,''											AS	[2420EP_REF02_ProviderIdentifier_1]
,''											AS	[2420EP_REF01_ProviderIdentifierQualifer_2]
,''											AS	[2420EP_REF02_ProviderIdentifier_2]
,''											AS	[2420FP_NM101_ProviderRole]
,''											AS	[2420FP_NM102_PersonIndicator]
,''											AS	[2420FP_NM103_LastName]
,''											AS	[2420FP_NM104_FirstName]
,''											AS	[2420FP_NM105_MiddleName]
,''											AS	[2420FP_NM107_Suffix]
,''											AS	[2420FP_NM108_ProviderIdentifierQualifer]
,''											AS	[2420FP_NM109_ProviderIdentifier]
,''											AS	[2420FP_REF01_ProviderIdentifierQualifer_1]
,''											AS	[2420FP_REF02_ProviderIdentifier_1]
,''											AS	[2420FP_REF01_ProviderIdentifierQualifer_2]
,''											AS	[2420FP_REF02_ProviderIdentifier_2]
,''											AS	[InNetworkIndicator] 
,''											AS	[ServiceLineContractID]
,''											AS	[TPLPaidAmount]
,''											AS	[40P-Filler 9]
,''											AS	[40P-Filler 10]
,''											AS	[40P-Filler 11]
,''											AS	[40P-Filler 12]
,''											AS	[40P-Filler 13]
,''											AS	[40P-Filler 14]
,''											AS	[40P-Filler 15]
,''											AS	[ServiceHealthPlan]
,''											AS	[ServiceBenefitPlan]
,''											AS	[ServiceAdministrativeCounty]
,''											AS	[ServiceResidenceCounty]
,''											AS	[ServiceEligibilityCode]
,''											AS	[ServiceSubProgram1]
,''											AS	[ServiceSubProgram2]
,''											AS	[ServiceSubProgram3]
,''											AS	[ServiceSubProgram4]
,''											AS	[ServiceArrangementCode]
,''											AS	[ServiceTribalCode]
,''											AS	[CategoryOfService] 
,''											AS	[RenderingProviderSpeciality] 
,''											AS	[PurchasedIndicator]
,''											AS	[BH_ESPDTIndicator]
,''											AS	[MPIServiceLocation]
,''											AS	[EBPPCode01]
,''											AS	[EBPPCode02] 
,''											AS	[EBPPCode03]
,''											AS	[EBPPCode04]
,''											AS	[EBPPCode05]
,''											AS	[Ordering Provider Location Code]
,''											AS	[40P_MediaType]
,''											AS	[Beneficiary Cost Sharing Status]
,''											AS	[Out of Pocket Maximum]
,''											AS	[Beneficiary Lock-In STATUS]
--select * 
--FROM WIPRO..OUTB_PROF_DETAIL_hist b
FROM WIPRO..OUTB_PROF_DETAIL b
LEFT JOIN 
		--(select * from
		WIPRO.dbo.Service_Line_Dup_Processing a
		on 
		b.claim_id = a.claim_id
		and a.sourcedatakey = a.sourcedatakey
		and Is_Resubmission_Eligible = '1'
		AND Has_Been_Resubmitted = '0'
		and a.claim_type in ('PRO', 'DME' )
		and a.Error_Code = '98325'

/*---------------------------------------------------------------------*/
/* POPULATE 431P TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_431P_Rec_Detail_Archive 
SELECT *, getdate()  FROM dbo.EE_CSV_431P_Rec_Detail

TRUNCATE TABLE dbo.EE_CSV_431P_Rec_Detail

INSERT INTO [dbo].EE_CSV_431P_Rec_Detail
	(
		[ClaimID]
		,[SourceDataKey]
		,[SourceDesc]
		,[CreateDate]
		,ClaimLineNumber

		,[2430_SVD01_COBPrimaryPayerID]
		,[2430_SVD02_COBServicePaidAmount]
		,[431_ClaimLineDisposition]
		,[2430_SVD03_01_ServiceCodeType]
		,[2430_SVD03_02_ServiceCode]
		,[2430_SVD03_03_ServiceModifier1]
		,[2430_SVD03_04_ServiceModifier2]
		,[2430_SVD03_05_ServiceModifier3]
		,[2430_SVD03_06_ServiceModifier4]
		,[2430_SVD03_07_ServiceCodeDescription]
		,[2430_SVD04_RevenueCode]
		,[2430_SVD05_Quantity]
		,[2430_SVD06_BundledLineNumber]
		,[2430_LineLevelDenial_1]
		,[2430_LineLevelDenial_2]
		,[2430_LineLevelDenial_3]
		,[2430_LineLevelDenial_4]
		,[2430_LineLevelDenial_5]
		,[2430_LineLevelDenial_6]
		,[2430_LineLevelDenial_7]
		,[2430_LineLevelDenial_8]
		,[2430_LineLevelDenial_9]
		,[2430_LineLevelDenial_10]
		,[2430_CAS01_ClaimAdjustmentGroup_1]
		,[2430_CAS02_ClaimAdjustmentReason_1]
		,[2430_CAS03_ClaimAdjustmentAmount_1]
		,[2430_CAS04_ClaimAdjustmentquantity_1]
		,[2430_CAS05_ClaimAdjustmentReason_1]
		,[2430_CAS06_ClaimAdjustmentAmount_1]
		,[2430_CAS07_ClaimAdjustmentquantity_1]
		,[2430_CAS08_ClaimAdjustmentReason_1]
		,[2430_CAS09_ClaimAdjustmentAmount_1]
		,[2430_CAS10_ClaimAdjustmentquantity_1]
		,[2430_CAS11_ClaimAdjustmentReason_1]
		,[2430_CAS12_ClaimAdjustmentAmount_1]
		,[2430_CAS13_ClaimAdjustmentquantity_1]
		,[2430_CAS14_ClaimAdjustmentReason_1]
		,[2430_CAS15_ClaimAdjustmentAmount_1]
		,[2430_CAS16_ClaimAdjustmentquantity_1]
		,[2430_CAS17_ClaimAdjustmentReason_1]
		,[2430_CAS18_ClaimAdjustmentAmount_1]
		,[2430_CAS19_ClaimAdjustmentquantity_1]
		,[2430_CAS01_ClaimAdjustmentGroup_2]
		,[2430_CAS02_ClaimAdjustmentReason_2]
		,[2430_CAS03_ClaimAdjustmentAmount_2]
		,[2430_CAS04_ClaimAdjustmentquantity_2]
		,[2430_CAS05_ClaimAdjustmentReason_2]
		,[2430_CAS06_ClaimAdjustmentAmount_2]
		,[2430_CAS07_ClaimAdjustmentquantity_2]
		,[2430_CAS08_ClaimAdjustmentReason_2]
		,[2430_CAS09_ClaimAdjustmentAmount_2]
		,[2430_CAS10_ClaimAdjustmentquantity_2]
		,[2430_CAS11_ClaimAdjustmentReason_2]
		,[2430_CAS12_ClaimAdjustmentAmount_2]
		,[2430_CAS13_ClaimAdjustmentquantity_2]
		,[2430_CAS14_ClaimAdjustmentReason_2]
		,[2430_CAS15_ClaimAdjustmentAmount_2]
		,[2430_CAS16_ClaimAdjustmentquantity_2]
		,[2430_CAS17_ClaimAdjustmentReason_2]
		,[2430_CAS18_ClaimAdjustmentAmount_2]
		,[2430_CAS19_ClaimAdjustmentquantity_2]
		,[2430_CAS01_ClaimAdjustmentGroup_3]
		,[2430_CAS02_ClaimAdjustmentReason_3]
		,[2430_CAS03_ClaimAdjustmentAmount_3]
		,[2430_CAS04_ClaimAdjustmentquantity_3]
		,[2430_CAS05_ClaimAdjustmentReason_3]
		,[2430_CAS06_ClaimAdjustmentAmount_3]
		,[2430_CAS07_ClaimAdjustmentquantity_3]
		,[2430_CAS08_ClaimAdjustmentReason_3]
		,[2430_CAS09_ClaimAdjustmentAmount_3]
		,[2430_CAS10_ClaimAdjustmentquantity_3]
		,[2430_CAS11_ClaimAdjustmentReason_3]
		,[2430_CAS12_ClaimAdjustmentAmount_3]
		,[2430_CAS13_ClaimAdjustmentquantity_3]
		,[2430_CAS14_ClaimAdjustmentReason_3]
		,[2430_CAS15_ClaimAdjustmentAmount_3]
		,[2430_CAS16_ClaimAdjustmentquantity_3]
		,[2430_CAS17_ClaimAdjustmentReason_3]
		,[2430_CAS18_ClaimAdjustmentAmount_3]
		,[2430_CAS19_ClaimAdjustmentquantity_3]
		,[2430_CAS01_ClaimAdjustmentGroup_4]
		,[2430_CAS02_ClaimAdjustmentReason_4]
		,[2430_CAS03_ClaimAdjustmentAmount_4]
		,[2430_CAS04_ClaimAdjustmentquantity_4]
		,[2430_CAS05_ClaimAdjustmentReason_4]
		,[2430_CAS06_ClaimAdjustmentAmount_4]
		,[2430_CAS07_ClaimAdjustmentquantity_4]
		,[2430_CAS08_ClaimAdjustmentReason_4]
		,[2430_CAS09_ClaimAdjustmentAmount_4]
		,[2430_CAS10_ClaimAdjustmentquantity_4]
		,[2430_CAS11_ClaimAdjustmentReason_4]
		,[2430_CAS12_ClaimAdjustmentAmount_4]
		,[2430_CAS13_ClaimAdjustmentquantity_4]
		,[2430_CAS14_ClaimAdjustmentReason_4]
		,[2430_CAS15_ClaimAdjustmentAmount_4]
		,[2430_CAS16_ClaimAdjustmentquantity_4]
		,[2430_CAS17_ClaimAdjustmentReason_4]
		,[2430_CAS18_ClaimAdjustmentAmount_4]
		,[2430_CAS19_ClaimAdjustmentquantity_4]
		,[2430_CAS01_ClaimAdjustmentGroup_5]
		,[2430_CAS02_ClaimAdjustmentReason_5]
		,[2430_CAS03_ClaimAdjustmentAmount_5]
		,[2430_CAS04_ClaimAdjustmentquantity_5]
		,[2430_CAS05_ClaimAdjustmentReason_5]
		,[2430_CAS06_ClaimAdjustmentAmount_5]
		,[2430_CAS07_ClaimAdjustmentquantity_5]
		,[2430_CAS08_ClaimAdjustmentReason_5]
		,[2430_CAS09_ClaimAdjustmentAmount_5]
		,[2430_CAS10_ClaimAdjustmentquantity_5]
		,[2430_CAS11_ClaimAdjustmentReason_5]
		,[2430_CAS12_ClaimAdjustmentAmount_5]
		,[2430_CAS13_ClaimAdjustmentquantity_5]
		,[2430_CAS14_ClaimAdjustmentReason_5]
		,[2430_CAS15_ClaimAdjustmentAmount_5]
		,[2430_CAS16_ClaimAdjustmentquantity_5]
		,[2430_CAS17_ClaimAdjustmentReason_5]
		,[2430_CAS18_ClaimAdjustmentAmount_5]
		,[2430_CAS19_ClaimAdjustmentquantity_5]
		,[2430_DTP01_DateTimeQualifier]
		,[2430_DTP02_DateTimeFormat]
		,[2430_DTP03_ServicePaidDate]
		,[2430_AMT01_AmountQualifier]
		,[2430_AMT02_PatientLiabilityAmount]
		,[431_Allowed_Amount]
		,[EOB_CODE]
		,[AccommodationCode]
		,[431_Filler_03]
		,[431_Filler_04]
		,[431_Filler_05]
		,[431_Filler_06]
		,[431_Filler_07]
		,[431_Filler_08]
		,[431_Filler_09]
		,[431_Filler_10]
		,[431_Filler_11]
		,[431_Filler_12]
		,[431_Filler_13]
		,[431_Filler_14]
		,[431_Filler_15]
		,[431_RecipientAidCategory]
	)
	SELECT 
		DISTINCT
		A.CLAIM_ID					--[ClaimID]
		,A.SOURCEDATAKEY			--[SourceDataKey]
		,'' 						--SourceDesc
		,GETDATE()					--[CreateDate]
		,CLAIM_LINE_NO AS ClaimLineNumber --ClaimLineNumber	

		,A.OTH_PAYER1_PRIMEID		-- 2430_SVD01_COBPrimaryPayerID  
		,A.OTH_PAYER1_PAID_AMT		-- 2430_SVD02_COBServicePaidAmount

		,CASE						--431_ClaimLineDisposition
			WHEN 1 = 1 THEN '1'		--Processed as Primary
			WHEN 1 = 1 THEN '2'		--Processed as Secondar
			WHEN 1 = 1 THEN '3'		--Processed as Tertiary
			WHEN 1 = 1 THEN '4'		--Denied
			WHEN 1 = 1 THEN '19'	--Processed as Primary, forwarded to additional Payers
			WHEN 1 = 1 THEN '20'	--Processed as Secondary, forwarded to additional Payers
			WHEN 1 = 1 THEN '21'	--Processed as Tertiary, forwarded to additional Payers
			WHEN 1 = 1 THEN '22'	--Processed as Reversal of Previous Payment
			WHEN 1 = 1 THEN '23'	--Not our claim, forwarded to additional Payers
			WHEN 1 = 1 THEN '25'	--Predetermination Pricing Only - No Payment
		END

		,SERV_ID_QUAL -- Updated EDS-2188 'HC'	--2430_SVD03_01_ServiceCodeType
		,A.PROC_CD					--2430_SVD03_02_ServiceCode
		--,A.PROC_MOD1				--2430_SVD03_03_ServiceModifier1
		--,A.PROC_MOD2				--2430_SVD03_04_ServiceModifier2
		--,A.PROC_MOD3				--2430_SVD03_05_ServiceModifier3
		--,A.PROC_MOD4				--2430_SVD03_06_ServiceModifier4
		,CASE WHEN c.claim_id is NOT NULL and isnull(PROC_CD,'') <> '' and 
				  PROC_MOD1 = '59' OR PROC_MOD2 = '59' or PROC_MOD3 = '59' or PROC_MOD3 = '59'	or PROC_MOD4 = '59'  THEN PROC_MOD1
			 WHEN c.claim_id is NOT NULL and isnull(PROC_CD,'') <> ''  and isnull(PROC_MOD1,'') = '' and ( isnull(PROC_MOD2,'') <> '59' or isnull(PROC_MOD3,'') <> '59' or isnull(PROC_MOD4,'') <> '59') THEN '59'
			  ELSE PROC_MOD1 END
										
																		AS	[2400P_SV101-03_ServiceModifier1]
		,CASE WHEN c.claim_id is NOT NULL and isnull(PROC_CD,'') <> '' and 
				  PROC_MOD1 = '59' OR PROC_MOD2 = '59' or PROC_MOD3 = '59' or PROC_MOD3 = '59'	or PROC_MOD4 = '59'  THEN PROC_MOD2
			 WHEN c.claim_id is NOT NULL and (isnull(PROC_CD,'') <> '' and (isnull(PROC_MOD2,'') = '' and isnull(PROC_MOD1,'') <> ''))
								THEN '59'
			  ELSE PROC_MOD2 END													
																		AS	[2400P_SV101-04_ServiceModifier2]
		,CASE WHEN c.claim_id is NOT NULL and isnull(PROC_CD,'') <> '' and 
				  PROC_MOD1 = '59' OR PROC_MOD2 = '59' or PROC_MOD3 = '59' or PROC_MOD3 = '59'	or PROC_MOD4 = '59'  THEN PROC_MOD3
			  WHEN c.claim_id is NOT NULL and (isnull(PROC_CD,'') <> '' and (isnull(PROC_MOD3,'') = '' and isnull(PROC_MOD1,'') <> '') and isnull(PROC_MOD2,'') <> '')
								 THEN '59'
			  else PROC_MOD3 END												
																		 AS	[2400P_SV101-05_ServiceModifier3]
		,CASE WHEN c.claim_id is NOT NULL and isnull(PROC_CD,'') <> '' and 
				  PROC_MOD1 = '59' OR PROC_MOD2 = '59' or PROC_MOD3 = '59' or PROC_MOD3 = '59'	or PROC_MOD4 = '59'  THEN PROC_MOD4
				WHEN c.claim_id is NOT NULL and (isnull(PROC_CD,'') <> '' and (isnull(PROC_MOD4,'') = '' and isnull(PROC_MOD1,'') <> '') and isnull(PROC_MOD2,'') <> '' and isnull(PROC_MOD3,'') <> '')
								 THEN '59'
				WHEN c.claim_id is NOT NULL and (isnull(PROC_CD,'') <> '' and (isnull(PROC_MOD4,'') <> '' and isnull(PROC_MOD1,'') <> '') and isnull(PROC_MOD2,'') <> '' and isnull(PROC_MOD3,'') <> '')
								 THEN '59'
	    ELSE PROC_MOD4 END									
																						
																AS	[2400P_SV101-06_ServiceModifier4]												

		,A.PROC_DESC				--2430_SVD03_07_ServiceCodeDescription
		,''							--2430_SVD04_RevenueCode (Yes on Institutional side and not on Professional) 
		,A.OTH_PAYER1_PAID_QTY		--2430_SVD05_Quantity
		,A.OTH_PAYER1_ADJ_BUNDLE	--2430_SVD06_BundledLineNumber
		,''							--2430_LineLevelDenial_1
		,''							--2430_LineLevelDenial_2
		,''							--2430_LineLevelDenial_3
		,''							--2430_LineLevelDenial_4
		,''							--2430_LineLevelDenial_5
		,''							--2430_LineLevelDenial_6
		,''							--2430_LineLevelDenial_7
		,''							--2430_LineLevelDenial_8
		,''							--2430_LineLevelDenial_9
		,''							--2430_LineLevelDenial_10
		,A.CLM_ADJ_GRP111			--2430_CAS01_ClaimAdjustmentGroup_1
		,A.CLM_ADJ_REASON111		--2430_CAS02_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT111			--2430_CAS03_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY111			--2430_CAS04_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_REASON112		--2430_CAS05_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT112			--2430_CAS06_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY112			--2430_CAS07_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_REASON113		--2430_CAS08_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT113			--2430_CAS09_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY113			--2430_CAS10_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_REASON114		--2430_CAS11_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT114			--2430_CAS12_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY114			--2430_CAS13_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_REASON115		--2430_CAS14_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT115			--2430_CAS15_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY115			--2430_CAS16_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_REASON116		--2430_CAS17_ClaimAdjustmentReason_1
		,A.CLM_ADJ_AMT116			--2430_CAS18_ClaimAdjustmentAmount_1
		,A.CLM_ADJ_QTY116			--2430_CAS19_ClaimAdjustmentquantity_1
		,A.CLM_ADJ_GRP12			--2430_CAS01_ClaimAdjustmentGroup_2
		,A.CLM_ADJ_REASON121		--2430_CAS02_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT121			--2430_CAS03_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY121			--2430_CAS04_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_REASON122		--2430_CAS05_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT122			--2430_CAS06_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY122			--2430_CAS07_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_REASON123		--2430_CAS08_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT123			--2430_CAS09_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY123			--2430_CAS10_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_REASON124		--2430_CAS11_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT124			--2430_CAS12_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY124			--2430_CAS13_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_REASON125		--2430_CAS14_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT125			--2430_CAS15_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY125			--2430_CAS16_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_REASON126		--2430_CAS17_ClaimAdjustmentReason_2
		,A.CLM_ADJ_AMT126			--2430_CAS18_ClaimAdjustmentAmount_2
		,A.CLM_ADJ_QTY126			--2430_CAS19_ClaimAdjustmentquantity_2
		,A.CLM_ADJ_GRP13			--2430_CAS01_ClaimAdjustmentGroup_3
		,A.CLM_ADJ_REASON131		--2430_CAS02_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT131			--2430_CAS03_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY131			--2430_CAS04_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_REASON132		--2430_CAS05_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT132			--2430_CAS06_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY132			--2430_CAS07_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_REASON133		--2430_CAS08_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT133			--2430_CAS09_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY133			--2430_CAS10_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_REASON134		--2430_CAS11_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT134			--2430_CAS12_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY134			--2430_CAS13_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_REASON135		--2430_CAS14_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT135			--2430_CAS15_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY135			--2430_CAS16_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_REASON136		--2430_CAS17_ClaimAdjustmentReason_3
		,A.CLM_ADJ_AMT136			--2430_CAS18_ClaimAdjustmentAmount_3
		,A.CLM_ADJ_QTY136			--2430_CAS19_ClaimAdjustmentquantity_3
		,A.CLM_ADJ_GRP14			--2430_CAS01_ClaimAdjustmentGroup_4
		,A.CLM_ADJ_REASON141		--2430_CAS02_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT141			--2430_CAS03_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY141			--2430_CAS04_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_REASON142		--2430_CAS05_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT142			--2430_CAS06_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY142			--2430_CAS07_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_REASON143		--2430_CAS08_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT143			--2430_CAS09_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY143			--2430_CAS10_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_REASON144		--2430_CAS11_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT144			--2430_CAS12_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY144			--2430_CAS13_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_REASON145		--2430_CAS14_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT145			--2430_CAS15_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY145			--2430_CAS16_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_REASON146		--2430_CAS17_ClaimAdjustmentReason_4
		,A.CLM_ADJ_AMT146			--2430_CAS18_ClaimAdjustmentAmount_4
		,A.CLM_ADJ_QTY146			--2430_CAS19_ClaimAdjustmentquantity_4
		,A.CLM_ADJ_GRP15			--2430_CAS01_ClaimAdjustmentGroup_5
		,A.CLM_ADJ_REASON151		--2430_CAS02_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT151			--2430_CAS03_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY151			--2430_CAS04_ClaimAdjustmentquantity_5
		,A.CLM_ADJ_REASON152		--2430_CAS05_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT152			--2430_CAS06_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY152			--2430_CAS07_ClaimAdjustmentquantity_5
		,A.CLM_ADJ_REASON153		--2430_CAS08_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT153			--2430_CAS09_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY153			--2430_CAS10_ClaimAdjustmentquantity_5
		,A.CLM_ADJ_REASON154		--2430_CAS11_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT154			--2430_CAS12_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY154			--2430_CAS13_ClaimAdjustmentquantity_5
		,A.CLM_ADJ_REASON155		--2430_CAS14_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT155			--2430_CAS15_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY155			--2430_CAS16_ClaimAdjustmentquantity_5
		,A.CLM_ADJ_REASON156		--2430_CAS17_ClaimAdjustmentReason_5
		,A.CLM_ADJ_AMT156			--2430_CAS18_ClaimAdjustmentAmount_5
		,A.CLM_ADJ_QTY156			--2430_CAS19_ClaimAdjustmentquantity_5
		,''						--2430_DTP01_DateTimeQualifier
		,''						--2430_DTP02_DateTimeFormat
		,A.OTH_PAYER1_ADJ_DT			--2430_DTP03_ServicePaidDate  ONLY FOR PROFESSIONAL CLAIMS
		,''						--2430_AMT01_AmountQualifier
		,B.PATIENT_EST_AMT_DUE		--2430_AMT02_PatientLiabilityAmount  ONLY FOR PROFESSIONAL CLAIMS
		,'' 						--431_Allowed_Amount
		,''							--EOB_CODE
		,''							--AccommodationCode
		,''							--431_Filler_03
		,''							--431_Filler_04
		,''							--431_Filler_05
		,''							--431_Filler_06
		,''							--431_Filler_07
		,''							--431_Filler_08
		,''							--431_Filler_09
		,''							--431_Filler_10
		,''							--431_Filler_11
		,''							--431_Filler_12
		,''							--431_Filler_13
		,''							--431_Filler_14
		,''							--431_Filler_15
		,''							--431_RecipientAidCategory
	FROM WIPRO.DBO.OUTB_PROF_DETAIL A
	JOIN WIPRO.DBO.OUTB_PROF_HEADER B
		ON B.SOURCEDATAKEY = A.SOURCEDATAKEY
		AND B.CLAIM_ID = A.CLAIM_ID
LEFT JOIN 
		(select * from
		WIPRO.dbo.Service_Line_Dup_Processing a
		where Is_Resubmission_Eligible = '1'
		AND Has_Been_Resubmitted = '0'
		and a.claim_type in ('PRO', 'DME' )
		and a.Error_Code = '98325'
		) c
		on c.claim_id = a.claim_id
		and c.sourcedatakey = a.sourcedatakey

/*---------------------------------------------------------------------*/
/* UPDATE SYSLOG                                                       */
/*---------------------------------------------------------------------*/

SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_PROF_HEADER)
									
				BEGIN TRANSACTION
						UPDATE  WIPRO.dbo.EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_EDIFECS_PROF_CSV_40P_431P_Detail'
										and END_DT is null
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
