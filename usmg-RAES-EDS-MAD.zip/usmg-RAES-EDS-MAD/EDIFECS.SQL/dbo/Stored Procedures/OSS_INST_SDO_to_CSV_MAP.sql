CREATE PROCEDURE [dbo].[OSS_INST_SDO_to_CSV_MAP]
(@IsResub BIT = 0 --default to regular run
 ,@IsRetraction BIT = 0)
AS
/********************************************************************************************************************************************************************
  HISTORY: 
  07-02-2024		Aaron Ridley    Created to map finalized claims in the OSS.dbo.SDO* tables into preliminary CSV staging schema

*********************************************************************************************************************************************************************/
/* Modifications
ASU 2024-09-19 RETM-721
	Added optional parameter @IsResub to handle submission of resub items
--
*/

DECLARE @TOTAL_RECORDS INT
		,@Procedure_Name VARCHAR(75) = 'EDIFECS.dbo.OSS_INST_SDO_to_CSV_MAP';
	
	--SYSLOG INSERT INITIATING PROCESS 
	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG (PROC_NAME
	, START_DT
	, END_DT
	, RUN_MINUTES
	, TOTAL_RECORDS
	, ENTRYDT)
		VALUES (@Procedure_Name, GETDATE(), NULL, NULL, 0, GETDATE());  


/********************************************************************************************************************************************************************
  100 RECORD INSERT 
*********************************************************************************************************************************************************************/

TRUNCATE TABLE EDIFECS.staging.EE_CSV_100I_Rec_Header;

INSERT INTO EDIFECS.staging.EE_CSV_100I_Rec_Header
SELECT	DISTINCT  
		CLMHDR.CLM_ID,
		CLMHDR.SRC_DATA_KEY,
		CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END, 
		getdate(),
		'',
		CASE WHEN CLMHDR.CLM_FRM_TY_CD = 'H' THEN 'P' ELSE 'I' END,
		'CHSAZCLP' , --SenderID
		'CHSAZAPP', --ReceiverID
		'', --OriginatorID
		CLMHDR.[CNTRCT_NUM], 
		'EDSCMS',
		'',     --    HistoricalIndicator
		'',     --    HistoricalDispositionStatus
		'',     -- HistoricalICN
		'',     --HistoricalEncounterID
		CASE WHEN CLM_SBMSN_TY = 'PAPER' THEN CLM_SBMSN_TY ELSE '' END AS PaperFlag, 
		CASE WHEN ECP.[ISDME] = 1  THEN 'TRUE' ELSE 'FALSE' END as DMEFlag,  
		'',		-- AdministrativeDenial
		'',		-- ChartReviewData
		CLMHDR.SRC_DATA_KEY,
		CASE WHEN ECP.[ISADJUSTMENT] = 1  THEN 'TRUE' ELSE 'FALSE' END,
		'',     --    TraceNumber
		'',     --    NM1010A_SubmitterEntityRole
		'',     --    NM1020A_SubmitterPersonIndicator
		'',     --    NM1030A_SubmitterLastName 
		'',     --    NM1080A_SubmitterIdentifierQualifier
		'',     --    NM1090A_SubmitterIdentifier
		'',     --    PER010A_01_SubmitterContactIdentifier
		'',     --    PER020A_01_SubmitterContactName
		'',     --    PER030A_01_SubmitterContactQualifier1 TE,EM,FX
		'',     --    PER040A_01_SubmitterContact1
		'',     --    PER050A_01_SubmitterContacQualifier2 TE,EM,FX, EX
		'',     --    PER060A_01_SubmitterContact2
		'',     --    NM1010B_ReceiverEntityRole
		'',     --    NM1020B_PersonIndicator
		'',     --    NM1030B_ReceiverName
		'',     --    NM1080B_ReceiverIdentifierQualifier
		'',     --    NM1090B_ReceiverIdentifier
		'',     --    PRV01A_BillingProviderCode
		'',     --    PRV02A_BillingProviderCodeQualifier
		CLMHDR.PROV_TAXNMY_CD,
		'',     --    NM101AA_BillingProviderRole
		'',
		CASE WHEN PROV.LAST_NM IS NULL THEN PROV.PROV_NM ELSE PROV.LAST_NM END,
		CASE WHEN PROV.FRST_NM IS NULL THEN '' ELSE PROV.FRST_NM END,
		CASE WHEN PROV.MID_NM IS NULL THEN '' ELSE PROV.MID_NM END,
		'',     --    NM107AA_BillingSuffix
		'',     --    NM108AA_BillingProviderIdentifierQualifier
		CLMHDR.[PROV_BILL_ENTTY_NPI],
		COALESCE(PROV.MAIL_SRC_ADDR_LN_1, PROV.BUS_SRC_ADDR_LN_1),
		COALESCE(PROV.MAIL_SRC_ADDR_LN_2, PROV.BUS_SRC_ADDR_LN_2),
		COALESCE(PROV.MAIL_SRC_CITY,PROV.BUS_SRC_CITY),
		COALESCE(PROV.MAIL_SRC_STE,PROV.BUS_SRC_STE),
		COALESCE(PROV.MAIL_SRC_ZIP_CD, PROV.BUS_SRC_ZIP_CD),
		'',     --    N404AA_BillingCountry
		'',     --    REF01AA_BillingProviderIdentifierQualifier01
		PROV.PROV_TIN,
		'',     --    REF01AA_BillingProviderIdentifierQualifier02
		'',     --    REF02AA_BillingProviderIdentifier02
		'',     --    BillingProviderSpecialityAA
		'',     --    BillingProviderTypeAA
		'',     --    PER0AA1_BillingProviderContactFunction_1
		'',     --    PER02AA_BillingProviderContactName_1
		'',     --    PER03AA_BillingProviderCommunicationNumberQualifier_1
		'',     --    PER04AA_BillingProviderCommunicationNumber_1
		'',     --    PER05AA_BillingProviderCommunicatioNumberQualifier_1
		'',     --    PER06AA_BillingProviderCommunicationNumber_1
		'',     --    PER07AA_BillingProviderCommunicatioNumberQualifier_1
		'',     --    PER08AA_BillingProviderCommunicationNumber_1
		'',     --    PER01AA_BillingProviderContactFunction_2
		'',     --    PER02AA_BillingProviderContactName_2
		'',     --    PER03AA_CommunicatioNumberQualifier_2
		'',     --    PER04AA_BillingProviderCommunicationNumber_2
		'',     --    PER05AA_BillingProviderCommunicatioNumberQualifier_2
		'',     --    PER06AA_BillingProviderCommunicationNumber_2
		'',     --    PER07AA_BillingProviderCommunicatioNumberQualifier_2
		'',     --    PER08AA_BillingProviderCommunicationNumber_2
		'',     --    NM101AB_PayToProviderRole
		'',     --    NM102AB_PayToPersonIndicator
		'',     --    N301AB_PayToAddressLine1
		'',     --    N302AB_PayToAddressLine2
		'',     --    N401AB_PayToCity
		'',     --    N402AB_PayToState
		'',     --    N403AB_PayToPostalCode
		'',     --    N404AB_PayToCountry
		'',     --    NM101AC_PayToPlanOrganizationRole
		'',     --    NM102AC_PayToPlanPersonIndicator
		'',     --    NM103AC_PayToPlanName
		'',     --    NM108AC_PayToPlanOrganizationIDQualifier
		'',     --    NM109AC_PayToPlanOrganizationIdentifier
		'',     --    N301AC_PayToPlanAddressLine1
		'',     --    N302AC_PayToPlanAddressLine2
		'',     --    N401AC_PayToPlanCity
		'',     --    N402AC_PayToPlanState
		'',     --    N403AC_PayToPlanPostalCode
		'',     --    N404AC_PayToPlanCountry
		'',     --    REF01AC_OrganizationIDQualifier_1
		'',     --    REF02AC_OrganizationIdentifier_1
		'',     --    REF01AC_OrganizationIDQualifier_2
		'',     --    REF02AC_OrganizationIdentifier_2
		'',     --    ClaimEncounterCleanup
		CASE WHEN CLMHDR.[PROV_BILL_ENTTY_NPI] IN ('1999999976','1999999984','1999999992') THEN 'Y'
			 WHEN CLMHDR.[PROV_BILL_ENTTY_NPI] IN ('1999999997','1999999998','1999999999') THEN 'Y'
			 ELSE 'N'
		END,      --    AtypicalProviderFlag   
		'',     --    SupplementalInterimFlag
		'',     --    InterimLateChargeFlag
		'',     --    IssuerIdentifier
		'',     --    Filler05
		'',     --    R_MonetaryAmountChangeFlag
		'',     --    NM1040ASubmitterFirstName
		'',     --    BillingCountyCode
		'',     --    Filler06
		'',     --    ClaimInputMethod
		'',     --    RehabFlag
		'',     --    PSCustomField01
		'',     --    VoidReason
		'',     --    PSCustomField02
		'',     --    Filler12
		'',     --    Filler13
		CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END,    --    Filler14 
		'',     --    Filler15	
		CASE WHEN ECP.[ISADJUSTMENT] = 1  THEN 'TRUE' ELSE 'FALSE' END, --    Filler16
		CASE 
				 WHEN CLMHDR.PREV_CLM_ID = '' OR CLMHDR.PREV_CLM_ID IS NULL THEN ''
				 WHEN ECP.[ISADJUSTMENT] = 1 AND CLMHDR.[IS_ENCNTR_IND] <> 'Y' THEN CAST(CLMHDR.SRC_DATA_KEY AS VARCHAR) + CLMHDR.PREV_CLM_ID
   --Remove above  WHEN ECP.ISENCOUNTER = 0 AND ECP.LOB_CODE <> 'C54581391' THEN CAST(CLMHDR.SRC_DATA_KEY AS VARCHAR) + CLMHDR.[PATNT_CTL_NUM
    --  		 WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLMHDR.[PATNT_CTL_NUM]
			 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLMHDR.[PATNT_CTL_NUM]	
			 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLMHDR.[PATNT_CTL_NUM]	
			 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLMHDR.[PATNT_CTL_NUM] -- 2300P_CLM01_ClaimNumber
	   -- 	 WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391'  AND ECP.LOB = 'MMAI' AND CLMHDR.ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLMHDR.[PATNT_CTL_NUM]
			 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391'  AND ECP.LOB = 'CAID' AND CLMHDR.ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLMHDR.[PATNT_CTL_NUM]
			 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391' AND ECP.LOB = 'MMAI' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLMHDR.[PATNT_CTL_NUM]
			 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391' AND ECP.LOB = 'CAID' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLMHDR.[PATNT_CTL_NUM]
			 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '45' + CLMHDR.CLM_ID -- RETM-11
			 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391' AND ECP.LOB = 'MMAI' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '451' + CLMHDR.CLM_ID -- RETM-11
			 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE = 'C54581391' AND ECP.LOB = 'CAID' AND CLMHDR.ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '452' + CLMHDR.CLM_ID -- RETM-11
			 --WHEN ECP.ISENCOUNTER = 1 AND ECP.LOB_CODE <> 'C54581391' AND CLMHDR.ENCNTR_SRC_VENDR_NM  IN ('Catasys', 'EDPS-Catasys') THEN '46' + CLMHDR.[PATNT_CTL_NUM]
			 --WHEN ECP.LOB = 'MMAI' AND ECP.LOB_CODE = 'C54581391' THEN '51' + CLMHDR.[PATNT_CTL_NUM]
	   --      WHEN ECP.LOB = 'CAID' AND ECP.LOB_CODE = 'C54581391' THEN '52' + CLMHDR.[PATNT_CTL_NUM]
	     END --Filler17
FROM  OSS.[dbo].[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR 
INNER JOIN WIPRO.[dbo].[EDS_Claims_Processing] ECP ON CLMHDR.CLM_ID = ECP.CLAIMID
LEFT OUTER JOIN OSS.staging.[CDO_PROV_DEMG] PROV ON CLMHDR.[PROV_BILL_ENTTY_ID] = PROV.[PROV_ID] 
LEFT JOIN WIPRO.dbo.Retraction_Input_Interim RII ON ECP.CLAIMID = RII.CLAIMID
WHERE 1 = 1
	AND CLMHDR.CLM_TY = 'INSTITUTIONAL'
	AND (	   (IsResub = CASE WHEN @IsResub = 0 AND @IsRetraction = 0 THEN 0 END AND ECP.MEDICARESUBMISSIONDATE IS NULL) --regular run
			OR (IsResub = CASE WHEN @IsResub = 1 THEN 1 END ) --resub run
			OR (IsRetraction = CASE WHEN @IsRetraction = 1 THEN 1 END AND RII.CLAIMID IS NOT NULL) --Retraction Run
		)
OPTION (OPTIMIZE FOR (@IsResub = 0)); --optimize for non-resub runs

/********************************************************************************************************************************************************************
  150 RECORD INSERT 
*********************************************************************************************************************************************************************/

TRUNCATE TABLE EDIFECS.staging.EE_CSV_150I_Rec_Header;

INSERT INTO EDIFECS.staging.EE_CSV_150I_Rec_Header
SELECT	DISTINCT
		CLMHDR.CLM_ID,
		CLMHDR.SRC_DATA_KEY,
		CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END, --System_Source (Data Gap)
		GETDATE(), 
		'',        -- SBR01BSubscriberPayerResponsibilitySequence - varchar(100)
		'',        -- SBR02BSubscriberRelationship - varchar(100)
		'',        -- SBR03BSubscriberPolicyNumber - varchar(100)
		'',        -- SBR04BInsuredGroupName - varchar(100)
		'16' as SBR09BClaimFilingIndicator,		-- SBR09BClaimFilingIndicator (Data Gap)
		'',        -- NM101BASubscriberPersonRole - varchar(100)
		'',        -- NM102BASubscriberPersonIndicator - varchar(100)
		CLMHDR.[MBR_LAST_NM],
		CLMHDR.[MBR_FRST_NM],
		CLMHDR.[MBR_MID_NM],
		'' as NM107BASubscriberSuffix,			-- NM107BASubscriberSuffix  
		'',        -- NM108BASubscriberIdentifierQualifer - varchar(100)
		CLMHDR.MBR_ID,
		'',        -- REF01BASubscriberSSNQualifier - varchar(100)
		MEM.SSN,
		'',        -- REF01BAPropertyandCasualtyQualifier - varchar(100)
		'',        -- REF02BAPropertyandCasualtyIdentifier - varchar(100)
		COALESCE([MAIL_SRC_ADDR_LN_1],MEM.PHY_SRC_ADDR_LN_1),
		COALESCE([MAIL_SRC_ADDR_LN_2],MEM.PHY_SRC_ADDR_LN_2),
		COALESCE([MAIL_SRC_CITY],MEM.PHY_SRC_CITY),
		COALESCE([MAIL_SRC_STE],MEM.PHY_SRC_STE), 
		COALESCE([MAIL_SRC_ZIP_CD],MEM.PHY_SRC_ZIP_CD),
		'',        -- N404BASubscriberCountry - varchar(100)
		'',        -- DMG01BADateQualifer - varchar(100)
		CONVERT(CHAR(8),MEM.DT_OF_BRTH,112),  
		MEM.GENDR, 
		'',        -- REF01BASubscriberIdentifierQualifier01 - varchar(100)
		'',        -- REF02BASubscriberIdentifier01 - varchar(100)
		'',        -- REF01BASubscriberIdentifierQualifer02 - varchar(100)
		MEM.MEDCR_ID,
		'',        -- NM101BBPayerOrganizationRole - varchar(100)
		'',        -- NM102BBPayerPersonIndicator - varchar(100)
		'',		   -- Commented out EDS-2185 oph.OTH_PAYER1_NAME,        -- NM103BBPayerName - varchar(100)
		'',        -- NM108BBPayerOrganizationIDQualifier - varchar(100)
		'',        -- NM109BBPayerOrganizationIdentifier - varchar(100)
		'' as N301BBPayerAddressLine1,         -- N301BBPayerAddressLine1 - varchar(100) (Data Gap)
		'' as N302BBPayerAddressLine2,        -- N302BBPayerAddressLine2 - varchar(100) (Data Gap)
		'' as N42010BB_N401_PayerCity,        --[2010BB_N401_PayerCity]  [VARCHAR] (100)   Default '', (Data Gap)
		'' as N401BBPayerState,        -- N401BBPayerState - varchar(100) (Data Gap)
		'' as N403BBPayerPostalCode,        -- N403BBPayerPostalCode - varchar(100) (Data Gap)
		'',        -- N404BBPayerCountry - varchar(100)
		'',        -- REF01BBPayerOrganizationIDQualifier01 - varchar(100)
		'',        -- REF02BBPayerOrganizationIdentifier01 - varchar(100)
		'',        -- REF01BBProviderIDQualifier01 - varchar(100)
		'',        -- REF02BBBillingProviderIdentifier01 - varchar(100)
		'',        -- REF01BBBillingProviderIDQualifier02 - varchar(100)
		'',        -- REF02BBBillingProviderIdentifier02 - varchar(100)
		'',        -- REF01BBBillingProviderIDQualifier03 - varchar(100)
		'',        -- REF02BBProviderIdentifier03 - varchar(100)
		'',        -- REF01BBBillingProviderIDQualifier04 - varchar(100)
		'',        -- REF02BBBillingProviderIdentifier04 - varchar(100)
		'',        -- PatientLastName - varchar(100)
		'',        -- PatientFirstName - varchar(100)
		'',        -- PatientMiddleName - varchar(100)
		'',        -- PatientSSN - varchar(100)
		'',        -- PatientMemberID - varchar(100)
		'',        -- PatientGender - varchar(100)
		'',        -- PatientDOB - varchar(100)
		'',        -- PatientAddressLine1 - varchar(100)
		'',        -- PatientAddressLine2 - varchar(100)
		'',        -- PatientAddressCity - varchar(100)
		'',        -- PatientAddressState - varchar(100)
		'',        -- PatientAddressZip - varchar(100)
		'',        -- PCPIDQual - varchar(100)
		'',        -- PCPID - varchar(100)
		'',        -- PCPGroupIdentifier - varchar(100)
		'',        -- PDPIPAPMGType - varchar(100)
		'',        -- PDPIPAPMGID - varchar(100)
		'',        -- PCPOpenIndic - varchar(100)
		'',        -- PCPEligibilityInd - varchar(100)
		'',        -- COS - varchar(100)
		'',        -- ServiceCategoryType - varchar(100)
		'',        -- RenderingProvEffDate - varchar(100)
		'',        -- RenderingProvTermDate - varchar(100)
		'',        -- RenderingProvDEAID - varchar(100)
		'',        -- RenderingProvGender - varchar(100)
		'',        -- ProviderParNonPar - varchar(100)
		'',        -- CarePlanOptionIndicator - varchar(100)
		'',        -- GroupIndicator - varchar(100)
		'',        -- CareTypeCode - varchar(100)
		'',        -- FinancialArrangementCode - varchar(100)
		'',        -- Filler05 - varchar(100) -- Aaron -- Utilize for Member Reimbursement Flag (only for Professional)  Y -SDK=30 only
		'',        --oph.OTH_INSR_TYPECD1,  iNSURANCETYPECODE
		'',        -- PAT09BPregnancyIndicator - varchar(100)
		'',        -- Filler06 - varchar(100)
		'',        -- Filler07 - varchar(100)
		'',        -- Filler08 - varchar(100)
		'',        -- Filler09 - varchar(100)
		'',        -- Filler10 - varchar(100)
		'',        -- Filler11 - varchar(100)
		'',        -- Filler12 - varchar(100)
		'',        -- Filler13 - varchar(100)
		'',        -- Filler14 - varchar(100)
		'',        -- Filler15 - varchar(100)
		'',        -- PAT06BPatientDeathDate - varchar(100)
		'',        -- PAT01CPatientRelationship - varchar(100)
		'',        -- PAT06CPatientDeathDate - varchar(100)
		'',        -- PAT08CPatientWeight - varchar(100)
		'',        -- PAT09CPregnancyIndicator - varchar(100)
		'',        -- SubscriberRegionCode - varchar(100)
		'',        -- SubscriberOtherInsuranceCoverage - varchar(100)
		'',        -- PurchasedIndicator - varchar(100)
		''         -- BehavioralHealthCOS - varchar(100)
from OSS.[dbo].[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR
INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CLMHDR.CLM_ID = CSVP.ClaimID
left join OSS.staging.[CDO_MBR_DEMG] MEM ON CLMHDR.MBR_ID = MEM.MBR_ID AND CLMHDR.SRC_DATA_KEY = MEM.SRC_DATA_KEY


 /********************************************************************************************************************************************************************
 UDPATE MEMBER DATA FOR MEMBERS INFO NOT UPDATED DUE TO SDK MISMATCH
*********************************************************************************************************************************************************************/
UPDATE EDIFECS.staging.EE_CSV_150I_Rec_Header
SET 
[2010BA_REF02_Subscriber_Identifier_SSN] = SSN,
[2010BA_N301_SubscriberAddressLine1] = COALESCE([MAIL_SRC_ADDR_LN_1],MEM.PHY_SRC_ADDR_LN_1),
[2010BA_N302_SubscriberAddressLine2] = COALESCE([MAIL_SRC_ADDR_LN_2],MEM.PHY_SRC_ADDR_LN_2),
[2010BA_N401_SubscriberCity] = COALESCE([MAIL_SRC_CITY],MEM.PHY_SRC_CITY),
[2010BA_N402_SubscriberState] = COALESCE([MAIL_SRC_STE],MEM.PHY_SRC_STE),
[2010BA_N403_SubscriberPostalCode] = COALESCE([MAIL_SRC_ZIP_CD],MEM.PHY_SRC_ZIP_CD),
[2010BA_DMG02_DateOfBirth] = CONVERT(CHAR(8),MEM.DT_OF_BRTH,112),
[2010BA_DMG03_Gender] = GENDR,
[2010BA_REF02_SubscriberIdentifier_1] = MEDCR_ID
FROM EDIFECS.staging.EE_CSV_150I_Rec_Header CSVP
left join OSS.staging.[CDO_MBR_DEMG] MEM ON CSVP.[2010BA_NM109_SubscriberIdentifier] = MEM.MBR_ID  
WHERE [2010BA_DMG03_Gender] IS NULL OR [2010BA_DMG03_Gender] =''


/********************************************************************************************************************************************************************
  20 RECORD INSERT 
*********************************************************************************************************************************************************************/

TRUNCATE TABLE EDIFECS.staging.EE_CSV_20I_Rec_Header;

INSERT INTO EDIFECS.staging.EE_CSV_20I_Rec_Header
SELECT	DISTINCT  
		 CLMHDR.CLM_ID,				--[ClaimID]
		 CLMHDR.src_data_key,		 --[SourceDataKey]
		 CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END,      --[SourceDesc]
		 GETDATE(),      --[CreateDate]
		 CASE	WHEN CLMHDR.src_data_key IN ('50','30','210','40')  THEN CAST(CLMHDR.src_data_key AS VARCHAR) + CLMHDR.CLM_ID
      			WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLMHDR.CLM_ID
				WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLMHDR.CLM_ID	
				WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLMHDR.CLM_ID	
				WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLMHDR.CLM_ID -- 2300P_CLM01_ClaimNumber
				WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLMHDR.CLM_ID
				WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLMHDR.CLM_ID
				WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLMHDR.CLM_ID
				WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLMHDR.CLM_ID
				WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '45' + CLMHDR.CLM_ID -- RETM-11
				WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '451' + CLMHDR.CLM_ID -- RETM-11
				WHEN CLMHDR.src_data_key in ('140','142','144')   AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '452' + CLMHDR.CLM_ID -- RETM-11
	    		 --WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN '51' + CLAIM_ID
			  --   WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN '52' + CLAIM_ID
		 END, -- 2300P_CLM01_ClaimNumber
		 CLMHDR.TOTL_BILLD_AMT,      --[2300I_CLM02_TotalClaimCharge]
		 ISNULL(CLMHDR.BILL_TY_CD,''),      --[2300I_CLM05-01_FacilityTypeCode]
		 '',      --[2300I_CLM05-02_BillTypeQualifier]
		 ISNULL(CLMHDR.FREQ_CD,''),      --[2300I_CLM05-03_ClaimFrequencyCode]
		 'A',--ISNULL(CLMHDR.[PROV_ASGNMT_STAT_CD],'A'),      --[2300I_CLM07_MedicareAssignment]
		 'Y',--ISNULL(CLMHDR.[BEN_ASGNMT_CERT_CD],'Y'),      --[2300I_CLM08_BenefitAssignmentIndicator]
		 'Y',--ISNULL(CLMHDR.[RELS_OF_INFO_CD],'Y'),      --[2300I_CLM09_ReleaseOfInformation]
		 '',      --[2300I_CLM20_DelayReason]
		 '',      --[2300I_DTP01_DateTimeQualifier_1]
		 '',      --[2300I_DTP02_FormatQualifier_1]
		 CASE WHEN [DISCHRG_TM] IS NULL THEN '' ELSE LEFT(REPLACE([DISCHRG_TM],':',''),4) END, --[2300I_DTP03_DateTime_1] 
		 '',      --[2300I_DTP01_DateTimeQualifier_2]
		 '',      --[2300I_DTP02_FormatQualifier_2]
		 CASE WHEN CLMHDR.SVC_START_DT = CLMHDR.SVC_END_DT THEN REPLACE(CLMHDR.SVC_END_DT,'-','')
			  WHEN ISNULL(CLMHDR.SVC_END_DT,'') = '' THEN REPLACE(CLMHDR.SVC_START_DT,'-','')
		      ELSE CONCAT(REPLACE(CLMHDR.SVC_START_DT,'-',''),'-',REPLACE(CLMHDR.SVC_END_DT,'-','')) 
		 END, 
		 '',      --[2300I_DTP01_DateTimeQualifier_3]
		 '',      --[2300I_DTP02_FormatQualifier_3]
		 REPLACE(REPLACE(ISNULL(CLMHDR.[ADMSN_DT],''),'-',''),'19000101',''),      --[2300I_DTP03_DateTime_3]
		 '',      --[2300I_DTP01_DateTimeQualifier_4]
		 '',      --[2300I_DTP02_FormatQualifier_4]
		 '', --DATERECEIVEDKEY,      --[2300I_DTP03_DateTime_4]
		 ISNULL(CLMHDR.ADMSN_TY_CD,''),      --[2300I_CL101_AdmissionType] *******
		 ISNULL(CLMHDR.[ADMSN_SRC_CD],''),      --[2300I_CL102_AdmissionSource]  
		 ISNULL(CLMHDR.[DISCHRG_STAT_CD],''),      --[2300I_CL103_PatientStatus]  
		 CASE WHEN [CAPITATED_LN_FLG] = 'Y' THEN '05' ELSE '' END, --[2300I_CN101_ContractTypeCode] 
		 '',      --[2300I_CN102_MonetaryAmount]
		 '',      --[2300I_CN103_ContractPercentage]
		 '',      --[2300I_CN104_ContractCode]
		 '',      --[2300I_CN105_TermsDiscountPercent]
		 '',      --[2300I_CN106_ContractVersionIdentifier]
		 '',      --[2300I_AMT01_AmountQualifier]
		 CLMHDR.[TOTL_DEDUCT_AMT] + CLMHDR.[TOTL_COPAY_AMT] + CLMHDR.[TOTL_COINS_AMT],      --[2300I_AMT02_PatientAmountDue]
		 '',      --[2300I_REF01_ClaimReferenceNumberQualifier_1]
		 '',      --[2300I_REF02_ClaimReferenceNumber_1]
		 '',      --[2300I_REF01_ClaimReferenceNumberQualifier_2]
		 CLMHDR.[AUTHZN_ID],      --[2300I_REF02_ClaimReferenceNumber_2]
		 '',      --[2300I_REF01_ClaimReferenceNumberQualifier_3]
		 CASE WHEN CLMHDR.src_data_key IN ('50','30','210','40')  THEN CAST(CLMHDR.src_data_key AS VARCHAR) + CLMHDR.CLM_ID
      		  WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLMHDR.CLM_ID
			  WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLMHDR.CLM_ID	
			  WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLMHDR.CLM_ID	
			  WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLMHDR.CLM_ID -- 2300P_CLM01_ClaimNumber
			  WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLMHDR.CLM_ID
			  WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLMHDR.CLM_ID
			  WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLMHDR.CLM_ID
			  WHEN CLMHDR.src_data_key in ('140','142','144') AND ENCNTR_SRC_VENDR_NM in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLMHDR.CLM_ID
			  WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '45' + CLMHDR.CLM_ID -- RETM-11
			  WHEN CLMHDR.src_data_key in ('140','142','144')  AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '451' + CLMHDR.CLM_ID -- RETM-11
			  WHEN CLMHDR.src_data_key in ('140','142','144')   AND ENCNTR_SRC_VENDR_NM in  ('EDPS-EyeMed') THEN '452' + CLMHDR.CLM_ID -- RETM-11
	     END,  --[2300I_REF02_ClaimReferenceNumber_3]
		 '',      --[2300I_REF01_ClaimReferenceNumberQualifier_4]
		 CLMHDR.[PATNT_CTL_NUM],      --[2300I_REF02_ClaimReferenceNumber_4]
		 '',      --[2300I_REF01_ClaimReferenceNumberQualifier_5]
		 '',      --[2300I_REF02_ClaimReferenceNumber_5]
		 '',      --[2300I_REF01_ClaimReferenceNumberQualifier_6]
		 '',      --[2300I_REF02_ClaimReferenceNumber_6]
		 '',      --[2300I_REF01_ClaimReferenceNumberQualifier_7]
		 '',      --[2300I_REF02_ClaimReferenceNumber_7]
		 '',      --[2300I_REF01_ClaimReferenceNumberQualifier_8]
		 '',      --[2300I_REF02_ClaimReferenceNumber_8]
		 '',      --[2300I_NTE01_ClaimNoteType]
		 '',      --[2300I_NTE02_ClaimNote]
		 '',      --[2300I_NTE01_BillNoteType]
		 '',      --[2300I_NTE01_BillNote]
		 '',      --[2300I_CRC01_ServiceCertificationCategory]
		 '',      --[2300I_CRC02_ServiceCertificationIndicator]
		 '',      --[2300I_CRC03_ConditionIndicatorCode]
		 '',      --[2300I_CRC04_ConditionIndicatorCode]
		 '',      --[2300I_CRC05_ConditionIndicatorCode]
		 '',      --[2300I_HI01-01_PrinDXType]  
		 '',      --[2300I_HI01-02_PrincipalDXCode]  
		 '',      --[2300I_HI01-09_PrincipalDXPOA]  
		 '',      --[2300I_HI01-01_AdmittingDXType]  
		 '',      --[2300I_HI01-02_AdmittingDXCode]  
		 '',      --[2300I_HI01-01_PatientDXType]   
		 '',      --[2300I_HI01-02_PatientDXCode]
		 '',      --[2300I_HI02-01_PatientDXType]
		 '',      --[2300I_HI02-02_PatientDXCode]
		 '',      --[2300I_HI03-01_PatientDXType]
		 '',      --[2300I_HI03-02_PatientDXCode]
		 '',      --[2300I_HI01-01_ECIDXType]  
		 '',      --[2300I_HI01-02_ECIDXCode]
		 '',      --[2300I_HI01-09_ECIDXPOA]
		 '',      --[2300I_HI02-01_ECIDXType]
		 '',      --[2300I_HI02-02_ECIDXCode]
		 '',      --[2300I_HI02-09_ECIDXPOA]
		 '',      --[2300I_HI03-01_ECIDXType]
		 '',      --[2300I_HI03-02_ECIDXCode]
		 '',      --[2300I_HI03-09_ECIDXPOA]
		 '',      --[2300I_HI04-01_ECIDXType]
		 '',      --[2300I_HI04-02_ECIDXCode]
		 '',      --[2300I_HI04-09_ECIDXPOA]
		 '',      --[2300I_HI05-01_ECIDXType]
		 '',      --[2300I_HI05-02_ECIDXCode]
		 '',      --[2300I_HI05-09_ECIDXPOA]
		 '',      --[2300I_HI06-01_ECIDXType]
		 '',      --[2300I_HI06-02_ECIDXCode]
		 '',      --[2300I_HI06-09_ECIDXPOA]
		 '',      --[2300I_HI07-01_ECIDXType]
		 '',      --[2300I_HI07-02_ECIDXCode]
		 '',      --[2300I_HI07-09_ECIDXPOA]
		 '',      --[2300I_HI08-01_ECIDXType]
		 '',      --[2300I_HI08-02_ECIDXCode]
		 '',      --[2300I_HI08-09_ECIDXPOA]
		 '',      --[2300I_HI09-01_ECIDXType]
		 '',      --[2300I_HI09-02_ECIDXCode]
		 '',      --[2300I_HI09-09_ECIDXPOA]
		 '',      --[2300I_HI10-01_ECIDXType]
		 '',      --[2300I_HI10-02_ECIDXCode]
		 '',      --[2300I_HI10-09_ECIDXPOA]
		 '',      --[2300I_HI11-01_ECIDXType]
		 '',      --[2300I_HI11-02_ECIDXCode]
		 '',      --[2300I_HI11-09_ECIDXPOA]
		 '',      --[2300I_HI12-01_ECIDXType]
		 '',      --[2300I_HI12-02_ECIDXCode]
		 '',      --[2300I_HI12-09_ECIDXPOA]
		 '',      --[2300I_HI01-01_DRGType]
		 '',      --[2300I_HI01-02_DRGCode]
		 '',      --[20I_DRG_Version]
		 '',      --[20I_DRG_Severity]
		 '',      --[20I_DRG_Risk]
		 '',      --[2300I_HI01-01_DXType_1]  
		 '',      --[2300I_HI01-02_DXCode_1]
		 '',      --[2300I_HI01-09_DXPOA_1]
		 '',      --[2300I_HI02-01_DXType_1]
		 '',      --[2300I_HI02-02_DXCode_1]
		 '',      --[2300I_HI02-09_DXPOA_1]
		 '',      --[2300I_HI03-01_DXType_1]
		 '',      --[2300I_HI03-02_DXCode_1]
		 '',      --[2300I_HI03-09_DXPOA_1]
		 '',      --[2300I_HI04-01_DXType_1]
		 '',      --[2300I_HI04-02_DXCode_1]
		 '',      --[2300I_HI04-09_DXPOA_1]
		 '',      --[2300I_HI05-01_DXType_1]
		 '',      --[2300I_HI05-02_DXCode_1]
		 '',      --[2300I_HI05-09_DXPOA_1]
		 '',      --[2300I_HI06-01_DXType_1]
		 '',      --[2300I_HI06-02_DXCode_1]
		 '',      --[2300I_HI06-09_DXPOA_1]
		 '',      --[2300I_HI07-01_DXType_1]
		 '',      --[2300I_HI07-02_DXCode_1]
		 '',      --[2300I_HI07-09_DXPOA_1]
		 '',      --[2300I_HI08-01_DXType_1]
		 '',      --[2300I_HI08-02_DXCode_1]
		 '',      --[2300I_HI08-09_DXPOA_1]
		 '',      --[2300I_HI09-01_DXType_1]
		 '',      --[2300I_HI09-02_DXCode_1]
		 '',      --[2300I_HI09-09_DXPOA_1]
		 '',      --[2300I_HI10-01_DXType_1]
		 '',      --[2300I_HI10-02_DXCode_1]
		 '',      --[2300I_HI10-09_DXPOA_1]
		 '',      --[2300I_HI11-01_DXType_1]
		 '',      --[2300I_HI11-02_DXCode_1]
		 '',      --[2300I_HI11-09_DXPOA_1]
		 '',      --[2300I_HI12-01_DXType_1]
		 '',      --[2300I_HI12-02_DXCode_1]
		 '',      --[2300I_HI12-09_DXPOA_1]
		 '',      --[2300I_HI01-01_DXType_2]
		 '',      --[2300I_HI01-02_DXCode_2]
		 '',      --[2300I_HI01-09_DXPOA_2]
		 '',      --[2300I_HI02-01_DXType_2]
		 '',      --[2300I_HI02-02_DXCode_2]
		 '',      --[2300I_HI02-09_DXPOA_2]
		 '',      --[2300I_HI03-01_DXType_2]
		 '',      --[2300I_HI03-02_DXCode_2]
		 '',      --[2300I_HI03-09_DXPOA_2]
		 '',      --[2300I_HI04-01_DXType_2]
		 '',      --[2300I_HI04-02_DXCode_2]
		 '',      --[2300I_HI04-09_DXPOA_2]
		 '',      --[2300I_HI05-01_DXType_2]
		 '',      --[2300I_HI05-02_DXCode_2]
		 '',      --[2300I_HI05-09_DXPOA_2]
		 '',      --[2300I_HI06-01_DXType_2]
		 '',      --[2300I_HI06-02_DXCode_2]
		 '',      --[2300I_HI06-09_DXPOA_2]
		 '',      --[2300I_HI07-01_DXType_2]
		 '',      --[2300I_HI07-02_DXCode_2]
		 '',      --[2300I_HI07-09_DXPOA_2]
		 '',      --[2300I_HI08-01_DXType_2]
		 '',      --[2300I_HI08-02_DXCode_2]
		 '',      --[2300I_HI08-09_DXPOA_2]
		 '',      --[2300I_HI09-01_DXType_2]
		 '',      --[2300I_HI09-02_DXCode_2]
		 '',      --[2300I_HI09-09_DXPOA_2]
		 '',      --[2300I_HI10-01_DXType_2]
		 '',      --[2300I_HI10-02_DXCode_2]
		 '',      --[2300I_HI10-09_DXPOA_2]
		 '',      --[2300I_HI11-01_DXType_2]
		 '',      --[2300I_HI11-02_DXCode_2]
		 '',      --[2300I_HI11-09_DXPOA_2]
		 '',      --[2300I_HI12-01_DXType_2]
		 '',      --[2300I_HI12-02_DXCode_2]
		 '',      --[2300I_HI12-09_DXPOA_2]
		 '',      --[2300I_HI13-01_DXType_2]
		 '',      --[2300I_HI13-02_DXCode_2]
		 '',      --[2300I_HI13-09_DXPOA_2]
		 '',      --[2300I_HI14-01_DXType_2]
		 '',      --[2300I_HI14-02_DXCode_2]
		 '',      --[2300I_HI14-09_DXPOA_2]
		 '',      --[2300I_HI01-01_PrincipalPXType]  
		 '',      --[2300I_HI01-02_PrincipalPXCode]
		 '',      --[2300I_HI01-03_PrincipalPXDateQualifier]  
		 '',      --[2300I_HI01-04_PrincipalPXDate] 
		 '',      --[2300I_HI01-01_PXType_1] 
		 '',      --[2300I_HI01-02_PXCode_1]  
		 '',      --[2300I_HI01-03_PXDateQualifier_1] 
		 '',      --[2300I_HI01-04_PXDate_1]
		 '',      --[2300I_HI02-01_PXType_1]
		 '',      --[2300I_HI02-02_PXCode_1]
		 '',      --[2300I_HI02-03_PXDateQualifier_1]
		 '',      --[2300I_HI02-04_PXDate_1]
		 '',      --[2300I_HI03-01_PXType_1]
		 '',      --[2300I_HI03-02_PXCode_1]
		 '',      --[2300I_HI03-03_PXDateQualifier_1]
		 '',      --[2300I_HI03-04_PXDate_1]
		 '',      --[2300I_HI04-01_PXType_1]
		 '',      --[2300I_HI04-02_PXCode_1]
		 '',      --[2300I_HI04-03_PXDateQualifier_1]
		 '',      --[2300I_HI04-04_PXDate_1]
		 '',      --[2300I_HI05-01_PXType_1]
		 '',      --[2300I_HI05-02_PXCode_1]
		 '',      --[2300I_HI05-03_PXDateQualifier_1]
		 '',      --[2300I_HI05-04_PXDate_1]
		 '',      --[2300I_HI06-01_PXType_1]
		 '',      --[2300I_HI06-02_PXCode_1]
		 '',      --[2300I_HI06-03_PXDateQualifier_1]
		 '',      --[2300I_HI06-04_PXDate_1]
		 '',      --[2300I_HI07-01_PXType_1]
		 '',      --[2300I_HI07-02_PXCode_1]
		 '',      --[2300I_HI07-03_PXDateQualifier_1]
		 '',      --[2300I_HI07-04_PXDate_1]
		 '',      --[2300I_HI08-01_PXType_1]
		 '',      --[2300I_HI08-02_PXCode_1]
		 '',      --[2300I_HI08-03_PXDateQualifier_1]
		 '',      --[2300I_HI08-04_PXDate_1]
		 '',      --[2300I_HI09-01_PXType_1]
		 '',      --[2300I_HI09-02_PXCode_1]
		 '',      --[2300I_HI09-03_PXDateQualifier_1]
		 '',      --[2300I_HI09-04_PXDate_1]
		 '',      --[2300I_HI10-01_PXType_1]
		 '',      --[2300I_HI10-02_PXCode_1]
		 '',      --[2300I_HI10-03_PXDateQualifier_1]
		 '',      --[2300I_HI10-04_PXDate_1]
		 '',      --[2300I_HI11-01_PXType_1]
		 '',      --[2300I_HI11-02_PXCode_1]
		 '',      --[2300I_HI11-03_PXDateQualifier_1]
		 '',      --[2300I_HI11-04_PXDate_1]
		 '',      --[2300I_HI12-01_PXType_1]
		 '',      --[2300I_HI12-02_PXCode_1]
		 '',      --[2300I_HI12-03_PXDateQualifier_1]
		 '',      --[2300I_HI12-04_PXDate_1]
		 '',      --[2300I_HI01-01_PXType_2]
		 '',      --[2300I_HI01-02_PXCode_2]
		 '',      --[2300I_HI01-03_PXDateQualifier_2]
		 '',      --[2300I_HI01-04_PXDate_2]
		 '',      --[2300I_HI02-01_PXType_2]
		 '',      --[2300I_HI02-02_PXCode_2]
		 '',      --[2300I_HI02-03_PXDateQualifier_2]
		 '',      --[2300I_HI02-04_PXDate_2]
		 '',      --[2300I_HI03-01_PXType_2]
		 '',      --[2300I_HI03-02_PXCode_2]
		 '',      --[2300I_HI03-03_PXDateQualifier_2]
		 '',      --[2300I_HI03-04_PXDate_2]
		 '',      --[2300I_HI04-01_PXType_2]
		 '',      --[2300I_HI04-02_PXCode_2]
		 '',      --[2300I_HI04-03_PXDateQualifier_2]
		 '',      --[2300I_HI04-04_PXDate_2]
		 '',      --[2300I_HI05-01_PXType_2]
		 '',      --[2300I_HI05-02_PXCode_2]
		 '',      --[2300I_HI05-03_PXDateQualifier_2]
		 '',      --[2300I_HI05-04_PXDate_2]
		 '',      --[2300I_HI06-01_PXType_2]
		 '',      --[2300I_HI06-02_PXCode_2]
		 '',      --[2300I_HI06-03_PXDateQualifier_2]
		 '',      --[2300I_HI06-04_PXDate_2]
		 '',      --[2300I_HI07-01_PXType_2]
		 '',      --[2300I_HI07-02_PXCode_2]
		 '',      --[2300I_HI07-03_PXDateQualifier_2]
		 '',      --[2300I_HI07-04_PXDate_2]
		 '',      --[2300I_HI08-01_PXType_2]
		 '',      --[2300I_HI08-02_PXCode_2]
		 '',      --[2300I_HI08-03_PXDateQualifier_2]
		 '',      --[2300I_HI08-04_PXDate_2]
		 '',      --[2300I_HI09-01_PXType_2]
		 '',      --[2300I_HI09-02_PXCode_2]
		 '',      --[2300I_HI09-03_PXDateQualifier_2]
		 '',      --[2300I_HI09-04_PXDate_2]
		 '',      --[2300I_HI10-01_PXType_2]
		 '',      --[2300I_HI10-02_PXCode_2]
		 '',      --[2300I_HI10-03_PXDateQualifier_2]
		 '',      --[2300I_HI10-04_PXDate_2]
		 '',      --[2300I_HI11-01_PXType_2]
		 '',      --[2300I_HI11-02_PXCode_2]
		 '',      --[2300I_HI11-03_PXDateQualifier_2]
		 '',      --[2300I_HI11-04_PXDate_2]
		 '',      --[2300I_HI12-01_PXType_2]
		 '',      --[2300I_HI12-02_PXCode_2]
		 '',      --[2300I_HI12-03_PXDateQualifier_2]
		 '',      --[2300I_HI12-04_PXDate_2]
		 '',      --[2300I_HI01-01_OccurSpanType]
		 '',      --[2300I_HI01-02_OccurSpanCode]
		 '',      --[2300I_HI01-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI01-04_OccurSpanDate]
		 '',      --[2300I_HI02-01_OccurSpanType]
		 '',      --[2300I_HI02-02_OccurSpanCode]
		 '',      --[2300I_HI02-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI02-04_OccurSpanDate]
		 '',      --[2300I_HI03-01_OccurSpanType]
		 '',      --[2300I_HI03-02_OccurSpanCode]
		 '',      --[2300I_HI03-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI03-04_OccurSpanDate]
		 '',      --[2300I_HI04-01_OccurSpanType]
		 '',      --[2300I_HI04-02_OccurSpanCode]
		 '',      --[2300I_HI04-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI04-04_OccurSpanDate]
		 '',      --[2300I_HI05-01_OccurSpanType]
		 '',      --[2300I_HI05-02_OccurSpanCode]
		 '',      --[2300I_HI05-03_OccurSpanDateQualifier]
		 '',       --[2300I_HI05-04_OccurSpanDate]
		 '',      --[2300I_HI06-01_OccurSpanType]
		 '',      --[2300I_HI06-02_OccurSpanCode]
		 '',      --[2300I_HI06-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI06-04_OccurSpanDate]
		 '',      --[2300I_HI07-01_OccurSpanType]
		 '',      --[2300I_HI07-02_OccurSpanCode]
		 '',      --[2300I_HI07-03_OccurSpanDateQualifier]
		 '',       --[2300I_HI07-04_OccurSpanDate]
		 '',      --[2300I_HI08-01_OccurSpanType]
		 '',      --[2300I_HI08-02_OccurSpanCode]
		 '',      --[2300I_HI08-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI08-04_OccurSpanDate]
		 '',      --[2300I_HI09-01_OccurSpanType]
		 '',      --[2300I_HI09-02_OccurSpanCode]
		 '',      --[2300I_HI09-03_OccurSpanDateQualifier]
		 '',       --[2300I_HI09-04_OccurSpanDate]
		 '',      --[2300I_HI10-01_OccurSpanType]
		 '',      --[2300I_HI10-02_OccurSpanCode]
		 '',      --[2300I_HI10-03_OccurSpanDateQualifier]
		 '',       --[2300I_HI10-04_OccurSpanDate]
		 '',      --[2300I_HI11-01_OccurSpanType]
		 '',      --[2300I_HI11-02_OccurSpanCode]
		 '',      --[2300I_HI11-03_OccurSpanDateQualifier]
		 '',       --[2300I_HI11-04_OccurSpanDate]
		 '',      --[2300I_HI12-01_OccurSpanType]
		 '',      --[2300I_HI12-02_OccurSpanCode]
		 '',      --[2300I_HI12-03_OccurSpanDateQualifier]
		 '',       --[2300I_HI12-04_OccurSpanDate]
		 '',      --[2300I_HI01-01_OccurType]
		 '',      --[2300I_HI01-02_OccurCode]
		 '',      --[2300I_HI01-03_OccurDateQualifier]
		 '',      --[2300I_HI01-04_OccurDate]
		 '',      --[2300I_HI02-01_OccurType]
		 '',      --[2300I_HI02-02_OccurCode]
		 '',      --[2300I_HI02-03_OccurDateQualifier]
		 '',      --[2300I_HI02-04_OccurDate]
		 '',      --[2300I_HI03-01_OccurType]
		 '',      --[2300I_HI03-02_OccurCode]
		 '',      --[2300I_HI03-03_OccurDateQualifier]
		 '',      --[2300I_HI03-04_OccurDate]
		 '',      --[2300I_HI04-01_OccurType]
		 '',      --[2300I_HI04-02_OccurCode]
		 '',      --[2300I_HI04-03_OccurDateQualifier]
		 '',      --[2300I_HI04-04_OccurDate]
		 '',      --[2300I_HI05-01_OccurType]
		 '',      --[2300I_HI05-02_OccurCode]
		 '',      --[2300I_HI05-03_OccurDateQualifier]
		 '',      --[2300I_HI05-04_OccurDate]
		 '',      --[2300I_HI06-01_OccurType]
		 '',      --[2300I_HI06-02_OccurCode]
		 '',      --[2300I_HI06-03_OccurDateQualifier]
		 '',      --[2300I_HI06-04_OccurDate]
		 '',      --[2300I_HI07-01_OccurType]
		 '',      --[2300I_HI07-02_OccurCode]
		 '',      --[2300I_HI07-03_OccurDateQualifier]
		 '',      --[2300I_HI07-04_OccurDate]
		 '',      --[2300I_HI08-01_OccurType]
		 '',      --[2300I_HI08-02_OccurCode]
		 '',      --[2300I_HI08-03_OccurDateQualifier]
		 '',      --[2300I_HI08-04_OccurDate]
		 '',      --[2300I_HI09-01_OccurType]
		 '',      --[2300I_HI09-02_OccurCode]
		 '',      --[2300I_HI09-03_OccurDateQualifier]
		 '',      --[2300I_HI09-04_OccurDate]
		 '',      --[2300I_HI10-01_OccurType]
		 '',      --[2300I_HI10-02_OccurCode]
		 '',      --[2300I_HI10-03_OccurDateQualifier]
		 '',      --[2300I_HI10-04_OccurDate]
		 '',      --[2300I_HI11-01_OccurType]
		 '',      --[2300I_HI11-02_OccurCode]
		 '',      --[2300I_HI11-03_OccurDateQualifier]
		 '',      --[2300I_HI11-04_OccurDate]
		 '',      --[2300I_HI12-01_OccurType]
		 '',      --[2300I_HI12-02_OccurCode]
		 '',      --[2300I_HI12-03_OccurDateQualifier]
		 '',      --[2300I_HI12-04_OccurDate]
		 '',      --[2300I_HI01-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI01-02_ValueCode_1 ]
		 '',      --[2300I_HI01-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI02-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI02-02_ValueCode_1 ]
		 '',      --[2300I_HI02-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI03-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI03-02_ValueCode_1 ]
		 '',      --[2300I_HI03-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI04-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI04-02_ValueCode_1 ]
		 '',      --[2300I_HI04-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI05-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI05-05_ValueCode_1 ]
		 '',      --[2300I_HI05-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI06-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI06-02_ValueCode_1 ]
		 '',      --[2300I_HI06-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI07-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI07-02_ValueCode_1 ]
		 '',      --[2300I_HI07-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI08-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI08-02_ValueCode_1 ]
		 '',      --[2300I_HI08-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI09-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI09-02_ValueCode_1 ]
		 '',      --[2300I_HI09-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI10-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI10-02_ValueCode_1 ]
		 '',      --[2300I_HI10-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI11-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI11-02_ValueCode_1 ]
		 '',      --[2300I_HI11-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI12-01_ValueCodeQualifer_1 ]
		 '',      --[2300I_HI12-02_ValueCode_1 ]
		 '',      --[2300I_HI12-05_ValueCodeAmount_1 ]
		 '',      --[2300I_HI01-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI01-02_ValueCode_2 ]
		 '',      --[2300I_HI01-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI02-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI02-02_ValueCode_2 ]
		 '',      --[2300I_HI02-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI03-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI03-02_ValueCode_2 ]
		 '',      --[2300I_HI03-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI04-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI04-02_ValueCode_2 ]
		 '',      --[2300I_HI04-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI05-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI05-02_ValueCode_2 ]
		 '',      --[2300I_HI05-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI06-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI06-02_ValueCode_2 ]
		 '',      --[2300I_HI06-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI07-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI07-02_ValueCode_2 ]
		 '',      --[2300I_HI07-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI08-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI08-02_ValueCode_2 ]
		 '',      --[2300I_HI08-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI09-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI09-02_ValueCode_2 ]
		 '',      --[2300I_HI09-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI10-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI10-02_ValueCode_2 ]
		 '',      --[2300I_HI10-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI11-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI11-02_ValueCode_2 ]
		 '',      --[2300I_HI11-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI12-01_ValueCodeQualifer_2 ]
		 '',      --[2300I_HI12-02_ValueCode_2 ]
		 '',      --[2300I_HI12-05_ValueCodeAmount_2 ]
		 '',      --[2300I_HI01-01_ConditionCodeQualifier]
		 '',      --[2300I_HI01-02_ConditionCode ]
		 '',      --[2300I_HI02-01_ConditionCodeQualifier]
		 '',      --[2300I_HI02-02_ConditionCode ]
		 '',      --[2300I_HI03-01_ConditionCodeQualifier]
		 '',      --[2300I_HI03-02_ConditionCode ]
		 '',      --[2300I_HI04-01_ConditionCodeQualifier]
		 '',      --[2300I_HI04-02_ConditionCode ]
		 '',      --[2300I_HI05-01_ConditionCodeQualifier]
		 '',      --[2300I_HI05-02_ConditionCode ]
		 '',      --[2300I_HI06-01_ConditionCodeQualifier]
		 '',      --[2300I_HI06-02_ConditionCode ]
		 '',      --[2300I_HI07-01_ConditionCodeQualifier]
		 '',      --[2300I_HI07-02_ConditionCode ]
		 '',      --[2300I_HI08-01_ConditionCodeQualifier]
		 '',      --[2300I_HI08-02_ConditionCode ]
		 '',      --[2300I_HI09-01_ConditionCodeQualifier]
		 '',      --[2300I_HI09-02_ConditionCode ]
		 '',      --[2300I_HI10-01_ConditionCodeQualifier]
		 '',      --[2300I_HI10-02_ConditionCode ]
		 '',      --[2300I_HI11-01_ConditionCodeQualifier]
		 '',      --[2300I_HI11-02_ConditionCode ]
		 '',      --[2300I_HI12-01_ConditionCodeQualifier]
		 '',      --[2300I_HI12-02_ConditionCode ]
		 '',      --[2300I_HI01-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI01-02_TreatmentCode ]
		 '',      --[2300I_HI02-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI02-02_TreatmentCode ]
		 '',      --[2300I_HI03-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI03-02_TreatmentCode ]
		 '',      --[2300I_HI04-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI04-02_TreatmentCode ]
		 '',      --[2300I_HI05-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI05-02_TreatmentCode ]
		 '',      --[2300I_HI06-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI06-02_TreatmentCode ]
		 '',      --[2300I_HI07-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI07-02_TreatmentCode ]
		 '',      --[2300I_HI08-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI08-02_TreatmentCode ]
		 '',      --[2300I_HI09-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI09-02_TreatmentCode ]
		 '',      --[2300I_HI10-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI10-02_TreatmentCode ]
		 '',      --[2300I_HI11-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI11-02_TreatmentCode ]
		 '',      --[2300I_HI12-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI12-02_TreatmentCode ]
		 '',      --[2300I_HCP01_PricingMethod ]
		 '',      --[2300I_HCP02_AllowedAmount]
		 '',      --[2300I_HCP03_SavingAmount]
		 '',      --[2300I_HCP04_OrgID]
		 '',      --[2300I_HCP05_PricingRate]
		 '',      --[2300I_HCP06_ApprovedDRGCode]
		 '',      --[2300I_HCP07_ApprovedDRGAmount]
		 '',      --[2300I_HCP08_ApprovedRevenueCode]
		 '',      --[2300I_HCP11_Units]
		 '',      --[2300I_HCP12_Quatity]
		 '',      --[2300I_HCP13_RejectReason]
		 '',      --[2300I_HCP14_PolicyCompliance]
		 '',      --[2300I_HCP15_ExceptionCode]
		 '',      --[2310AI_NM101_ProviderRole]
		 '',      --[2310AI_NM102_PersonIndicator]
		 '',      --[2310AI_NM103_LastName] 
		 '',	  --[2310AI_NM104_FirstName]
		 '',	  --[2310AI_NM105_MiddleName]
		 '',	  --[2310AI_NM107_Suffix]
		 '',      --[2310AI_NM108_ProviderIdentifierQualifer]
		 CLMHDR.ATTND_PROV_NPI,      --[2310AI_NM109_ProviderIdentifier]
		 '',      --[2310AI_PRV01_ProviderCode]
		 '',      --[2310AI_PRV02_ProviderCodeQualifer]
		 '',	  --[2310AI_PRV03_ProviderTaxonomy]
		 '',      --[2310AI_REF01_ProviderIdentifierQualifer]
		 '',      --[2310AI_REF02_ProviderIdentifier]
		 '',      --[2310AI_REF01_ProviderIdentifierQualifer_02]
		 '',      --[2310AI_REF02_ProviderIdentifier_02]
		 '',      --[2310BI_NM101_ProviderRole]
		 '',      --[2310BI_NM102_PersonIndicator]
		 '',      --[2310BI_NM103_LastName] OPERATING PROVIDER DATA WILL BE UPDATED WHEN AVAILABLE 
		 '',      --[2310BI_NM104_FirstName]
		 '',      --[2310BI_NM105_MiddleName]
		 '',      --[2310BI_NM107_Suffix]
		 '',      --[2310BI_NM108_ProviderIdentifierQualifer]
		 '',      --[2310BI_NM109_ProviderIdentifier]
		 '',      --[2310BI_REF01_ProviderIdentifierQualifer]
		 '',      --[2310BI_REF02_ProviderIdentifier]
		 '',      --[2310BI_REF01_ProviderIdentifierQualifer_02]
		 '',      --[2310BI_REF02_ProviderIdentifier_02]
		 '',      --[2310CI_NM101_ProviderRole]
		 '',      --[2310CI_NM102_PersonIndicator]
		 '',      --[2310CI_NM103_LastName]
		 '',      --[2310CI_NM104_FirstName]
		 '',      --[2310CI_NM105_MiddleName]
		 '',      --[2310CI_NM107_Suffix]
		 '',      --[2310CI_NM108_ProviderIdentifierQualifer]
		 '',      --[2310CI_NM109_ProviderIdentifier]
		 '',      --[2310CI_REF01_ProviderIdentifierQualifer]
		 '',      --[2310CI_REF02_ProviderIdentifier]
		 '',      --[2310CI_REF01_ProviderIdentifierQualifer_02]
		 '',      --[2310CI_REF02_ProviderIdentifier_02]
		 '',      --[2310DI_NM101_ProviderRole]
		 '',      --[2310DI_NM102_PersonIndicator]
		 '',	  --[2310DI_NM103_LastName] 
		 '',	  --[2310DI_NM104_FirstName]
		 '',	  --[2310DI_NM105_MiddleName]
		 '',	  --[2310DI_NM107_Suffix]
		 '',      --[2310DI_NM108_ProviderIdentifierQualifer]
		 '',	  --[2310DI_NM109_ProviderIdentifier]
		 '',      --[2310DI_REF01_ProviderIdentifierQualifer]
		 '',      --[2310DI_REF02_ProviderIdentifier]
		 '',      --[2310DI_REF01_ProviderIdentifierQualifer_02]
		 '',      --[2310DI_REF02_ProviderIdentifier_02]
		 '',      --[20I_RenderingProviderAddress1]
		 '',      --[20I_RenderingProviderAddress2]
		 '',      --[20I_RenderingProviderCity]
		 '',      --[20I_RenderingProviderState]
		 '',      --[20I_RenderingProviderZip]
		 '',      --[2310EI_NM101_ProviderRole]
		 '',      --[2310EI_NM102_PersonIndicator]
		 '',      --[2310EI_NM103_ORG_LastName]
		 '',      --[2310EI_NM108_ProviderIdentifierQualifer]
		 '',      --[2310EI_NM109_ProviderIdentifier]
		 '',      --[2310EI_N301_AddressLine1]
		 '',      --[2310EI_N302_AddressLine2]
		 '',      --[2310EI_N401_City]
		 '',      --[2310EI_N402_State]
		 '',      --[2310EI_N403_PostalCode]
		 '',      --[2310EI_N404_Country]
		 '',      --[2310EI_REF01_ProviderIdentifierQualifer1]
		 '',      --[2310EI_REF02_ProviderIdentifier1]
		 '',      --[2310EI_REF01_ProviderIdentifierQualifer2]
		 '',      --[2310EI_REF02_ProviderIdentifier2]
		 '',      --[2310FI_NM101_ProviderRole]
		 '',      --[2310FI_NM102_PersonIndicator]
		 '',	  --[2310FI_NM103_LastName] 
		 '',      --[2310FI_NM104_FirstName]
		 '',	  --[2310FI_NM105_MiddleName]
		 '',	  --[2310FI_NM107_Suffix]
		 '',      --[2310FI_NM108_ProviderIdentifierQualifer]
		 '',	  --[2310FI_NM109_ProviderIdentifier]
		 '',      --[2310FI_REF01_ProviderIdentifierQualifer]
		 '',      --[2310FI_REF02_ProviderIdentifier]
		 '',      --[2310FI_REF01_ProviderIdentifierQualifer_02]
		 '',      --[2310FI_REF02_ProviderIdentifier_02]
		 '',      --[2300I_PWK01_AttachmentReportType]
		 '',      --[2300I_PWK02_AttachmentTransmissionCode]
		 '',      --[2300I_PWK06_AttachmentControlNumber]
		 '',      --[2300I_REF01_ServiceAuthorizationExceptionCode_Qualifier]
		 '',      --[2300I_REF02_ServiceAuthorizationExceptionCode]
		 '',      --[2300I_REF01_InvestigationalDeviceExemptionNumber_Qualifier]
		 '',      --[2300I_REF02_InvestigationalDeviceExemptionNumber]
		 '',      --[2300I_REF01_DemonstrationProject_Qualifier]
		 '',      --[2300I_REF02_DemonstrationProjectIdentifier]
		 '',      --[2300I_REF01_PeerReviewOrganization_Qualifier]
		 '',      --[2300I_REF02_PeerReviewOrganizationNumber ]
		 '',      --[2300I_REF01_FileInformation_Qualifier]
		 '',      --[2300I_REF01_FileInformation]
		 '',      --[Claim Processor Receiver Date]
		 '',      --[InNetworkIndicator ]
		 '',      --[PatientControlNumber]
		 '',      --[20I-Filler 04]
		 '',      --[20I-Filler 05]
		 '',      --[20I-Filler 06]
		 '',      --[20I-Filler 07]
		 '',      --[20I-Filler 08]
		 '',      --[20I-IFiller 09]
		 '',      --[20I-IFiller 10]
		 '',      --[20I-IFiller 11]
		 '',      --[20I-IFiller 12]
		 '',      --[20I-IFiller 13]
		 '',      --[20I-IFiller 14]
		 '',      --[20I-IFiller 15]
		 '',      --[2300I_HI13-01_OccurSpanType]
		 '',      --[2300I_HI13-02_OccurSpanCode]
		 '',      --[2300I_HI13-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI13-04_OccurSpanDate]
		 '',      --[2300I_HI14-01_OccurSpanType]
		 '',      --[2300I_HI14-02_OccurSpanCode]
		 '',      --[2300I_HI14-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI14-04_OccurSpanDate]
		 '',      --[2300I_HI15-01_OccurSpanType]
		 '',      --[2300I_HI15-02_OccurSpanCode]
		 '',      --[2300I_HI15-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI15-04_OccurSpanDate]
		 '',      --[2300I_HI16-01_OccurSpanType]
		 '',      --[2300I_HI16-02_OccurSpanCode]
		 '',      --[2300I_HI16-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI16-04_OccurSpanDate]
		 '',      --[2300I_HI17-01_OccurSpanType]
		 '',      --[2300I_HI17-02_OccurSpanCode]
		 '',      --[2300I_HI17-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI17-04_OccurSpanDate]
		 '',      --[2300I_HI18-01_OccurSpanType]
		 '',      --[2300I_HI18-02_OccurSpanCode]
		 '',      --[2300I_HI18-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI18-04_OccurSpanDate]
		 '',      --[2300I_HI19-01_OccurSpanType]
		 '',      --[2300I_HI19-02_OccurSpanCode]
		 '',      --[2300I_HI19-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI19-04_OccurSpanDate]
		 '',      --[2300I_HI20-01_OccurSpanType]
		 '',      --[2300I_HI20-02_OccurSpanCode]
		 '',      --[2300I_HI20-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI20-04_OccurSpanDate]
		 '',      --[2300I_HI21-01_OccurSpanType]
		 '',      --[2300I_HI21-02_OccurSpanCode]
		 '',      --[2300I_HI21-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI21-04_OccurSpanDate]
		 '',      --[2300I_HI22-01_OccurSpanType]
		 '',      --[2300I_HI22-02_OccurSpanCode]
		 '',      --[2300I_HI22-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI22-04_OccurSpanDate]
		 '',      --[2300I_HI23-01_OccurSpanType]
		 '',      --[2300I_HI23-02_OccurSpanCode]
		 '',      --[2300I_HI23-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI23-04_OccurSpanDate]
		 '',      --[2300I_HI24-01_OccurSpanType]
		 '',      --[2300I_HI24-02_OccurSpanCode]
		 '',      --[2300I_HI24-03_OccurSpanDateQualifier]
		 '',      --[2300I_HI24-04_OccurSpanDate]
		 '',      --[2300I_HI13-01_OccurType]
		 '',      --[2300I_HI13-02_OccurCode]
		 '',      --[2300I_HI13-03_OccurDateQualifier]
		 '',      --[2300I_HI13-04_OccurDate]
		 '',      --[2300I_HI14-01_OccurType]
		 '',      --[2300I_HI14-02_OccurCode]
		 '',      --[2300I_HI14-03_OccurDateQualifier]
		 '',      --[2300I_HI14-04_OccurDate]
		 '',      --[2300I_HI15-01_OccurType]
		 '',      --[2300I_HI15-02_OccurCode]
		 '',      --[2300I_HI15-03_OccurDateQualifier]
		 '',      --[2300I_HI15-04_OccurDate]
		 '',      --[2300I_HI16-01_OccurType]
		 '',      --[2300I_HI16-02_OccurCode]
		 '',      --[2300I_HI16-03_OccurDateQualifier]
		 '',      --[2300I_HI16-04_OccurDate]
		 '',      --[2300I_HI17-01_OccurType]
		 '',      --[2300I_HI17-02_OccurCode]
		 '',      --[2300I_HI17-03_OccurDateQualifier]
		 '',      --[2300I_HI17-04_OccurDate]
		 '',      --[2300I_HI18-01_OccurType]
		 '',      --[2300I_HI18-02_OccurCode]
		 '',      --[2300I_HI18-03_OccurDateQualifier]
		 '',      --[2300I_HI18-04_OccurDate]
		 '',      --[2300I_HI19-01_OccurType]
		 '',      --[2300I_HI19-02_OccurCode]
		 '',      --[2300I_HI19-03_OccurDateQualifier]
		 '',      --[2300I_HI19-04_OccurDate]
		 '',      --[2300I_HI20-01_OccurType]
		 '',      --[2300I_HI20-02_OccurCode]
		 '',      --[2300I_HI20-03_OccurDateQualifier]
		 '',      --[2300I_HI20-04_OccurDate]
		 '',      --[2300I_HI21-01_OccurType]
		 '',      --[2300I_HI21-02_OccurCode]
		 '',      --[2300I_HI21-03_OccurDateQualifier]
		 '',      --[2300I_HI21-04_OccurDate]
		 '',      --[2300I_HI22-01_OccurType]
		 '',      --[2300I_HI22-02_OccurCode]
		 '',      --[2300I_HI22-03_OccurDateQualifier]
		 '',      --[2300I_HI22-04_OccurDate]
		 '',      --[2300I_HI23-01_OccurType]
		 '',      --[2300I_HI23-02_OccurCode]
		 '',      --[2300I_HI23-03_OccurDateQualifier]
		 '',      --[2300I_HI23-04_OccurDate]
		 '',      --[2300I_HI24-01_OccurType]
		 '',      --[2300I_HI24-02_OccurCode]
		 '',      --[2300I_HI24-03_OccurDateQualifier]
		 '',      --[2300I_HI24-04_OccurDate]
		 '',      --[2300I_HI13-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI13-02_TreatmentCode ]
		 '',      --[2300I_HI14-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI14-02_TreatmentCode ]
		 '',      --[2300I_HI15-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI15-02_TreatmentCode ]
		 '',      --[2300I_HI16-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI16-02_TreatmentCode ]
		 '',      --[2300I_HI17-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI17-02_TreatmentCode ]
		 '',      --[2300I_HI18-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI18-02_TreatmentCode ]
		 '',      --[2300I_HI19-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI19-02_TreatmentCode ]
		 '',      --[2300I_HI20-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI20-02_TreatmentCode ]
		 '',      --[2300I_HI21-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI21-02_TreatmentCode ]
		 '',      --[2300I_HI22-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI22-02_TreatmentCode ]
		 '',      --[2300I_HI23-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI23-02_TreatmentCode ]
		 '',      --[2300I_HI24-01_TreatmentCodeQualifier]
		 '',      --[2300I_HI24-02_TreatmentCode ]
		 '',      --[2300I_HI13-01_ConditionCodeQualifier]
		 '',      --[2300I_HI13-02_ConditionCode ]
		 '',      --[2300I_HI14-01_ConditionCodeQualifier]
		 '',      --[2300I_HI14-02_ConditionCode ]
		 '',      --[2300I_HI15-01_ConditionCodeQualifier]
		 '',      --[2300I_HI15-02_ConditionCode ]
		 '',      --[2300I_HI16-01_ConditionCodeQualifier]
		 '',      --[2300I_HI16-02_ConditionCode ]
		 '',      --[2300I_HI17-01_ConditionCodeQualifier]
		 '',      --[2300I_HI17-02_ConditionCode ]
		 '',      --[2300I_HI18-01_ConditionCodeQualifier]
		 '',      --[2300I_HI18-02_ConditionCode ]
		 '',      --[2300I_HI19-01_ConditionCodeQualifier]
		 '',      --[2300I_HI19-02_ConditionCode ]
		 '',      --[2300I_HI20-01_ConditionCodeQualifier]
		 '',      --[2300I_HI20-02_ConditionCode ]
		 '',      --[2300I_HI21-01_ConditionCodeQualifier]
		 '',      --[2300I_HI21-02_ConditionCode ]
		 '',      --[2300I_HI22-01_ConditionCodeQualifier]
		 '',      --[2300I_HI22-02_ConditionCode ]
		 '',      --[2300I_HI23-01_ConditionCodeQualifier]
		 '',      --[2300I_HI23-02_ConditionCode ]
		 '',      --[2300I_HI24-01_ConditionCodeQualifier]
		 '',      --[2300I_HI24-02_ConditionCode ]
		 '',      --[2300I_REF01_FileInformation2]
		 '',      --[2300I_REF01_FileInformation3]
		 '',      --[2300I_REF01_FileInformation4]
		 '',      --[2300I_REF01_FileInformation5]
		 '',      --[2300I_REF01_FileInformation6]
		 '',      --[2300I_REF01_FileInformation7]
		 '',      --[2300I_REF01_FileInformation8]
		 '',      --[2300I_REF01_FileInformation9]
		 '',      --[2300I_REF01_FileInformation10]
		 '',      --[2310EI_REF01_ProviderIdentifierQualifer3]
		 ''    --[2310EI_REF02_ProviderIdentifier3]
FROM	OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CLMHDR
INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CLMHDR.CLM_ID = CSVP.ClaimID
LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_DTL_ADJUD CLMDTL ON CSVP.ClaimID = CLMDTL.CLM_ID;


/********************************************************************************************************************************************************************
  STARTING ATTENDING PROVIDER DATA UDPATES 
*********************************************************************************************************************************************************************/

IF OBJECT_ID('tempdb.dbo.#TMPATTENDPROV') IS NOT NULL
        	DROP TABLE #TMPATTENDPROV;

SELECT DISTINCT 
		CLMHDR.CLM_ID, 
		PROVDEM.FRST_NM, 
		PROVDEM.LAST_NM, 
		PROVDEM.PROV_NM, 
		PROVDEM.PROV_NPI
INTO #TMPATTENDPROV
FROM OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CLMHDR
INNER JOIN EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20 ON CLMHDR.CLM_ID = CSV20.ClaimID 
JOIN OSS.staging.CDO_PROV_DEMG PROVDEM ON CLMHDR.ATTND_PROV_NPI = PROVDEM.PROV_NPI AND CLMHDR.SRC_DATA_KEY = PROVDEM.SRC_DATA_KEY
WHERE CLMHDR.SRC_DATA_KEY <> '40'
UNION 
SELECT DISTINCT  
		CLMHDR.CLM_ID, 
		PROVDEM.FRST_NM, 
		PROVDEM.LAST_NM, 
		PROVDEM.PROV_NM, 
		PROVDEM.PROV_NPI
FROM OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CLMHDR
INNER JOIN EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20 ON CLMHDR.CLM_ID = CSV20.ClaimID 
JOIN OSS.staging.CDO_PROV_DEMG PROVDEM ON CLMHDR.ATTND_PROV_ID = PROVDEM.PROV_ID AND CLMHDR.SRC_DATA_KEY = PROVDEM.SRC_DATA_KEY
WHERE CLMHDR.SRC_DATA_KEY = '40';

UPDATE CSV20I
SET [2310AI_NM104_FirstName] = CASE WHEN TMPATTENDPROV.FRST_NM = '' OR TMPATTENDPROV.FRST_NM IS NULL THEN '' ELSE TMPATTENDPROV.FRST_NM END,
    [2310AI_NM103_LastName]  = CASE WHEN TMPATTENDPROV.FRST_NM = '' OR TMPATTENDPROV.FRST_NM IS NOT NULL THEN TMPATTENDPROV.LAST_NM ELSE TMPATTENDPROV.PROV_NM END,
	[2310AI_NM109_ProviderIdentifier] = CASE WHEN TMPATTENDPROV.CLM_ID IS NULL THEN '' ELSE TMPATTENDPROV.PROV_NPI END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
LEFT JOIN #TMPATTENDPROV TMPATTENDPROV ON CSV20I.ClaimID = TMPATTENDPROV.CLM_ID;

/********************************************************************************************************************************************************************
  STARTING OPERATING PROVIDER DATA UDPATES 
*********************************************************************************************************************************************************************/

IF OBJECT_ID('tempdb.dbo.#TMPOPERPROV') IS NOT NULL
        	DROP TABLE #TMPOPERPROV;

SELECT DISTINCT 
		CLMHDR.CLM_ID, 
		PROVDEM.FRST_NM, 
		PROVDEM.LAST_NM, 
		PROVDEM.PROV_NM, 
		PROVDEM.PROV_NPI
INTO #TMPOPERPROV
FROM OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CLMHDR
INNER JOIN EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20 ON CLMHDR.CLM_ID = CSV20.ClaimID 
JOIN OSS.staging.CDO_PROV_DEMG PROVDEM ON CLMHDR.ATTND_PROV_NPI = PROVDEM.PROV_NPI AND CLMHDR.SRC_DATA_KEY = PROVDEM.SRC_DATA_KEY
WHERE CLMHDR.SRC_DATA_KEY <> '40'
UNION 
SELECT DISTINCT  
		CLMHDR.CLM_ID, 
		PROVDEM.FRST_NM, 
		PROVDEM.LAST_NM, 
		PROVDEM.PROV_NM, 
		PROVDEM.PROV_NPI
FROM OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CLMHDR
INNER JOIN EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20 ON CLMHDR.CLM_ID = CSV20.ClaimID 
JOIN OSS.staging.CDO_PROV_DEMG PROVDEM ON CLMHDR.ATTND_PROV_ID = PROVDEM.PROV_ID AND CLMHDR.SRC_DATA_KEY = PROVDEM.SRC_DATA_KEY
WHERE CLMHDR.SRC_DATA_KEY = '40';

UPDATE CSV20I
SET [2310BI_NM104_FirstName] = CASE WHEN TMPOPERPROV.FRST_NM = '' OR TMPOPERPROV.FRST_NM IS NULL THEN '' ELSE TMPOPERPROV.FRST_NM END,
    [2310BI_NM103_LastName]  = CASE WHEN TMPOPERPROV.FRST_NM = '' OR TMPOPERPROV.FRST_NM IS NOT NULL THEN TMPOPERPROV.LAST_NM ELSE TMPOPERPROV.PROV_NM END,
	[2310AI_NM109_ProviderIdentifier] = CASE WHEN TMPOPERPROV.CLM_ID IS NULL THEN '' ELSE TMPOPERPROV.PROV_NPI END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
LEFT JOIN #TMPOPERPROV TMPOPERPROV ON CSV20I.ClaimID = TMPOPERPROV.CLM_ID;


/********************************************************************************************************************************************************************
  PIVOT DIAGNOSIS CODES FOR INSERT INTO 20 RECORD
*********************************************************************************************************************************************************************/
IF OBJECT_ID('tempdb.dbo.#TMPDIAGS') IS NOT NULL
        	DROP TABLE #TMPDIAGS;

IF OBJECT_ID('tempdb.dbo.#TMPDIAGSRET') IS NOT NULL
        	DROP TABLE #TMPDIAGSRET;

IF @IsRetraction = 0
BEGIN
WITH diags AS (
    SELECT
        CD.CLM_ID
        ,ICD_DIAGS_CD
		,DX_Label = 
            REPLACE('DX' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY DIAGS_SEQ)) % 26 AS VARCHAR)  
            , 'DX0', 'DX26')
    FROM OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CD
	INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CSVP.ClaimID = CDHDR.CLM_ID
    WHERE 1 = 1
   	AND CD.DIAGS_TY_CD = 'S'
    AND CD.DIAGS_SEQ < 27
	)
SELECT
    CLM_ID
   ,pt.[DX1]
   ,pt.[DX2]
   ,pt.[DX3]
   ,pt.[DX4]
   ,pt.[DX5]
   ,pt.[DX6]
   ,pt.[DX7]
   ,pt.[DX8]
   ,pt.[DX9]
   ,pt.[DX10]
   ,pt.[DX11]
   ,pt.[DX12] 
   ,pt.[DX13]
   ,pt.[DX14]
   ,pt.[DX15]
   ,pt.[DX16]
   ,pt.[DX17]
   ,pt.[DX18]
   ,pt.[DX19]
   ,pt.[DX20]
   ,pt.[DX21]
   ,pt.[DX22]
   ,pt.[DX23]
   ,pt.[DX24] 
   ,pt.[DX25] 
   ,pt.[DX26] 
INTO #TMPDIAGS
FROM  DIAGS
PIVOT
(
MIN(ICD_DIAGS_CD)
FOR DIAGS.DX_Label IN ([DX1], [DX2], [DX3], [DX4], [DX5], [DX6], [DX7], [DX8], [DX9], [DX10], [DX11], [DX12],[DX13],[DX14], [DX15], [DX16], [DX17], [DX18], [DX19], [DX20], [DX21],[DX22], [DX23], [DX24], [DX25], [DX26])
) AS pt;
END;

IF @IsRetraction = 1
BEGIN
WITH diags AS (
    SELECT
        CD.CLM_ID
        ,ICD_DIAGS_CD
		,DX_Label = 
            REPLACE('DX' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY DIAGS_SEQ)) % 26 AS VARCHAR)  
            , 'DX0', 'DX26')
    FROM OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CD
	INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	INNER JOIN WIPRO.dbo.Retraction_Input_Interim RII ON RII.CLAIMID = CD.CLM_ID AND RII.DXCode = CD.ICD_DIAGS_CD
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CSVP.ClaimID = CDHDR.CLM_ID
    WHERE 1 = 1
    AND CD.DIAGS_SEQ < 27
	)
SELECT
    CLM_ID
   ,pt.[DX1]
   ,pt.[DX2]
   ,pt.[DX3]
   ,pt.[DX4]
   ,pt.[DX5]
   ,pt.[DX6]
   ,pt.[DX7]
   ,pt.[DX8]
   ,pt.[DX9]
   ,pt.[DX10]
   ,pt.[DX11]
   ,pt.[DX12] 
   ,pt.[DX13]
   ,pt.[DX14]
   ,pt.[DX15]
   ,pt.[DX16]
   ,pt.[DX17]
   ,pt.[DX18]
   ,pt.[DX19]
   ,pt.[DX20]
   ,pt.[DX21]
   ,pt.[DX22]
   ,pt.[DX23]
   ,pt.[DX24] 
   ,pt.[DX25] 
   ,pt.[DX26] 
INTO #TMPDIAGSRET
FROM  DIAGS
PIVOT
(
MIN(ICD_DIAGS_CD)
FOR DIAGS.DX_Label IN ([DX1], [DX2], [DX3], [DX4], [DX5], [DX6], [DX7], [DX8], [DX9], [DX10], [DX11], [DX12],[DX13],[DX14], [DX15], [DX16], [DX17], [DX18], [DX19], [DX20], [DX21],[DX22], [DX23], [DX24], [DX25], [DX26])
) AS pt;
END;

/********************************************************************************************************************************************************************
  PIVOT POA INDICATORS FOR INSERT INTO 20 RECORD
*********************************************************************************************************************************************************************/
IF OBJECT_ID('tempdb.dbo.#TMPDIAGSPOA') IS NOT NULL
        	DROP TABLE #TMPDIAGSPOA;

IF OBJECT_ID('tempdb.dbo.#TMPDIAGSPOARET') IS NOT NULL
        	DROP TABLE #TMPDIAGSPOARET;

IF @IsRetraction = 0 
BEGIN 
WITH diags AS (
    SELECT
        CD.CLM_ID
        ,POA_CD
		,DX_Label = 
            REPLACE('DXPOA' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY DIAGS_SEQ)) % 26 AS VARCHAR) --end rownumber
            , 'DXPOA0', 'DXPOA26')
    FROM OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CD
	INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CSVP.ClaimID = CDHDR.CLM_ID
    WHERE 1 = 1
    --AND CD.SRC_DATA_KEY = '210' AND CDHDR.CLM_TY = 'INSTITUTIONAL' 
	AND CD.DIAGS_TY_CD = 'S'
    AND CD.DIAGS_SEQ < 27
	)
SELECT
    CLM_ID
   ,pt.[DXPOA1]
   ,pt.[DXPOA2]
   ,pt.[DXPOA3]
   ,pt.[DXPOA4]
   ,pt.[DXPOA5]
   ,pt.[DXPOA6]
   ,pt.[DXPOA7]
   ,pt.[DXPOA8]
   ,pt.[DXPOA9]
   ,pt.[DXPOA10]
   ,pt.[DXPOA11]
   ,pt.[DXPOA12] 
   ,pt.[DXPOA13]
   ,pt.[DXPOA14]
   ,pt.[DXPOA15]
   ,pt.[DXPOA16]
   ,pt.[DXPOA17]
   ,pt.[DXPOA18]
   ,pt.[DXPOA19]
   ,pt.[DXPOA20]
   ,pt.[DXPOA21]
   ,pt.[DXPOA22]
   ,pt.[DXPOA23]
   ,pt.[DXPOA24] 
   ,pt.[DXPOA25] 
   ,pt.[DXPOA26] 
INTO #TMPDIAGSPOA
FROM  DIAGS
PIVOT
(
MIN(POA_CD)
FOR DIAGS.DX_Label IN ([DXPOA1], [DXPOA2], [DXPOA3], [DXPOA4], [DXPOA5], [DXPOA6], [DXPOA7], [DXPOA8], [DXPOA9], [DXPOA10], [DXPOA11], [DXPOA12],[DXPOA13],[DXPOA14], [DXPOA15], [DXPOA16], [DXPOA17], [DXPOA18], [DXPOA19], [DXPOA20], [DXPOA21],[DXPOA22], [DXPOA23], [DXPOA24], [DXPOA25], [DXPOA26])
) AS pt;
END;


IF @IsRetraction = 1 
BEGIN 
WITH diags AS (
    SELECT
        CD.CLM_ID
        ,POA_CD
		,DX_Label = 
            REPLACE('DXPOA' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY DIAGS_SEQ)) % 26 AS VARCHAR) --end rownumber
            , 'DXPOA0', 'DXPOA26')
    FROM OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CD
	INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	INNER JOIN WIPRO.dbo.Retraction_Input_Interim RII ON RII.CLAIMID = CD.CLM_ID AND RII.DXCode = CD.ICD_DIAGS_CD
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CSVP.ClaimID = CDHDR.CLM_ID
    WHERE 1 = 1
    --AND CD.SRC_DATA_KEY = '210' AND CDHDR.CLM_TY = 'INSTITUTIONAL' 
	 AND CD.DIAGS_SEQ < 27
	)
SELECT
    CLM_ID
   ,pt.[DXPOA1]
   ,pt.[DXPOA2]
   ,pt.[DXPOA3]
   ,pt.[DXPOA4]
   ,pt.[DXPOA5]
   ,pt.[DXPOA6]
   ,pt.[DXPOA7]
   ,pt.[DXPOA8]
   ,pt.[DXPOA9]
   ,pt.[DXPOA10]
   ,pt.[DXPOA11]
   ,pt.[DXPOA12] 
   ,pt.[DXPOA13]
   ,pt.[DXPOA14]
   ,pt.[DXPOA15]
   ,pt.[DXPOA16]
   ,pt.[DXPOA17]
   ,pt.[DXPOA18]
   ,pt.[DXPOA19]
   ,pt.[DXPOA20]
   ,pt.[DXPOA21]
   ,pt.[DXPOA22]
   ,pt.[DXPOA23]
   ,pt.[DXPOA24] 
   ,pt.[DXPOA25] 
   ,pt.[DXPOA26] 
INTO #TMPDIAGSPOARET
FROM  DIAGS
PIVOT
(
MIN(POA_CD)
FOR DIAGS.DX_Label IN ([DXPOA1], [DXPOA2], [DXPOA3], [DXPOA4], [DXPOA5], [DXPOA6], [DXPOA7], [DXPOA8], [DXPOA9], [DXPOA10], [DXPOA11], [DXPOA12],[DXPOA13],[DXPOA14], [DXPOA15], [DXPOA16], [DXPOA17], [DXPOA18], [DXPOA19], [DXPOA20], [DXPOA21],[DXPOA22], [DXPOA23], [DXPOA24], [DXPOA25], [DXPOA26])
) AS pt;
END;

/********************************************************************************************************************************************************************
  UPDATE 20I RECORD WITH DIAGNOSIS CODES 
* Principal Diags
* All 26 pos secondary Digs  
*********************************************************************************************************************************************************************/
IF @IsRetraction = 0
BEGIN 
UPDATE CSV20I
SET 
[2300I_HI01-01_PrinDXType]		=	CASE WHEN CLMSDIAG.DIAGS_SEQ = '1' THEN 'ABK' END,
[2300I_HI01-02_PrincipalDXCode] =	CASE WHEN CLMSDIAG.DIAGS_SEQ = '1' THEN ICD_DIAGS_CD END,
[2300I_HI01-09_PrincipalDXPOA]  =   CASE WHEN CLMSDIAG.DIAGS_SEQ = '1' THEN POA_CD END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CLMSDIAG ON CSV20I.CLAIMID = CLMSDIAG.CLM_ID AND CLMSDIAG.DIAGS_SEQ = '1'; 


UPDATE CSV20I
SET 
[2300I_HI01-01_DXType_1]		=	CASE WHEN [DX1] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI01-02_DXCode_1]		=	CASE WHEN [DX1] IS NOT NULL THEN [DX1] ELSE '' END,
[2300I_HI02-01_DXType_1]		=	CASE WHEN [DX2] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI02-02_DXCode_1]		=	CASE WHEN [DX2] IS NOT NULL THEN [DX2] ELSE '' END,	
[2300I_HI03-01_DXType_1]		=	CASE WHEN [DX3] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI03-02_DXCode_1]		=	CASE WHEN [DX3] IS NOT NULL THEN [DX3] ELSE '' END,
[2300I_HI04-01_DXType_1]		=	CASE WHEN [DX4] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI04-02_DXCode_1]		=	CASE WHEN [DX4] IS NOT NULL THEN [DX4] ELSE '' END,
[2300I_HI05-01_DXType_1]		=	CASE WHEN [DX5] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI05-02_DXCode_1]		=	CASE WHEN [DX5] IS NOT NULL THEN [DX5] ELSE '' END,
[2300I_HI06-01_DXType_1]		=	CASE WHEN [DX6] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI06-02_DXCode_1]		=	CASE WHEN [DX6] IS NOT NULL THEN [DX6] ELSE '' END,
[2300I_HI07-01_DXType_1]		=	CASE WHEN [DX7] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI07-02_DXCode_1]		=	CASE WHEN [DX7] IS NOT NULL THEN [DX7] ELSE '' END,
[2300I_HI08-01_DXType_1]		=	CASE WHEN [DX8] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI08-02_DXCode_1]		=	CASE WHEN [DX8] IS NOT NULL THEN [DX8] ELSE '' END,
[2300I_HI09-01_DXType_1]		=	CASE WHEN [DX9] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI09-02_DXCode_1]		=	CASE WHEN [DX9] IS NOT NULL THEN [DX9] ELSE '' END,
[2300I_HI10-01_DXType_1]		=	CASE WHEN [DX10] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI10-02_DXCode_1]		=	CASE WHEN [DX10] IS NOT NULL THEN [DX10] ELSE '' END,
[2300I_HI11-01_DXType_1]		=	CASE WHEN [DX11] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI11-02_DXCode_1]		=	CASE WHEN [DX11] IS NOT NULL THEN [DX11] ELSE '' END,
[2300I_HI12-01_DXType_1]		=	CASE WHEN [DX12] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI12-02_DXCode_1]		=	CASE WHEN [DX12] IS NOT NULL THEN [DX12] ELSE '' END,
[2300I_HI01-01_DXType_2]		=	CASE WHEN [DX13] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI01-02_DXCode_2]		=	CASE WHEN [DX13] IS NOT NULL THEN [DX13] ELSE '' END,
[2300I_HI02-01_DXType_2]		=	CASE WHEN [DX14] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI02-02_DXCode_2]		=	CASE WHEN [DX14] IS NOT NULL THEN [DX14] ELSE '' END,	
[2300I_HI03-01_DXType_2]		=	CASE WHEN [DX15] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI03-02_DXCode_2]		=	CASE WHEN [DX15] IS NOT NULL THEN [DX15] ELSE '' END,
[2300I_HI04-01_DXType_2]		=	CASE WHEN [DX16] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI04-02_DXCode_2]		=	CASE WHEN [DX16] IS NOT NULL THEN [DX16] ELSE '' END,
[2300I_HI05-01_DXType_2]		=	CASE WHEN [DX17] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI05-02_DXCode_2]		=	CASE WHEN [DX17] IS NOT NULL THEN [DX17] ELSE '' END,
[2300I_HI06-01_DXType_2]		=	CASE WHEN [DX18] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI06-02_DXCode_2]		=	CASE WHEN [DX18] IS NOT NULL THEN [DX18] ELSE '' END,
[2300I_HI07-01_DXType_2]		=	CASE WHEN [DX19] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI07-02_DXCode_2]		=	CASE WHEN [DX19] IS NOT NULL THEN [DX19] ELSE '' END,
[2300I_HI08-01_DXType_2]		=	CASE WHEN [DX20] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI08-02_DXCode_2]		=	CASE WHEN [DX20] IS NOT NULL THEN [DX20] ELSE '' END,
[2300I_HI09-01_DXType_2]		=	CASE WHEN [DX21] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI09-02_DXCode_2]		=	CASE WHEN [DX21] IS NOT NULL THEN [DX21] ELSE '' END,
[2300I_HI10-01_DXType_2]		=	CASE WHEN [DX22] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI10-02_DXCode_2]		=	CASE WHEN [DX22] IS NOT NULL THEN [DX22] ELSE '' END,
[2300I_HI11-01_DXType_2]		=	CASE WHEN [DX23] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI11-02_DXCode_2]		=	CASE WHEN [DX23] IS NOT NULL THEN [DX23] ELSE '' END,
[2300I_HI12-01_DXType_2]		=	CASE WHEN [DX24] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI12-02_DXCode_2]		=	CASE WHEN [DX24] IS NOT NULL THEN [DX24] ELSE '' END,
[2300I_HI13-01_DXType_2]		=	CASE WHEN [DX25] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI13-02_DXCode_2]		=	CASE WHEN [DX25] IS NOT NULL THEN [DX25] ELSE '' END,
[2300I_HI14-01_DXType_2]		=	CASE WHEN [DX26] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI14-02_DXCode_2]		=	CASE WHEN [DX26] IS NOT NULL THEN [DX26] ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
LEFT JOIN #TMPDIAGS TMPDIAGS ON CSV20I.CLAIMID = TMPDIAGS.CLM_ID 
LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CLMSDIAG ON CSV20I.CLAIMID = CLMSDIAG.CLM_ID; 

END; 

IF @IsRetraction = 1
BEGIN 

UPDATE CSV20I
SET 
[2300I_HI01-01_PrinDXType]		=	CASE WHEN [DX1] IS NOT NULL THEN 'ABK' ELSE '' END,
[2300I_HI01-02_PrincipalDXCode]	=	CASE WHEN [DX1] IS NOT NULL THEN [DX1] ELSE '' END,
[2300I_HI02-01_DXType_1]		=	CASE WHEN [DX2] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI02-02_DXCode_1]		=	CASE WHEN [DX2] IS NOT NULL THEN [DX2] ELSE '' END,	
[2300I_HI03-01_DXType_1]		=	CASE WHEN [DX3] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI03-02_DXCode_1]		=	CASE WHEN [DX3] IS NOT NULL THEN [DX3] ELSE '' END,
[2300I_HI04-01_DXType_1]		=	CASE WHEN [DX4] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI04-02_DXCode_1]		=	CASE WHEN [DX4] IS NOT NULL THEN [DX4] ELSE '' END,
[2300I_HI05-01_DXType_1]		=	CASE WHEN [DX5] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI05-02_DXCode_1]		=	CASE WHEN [DX5] IS NOT NULL THEN [DX5] ELSE '' END,
[2300I_HI06-01_DXType_1]		=	CASE WHEN [DX6] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI06-02_DXCode_1]		=	CASE WHEN [DX6] IS NOT NULL THEN [DX6] ELSE '' END,
[2300I_HI07-01_DXType_1]		=	CASE WHEN [DX7] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI07-02_DXCode_1]		=	CASE WHEN [DX7] IS NOT NULL THEN [DX7] ELSE '' END,
[2300I_HI08-01_DXType_1]		=	CASE WHEN [DX8] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI08-02_DXCode_1]		=	CASE WHEN [DX8] IS NOT NULL THEN [DX8] ELSE '' END,
[2300I_HI09-01_DXType_1]		=	CASE WHEN [DX9] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI09-02_DXCode_1]		=	CASE WHEN [DX9] IS NOT NULL THEN [DX9] ELSE '' END,
[2300I_HI10-01_DXType_1]		=	CASE WHEN [DX10] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI10-02_DXCode_1]		=	CASE WHEN [DX10] IS NOT NULL THEN [DX10] ELSE '' END,
[2300I_HI11-01_DXType_1]		=	CASE WHEN [DX11] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI11-02_DXCode_1]		=	CASE WHEN [DX11] IS NOT NULL THEN [DX11] ELSE '' END,
[2300I_HI12-01_DXType_1]		=	CASE WHEN [DX12] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI12-02_DXCode_1]		=	CASE WHEN [DX12] IS NOT NULL THEN [DX12] ELSE '' END,
[2300I_HI01-01_DXType_2]		=	CASE WHEN [DX13] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI01-02_DXCode_2]		=	CASE WHEN [DX13] IS NOT NULL THEN [DX13] ELSE '' END,
[2300I_HI02-01_DXType_2]		=	CASE WHEN [DX14] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI02-02_DXCode_2]		=	CASE WHEN [DX14] IS NOT NULL THEN [DX14] ELSE '' END,	
[2300I_HI03-01_DXType_2]		=	CASE WHEN [DX15] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI03-02_DXCode_2]		=	CASE WHEN [DX15] IS NOT NULL THEN [DX15] ELSE '' END,
[2300I_HI04-01_DXType_2]		=	CASE WHEN [DX16] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI04-02_DXCode_2]		=	CASE WHEN [DX16] IS NOT NULL THEN [DX16] ELSE '' END,
[2300I_HI05-01_DXType_2]		=	CASE WHEN [DX17] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI05-02_DXCode_2]		=	CASE WHEN [DX17] IS NOT NULL THEN [DX17] ELSE '' END,
[2300I_HI06-01_DXType_2]		=	CASE WHEN [DX18] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI06-02_DXCode_2]		=	CASE WHEN [DX18] IS NOT NULL THEN [DX18] ELSE '' END,
[2300I_HI07-01_DXType_2]		=	CASE WHEN [DX19] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI07-02_DXCode_2]		=	CASE WHEN [DX19] IS NOT NULL THEN [DX19] ELSE '' END,
[2300I_HI08-01_DXType_2]		=	CASE WHEN [DX20] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI08-02_DXCode_2]		=	CASE WHEN [DX20] IS NOT NULL THEN [DX20] ELSE '' END,
[2300I_HI09-01_DXType_2]		=	CASE WHEN [DX21] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI09-02_DXCode_2]		=	CASE WHEN [DX21] IS NOT NULL THEN [DX21] ELSE '' END,
[2300I_HI10-01_DXType_2]		=	CASE WHEN [DX22] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI10-02_DXCode_2]		=	CASE WHEN [DX22] IS NOT NULL THEN [DX22] ELSE '' END,
[2300I_HI11-01_DXType_2]		=	CASE WHEN [DX23] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI11-02_DXCode_2]		=	CASE WHEN [DX23] IS NOT NULL THEN [DX23] ELSE '' END,
[2300I_HI12-01_DXType_2]		=	CASE WHEN [DX24] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI12-02_DXCode_2]		=	CASE WHEN [DX24] IS NOT NULL THEN [DX24] ELSE '' END,
[2300I_HI13-01_DXType_2]		=	CASE WHEN [DX25] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI13-02_DXCode_2]		=	CASE WHEN [DX25] IS NOT NULL THEN [DX25] ELSE '' END,
[2300I_HI14-01_DXType_2]		=	CASE WHEN [DX26] IS NOT NULL THEN 'ABF' ELSE '' END,
[2300I_HI14-02_DXCode_2]		=	CASE WHEN [DX26] IS NOT NULL THEN [DX26] ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
INNER JOIN #TMPDIAGSRET TMPDIAGS ON CSV20I.CLAIMID = TMPDIAGS.CLM_ID 
LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CLMSDIAG ON CSV20I.CLAIMID = CLMSDIAG.CLM_ID; 

END;

/* ----------------------------------------------------------------------------------
UPDATE 20I RECORD WITH DIAGNOSIS CODES 
* Principal Diags
* All 26 pos secondary Digs                                                        *
-----------------------------------------------------------------------------------*/ 

--Admit Diagnosis Code Updates 
UPDATE CSV20I
SET 
[2300I_HI01-01_AdmittingDXType] =	CASE WHEN DIAGS_TY_CD = 'A' THEN 'ABJ'END,
[2300I_HI01-02_AdmittingDXCode] =	CASE WHEN DIAGS_TY_CD = 'A' THEN ICD_DIAGS_CD END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
INNER JOIN OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CLMSDIAG ON CSV20I.CLAIMID = CLMSDIAG.CLM_ID AND DIAGS_TY_CD = 'A';

--POA Indicator Updates 
IF @IsRetraction = 0
BEGIN 
UPDATE CSV20I
SET 
[2300I_HI01-09_DXPOA_1]		=	CASE WHEN [DXPOA1] IS NOT NULL THEN [DXPOA1] ELSE '' END,
[2300I_HI02-09_DXPOA_1]		=	CASE WHEN [DXPOA2] IS NOT NULL THEN [DXPOA2] ELSE '' END,	
[2300I_HI03-09_DXPOA_1]		=	CASE WHEN [DXPOA3] IS NOT NULL THEN [DXPOA3] ELSE '' END,
[2300I_HI04-09_DXPOA_1]		=	CASE WHEN [DXPOA4] IS NOT NULL THEN [DXPOA4] ELSE '' END,
[2300I_HI05-09_DXPOA_1]		=	CASE WHEN [DXPOA5] IS NOT NULL THEN [DXPOA5] ELSE '' END,
[2300I_HI06-09_DXPOA_1]		=	CASE WHEN [DXPOA6] IS NOT NULL THEN [DXPOA6] ELSE '' END,
[2300I_HI07-09_DXPOA_1]		=	CASE WHEN [DXPOA7] IS NOT NULL THEN [DXPOA7] ELSE '' END,
[2300I_HI08-09_DXPOA_1]		=	CASE WHEN [DXPOA8] IS NOT NULL THEN [DXPOA8] ELSE '' END,
[2300I_HI09-09_DXPOA_1]		=	CASE WHEN [DXPOA9] IS NOT NULL THEN [DXPOA9] ELSE '' END,
[2300I_HI10-09_DXPOA_1]		=	CASE WHEN [DXPOA10] IS NOT NULL THEN [DXPOA10] ELSE '' END,
[2300I_HI11-09_DXPOA_1]		=	CASE WHEN [DXPOA11] IS NOT NULL THEN [DXPOA11] ELSE '' END,
[2300I_HI12-09_DXPOA_1]		=	CASE WHEN [DXPOA12] IS NOT NULL THEN [DXPOA12] ELSE '' END,
[2300I_HI01-09_DXPOA_2]		=	CASE WHEN [DXPOA13] IS NOT NULL THEN [DXPOA13] ELSE '' END,
[2300I_HI02-09_DXPOA_2]		=	CASE WHEN [DXPOA14] IS NOT NULL THEN [DXPOA14] ELSE '' END,	
[2300I_HI03-09_DXPOA_2]		=	CASE WHEN [DXPOA15] IS NOT NULL THEN [DXPOA15] ELSE '' END,
[2300I_HI04-09_DXPOA_2]		=	CASE WHEN [DXPOA16] IS NOT NULL THEN [DXPOA16] ELSE '' END,
[2300I_HI05-09_DXPOA_2]		=	CASE WHEN [DXPOA17] IS NOT NULL THEN [DXPOA17] ELSE '' END,
[2300I_HI06-09_DXPOA_2]		=	CASE WHEN [DXPOA18] IS NOT NULL THEN [DXPOA18] ELSE '' END,
[2300I_HI07-09_DXPOA_2]		=	CASE WHEN [DXPOA19] IS NOT NULL THEN [DXPOA19] ELSE '' END,
[2300I_HI08-09_DXPOA_2]		=	CASE WHEN [DXPOA20] IS NOT NULL THEN [DXPOA20] ELSE '' END,
[2300I_HI09-09_DXPOA_2]		=	CASE WHEN [DXPOA21] IS NOT NULL THEN [DXPOA21] ELSE '' END,
[2300I_HI10-09_DXPOA_2]		=	CASE WHEN [DXPOA22] IS NOT NULL THEN [DXPOA22] ELSE '' END,
[2300I_HI11-09_DXPOA_2]		=	CASE WHEN [DXPOA23] IS NOT NULL THEN [DXPOA23] ELSE '' END,
[2300I_HI12-09_DXPOA_2]		=	CASE WHEN [DXPOA24] IS NOT NULL THEN [DXPOA24] ELSE '' END,
[2300I_HI13-09_DXPOA_2]		=	CASE WHEN [DXPOA25] IS NOT NULL THEN [DXPOA25] ELSE '' END,
[2300I_HI14-09_DXPOA_2]		=	CASE WHEN [DXPOA26] IS NOT NULL THEN [DXPOA26] ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
LEFT JOIN #TMPDIAGSPOA TMPDIAGSPOA ON CSV20I.CLAIMID = TMPDIAGSPOA.CLM_ID 
LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CLMSDIAG ON CSV20I.CLAIMID = CLMSDIAG.CLM_ID
END;

IF @IsRetraction = 1
BEGIN 
UPDATE CSV20I
SET 
[2300I_HI01-09_DXPOA_1]		=	CASE WHEN [DXPOA1] IS NOT NULL THEN [DXPOA1] ELSE '' END,
[2300I_HI02-09_DXPOA_1]		=	CASE WHEN [DXPOA2] IS NOT NULL THEN [DXPOA2] ELSE '' END,	
[2300I_HI03-09_DXPOA_1]		=	CASE WHEN [DXPOA3] IS NOT NULL THEN [DXPOA3] ELSE '' END,
[2300I_HI04-09_DXPOA_1]		=	CASE WHEN [DXPOA4] IS NOT NULL THEN [DXPOA4] ELSE '' END,
[2300I_HI05-09_DXPOA_1]		=	CASE WHEN [DXPOA5] IS NOT NULL THEN [DXPOA5] ELSE '' END,
[2300I_HI06-09_DXPOA_1]		=	CASE WHEN [DXPOA6] IS NOT NULL THEN [DXPOA6] ELSE '' END,
[2300I_HI07-09_DXPOA_1]		=	CASE WHEN [DXPOA7] IS NOT NULL THEN [DXPOA7] ELSE '' END,
[2300I_HI08-09_DXPOA_1]		=	CASE WHEN [DXPOA8] IS NOT NULL THEN [DXPOA8] ELSE '' END,
[2300I_HI09-09_DXPOA_1]		=	CASE WHEN [DXPOA9] IS NOT NULL THEN [DXPOA9] ELSE '' END,
[2300I_HI10-09_DXPOA_1]		=	CASE WHEN [DXPOA10] IS NOT NULL THEN [DXPOA10] ELSE '' END,
[2300I_HI11-09_DXPOA_1]		=	CASE WHEN [DXPOA11] IS NOT NULL THEN [DXPOA11] ELSE '' END,
[2300I_HI12-09_DXPOA_1]		=	CASE WHEN [DXPOA12] IS NOT NULL THEN [DXPOA12] ELSE '' END,
[2300I_HI01-09_DXPOA_2]		=	CASE WHEN [DXPOA13] IS NOT NULL THEN [DXPOA13] ELSE '' END,
[2300I_HI02-09_DXPOA_2]		=	CASE WHEN [DXPOA14] IS NOT NULL THEN [DXPOA14] ELSE '' END,	
[2300I_HI03-09_DXPOA_2]		=	CASE WHEN [DXPOA15] IS NOT NULL THEN [DXPOA15] ELSE '' END,
[2300I_HI04-09_DXPOA_2]		=	CASE WHEN [DXPOA16] IS NOT NULL THEN [DXPOA16] ELSE '' END,
[2300I_HI05-09_DXPOA_2]		=	CASE WHEN [DXPOA17] IS NOT NULL THEN [DXPOA17] ELSE '' END,
[2300I_HI06-09_DXPOA_2]		=	CASE WHEN [DXPOA18] IS NOT NULL THEN [DXPOA18] ELSE '' END,
[2300I_HI07-09_DXPOA_2]		=	CASE WHEN [DXPOA19] IS NOT NULL THEN [DXPOA19] ELSE '' END,
[2300I_HI08-09_DXPOA_2]		=	CASE WHEN [DXPOA20] IS NOT NULL THEN [DXPOA20] ELSE '' END,
[2300I_HI09-09_DXPOA_2]		=	CASE WHEN [DXPOA21] IS NOT NULL THEN [DXPOA21] ELSE '' END,
[2300I_HI10-09_DXPOA_2]		=	CASE WHEN [DXPOA22] IS NOT NULL THEN [DXPOA22] ELSE '' END,
[2300I_HI11-09_DXPOA_2]		=	CASE WHEN [DXPOA23] IS NOT NULL THEN [DXPOA23] ELSE '' END,
[2300I_HI12-09_DXPOA_2]		=	CASE WHEN [DXPOA24] IS NOT NULL THEN [DXPOA24] ELSE '' END,
[2300I_HI13-09_DXPOA_2]		=	CASE WHEN [DXPOA25] IS NOT NULL THEN [DXPOA25] ELSE '' END,
[2300I_HI14-09_DXPOA_2]		=	CASE WHEN [DXPOA26] IS NOT NULL THEN [DXPOA26] ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
LEFT JOIN #TMPDIAGSPOARET TMPDIAGSPOA ON CSV20I.CLAIMID = TMPDIAGSPOA.CLM_ID 
LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CLMSDIAG ON CSV20I.CLAIMID = CLMSDIAG.CLM_ID
END;

/********************************************************************************************************
	PROCEDURE CODE UPDATES 
*********************************************************************************************************/
IF OBJECT_ID('tempdb.dbo.#TMPPROCS') IS NOT NULL
        	DROP TABLE #TMPPROCS;

WITH procs AS (
    SELECT
        CD.CLM_ID
        ,ICD_PROC_CD
        ,PC_Label = 
            REPLACE('PC' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY [PROC_SEQ])) % 12 AS VARCHAR) --end rownumber
            , 'PC0', 'PC12')
    FROM OSS.dbo.[SDO_MDQO_CLM_ICD_PROC_CD_ADJUD] CD
	INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CSVP.ClaimID = CDHDR.CLM_ID
    WHERE 1 = 1
    --AND CD.SRC_DATA_KEY = '210' AND CDHDR.CLM_TY = 'INSTITUTIONAL' 
	AND CD.PROC_TY_CD = 'O'
    AND CD.PROC_SEQ < 14
	)
SELECT
    CLM_ID
   ,pt.[PC1]
   ,pt.[PC2]
   ,pt.[PC3]
   ,pt.[PC4]
   ,pt.[PC5]
   ,pt.[PC6]
   ,pt.[PC7]
   ,pt.[PC8]
   ,pt.[PC9]
   ,pt.[PC10]
   ,pt.[PC11]
   ,pt.[PC12] 
INTO #TMPPROCS
FROM  PROCS
PIVOT
(
MIN(ICD_PROC_CD)
FOR PROCS.PC_Label IN ([PC1], [PC2], [PC3], [PC4], [PC5], [PC6], [PC7], [PC8], [PC9], [PC10], [PC11], [PC12])
) AS pt;

/********************************************************************************************************
	PROCEDURE CODE UPDATES 
*********************************************************************************************************/
IF OBJECT_ID('tempdb.dbo.##TMPPROCDATE') IS NOT NULL
        	DROP TABLE ##TMPPROCDATE;

CREATE TABLE ##TMPPROCDATE (
    CLM_ID  VARCHAR (50)
   ,[PC1]  VARCHAR(20)
   ,[PC2]  VARCHAR(20)
   ,[PC3]  VARCHAR(20)
   ,[PC4]  VARCHAR(20)
   ,[PC5]  VARCHAR(20)
   ,[PC6]  VARCHAR(20)
   ,[PC7]  VARCHAR(20)
   ,[PC8]  VARCHAR(20)
   ,[PC9]  VARCHAR(20)
   ,[PC10] VARCHAR(20)
   ,[PC11] VARCHAR(20)
   ,[PC12] VARCHAR(20) 
   ,[PC1DATE]  date
   ,[PC2DATE]  date
   ,[PC3DATE]  date
   ,[PC4DATE]  date
   ,[PC5DATE]  date
   ,[PC6DATE]  date
   ,[PC7DATE]  date
   ,[PC8DATE]  date
   ,[PC9DATE]  date
   ,[PC10DATE] date
   ,[PC11DATE] date
   ,[PC12DATE] date) ;

   TRUNCATE TABLE ##TMPPROCDATE;
   INSERT INTO ##TMPPROCDATE (
		CLM_ID,[PC1],[PC2],[PC3],[PC4],[PC5],[PC6],[PC7],[PC8],[PC9],[PC10],[PC11],[PC12])
   SELECT 
		CLM_ID,[PC1],[PC2],[PC3],[PC4],[PC5],[PC6],[PC7],[PC8],[PC9],[PC10],[PC11],[PC12]
	FROM #TMPPROCS


DECLARE @PROCCOLUMN INT,
        @PROCCPREFIX VARCHAR(3),
		@PROCCONCAT VARCHAR(5),
		@PROCCDATE VARCHAR(10),
		@PROCSQLTEXT NVARCHAR(1000);
SET @PROCCPREFIX = 'PC';
SET @PROCCOLUMN = 1;
SET @PROCCONCAT = @PROCCPREFIX + CAST(@PROCCOLUMN AS VARCHAR(2));
SET @PROCCDATE = RTRIM(LTRIM(@PROCCONCAT)) + 'DATE' 
WHILE (@PROCCOLUMN < 13)
	BEGIN 
		SET @PROCSQLTEXT = N'UPDATE' + ' ##TMPPROCDATE SET ' + @PROCCDATE + ' = PROC_DT FROM ##TMPPROCDATE A JOIN OSS.staging.SDO_MDQO_CLM_ICD_PROC_CD_ADJUD B ON ' +  @PROCCONCAT + ' = ICD_PROC_CD AND A.CLM_ID = B.CLM_ID' 
		EXEC (@PROCSQLTEXT)
			SET @PROCCOLUMN = @PROCCOLUMN + 1;
			SET @PROCCONCAT = @PROCCPREFIX + CAST(@PROCCOLUMN AS VARCHAR(2));
			SET @PROCCDATE = RTRIM(LTRIM(@PROCCONCAT)) + 'DATE' 
	END;
/* 

20I Update Principal Procedure Codes 
*/   

UPDATE CSV20I
SET 
[2300I_HI01-01_PrincipalPXType] =	CASE WHEN CDPROC.PROC_TY_CD = 'P' THEN 'BBR' ELSE '' END,
[2300I_HI01-02_PrincipalPXCode] =	CASE WHEN CDPROC.PROC_TY_CD = 'P' AND CDPROC.[ICD_PROC_CD] IS NOT NULL THEN CDPROC.[ICD_PROC_CD] ELSE '' END,
[2300I_HI01-04_PrincipalPXDate] =	CASE WHEN CDPROC.PROC_TY_CD = 'P' AND CDPROC.[ICD_PROC_CD] IS NOT NULL THEN REPLACE(REPLACE([PROC_DT],'1900-01-01' ,''),'-','') ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_ICD_PROC_CD_ADJUD] CDPROC ON CSV20I.CLAIMID = CDPROC.CLM_ID
WHERE CDPROC.PROC_TY_CD = 'P'
/* 

20I Update Procedure Codes 
*/ 
UPDATE CSV20I
SET 
[2300I_HI01-01_PXType_1]		=	CASE WHEN [PC1] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI01-02_PXCode_1]		=	CASE WHEN [PC1] IS NOT NULL THEN [PC1] ELSE '' END,
[2300I_HI01-04_PXDate_1]        =	CASE WHEN [PC1] IS NOT NULL THEN REPLACE(REPLACE([PC1DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI02-01_PXType_1]		=	CASE WHEN [PC2] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI02-02_PXCode_1]		=	CASE WHEN [PC2] IS NOT NULL THEN [PC2] ELSE '' END,
[2300I_HI02-04_PXDate_1]        =	CASE WHEN [PC2] IS NOT NULL THEN REPLACE(REPLACE([PC2DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI03-01_PXType_1]		=	CASE WHEN [PC3] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI03-02_PXCode_1]		=	CASE WHEN [PC3] IS NOT NULL THEN [PC3] ELSE '' END,
[2300I_HI03-04_PXDate_1]        =	CASE WHEN [PC3] IS NOT NULL THEN REPLACE(REPLACE([PC3DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI04-01_PXType_1]		=	CASE WHEN [PC4] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI04-02_PXCode_1]		=	CASE WHEN [PC4] IS NOT NULL THEN [PC4] ELSE '' END,
[2300I_HI04-04_PXDate_1]        =	CASE WHEN [PC4] IS NOT NULL THEN REPLACE(REPLACE([PC4DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI05-01_PXType_1]		=	CASE WHEN [PC5] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI05-02_PXCode_1]		=	CASE WHEN [PC5] IS NOT NULL THEN [PC5] ELSE '' END,
[2300I_HI05-04_PXDate_1]        =	CASE WHEN [PC5] IS NOT NULL THEN REPLACE(REPLACE([PC5DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI06-01_PXType_1]		=	CASE WHEN [PC6] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI06-02_PXCode_1]		=	CASE WHEN [PC6] IS NOT NULL THEN [PC6] ELSE '' END,
[2300I_HI06-04_PXDate_1]        =	CASE WHEN [PC6] IS NOT NULL THEN REPLACE(REPLACE([PC6DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI07-01_PXType_1]		=	CASE WHEN [PC7] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI07-02_PXCode_1]		=	CASE WHEN [PC7] IS NOT NULL THEN [PC7] ELSE '' END,
[2300I_HI07-04_PXDate_1]        =	CASE WHEN [PC7] IS NOT NULL THEN REPLACE(REPLACE([PC7DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI08-01_PXType_1]		=	CASE WHEN [PC8] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI08-02_PXCode_1]		=	CASE WHEN [PC8] IS NOT NULL THEN [PC8] ELSE '' END,
[2300I_HI08-04_PXDate_1]        =	CASE WHEN [PC8] IS NOT NULL THEN REPLACE(REPLACE([PC8DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI09-01_PXType_1]		=	CASE WHEN [PC9] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI09-02_PXCode_1]		=	CASE WHEN [PC9] IS NOT NULL THEN [PC9] ELSE '' END,
[2300I_HI09-04_PXDate_1]        =	CASE WHEN [PC9] IS NOT NULL THEN REPLACE(REPLACE([PC9DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI10-01_PXType_1]		=	CASE WHEN [PC10] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI10-02_PXCode_1]		=	CASE WHEN [PC10] IS NOT NULL THEN [PC10] ELSE '' END,
[2300I_HI10-04_PXDate_1]        =	CASE WHEN [PC10] IS NOT NULL THEN REPLACE(REPLACE([PC10DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI11-01_PXType_1]		=	CASE WHEN [PC11] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI11-02_PXCode_1]		=	CASE WHEN [PC11] IS NOT NULL THEN [PC11] ELSE '' END,
[2300I_HI11-04_PXDate_1]        =	CASE WHEN [PC11] IS NOT NULL THEN REPLACE(REPLACE([PC11DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI12-01_PXType_1]		=	CASE WHEN [PC12] IS NOT NULL THEN 'BBQ' ELSE '' END,
[2300I_HI12-02_PXCode_1]		=	CASE WHEN [PC12] IS NOT NULL THEN [PC12] ELSE '' END,
[2300I_HI12-04_PXDate_1]        =	CASE WHEN [PC12] IS NOT NULL THEN REPLACE(REPLACE([PC12DATE],'1900-01-01' ,''),'-','') ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
LEFT JOIN ##TMPPROCDATE TMPPROCS ON CSV20I.CLAIMID = TMPPROCS.CLM_ID 
LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_ICD_PROC_CD_ADJUD] CDPROC ON CSV20I.CLAIMID = CDPROC.CLM_ID

/*--------------------------------------------------------------
PIVOT ON INJURY CODES FOR 20I UPDATES 

--------------------------------------------------------------*/
IF OBJECT_ID('tempdb.dbo.#TMPDIAGINJ') IS NOT NULL
        	DROP TABLE #TMPDIAGINJ;

WITH diagsinj AS (
    SELECT
        CD.CLM_ID
        ,ICD_DIAGS_CD
        ,DX_Label = 
            REPLACE('DX' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY DIAGS_SEQ)) % 26 AS VARCHAR) --end rownumber
            , 'DX0', 'DX12')
    FROM OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CD
	INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CSVP.ClaimID = CDHDR.CLM_ID
    WHERE 1 = 1
    --AND CD.SRC_DATA_KEY = '210' AND CDHDR.CLM_TY = 'INSTITUTIONAL' 
	AND CD.DIAGS_TY_CD = 'T'
    AND CD.DIAGS_SEQ < 27
	)
SELECT
    CLM_ID
   ,ptinj.[DX1]
   ,ptinj.[DX2]
   ,ptinj.[DX3]
   ,ptinj.[DX4]
   ,ptinj.[DX5]
   ,ptinj.[DX6]
   ,ptinj.[DX7]
   ,ptinj.[DX8]
   ,ptinj.[DX9]
   ,ptinj.[DX10]
   ,ptinj.[DX11]
   ,ptinj.[DX12] 
INTO #TMPDIAGINJ
FROM  DIAGSINJ
PIVOT
(
MIN(ICD_DIAGS_CD)
FOR DIAGSINJ.DX_Label IN ([DX1], [DX2], [DX3], [DX4], [DX5], [DX6], [DX7], [DX8], [DX9], [DX10], [DX11], [DX12])
) AS ptinj;

---------------------
---------------------

IF OBJECT_ID('tempdb.dbo.#TMPDIAGSINJPOA') IS NOT NULL
        	DROP TABLE #TMPDIAGSINJPOA;

WITH diaginjpoa AS (
    SELECT
        CD.CLM_ID
        ,POA_CD
		,DX_Label = 
            REPLACE('DXPOA' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY DIAGS_SEQ)) % 26 AS VARCHAR) --end rownumber
            , 'DXPOA0', 'DXPOA26')
    FROM OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CD
	INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CSVP.ClaimID = CDHDR.CLM_ID
    WHERE 1 = 1
	AND CD.DIAGS_TY_CD = 'T'
    AND CD.DIAGS_SEQ < 27
	)
SELECT
    CLM_ID
   ,ptinjpoa.[DXPOA1]
   ,ptinjpoa.[DXPOA2]
   ,ptinjpoa.[DXPOA3]
   ,ptinjpoa.[DXPOA4]
   ,ptinjpoa.[DXPOA5]
   ,ptinjpoa.[DXPOA6]
   ,ptinjpoa.[DXPOA7]
   ,ptinjpoa.[DXPOA8]
   ,ptinjpoa.[DXPOA9]
   ,ptinjpoa.[DXPOA10]
   ,ptinjpoa.[DXPOA11]
   ,ptinjpoa.[DXPOA12] 
   ,ptinjpoa.[DXPOA13]
   ,ptinjpoa.[DXPOA14]
   ,ptinjpoa.[DXPOA15]
   ,ptinjpoa.[DXPOA16]
   ,ptinjpoa.[DXPOA17]
   ,ptinjpoa.[DXPOA18]
   ,ptinjpoa.[DXPOA19]
   ,ptinjpoa.[DXPOA20]
   ,ptinjpoa.[DXPOA21]
   ,ptinjpoa.[DXPOA22]
   ,ptinjpoa.[DXPOA23]
   ,ptinjpoa.[DXPOA24] 
   ,ptinjpoa.[DXPOA25] 
   ,ptinjpoa.[DXPOA26] 
INTO #TMPDIAGSINJPOA
FROM  DIAGINJPOA
PIVOT
(
MIN(POA_CD)
FOR DIAGINJPOA.DX_Label IN ([DXPOA1], [DXPOA2], [DXPOA3], [DXPOA4], [DXPOA5], [DXPOA6], [DXPOA7], [DXPOA8], [DXPOA9], [DXPOA10], [DXPOA11], [DXPOA12],[DXPOA13],[DXPOA14], [DXPOA15], [DXPOA16], [DXPOA17], [DXPOA18], [DXPOA19], [DXPOA20], [DXPOA21],[DXPOA22], [DXPOA23], [DXPOA24], [DXPOA25], [DXPOA26])
) AS ptinjpoa;

/* ----------------------------------------------------------------------------------
          UPDATE 20I RECORD WITH EXTERNAL CAUSE OF INJURY CODES  
                                                                                   *
-----------------------------------------------------------------------------------*/ 
UPDATE CSV20I
SET 
[2300I_HI01-01_ECIDXType]		=	CASE WHEN [DX1] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI01-02_ECIDXCode]		=	CASE WHEN [DX1] IS NOT NULL THEN [DX1] ELSE '' END,
[2300I_HI02-01_ECIDXType]		=	CASE WHEN [DX2] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI02-02_ECIDXCode]		=	CASE WHEN [DX2] IS NOT NULL THEN [DX2] ELSE '' END,
[2300I_HI03-01_ECIDXType]		=	CASE WHEN [DX3] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI03-02_ECIDXCode]		=	CASE WHEN [DX3] IS NOT NULL THEN [DX3] ELSE '' END,
[2300I_HI04-01_ECIDXType]		=	CASE WHEN [DX4] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI04-02_ECIDXCode]		=	CASE WHEN [DX4] IS NOT NULL THEN [DX4] ELSE '' END,
[2300I_HI05-01_ECIDXType]		=	CASE WHEN [DX5] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI05-02_ECIDXCode]		=	CASE WHEN [DX5] IS NOT NULL THEN [DX5] ELSE '' END,
[2300I_HI06-01_ECIDXType]		=	CASE WHEN [DX6] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI06-02_ECIDXCode]		=	CASE WHEN [DX6] IS NOT NULL THEN [DX6] ELSE '' END,
[2300I_HI07-01_ECIDXType]		=	CASE WHEN [DX7] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI07-02_ECIDXCode]		=	CASE WHEN [DX7] IS NOT NULL THEN [DX7] ELSE '' END,
[2300I_HI08-01_ECIDXType]		=	CASE WHEN [DX8] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI08-02_ECIDXCode]		=	CASE WHEN [DX8] IS NOT NULL THEN [DX8] ELSE '' END,
[2300I_HI09-01_ECIDXType]		=	CASE WHEN [DX9] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI09-02_ECIDXCode]		=	CASE WHEN [DX9] IS NOT NULL THEN [DX9] ELSE '' END,
[2300I_HI10-01_ECIDXType]		=	CASE WHEN [DX10] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI10-02_ECIDXCode]		=	CASE WHEN [DX10] IS NOT NULL THEN [DX10] ELSE '' END,
[2300I_HI11-01_ECIDXType]		=	CASE WHEN [DX11] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI11-02_ECIDXCode]		=	CASE WHEN [DX11] IS NOT NULL THEN [DX11] ELSE '' END,
[2300I_HI12-01_ECIDXType]		=	CASE WHEN [DX12] IS NOT NULL THEN 'ABN' ELSE '' END,
[2300I_HI12-02_ECIDXCode]		=	CASE WHEN [DX12] IS NOT NULL THEN [DX12] ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
INNER JOIN #TMPDIAGINJ TMPDIAGINJ ON CSV20I.CLAIMID = TMPDIAGINJ.CLM_ID;
-----------------------------------------------------------------------------------*/ 
UPDATE CSV20I
SET 
[2300I_HI01-09_ECIDXPOA]		=	CASE WHEN [DXPOA1] IS NOT NULL THEN [DXPOA1] ELSE '' END,
[2300I_HI02-09_ECIDXPOA]		=	CASE WHEN [DXPOA2] IS NOT NULL THEN [DXPOA2] ELSE '' END,
[2300I_HI03-09_ECIDXPOA]		=	CASE WHEN [DXPOA3] IS NOT NULL THEN [DXPOA3] ELSE '' END,
[2300I_HI04-09_ECIDXPOA]		=	CASE WHEN [DXPOA4] IS NOT NULL THEN [DXPOA4] ELSE '' END,
[2300I_HI05-09_ECIDXPOA]		=	CASE WHEN [DXPOA5] IS NOT NULL THEN [DXPOA5] ELSE '' END,
[2300I_HI06-09_ECIDXPOA]		=	CASE WHEN [DXPOA6] IS NOT NULL THEN [DXPOA6] ELSE '' END,
[2300I_HI07-09_ECIDXPOA]		=	CASE WHEN [DXPOA7] IS NOT NULL THEN [DXPOA7] ELSE '' END,
[2300I_HI08-09_ECIDXPOA]		=	CASE WHEN [DXPOA8] IS NOT NULL THEN [DXPOA8] ELSE '' END,
[2300I_HI09-09_ECIDXPOA]		=	CASE WHEN [DXPOA9] IS NOT NULL THEN [DXPOA9] ELSE '' END,
[2300I_HI10-09_ECIDXPOA]		=	CASE WHEN [DXPOA10] IS NOT NULL THEN [DXPOA10] ELSE '' END,
[2300I_HI11-09_ECIDXPOA]		=	CASE WHEN [DXPOA11] IS NOT NULL THEN [DXPOA11] ELSE '' END,
[2300I_HI12-09_ECIDXPOA]		=	CASE WHEN [DXPOA12] IS NOT NULL THEN [DXPOA12] ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
INNER JOIN #TMPDIAGSINJPOA TMPDIAGSINJPOA ON CSV20I.CLAIMID = TMPDIAGSINJPOA.CLM_ID;


/* ----------------------------------------------------------------------------------
          PIVOT ON PATIENT REASON FOR VISIT CODES  
                                                                                   *
-----------------------------------------------------------------------------------*/ 
IF OBJECT_ID('tempdb.dbo.#TMPRESVISIT') IS NOT NULL
        	DROP TABLE #TMPRESVISIT;

WITH diagsvisit AS (
    SELECT
        CD.CLM_ID
        ,ICD_DIAGS_CD
        ,DX_Label = 
            REPLACE('DX' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY DIAGS_SEQ)) % 26 AS VARCHAR) --end rownumber
            , 'DX0', 'DX3')
    FROM OSS.dbo.[SDO_MDQO_CLM_DIAG_CD_ADJUD] CD
	INNER JOIN EDIFECS.staging.EE_CSV_20I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CSVP.ClaimID = CDHDR.CLM_ID
    WHERE 1 = 1
	AND CD.DIAGS_TY_CD = 'V'
    AND CD.DIAGS_SEQ < 4
	)
SELECT
    CLM_ID
   ,ptvisit.[DX1]
   ,ptvisit.[DX2]
   ,ptvisit.[DX3]
INTO #TMPRESVISIT
FROM  DIAGSVISIT
PIVOT
(
MIN(ICD_DIAGS_CD)
FOR DIAGSVISIT.DX_Label IN ([DX1], [DX2], [DX3])
) AS ptvisit;

/* ----------------------------------------------------------------------------------
UPDATE 20I RECORD WITH PATIENT REASON FOR VISIT CODES  
                                                     *
-----------------------------------------------------------------------------------*/ 
UPDATE CSV20I
SET 
[2300I_HI01-01_PatientDXType]	=	CASE WHEN [DX1] IS NOT NULL THEN 'APR' ELSE '' END,
[2300I_HI01-02_PatientDXCode]	=	CASE WHEN [DX1] IS NOT NULL THEN [DX1] ELSE '' END,
[2300I_HI02-01_PatientDXType]	=	CASE WHEN [DX2] IS NOT NULL THEN 'APR' ELSE '' END,
[2300I_HI02-02_PatientDXCode]	=	CASE WHEN [DX2] IS NOT NULL THEN [DX2] ELSE '' END,
[2300I_HI03-01_PatientDXType]	=	CASE WHEN [DX3] IS NOT NULL THEN 'APR' ELSE '' END,
[2300I_HI03-02_PatientDXCode]	=	CASE WHEN [DX3] IS NOT NULL THEN [DX3] ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
INNER JOIN #TMPRESVISIT TMPRESVISIT ON CSV20I.CLAIMID = TMPRESVISIT.CLM_ID;


/* ----------------------------------------------------------------------------------
          PIVOT ON OCCURRENCE CODES  
                                                                                   *
-----------------------------------------------------------------------------------*/ 
IF OBJECT_ID('tempdb.dbo.#TMPOCCODE') IS NOT NULL
        	DROP TABLE #TMPOCCODE;

WITH occcode AS (
    SELECT
        CD.CLM_ID
        ,CDSET_CD
        ,DX_Label = 
            REPLACE('OSC' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY [CDSET_CD])) % 26 AS VARCHAR) --end rownumber
            , 'OSC0', 'OSC12')
    FROM OSS.dbo.[SDO_MDQO_MED_CLM_CDSET] CD
	INNER JOIN EDIFECS.staging.EE_CSV_20I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CD.CLM_ID = CDHDR.CLM_ID
    WHERE 1 = 1
	AND CDSET_ATTRIB_NM = 'Occurrence Code'    
	)
SELECT
    CLM_ID
   ,OCCURCODE.[OSC1]
   ,OCCURCODE.[OSC2]
   ,OCCURCODE.[OSC3]
   ,OCCURCODE.[OSC4]
   ,OCCURCODE.[OSC5]
   ,OCCURCODE.[OSC6]
   ,OCCURCODE.[OSC7]
   ,OCCURCODE.[OSC8]
   ,OCCURCODE.[OSC9]
   ,OCCURCODE.[OSC10]
   ,OCCURCODE.[OSC11]
   ,OCCURCODE.[OSC12] 
 INTO #TMPOCCODE
FROM  OCCCODE
PIVOT
(
MIN([CDSET_CD])
FOR OCCCODE.DX_Label IN ([OSC1], [OSC2], [OSC3], [OSC4], [OSC5], [OSC6], [OSC7], [OSC8], [OSC9], [OSC10], [OSC11], [OSC12])
) AS OCCURCODE;

/* ----------------------------------------------------------------------------------
    ASSOCIATE DATES WITH OCCURRENCE CODES  
                                                                                   *
-----------------------------------------------------------------------------------*/ 
IF OBJECT_ID('tempdb.dbo.##TMPOCCDATE') IS NOT NULL
        	DROP TABLE ##TMPOCCDATE;

CREATE TABLE ##TMPOCCDATE (
    CLM_ID  VARCHAR (50)
   ,[OSC1]  VARCHAR(3)
   ,[OSC2]  VARCHAR(3)
   ,[OSC3]  VARCHAR(3)
   ,[OSC4]  VARCHAR(3)
   ,[OSC5]  VARCHAR(3)
   ,[OSC6]  VARCHAR(3)
   ,[OSC7]  VARCHAR(3)
   ,[OSC8]  VARCHAR(3)
   ,[OSC9]  VARCHAR(3)
   ,[OSC10] VARCHAR(3)
   ,[OSC11] VARCHAR(3)
   ,[OSC12] VARCHAR(3) 
   ,[OSC1DATE]  date
   ,[OSC2DATE]  date
   ,[OSC3DATE]  date
   ,[OSC4DATE]  date
   ,[OSC5DATE]  date
   ,[OSC6DATE]  date
   ,[OSC7DATE]  date
   ,[OSC8DATE]  date
   ,[OSC9DATE]  date
   ,[OSC10DATE] date
   ,[OSC11DATE] date
   ,[OSC12DATE] date) 

   INSERT INTO ##TMPOCCDATE (
		CLM_ID,[OSC1],[OSC2],[OSC3],[OSC4],[OSC5],[OSC6],[OSC7],[OSC8],[OSC9],[OSC10],[OSC11],[OSC12])
   SELECT 
		CLM_ID,[OSC1],[OSC2],[OSC3],[OSC4],[OSC5],[OSC6],[OSC7],[OSC8],[OSC9],[OSC10],[OSC11],[OSC12]
	FROM #TMPOCCODE;

DECLARE @OSCCOLUMN INT,
        @OCSCPREFIX VARCHAR(3),
        @OCSCONCAT VARCHAR(5),
        @OCSCDATE VARCHAR(10),
        @SQLTEXT NVARCHAR(1000),
        @OCSCATTB VARCHAR(30);
SET @OCSCPREFIX = 'OSC';
SET @OSCCOLUMN = 1;
SET @OCSCONCAT = @OCSCPREFIX + CAST(@OSCCOLUMN AS VARCHAR(2));
SET @OCSCDATE = RTRIM(LTRIM(@OCSCONCAT)) + 'DATE';
SET @OCSCATTB = 'Occurrence Code';
WHILE (@OSCCOLUMN < 13)
    BEGIN 
        SET @SQLTEXT = N'UPDATE ##TMPOCCDATE 
						SET ' + @OCSCDATE + ' = CLM_CDSET_EFF_DT FROM ##TMPOCCDATE A JOIN OSS.staging.SDO_MDQO_MED_CLM_CDSET B ON ' 
						+  @OCSCONCAT + ' = CDSET_CD AND A.CLM_ID = B.CLM_ID AND CDSET_ATTRIB_NM = '''+ 
						+  @OCSCATTB + ''';'; 
		EXEC (@SQLTEXT)
			SET @OSCCOLUMN = @OSCCOLUMN + 1;
			SET @OCSCONCAT = @OCSCPREFIX + CAST(@OSCCOLUMN AS VARCHAR(2));
			SET @OCSCDATE = RTRIM(LTRIM(@OCSCONCAT)) + 'DATE' 
	END;


/* ----------------------------------------------------------------------------------
UPDATE 20I RECORD WITH OCCURRENCE CODES  
                                                     *
-----------------------------------------------------------------------------------*/ 

UPDATE CSV20I
SET 
[2300I_HI01-02_OccurCode]		=	CASE WHEN [OSC1] IS NOT NULL THEN [OSC1] ELSE '' END,
[2300I_HI01-04_OccurDate]		=	CASE WHEN [OSC1] IS NOT NULL THEN REPLACE(REPLACE([OSC1DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI02-02_OccurCode]		=	CASE WHEN [OSC2] IS NOT NULL THEN [OSC2] ELSE '' END,
[2300I_HI02-04_OccurDate]		=	CASE WHEN [OSC2] IS NOT NULL THEN REPLACE(REPLACE([OSC2DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI03-02_OccurCode]		=	CASE WHEN [OSC3] IS NOT NULL THEN [OSC3] ELSE '' END,
[2300I_HI03-04_OccurDate]		=	CASE WHEN [OSC3] IS NOT NULL THEN REPLACE(REPLACE([OSC3DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI04-02_OccurCode]		=	CASE WHEN [OSC4] IS NOT NULL THEN [OSC4] ELSE '' END,
[2300I_HI04-04_OccurDate]		=	CASE WHEN [OSC4] IS NOT NULL THEN REPLACE(REPLACE([OSC4DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI05-02_OccurCode]		=	CASE WHEN [OSC5] IS NOT NULL THEN [OSC5] ELSE '' END,
[2300I_HI05-04_OccurDate]		=	CASE WHEN [OSC5] IS NOT NULL THEN REPLACE(REPLACE([OSC5DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI06-02_OccurCode]		=	CASE WHEN [OSC6] IS NOT NULL THEN [OSC6] ELSE '' END,
[2300I_HI06-04_OccurDate]		=	CASE WHEN [OSC6] IS NOT NULL THEN REPLACE(REPLACE([OSC6DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI07-02_OccurCode]		=	CASE WHEN [OSC7] IS NOT NULL THEN [OSC7] ELSE '' END,
[2300I_HI07-04_OccurDate]		=	CASE WHEN [OSC7] IS NOT NULL THEN REPLACE(REPLACE([OSC7DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI08-02_OccurCode]		=	CASE WHEN [OSC8] IS NOT NULL THEN [OSC8] ELSE '' END,
[2300I_HI08-04_OccurDate]		=	CASE WHEN [OSC8] IS NOT NULL THEN REPLACE(REPLACE([OSC8DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI09-02_OccurCode]		=	CASE WHEN [OSC9] IS NOT NULL THEN [OSC9] ELSE '' END,
[2300I_HI09-04_OccurDate]		=	CASE WHEN [OSC9] IS NOT NULL THEN REPLACE(REPLACE([OSC9DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI10-02_OccurCode]		=	CASE WHEN [OSC10] IS NOT NULL THEN [OSC10] ELSE '' END,
[2300I_HI10-04_OccurDate]		=	CASE WHEN [OSC10] IS NOT NULL THEN REPLACE(REPLACE([OSC10DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI11-02_OccurCode]		=	CASE WHEN [OSC11] IS NOT NULL THEN [OSC11] ELSE '' END,
[2300I_HI11-04_OccurDate]		=	CASE WHEN [OSC11] IS NOT NULL THEN REPLACE(REPLACE([OSC11DATE],'1900-01-01' ,''),'-','') ELSE '' END,
[2300I_HI12-02_OccurCode]		=	CASE WHEN [OSC12] IS NOT NULL THEN [OSC12] ELSE '' END,
[2300I_HI12-04_OccurDate]		=	CASE WHEN [OSC12] IS NOT NULL THEN REPLACE(REPLACE([OSC12DATE],'1900-01-01' ,''),'-','') ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
INNER JOIN ##TMPOCCDATE TMPOCCDATE ON CSV20I.CLAIMID = TMPOCCDATE.CLM_ID;


/* ----------------------------------------------------------------------------------
          PIVOT ON OCCURRENCE SPAN CODES  
                                                                                   *
-----------------------------------------------------------------------------------*/ 
IF OBJECT_ID('tempdb.dbo.#TMPOCCSPAN') IS NOT NULL
        	DROP TABLE #TMPOCCSPAN;

	WITH occspan AS (
    SELECT
        CD.CLM_ID
        ,CDSET_CD
        ,DX_Label = 
            REPLACE('OSC' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY [CDSET_CD])) % 26 AS VARCHAR) --end rownumber
            , 'OSC0', 'OSC12')
    FROM OSS.dbo.[SDO_MDQO_MED_CLM_CDSET] CD
	INNER JOIN EDIFECS.staging.EE_CSV_20I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CD.CLM_ID = CDHDR.CLM_ID
    WHERE 1 = 1
    --AND CD.SRC_DATA_KEY = '210' AND CDHDR.CLM_TY = 'INSTITUTIONAL' 
	AND CDSET_ATTRIB_NM = 'Occurrence Span Code'    
	)
SELECT
    CLM_ID
   ,OCCURSPANCODE.[OSC1]
   ,OCCURSPANCODE.[OSC2]
   ,OCCURSPANCODE.[OSC3]
   ,OCCURSPANCODE.[OSC4]
   ,OCCURSPANCODE.[OSC5]
   ,OCCURSPANCODE.[OSC6]
   ,OCCURSPANCODE.[OSC7]
   ,OCCURSPANCODE.[OSC8]
   ,OCCURSPANCODE.[OSC9]
   ,OCCURSPANCODE.[OSC10]
   ,OCCURSPANCODE.[OSC11]
   ,OCCURSPANCODE.[OSC12] 
   INTO #TMPOCCSPAN
FROM  OCCSPAN
PIVOT
(
MIN([CDSET_CD])
FOR OCCSPAN.DX_Label IN ([OSC1], [OSC2], [OSC3], [OSC4], [OSC5], [OSC6], [OSC7], [OSC8], [OSC9], [OSC10], [OSC11], [OSC12])
) AS OCCURSPANCODE;

IF OBJECT_ID('tempdb.dbo.##TMPOCCSPANDATE') IS NOT NULL
        	DROP TABLE ##TMPOCCSPANDATE;

CREATE TABLE ##TMPOCCSPANDATE (
    CLM_ID  VARCHAR (50)
   ,[OSC1]  VARCHAR(3)
   ,[OSC2]  VARCHAR(3)
   ,[OSC3]  VARCHAR(3)
   ,[OSC4]  VARCHAR(3)
   ,[OSC5]  VARCHAR(3)
   ,[OSC6]  VARCHAR(3)
   ,[OSC7]  VARCHAR(3)
   ,[OSC8]  VARCHAR(3)
   ,[OSC9]  VARCHAR(3)
   ,[OSC10] VARCHAR(3)
   ,[OSC11] VARCHAR(3)
   ,[OSC12] VARCHAR(3) 
   ,[OSC1DATE]  VARCHAR(20)
   ,[OSC2DATE]  VARCHAR(20)
   ,[OSC3DATE]  VARCHAR(20)
   ,[OSC4DATE]  VARCHAR(20)
   ,[OSC5DATE]  VARCHAR(20)
   ,[OSC6DATE]  VARCHAR(20)
   ,[OSC7DATE]  VARCHAR(20)
   ,[OSC8DATE]  VARCHAR(20)
   ,[OSC9DATE]  VARCHAR(20)
   ,[OSC10DATE] VARCHAR(20)
   ,[OSC11DATE] VARCHAR(20)
   ,[OSC12DATE] VARCHAR(20));

--DROP TABLE ##TMPOCCDATE
   INSERT INTO ##TMPOCCSPANDATE (
		CLM_ID,[OSC1],[OSC2],[OSC3],[OSC4],[OSC5],[OSC6],[OSC7],[OSC8],[OSC9],[OSC10],[OSC11],[OSC12])
   SELECT 
		CLM_ID,[OSC1],[OSC2],[OSC3],[OSC4],[OSC5],[OSC6],[OSC7],[OSC8],[OSC9],[OSC10],[OSC11],[OSC12]
	FROM #TMPOCCSPAN;


DECLARE @OSCSPANCOLUMN INT,
        @OSCSPANCPREFIX VARCHAR(3),
		@OSCSPANCONCAT VARCHAR(5),
		@OSCSPANCDATE VARCHAR(10),
		@OSCSPANSQLTEXT NVARCHAR(1000),
		@OSCSPANATTRB VARCHAR(30);
SET @OSCSPANCPREFIX = 'OSCSPAN';
SET @OSCSPANCOLUMN = 1;
SET @OSCSPANCONCAT = @OSCSPANCPREFIX + CAST(@OSCSPANCOLUMN AS VARCHAR(2));
SET @OSCSPANCDATE = RTRIM(LTRIM(@OSCSPANCONCAT)) + 'DATE';
SET @OSCSPANATTRB = 'Occurrence Span Code';
WHILE (@OSCSPANCOLUMN < 13)
	BEGIN 
		SET @OSCSPANSQLTEXT = N'UPDATE ##TMPOCCSPANDATE 
								SET ' + @OSCSPANCDATE + ' = CAST(CONVERT(CHAR(8),CLM_CDSET_EFF_DT,112) + CONVERT(CHAR(8),CLM_CDSET_TERM_DT,112) AS VARCHAR) FROM ##TMPOCCSPANDATE A JOIN OSS.staging.SDO_MDQO_MED_CLM_CDSET B ON ' 
									  +  @OSCSPANCONCAT + ' = CDSET_CD AND A.CLM_ID = B.CLM_ID AND CDSET_ATTRIB_NM = '''+  
					                  +  @OSCSPANATTRB +''';'; 
		EXEC (@OSCSPANSQLTEXT)
			SET @OSCSPANCOLUMN = @OSCSPANCOLUMN + 1;
			SET @OSCSPANCONCAT = @OSCSPANCPREFIX + CAST(@OSCSPANCOLUMN AS VARCHAR(2));
			SET @OSCSPANCDATE = RTRIM(LTRIM(@OSCSPANCONCAT)) + 'DATE' 
	END;

/* PREP OCCURANCE SPAN CODE DATES FOR CSV */

/* ----------------------------------------------------------------------------------
UPDATE 20I RECORD WITH OCCURRENCE SPAN CODES  
                                                     *
-----------------------------------------------------------------------------------*/ 
UPDATE CSV20I
SET 
[2300I_HI01-02_OccurSpanCode]		=	CASE WHEN [OSC1] IS NOT NULL THEN [OSC1] ELSE '' END,
[2300I_HI01-04_OccurSpanDate]		=	CASE WHEN [OSC1] IS NOT NULL THEN LEFT(OSC1DATE,LEN(OSC1DATE)-8) + '-' + RIGHT(OSC1DATE,8) ELSE '' END,
[2300I_HI02-02_OccurSpanCode]		=	CASE WHEN [OSC2] IS NOT NULL THEN [OSC2] ELSE '' END,
[2300I_HI02-04_OccurSpanDate]		=	CASE WHEN [OSC2] IS NOT NULL THEN LEFT(OSC2DATE,LEN(OSC2DATE)-8) + '-' + RIGHT(OSC2DATE,8) ELSE '' END,
[2300I_HI03-02_OccurSpanCode]		=	CASE WHEN [OSC3] IS NOT NULL THEN [OSC3] ELSE '' END,
[2300I_HI03-04_OccurSpanDate]		=	CASE WHEN [OSC3] IS NOT NULL THEN LEFT(OSC3DATE,LEN(OSC3DATE)-8) + '-' + RIGHT(OSC3DATE,8) ELSE '' END,
[2300I_HI04-02_OccurSpanCode]		=	CASE WHEN [OSC4] IS NOT NULL THEN [OSC4] ELSE '' END,
[2300I_HI04-04_OccurSpanDate]		=	CASE WHEN [OSC4] IS NOT NULL THEN LEFT(OSC5DATE,LEN(OSC5DATE)-8) + '-' + RIGHT(OSC5DATE,8) ELSE '' END,
[2300I_HI05-02_OccurSpanCode]		=	CASE WHEN [OSC5] IS NOT NULL THEN [OSC5] ELSE '' END,
[2300I_HI05-04_OccurSpanDate]		=	CASE WHEN [OSC5] IS NOT NULL THEN LEFT(OSC5DATE,LEN(OSC5DATE)-8) + '-' + RIGHT(OSC5DATE,8) ELSE '' END,
[2300I_HI06-02_OccurSpanCode]		=	CASE WHEN [OSC6] IS NOT NULL THEN [OSC6] ELSE '' END,
[2300I_HI06-04_OccurSpanDate]		=	CASE WHEN [OSC6] IS NOT NULL THEN LEFT(OSC6DATE,LEN(OSC6DATE)-8) + '-' + RIGHT(OSC6DATE,8) ELSE '' END,
[2300I_HI07-02_OccurSpanCode]		=	CASE WHEN [OSC7] IS NOT NULL THEN [OSC7] ELSE '' END,
[2300I_HI07-04_OccurSpanDate]		=	CASE WHEN [OSC7] IS NOT NULL THEN LEFT(OSC7DATE,LEN(OSC7DATE)-8) + '-' + RIGHT(OSC7DATE,8) ELSE '' END,
[2300I_HI08-02_OccurSpanCode]		=	CASE WHEN [OSC8] IS NOT NULL THEN [OSC8] ELSE '' END,
[2300I_HI08-04_OccurSpanDate]		=	CASE WHEN [OSC8] IS NOT NULL THEN LEFT(OSC8DATE,LEN(OSC8DATE)-8) + '-' + RIGHT(OSC8DATE,8) ELSE '' END,
[2300I_HI09-02_OccurSpanCode]		=	CASE WHEN [OSC9] IS NOT NULL THEN [OSC9] ELSE '' END,
[2300I_HI09-04_OccurSpanDate]		=	CASE WHEN [OSC9] IS NOT NULL THEN LEFT(OSC9DATE,LEN(OSC9DATE)-8) + '-' + RIGHT(OSC9DATE,8) ELSE '' END,
[2300I_HI10-02_OccurSpanCode]		=	CASE WHEN [OSC10] IS NOT NULL THEN [OSC10] ELSE '' END,
[2300I_HI10-04_OccurSpanDate]		=	CASE WHEN [OSC10] IS NOT NULL THEN LEFT(OSC10DATE,LEN(OSC10DATE)-8) + '-' + RIGHT(OSC10DATE,8) ELSE '' END,
[2300I_HI11-02_OccurSpanCode]		=	CASE WHEN [OSC11] IS NOT NULL THEN [OSC11] ELSE '' END,
[2300I_HI11-04_OccurSpanDate]		=	CASE WHEN [OSC11] IS NOT NULL THEN LEFT(OSC12DATE,LEN(OSC12DATE)-8) + '-' + RIGHT(OSC12DATE,8) ELSE '' END,
[2300I_HI12-02_OccurSpanCode]		=	CASE WHEN [OSC12] IS NOT NULL THEN [OSC12] ELSE '' END,
[2300I_HI12-04_OccurSpanDate]		=	CASE WHEN [OSC12] IS NOT NULL THEN LEFT(OSC12DATE,LEN(OSC12DATE)-8) + '-' + RIGHT(OSC12DATE,8) ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
INNER JOIN ##TMPOCCSPANDATE TMPOCCSPANDATE ON CSV20I.CLAIMID = TMPOCCSPANDATE.CLM_ID; 
	---------------------------------------------------------------------------------------------------------
	------------------------------------------------------------------------------------------------------------------
	IF OBJECT_ID('tempdb.dbo.#TMPCONDCODE') IS NOT NULL
        	DROP TABLE #TMPCONDCODE;
	
	WITH ccode AS (
    SELECT
        CD.CLM_ID
        ,CDSET_CD
        ,DX_Label = 
            REPLACE('CON' + 
                TRY_CAST(
                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY [CDSET_CD])) % 26 AS VARCHAR) --end rownumber
            , 'CON0', 'CON12')
    FROM OSS.dbo.[SDO_MDQO_MED_CLM_CDSET] CD
	INNER JOIN EDIFECS.staging.EE_CSV_20I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CD.CLM_ID = CDHDR.CLM_ID
    WHERE 1 = 1
    --AND CD.SRC_DATA_KEY = '210' AND CDHDR.CLM_TY = 'INSTITUTIONAL' 
	AND CDSET_ATTRIB_NM = 'Condition Code'    
	)
SELECT
    CLM_ID
   ,CONDITIONCODE.CON1
   ,CONDITIONCODE.CON2
   ,CONDITIONCODE.CON3
   ,CONDITIONCODE.CON4
   ,CONDITIONCODE.CON5
   ,CONDITIONCODE.CON6
   ,CONDITIONCODE.CON7
   ,CONDITIONCODE.CON8
   ,CONDITIONCODE.CON9
   ,CONDITIONCODE.CON10
   ,CONDITIONCODE.CON11
   ,CONDITIONCODE.CON12 
  INTO #TMPCONDCODE
FROM  ccode
PIVOT
(
MIN([CDSET_CD])
FOR ccode.DX_Label IN ([CON1], [CON2], [CON3], [CON4], [CON5], [CON6], [CON7], [CON8], [CON9], [CON10], [CON11], [CON12])
) AS CONDITIONCODE;

/* ----------------------------------------------------------------------------------
UPDATE 20I RECORD WITH CONDITION CODES  
                                                     *
-----------------------------------------------------------------------------------*/ 
UPDATE CSV20I
SET 
[2300I_HI01-02_ConditionCode ]		=	CASE WHEN [CON1] IS NOT NULL THEN [CON1] ELSE '' END,
[2300I_HI02-02_ConditionCode ]		=	CASE WHEN [CON2] IS NOT NULL THEN [CON2] ELSE '' END,
[2300I_HI03-02_ConditionCode ]		=	CASE WHEN [CON3] IS NOT NULL THEN [CON3] ELSE '' END,
[2300I_HI04-02_ConditionCode ]		=	CASE WHEN [CON4] IS NOT NULL THEN [CON4] ELSE '' END,
[2300I_HI05-02_ConditionCode ]		=	CASE WHEN [CON5] IS NOT NULL THEN [CON5] ELSE '' END,
[2300I_HI06-02_ConditionCode ]		=	CASE WHEN [CON6] IS NOT NULL THEN [CON6] ELSE '' END,
[2300I_HI07-02_ConditionCode ]		=	CASE WHEN [CON7] IS NOT NULL THEN [CON7] ELSE '' END,
[2300I_HI08-02_ConditionCode ]		=	CASE WHEN [CON8] IS NOT NULL THEN [CON8] ELSE '' END,
[2300I_HI09-02_ConditionCode ]		=	CASE WHEN [CON9] IS NOT NULL THEN [CON9] ELSE '' END,
[2300I_HI10-02_ConditionCode ]		=	CASE WHEN [CON10] IS NOT NULL THEN [CON10] ELSE '' END,
[2300I_HI11-02_ConditionCode ]		=	CASE WHEN [CON11] IS NOT NULL THEN [CON11] ELSE '' END,
[2300I_HI12-02_ConditionCode ]		=	CASE WHEN [CON12] IS NOT NULL THEN [CON12] ELSE '' END
FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
INNER JOIN #TMPCONDCODE TMPCONDCODE ON CSV20I.CLAIMID = TMPCONDCODE.CLM_ID; 

	------------------------------------------------------------------------------------------------------------------
	--Note: ValueCode logic commented out until data becomes available 
--	WITH ccode AS (
--    SELECT
--        CD.CLM_ID
--        ,CDSET_CD
--        ,DX_Label = 
--            REPLACE('VAL' + 
--                TRY_CAST(
--                    (ROW_NUMBER() OVER (PARTITION BY CD.CLM_ID    ORDER BY [CDSET_CD])) % 26 AS VARCHAR) --end rownumber
--            , 'VAL0', 'VAL12')
--    FROM OSS.dbo.[SDO_MDQO_MED_CLM_CDSET] CD
--	INNER JOIN EDIFECS.staging.EE_CSV_20I_Rec_Header CSVP ON CD.CLM_ID = CSVP.ClaimID
--	LEFT JOIN OSS.dbo.SDO_MDQO_MED_CLM_HDR_ADJUD CDHDR ON CD.CLM_ID = CDHDR.CLM_ID
--    WHERE 1 = 1
--    --AND CD.SRC_DATA_KEY = '210' AND CDHDR.CLM_TY = 'INSTITUTIONAL' 
--	AND CDSET_ATTRIB_NM = 'Value Code'    
--	)
--SELECT
--    CLM_ID
--   ,VALCODE.VAL1
--   ,VALCODE.VAL2
--   ,VALCODE.VAL3
--   ,VALCODE.VAL4
--   ,VALCODE.VAL5
--   ,VALCODE.VAL6
--   ,VALCODE.VAL7
--   ,VALCODE.VAL8
--   ,VALCODE.VAL9
--   ,VALCODE.VAL10
--   ,VALCODE.VAL11
--   ,VALCODE.VAL12 
--  INTO #TMPVALCODE
--FROM  ccode
--PIVOT
--(
--MIN([CDSET_CD])
--FOR ccode.DX_Label IN ([VAL1], [VAL2], [VAL3], [VAL4], [VAL5], [VAL6], [VAL7], [VAL8], [VAL9], [VAL10], [VAL11], [VAL12])
--) AS VALCODE;

/* ----------------------------------------------------------------------------------
UPDATE 20I RECORD WITH VALDITION CODES  
                                                     *
-----------------------------------------------------------------------------------*/ 
--UPDATE CSV20I
--SET 
--[2300I_HI01-02_ValueCode_1 ]		=	CASE WHEN [VAL1] IS NOT NULL THEN [VAL1] ELSE '' END,
--[2300I_HI02-02_ValueCode_1 ]		=	CASE WHEN [VAL2] IS NOT NULL THEN [VAL2] ELSE '' END,
--[2300I_HI03-02_ValueCode_1 ]		=	CASE WHEN [VAL3] IS NOT NULL THEN [VAL3] ELSE '' END,
--[2300I_HI04-02_ValueCode_1 ]		=	CASE WHEN [VAL4] IS NOT NULL THEN [VAL4] ELSE '' END,
--[2300I_HI05-05_ValueCode_1 ]		=	CASE WHEN [VAL5] IS NOT NULL THEN [VAL5] ELSE '' END,
--[2300I_HI06-02_ValueCode_1 ]		=	CASE WHEN [VAL6] IS NOT NULL THEN [VAL6] ELSE '' END,
--[2300I_HI07-02_ValueCode_1 ]		=	CASE WHEN [VAL7] IS NOT NULL THEN [VAL7] ELSE '' END,
--[2300I_HI08-02_ValueCode_1 ]		=	CASE WHEN [VAL8] IS NOT NULL THEN [VAL8] ELSE '' END,
--[2300I_HI09-02_ValueCode_1 ]		=	CASE WHEN [VAL9] IS NOT NULL THEN [VAL9] ELSE '' END,
--[2300I_HI10-02_ValueCode_1 ]		=	CASE WHEN [VAL10] IS NOT NULL THEN [VAL10] ELSE '' END,
--[2300I_HI11-02_ValueCode_1 ]		=	CASE WHEN [VAL11] IS NOT NULL THEN [VAL11] ELSE '' END,
--[2300I_HI12-02_ValueCode_1 ]		=	CASE WHEN [VAL12] IS NOT NULL THEN [VAL12] ELSE '' END
--FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSV20I
--INNER JOIN #TMPVALCODE TMPVALCODE ON CSV20I.CLAIMID = TMPVALCODE.CLM_ID; 




/* ----------------------------------------------------------------------------------
INSERT FOR 310I Record
                                                      *
-----------------------------------------------------------------------------------*/ 
TRUNCATE TABLE EDIFECS.staging.[EE_CSV_310I_Rec_Header];
INSERT INTO  EDIFECS.staging.[EE_CSV_310I_Rec_Header] (
		[ClaimID],
		[SourceDataKey],
		[SourceDesc],
		[CreateDate],
		[2320_SBR01_PayerResponsibilitySequence],
		[2320_SBR02_SubscriberRelationship],
		[2320_SBR09_ClaimFilingIndicator],
		[2320_AMT02_COBAmount_1],
		[2320_OI03_AssignBenefitsIndicator],
		[2330A_NM103_LastName],
		[2330A_NM104_FirstName],
		[2330A_N301_AddressLine1],
		[2330A_N302_AddressLine2],
		[2330A_N401_City],
		[2330A_N402_State],
		[2330A_N403_PostalCode],
		[2330B_NM103_Name],
		[2330B_NM109_OrganizationIdentifier],
		[2330B_N301_AddressLine1],
		[2330B_N302_AddressLine2],
		[2330B_N401_City],
		[2330B_N402_State],
		[2330B_N403_PostalCode]
)
SELECT 
	    DISTINCT 
		CLMHDR.[CLM_ID],        -- ClaimID - varchar(20)
		CLMHDR.[SRC_DATA_KEY],         -- SourceDataKey - int
		CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END,        -- SourceDesc - varchar(60)
		GETDATE(), -- CreateDate - datetime
		'P',--PAYER_RESP, -- PayerResponsibilityCode
		'18',--REL_CD1, --RelationshipCode
		'16',--CLM_FIL_INDCD1,
		[TOTL_PD_AMT],
		'Y',--[BEN_ASGNMT_CERT_CD],
		MEM.LAST_NM,
		MEM.FRST_NM,
		MEM.PHY_SRC_ADDR_LN_1,
		MEM.PHY_SRC_ADDR_LN_2, 
		MEM.PHY_SRC_CITY,
		MEM.PHY_SRC_STE,
		MEM.PHY_SRC_ZIP_CD,
		'HealthSpring', --OTH_PAYER1_NAME,
		[CNTRCT_NUM], --OTH_PAYER1_PLANID,
		'530 GREAT CIRCLE', --OTH_PAYER1_ADDRESS1,
		'', --OTH_PAYER1_ADDRESS2,
		'NASHVILLE', --OTH_PAYER1_CITY,
		'TN' , --OTH_PAYER1_STATE,
		'372289999'--[OTH_PAYER1_ZIP] + [OTH_PAYER1_ZIP4]
FROM OSS.dbo.[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR
INNER JOIN EDIFECS.staging.EE_CSV_20I_Rec_Header CSVP ON CLMHDR.CLM_ID = CSVP.ClaimID
left join OSS.staging.CDO_MBR_DEMG MEM ON CLMHDR.MBR_ID = MEM.MBR_ID AND CLMHDR.SRC_DATA_KEY = MEM.SRC_DATA_KEY

/* ----------------------------------------------------------------------------------
INSERT RECORDS INTO THE 40I SERVICE LINE RECS
                                                                                   *
-----------------------------------------------------------------------------------*/ 

TRUNCATE TABLE EDIFECS.staging.EE_CSV_40I_Rec_Detail;

INSERT INTO EDIFECS.staging.EE_CSV_40I_Rec_Detail
SELECT DISTINCT
 CLMDTL.[CLM_ID]
,CLMDTL.SRC_DATA_KEY
,CASE WHEN CLMHDR.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END AS SourceDesc  
,GETDATE() AS CreateDate 
,CLMDTL.[CLM_LN_ID]			AS ClaimLineNumber
,CLMDTL.[CLM_LN_ID]											AS [2400I_LX01_LineCounter]
,[REVNU_CD]
,CASE WHEN (CPT_PROC_CD <> '' OR CPT_PROC_CD IS NOT NULL) AND CLMDTL.REVNU_CD	NOT IN ('0024','0022','0023') THEN 'HC'
	  WHEN (CPT_PROC_CD <> '' OR CPT_PROC_CD IS NOT NULL) AND CLMDTL.REVNU_CD	IN ('0024','0022','0023') THEN 'HP'
	  ELSE ''	
END  --CPT_PROC_CD_GRP = 'HIPPS Rate Code' then 'HP' ELSE 'HC' 												AS [2400I_SV201_RevenueCode]
--,CASE WHEN CPT_PROC_CD = '' THEN '' 
--      ELSE SERV_ID_QUAL END                             AS [2400I_SV202-01_ServiceCodeType]
,ISNULL(CPT_PROC_CD,'')												AS [2400I_SV202-02_ServiceCode]


--,PROC_MOD1												AS [2400I_SV202-03_ServiceModifier1]
--,PROC_MOD2												AS [2400I_SV202-04_ServiceModifier2]
--,PROC_MOD3												AS [2400I_SV202-05_ServiceModifier3]
--,PROC_MOD4												AS [2400I_SV202-06_ServiceModifier4]

,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_1
     WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> ''  and isnull(CPT_MODFR_CD_1,'') = '' and ( isnull(CPT_MODFR_CD_2,'') <> '59' or isnull(CPT_MODFR_CD_3,'') <> '59' or isnull(CPT_MODFR_CD_4,'') <> '59') THEN '59'
	  ELSE CPT_MODFR_CD_1 END AS	[2400P_SV101-03_ServiceModifier1]
,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_2
     WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_2,'') = '' and isnull(CPT_MODFR_CD_1,'') <> ''))
						 THEN '59'
	  ELSE CPT_MODFR_CD_2 END	AS	[2400P_SV101-04_ServiceModifier2]
,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_3
	  WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_3,'') = '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '')
	                     THEN '59'
	  else CPT_MODFR_CD_3 END AS	[2400P_SV101-05_ServiceModifier3]
,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_4
	  WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_4,'') = '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '' and isnull(CPT_MODFR_CD_3,'') <> '')
	                     THEN '59'
	  WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_4,'') <> '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '' and isnull(CPT_MODFR_CD_3,'') <> '')
	                     THEN '59'
	  ELSE CPT_MODFR_CD_4 END  AS	[2400P_SV101-06_ServiceModifier4]	


,LEFT(CPT_PROC_CD_DESC,100)			AS [2400I_SV202-07_ServiceCodeDescription]
,REQD_AMT							AS [2400I_SV203_LineCharge]
, 'UN' /*CASE WHEN ISNULL(PROC_CD,'') <> '' THEN 'UN'ELSE '' END  [2400I_SV204_ServiceUnitMeasure]V */
,[SVC_UNITS]						AS [2400I_SV205_Quantity]
,''						            AS [2400I_SV207_NonCoveredCharge]
,''									AS [2400I_PWK01_ReportType]
,''									AS [2400I_PWK02_TransmissionCode]
,''									AS [2400I_PWK05_CodeQualifier]
,''									AS [2400I_PWK06_ControlNumber]
,''									AS [2400I_DTP01_DateTimeQualifier]
,''									AS [2400I_DTP02_FormatQualifier]
, CASE WHEN [SVC_LN_START_DT] = [SVC_LN_END_DT] THEN REPLACE([SVC_LN_END_DT],'-','')
	   WHEN ISNULL([SVC_LN_END_DT],'') = '' THEN REPLACE([SVC_LN_START_DT],'-','')
    ELSE CONCAT(REPLACE([SVC_LN_START_DT],'-',''),'-',REPLACE([SVC_LN_END_DT],'-','')) END AS	[2400I_DTP03_Date_1]								
--,SERV_END_DT											AS [2400I_DTP03_Date]
,''			AS [2400I_REF01_ServiceRefNumberQualifier]
,CASE WHEN LEN(CLMDTL.[CLM_LN_ID]) = 1 THEN '000' + CLMDTL.[CLM_LN_ID]
      WHEN LEN(CLMDTL.[CLM_LN_ID]) = 2 THEN '00' + CLMDTL.[CLM_LN_ID]
	  WHEN LEN(CLMDTL.[CLM_LN_ID]) = 3 THEN '0' + CLMDTL.[CLM_LN_ID]
END										--AS [2400I_REF02_ServiceRefNumber]
,''									AS [2410I_LIN02_DrugCodeType]
,''									AS [2410I_LIN03_NationalDrugCode]
,''									AS [2410I_CTP04_Quantity]
,''									AS [2410I_CTP05-01_Units]
,''									AS [2410I_REF01_ReferenceIDQualifier]
,''									AS [2410I_REF02_ReferenceIdentifier]
,''									AS [2400I_REF01_RepricedLineItemReference_Qualifier]
,''									AS [2400I_REF02_RepricedLineItemReferenceNumber]
,''									AS [2400I_REF01_AdjustedRepricedLineItemReference_Qualifier]
,''									AS [2400I_REF02_AdjustedRepricedLineItemReferenceNumber]
,''									AS [2400I_HCP01_PricingMethodology]
,''									AS [2400I_HCP02_RepricedAllowedAmt]
,''									AS [2400I_HCP03_RepricedSavingAmt]
,''									AS [2400I_HCP04_RepricingOrganziationIdentifier]
,''									AS [2400I_HCP05_RepricingPerDiem]
,''									AS [2400I_HCP06_APGPricingCode]
,''									AS [2400I_HCP07_APGPricingAmt]
,''									AS [2400I_HCP09_ServiceType]
,''									AS [2400I_HCP10_ApprovedServiceCode]
,''									AS [2400I_HCP11_RepricingUnits]
,''									AS [2400I_HCP12_RepricingQuantity]
,''									AS [2400I_HCP13_RejectReasonCode]
,''									AS [2400I_HCP14_PolicyComplianceCode]
,''									AS [2400I_HCP15_ExceptionCode]
,''									AS [2410I_REF01_ReferenceIDQualifier_2]
,''									AS [2410I_REF02_ReferenceIdentifier_2]
,''									AS [40-IFiller 01]
,''									AS [40I-Filler 02]
,''									AS [40I-Filler 03]
,''									AS [40I-Filler 04]
,''									AS [40I-Filler 05]
,''									AS [2420AI_NM101_ProviderRole]
,''									AS [2420AI_NM102_PersonIndicator]
,''									AS [2420AI_NM103_LastName]
,''									AS [2420AI_NM104_FirstName]
,''									AS [2420AI_NM105_MiddleName]
,''									AS [2420AI_NM107_Suffix]
,''									AS [2420AI_NM108_ProviderIdentifierQualifer]
,''									AS [2420AI_NM109_ProviderIdentifier]
,''									AS [2420AI_REF01_ProviderIdentifierQualifer_1]
,''									AS [2420AI_REF02_ProviderIdentifier_1]
,''									AS [2420AI_REF01_ProviderIdentifierQualifer_2]
,''									AS [2420AI_REF02_ProviderIdentifier_2]
,''									AS [2420AI_REF01_ProviderIdentifierQualifer_3]
,''									AS [2420AI_REF02_ProviderIdentifier_3]
,''									AS [2420BI_NM101_ProviderRole]
,''									AS [2420BI_NM102_PersonIndicator]
,''									AS [2420BI_NM103_LastName]
,''									AS [2420BI_NM104_FirstName]
,''									AS [2420BI_NM105_MiddleName]
,''									AS [2420BI_NM107_Suffix]
,''									AS [2420BI_NM108_ProviderIdentifierQualifer]
,''									AS [2420BI_NM109_ProviderIdentifier]
,''									AS [2420BI_REF01_ProviderIdentifierQualifer_1]
,''									AS [2420BI_REF02_ProviderIdentifier_1]
,''									AS [2420BI_REF01_ProviderIdentifierQualifer_2]
,''									AS [2420BI_REF02_ProviderIdentifier_2]
,''									AS [2420BI_REF01_ProviderIdentifierQualifer_3]
,''									AS [2420BI_REF02_ProviderIdentifier_3]
,''									AS [2420CI_NM101_ProviderRole]
,''									AS [2420CI_NM102_PersonIndicator]
,''									AS [2420CI_NM103_LastName]
,''									AS [2420CI_NM104_FirstName]
,''									AS [2420CI_NM105_MiddleName]
,''									AS [2420CI_NM107_Suffix]
,''									AS [2420CI_NM108_ProviderIdentifierQualifer]
,''									AS [2420CI_NM109_ProviderIdentifier]
,''									AS [2420CI_REF01_ProviderIdentifierQualifer_1]
,''									AS [2420CI_REF02_ProviderIdentifier_1]
,''									AS [2420CI_REF01_ProviderIdentifierQualifer_2]
,''									AS [2420CI_REF02_ProviderIdentifier_2]
,''									AS [2420CI_REF01_ProviderIdentifierQualifer_3]
,''									AS [2420CI_REF02_ProviderIdentifier_3]
,''									AS [2420DI_NM101_ProviderRole]
,''									AS [2420DI_NM102_PersonIndicator]
,''									AS [2420DI_NM103_LastName]
,''									AS [2420DI_NM104_FirstName]
,''									AS [2420DI_NM105_MiddleName]
,''									AS [2420DI_NM107_Suffix]
,''									AS [2420DI_NM108_ProviderIdentifierQualifer]
,''									AS [2420DI_NM109_ProviderIdentifier]
,''									AS [2420DI_REF01_ProviderIdentifierQualifer_1]
,''									AS [2420DI_REF02_ProviderIdentifier_1]
,''									AS [2420DI_REF01_ProviderIdentifierQualifer_2]
,''									AS [2420DI_REF02_ProviderIdentifier_2]
,''									AS [InNetworkIndicator]
,''									AS [ServiceLineContractID]
,''									AS [TPLPaidAmount]
,''									AS [2400I_NTE02_ServiceNote]
,''									AS [AccommodationCode]
,''									AS [40I-IFiller 11]
,''									AS [40I-IFiller 12]
,''									AS [40I-IFiller 13]
,''									AS [40I-IFiller 14]
,''									AS [40I-IFiller 15]
,''									AS [ServiceHealthPlan]
,''									AS [ServiceBenefitPlan]
,''									AS [ServiceAdministrativeCounty]
,''									AS [ServiceResidenceCounty]
,''									AS [ServiceEligibilityCode]
,''									AS [ServiceSubProgram1]
,''									AS [ServiceSubProgram2]
,''									AS [ServiceSubProgram3]
,''									AS [ServiceSubProgram4]
,''									AS [ServiceArrangementCode]
,''									AS [ServiceTribalCode]
,''									AS [FamilyPlanningService]
,''									AS [40I_MediaType]
,''									AS [Beneficiary Cost Sharing Status]
,''									AS [Out of Pocket Maximum]
,''									AS [Beneficiary Lock-In STATUS]
    FROM [OSS].dbo.[SDO_MDQO_MED_CLM_DTL_ADJUD] CLMDTL
	INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CLMDTL.CLM_ID = CSVP.ClaimID
	JOIN OSS.dbo.[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR ON CSVP.ClaimID = CLMHDR.CLM_ID
	LEFT JOIN OSS.dbo.[SDO_MDQO_CLM_LN_DIAG_CD_ADJUD] CLMDIAG ON CLMHDR.CLM_ID = CLMDIAG.CLM_ID AND CLMDTL.[CLM_LN_ID] = CLMDIAG.[CLM_LN_ID]
	LEFT JOIN WIPRO.[dbo].[ANES_2018] CLMANES ON CLMDTL.CPT_PROC_CD = CLMANES.ANES_CODE
	LEFT JOIN WIPRO.dbo.Service_Line_Dup_Processing SLDP ON CLMDTL.CLM_ID = SLDP.claim_id
						   AND CLMDTL.src_data_key = SLDP.sourcedatakey
						   AND SLDP.Is_Resubmission_Eligible = '1'
						   AND SLDP.Has_Been_Resubmitted = '0'
						   AND SLDP.claim_type = 'INS'
						   AND SLDP.Error_Code = '98325';

/* ----------------------------------------------------------------------------------
  INSERT 431I Records 
                                                                                   *
-----------------------------------------------------------------------------------*/ 

 TRUNCATE TABLE EDIFECS.staging.EE_CSV_431I_Rec_Detail;
 INSERT INTO EDIFECS.staging.EE_CSV_431I_Rec_Detail
	(
		[ClaimID]
		,[SourceDataKey]
		,[SourceDesc]
		,[CreateDate]
		,ClaimLineNumber
		,[2430_SVD01_COBPrimaryPayerID]
		,[2430_SVD02_COBServicePaidAmount]
		,[431_ClaimLineDisposition]
		,[2430_SVD03_01_ServiceCodeType]
		,[2430_SVD03_02_ServiceCode]
		,[2430_SVD03_03_ServiceModifier1]
		,[2430_SVD03_04_ServiceModifier2]
		,[2430_SVD03_05_ServiceModifier3]
		,[2430_SVD03_06_ServiceModifier4]
		,[2430_SVD03_07_ServiceCodeDescription]
		,[2430_SVD04_RevenueCode]
		,[2430_SVD05_Quantity]
		,[2430_SVD06_BundledLineNumber]
		,[2430_LineLevelDenial_1]
		,[2430_LineLevelDenial_2]
		,[2430_LineLevelDenial_3]
		,[2430_LineLevelDenial_4]
		,[2430_LineLevelDenial_5]
		,[2430_LineLevelDenial_6]
		,[2430_LineLevelDenial_7]
		,[2430_LineLevelDenial_8]
		,[2430_LineLevelDenial_9]
		,[2430_LineLevelDenial_10]
		,[2430_CAS01_ClaimAdjustmentGroup_1]
		,[2430_CAS02_ClaimAdjustmentReason_1]
		,[2430_CAS03_ClaimAdjustmentAmount_1]
		,[2430_CAS04_ClaimAdjustmentquantity_1]
		,[2430_CAS05_ClaimAdjustmentReason_1]
		,[2430_CAS06_ClaimAdjustmentAmount_1]
		,[2430_CAS07_ClaimAdjustmentquantity_1]
		,[2430_CAS08_ClaimAdjustmentReason_1]
		,[2430_CAS09_ClaimAdjustmentAmount_1]
		,[2430_CAS10_ClaimAdjustmentquantity_1]
		,[2430_CAS11_ClaimAdjustmentReason_1]
		,[2430_CAS12_ClaimAdjustmentAmount_1]
		,[2430_CAS13_ClaimAdjustmentquantity_1]
		,[2430_CAS14_ClaimAdjustmentReason_1]
		,[2430_CAS15_ClaimAdjustmentAmount_1]
		,[2430_CAS16_ClaimAdjustmentquantity_1]
		,[2430_CAS17_ClaimAdjustmentReason_1]
		,[2430_CAS18_ClaimAdjustmentAmount_1]
		,[2430_CAS19_ClaimAdjustmentquantity_1]
		,[2430_CAS01_ClaimAdjustmentGroup_2]
		,[2430_CAS02_ClaimAdjustmentReason_2]
		,[2430_CAS03_ClaimAdjustmentAmount_2]
		,[2430_CAS04_ClaimAdjustmentquantity_2]
		,[2430_CAS05_ClaimAdjustmentReason_2]
		,[2430_CAS06_ClaimAdjustmentAmount_2]
		,[2430_CAS07_ClaimAdjustmentquantity_2]
		,[2430_CAS08_ClaimAdjustmentReason_2]
		,[2430_CAS09_ClaimAdjustmentAmount_2]
		,[2430_CAS10_ClaimAdjustmentquantity_2]
		,[2430_CAS11_ClaimAdjustmentReason_2]
		,[2430_CAS12_ClaimAdjustmentAmount_2]
		,[2430_CAS13_ClaimAdjustmentquantity_2]
		,[2430_CAS14_ClaimAdjustmentReason_2]
		,[2430_CAS15_ClaimAdjustmentAmount_2]
		,[2430_CAS16_ClaimAdjustmentquantity_2]
		,[2430_CAS17_ClaimAdjustmentReason_2]
		,[2430_CAS18_ClaimAdjustmentAmount_2]
		,[2430_CAS19_ClaimAdjustmentquantity_2]
		,[2430_CAS01_ClaimAdjustmentGroup_3]
		,[2430_CAS02_ClaimAdjustmentReason_3]
		,[2430_CAS03_ClaimAdjustmentAmount_3]
		,[2430_CAS04_ClaimAdjustmentquantity_3]
		,[2430_CAS05_ClaimAdjustmentReason_3]
		,[2430_CAS06_ClaimAdjustmentAmount_3]
		,[2430_CAS07_ClaimAdjustmentquantity_3]
		,[2430_CAS08_ClaimAdjustmentReason_3]
		,[2430_CAS09_ClaimAdjustmentAmount_3]
		,[2430_CAS10_ClaimAdjustmentquantity_3]
		,[2430_CAS11_ClaimAdjustmentReason_3]
		,[2430_CAS12_ClaimAdjustmentAmount_3]
		,[2430_CAS13_ClaimAdjustmentquantity_3]
		,[2430_CAS14_ClaimAdjustmentReason_3]
		,[2430_CAS15_ClaimAdjustmentAmount_3]
		,[2430_CAS16_ClaimAdjustmentquantity_3]
		,[2430_CAS17_ClaimAdjustmentReason_3]
		,[2430_CAS18_ClaimAdjustmentAmount_3]
		,[2430_CAS19_ClaimAdjustmentquantity_3]
		,[2430_CAS01_ClaimAdjustmentGroup_4]
		,[2430_CAS02_ClaimAdjustmentReason_4]
		,[2430_CAS03_ClaimAdjustmentAmount_4]
		,[2430_CAS04_ClaimAdjustmentquantity_4]
		,[2430_CAS05_ClaimAdjustmentReason_4]
		,[2430_CAS06_ClaimAdjustmentAmount_4]
		,[2430_CAS07_ClaimAdjustmentquantity_4]
		,[2430_CAS08_ClaimAdjustmentReason_4]
		,[2430_CAS09_ClaimAdjustmentAmount_4]
		,[2430_CAS10_ClaimAdjustmentquantity_4]
		,[2430_CAS11_ClaimAdjustmentReason_4]
		,[2430_CAS12_ClaimAdjustmentAmount_4]
		,[2430_CAS13_ClaimAdjustmentquantity_4]
		,[2430_CAS14_ClaimAdjustmentReason_4]
		,[2430_CAS15_ClaimAdjustmentAmount_4]
		,[2430_CAS16_ClaimAdjustmentquantity_4]
		,[2430_CAS17_ClaimAdjustmentReason_4]
		,[2430_CAS18_ClaimAdjustmentAmount_4]
		,[2430_CAS19_ClaimAdjustmentquantity_4]
		,[2430_CAS01_ClaimAdjustmentGroup_5]
		,[2430_CAS02_ClaimAdjustmentReason_5]
		,[2430_CAS03_ClaimAdjustmentAmount_5]
		,[2430_CAS04_ClaimAdjustmentquantity_5]
		,[2430_CAS05_ClaimAdjustmentReason_5]
		,[2430_CAS06_ClaimAdjustmentAmount_5]
		,[2430_CAS07_ClaimAdjustmentquantity_5]
		,[2430_CAS08_ClaimAdjustmentReason_5]
		,[2430_CAS09_ClaimAdjustmentAmount_5]
		,[2430_CAS10_ClaimAdjustmentquantity_5]
		,[2430_CAS11_ClaimAdjustmentReason_5]
		,[2430_CAS12_ClaimAdjustmentAmount_5]
		,[2430_CAS13_ClaimAdjustmentquantity_5]
		,[2430_CAS14_ClaimAdjustmentReason_5]
		,[2430_CAS15_ClaimAdjustmentAmount_5]
		,[2430_CAS16_ClaimAdjustmentquantity_5]
		,[2430_CAS17_ClaimAdjustmentReason_5]
		,[2430_CAS18_ClaimAdjustmentAmount_5]
		,[2430_CAS19_ClaimAdjustmentquantity_5]
		,[2430_DTP01_DateTimeQualifier]
		,[2430_DTP02_DateTimeFormat]
		,[2430_DTP03_ServicePaidDate]
		,[2430_AMT01_AmountQualifier]
		,[2430_AMT02_PatientLiabilityAmount]
		,[431_Allowed_Amount]
		,[EOB_CODE]
		,[AccommodationCode]
		,[431_Filler_03]
		,[431_Filler_04]
		,[431_Filler_05]
		,[431_Filler_06]
		,[431_Filler_07]
		,[431_Filler_08]
		,[431_Filler_09]
		,[431_Filler_10]
		,[431_Filler_11]
		,[431_Filler_12]
		,[431_Filler_13]
		,[431_Filler_14]
		,[431_Filler_15]
		,[431_RecipientAidCategory]
	)
	SELECT 
		DISTINCT
		CLMDTL.CLM_ID					--[ClaimID]
		,CLMDTL.SRC_DATA_KEY			--[SourceDataKey]
		,CASE WHEN CLMDTL.SRC_DATA_KEY IN ('50', '30','40','210') THEN '' ELSE  CLMHDR.ENCNTR_SRC_VENDR_NM END AS SourceDesc				--SourceDesc
		,GETDATE()					--[CreateDate]
		,CLMDTL.CLM_LN_ID AS ClaimLineNumber --ClaimLineNumber	
		,CASE WHEN Contract_ID IS NOT NULL THEN Contract_ID ELSE '' END  --CLMDTL.OTH_PAYER1_PRIMEID		-- 2430_SVD01_COBPrimaryPayerID  - HPLAN - Fill 
		,CLMDTL.PD_AMT   --CLMDTL.OTH_PAYER1_PAID_AMT		-- 2430_SVD02_COBServicePaidAmount
		,CASE						--431_ClaimLineDisposition
			WHEN 1 = 1 THEN '1'		--Processed as Primary
			WHEN 1 = 1 THEN '2'		--Processed as Secondar
			WHEN 1 = 1 THEN '3'		--Processed as Tertiary
			WHEN 1 = 1 THEN '4'		--Denied
			WHEN 1 = 1 THEN '19'	--Processed as Primary, forwarded to additional Payers
			WHEN 1 = 1 THEN '20'	--Processed as Secondary, forwarded to additional Payers
			WHEN 1 = 1 THEN '21'	--Processed as Tertiary, forwarded to additional Payers
			WHEN 1 = 1 THEN '22'	--Processed as Reversal of Previous Payment
			WHEN 1 = 1 THEN '23'	--Not our claim, forwarded to additional Payers
			WHEN 1 = 1 THEN '25'	--Predetermination Pricing Only - No Payment
		END
		,CASE WHEN (CPT_PROC_CD <> '' OR CPT_PROC_CD IS NOT NULL) AND CLMDTL.REVNU_CD	NOT IN ('0024','0022','0023') THEN 'HC'
			  WHEN (CPT_PROC_CD <> '' OR CPT_PROC_CD IS NOT NULL) AND CLMDTL.REVNU_CD	IN ('0024','0022','0023') THEN 'HP'
				ELSE '' END -- Updated EDS-2188 'HC'	--2430_SVD03_01_ServiceCodeType
		,ISNULL(CLMDTL.CPT_PROC_CD,'')					--2430_SVD03_02_ServiceCode
		--,CLMDTL.PROC_MOD1				--2430_SVD03_03_ServiceModifier1
		--,CLMDTL.PROC_MOD2				--2430_SVD03_04_ServiceModifier2
		--,CLMDTL.PROC_MOD3				--2430_SVD03_05_ServiceModifier3
		--,CLMDTL.PROC_MOD4				--2430_SVD03_06_ServiceModifier4
	  ,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_1
     WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> ''  and isnull(CPT_MODFR_CD_1,'') = '' and ( isnull(CPT_MODFR_CD_2,'') <> '59' or isnull(CPT_MODFR_CD_3,'') <> '59' or isnull(CPT_MODFR_CD_4,'') <> '59') THEN '59'
	  ELSE CPT_MODFR_CD_1 END
										
																AS	[2400P_SV101-03_ServiceModifier1]
,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_2
     WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_2,'') = '' and isnull(CPT_MODFR_CD_1,'') <> ''))
						THEN '59'
	  ELSE CPT_MODFR_CD_2 END													
																AS	[2400P_SV101-04_ServiceModifier2]
,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_3
	  WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_3,'') = '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '')
	                     THEN '59'
	  else CPT_MODFR_CD_3 END												
																 AS	[2400P_SV101-05_ServiceModifier3]
,CASE WHEN SLDP.CLAIM_ID is NOT NULL and isnull(CPT_PROC_CD,'') <> '' and 
		  CPT_MODFR_CD_1 = '59' OR CPT_MODFR_CD_2 = '59' or CPT_MODFR_CD_3 = '59' or CPT_MODFR_CD_3 = '59'	or CPT_MODFR_CD_4 = '59'  THEN CPT_MODFR_CD_4
		WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_4,'') = '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '' and isnull(CPT_MODFR_CD_3,'') <> '')
	                     THEN '59'
		WHEN SLDP.CLAIM_ID is NOT NULL and (isnull(CPT_PROC_CD,'') <> '' and (isnull(CPT_MODFR_CD_4,'') <> '' and isnull(CPT_MODFR_CD_1,'') <> '') and isnull(CPT_MODFR_CD_2,'') <> '' and isnull(CPT_MODFR_CD_3,'') <> '')
	                     THEN '59'
	  ELSE CPT_MODFR_CD_4 END AS	[2400P_SV101-06_ServiceModifier4]												

		,LEFT(CLMDTL.CPT_PROC_CD_DESC,100)				--2430_SVD03_07_ServiceCodeDescription
		,CLMDTL.REVNU_CD							--2430_SVD04_RevenueCode (Yes on Institutional side and not on Professional) 
		,CLMDTL.SVC_UNITS  --CLMDTL.OTH_PAYER1_PAID_QTY		--2430_SVD05_Quantity
		,''    --CLMDTL.OTH_PAYER1_ADJ_BUNDLE	--2430_SVD06_BundledLineNumber
		,''							--2430_LineLevelDenial_1
		,''							--2430_LineLevelDenial_2
		,''							--2430_LineLevelDenial_3
		,''							--2430_LineLevelDenial_4
		,''							--2430_LineLevelDenial_5
		,''							--2430_LineLevelDenial_6
		,''							--2430_LineLevelDenial_7
		,''							--2430_LineLevelDenial_8
		,''							--2430_LineLevelDenial_9
		,''							--2430_LineLevelDenial_10
		-- REPLACED BELOW,CLMDTL.CLM_ADJ_GRP111			--2430_CAS01_ClaimAdjustmentGroup_1 - CO - Sequence 1 (CASE WHEN DISALW_AMT > 0 AND ADJ_GRP_CD IS NULL THEN 'CO' 
		                                                                                      --WHEN DISALW_AMT > 0 AND ADJ_GRP_CD = 'CO' THEN ADJ_GRP_CD
		,CASE WHEN DISALW_AMT > 0 AND ADJ_GRP_CD IS NULL THEN 'CO' 
			  WHEN DISALW_AMT > 0 AND ADJ_GRP_CD ='PR' THEN 'CO'
			  WHEN DISALW_AMT > 0 AND ADJ_GRP_CD ='OA' THEN 'CO'
			  WHEN DISALW_AMT > 0 AND ADJ_GRP_CD = 'CO' THEN ADJ_GRP_CD
			  WHEN DISALW_AMT > 0 AND ADJ_GRP_CD IS NOT NULL THEN ADJ_GRP_CD
			  ELSE NULL END AS CLM_ADJ_GRP111																			   
		-- replaced below,CLMDTL.CLM_ADJ_REASON111		--2430_CAS02_ClaimAdjustmentReason_1 - 45 - CASE WHEN DISALW_AMT > 0 AND ADJ_RSN_CD IS NULL THEN '45' 
		                                                                       --WHEN DISALW_AMT > 0 AND ADJ_RSN_CD IS NOT NULL THEN ADJ_RSN_CD 
																			   --ELSE ''
		,CASE WHEN DISALW_AMT > 0 AND ADJ_RSN_CD IS NULL THEN '45' 
			  WHEN DISALW_AMT > 0 AND ADJ_GRP_CD ='PR' THEN '45'
			  WHEN DISALW_AMT > 0 AND ADJ_RSN_CD IS NOT NULL THEN ADJ_RSN_CD 
			  ELSE NULL END AS CLM_ADJ_REASON111
		-- REPLACED BELOW,CLMDTL.CLM_ADJ_AMT111			--2430_CAS03_ClaimAdjustmentAmount_1 - REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT]) - CASE WHEN DISALW_AMT > 0 THEN DISALW_AMT ELSE ''
		                                                                                                                                           --CASE WHEN DISALW_AMT > 0 AND REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT]) <> DISALW_AMT
	    ,CASE WHEN DISALW_AMT > 0 AND REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT]) <> DISALW_AMT
					THEN REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT])
			  WHEN DISALW_AMT > 0 THEN DISALW_AMT
			ELSE NULL END AS 	CLM_ADJ_AMT111																																     
		,''			--2430_CAS04_ClaimAdjustmentquantity_1
		,''		--2430_CAS05_ClaimAdjustmentReason_1 - Sequence 2 
		,''		--2430_CAS06_ClaimAdjustmentAmount_1
		,''			--2430_CAS07_ClaimAdjustmentquantity_1
		,''		--2430_CAS08_ClaimAdjustmentReason_1- Sequence 3 
		,''			--2430_CAS09_ClaimAdjustmentAmount_1
		,''			--2430_CAS10_ClaimAdjustmentquantity_1
		,''		--2430_CAS11_ClaimAdjustmentReason_1 - Sequence 4
		,''		--2430_CAS12_ClaimAdjustmentAmount_1
		,''		--2430_CAS13_ClaimAdjustmentquantity_1
		,''		--2430_CAS14_ClaimAdjustmentReason_1 - Sequence 5 
		,''			--2430_CAS15_ClaimAdjustmentAmount_1
		,''		--2430_CAS16_ClaimAdjustmentquantity_1
		,''		--2430_CAS17_ClaimAdjustmentReason_1 - Sequence  6
		,''	--2430_CAS18_ClaimAdjustmentAmount_1
		,''		--2430_CAS19_ClaimAdjustmentquantity_1
		-- REPLACE BELOW ,CLMDTL.CLM_ADJ_GRP12			--2430_CAS01_ClaimAdjustmentGroup_2 - OA 
		,CASE WHEN ADJ_GRP_CD = 'OA' AND DISALW_AMT = '0' THEN ADJ_GRP_CD ELSE '' END AS CLM_ADJ_GRP12
		--REPLACED WITH BELOW ,CLMDTL.CLM_ADJ_REASON121		--2430_CAS02_ClaimAdjustmentReason_2 - Sequence 1 
		,CASE WHEN ADJ_GRP_CD = 'OA' AND DISALW_AMT = '0' THEN ADJ_RSN_CD ELSE '' END AS CLM_ADJ_REASON121
		--replaced with below,CLMDTL.CLM_ADJ_AMT121			--2430_CAS03_ClaimAdjustmentAmount_2 -  REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT])
		,CASE WHEN ADJ_GRP_CD = 'OA' AND DISALW_AMT = '0' 
		      THEN REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT]) 
			  --WHEN ADJ_GRP_CD = 'OA' AND DISALW_AMT > 0 THEN DISALW_AMT
			  ELSE NULL END AS CLM_ADJ_AMT121
		,''			--2430_CAS04_ClaimAdjustmentquantity_2
		,''		--2430_CAS05_ClaimAdjustmentReason_2 - Sequence 2
		,''		--2430_CAS06_ClaimAdjustmentAmount_2
		,''		--2430_CAS07_ClaimAdjustmentquantity_2
		,''		--2430_CAS08_ClaimAdjustmentReason_2 - Sequence 3
		,''		--2430_CAS09_ClaimAdjustmentAmount_2
		,''			--2430_CAS10_ClaimAdjustmentquantity_2
		,''		--2430_CAS11_ClaimAdjustmentReason_2 - Sequence 4
		,''			--2430_CAS12_ClaimAdjustmentAmount_2
		,''			--2430_CAS13_ClaimAdjustmentquantity_2
		,''		--2430_CAS14_ClaimAdjustmentReason_2 - Sequence 5
		,''			--2430_CAS15_ClaimAdjustmentAmount_2
		,''			--2430_CAS16_ClaimAdjustmentquantity_2
		,''		--2430_CAS17_ClaimAdjustmentReason_2 - Sequence 6
		,''			--2430_CAS18_ClaimAdjustmentAmount_2
		,''			--2430_CAS19_ClaimAdjustmentquantity_2
		,CASE WHEN ( [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT]) > 0 THEN 'PR' ELSE '' END AS CLM_ADJ_GRP13			--2430_CAS01_ClaimAdjustmentGroup_3 - PR - 
		,CASE WHEN COPAY_AMT > 0 THEN '3' --ELSE NULL END AS CLM_ADJ_REASON131		--2430_CAS02_ClaimAdjustmentReason_3 - 3  - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		      WHEN COPAY_AMT = 0 AND DEDUCT_AMT > 0 THEN '1' 
			  WHEN COPAY_AMT = 0 AND DEDUCT_AMT = 0 AND COINS_AMT > 0  THEN '2' 
			  ELSE NULL END AS CLM_ADJ_REASON131
		,CASE WHEN COPAY_AMT > 0 THEN COPAY_AMT 
			  WHEN COPAY_AMT = 0 AND DEDUCT_AMT > 0 THEN DEDUCT_AMT
			  WHEN COPAY_AMT = 0 AND DEDUCT_AMT = 0 AND COINS_AMT > 0  THEN COINS_AMT
			  ELSE NULL END AS CLM_ADJ_AMT131			--2430_CAS03_ClaimAdjustmentAmount_3 - [COPAY_AMT]
		,''			--2430_CAS04_ClaimAdjustmentquantity_3
		,CASE WHEN COPAY_AMT > 0 AND DEDUCT_AMT > 0 THEN '1' 
		      WHEN COPAY_AMT > 0 AND DEDUCT_AMT = 0 AND COINS_AMT > 0  THEN '2' 
			  WHEN COPAY_AMT = 0 AND  DEDUCT_AMT > 0 AND COINS_AMT > 0  THEN '2' 
		    ELSE NULL END AS CLM_ADJ_REASON132		--2430_CAS05_ClaimAdjustmentReason_3 - 1 - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		,CASE WHEN COPAY_AMT > 0 AND DEDUCT_AMT > 0 THEN DEDUCT_AMT 
		      WHEN COPAY_AMT > 0 AND DEDUCT_AMT = 0 AND COINS_AMT > 0 THEN COINS_AMT
			  WHEN COPAY_AMT = 0 AND  DEDUCT_AMT > 0 AND COINS_AMT > 0  THEN COINS_AMT
		      ELSE NULL END  AS CLM_ADJ_AMT132			--2430_CAS06_ClaimAdjustmentAmount_3 - [DEDUCT_AMT]
		,''			--2430_CAS07_ClaimAdjustmentquantity_3 - QUANTITY NEEDED
		,CASE --WHEN COINS_AMT > 0 THEN '2' 
		      WHEN COPAY_AMT > 0 AND DEDUCT_AMT > 0 AND COINS_AMT > 0 THEN '2' 
			  ELSE NULL END AS CLM_ADJ_REASON133		--2430_CAS08_ClaimAdjustmentReason_3 - 2  - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		,CASE --WHEN COINS_AMT > 0 THEN COINS_AMT 
		      WHEN COPAY_AMT > 0 AND DEDUCT_AMT > 0 AND COINS_AMT > 0 THEN COINS_AMT
		     ELSE NULL END AS CLM_ADJ_AMT133
		,''			--2430_CAS10_ClaimAdjustmentquantity_3
		,''		--2430_CAS11_ClaimAdjustmentReason_3 - PR - Sequence 4 - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		,''			--2430_CAS12_ClaimAdjustmentAmount_3
		,''			--2430_CAS13_ClaimAdjustmentquantity_3
		,''		--2430_CAS14_ClaimAdjustmentReason_3- PR - Sequence 5 - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		,''			--2430_CAS15_ClaimAdjustmentAmount_3
		,''			--2430_CAS16_ClaimAdjustmentquantity_3
		,''		--2430_CAS17_ClaimAdjustmentReason_3 - PR - Sequence 6 - (CLM_ADJ_GRP111 <> 'CO' AND CLM_ADJ_REASON111 <> '24')
		,''			--2430_CAS18_ClaimAdjustmentAmount_3
		,''			--2430_CAS19_ClaimAdjustmentquantity_3
		,CASE WHEN ADJ_GRP_CD = 'PI' AND DISALW_AMT = '0' THEN ADJ_GRP_CD ELSE NULL END  AS CLM_ADJ_GRP141			--2430_CAS01_ClaimAdjustmentGroup_4 - PI
		,CASE WHEN ADJ_GRP_CD = 'PI' AND DISALW_AMT = '0' THEN ADJ_RSN_CD ELSE NULL END AS CLM_ADJ_REASON141		--2430_CAS02_ClaimAdjustmentReason_4 - Sequence 1 
		,CASE WHEN ADJ_GRP_CD = 'PI' AND DISALW_AMT = '0' THEN REQD_AMT - (PD_AMT + [DEDUCT_AMT] + [COINS_AMT] + [COPAY_AMT] +  [COB_AMT]) 
		      WHEN ADJ_GRP_CD = 'PI' AND DISALW_AMT = '0'  THEN DISALW_AMT  
		      ELSE NULL END AS CLM_ADJ_AMT141			--2430_CAS03_ClaimAdjustmentAmount_4 
		,''		--2430_CAS04_ClaimAdjustmentquantity_4
		,''		--2430_CAS05_ClaimAdjustmentReason_4 - Sequence 2
		,''		--2430_CAS06_ClaimAdjustmentAmount_4
		,''		--2430_CAS07_ClaimAdjustmentquantity_4
		,''		--2430_CAS08_ClaimAdjustmentReason_4 - Sequence 3
		,''		--2430_CAS09_ClaimAdjustmentAmount_4
		,''		--2430_CAS10_ClaimAdjustmentquantity_4
		,''		--2430_CAS11_ClaimAdjustmentReason_4 - Sequence 4 
		,''		--2430_CAS12_ClaimAdjustmentAmount_4
		,''		--2430_CAS13_ClaimAdjustmentquantity_4
		,''		--2430_CAS14_ClaimAdjustmentReason_4 - Sequence 5 
		,''		--2430_CAS15_ClaimAdjustmentAmount_4
		,''		--2430_CAS16_ClaimAdjustmentquantity_4
		,''		--2430_CAS17_ClaimAdjustmentReason_4 - Sequence 6
		,''		--2430_CAS18_ClaimAdjustmentAmount_4
		,''		--2430_CAS19_ClaimAdjustmentquantity_4
		,''		--2430_CAS01_ClaimAdjustmentGroup_5
		,''		--2430_CAS02_ClaimAdjustmentReason_5
		,''		--2430_CAS03_ClaimAdjustmentAmount_5
		,''		--2430_CAS04_ClaimAdjustmentquantity_5
		,''		--2430_CAS05_ClaimAdjustmentReason_5
		,''		--2430_CAS06_ClaimAdjustmentAmount_5
		,''		--2430_CAS07_ClaimAdjustmentquantity_5
		,''		--2430_CAS08_ClaimAdjustmentReason_5
		,''		--2430_CAS09_ClaimAdjustmentAmount_5
		,''		--2430_CAS10_ClaimAdjustmentquantity_5
		,''		--2430_CAS11_ClaimAdjustmentReason_5
		,''		--2430_CAS12_ClaimAdjustmentAmount_5
		,''		--2430_CAS13_ClaimAdjustmentquantity_5
		,''		--2430_CAS14_ClaimAdjustmentReason_5
		,''		--2430_CAS15_ClaimAdjustmentAmount_5
		,''		--2430_CAS16_ClaimAdjustmentquantity_5
		,''		--2430_CAS17_ClaimAdjustmentReason_5
		,''		--2430_CAS18_ClaimAdjustmentAmount_5
		,''		--2430_CAS19_ClaimAdjustmentquantity_5
		,''						--2430_DTP01_DateTimeQualifier
		,''						--2430_DTP02_DateTimeFormat
		,REPLACE(CLMHDR.PD_DT,'-','') --CLMDTL.OTH_PAYER1_ADJ_DT			--2430_DTP03_ServicePaidDate  ONLY FOR PROFESSIONAL CLAIMS
		,''						--2430_AMT01_AmountQualifier
		,'' --B.PATIENT_EST_AMT_DUE		--2430_AMT02_PatientLiabilityAmount  ONLY FOR PROFESSIONAL CLAIMS
		,'' 						--431_Allowed_Amount
		,''							--EOB_CODE
		,''							--AccommodationCode
		,''							--431_Filler_03
		,''							--431_Filler_04
		,''							--431_Filler_05
		,''							--431_Filler_06
		,''							--431_Filler_07
		,''							--431_Filler_08
		,''							--431_Filler_09
		,''							--431_Filler_10
		,''							--431_Filler_11
		,''							--431_Filler_12
		,''							--431_Filler_13
		,''							--431_Filler_14
		,''							--431_Filler_15
		,''							--431_RecipientAidCategory
FROM OSS.dbo.[SDO_MDQO_MED_CLM_DTL_ADJUD] CLMDTL
INNER JOIN EDIFECS.staging.EE_CSV_100I_Rec_Header CSVP ON CLMDTL.CLM_ID = CSVP.ClaimID
LEFT JOIN OSS.dbo.[SDO_MDQO_MED_CLM_LN_PROV_DENL_LANG] B ON CLMDTL.CLM_ID = B.CLM_ID AND RTRIM(LTRIM(CLMDTL.CLM_LN_ID)) = RTRIM(LTRIM(B.CLM_LN_ID)) AND B.EOB_SEQ = '1'
LEFT JOIN  OSS.dbo.[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR ON CLMDTL.CLM_ID = CLMHDR.CLM_ID
LEFT JOIN WIPRO.dbo.Service_Line_Dup_Processing SLDP ON CLMDTL.CLM_ID = SLDP.claim_id
						   AND CLMDTL.src_data_key = SLDP.sourcedatakey
						   AND SLDP.Is_Resubmission_Eligible = '1'
						   AND SLDP.Has_Been_Resubmitted = '0'
						   AND SLDP.claim_type = 'INS' 
						   AND SLDP.Error_Code = '98325';

/*----------------------------------------------------------------------------------
        Retraction Process Overlays 
-----------------------------------------------------------------------------------*/

IF @IsRetraction = 1 
   BEGIN 
	UPDATE CSVI100
	 SET 
		 Chart_Review_Data	= 'TRUE',
		 [PS_Custom_Field_2]	= RII.CMSICN,
		 [100_Filler_17]	= RII.EncounterID   
	 FROM EDIFECS.staging.EE_CSV_100I_Rec_Header CSVI100
	 INNER JOIN WIPRO.dbo.Retraction_Input_Interim RII ON CSVI100.CLAIMID = RII.CLAIMID;

	 UPDATE CSVI20
	 SET 
		 [2300I_CLM01_ClaimNumber] = RII.Retraction_Unique_ID,
		 [2300I_REF02_ClaimReferenceNumber_3] = RII.ENCOUNTERID,
		 [2300I_REF02_ClaimReferenceNumber_6] = RII.CLAIMID, 
		 [2300I_REF02_ClaimReferenceNumber_8] = CASE WHEN RETRACTION_TYPE IN ('CLM_DELETE','CR_DELETE') THEN 'DEL' 
		                                             WHEN RETRACTION_TYPE IN ('CLM_VOID','CR_VOID') THEN 'EA'
												     ELSE [2300I_REF02_ClaimReferenceNumber_8] END,
		 [2300I_CLM05-03_ClaimFrequencyCode]  = CASE WHEN RETRACTION_TYPE IN ('CLM_DELETE','CR_DELETE') THEN '1' 
		                                            WHEN RETRACTION_TYPE IN ('CLM_VOID','CR_VOID') THEN '8'
												ELSE '' END,
		 [2300I_HI01-01_PrinDXType]           = CASE WHEN ISNULL([2300I_HI01-01_PrinDXType],'') = '' THEN 'ABK' ELSE [2300I_HI01-01_PrinDXType] END,
		 [2300I_HI01-02_PrincipalDXCode]      = CASE WHEN ISNULL([2300I_HI01-02_PrincipalDXCode],'') ='' THEN RII.DXCODE ELSE [2300I_HI01-02_PrincipalDXCode] END, 
		 [2300I_HI01-09_DXPOA_1]              = CASE WHEN ISNULL([2300I_HI01-09_DXPOA_1],'') = '' THEN 'U' ELSE [2300I_HI01-09_DXPOA_1] END
	 FROM EDIFECS.staging.EE_CSV_20I_Rec_Header CSVI20
	 INNER JOIN WIPRO.dbo.Retraction_Input_Interim RII ON CSVI20.CLAIMID = RII.CLAIMID;

	END;


/********************************************************************************************************************************************************************
  END PROCESS SYSLOG 
*********************************************************************************************************************************************************************/
SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EDIFECS.staging.EE_CSV_100I_Rec_Header)	    

	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @TOTAL_RECORDS    
		,ENTRYDT = GETDATE()    
	WHERE PROC_NAME = 'EDIFECS.dbo.OSS_INST_SDO_to_CSV_MAP'    
			AND END_DT IS NULL;

/********************************************************************************************************************************************************************
END PROCESS 
*********************************************************************************************************************************************************************/