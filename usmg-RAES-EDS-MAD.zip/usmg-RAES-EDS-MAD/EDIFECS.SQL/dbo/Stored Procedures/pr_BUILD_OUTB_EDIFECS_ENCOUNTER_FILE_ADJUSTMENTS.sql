﻿ 
Create PROCEDURE [dbo].[pr_BUILD_OUTB_EDIFECS_ENCOUNTER_FILE_ADJUSTMENTS] 
(	@LOB CHAR(10)  --Valid Values (MMAI,MOA) 
	,@CLAIM_TYPE CHAR(1) --Valid Values (I,P) 
	,@SOURCEDATAKEY INT  
	,@SOURCEDESC VARCHAR(60) 
	,@JOBID INT = 1	 
	,@ExecutionMode		CHAR(1) = 'M' 
	,@exclusionmode		char(1) = 'R' 
	,@LOBCODE VARCHAR(15) = ' ' 
	) 
 
AS 
/*************************************************************************************************** 
** CREATE DATE: 09/2014 
** 
** AUTHOR: LOYAL RICKS  
** 
** DESCRIPTION: PROCEDURE WILL EXECUTE REQUIRD STEPS FOR COMPILING WIPRO CLAIM SUBMISSIONS. 
**               
Modification History 
==================== 
Date			Who				Description 
----------------------------------------------------------------------------------------------------- 
08/08/16		Loyal Ricks		Initial WIPRO Implementation for Encounter submissions	
03/20/2018		Scott Waller	TETDM-1760 The code that collects claims is getting multiple records for the same claimid/sourcedesc/lob/hicfa
								So even though it gets 50000, there is only a small number of distinct claims (like hundreds to low thousands)
02/24/2021      Aaron Ridley	TETDM-2359 Adjustment process execution for Encounters
*****************************************************************************************************/ 
						--DECLARE VARIABLES 
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM  
			DECLARE 
			 
			@TOTAL_RECORDS INT 
		 
 
 
 
								 
-- Run controls 
			  
					INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG 
							(PROC_NAME 
							,STEP 
							,START_DT 
							,END_DT 
							,RUN_MINUTES 
							,TOTAL_RECORDS 
							,ENTRYDT 
							) 
					VALUES('EDIFECS.dbo.pr_BUILD_OUTB_EDIFECS_Encounter_FILE' + '-' + rtrim(@LOB) + '-' + RTRIM(@SOURCEDESC) + '-'+ rtrim(@CLAIM_TYPE) 
							,'1' 
							,GETDATE() 
							,NULL 
							,NULL 
							,0 
							,GETDATE() 
							) 
 
 
					IF @CLAIM_TYPE = 'P'  
						BEGIN  
							--TETDM-1760 that last @parameter value is incorrect, it needs to be @exclusionmode
							--EXECUTE pr_BUILD_OUTB_PROF_ENCOUNTER_FILE @LOB,@LOBCODE,@JOBID,@SOURCEDESC,@ExecutionMode--,@exclusionmode,@LOBCODE	
							EXECUTE EDIFECS.dbo.pr_BUILD_OUTB_PROF_ENCOUNTER_FILE @LOB,@LOBCODE,@JOBID,@SOURCEDESC,'R'
						END 
 
					IF  @CLAIM_TYPE = 'I'  
						BEGIN 
							--TETDM-1760 that last @parameter value is incorrect, it needs to be @exclusionmode
							--EXECUTE pr_BUILD_OUTB_INST_ENCOUNTER_FILE @LOB,@LOBCODE,@JOBID,@SOURCEDESC,@ExecutionMode
							EXECUTE EDIFECS.dbo.pr_BUILD_OUTB_INST_ENCOUNTER_FILE @LOB,@LOBCODE,@JOBID,@SOURCEDESC,'R'
						END 
				 
					 
 
				--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM 
						IF @CLAIM_TYPE = 'P' 
							BEGIN 	  
									SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_PROF_HEADER) 
									SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_PROF_DETAIL) 
							END 
						IF @CLAIM_TYPE = 'I' 
							BEGIN 	  
									SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_INST_HEADER) 
									SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_INST_DETAIL) 
							END		 
		----HRP_CLAIM_FILE Update Run Controls 
				 
						UPDATE WIPRO.dbo.EXT_SYS_RUNLOG 
						SET END_DT = GETDATE()	 
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()) 
							,TOTAL_RECORDS = @TOTAL_RECORDS 
							,ENTRYDT = GETDATE() 
						WHERE PROC_NAME = 'EDIFECS.dbo.pr_BUILD_OUTB_EDIFECS_Encounter_FILE' + '-' + rtrim(@LOB) + '-' + RTRIM(@SOURCEDESC) + '-'+ rtrim(@CLAIM_TYPE) 
										and END_DT is null
