﻿
CREATE PROCEDURE [dbo].[pr_EDIFECS_INST_CSV_100I_150I_20I_310I_Header]
( @LOB CHAR(10),
@LOBCODE VARCHAR(15),
@JOBID INT
)
AS
/***************************************************************************************************
** CREATE DATE: 02/18/2020
**
** AUTHOR: Aaron Ridley 
**
** DESCRIPTION: PROCEDURE WILL POPULATE CSV HEADER TABLE (100I,150I,310I,20I)
**              UTILIZING THE OUTB_INST_HEADER AS SOURCE
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
02/18/20		Aaron Ridley	Version 1
08/25/2020      Aaron Ridley    TETDM-2337 Added logic to accommodate MMP file naming convention
02/24/2020      Aaron Ridley    TETDM-2359 Added logic to 20P to populate previous claimid  
04/05/2022		Henry Faust		RETM-49 update logiis from Jobid 3000 to Claim Indicator in 7,8
04/06/2022		Henry Faust		RETM-51 Remove duplicate 100 records
05/25/2022		Scott Waller	RETM-?? Correct the statement for 100 record, Filler16 column value.

*****************************************************************************************************/	
			DECLARE	@TOTAL_RECORDS INT
		
			BEGIN TRANSACTION 
					INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_EDIFECS_INST_CSV_100I_150I_20I_310I_Header'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					if @@ERROR <> 0
							begin
								rollback 
							end
				commit
			

/*---------------------------------------------------------------------*/
/* POPULATE 100 TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_100I_Rec_Header_Archive 
SELECT *, getdate()  FROM dbo.EE_CSV_100I_Rec_Header

TRUNCATE TABLE dbo.EE_CSV_100I_Rec_Header

INSERT INTO EE_CSV_100I_Rec_Header
 SELECT           --RETM-51
      oph.claim_id    --    ClaimID
     ,oph.SOURCEDATAKEY --@SourceDataKey   --    SourceDataKey
      ,CASE WHEN SYSTEM_SOURCE IN ('50','30') THEN '' ELSE SYSTEM_SOURCE END   --    SourceDesc
      ,getdate()   --    CreateDate
    ,''     --    ClaimStatus
    ,oph.CLAIM_TYPE     --    ClaimType
	,CASE WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN 'CHSMMPCARECLP'
	      WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN 'CHSMMPCAIDCLP'
	 ELSE 'CHSMAOCLP'    
	 END --    SenderID
    ,CASE WHEN @LOBCODE  = 'C54581391' THEN 'DTXT11'
	      ELSE 'ENC0159' 
	 END    --    ReceiverID
    ,''     --    OriginatorID
    ,oph.cms_contract_num     --    ContractID
    ,'EDSCMS'     --    DestinationID
    ,''     --    HistoricalIndicator
    ,''     --    HistoricalDispositionStatus
    ,CASE WHEN @JOBID BETWEEN 3000 AND 3062 THEN ocs.CMS_ICN ELSE '' END--''     --    HistoricalEncounterICN
    ,''     --    HistoricalEncounterID
    ,CASE WHEN oph.OPTIONAL_REPORTING_IND1  ='PAPER' THEN 'PAPER' ELSE '' END   --    Paper
    ,CASE WHEN oph.CLAIM_TYPE = 'E' THEN 'TRUE' ELSE 'FALSE' END    --  AARON  DME 
    ,''     --    AdministrativeDenial
    ,''     --    ChartReviewData
    ,oph.SOURCEDATAKEY     --    Source
    ,CASE WHEN @JOBID BETWEEN 3000 AND 3062 THEN 'Y' ELSE 'N' END -- Used as flag to identify if CSV for adjustments should be used over EDIFECS enrichment     --    Filler
    ,''     --    TraceNumber
    ,''     --    NM1010A_SubmitterEntityRole
    ,''     --    NM1020A_SubmitterPersonIndicator
    ,''     --    NM1030A_SubmitterLastName
    ,''     --    NM1080A_SubmitterIdentifierQualifier
    ,''     --    NM1090A_SubmitterIdentifier
    ,''     --    PER010A_01_SubmitterContactIdentifier
    ,''     --    PER020A_01_SubmitterContactName
    ,''     --    PER030A_01_SubmitterContactQualifier1 TE,EM,FX
    ,''     --    PER040A_01_SubmitterContact1
    ,''     --    PER050A_01_SubmitterContacQualifier2 TE,EM,FX, EX
    ,''     --    PER060A_01_SubmitterContact2
    ,''     --    NM1010B_ReceiverEntityRole
    ,''     --    NM1020B_PersonIndicator
    ,''     --    NM1030B_ReceiverName
    ,''     --    NM1080B_ReceiverIdentifierQualifier
    ,''     --    NM1090B_ReceiverIdentifier
    ,''     --    PRV01A_BillingProviderCode
    ,''     --    PRV02A_BillingProviderCodeQualifier
    ,oph.BILL_PROV_TAXONOMY_CD    --    PRV03A_BillingProviderTaxonomy 
    ,''     --    NM101AA_BillingProviderRole
    ,''     --    NM102AA_BillingPersonIndicator
    ,CASE WHEN oph.BILL_PROV_FNAME =''  AND BILL_PROV_LNAME ='' THEN [BILL_PROV_ORG_NAME] 
	      WHEN oph.BILL_PROV_FNAME ='' AND  [BILL_PROV_ORG_NAME] ='' THEN BILL_PROV_LNAME
		  ELSE oph.BILL_PROV_LNAME  END     --    NM103AA_BillingOrg_LastName
    ,oph.BILL_PROV_FNAME     --    NM104AA_BillingFirstName
    ,''     --    NM105AA_BillingMiddleName
    ,''     --    NM107AA_BillingSuffix
    ,''     --    NM108AA_BillingProviderIdentifierQualifier
    ,CASE WHEN BILL_PROV_NPI <>'' THEN  BILL_PROV_NPI ELSE BILL_PROV_GRP_NPI  END    --    NM109AA_BillingProviderIdentifier - Aaron (Set to blank for atypical providers) 
    ,oph.BILL_PROV_ADDR1     --    N301AA_BillingAddressLine1
    ,oph.BILL_PROV_ADDR2     --    N302AA_BillingAddressLine2
    ,oph.BILL_PROV_CITY     --    N401AA_BillingCity
    ,oph.BILL_PROV_STATE     --    N402AA_BillingState
    ,oph.BILL_PROV_ZIP + oph.BILL_PROV_ZIP4     --    N403AA_BillingPostalCode
    ,''     --    N404AA_BillingCountry
    ,''     --    REF01AA_BillingProviderIdentifierQualifier01
    ,oph.BILL_PROV_TAX_ID     --    REF02AA_BillingProviderIdentifier01 --Aaron (Set to blank for Atypical providers) 
    ,''     --    REF01AA_BillingProviderIdentifierQualifier02
    ,''     --    REF02AA_BillingProviderIdentifier02
    ,''     --    BillingProviderSpecialityAA
    ,''     --    BillingProviderTypeAA
    ,''     --    PER0AA1_BillingProviderContactFunction_1
    ,''     --    PER02AA_BillingProviderContactName_1
    ,''     --    PER03AA_BillingProviderCommunicationNumberQualifier_1
    ,''     --    PER04AA_BillingProviderCommunicationNumber_1
    ,''     --    PER05AA_BillingProviderCommunicatioNumberQualifier_1
    ,''     --    PER06AA_BillingProviderCommunicationNumber_1
    ,''     --    PER07AA_BillingProviderCommunicatioNumberQualifier_1
    ,''     --    PER08AA_BillingProviderCommunicationNumber_1
    ,''     --    PER01AA_BillingProviderContactFunction_2
    ,''     --    PER02AA_BillingProviderContactName_2
    ,''     --    PER03AA_CommunicatioNumberQualifier_2
    ,''     --    PER04AA_BillingProviderCommunicationNumber_2
    ,''     --    PER05AA_BillingProviderCommunicatioNumberQualifier_2
    ,''     --    PER06AA_BillingProviderCommunicationNumber_2
    ,''     --    PER07AA_BillingProviderCommunicatioNumberQualifier_2
    ,''     --    PER08AA_BillingProviderCommunicationNumber_2
    ,''     --    NM101AB_PayToProviderRole
    ,''     --    NM102AB_PayToPersonIndicator
    ,''     --    N301AB_PayToAddressLine1
    ,''     --    N302AB_PayToAddressLine2
    ,''     --    N401AB_PayToCity
    ,''     --    N402AB_PayToState
    ,''     --    N403AB_PayToPostalCode
    ,''     --    N404AB_PayToCountry
    ,''     --    NM101AC_PayToPlanOrganizationRole
    ,''     --    NM102AC_PayToPlanPersonIndicator
    ,''     --    NM103AC_PayToPlanName
    ,''     --    NM108AC_PayToPlanOrganizationIDQualifier
    ,''     --    NM109AC_PayToPlanOrganizationIdentifier
    ,''     --    N301AC_PayToPlanAddressLine1
    ,''     --    N302AC_PayToPlanAddressLine2
    ,''     --    N401AC_PayToPlanCity
    ,''     --    N402AC_PayToPlanState
    ,''     --    N403AC_PayToPlanPostalCode
    ,''     --    N404AC_PayToPlanCountry
    ,''     --    REF01AC_OrganizationIDQualifier_1
    ,''     --    REF02AC_OrganizationIdentifier_1
    ,''     --    REF01AC_OrganizationIDQualifier_2
    ,''     --    REF02AC_OrganizationIdentifier_2
    ,''     --    ClaimEncounterCleanup
    ,CASE WHEN BILL_PROV_NPI IN ('1999999976','1999999984','1999999992') THEN 'Y'
		  WHEN BILL_PROV_TAX_ID IN ('1999999997','1999999998','1999999999') THEN 'Y'
		  ELSE 'N'
	 END      --    AtypicalProviderFlag  -- Update (Need criteria to identify default NPI - NPI or TaxID) 'Y' DDRC (048/052) 19999
    ,''     --    SupplementalInterimFlag
    ,''     --    InterimLateChargeFlag
    ,''     --    IssuerIdentifier
    ,''     --    Filler05
    ,''     --    R_MonetaryAmountChangeFlag
    ,''     --    NM1040ASubmitterFirstName
    ,''     --    BillingCountyCode
    ,''     --    Filler06
    ,''     --    ClaimInputMethod
    ,''     --    RehabFlag
    ,''     --    PSCustomField01
    ,''     --    VoidReason
    ,''     --    PSCustomField02
    ,''     --    Filler12
    ,''     --    Filler13
    ,CASE WHEN SYSTEM_SOURCE IN ('50','30') THEN '' ELSE SYSTEM_SOURCE END -- EDIFECS suggested move from Filler1''     --    Filler14
    ,''     --    Filler15		 
--     RETM-49
--	,CASE WHEN @JOBID BETWEEN 3000 AND 3062 THEN 'TRUE' ELSE 'FALSE' END     --    Filler16

-- RETM-??	Scott Waller putting single quotes around the 7 and the 8 in the IN statement.  
--			WIthout, it is assuming INT values, and we have some CLM_IND values that are alphabetical.
--	,CASE WHEN oph.clm_ind in (7,8) THEN 'TRUE' ELSE 'FALSE' END     --    Filler16
	,CASE WHEN oph.clm_ind in ('7','8') THEN 'TRUE' ELSE 'FALSE' END     --    Filler16

	--,CASE WHEN @JOBID BETWEEN 3000 AND 3062 THEN 'TN50' + CLM_CNTRL_NO ELSE '' END     --    Filler17
	,CASE	 WHEN CLM_CNTRL_NO = '' OR CLM_CNTRL_NO IS NULL THEN ''
			 WHEN oph.SOURCEDATAKEY IN ('50','30') AND @LOBCODE <> 'C54581391' THEN CAST(oph.SOURCEDATAKEY AS VARCHAR) + CLM_CNTRL_NO
      		 WHEN oph.SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLM_CNTRL_NO
			 WHEN oph.SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLM_CNTRL_NO	
			 WHEN oph.SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLM_CNTRL_NO	
			 WHEN oph.SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLM_CNTRL_NO -- 2300P_CLM01_ClaimNumber
	    	 WHEN oph.SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'MMAI' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLM_CNTRL_NO
			 WHEN oph.SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'CAID' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLM_CNTRL_NO
			 WHEN oph.SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'MMAI' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLM_CNTRL_NO
			 WHEN oph.SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'CAID' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLM_CNTRL_NO
			 WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN '51' + CLM_CNTRL_NO
	         WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN '52' + CLM_CNTRL_NO
	     END -- Filler17
	FROM wipro.dbo.OUTB_INST_HEADER oph
   LEFT JOIN (select claim_id , max(cms_icn) as cms_icn from wipro.dbo.outb_claim_status where cms_icn is not NULL group by claim_id) ocs on oph.CLM_CNTRL_NO = ocs.CLAIM_ID  and ocs.cms_icn is not null
--   LEFT JOIN WIPRO.dbo.OUTB_CLAIM_STATUS ocs on oph.CLM_CNTRL_NO = ocs.CLAIM_ID  and ocs.cms_icn is not null



/*---------------------------------------------------------------------*/
/* POPULATE 150 TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_150I_Rec_Header_Archive 
SELECT *, getdate()  FROM dbo.EE_CSV_150I_Rec_Header

TRUNCATE TABLE dbo.EE_CSV_150I_Rec_Header

INSERT INTO dbo.EE_CSV_150I_Rec_Header
SELECT 
    oph.claim_id,        -- ClaimID - varchar(20)
    SOURCEDATAKEY,         -- SourceDataKey - int
    CASE WHEN SYSTEM_SOURCE IN ('50','30') THEN '' ELSE SYSTEM_SOURCE END,        -- SourceDesc - varchar(60)
    GETDATE(), -- CreateDate - datetime
    '',        -- SBR01BSubscriberPayerResponsibilitySequence - varchar(100)
    '',        -- SBR02BSubscriberRelationship - varchar(100)
    '',        -- SBR03BSubscriberPolicyNumber - varchar(100)
    '',        -- SBR04BInsuredGroupName - varchar(100)
    oph.CLM_FIL_INDCD1,        -- SBR09BClaimFilingIndicator - varchar(100)
    '',        -- NM101BASubscriberPersonRole - varchar(100)
    '',        -- NM102BASubscriberPersonIndicator - varchar(100)
    oph.MEMBER_LAST_NAME,        -- NM103BASubscriberLastName - varchar(100)
    oph.MEMBER_FIRST_NAME,        -- NM104BASubscriberFirstName - varchar(100)
    oph.MEMBER_MID_INIT,        -- NM105BASubscriberMiddleName - varchar(100)
    oph.MEMBER_SFX,        -- NM107BASubscriberSuffix - varchar(100)
    '',        -- NM108BASubscriberIdentifierQualifer - varchar(100)
    oph.MEMBER_ID,        -- NM109BASubscriberIdentifier - varchar(100)
    '',        -- REF01BASubscriberSSNQualifier - varchar(100)
    oph.MEMBER_SSN,        -- REF02BASubscriberIdentifierSSN - varchar(100)
    '',        -- REF01BAPropertyandCasualtyQualifier - varchar(100)
    '',        -- REF02BAPropertyandCasualtyIdentifier - varchar(100)
    oph.MEMBER_ADDR1,        -- N301BASubscriberAddressLine1 - varchar(100)
    oph.MEMBER_ADDR2,        -- N302BASubscriberAddressLine2 - varchar(100)
    oph.MEMBER_CITY,        -- N401BASubscriberCity - varchar(100)
    oph.MEMBER_STATE,        -- N402BASubscriberState - varchar(100)
    oph.MEMBER_ZIP + oph.MEMBER_ZIP4,        -- N403BASubscriberPostalCode - varchar(100) 
	 '',        -- N404BASubscriberCountry - varchar(100)
    '',        -- DMG01BADateQualifer - varchar(100)
    oph.MEMBER_DOB,        -- DMG02BADateOfBirth - varchar(100)
    oph.MEMBER_GENDER,        -- DMG03BAGender - varchar(100)
    '',        -- REF01BASubscriberIdentifierQualifier01 - varchar(100)
    '',        -- REF02BASubscriberIdentifier01 - varchar(100)
    '',        -- REF01BASubscriberIdentifierQualifer02 - varchar(100)
     oph.HICN_NUM,        -- REF02BASubscriberIdentifier02 - varchar(100)
    '',        -- NM101BBPayerOrganizationRole - varchar(100)
    '',        -- NM102BBPayerPersonIndicator - varchar(100)
    '', -- Commented EDS-2185 oph.OTH_PAYER1_NAME,        -- NM103BBPayerName - varchar(100)
    '',        -- NM108BBPayerOrganizationIDQualifier - varchar(100)
    '',        -- NM109BBPayerOrganizationIdentifier - varchar(100)
    oph.PAYTO_ADDR1,        -- N301BBPayerAddressLine1 - varchar(100)
    oph.PAYTO_ADDR2,        -- N302BBPayerAddressLine2 - varchar(100)
    oph.PAYTO_CITY,        --[2010BB_N401_PayerCity]  [VARCHAR] (100)   Default '',
    oph.PAYTO_STATE,        -- N401BBPayerState - varchar(100)
    oph.PAYTO_ZIP,        -- N403BBPayerPostalCode - varchar(100)
    '',        -- N404BBPayerCountry - varchar(100)
    '',        -- REF01BBPayerOrganizationIDQualifier01 - varchar(100)
    '',        -- REF02BBPayerOrganizationIdentifier01 - varchar(100)
    '',        -- REF01BBProviderIDQualifier01 - varchar(100)
    '',        -- REF02BBBillingProviderIdentifier01 - varchar(100)
    '',        -- REF01BBBillingProviderIDQualifier02 - varchar(100)
    '',        -- REF02BBBillingProviderIdentifier02 - varchar(100)
    '',        -- REF01BBBillingProviderIDQualifier03 - varchar(100)
    '',        -- REF02BBProviderIdentifier03 - varchar(100)
    '',        -- REF01BBBillingProviderIDQualifier04 - varchar(100)
    '',        -- REF02BBBillingProviderIdentifier04 - varchar(100)
    '',        -- PatientLastName - varchar(100)
    '',        -- PatientFirstName - varchar(100)
    '',        -- PatientMiddleName - varchar(100)
    '',        -- PatientSSN - varchar(100)
    '',        -- PatientMemberID - varchar(100)
    '',        -- PatientGender - varchar(100)
    '',        -- PatientDOB - varchar(100)
    '',        -- PatientAddressLine1 - varchar(100)
    '',        -- PatientAddressLine2 - varchar(100)
    '',        -- PatientAddressCity - varchar(100)
    '',        -- PatientAddressState - varchar(100)
    '',        -- PatientAddressZip - varchar(100)
    '',        -- PCPIDQual - varchar(100)
    '',        -- PCPID - varchar(100)
    '',        -- PCPGroupIdentifier - varchar(100)
    '',        -- PDPIPAPMGType - varchar(100)
    '',        -- PDPIPAPMGID - varchar(100)
    '',        -- PCPOpenIndic - varchar(100)
    '',        -- PCPEligibilityInd - varchar(100)
    '',        -- COS - varchar(100)
    '',        -- ServiceCategoryType - varchar(100)
    '',        -- RenderingProvEffDate - varchar(100)
    '',        -- RenderingProvTermDate - varchar(100)
    '',        -- RenderingProvDEAID - varchar(100)
    '',        -- RenderingProvGender - varchar(100)
    '',        -- ProviderParNonPar - varchar(100)
    '',        -- CarePlanOptionIndicator - varchar(100)
    '',        -- GroupIndicator - varchar(100)
    '',        -- CareTypeCode - varchar(100)
    '',        -- FinancialArrangementCode - varchar(100)
    '',        -- Filler05 - varchar(100) -- Aaron -- Utilize for Member Reimbursement Flag (only for Professional)  Y -SDK=30 only
    oph.INSURANCE_TYPE,        -- SBR05BIsuranceTypeCode - varchar(100)
    '',        -- PAT09BPregnancyIndicator - varchar(100)
    '',        -- Filler06 - varchar(100)
    '',        -- Filler07 - varchar(100)
    '',        -- Filler08 - varchar(100)
    '',        -- Filler09 - varchar(100)
    '',        -- Filler10 - varchar(100)
    '',        -- Filler11 - varchar(100)
    '',        -- Filler12 - varchar(100)
    '',        -- Filler13 - varchar(100)
    '',        -- Filler14 - varchar(100)
    '',        -- Filler15 - varchar(100)
    '',        -- PAT06BPatientDeathDate - varchar(100)
    '',        -- PAT01CPatientRelationship - varchar(100)
    '',        -- PAT06CPatientDeathDate - varchar(100)
    '',        -- PAT08CPatientWeight - varchar(100)
    '',        -- PAT09CPregnancyIndicator - varchar(100)
    '',        -- SubscriberRegionCode - varchar(100)
    '',        -- SubscriberOtherInsuranceCoverage - varchar(100)
    '',        -- PurchasedIndicator - varchar(100)
    ''         -- BehavioralHealthCOS - varchar(100)
FROM WIPRO.dbo.OUTB_INST_HEADER oph

/*---------------------------------------------------------------------*/
/* POPULATE 20 REC TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_20I_Rec_Header_Archive 
SELECT *, getdate()  FROM dbo.EE_CSV_20I_Rec_Header

TRUNCATE TABLE dbo.EE_CSV_20I_Rec_Header

INSERT INTO [dbo].[EE_CSV_20I_Rec_Header] (
	   [ClaimID]
      ,[SourceDataKey]
      ,[SourceDesc]
      ,[CreateDate]
      ,[2300I_CLM01_ClaimNumber]
      ,[2300I_CLM02_TotalClaimCharge]
      ,[2300I_CLM05-01_FacilityTypeCode]
      ,[2300I_CLM05-02_BillTypeQualifier]
      ,[2300I_CLM05-03_ClaimFrequencyCode]
      ,[2300I_CLM07_MedicareAssignment]
      ,[2300I_CLM08_BenefitAssignmentIndicator]
      ,[2300I_CLM09_ReleaseOfInformation]
      ,[2300I_CLM20_DelayReason]
      ,[2300I_DTP01_DateTimeQualifier_1]
      ,[2300I_DTP02_FormatQualifier_1]
      ,[2300I_DTP03_DateTime_1]
      ,[2300I_DTP01_DateTimeQualifier_2]
      ,[2300I_DTP02_FormatQualifier_2]
      ,[2300I_DTP03_DateTime_2]
      ,[2300I_DTP01_DateTimeQualifier_3]
      ,[2300I_DTP02_FormatQualifier_3]
      ,[2300I_DTP03_DateTime_3]
      ,[2300I_DTP01_DateTimeQualifier_4]
      ,[2300I_DTP02_FormatQualifier_4]
      ,[2300I_DTP03_DateTime_4]
      ,[2300I_CL101_AdmissionType]
      ,[2300I_CL102_AdmissionSource]
      ,[2300I_CL103_PatientStatus]
      ,[2300I_CN101_ContractTypeCode]
      ,[2300I_CN102_MonetaryAmount]
      ,[2300I_CN103_ContractPercentage]
      ,[2300I_CN104_ContractCode]
      ,[2300I_CN105_TermsDiscountPercent]
      ,[2300I_CN106_ContractVersionIdentifier]
      ,[2300I_AMT01_AmountQualifier]
      ,[2300I_AMT02_PatientAmountDue]
      ,[2300I_REF01_ClaimReferenceNumberQualifier_1]
      ,[2300I_REF02_ClaimReferenceNumber_1]
      ,[2300I_REF01_ClaimReferenceNumberQualifier_2]
      ,[2300I_REF02_ClaimReferenceNumber_2]
      ,[2300I_REF01_ClaimReferenceNumberQualifier_3]
      ,[2300I_REF02_ClaimReferenceNumber_3]
      ,[2300I_REF01_ClaimReferenceNumberQualifier_4]
      ,[2300I_REF02_ClaimReferenceNumber_4]
      ,[2300I_REF01_ClaimReferenceNumberQualifier_5]
      ,[2300I_REF02_ClaimReferenceNumber_5]
      ,[2300I_REF01_ClaimReferenceNumberQualifier_6]
      ,[2300I_REF02_ClaimReferenceNumber_6]
      ,[2300I_REF01_ClaimReferenceNumberQualifier_7]
      ,[2300I_REF02_ClaimReferenceNumber_7]
      ,[2300I_REF01_ClaimReferenceNumberQualifier_8]
      ,[2300I_REF02_ClaimReferenceNumber_8]
      ,[2300I_NTE01_ClaimNoteType]
      ,[2300I_NTE02_ClaimNote]
      ,[2300I_NTE01_BillNoteType]
      ,[2300I_NTE01_BillNote]
      ,[2300I_CRC01_ServiceCertificationCategory]
      ,[2300I_CRC02_ServiceCertificationIndicator]
      ,[2300I_CRC03_ConditionIndicatorCode]
      ,[2300I_CRC04_ConditionIndicatorCode]
      ,[2300I_CRC05_ConditionIndicatorCode]
      ,[2300I_HI01-01_PrinDXType]
      ,[2300I_HI01-02_PrincipalDXCode]
      ,[2300I_HI01-09_PrincipalDXPOA]
      ,[2300I_HI01-01_AdmittingDXType]
      ,[2300I_HI01-02_AdmittingDXCode]
      ,[2300I_HI01-01_PatientDXType]
      ,[2300I_HI01-02_PatientDXCode]
      ,[2300I_HI02-01_PatientDXType]
      ,[2300I_HI02-02_PatientDXCode]
      ,[2300I_HI03-01_PatientDXType]
      ,[2300I_HI03-02_PatientDXCode]
      ,[2300I_HI01-01_ECIDXType]
      ,[2300I_HI01-02_ECIDXCode]
      ,[2300I_HI01-09_ECIDXPOA]
      ,[2300I_HI02-01_ECIDXType]
      ,[2300I_HI02-02_ECIDXCode]
      ,[2300I_HI02-09_ECIDXPOA]
      ,[2300I_HI03-01_ECIDXType]
      ,[2300I_HI03-02_ECIDXCode]
      ,[2300I_HI03-09_ECIDXPOA]
      ,[2300I_HI04-01_ECIDXType]
      ,[2300I_HI04-02_ECIDXCode]
      ,[2300I_HI04-09_ECIDXPOA]
      ,[2300I_HI05-01_ECIDXType]
      ,[2300I_HI05-02_ECIDXCode]
      ,[2300I_HI05-09_ECIDXPOA]
      ,[2300I_HI06-01_ECIDXType]
      ,[2300I_HI06-02_ECIDXCode]
      ,[2300I_HI06-09_ECIDXPOA]
      ,[2300I_HI07-01_ECIDXType]
      ,[2300I_HI07-02_ECIDXCode]
      ,[2300I_HI07-09_ECIDXPOA]
      ,[2300I_HI08-01_ECIDXType]
      ,[2300I_HI08-02_ECIDXCode]
      ,[2300I_HI08-09_ECIDXPOA]
      ,[2300I_HI09-01_ECIDXType]
      ,[2300I_HI09-02_ECIDXCode]
      ,[2300I_HI09-09_ECIDXPOA]
      ,[2300I_HI10-01_ECIDXType]
      ,[2300I_HI10-02_ECIDXCode]
      ,[2300I_HI10-09_ECIDXPOA]
      ,[2300I_HI11-01_ECIDXType]
      ,[2300I_HI11-02_ECIDXCode]
      ,[2300I_HI11-09_ECIDXPOA]
      ,[2300I_HI12-01_ECIDXType]
      ,[2300I_HI12-02_ECIDXCode]
      ,[2300I_HI12-09_ECIDXPOA]
      ,[2300I_HI01-01_DRGType]
      ,[2300I_HI01-02_DRGCode]
      ,[20I_DRG_Version]
      ,[20I_DRG_Severity]
      ,[20I_DRG_Risk]
      ,[2300I_HI01-01_DXType_1]
      ,[2300I_HI01-02_DXCode_1]
      ,[2300I_HI01-09_DXPOA_1]
      ,[2300I_HI02-01_DXType_1]
      ,[2300I_HI02-02_DXCode_1]
      ,[2300I_HI02-09_DXPOA_1]
      ,[2300I_HI03-01_DXType_1]
      ,[2300I_HI03-02_DXCode_1]
      ,[2300I_HI03-09_DXPOA_1]
      ,[2300I_HI04-01_DXType_1]
      ,[2300I_HI04-02_DXCode_1]
      ,[2300I_HI04-09_DXPOA_1]
      ,[2300I_HI05-01_DXType_1]
      ,[2300I_HI05-02_DXCode_1]
      ,[2300I_HI05-09_DXPOA_1]
      ,[2300I_HI06-01_DXType_1]
      ,[2300I_HI06-02_DXCode_1]
      ,[2300I_HI06-09_DXPOA_1]
      ,[2300I_HI07-01_DXType_1]
      ,[2300I_HI07-02_DXCode_1]
      ,[2300I_HI07-09_DXPOA_1]
      ,[2300I_HI08-01_DXType_1]
      ,[2300I_HI08-02_DXCode_1]
      ,[2300I_HI08-09_DXPOA_1]
      ,[2300I_HI09-01_DXType_1]
      ,[2300I_HI09-02_DXCode_1]
      ,[2300I_HI09-09_DXPOA_1]
      ,[2300I_HI10-01_DXType_1]
      ,[2300I_HI10-02_DXCode_1]
      ,[2300I_HI10-09_DXPOA_1]
      ,[2300I_HI11-01_DXType_1]
      ,[2300I_HI11-02_DXCode_1]
      ,[2300I_HI11-09_DXPOA_1]
      ,[2300I_HI12-01_DXType_1]
      ,[2300I_HI12-02_DXCode_1]
      ,[2300I_HI12-09_DXPOA_1]
      ,[2300I_HI01-01_DXType_2]
      ,[2300I_HI01-02_DXCode_2]
      ,[2300I_HI01-09_DXPOA_2]
      ,[2300I_HI02-01_DXType_2]
      ,[2300I_HI02-02_DXCode_2]
      ,[2300I_HI02-09_DXPOA_2]
      ,[2300I_HI03-01_DXType_2]
      ,[2300I_HI03-02_DXCode_2]
      ,[2300I_HI03-09_DXPOA_2]
      ,[2300I_HI04-01_DXType_2]
      ,[2300I_HI04-02_DXCode_2]
      ,[2300I_HI04-09_DXPOA_2]
      ,[2300I_HI05-01_DXType_2]
      ,[2300I_HI05-02_DXCode_2]
      ,[2300I_HI05-09_DXPOA_2]
      ,[2300I_HI06-01_DXType_2]
      ,[2300I_HI06-02_DXCode_2]
      ,[2300I_HI06-09_DXPOA_2]
      ,[2300I_HI07-01_DXType_2]
      ,[2300I_HI07-02_DXCode_2]
      ,[2300I_HI07-09_DXPOA_2]
      ,[2300I_HI08-01_DXType_2]
      ,[2300I_HI08-02_DXCode_2]
      ,[2300I_HI08-09_DXPOA_2]
      ,[2300I_HI09-01_DXType_2]
      ,[2300I_HI09-02_DXCode_2]
      ,[2300I_HI09-09_DXPOA_2]
      ,[2300I_HI10-01_DXType_2]
      ,[2300I_HI10-02_DXCode_2]
      ,[2300I_HI10-09_DXPOA_2]
      ,[2300I_HI11-01_DXType_2]
      ,[2300I_HI11-02_DXCode_2]
      ,[2300I_HI11-09_DXPOA_2]
      ,[2300I_HI12-01_DXType_2]
      ,[2300I_HI12-02_DXCode_2]
      ,[2300I_HI12-09_DXPOA_2]
      ,[2300I_HI13-01_DXType_2]
      ,[2300I_HI13-02_DXCode_2]
      ,[2300I_HI13-09_DXPOA_2]
      ,[2300I_HI14-01_DXType_2]
      ,[2300I_HI14-02_DXCode_2]
      ,[2300I_HI14-09_DXPOA_2]
      ,[2300I_HI01-01_PrincipalPXType]
      ,[2300I_HI01-02_PrincipalPXCode]
      ,[2300I_HI01-03_PrincipalPXDateQualifier]
      ,[2300I_HI01-04_PrincipalPXDate]
      ,[2300I_HI01-01_PXType_1]
      ,[2300I_HI01-02_PXCode_1]
      ,[2300I_HI01-03_PXDateQualifier_1]
      ,[2300I_HI01-04_PXDate_1]
      ,[2300I_HI02-01_PXType_1]
      ,[2300I_HI02-02_PXCode_1]
      ,[2300I_HI02-03_PXDateQualifier_1]
      ,[2300I_HI02-04_PXDate_1]
      ,[2300I_HI03-01_PXType_1]
      ,[2300I_HI03-02_PXCode_1]
      ,[2300I_HI03-03_PXDateQualifier_1]
      ,[2300I_HI03-04_PXDate_1]
      ,[2300I_HI04-01_PXType_1]
      ,[2300I_HI04-02_PXCode_1]
      ,[2300I_HI04-03_PXDateQualifier_1]
      ,[2300I_HI04-04_PXDate_1]
      ,[2300I_HI05-01_PXType_1]
      ,[2300I_HI05-02_PXCode_1]
      ,[2300I_HI05-03_PXDateQualifier_1]
      ,[2300I_HI05-04_PXDate_1]
      ,[2300I_HI06-01_PXType_1]
      ,[2300I_HI06-02_PXCode_1]
      ,[2300I_HI06-03_PXDateQualifier_1]
      ,[2300I_HI06-04_PXDate_1]
      ,[2300I_HI07-01_PXType_1]
      ,[2300I_HI07-02_PXCode_1]
      ,[2300I_HI07-03_PXDateQualifier_1]
      ,[2300I_HI07-04_PXDate_1]
      ,[2300I_HI08-01_PXType_1]
      ,[2300I_HI08-02_PXCode_1]
      ,[2300I_HI08-03_PXDateQualifier_1]
      ,[2300I_HI08-04_PXDate_1]
      ,[2300I_HI09-01_PXType_1]
      ,[2300I_HI09-02_PXCode_1]
      ,[2300I_HI09-03_PXDateQualifier_1]
      ,[2300I_HI09-04_PXDate_1]
      ,[2300I_HI10-01_PXType_1]
      ,[2300I_HI10-02_PXCode_1]
      ,[2300I_HI10-03_PXDateQualifier_1]
      ,[2300I_HI10-04_PXDate_1]
      ,[2300I_HI11-01_PXType_1]
      ,[2300I_HI11-02_PXCode_1]
      ,[2300I_HI11-03_PXDateQualifier_1]
      ,[2300I_HI11-04_PXDate_1]
      ,[2300I_HI12-01_PXType_1]
      ,[2300I_HI12-02_PXCode_1]
      ,[2300I_HI12-03_PXDateQualifier_1]
      ,[2300I_HI12-04_PXDate_1]
      ,[2300I_HI01-01_PXType_2]
      ,[2300I_HI01-02_PXCode_2]
      ,[2300I_HI01-03_PXDateQualifier_2]
      ,[2300I_HI01-04_PXDate_2]
      ,[2300I_HI02-01_PXType_2]
      ,[2300I_HI02-02_PXCode_2]
      ,[2300I_HI02-03_PXDateQualifier_2]
      ,[2300I_HI02-04_PXDate_2]
      ,[2300I_HI03-01_PXType_2]
      ,[2300I_HI03-02_PXCode_2]
      ,[2300I_HI03-03_PXDateQualifier_2]
      ,[2300I_HI03-04_PXDate_2]
      ,[2300I_HI04-01_PXType_2]
      ,[2300I_HI04-02_PXCode_2]
      ,[2300I_HI04-03_PXDateQualifier_2]
      ,[2300I_HI04-04_PXDate_2]
      ,[2300I_HI05-01_PXType_2]
      ,[2300I_HI05-02_PXCode_2]
      ,[2300I_HI05-03_PXDateQualifier_2]
      ,[2300I_HI05-04_PXDate_2]
      ,[2300I_HI06-01_PXType_2]
      ,[2300I_HI06-02_PXCode_2]
      ,[2300I_HI06-03_PXDateQualifier_2]
      ,[2300I_HI06-04_PXDate_2]
      ,[2300I_HI07-01_PXType_2]
      ,[2300I_HI07-02_PXCode_2]
      ,[2300I_HI07-03_PXDateQualifier_2]
      ,[2300I_HI07-04_PXDate_2]
      ,[2300I_HI08-01_PXType_2]
      ,[2300I_HI08-02_PXCode_2]
      ,[2300I_HI08-03_PXDateQualifier_2]
      ,[2300I_HI08-04_PXDate_2]
      ,[2300I_HI09-01_PXType_2]
      ,[2300I_HI09-02_PXCode_2]
      ,[2300I_HI09-03_PXDateQualifier_2]
      ,[2300I_HI09-04_PXDate_2]
      ,[2300I_HI10-01_PXType_2]
      ,[2300I_HI10-02_PXCode_2]
      ,[2300I_HI10-03_PXDateQualifier_2]
      ,[2300I_HI10-04_PXDate_2]
      ,[2300I_HI11-01_PXType_2]
      ,[2300I_HI11-02_PXCode_2]
      ,[2300I_HI11-03_PXDateQualifier_2]
      ,[2300I_HI11-04_PXDate_2]
      ,[2300I_HI12-01_PXType_2]
      ,[2300I_HI12-02_PXCode_2]
      ,[2300I_HI12-03_PXDateQualifier_2]
      ,[2300I_HI12-04_PXDate_2]
      ,[2300I_HI01-01_OccurSpanType]
      ,[2300I_HI01-02_OccurSpanCode]
      ,[2300I_HI01-03_OccurSpanDateQualifier]
      ,[2300I_HI01-04_OccurSpanDate]
      ,[2300I_HI02-01_OccurSpanType]
      ,[2300I_HI02-02_OccurSpanCode]
      ,[2300I_HI02-03_OccurSpanDateQualifier]
      ,[2300I_HI02-04_OccurSpanDate]
      ,[2300I_HI03-01_OccurSpanType]
      ,[2300I_HI03-02_OccurSpanCode]
      ,[2300I_HI03-03_OccurSpanDateQualifier]
      ,[2300I_HI03-04_OccurSpanDate]
      ,[2300I_HI04-01_OccurSpanType]
      ,[2300I_HI04-02_OccurSpanCode]
      ,[2300I_HI04-03_OccurSpanDateQualifier]
      ,[2300I_HI04-04_OccurSpanDate]
      ,[2300I_HI05-01_OccurSpanType]
      ,[2300I_HI05-02_OccurSpanCode]
      ,[2300I_HI05-03_OccurSpanDateQualifier]
      ,[2300I_HI05-04_OccurSpanDate]
      ,[2300I_HI06-01_OccurSpanType]
      ,[2300I_HI06-02_OccurSpanCode]
      ,[2300I_HI06-03_OccurSpanDateQualifier]
      ,[2300I_HI06-04_OccurSpanDate]
      ,[2300I_HI07-01_OccurSpanType]
      ,[2300I_HI07-02_OccurSpanCode]
      ,[2300I_HI07-03_OccurSpanDateQualifier]
      ,[2300I_HI07-04_OccurSpanDate]
      ,[2300I_HI08-01_OccurSpanType]
      ,[2300I_HI08-02_OccurSpanCode]
      ,[2300I_HI08-03_OccurSpanDateQualifier]
      ,[2300I_HI08-04_OccurSpanDate]
      ,[2300I_HI09-01_OccurSpanType]
      ,[2300I_HI09-02_OccurSpanCode]
      ,[2300I_HI09-03_OccurSpanDateQualifier]
      ,[2300I_HI09-04_OccurSpanDate]
      ,[2300I_HI10-01_OccurSpanType]
      ,[2300I_HI10-02_OccurSpanCode]
      ,[2300I_HI10-03_OccurSpanDateQualifier]
      ,[2300I_HI10-04_OccurSpanDate]
      ,[2300I_HI11-01_OccurSpanType]
      ,[2300I_HI11-02_OccurSpanCode]
      ,[2300I_HI11-03_OccurSpanDateQualifier]
      ,[2300I_HI11-04_OccurSpanDate]
      ,[2300I_HI12-01_OccurSpanType]
      ,[2300I_HI12-02_OccurSpanCode]
      ,[2300I_HI12-03_OccurSpanDateQualifier]
      ,[2300I_HI12-04_OccurSpanDate]
      ,[2300I_HI01-01_OccurType]
      ,[2300I_HI01-02_OccurCode]
      ,[2300I_HI01-03_OccurDateQualifier]
      ,[2300I_HI01-04_OccurDate]
      ,[2300I_HI02-01_OccurType]
      ,[2300I_HI02-02_OccurCode]
      ,[2300I_HI02-03_OccurDateQualifier]
      ,[2300I_HI02-04_OccurDate]
      ,[2300I_HI03-01_OccurType]
      ,[2300I_HI03-02_OccurCode]
      ,[2300I_HI03-03_OccurDateQualifier]
      ,[2300I_HI03-04_OccurDate]
      ,[2300I_HI04-01_OccurType]
      ,[2300I_HI04-02_OccurCode]
      ,[2300I_HI04-03_OccurDateQualifier]
      ,[2300I_HI04-04_OccurDate]
      ,[2300I_HI05-01_OccurType]
      ,[2300I_HI05-02_OccurCode]
      ,[2300I_HI05-03_OccurDateQualifier]
      ,[2300I_HI05-04_OccurDate]
      ,[2300I_HI06-01_OccurType]
      ,[2300I_HI06-02_OccurCode]
      ,[2300I_HI06-03_OccurDateQualifier]
      ,[2300I_HI06-04_OccurDate]
      ,[2300I_HI07-01_OccurType]
      ,[2300I_HI07-02_OccurCode]
      ,[2300I_HI07-03_OccurDateQualifier]
      ,[2300I_HI07-04_OccurDate]
      ,[2300I_HI08-01_OccurType]
      ,[2300I_HI08-02_OccurCode]
      ,[2300I_HI08-03_OccurDateQualifier]
      ,[2300I_HI08-04_OccurDate]
      ,[2300I_HI09-01_OccurType]
      ,[2300I_HI09-02_OccurCode]
      ,[2300I_HI09-03_OccurDateQualifier]
      ,[2300I_HI09-04_OccurDate]
      ,[2300I_HI10-01_OccurType]
      ,[2300I_HI10-02_OccurCode]
      ,[2300I_HI10-03_OccurDateQualifier]
      ,[2300I_HI10-04_OccurDate]
      ,[2300I_HI11-01_OccurType]
      ,[2300I_HI11-02_OccurCode]
      ,[2300I_HI11-03_OccurDateQualifier]
      ,[2300I_HI11-04_OccurDate]
      ,[2300I_HI12-01_OccurType]
      ,[2300I_HI12-02_OccurCode]
      ,[2300I_HI12-03_OccurDateQualifier]
      ,[2300I_HI12-04_OccurDate]
      ,[2300I_HI01-01_ValueCodeQualifer_1 ]
      ,[2300I_HI01-02_ValueCode_1 ]
      ,[2300I_HI01-05_ValueCodeAmount_1 ]
      ,[2300I_HI02-01_ValueCodeQualifer_1 ]
      ,[2300I_HI02-02_ValueCode_1 ]
      ,[2300I_HI02-05_ValueCodeAmount_1 ]
      ,[2300I_HI03-01_ValueCodeQualifer_1 ]
      ,[2300I_HI03-02_ValueCode_1 ]
      ,[2300I_HI03-05_ValueCodeAmount_1 ]
      ,[2300I_HI04-01_ValueCodeQualifer_1 ]
      ,[2300I_HI04-02_ValueCode_1 ]
      ,[2300I_HI04-05_ValueCodeAmount_1 ]
      ,[2300I_HI05-01_ValueCodeQualifer_1 ]
      ,[2300I_HI05-05_ValueCode_1 ]
      ,[2300I_HI05-05_ValueCodeAmount_1 ]
      ,[2300I_HI06-01_ValueCodeQualifer_1 ]
      ,[2300I_HI06-02_ValueCode_1 ]
      ,[2300I_HI06-05_ValueCodeAmount_1 ]
      ,[2300I_HI07-01_ValueCodeQualifer_1 ]
      ,[2300I_HI07-02_ValueCode_1 ]
      ,[2300I_HI07-05_ValueCodeAmount_1 ]
      ,[2300I_HI08-01_ValueCodeQualifer_1 ]
      ,[2300I_HI08-02_ValueCode_1 ]
      ,[2300I_HI08-05_ValueCodeAmount_1 ]
      ,[2300I_HI09-01_ValueCodeQualifer_1 ]
      ,[2300I_HI09-02_ValueCode_1 ]
      ,[2300I_HI09-05_ValueCodeAmount_1 ]
      ,[2300I_HI10-01_ValueCodeQualifer_1 ]
      ,[2300I_HI10-02_ValueCode_1 ]
      ,[2300I_HI10-05_ValueCodeAmount_1 ]
      ,[2300I_HI11-01_ValueCodeQualifer_1 ]
      ,[2300I_HI11-02_ValueCode_1 ]
      ,[2300I_HI11-05_ValueCodeAmount_1 ]
      ,[2300I_HI12-01_ValueCodeQualifer_1 ]
      ,[2300I_HI12-02_ValueCode_1 ]
      ,[2300I_HI12-05_ValueCodeAmount_1 ]
      ,[2300I_HI01-01_ValueCodeQualifer_2 ]
      ,[2300I_HI01-02_ValueCode_2 ]
      ,[2300I_HI01-05_ValueCodeAmount_2 ]
      ,[2300I_HI02-01_ValueCodeQualifer_2 ]
      ,[2300I_HI02-02_ValueCode_2 ]
      ,[2300I_HI02-05_ValueCodeAmount_2 ]
      ,[2300I_HI03-01_ValueCodeQualifer_2 ]
      ,[2300I_HI03-02_ValueCode_2 ]
      ,[2300I_HI03-05_ValueCodeAmount_2 ]
      ,[2300I_HI04-01_ValueCodeQualifer_2 ]
      ,[2300I_HI04-02_ValueCode_2 ]
      ,[2300I_HI04-05_ValueCodeAmount_2 ]
      ,[2300I_HI05-01_ValueCodeQualifer_2 ]
      ,[2300I_HI05-02_ValueCode_2 ]
      ,[2300I_HI05-05_ValueCodeAmount_2 ]
      ,[2300I_HI06-01_ValueCodeQualifer_2 ]
      ,[2300I_HI06-02_ValueCode_2 ]
      ,[2300I_HI06-05_ValueCodeAmount_2 ]
      ,[2300I_HI07-01_ValueCodeQualifer_2 ]
      ,[2300I_HI07-02_ValueCode_2 ]
      ,[2300I_HI07-05_ValueCodeAmount_2 ]
      ,[2300I_HI08-01_ValueCodeQualifer_2 ]
      ,[2300I_HI08-02_ValueCode_2 ]
      ,[2300I_HI08-05_ValueCodeAmount_2 ]
      ,[2300I_HI09-01_ValueCodeQualifer_2 ]
      ,[2300I_HI09-02_ValueCode_2 ]
      ,[2300I_HI09-05_ValueCodeAmount_2 ]
      ,[2300I_HI10-01_ValueCodeQualifer_2 ]
      ,[2300I_HI10-02_ValueCode_2 ]
      ,[2300I_HI10-05_ValueCodeAmount_2 ]
      ,[2300I_HI11-01_ValueCodeQualifer_2 ]
      ,[2300I_HI11-02_ValueCode_2 ]
      ,[2300I_HI11-05_ValueCodeAmount_2 ]
      ,[2300I_HI12-01_ValueCodeQualifer_2 ]
      ,[2300I_HI12-02_ValueCode_2 ]
      ,[2300I_HI12-05_ValueCodeAmount_2 ]
      ,[2300I_HI01-01_ConditionCodeQualifier]
      ,[2300I_HI01-02_ConditionCode ]
      ,[2300I_HI02-01_ConditionCodeQualifier]
      ,[2300I_HI02-02_ConditionCode ]
      ,[2300I_HI03-01_ConditionCodeQualifier]
      ,[2300I_HI03-02_ConditionCode ]
      ,[2300I_HI04-01_ConditionCodeQualifier]
      ,[2300I_HI04-02_ConditionCode ]
      ,[2300I_HI05-01_ConditionCodeQualifier]
      ,[2300I_HI05-02_ConditionCode ]
      ,[2300I_HI06-01_ConditionCodeQualifier]
      ,[2300I_HI06-02_ConditionCode ]
      ,[2300I_HI07-01_ConditionCodeQualifier]
      ,[2300I_HI07-02_ConditionCode ]
      ,[2300I_HI08-01_ConditionCodeQualifier]
      ,[2300I_HI08-02_ConditionCode ]
      ,[2300I_HI09-01_ConditionCodeQualifier]
      ,[2300I_HI09-02_ConditionCode ]
      ,[2300I_HI10-01_ConditionCodeQualifier]
      ,[2300I_HI10-02_ConditionCode ]
      ,[2300I_HI11-01_ConditionCodeQualifier]
      ,[2300I_HI11-02_ConditionCode ]
      ,[2300I_HI12-01_ConditionCodeQualifier]
      ,[2300I_HI12-02_ConditionCode ]
      ,[2300I_HI01-01_TreatmentCodeQualifier]
      ,[2300I_HI01-02_TreatmentCode ]
      ,[2300I_HI02-01_TreatmentCodeQualifier]
      ,[2300I_HI02-02_TreatmentCode ]
      ,[2300I_HI03-01_TreatmentCodeQualifier]
      ,[2300I_HI03-02_TreatmentCode ]
      ,[2300I_HI04-01_TreatmentCodeQualifier]
      ,[2300I_HI04-02_TreatmentCode ]
      ,[2300I_HI05-01_TreatmentCodeQualifier]
      ,[2300I_HI05-02_TreatmentCode ]
      ,[2300I_HI06-01_TreatmentCodeQualifier]
      ,[2300I_HI06-02_TreatmentCode ]
      ,[2300I_HI07-01_TreatmentCodeQualifier]
      ,[2300I_HI07-02_TreatmentCode ]
      ,[2300I_HI08-01_TreatmentCodeQualifier]
      ,[2300I_HI08-02_TreatmentCode ]
      ,[2300I_HI09-01_TreatmentCodeQualifier]
      ,[2300I_HI09-02_TreatmentCode ]
      ,[2300I_HI10-01_TreatmentCodeQualifier]
      ,[2300I_HI10-02_TreatmentCode ]
      ,[2300I_HI11-01_TreatmentCodeQualifier]
      ,[2300I_HI11-02_TreatmentCode ]
      ,[2300I_HI12-01_TreatmentCodeQualifier]
      ,[2300I_HI12-02_TreatmentCode ]
      ,[2300I_HCP01_PricingMethod ]
      ,[2300I_HCP02_AllowedAmount]
      ,[2300I_HCP03_SavingAmount]
      ,[2300I_HCP04_OrgID]
      ,[2300I_HCP05_PricingRate]
      ,[2300I_HCP06_ApprovedDRGCode]
      ,[2300I_HCP07_ApprovedDRGAmount]
      ,[2300I_HCP08_ApprovedRevenueCode]
      ,[2300I_HCP11_Units]
      ,[2300I_HCP12_Quatity]
      ,[2300I_HCP13_RejectReason]
      ,[2300I_HCP14_PolicyCompliance]
      ,[2300I_HCP15_ExceptionCode]
      ,[2310AI_NM101_ProviderRole]
      ,[2310AI_NM102_PersonIndicator]
      ,[2310AI_NM103_LastName]
      ,[2310AI_NM104_FirstName]
      ,[2310AI_NM105_MiddleName]
      ,[2310AI_NM107_Suffix]
      ,[2310AI_NM108_ProviderIdentifierQualifer]
      ,[2310AI_NM109_ProviderIdentifier]
      ,[2310AI_PRV01_ProviderCode]
      ,[2310AI_PRV02_ProviderCodeQualifer]
      ,[2310AI_PRV03_ProviderTaxonomy]
      ,[2310AI_REF01_ProviderIdentifierQualifer]
      ,[2310AI_REF02_ProviderIdentifier]
      ,[2310AI_REF01_ProviderIdentifierQualifer_02]
      ,[2310AI_REF02_ProviderIdentifier_02]
      ,[2310BI_NM101_ProviderRole]
      ,[2310BI_NM102_PersonIndicator]
      ,[2310BI_NM103_LastName]
      ,[2310BI_NM104_FirstName]
      ,[2310BI_NM105_MiddleName]
      ,[2310BI_NM107_Suffix]
      ,[2310BI_NM108_ProviderIdentifierQualifer]
      ,[2310BI_NM109_ProviderIdentifier]
      ,[2310BI_REF01_ProviderIdentifierQualifer]
      ,[2310BI_REF02_ProviderIdentifier]
      ,[2310BI_REF01_ProviderIdentifierQualifer_02]
      ,[2310BI_REF02_ProviderIdentifier_02]
      ,[2310CI_NM101_ProviderRole]
      ,[2310CI_NM102_PersonIndicator]
      ,[2310CI_NM103_LastName]
      ,[2310CI_NM104_FirstName]
      ,[2310CI_NM105_MiddleName]
      ,[2310CI_NM107_Suffix]
      ,[2310CI_NM108_ProviderIdentifierQualifer]
      ,[2310CI_NM109_ProviderIdentifier]
      ,[2310CI_REF01_ProviderIdentifierQualifer]
      ,[2310CI_REF02_ProviderIdentifier]
      ,[2310CI_REF01_ProviderIdentifierQualifer_02]
      ,[2310CI_REF02_ProviderIdentifier_02]
      ,[2310DI_NM101_ProviderRole]
      ,[2310DI_NM102_PersonIndicator]
      ,[2310DI_NM103_LastName]
      ,[2310DI_NM104_FirstName]
      ,[2310DI_NM105_MiddleName]
      ,[2310DI_NM107_Suffix]
      ,[2310DI_NM108_ProviderIdentifierQualifer]
      ,[2310DI_NM109_ProviderIdentifier]
      ,[2310DI_REF01_ProviderIdentifierQualifer]
      ,[2310DI_REF02_ProviderIdentifier]
      ,[2310DI_REF01_ProviderIdentifierQualifer_02]
      ,[2310DI_REF02_ProviderIdentifier_02]
      ,[20I_RenderingProviderAddress1]
      ,[20I_RenderingProviderAddress2]
      ,[20I_RenderingProviderCity]
      ,[20I_RenderingProviderState]
      ,[20I_RenderingProviderZip]
      ,[2310EI_NM101_ProviderRole]
      ,[2310EI_NM102_PersonIndicator]
      ,[2310EI_NM103_ORG_LastName]
      ,[2310EI_NM108_ProviderIdentifierQualifer]
      ,[2310EI_NM109_ProviderIdentifier]
      ,[2310EI_N301_AddressLine1]
      ,[2310EI_N302_AddressLine2]
      ,[2310EI_N401_City]
      ,[2310EI_N402_State]
      ,[2310EI_N403_PostalCode]
      ,[2310EI_N404_Country]
      ,[2310EI_REF01_ProviderIdentifierQualifer1]
      ,[2310EI_REF02_ProviderIdentifier1]
      ,[2310EI_REF01_ProviderIdentifierQualifer2]
      ,[2310EI_REF02_ProviderIdentifier2]
      ,[2310FI_NM101_ProviderRole]
      ,[2310FI_NM102_PersonIndicator]
      ,[2310FI_NM103_LastName]
      ,[2310FI_NM104_FirstName]
      ,[2310FI_NM105_MiddleName]
      ,[2310FI_NM107_Suffix]
      ,[2310FI_NM108_ProviderIdentifierQualifer]
      ,[2310FI_NM109_ProviderIdentifier]
      ,[2310FI_REF01_ProviderIdentifierQualifer]
      ,[2310FI_REF02_ProviderIdentifier]
      ,[2310FI_REF01_ProviderIdentifierQualifer_02]
      ,[2310FI_REF02_ProviderIdentifier_02]
      ,[2300I_PWK01_AttachmentReportType]
      ,[2300I_PWK02_AttachmentTransmissionCode]
      ,[2300I_PWK06_AttachmentControlNumber]
      ,[2300I_REF01_ServiceAuthorizationExceptionCode_Qualifier]
      ,[2300I_REF02_ServiceAuthorizationExceptionCode]
      ,[2300I_REF01_InvestigationalDeviceExemptionNumber_Qualifier]
      ,[2300I_REF02_InvestigationalDeviceExemptionNumber]
      ,[2300I_REF01_DemonstrationProject_Qualifier]
      ,[2300I_REF02_DemonstrationProjectIdentifier]
      ,[2300I_REF01_PeerReviewOrganization_Qualifier]
      ,[2300I_REF02_PeerReviewOrganizationNumber ]
      ,[2300I_REF01_FileInformation_Qualifier]
      ,[2300I_REF01_FileInformation]
      ,[Claim Processor Receiver Date]
      ,[InNetworkIndicator ]
      ,[PatientControlNumber]
      ,[20I-Filler 04]
      ,[20I-Filler 05]
      ,[20I-Filler 06]
      ,[20I-Filler 07]
      ,[20I-Filler 08]
      ,[20I-IFiller 09]
      ,[20I-IFiller 10]
      ,[20I-IFiller 11]
      ,[20I-IFiller 12]
      ,[20I-IFiller 13]
      ,[20I-IFiller 14]
      ,[20I-IFiller 15]
      ,[2300I_HI13-01_OccurSpanType]
      ,[2300I_HI13-02_OccurSpanCode]
      ,[2300I_HI13-03_OccurSpanDateQualifier]
      ,[2300I_HI13-04_OccurSpanDate]
      ,[2300I_HI14-01_OccurSpanType]
      ,[2300I_HI14-02_OccurSpanCode]
      ,[2300I_HI14-03_OccurSpanDateQualifier]
      ,[2300I_HI14-04_OccurSpanDate]
      ,[2300I_HI15-01_OccurSpanType]
      ,[2300I_HI15-02_OccurSpanCode]
      ,[2300I_HI15-03_OccurSpanDateQualifier]
      ,[2300I_HI15-04_OccurSpanDate]
      ,[2300I_HI16-01_OccurSpanType]
      ,[2300I_HI16-02_OccurSpanCode]
      ,[2300I_HI16-03_OccurSpanDateQualifier]
      ,[2300I_HI16-04_OccurSpanDate]
      ,[2300I_HI17-01_OccurSpanType]
      ,[2300I_HI17-02_OccurSpanCode]
      ,[2300I_HI17-03_OccurSpanDateQualifier]
      ,[2300I_HI17-04_OccurSpanDate]
      ,[2300I_HI18-01_OccurSpanType]
      ,[2300I_HI18-02_OccurSpanCode]
      ,[2300I_HI18-03_OccurSpanDateQualifier]
      ,[2300I_HI18-04_OccurSpanDate]
      ,[2300I_HI19-01_OccurSpanType]
      ,[2300I_HI19-02_OccurSpanCode]
      ,[2300I_HI19-03_OccurSpanDateQualifier]
      ,[2300I_HI19-04_OccurSpanDate]
      ,[2300I_HI20-01_OccurSpanType]
      ,[2300I_HI20-02_OccurSpanCode]
      ,[2300I_HI20-03_OccurSpanDateQualifier]
      ,[2300I_HI20-04_OccurSpanDate]
      ,[2300I_HI21-01_OccurSpanType]
      ,[2300I_HI21-02_OccurSpanCode]
      ,[2300I_HI21-03_OccurSpanDateQualifier]
      ,[2300I_HI21-04_OccurSpanDate]
      ,[2300I_HI22-01_OccurSpanType]
      ,[2300I_HI22-02_OccurSpanCode]
      ,[2300I_HI22-03_OccurSpanDateQualifier]
      ,[2300I_HI22-04_OccurSpanDate]
      ,[2300I_HI23-01_OccurSpanType]
      ,[2300I_HI23-02_OccurSpanCode]
      ,[2300I_HI23-03_OccurSpanDateQualifier]
      ,[2300I_HI23-04_OccurSpanDate]
      ,[2300I_HI24-01_OccurSpanType]
      ,[2300I_HI24-02_OccurSpanCode]
      ,[2300I_HI24-03_OccurSpanDateQualifier]
      ,[2300I_HI24-04_OccurSpanDate]
      ,[2300I_HI13-01_OccurType]
      ,[2300I_HI13-02_OccurCode]
      ,[2300I_HI13-03_OccurDateQualifier]
      ,[2300I_HI13-04_OccurDate]
      ,[2300I_HI14-01_OccurType]
      ,[2300I_HI14-02_OccurCode]
      ,[2300I_HI14-03_OccurDateQualifier]
      ,[2300I_HI14-04_OccurDate]
      ,[2300I_HI15-01_OccurType]
      ,[2300I_HI15-02_OccurCode]
      ,[2300I_HI15-03_OccurDateQualifier]
      ,[2300I_HI15-04_OccurDate]
      ,[2300I_HI16-01_OccurType]
      ,[2300I_HI16-02_OccurCode]
      ,[2300I_HI16-03_OccurDateQualifier]
      ,[2300I_HI16-04_OccurDate]
      ,[2300I_HI17-01_OccurType]
      ,[2300I_HI17-02_OccurCode]
      ,[2300I_HI17-03_OccurDateQualifier]
      ,[2300I_HI17-04_OccurDate]
      ,[2300I_HI18-01_OccurType]
      ,[2300I_HI18-02_OccurCode]
      ,[2300I_HI18-03_OccurDateQualifier]
      ,[2300I_HI18-04_OccurDate]
      ,[2300I_HI19-01_OccurType]
      ,[2300I_HI19-02_OccurCode]
      ,[2300I_HI19-03_OccurDateQualifier]
      ,[2300I_HI19-04_OccurDate]
      ,[2300I_HI20-01_OccurType]
      ,[2300I_HI20-02_OccurCode]
      ,[2300I_HI20-03_OccurDateQualifier]
      ,[2300I_HI20-04_OccurDate]
      ,[2300I_HI21-01_OccurType]
      ,[2300I_HI21-02_OccurCode]
      ,[2300I_HI21-03_OccurDateQualifier]
      ,[2300I_HI21-04_OccurDate]
      ,[2300I_HI22-01_OccurType]
      ,[2300I_HI22-02_OccurCode]
      ,[2300I_HI22-03_OccurDateQualifier]
      ,[2300I_HI22-04_OccurDate]
      ,[2300I_HI23-01_OccurType]
      ,[2300I_HI23-02_OccurCode]
      ,[2300I_HI23-03_OccurDateQualifier]
      ,[2300I_HI23-04_OccurDate]
      ,[2300I_HI24-01_OccurType]
      ,[2300I_HI24-02_OccurCode]
      ,[2300I_HI24-03_OccurDateQualifier]
      ,[2300I_HI24-04_OccurDate]
      ,[2300I_HI13-01_TreatmentCodeQualifier]
      ,[2300I_HI13-02_TreatmentCode ]
      ,[2300I_HI14-01_TreatmentCodeQualifier]
      ,[2300I_HI14-02_TreatmentCode ]
      ,[2300I_HI15-01_TreatmentCodeQualifier]
      ,[2300I_HI15-02_TreatmentCode ]
      ,[2300I_HI16-01_TreatmentCodeQualifier]
      ,[2300I_HI16-02_TreatmentCode ]
      ,[2300I_HI17-01_TreatmentCodeQualifier]
      ,[2300I_HI17-02_TreatmentCode ]
      ,[2300I_HI18-01_TreatmentCodeQualifier]
      ,[2300I_HI18-02_TreatmentCode ]
      ,[2300I_HI19-01_TreatmentCodeQualifier]
      ,[2300I_HI19-02_TreatmentCode ]
      ,[2300I_HI20-01_TreatmentCodeQualifier]
      ,[2300I_HI20-02_TreatmentCode ]
      ,[2300I_HI21-01_TreatmentCodeQualifier]
      ,[2300I_HI21-02_TreatmentCode ]
      ,[2300I_HI22-01_TreatmentCodeQualifier]
      ,[2300I_HI22-02_TreatmentCode ]
      ,[2300I_HI23-01_TreatmentCodeQualifier]
      ,[2300I_HI23-02_TreatmentCode ]
      ,[2300I_HI24-01_TreatmentCodeQualifier]
      ,[2300I_HI24-02_TreatmentCode ]
      ,[2300I_HI13-01_ConditionCodeQualifier]
      ,[2300I_HI13-02_ConditionCode ]
      ,[2300I_HI14-01_ConditionCodeQualifier]
      ,[2300I_HI14-02_ConditionCode ]
      ,[2300I_HI15-01_ConditionCodeQualifier]
      ,[2300I_HI15-02_ConditionCode ]
      ,[2300I_HI16-01_ConditionCodeQualifier]
      ,[2300I_HI16-02_ConditionCode ]
      ,[2300I_HI17-01_ConditionCodeQualifier]
      ,[2300I_HI17-02_ConditionCode ]
      ,[2300I_HI18-01_ConditionCodeQualifier]
      ,[2300I_HI18-02_ConditionCode ]
      ,[2300I_HI19-01_ConditionCodeQualifier]
      ,[2300I_HI19-02_ConditionCode ]
      ,[2300I_HI20-01_ConditionCodeQualifier]
      ,[2300I_HI20-02_ConditionCode ]
      ,[2300I_HI21-01_ConditionCodeQualifier]
      ,[2300I_HI21-02_ConditionCode ]
      ,[2300I_HI22-01_ConditionCodeQualifier]
      ,[2300I_HI22-02_ConditionCode ]
      ,[2300I_HI23-01_ConditionCodeQualifier]
      ,[2300I_HI23-02_ConditionCode ]
      ,[2300I_HI24-01_ConditionCodeQualifier]
      ,[2300I_HI24-02_ConditionCode ]
      ,[2300I_REF01_FileInformation2]
      ,[2300I_REF01_FileInformation3]
      ,[2300I_REF01_FileInformation4]
      ,[2300I_REF01_FileInformation5]
      ,[2300I_REF01_FileInformation6]
      ,[2300I_REF01_FileInformation7]
      ,[2300I_REF01_FileInformation8]
      ,[2300I_REF01_FileInformation9]
      ,[2300I_REF01_FileInformation10]
      ,[2310EI_REF01_ProviderIdentifierQualifer3]
      ,[2310EI_REF02_ProviderIdentifier3]
  )
SELECT 
	  CLAIM_ID,				--[ClaimID]
      SOURCEDATAKEY,		 --[SourceDataKey]
      CASE WHEN SYSTEM_SOURCE IN ('50','30') THEN '' ELSE SYSTEM_SOURCE END,      --[SourceDesc]
      GETDATE(),      --[CreateDate]
		CASE WHEN SOURCEDATAKEY IN ('50','30') AND @LOBCODE <> 'C54581391' THEN CAST(SOURCEDATAKEY AS VARCHAR) + CLAIM_ID
      		 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLAIM_ID
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLAIM_ID	
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLAIM_ID	
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLAIM_ID -- 2300P_CLM01_ClaimNumber
	    	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'MMAI' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLAIM_ID
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'CAID' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLAIM_ID
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'MMAI' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLAIM_ID
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'CAID' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLAIM_ID
			 WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN '51' + CLAIM_ID
	         WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN '52' + CLAIM_ID
	     END, -- 2300P_CLM01_ClaimNumber
      TOT_CHRG_AMT,      --[2300I_CLM02_TotalClaimCharge]
      POS,      --[2300I_CLM05-01_FacilityTypeCode]
      '',      --[2300I_CLM05-02_BillTypeQualifier]
      ISNULL(CLM_IND,''),      --[2300I_CLM05-03_ClaimFrequencyCode]
      'A',      --[2300I_CLM07_MedicareAssignment]
      INSR_BEN_ASSGN_IND,      --[2300I_CLM08_BenefitAssignmentIndicator]
      REL_OF_INFO_FLAG,      --[2300I_CLM09_ReleaseOfInformation]
      '',      --[2300I_CLM20_DelayReason]
      '',      --[2300I_DTP01_DateTimeQualifier_1]
      '',      --[2300I_DTP02_FormatQualifier_1]
      DISCHRG_TIME,      --[2300I_DTP03_DateTime_1]
      '',      --[2300I_DTP01_DateTimeQualifier_2]
      '',      --[2300I_DTP02_FormatQualifier_2]
	  CASE WHEN STATE_BEGIN_DT = STATE_END_DT THEN STATE_BEGIN_DT 			
	  WHEN ISNULL(STATE_END_DT,'') = '' THEN STATE_BEGIN_DT		
	  ELSE concat (ltrim(rtrim(STATE_BEGIN_DT)),'-',ltrim(rtrim(STATE_END_DT))) END,	-- Commented out STATE_BEGIN_DT,      --[2300I_DTP03_DateTime_2]
      '',      --[2300I_DTP01_DateTimeQualifier_3]
      '',      --[2300I_DTP02_FormatQualifier_3]
      ADM_DT,      --[2300I_DTP03_DateTime_3]
      '',      --[2300I_DTP01_DateTimeQualifier_4]
      '',      --[2300I_DTP02_FormatQualifier_4]
      '', --DATERECEIVEDKEY,      --[2300I_DTP03_DateTime_4]
     ADM_TYPE_CD,      --[2300I_CL101_AdmissionType]
     ADM_SOURCE_CD,      --[2300I_CL102_AdmissionSource]
     PATIENT_STATUS_CD,      --[2300I_CL103_PatientStatus]
      CONTRACT_TYPE,      --[2300I_CN101_ContractTypeCode]
      '',      --[2300I_CN102_MonetaryAmount]
      '',      --[2300I_CN103_ContractPercentage]
      '',      --[2300I_CN104_ContractCode]
      '',      --[2300I_CN105_TermsDiscountPercent]
      '',      --[2300I_CN106_ContractVersionIdentifier]
      '',      --[2300I_AMT01_AmountQualifier]
      MEMBER_AMT_PAID,      --[2300I_AMT02_PatientAmountDue]
      '',      --[2300I_REF01_ClaimReferenceNumberQualifier_1]
      REFERRAL_NO,      --[2300I_REF02_ClaimReferenceNumber_1]
      '',      --[2300I_REF01_ClaimReferenceNumberQualifier_2]
      PRIOR_AUTH_NO,      --[2300I_REF02_ClaimReferenceNumber_2]
      '',      --[2300I_REF01_ClaimReferenceNumberQualifier_3]
	  	CASE 
			 WHEN CLM_CNTRL_NO = '' OR CLM_CNTRL_NO IS NULL THEN ''
			 WHEN SOURCEDATAKEY IN ('50','30') AND @LOBCODE <> 'C54581391' THEN CAST(SOURCEDATAKEY AS VARCHAR) + CLM_CNTRL_NO
      		 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE IN  ('ADVOCATE', 'EDPS-ADVOCATE') THEN '41' + CLM_CNTRL_NO
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in ('UNIV_CHI', 'EDPS-UNIV_CHI') THEN '42' + CLM_CNTRL_NO	
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '43' + CLM_CNTRL_NO	
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE <> 'C54581391' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '44' + CLM_CNTRL_NO -- 2300P_CLM01_ClaimNumber
	    	 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'MMAI' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '431' + CLM_CNTRL_NO
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391'  AND @LOB = 'CAID' AND SYSTEM_SOURCE  IN ('WELLMED', 'EDPS-WELLMED') THEN '432' + CLM_CNTRL_NO
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'MMAI' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '441' + CLM_CNTRL_NO
			 WHEN SOURCEDATAKEY = '4' AND @LOBCODE = 'C54581391' AND @LOB = 'CAID' AND SYSTEM_SOURCE in  ('SUPERIORVISION','EDPS-SUPERIORVISION') THEN '442' + CLM_CNTRL_NO
			 WHEN @LOB = 'MMAI' AND @LOBCODE = 'C54581391' THEN '51' + CLM_CNTRL_NO
	         WHEN @LOB = 'CAID' AND @LOBCODE = 'C54581391' THEN '52' + CLM_CNTRL_NO
	     END,   
	  --CLM_CNTRL_NO, --[2300I_REF02_ClaimReferenceNumber_3]
      '',      --[2300I_REF01_ClaimReferenceNumberQualifier_4]
      PAT_CNTRL_NO,      --[2300I_REF02_ClaimReferenceNumber_4]
      '',      --[2300I_REF01_ClaimReferenceNumberQualifier_5]
      '',      --[2300I_REF02_ClaimReferenceNumber_5]
      '',      --[2300I_REF01_ClaimReferenceNumberQualifier_6]
      '',      --[2300I_REF02_ClaimReferenceNumber_6]
      '',      --[2300I_REF01_ClaimReferenceNumberQualifier_7]
      '',      --[2300I_REF02_ClaimReferenceNumber_7]
      '',      --[2300I_REF01_ClaimReferenceNumberQualifier_8]
      '',      --[2300I_REF02_ClaimReferenceNumber_8]
      '',      --[2300I_NTE01_ClaimNoteType]
      '',      --[2300I_NTE02_ClaimNote]
      '',      --[2300I_NTE01_BillNoteType]
      '',      --[2300I_NTE01_BillNote]
      '',      --[2300I_CRC01_ServiceCertificationCategory]
      EPSDT_REF_COND_RESP_CD,      --[2300I_CRC02_ServiceCertificationIndicator]
	  EPSDT_REF_COND_IND1,      --[2300I_CRC03_ConditionIndicatorCode]
      EPSDT_REF_COND_IND2,      --[2300I_CRC04_ConditionIndicatorCode]
      EPSDT_REF_COND_IND3,      --[2300I_CRC05_ConditionIndicatorCode]
      PRINCIPAL_DIAG_QUAL,      --[2300I_HI01-01_PrinDXType]
      INST_PRINCIPAL_DIAG_CD,      --[2300I_HI01-02_PrincipalDXCode]
      INST_PRINCIPAL_POA_CD,      --[2300I_HI01-09_PrincipalDXPOA]
      ADMIT_DIAG_QUAL,      --[2300I_HI01-01_AdmittingDXType]
      INST_ADM_DIAG_CD,      --[2300I_HI01-02_AdmittingDXCode]
      REA_VISIT_DIAG_QUAL1,      --[2300I_HI01-01_PatientDXType]
      INST_VISIT_DIAG_CD1,      --[2300I_HI01-02_PatientDXCode]
      REA_VISIT_DIAG_QUAL2,      --[2300I_HI02-01_PatientDXType]
      INST_VISIT_DIAG_CD2,      --[2300I_HI02-02_PatientDXCode]
      REA_VISIT_DIAG_QUAL3,      --[2300I_HI03-01_PatientDXType]
      INST_VISIT_DIAG_CD3,      --[2300I_HI03-02_PatientDXCode]
      INST_EXT_INJ_QUAL1,      --[2300I_HI01-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD1,      --[2300I_HI01-02_ECIDXCode]
      INST_EXT_INJ_POA_IND1,      --[2300I_HI01-09_ECIDXPOA]
      INST_EXT_INJ_QUAL2,      --[2300I_HI02-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD2,      --[2300I_HI02-02_ECIDXCode]
      INST_EXT_INJ_POA_IND2,      --[2300I_HI02-09_ECIDXPOA]
      INST_EXT_INJ_QUAL3,      --[2300I_HI03-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD3,      --[2300I_HI03-02_ECIDXCode]
      INST_EXT_INJ_POA_IND3,      --[2300I_HI03-09_ECIDXPOA]
      INST_EXT_INJ_QUAL4,      --[2300I_HI04-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD4,      --[2300I_HI04-02_ECIDXCode]
      INST_EXT_INJ_POA_IND4,      --[2300I_HI04-09_ECIDXPOA]
      INST_EXT_INJ_QUAL5,      --[2300I_HI05-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD5,      --[2300I_HI05-02_ECIDXCode]
      INST_EXT_INJ_POA_IND5,      --[2300I_HI05-09_ECIDXPOA]
      INST_EXT_INJ_QUAL6,      --[2300I_HI06-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD6,      --[2300I_HI06-02_ECIDXCode]
      INST_EXT_INJ_POA_IND6,      --[2300I_HI06-09_ECIDXPOA]
      INST_EXT_INJ_QUAL7,      --[2300I_HI07-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD7,      --[2300I_HI07-02_ECIDXCode]
      INST_EXT_INJ_POA_IND7,      --[2300I_HI07-09_ECIDXPOA]
      INST_EXT_INJ_QUAL8,      --[2300I_HI08-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD8,      --[2300I_HI08-02_ECIDXCode]
      INST_EXT_INJ_POA_IND8,      --[2300I_HI08-09_ECIDXPOA]
      INST_EXT_INJ_QUAL9,      --[2300I_HI09-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD9,      --[2300I_HI09-02_ECIDXCode]
      INST_EXT_INJ_POA_IND9,      --[2300I_HI09-09_ECIDXPOA]
      INST_EXT_INJ_QUAL10,      --[2300I_HI10-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD10,      --[2300I_HI10-02_ECIDXCode]
      INST_EXT_INJ_POA_IND10,      --[2300I_HI10-09_ECIDXPOA]
      INST_EXT_INJ_QUAL11	,      --[2300I_HI11-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD11,      --[2300I_HI11-02_ECIDXCode]
      INST_EXT_INJ_POA_IND11,      --[2300I_HI11-09_ECIDXPOA]
      INST_EXT_INJ_QUAL12,      --[2300I_HI12-01_ECIDXType]
      INST_EXT_INJ_DIAG_CD12,      --[2300I_HI12-02_ECIDXCode]
      INST_EXT_INJ_POA_IND12,      --[2300I_HI12-09_ECIDXPOA]
      '',      --[2300I_HI01-01_DRGType]
      '',      --[2300I_HI01-02_DRGCode]
      '',      --[20I_DRG_Version]
      '',      --[20I_DRG_Severity]
      '',      --[20I_DRG_Risk]
      DIAG_CD_QUAL1,      --[2300I_HI01-01_DXType_1]
      DIAG_CD1,      --[2300I_HI01-02_DXCode_1]
      POA_IND1,      --[2300I_HI01-09_DXPOA_1]
      DIAG_CD_QUAL2,      --[2300I_HI02-01_DXType_1]
      DIAG_CD2,      --[2300I_HI02-02_DXCode_1]
      POA_IND2,      --[2300I_HI02-09_DXPOA_1]
      DIAG_CD_QUAL3,      --[2300I_HI03-01_DXType_1]
      DIAG_CD3,      --[2300I_HI03-02_DXCode_1]
      POA_IND3,      --[2300I_HI03-09_DXPOA_1]
      DIAG_CD_QUAL4,      --[2300I_HI04-01_DXType_1]
      DIAG_CD4,      --[2300I_HI04-02_DXCode_1]
      POA_IND4,      --[2300I_HI04-09_DXPOA_1]
      DIAG_CD_QUAL5,      --[2300I_HI05-01_DXType_1]
      DIAG_CD5,      --[2300I_HI05-02_DXCode_1]
      POA_IND5,      --[2300I_HI05-09_DXPOA_1]
      DIAG_CD_QUAL6,      --[2300I_HI06-01_DXType_1]
      DIAG_CD6,      --[2300I_HI06-02_DXCode_1]
      POA_IND6,      --[2300I_HI06-09_DXPOA_1]
      DIAG_CD_QUAL7,      --[2300I_HI07-01_DXType_1]
      DIAG_CD7,      --[2300I_HI07-02_DXCode_1]
      POA_IND7,      --[2300I_HI07-09_DXPOA_1]
      DIAG_CD_QUAL8,      --[2300I_HI08-01_DXType_1]
      DIAG_CD8,      --[2300I_HI08-02_DXCode_1]
      POA_IND8,      --[2300I_HI08-09_DXPOA_1]
      DIAG_CD_QUAL9,      --[2300I_HI09-01_DXType_1]
      DIAG_CD9,      --[2300I_HI09-02_DXCode_1]
      POA_IND9,      --[2300I_HI09-09_DXPOA_1]
      DIAG_CD_QUAL10,      --[2300I_HI10-01_DXType_1]
      DIAG_CD10,      --[2300I_HI10-02_DXCode_1]
      POA_IND10,      --[2300I_HI10-09_DXPOA_1]
      DIAG_CD_QUAL11,      --[2300I_HI11-01_DXType_1]
      DIAG_CD11,      --[2300I_HI11-02_DXCode_1]
      POA_IND11,      --[2300I_HI11-09_DXPOA_1]
      DIAG_CD_QUAL12,      --[2300I_HI12-01_DXType_1]
      DIAG_CD12,      --[2300I_HI12-02_DXCode_1]
      POA_IND12,      --[2300I_HI12-09_DXPOA_1]
      DIAG_CD_QUAL13,      --[2300I_HI01-01_DXType_2]
      DIAG_CD13,      --[2300I_HI01-02_DXCode_2]
      POA_IND13,      --[2300I_HI01-09_DXPOA_2]
      DIAG_CD_QUAL14,      --[2300I_HI02-01_DXType_2]
      DIAG_CD14,      --[2300I_HI02-02_DXCode_2]
      POA_IND14,      --[2300I_HI02-09_DXPOA_2]
      DIAG_CD_QUAL15,      --[2300I_HI03-01_DXType_2]
      DIAG_CD15,      --[2300I_HI03-02_DXCode_2]
      POA_IND15,      --[2300I_HI03-09_DXPOA_2]
      DIAG_CD_QUAL16,      --[2300I_HI04-01_DXType_2]
      DIAG_CD16,      --[2300I_HI04-02_DXCode_2]
      POA_IND16,      --[2300I_HI04-09_DXPOA_2]
      DIAG_CD_QUAL17,      --[2300I_HI05-01_DXType_2]
      DIAG_CD17,      --[2300I_HI05-02_DXCode_2]
      POA_IND17,      --[2300I_HI05-09_DXPOA_2]
      DIAG_CD_QUAL18,      --[2300I_HI06-01_DXType_2]
      DIAG_CD18,      --[2300I_HI06-02_DXCode_2]
      POA_IND18,      --[2300I_HI06-09_DXPOA_2]
      DIAG_CD_QUAL19,      --[2300I_HI07-01_DXType_2]
      DIAG_CD19,      --[2300I_HI07-02_DXCode_2]
      POA_IND19,      --[2300I_HI07-09_DXPOA_2]
      DIAG_CD_QUAL20,      --[2300I_HI08-01_DXType_2]
      DIAG_CD20,      --[2300I_HI08-02_DXCode_2]
      POA_IND20,      --[2300I_HI08-09_DXPOA_2]
      DIAG_CD_QUAL21,      --[2300I_HI09-01_DXType_2]
      DIAG_CD21,      --[2300I_HI09-02_DXCode_2]
      POA_IND21,      --[2300I_HI09-09_DXPOA_2]
      DIAG_CD_QUAL22,      --[2300I_HI10-01_DXType_2]
      DIAG_CD22,      --[2300I_HI10-02_DXCode_2]
      POA_IND22,      --[2300I_HI10-09_DXPOA_2]
      DIAG_CD_QUAL23,      --[2300I_HI11-01_DXType_2]
      DIAG_CD23,      --[2300I_HI11-02_DXCode_2]
      POA_IND23,      --[2300I_HI11-09_DXPOA_2]
      DIAG_CD_QUAL24,      --[2300I_HI12-01_DXType_2]
      DIAG_CD24,      --[2300I_HI12-02_DXCode_2]
      POA_IND24,      --[2300I_HI12-09_DXPOA_2]
      DIAG_CD_QUAL25,      --[2300I_HI13-01_DXType_2]
      DIAG_CD25,      --[2300I_HI13-02_DXCode_2]
      POA_IND25,      --[2300I_HI13-09_DXPOA_2]
      DIAG_CD_QUAL26,      --[2300I_HI14-01_DXType_2]
      DIAG_CD26,      --[2300I_HI14-02_DXCode_2]
      POA_IND26,      --[2300I_HI14-09_DXPOA_2]
      OTH_PROC_CD_TYPE_11,      --[2300I_HI01-01_PrincipalPXType]
      OTH_PROC_CD_11,      --[2300I_HI01-02_PrincipalPXCode]
      '',      --[2300I_HI01-03_PrincipalPXDateQualifier]
      OTH_PROC_CD_DT_11,      --[2300I_HI01-04_PrincipalPXDate]
      OTH_PROC_CD_TYPE_12,      --[2300I_HI01-01_PXType_1]
      OTH_PROC_CD_12,      --[2300I_HI01-02_PXCode_1]
      '',      --[2300I_HI01-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_12,      --[2300I_HI01-04_PXDate_1]
      OTH_PROC_CD_TYPE_13,      --[2300I_HI02-01_PXType_1]
      OTH_PROC_CD_13,      --[2300I_HI02-02_PXCode_1]
      '',      --[2300I_HI02-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_13,      --[2300I_HI02-04_PXDate_1]
      OTH_PROC_CD_TYPE_14,      --[2300I_HI03-01_PXType_1]
      OTH_PROC_CD_14,      --[2300I_HI03-02_PXCode_1]
      '',      --[2300I_HI03-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_14,      --[2300I_HI03-04_PXDate_1]
      OTH_PROC_CD_TYPE_15,      --[2300I_HI04-01_PXType_1]
      OTH_PROC_CD_15,      --[2300I_HI04-02_PXCode_1]
      '',      --[2300I_HI04-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_15,      --[2300I_HI04-04_PXDate_1]
      OTH_PROC_CD_TYPE_16,      --[2300I_HI05-01_PXType_1]
      OTH_PROC_CD_16,      --[2300I_HI05-02_PXCode_1]
      '',      --[2300I_HI05-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_16,      --[2300I_HI05-04_PXDate_1]
      OTH_PROC_CD_TYPE_17,      --[2300I_HI06-01_PXType_1]
      OTH_PROC_CD_17,      --[2300I_HI06-02_PXCode_1]
      '',      --[2300I_HI06-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_17,      --[2300I_HI06-04_PXDate_1]
      OTH_PROC_CD_TYPE_18,      --[2300I_HI07-01_PXType_1]
      OTH_PROC_CD_18,      --[2300I_HI07-02_PXCode_1]
      '',      --[2300I_HI07-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_18,      --[2300I_HI07-04_PXDate_1]
      OTH_PROC_CD_TYPE_19,      --[2300I_HI08-01_PXType_1]
      OTH_PROC_CD_19,      --[2300I_HI08-02_PXCode_1]
      '',      --[2300I_HI08-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_19,      --[2300I_HI08-04_PXDate_1]
      OTH_PROC_CD_TYPE_110,      --[2300I_HI09-01_PXType_1]
      OTH_PROC_CD_110,      --[2300I_HI09-02_PXCode_1]
      '',      --[2300I_HI09-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_110,      --[2300I_HI09-04_PXDate_1]
      OTH_PROC_CD_TYPE_111,      --[2300I_HI10-01_PXType_1]
      OTH_PROC_CD_111,      --[2300I_HI10-02_PXCode_1]
      '',      --[2300I_HI10-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_111,      --[2300I_HI10-04_PXDate_1]
      OTH_PROC_CD_TYPE_112,      --[2300I_HI11-01_PXType_1]
      OTH_PROC_CD_112,      --[2300I_HI11-02_PXCode_1]
      '',      --[2300I_HI11-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_112,      --[2300I_HI11-04_PXDate_1]
      OTH_PROC_CD_TYPE_21,      --[2300I_HI12-01_PXType_1]
      OTH_PROC_CD_21,      --[2300I_HI12-02_PXCode_1]
      '',      --[2300I_HI12-03_PXDateQualifier_1]
      OTH_PROC_CD_DT_21,      --[2300I_HI12-04_PXDate_1]
      OTH_PROC_CD_TYPE_22,      --[2300I_HI01-01_PXType_2]
      OTH_PROC_CD_22,      --[2300I_HI01-02_PXCode_2]
      '',      --[2300I_HI01-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_22,      --[2300I_HI01-04_PXDate_2]
      OTH_PROC_CD_TYPE_23,      --[2300I_HI02-01_PXType_2]
      OTH_PROC_CD_23,      --[2300I_HI02-02_PXCode_2]
      '',      --[2300I_HI02-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_23,      --[2300I_HI02-04_PXDate_2]
      OTH_PROC_CD_TYPE_24,      --[2300I_HI03-01_PXType_2]
      OTH_PROC_CD_24,      --[2300I_HI03-02_PXCode_2]
      '',      --[2300I_HI03-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_24,      --[2300I_HI03-04_PXDate_2]
      OTH_PROC_CD_TYPE_25,      --[2300I_HI04-01_PXType_2]
      OTH_PROC_CD_25,      --[2300I_HI04-02_PXCode_2]
      '',      --[2300I_HI04-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_25,      --[2300I_HI04-04_PXDate_2]
      OTH_PROC_CD_TYPE_26,      --[2300I_HI05-01_PXType_2]
      OTH_PROC_CD_26,      --[2300I_HI05-02_PXCode_2]
      '',      --[2300I_HI05-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_26,      --[2300I_HI05-04_PXDate_2]
      OTH_PROC_CD_TYPE_27,      --[2300I_HI06-01_PXType_2]
      OTH_PROC_CD_27,      --[2300I_HI06-02_PXCode_2]
      '',      --[2300I_HI06-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_27,      --[2300I_HI06-04_PXDate_2]
      OTH_PROC_CD_TYPE_28,      --[2300I_HI07-01_PXType_2]
	  OTH_PROC_CD_28,      --[2300I_HI07-02_PXCode_2]
      '',      --[2300I_HI07-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_28,      --[2300I_HI07-04_PXDate_2]
      OTH_PROC_CD_TYPE_29,      --[2300I_HI08-01_PXType_2]
      OTH_PROC_CD_29,      --[2300I_HI08-02_PXCode_2]
      '',      --[2300I_HI08-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_29,      --[2300I_HI08-04_PXDate_2]
      OTH_PROC_CD_TYPE_210,      --[2300I_HI09-01_PXType_2]
      OTH_PROC_CD_210,      --[2300I_HI09-02_PXCode_2]
      '',      --[2300I_HI09-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_210,      --[2300I_HI09-04_PXDate_2]
      OTH_PROC_CD_TYPE_211,      --[2300I_HI10-01_PXType_2]
      OTH_PROC_CD_211,      --[2300I_HI10-02_PXCode_2]
      '',      --[2300I_HI10-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_211,      --[2300I_HI10-04_PXDate_2]
      OTH_PROC_CD_TYPE_212,      --[2300I_HI11-01_PXType_2]
      OTH_PROC_CD_212,      --[2300I_HI11-02_PXCode_2]
      '',      --[2300I_HI11-03_PXDateQualifier_2]
      OTH_PROC_CD_DT_212,      --[2300I_HI11-04_PXDate_2]
      '',      --[2300I_HI12-01_PXType_2]
      '',      --[2300I_HI12-02_PXCode_2]
      '',      --[2300I_HI12-03_PXDateQualifier_2]
      '',      --[2300I_HI12-04_PXDate_2]
      '',      --[2300I_HI01-01_OccurSpanType]
      occ_scode_01,      --[2300I_HI01-02_OccurSpanCode]
      '',      --[2300I_HI01-03_OccurSpanDateQualifier]
      CASE WHEN occ_scode_01 IS NOT NULL THEN concat (occ_SSdate_01, '-',occ_SEdate_01) ELSE '' END,      --[2300I_HI01-04_OccurSpanDate]
      '',      --[2300I_HI02-01_OccurSpanType]
      occ_scode_02,      --[2300I_HI02-02_OccurSpanCode]
      '',      --[2300I_HI02-03_OccurSpanDateQualifier]
	  CASE WHEN occ_scode_02 IS NOT NULL THEN concat (occ_SSdate_02, '-',occ_SEdate_02) ELSE '' END,      --[2300I_HI02-04_OccurSpanDate]
      '',      --[2300I_HI03-01_OccurSpanType]
      occ_scode_03,      --[2300I_HI03-02_OccurSpanCode]
      '',      --[2300I_HI03-03_OccurSpanDateQualifier]
	  CASE WHEN occ_scode_03 IS NOT NULL THEN concat (occ_SSdate_03, '-',occ_SEdate_03) ELSE '' END,      --[2300I_HI03-04_OccurSpanDate]
      '',      --[2300I_HI04-01_OccurSpanType]
      occ_scode_04,      --[2300I_HI04-02_OccurSpanCode]
      '',      --[2300I_HI04-03_OccurSpanDateQualifier]
	  CASE WHEN occ_scode_04 IS NOT NULL THEN concat (occ_SSdate_04, '-',occ_SEdate_04) ELSE '' END,      --[2300I_HI04-04_OccurSpanDate]
      '',      --[2300I_HI05-01_OccurSpanType]
      occ_scode_05,      --[2300I_HI05-02_OccurSpanCode]
      '',      --[2300I_HI05-03_OccurSpanDateQualifier]
	  CASE WHEN occ_scode_05 IS NOT NULL THEN concat (occ_SSdate_05, '-',occ_SEdate_05) ELSE '' END,       --[2300I_HI05-04_OccurSpanDate]
      '',      --[2300I_HI06-01_OccurSpanType]
      occ_scode_06,      --[2300I_HI06-02_OccurSpanCode]
      '',      --[2300I_HI06-03_OccurSpanDateQualifier]
	  CASE WHEN occ_scode_06 IS NOT NULL THEN concat (occ_SSdate_06, '-',occ_SEdate_06) ELSE '' END,      --[2300I_HI06-04_OccurSpanDate]
      '',      --[2300I_HI07-01_OccurSpanType]
      occ_scode_07,      --[2300I_HI07-02_OccurSpanCode]
      '',      --[2300I_HI07-03_OccurSpanDateQualifier]
	 CASE WHEN occ_scode_07 IS NOT NULL THEN concat (occ_SSdate_07, '-',occ_SEdate_07) ELSE '' END,       --[2300I_HI07-04_OccurSpanDate]
      '',      --[2300I_HI08-01_OccurSpanType]
      occ_scode_08,      --[2300I_HI08-02_OccurSpanCode]
      '',      --[2300I_HI08-03_OccurSpanDateQualifier]
	  CASE WHEN occ_scode_08 IS NOT NULL THEN concat (occ_SSdate_08, '-',occ_SEdate_08) ELSE '' END,      --[2300I_HI08-04_OccurSpanDate]
      '',      --[2300I_HI09-01_OccurSpanType]
      occ_scode_09,      --[2300I_HI09-02_OccurSpanCode]
      '',      --[2300I_HI09-03_OccurSpanDateQualifier]
	  CASE WHEN occ_scode_09 IS NOT NULL THEN concat (occ_SSdate_09, '-',occ_SEdate_09) ELSE '' END,       --[2300I_HI09-04_OccurSpanDate]
      '',      --[2300I_HI10-01_OccurSpanType]
      occ_scode_10,      --[2300I_HI10-02_OccurSpanCode]
      '',      --[2300I_HI10-03_OccurSpanDateQualifier]
	  CASE WHEN occ_scode_10 IS NOT NULL THEN concat (occ_SSdate_10, '-',occ_SEdate_10) ELSE '' END,       --[2300I_HI10-04_OccurSpanDate]
      '',      --[2300I_HI11-01_OccurSpanType]
      occ_scode_11,      --[2300I_HI11-02_OccurSpanCode]
      '',      --[2300I_HI11-03_OccurSpanDateQualifier]
	  CASE WHEN occ_scode_11 IS NOT NULL THEN concat (occ_SSdate_11, '-',occ_SEdate_11) ELSE '' END,       --[2300I_HI11-04_OccurSpanDate]
      '',      --[2300I_HI12-01_OccurSpanType]
      occ_scode_12,      --[2300I_HI12-02_OccurSpanCode]
      '',      --[2300I_HI12-03_OccurSpanDateQualifier]
	  CASE WHEN occ_scode_12 IS NOT NULL THEN concat (occ_SSdate_12, '-',occ_SEdate_12) ELSE '' END,       --[2300I_HI12-04_OccurSpanDate]
      '',      --[2300I_HI01-01_OccurType]
      [Occ_Code_01],      --[2300I_HI01-02_OccurCode]
      '',      --[2300I_HI01-03_OccurDateQualifier]
      [Occ_Date_01],      --[2300I_HI01-04_OccurDate]
      '',      --[2300I_HI02-01_OccurType]
      [Occ_Code_02],      --[2300I_HI02-02_OccurCode]
      '',      --[2300I_HI02-03_OccurDateQualifier]
      [Occ_Date_02],      --[2300I_HI02-04_OccurDate]
      '',      --[2300I_HI03-01_OccurType]
      [Occ_Code_03],      --[2300I_HI03-02_OccurCode]
      '',      --[2300I_HI03-03_OccurDateQualifier]
      [Occ_Date_03],      --[2300I_HI03-04_OccurDate]
      '',      --[2300I_HI04-01_OccurType]
      [Occ_Code_04],      --[2300I_HI04-02_OccurCode]
      '',      --[2300I_HI04-03_OccurDateQualifier]
      [Occ_Date_04],      --[2300I_HI04-04_OccurDate]
      '',      --[2300I_HI05-01_OccurType]
      [Occ_Code_05],      --[2300I_HI05-02_OccurCode]
      '',      --[2300I_HI05-03_OccurDateQualifier]
      [Occ_Date_05],      --[2300I_HI05-04_OccurDate]
      '',      --[2300I_HI06-01_OccurType]
      [Occ_Code_06],      --[2300I_HI06-02_OccurCode]
      '',      --[2300I_HI06-03_OccurDateQualifier]
      [Occ_Date_06],      --[2300I_HI06-04_OccurDate]
      '',      --[2300I_HI07-01_OccurType]
      [Occ_Code_07],      --[2300I_HI07-02_OccurCode]
      '',      --[2300I_HI07-03_OccurDateQualifier]
      [Occ_Date_07],      --[2300I_HI07-04_OccurDate]
      '',      --[2300I_HI08-01_OccurType]
      [Occ_Code_08],      --[2300I_HI08-02_OccurCode]
      '',      --[2300I_HI08-03_OccurDateQualifier]
      [Occ_Date_08],      --[2300I_HI08-04_OccurDate]
      '',      --[2300I_HI09-01_OccurType]
      [Occ_Code_09],      --[2300I_HI09-02_OccurCode]
      '',      --[2300I_HI09-03_OccurDateQualifier]
      [Occ_Date_09],      --[2300I_HI09-04_OccurDate]
      '',      --[2300I_HI10-01_OccurType]
      [Occ_Code_10],      --[2300I_HI10-02_OccurCode]
      '',      --[2300I_HI10-03_OccurDateQualifier]
      [Occ_Date_10],      --[2300I_HI10-04_OccurDate]
      '',      --[2300I_HI11-01_OccurType]
      [Occ_Code_11],      --[2300I_HI11-02_OccurCode]
      '',      --[2300I_HI11-03_OccurDateQualifier]
      [Occ_Date_11],      --[2300I_HI11-04_OccurDate]
      '',      --[2300I_HI12-01_OccurType]
      [Occ_Code_12],      --[2300I_HI12-02_OccurCode]
      '',      --[2300I_HI12-03_OccurDateQualifier]
      [Occ_Date_12],      --[2300I_HI12-04_OccurDate]
      '',      --[2300I_HI01-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI01-02_ValueCode_1 ]
      '',      --[2300I_HI01-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI02-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI02-02_ValueCode_1 ]
      '',      --[2300I_HI02-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI03-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI03-02_ValueCode_1 ]
      '',      --[2300I_HI03-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI04-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI04-02_ValueCode_1 ]
      '',      --[2300I_HI04-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI05-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI05-05_ValueCode_1 ]
      '',      --[2300I_HI05-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI06-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI06-02_ValueCode_1 ]
      '',      --[2300I_HI06-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI07-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI07-02_ValueCode_1 ]
      '',      --[2300I_HI07-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI08-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI08-02_ValueCode_1 ]
      '',      --[2300I_HI08-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI09-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI09-02_ValueCode_1 ]
      '',      --[2300I_HI09-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI10-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI10-02_ValueCode_1 ]
      '',      --[2300I_HI10-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI11-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI11-02_ValueCode_1 ]
      '',      --[2300I_HI11-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI12-01_ValueCodeQualifer_1 ]
      '',      --[2300I_HI12-02_ValueCode_1 ]
      '',      --[2300I_HI12-05_ValueCodeAmount_1 ]
      '',      --[2300I_HI01-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI01-02_ValueCode_2 ]
      '',      --[2300I_HI01-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI02-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI02-02_ValueCode_2 ]
      '',      --[2300I_HI02-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI03-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI03-02_ValueCode_2 ]
      '',      --[2300I_HI03-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI04-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI04-02_ValueCode_2 ]
      '',      --[2300I_HI04-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI05-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI05-02_ValueCode_2 ]
      '',      --[2300I_HI05-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI06-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI06-02_ValueCode_2 ]
      '',      --[2300I_HI06-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI07-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI07-02_ValueCode_2 ]
      '',      --[2300I_HI07-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI08-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI08-02_ValueCode_2 ]
      '',      --[2300I_HI08-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI09-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI09-02_ValueCode_2 ]
      '',      --[2300I_HI09-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI10-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI10-02_ValueCode_2 ]
      '',      --[2300I_HI10-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI11-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI11-02_ValueCode_2 ]
      '',      --[2300I_HI11-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI12-01_ValueCodeQualifer_2 ]
      '',      --[2300I_HI12-02_ValueCode_2 ]
      '',      --[2300I_HI12-05_ValueCodeAmount_2 ]
      '',      --[2300I_HI01-01_ConditionCodeQualifier]
      CONDITION1,      --[2300I_HI01-02_ConditionCode ]
      '',      --[2300I_HI02-01_ConditionCodeQualifier]
      CONDITION2,      --[2300I_HI02-02_ConditionCode ]
      '',      --[2300I_HI03-01_ConditionCodeQualifier]
      CONDITION3,      --[2300I_HI03-02_ConditionCode ]
      '',      --[2300I_HI04-01_ConditionCodeQualifier]
      CONDITION4,      --[2300I_HI04-02_ConditionCode ]
      '',      --[2300I_HI05-01_ConditionCodeQualifier]
      CONDITION5,      --[2300I_HI05-02_ConditionCode ]
      '',      --[2300I_HI06-01_ConditionCodeQualifier]
      CONDITION6,      --[2300I_HI06-02_ConditionCode ]
      '',      --[2300I_HI07-01_ConditionCodeQualifier]
      CONDITION7,      --[2300I_HI07-02_ConditionCode ]
      '',      --[2300I_HI08-01_ConditionCodeQualifier]
      CONDITION8,      --[2300I_HI08-02_ConditionCode ]
      '',      --[2300I_HI09-01_ConditionCodeQualifier]
      CONDITION9,      --[2300I_HI09-02_ConditionCode ]
      '',      --[2300I_HI10-01_ConditionCodeQualifier]
      CONDITION10,      --[2300I_HI10-02_ConditionCode ]
      '',      --[2300I_HI11-01_ConditionCodeQualifier]
      CONDITION11,      --[2300I_HI11-02_ConditionCode ]
      '',      --[2300I_HI12-01_ConditionCodeQualifier]
      CONDITION12,      --[2300I_HI12-02_ConditionCode ]
      '',      --[2300I_HI01-01_TreatmentCodeQualifier]
      '',      --[2300I_HI01-02_TreatmentCode ]
      '',      --[2300I_HI02-01_TreatmentCodeQualifier]
      '',      --[2300I_HI02-02_TreatmentCode ]
      '',      --[2300I_HI03-01_TreatmentCodeQualifier]
      '',      --[2300I_HI03-02_TreatmentCode ]
      '',      --[2300I_HI04-01_TreatmentCodeQualifier]
      '',      --[2300I_HI04-02_TreatmentCode ]
      '',      --[2300I_HI05-01_TreatmentCodeQualifier]
      '',      --[2300I_HI05-02_TreatmentCode ]
      '',      --[2300I_HI06-01_TreatmentCodeQualifier]
      '',      --[2300I_HI06-02_TreatmentCode ]
      '',      --[2300I_HI07-01_TreatmentCodeQualifier]
      '',      --[2300I_HI07-02_TreatmentCode ]
      '',      --[2300I_HI08-01_TreatmentCodeQualifier]
      '',      --[2300I_HI08-02_TreatmentCode ]
      '',      --[2300I_HI09-01_TreatmentCodeQualifier]
      '',      --[2300I_HI09-02_TreatmentCode ]
      '',      --[2300I_HI10-01_TreatmentCodeQualifier]
      '',      --[2300I_HI10-02_TreatmentCode ]
      '',      --[2300I_HI11-01_TreatmentCodeQualifier]
      '',      --[2300I_HI11-02_TreatmentCode ]
      '',      --[2300I_HI12-01_TreatmentCodeQualifier]
      '',      --[2300I_HI12-02_TreatmentCode ]
      '',      --[2300I_HCP01_PricingMethod ]
      '',      --[2300I_HCP02_AllowedAmount]
      '',      --[2300I_HCP03_SavingAmount]
      '',      --[2300I_HCP04_OrgID]
      '',      --[2300I_HCP05_PricingRate]
      '',      --[2300I_HCP06_ApprovedDRGCode]
      '',      --[2300I_HCP07_ApprovedDRGAmount]
      '',      --[2300I_HCP08_ApprovedRevenueCode]
      '',      --[2300I_HCP11_Units]
      '',      --[2300I_HCP12_Quatity]
      '',      --[2300I_HCP13_RejectReason]
      '',      --[2300I_HCP14_PolicyCompliance]
      '',      --[2300I_HCP15_ExceptionCode]
      '',      --[2310AI_NM101_ProviderRole]
      '',      --[2310AI_NM102_PersonIndicator]
      ATTN_PROV_LNAME,      --[2310AI_NM103_LastName]
      ATTN_PROV_FNAME,      --[2310AI_NM104_FirstName]
      ATTN_PROV_MIDINIT,      --[2310AI_NM105_MiddleName]
      ATTN_PROV_SFX,      --[2310AI_NM107_Suffix]
      '',      --[2310AI_NM108_ProviderIdentifierQualifer]
      ATTN_PROV_NPI,      --[2310AI_NM109_ProviderIdentifier]
      '',      --[2310AI_PRV01_ProviderCode]
      '',      --[2310AI_PRV02_ProviderCodeQualifer]
      ATTN_PROV_TAXONOMY_CD,      --[2310AI_PRV03_ProviderTaxonomy]
      '',      --[2310AI_REF01_ProviderIdentifierQualifer]
      '',      --[2310AI_REF02_ProviderIdentifier]
      '',      --[2310AI_REF01_ProviderIdentifierQualifer_02]
      '',      --[2310AI_REF02_ProviderIdentifier_02]
      '',      --[2310BI_NM101_ProviderRole]
      '',      --[2310BI_NM102_PersonIndicator]
      OPER_PHYS_LNAME,      --[2310BI_NM103_LastName]
      OPER_PHYS_FNAME,      --[2310BI_NM104_FirstName]
      '',      --[2310BI_NM105_MiddleName]
      OPER_PHYS_SFX,      --[2310BI_NM107_Suffix]
      '',      --[2310BI_NM108_ProviderIdentifierQualifer]
      OPER_PHYS_NPI,      --[2310BI_NM109_ProviderIdentifier]
      '',      --[2310BI_REF01_ProviderIdentifierQualifer]
      '',      --[2310BI_REF02_ProviderIdentifier]
      '',      --[2310BI_REF01_ProviderIdentifierQualifer_02]
      '',      --[2310BI_REF02_ProviderIdentifier_02]
      '',      --[2310CI_NM101_ProviderRole]
      '',      --[2310CI_NM102_PersonIndicator]
      '',      --[2310CI_NM103_LastName]
      '',      --[2310CI_NM104_FirstName]
      '',      --[2310CI_NM105_MiddleName]
      '',      --[2310CI_NM107_Suffix]
      '',      --[2310CI_NM108_ProviderIdentifierQualifer]
      '',      --[2310CI_NM109_ProviderIdentifier]
      '',      --[2310CI_REF01_ProviderIdentifierQualifer]
      '',      --[2310CI_REF02_ProviderIdentifier]
      '',      --[2310CI_REF01_ProviderIdentifierQualifer_02]
      '',      --[2310CI_REF02_ProviderIdentifier_02]
      '',      --[2310DI_NM101_ProviderRole]
      '',      --[2310DI_NM102_PersonIndicator]
      RENDERING_PROV_LAST_NAME,      --[2310DI_NM103_LastName]
      RENDERING_PROV_FIRST_NAME,      --[2310DI_NM104_FirstName]
      RENDERING_PROV_MID_INIT,      --[2310DI_NM105_MiddleName]
      RENDERING_PROV_SFX,      --[2310DI_NM107_Suffix]
      '',      --[2310DI_NM108_ProviderIdentifierQualifer]
      RENDERING_PROV_NPI,      --[2310DI_NM109_ProviderIdentifier]
      '',      --[2310DI_REF01_ProviderIdentifierQualifer]
      '',      --[2310DI_REF02_ProviderIdentifier]
      '',      --[2310DI_REF01_ProviderIdentifierQualifer_02]
      '',      --[2310DI_REF02_ProviderIdentifier_02]
      '',      --[20I_RenderingProviderAddress1]
      '',      --[20I_RenderingProviderAddress2]
      '',      --[20I_RenderingProviderCity]
      '',      --[20I_RenderingProviderState]
      '',      --[20I_RenderingProviderZip]
      '',      --[2310EI_NM101_ProviderRole]
      '',      --[2310EI_NM102_PersonIndicator]
      '',      --[2310EI_NM103_ORG_LastName]
      '',      --[2310EI_NM108_ProviderIdentifierQualifer]
      '',      --[2310EI_NM109_ProviderIdentifier]
      '',      --[2310EI_N301_AddressLine1]
      '',      --[2310EI_N302_AddressLine2]
      '',      --[2310EI_N401_City]
      '',      --[2310EI_N402_State]
      '',      --[2310EI_N403_PostalCode]
      '',      --[2310EI_N404_Country]
      '',      --[2310EI_REF01_ProviderIdentifierQualifer1]
      '',      --[2310EI_REF02_ProviderIdentifier1]
      '',      --[2310EI_REF01_ProviderIdentifierQualifer2]
      '',      --[2310EI_REF02_ProviderIdentifier2]
      '',      --[2310FI_NM101_ProviderRole]
      '',      --[2310FI_NM102_PersonIndicator]
      REF_PROV_LNAME,      --[2310FI_NM103_LastName]
      REF_PROV_FNAME,      --[2310FI_NM104_FirstName]
      REF_PROV_MID_INIT,      --[2310FI_NM105_MiddleName]
      REF_PROV_SFX,      --[2310FI_NM107_Suffix]
      '',      --[2310FI_NM108_ProviderIdentifierQualifer]
      REF_PROV_NPI,      --[2310FI_NM109_ProviderIdentifier]
      '',      --[2310FI_REF01_ProviderIdentifierQualifer]
      '',      --[2310FI_REF02_ProviderIdentifier]
      '',      --[2310FI_REF01_ProviderIdentifierQualifer_02]
      '',      --[2310FI_REF02_ProviderIdentifier_02]
      '',-- OPTIONAL_REPORTING_IND1,      --[2300I_PWK01_AttachmentReportType]
      '',      --[2300I_PWK02_AttachmentTransmissionCode]
      '',      --[2300I_PWK06_AttachmentControlNumber]
      '',      --[2300I_REF01_ServiceAuthorizationExceptionCode_Qualifier]
      '',      --[2300I_REF02_ServiceAuthorizationExceptionCode]
      '',      --[2300I_REF01_InvestigationalDeviceExemptionNumber_Qualifier]
      '',      --[2300I_REF02_InvestigationalDeviceExemptionNumber]
      '',      --[2300I_REF01_DemonstrationProject_Qualifier]
      '',      --[2300I_REF02_DemonstrationProjectIdentifier]
      '',      --[2300I_REF01_PeerReviewOrganization_Qualifier]
      '',      --[2300I_REF02_PeerReviewOrganizationNumber ]
      '',      --[2300I_REF01_FileInformation_Qualifier]
      '',      --[2300I_REF01_FileInformation]
      '',      --[Claim Processor Receiver Date]
      '',      --[InNetworkIndicator ]
      '',      --[PatientControlNumber]
      '',      --[20I-Filler 04]
      '',      --[20I-Filler 05]
      '',      --[20I-Filler 06]
      '',      --[20I-Filler 07]
      '',      --[20I-Filler 08]
      '',      --[20I-IFiller 09]
      '',      --[20I-IFiller 10]
      '',      --[20I-IFiller 11]
      '',      --[20I-IFiller 12]
      '',      --[20I-IFiller 13]
      '',      --[20I-IFiller 14]
      '',      --[20I-IFiller 15]
      '',      --[2300I_HI13-01_OccurSpanType]
      '',      --[2300I_HI13-02_OccurSpanCode]
      '',      --[2300I_HI13-03_OccurSpanDateQualifier]
      '',      --[2300I_HI13-04_OccurSpanDate]
      '',      --[2300I_HI14-01_OccurSpanType]
      '',      --[2300I_HI14-02_OccurSpanCode]
      '',      --[2300I_HI14-03_OccurSpanDateQualifier]
      '',      --[2300I_HI14-04_OccurSpanDate]
      '',      --[2300I_HI15-01_OccurSpanType]
      '',      --[2300I_HI15-02_OccurSpanCode]
      '',      --[2300I_HI15-03_OccurSpanDateQualifier]
      '',      --[2300I_HI15-04_OccurSpanDate]
      '',      --[2300I_HI16-01_OccurSpanType]
      '',      --[2300I_HI16-02_OccurSpanCode]
      '',      --[2300I_HI16-03_OccurSpanDateQualifier]
      '',      --[2300I_HI16-04_OccurSpanDate]
      '',      --[2300I_HI17-01_OccurSpanType]
      '',      --[2300I_HI17-02_OccurSpanCode]
      '',      --[2300I_HI17-03_OccurSpanDateQualifier]
      '',      --[2300I_HI17-04_OccurSpanDate]
      '',      --[2300I_HI18-01_OccurSpanType]
      '',      --[2300I_HI18-02_OccurSpanCode]
      '',      --[2300I_HI18-03_OccurSpanDateQualifier]
      '',      --[2300I_HI18-04_OccurSpanDate]
      '',      --[2300I_HI19-01_OccurSpanType]
      '',      --[2300I_HI19-02_OccurSpanCode]
      '',      --[2300I_HI19-03_OccurSpanDateQualifier]
      '',      --[2300I_HI19-04_OccurSpanDate]
      '',      --[2300I_HI20-01_OccurSpanType]
      '',      --[2300I_HI20-02_OccurSpanCode]
      '',      --[2300I_HI20-03_OccurSpanDateQualifier]
      '',      --[2300I_HI20-04_OccurSpanDate]
      '',      --[2300I_HI21-01_OccurSpanType]
      '',      --[2300I_HI21-02_OccurSpanCode]
      '',      --[2300I_HI21-03_OccurSpanDateQualifier]
      '',      --[2300I_HI21-04_OccurSpanDate]
      '',      --[2300I_HI22-01_OccurSpanType]
      '',      --[2300I_HI22-02_OccurSpanCode]
      '',      --[2300I_HI22-03_OccurSpanDateQualifier]
      '',      --[2300I_HI22-04_OccurSpanDate]
      '',      --[2300I_HI23-01_OccurSpanType]
      '',      --[2300I_HI23-02_OccurSpanCode]
      '',      --[2300I_HI23-03_OccurSpanDateQualifier]
      '',      --[2300I_HI23-04_OccurSpanDate]
      '',      --[2300I_HI24-01_OccurSpanType]
      '',      --[2300I_HI24-02_OccurSpanCode]
      '',      --[2300I_HI24-03_OccurSpanDateQualifier]
      '',      --[2300I_HI24-04_OccurSpanDate]
      '',      --[2300I_HI13-01_OccurType]
      '',      --[2300I_HI13-02_OccurCode]
      '',      --[2300I_HI13-03_OccurDateQualifier]
      '',      --[2300I_HI13-04_OccurDate]
      '',      --[2300I_HI14-01_OccurType]
      '',      --[2300I_HI14-02_OccurCode]
      '',      --[2300I_HI14-03_OccurDateQualifier]
      '',      --[2300I_HI14-04_OccurDate]
      '',      --[2300I_HI15-01_OccurType]
      '',      --[2300I_HI15-02_OccurCode]
      '',      --[2300I_HI15-03_OccurDateQualifier]
      '',      --[2300I_HI15-04_OccurDate]
      '',      --[2300I_HI16-01_OccurType]
      '',      --[2300I_HI16-02_OccurCode]
      '',      --[2300I_HI16-03_OccurDateQualifier]
      '',      --[2300I_HI16-04_OccurDate]
      '',      --[2300I_HI17-01_OccurType]
      '',      --[2300I_HI17-02_OccurCode]
      '',      --[2300I_HI17-03_OccurDateQualifier]
      '',      --[2300I_HI17-04_OccurDate]
      '',      --[2300I_HI18-01_OccurType]
      '',      --[2300I_HI18-02_OccurCode]
      '',      --[2300I_HI18-03_OccurDateQualifier]
      '',      --[2300I_HI18-04_OccurDate]
      '',      --[2300I_HI19-01_OccurType]
      '',      --[2300I_HI19-02_OccurCode]
      '',      --[2300I_HI19-03_OccurDateQualifier]
      '',      --[2300I_HI19-04_OccurDate]
      '',      --[2300I_HI20-01_OccurType]
      '',      --[2300I_HI20-02_OccurCode]
      '',      --[2300I_HI20-03_OccurDateQualifier]
      '',      --[2300I_HI20-04_OccurDate]
      '',      --[2300I_HI21-01_OccurType]
      '',      --[2300I_HI21-02_OccurCode]
      '',      --[2300I_HI21-03_OccurDateQualifier]
      '',      --[2300I_HI21-04_OccurDate]
      '',      --[2300I_HI22-01_OccurType]
      '',      --[2300I_HI22-02_OccurCode]
      '',      --[2300I_HI22-03_OccurDateQualifier]
      '',      --[2300I_HI22-04_OccurDate]
      '',      --[2300I_HI23-01_OccurType]
      '',      --[2300I_HI23-02_OccurCode]
      '',      --[2300I_HI23-03_OccurDateQualifier]
      '',      --[2300I_HI23-04_OccurDate]
      '',      --[2300I_HI24-01_OccurType]
      '',      --[2300I_HI24-02_OccurCode]
      '',      --[2300I_HI24-03_OccurDateQualifier]
      '',      --[2300I_HI24-04_OccurDate]
      '',      --[2300I_HI13-01_TreatmentCodeQualifier]
      '',      --[2300I_HI13-02_TreatmentCode ]
      '',      --[2300I_HI14-01_TreatmentCodeQualifier]
      '',      --[2300I_HI14-02_TreatmentCode ]
      '',      --[2300I_HI15-01_TreatmentCodeQualifier]
      '',      --[2300I_HI15-02_TreatmentCode ]
      '',      --[2300I_HI16-01_TreatmentCodeQualifier]
      '',      --[2300I_HI16-02_TreatmentCode ]
      '',      --[2300I_HI17-01_TreatmentCodeQualifier]
      '',      --[2300I_HI17-02_TreatmentCode ]
      '',      --[2300I_HI18-01_TreatmentCodeQualifier]
      '',      --[2300I_HI18-02_TreatmentCode ]
      '',      --[2300I_HI19-01_TreatmentCodeQualifier]
      '',      --[2300I_HI19-02_TreatmentCode ]
      '',      --[2300I_HI20-01_TreatmentCodeQualifier]
      '',      --[2300I_HI20-02_TreatmentCode ]
      '',      --[2300I_HI21-01_TreatmentCodeQualifier]
      '',      --[2300I_HI21-02_TreatmentCode ]
      '',      --[2300I_HI22-01_TreatmentCodeQualifier]
      '',      --[2300I_HI22-02_TreatmentCode ]
      '',      --[2300I_HI23-01_TreatmentCodeQualifier]
      '',      --[2300I_HI23-02_TreatmentCode ]
      '',      --[2300I_HI24-01_TreatmentCodeQualifier]
      '',      --[2300I_HI24-02_TreatmentCode ]
      '',      --[2300I_HI13-01_ConditionCodeQualifier]
      '',      --[2300I_HI13-02_ConditionCode ]
      '',      --[2300I_HI14-01_ConditionCodeQualifier]
      '',      --[2300I_HI14-02_ConditionCode ]
      '',      --[2300I_HI15-01_ConditionCodeQualifier]
      '',      --[2300I_HI15-02_ConditionCode ]
      '',      --[2300I_HI16-01_ConditionCodeQualifier]
      '',      --[2300I_HI16-02_ConditionCode ]
      '',      --[2300I_HI17-01_ConditionCodeQualifier]
      '',      --[2300I_HI17-02_ConditionCode ]
      '',      --[2300I_HI18-01_ConditionCodeQualifier]
      '',      --[2300I_HI18-02_ConditionCode ]
      '',      --[2300I_HI19-01_ConditionCodeQualifier]
      '',      --[2300I_HI19-02_ConditionCode ]
      '',      --[2300I_HI20-01_ConditionCodeQualifier]
      '',      --[2300I_HI20-02_ConditionCode ]
      '',      --[2300I_HI21-01_ConditionCodeQualifier]
      '',      --[2300I_HI21-02_ConditionCode ]
      '',      --[2300I_HI22-01_ConditionCodeQualifier]
      '',      --[2300I_HI22-02_ConditionCode ]
      '',      --[2300I_HI23-01_ConditionCodeQualifier]
      '',      --[2300I_HI23-02_ConditionCode ]
      '',      --[2300I_HI24-01_ConditionCodeQualifier]
      '',      --[2300I_HI24-02_ConditionCode ]
      '',      --[2300I_REF01_FileInformation2]
      '',      --[2300I_REF01_FileInformation3]
      '',      --[2300I_REF01_FileInformation4]
      '',      --[2300I_REF01_FileInformation5]
      '',      --[2300I_REF01_FileInformation6]
      '',      --[2300I_REF01_FileInformation7]
      '',      --[2300I_REF01_FileInformation8]
      '',      --[2300I_REF01_FileInformation9]
      '',      --[2300I_REF01_FileInformation10]
      '',      --[2310EI_REF01_ProviderIdentifierQualifer3]
      ''    --[2310EI_REF02_ProviderIdentifier3]
FROM WIPRO.dbo.OUTB_INST_HEADER OIH
LEFT OUTER JOIN WIPRO.dbo.OUTB_ClaimOccDate cod ON cod.claimid = OIH.CLAIM_ID
LEFT OUTER JOIN WIPRO.dbo.OUTB_ClaimOccSpanDate cosd ON cosd.claimid = OIH.CLAIM_ID

/*---------------------------------------------------------------------*/
/* POPULATE 310 REC TABLE                                                */
/*---------------------------------------------------------------------*/

INSERT INTO dbo.EE_CSV_310I_Rec_Header_Archive 
SELECT *, getdate()  FROM EE_CSV_310I_Rec_Header

TRUNCATE TABLE [dbo].[EE_CSV_310I_Rec_Header]

INSERT INTO [dbo].[EE_CSV_310I_Rec_Header] (
[ClaimID],
[SourceDataKey],
[SourceDesc],
[CreateDate],
[2320_SBR01_PayerResponsibilitySequence],
[2320_SBR02_SubscriberRelationship],
[2320_SBR09_ClaimFilingIndicator],
[2320_AMT02_COBAmount_1],
[2320_OI03_AssignBenefitsIndicator],
[2330A_NM103_LastName],
[2330A_NM104_FirstName],
[2330A_N301_AddressLine1],
[2330A_N302_AddressLine2],
[2330A_N401_City],
[2330A_N402_State],
[2330A_N403_PostalCode],
[2330B_NM103_Name],
[2330B_NM109_OrganizationIdentifier],
[2330B_N301_AddressLine1],
[2330B_N302_AddressLine2],
[2330B_N401_City],
[2330B_N402_State],
[2330B_N403_PostalCode]
)
SELECT 
claim_id,        -- ClaimID - varchar(20)
SOURCEDATAKEY,         -- SourceDataKey - int
CASE WHEN SYSTEM_SOURCE IN ('50','30') THEN '' ELSE SYSTEM_SOURCE END,        -- SourceDesc - varchar(60)
GETDATE(), -- CreateDate - datetime
PAYER_RESP, -- PayerResponsibilityCode
REL_CD1, --RelationshipCode
CLM_FIL_INDCD1,
AMOUNT_PAID,
ASSIGN_BEN_IND1,
MEMBER_LAST_NAME,
MEMBER_FIRST_NAME,
MEMBER_ADDR1,
MEMBER_ADDR2, 
MEMBER_CITY,
MEMBER_STATE,
MEMBER_ZIP + MEMBER_ZIP4,
OTH_PAYER1_NAME,
OTH_PAYER1_PLANID,
OTH_PAYER1_ADDRESS1,
OTH_PAYER1_ADDRESS2,
OTH_PAYER1_CITY,
OTH_PAYER1_STATE,
[OTH_PAYER1_ZIP] + [OTH_PAYER1_ZIP4]
FROM	WIPRO.dbo.OUTB_INST_HEADER

/*---------------------------------------------------------------------*/
/* UPDATE SYSLOG                                                       */
/*---------------------------------------------------------------------*/

SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_INST_HEADER)
									
				BEGIN TRANSACTION
						UPDATE WIPRO.dbo.EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_EDIFECS_INST_CSV_100I_150I_20I_310I_Header'
										and END_DT is null
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
