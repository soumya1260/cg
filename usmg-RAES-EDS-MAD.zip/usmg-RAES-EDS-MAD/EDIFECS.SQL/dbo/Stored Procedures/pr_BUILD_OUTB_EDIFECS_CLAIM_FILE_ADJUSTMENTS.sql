﻿
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_EDIFECS_CLAIM_FILE_ADJUSTMENTS]  
( @LOB CHAR(10)  --Valid Values (MMAI,MOA)  
 ,@CLAIM_TYPE CHAR(1) --Valid Values (I,P)  
 ,@SOURCEDATAKEY INT   
 ,@JOBID INT = 1   
 ,@ExecutionMode  CHAR(1) = 'M'  
 ,@exclusionmode  char(1) = 'R'  
 ,@LOBCODE VARCHAR(15) = ' '  
 )  
AS  
/***************************************************************************************************  
** CREATE DATE: 09/2014  
**  
** AUTHOR: LOYAL RICKS   
**  
** DESCRIPTION: PROCEDURE WILL EXECUTE REQUIRD STEPS FOR COMPILING WIPRO CLAIM SUBMISSIONS.  
**                
Modification History  
====================  
Date   Who    Description  
-----------------------------------------------------------------------------------------------------  
09/30/14  Loyal Ricks  Added @SOURCEDATAKEY, @LOB , @ExecutionMode, @exclusionmode to  
        professional file sp call  
10/06/14  Loyal Ricks  Added dbo.BUILD_OUTB_PROF_ADJUSTMENTS_WIPRO - testing only, migrate   
        related code in this sp to the standard adjustment sp (BUILD_OUTB_PROF_ADJUSTMENTS)  
        once user acceptance is obtained.    
11/19/14  Loyal Ricks     Add BUILD_OUTB_PROF_DIAG_WIPRO - testing only, migrate   
        related code in this sp to the standard adjustment sp (BUILD_OUTB_PROF_DIAG)  
        once user acceptance is obtained.          
11/24/14  Loyal Ricks  Add pr_BUILD_OUTB_MAO_INST_CLM_FILE    
02/09/15  Loyal Ricks  EDS-706 - Add input parameter @SOURCEDATAKEY for dbo.BUILD_OUTB_PROF_DIAG_WIPRO   
06/10/15  Loyal Ricks  Add @lobcode for MMAI TX and IL files   
06/17/15  Loyal Ricks  Change order of input parameters, assigning @lobcode default value = ' ' and  
        changing parameter order. Moved @lobcode to last parameter for testing of   
        EDS jobs.    
2015-07-23  Loyal Ricks  TETDM-276 Add JOBID to filedesc   
2016-04-11  Loyal Ricks  TETDM-667 Add procedure -  BUILD_OUTB_PROF_AMBULANCEINFO   
2016-06-23  Loyal Ricks  TETDM-825 Add valid value "CAID" for @LOB to support MMAI-CAID submissions   
2016-08-17  Loyal Ricks  Add input parameter @JOBID to  EXECUTE dbo.pr_BUILD_PROF_DME   
2016-09-10  Loyal Ricks  TETDM-988 Professional Denied Claim adjustment added -  DBO.BUILD_OUTB_PROF_DENIED_ADJUSTMENTS_WIPRO           
2017-09-26      JohnBartholomay TETDM-1436 Remove the DME logic for SDK=30  
2018-01-17      JohnBartholomay TETDM-1715 Remove Zero dollar amount CAS segments  
2020-02-17  Anthony Ulmer Stub created for EDIFECS usage  
2020-08-25      Aaron Ridley    TETDM-2337 Added logic to accommodate MMP file naming convention  
2021-02-24      Aaron Ridley    TETDM-2359 Added logic to pass LOBCODE to the Header sprocs   
2021-05-05  Aaron Ridley TETDM-2472 Added logic to allow for 'CAID' LOBCODES  
2022-09-12  Aaron Ridley RETM-131 Added sproc EXECUTE EDIFECS.dbo.CSV_DUPE_CLAIM_DELETE  
2023-06-10  Subhash Acharya RETM-209 added new proc [dbo].[RETRATION_DIAG_OVERLAY]
*****************************************************************************************************/  
      --DECLARE VARIABLES  
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM   
   DECLARE  
     
   @TOTAL_RECORDS INT  
    
  
  
  
          
-- Run controls  
      
     INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG  
       (PROC_NAME  
       ,STEP  
       ,START_DT  
       ,END_DT  
       ,RUN_MINUTES  
       ,TOTAL_RECORDS  
       ,ENTRYDT  
       )  
     VALUES('pr_BUILD_OUTB_EDIFECS_CLAIM_FILE_ADJUSTMENTS' + '-' + rtrim(@LOB) + '-' + rtrim(@CLAIM_TYPE)  
       ,'1'  
       ,GETDATE()  
       ,NULL  
       ,NULL  
       ,0  
       ,GETDATE()  
       )  
       
    
  
     --IF @LOB in ('MMAI','CAID') AND @CLAIM_TYPE = 'P'   
     -- BEGIN   
     --  EXECUTE EDIFECS.dbo.pr_BUILD_OUTB_MMAI_PROF_CLM_FILE_ADJUSTMENTS @LOB,@ExecutionMode,@exclusionmode, @JOBID,@LOBCODE   
     -- END  
  
     --IF @LOB in ('MMAI','CAID')  AND @CLAIM_TYPE = 'I'   
     -- BEGIN  
     --  EXECUTE EDIFECS.dbo.pr_BUILD_OUTB_MMAI_INST_CLM_FILE_ADJUSTMENTS @SOURCEDATAKEY, @LOB,@ExecutionMode,@exclusionmode, @JOBID,@LOBCODE  
     -- END  
     --IF  @LOB = 'MAO' AND @CLAIM_TYPE = 'P'   
     IF  @LOB in ('MAO','MMAI','CAID') AND @CLAIM_TYPE = 'P'  
      BEGIN   
       if @jobid < 10   
        begin   
         EXECUTE WIPRO.dbo.EXSP_WIPRO_CLAIM_EXCLUSION @SOURCEDATAKEY ,@exclusionmode  
        end  
       EXECUTE WIPRO.dbo.pr_BUILD_OUTB_MAO_PROF_CLAIM_HEADER_ADJUSTMENTS @ExecutionMode,@sourcedatakey,@JOBID, @LOB  
       EXECUTE WIPRO.dbo.BUILD_OUTB_PROF_CLM_DETAIL  
       EXECUTE WIPRO.dbo.BUILD_OUTB_PROF_DIAG_WIPRO @SOURCEDATAKEY  
       EXECUTE WIPRO.dbo.BUILD_OUTB_PROF_DIAG_POINTERS  
       EXECUTE WIPRO.dbo.BUILD_OUTB_PROF_EDSPROVIDER  
       EXECUTE WIPRO.dbo.BUILD_OUTB_PROF_ADJUSTMENTS_WIPRO  
       EXECUTE WIPRO.dbo.BUILD_OUTB_PROF_DENIED_ADJUSTMENTS_WIPRO        
       EXECUTE WIPRO.dbo.BUILD_OUTB_PROF_5010  
       EXECUTE WIPRO.dbo.BUILD_OUTB_PROF_AMBULANCEINFO  
       --EXECUTE WIPRO.dbo.pr_BUILD_PROF_DME @JOBID  
       EXECUTE WIPRO.dbo.pr_BUILD_OUTB_PROF_WIPRO_DATASCRUB  
       EXECUTE WIPRO.dbo.pr_BUILD_OUTB_PROF_REMOVE_DUP_ADJUSTMENTS --TETDM-1436  
       EXECUTE WIPRO.dbo.pr_BUILD_OUTB_PROF_REMOVE_ZERO_CAS_AMTS --TETDM-1715 
	   --EXECUTE EDIFECS.[dbo].[RETRATION_DIAG_OVERLAY] --RETM--209
       EXECUTE EDIFECS.[dbo].[pr_EDIFECS_PROF_CSV_100P_150P_20P_310P_Header] @LOB, @LOBCODE, @JOBID  
       EXECUTE EDIFECS.[dbo].[pr_EDIFECS_PROF_CSV_40P_431P_Detail]  
       EXECUTE EDIFECS.dbo.CSV_DUPE_CLAIM_DELETE  
       EXECUTE EDIFECS.dbo.BUILD_OUTB_PROF_MAP @LOB,@LOBCODE,@JOBID  
      END  
     --IF @LOB = 'MAO' AND @CLAIM_TYPE = 'I'   
     IF  @LOB in ('MAO','MMAI','CAID') AND @CLAIM_TYPE = 'I'   
      BEGIN  
       EXECUTE EDIFECS.[dbo].[pr_BUILD_OUTB_MAO_INST_CLM_FILE_ADJUSTMENTS]  @SOURCEDATAKEY, @LOB, @JOBID,@LOBCODE  
      END  
       
  
    --ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM  
      IF @CLAIM_TYPE = 'P'  
       BEGIN     
         SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_PROF_HEADER)  
         SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_PROF_DETAIL)  
       END  
      IF @CLAIM_TYPE = 'I'  
       BEGIN     
         SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_INST_HEADER)  
         SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM WIPRO.dbo.OUTB_INST_DETAIL)  
       END    
  ----HRP_CLAIM_FILE Update Run Controls  
      
      UPDATE WIPRO.dbo.EXT_SYS_RUNLOG  
      SET END_DT = GETDATE()   
       ,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
       ,TOTAL_RECORDS = @TOTAL_RECORDS  
       ,ENTRYDT = GETDATE()  
      WHERE PROC_NAME = 'pr_BUILD_OUTB_EDIFECS_CLAIM_FILE_ADJUSTMENTS' + '-' + rtrim(@LOB) + '-' + rtrim(@CLAIM_TYPE)  
          and END_DT is null
