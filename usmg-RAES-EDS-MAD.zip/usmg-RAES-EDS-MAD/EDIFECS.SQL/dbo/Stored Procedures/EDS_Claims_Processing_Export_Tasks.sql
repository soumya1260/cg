﻿CREATE PROCEDURE [dbo].[EDS_Claims_Processing_Export_Tasks]
(@IsResub BIT = 0) --default to regular run if value not provided
AS



IF @IsResub = 0 BEGIN  
	--update submission date in processing table
	UPDATE ecp
		SET MEDICARESUBMISSIONDATE = GETDATE()	
	FROM WIPRO.dbo.OUTB_CLAIM_MAP_GENERIC ocmg
	JOIN WIPRO.dbo.EDS_Claims_Processing ecp
		ON ocmg.CLAIMID = ecp.CLAIMID
		AND ocmg.SOURCEDATAKEY = ecp.SOURCEDATAKEY
	WHERE ocmg.IsExportDone = 1;

	EXEC WIPRO.dbo.EDS_Claims_Processing_MERGE_Config;--<<--call procedure to update counts on processing table (if not resub)
END
ELSE IF @IsResub = 1 BEGIN
	--update submission date in processing table, reset resub items
	UPDATE ecp
		SET MEDICARESUBMISSIONDATE = GETDATE(),
			ISRESUB = 0	
	FROM WIPRO.dbo.OUTB_CLAIM_MAP_GENERIC ocmg
	JOIN WIPRO.dbo.EDS_Claims_Processing ecp
		ON ocmg.CLAIMID = ecp.CLAIMID
		AND ocmg.SOURCEDATAKEY = ecp.SOURCEDATAKEY
	WHERE ocmg.IsExportDone = 1;
END;

--insert into file hist
INSERT INTO WIPRO.dbo.OUTB_FILE_HIST
(FILEID, FILEDATE,FILENAME,ENTRYDT,TOTAL_CLM,SOURCEDATAKEY,FILEHEADER,FILEFOOTER)
SELECT
	ocmg.File_Name,
	GETDATE(),
	CONCAT(ocmg.File_Name,'.txt'),
	GETDATE(),
	COUNT(DISTINCT ocmg.CLAIMID),
	ocmg.SOURCEDATAKEY,
	--These two selects should only ever return one result per file. Errors here indicate issue with header or trailer generation in map procedure
	(SELECT ocmg1.DATAROW FROM WIPRO.dbo.OUTB_CLAIM_MAP_GENERIC ocmg1 WHERE ocmg1.Record_Type = 'H' AND ocmg1.File_Name = ocmg.File_Name),
	(SELECT ocmg1.DATAROW FROM WIPRO.dbo.OUTB_CLAIM_MAP_GENERIC ocmg1 WHERE ocmg1.Record_Type = 'T' AND ocmg1.File_Name = ocmg.File_Name)	
FROM WIPRO.dbo.OUTB_CLAIM_MAP_GENERIC ocmg
WHERE ocmg.IsExportDone = 1
GROUP BY ocmg.File_Name, ocmg.SOURCEDATAKEY;


--insert into claim status
INSERT INTO WIPRO.dbo.OUTB_CLAIM_STATUS
(CLAIM_ID,CLAIM_TYPE, FILEID,SOURCEDATAKEY, MEMBER_ID,HICN_NUM, LAST_UPD_DATE, FILEDATE)
SELECT DISTINCT
	cl.CLAIMID
   ,cl.CLAIM_TYPE
   ,cl.File_Name
   ,cl.SOURCEDATAKEY
   ,CASE 
		WHEN cl.CLAIM_TYPE = 'I' THEN i.[2010BA_NM109_SubscriberIdentifier]
		WHEN cl.CLAIM_TYPE = 'P' THEN p.[2010BA_NM109_SubscriberIdentifier]
		ELSE NULL
	END
   ,CASE
		WHEN cl.CLAIM_TYPE = 'I' THEN i.[2010BA_REF02_SubscriberIdentifier_2]
		WHEN cl.CLAIM_TYPE = 'P' THEN p.[2010BA_REF02_SubscriberIdentifier_2]
		ELSE NULL
	END
   ,GETDATE()
   ,GETDATE()
FROM WIPRO.dbo.OUTB_CLAIM_MAP_GENERIC cl
LEFT JOIN EDIFECS.dbo.EE_CSV_150I_Rec_Header i
	ON i.ClaimID = cl.CLAIMID
		AND i.SourceDataKey = cl.SOURCEDATAKEY
LEFT JOIN EDIFECS.dbo.EE_CSV_150P_Rec_Header p
	ON p.ClaimID = cl.CLAIMID
		AND p.SourceDataKey = cl.SOURCEDATAKEY
WHERE 1 = 1
	AND cl.Record_Type = 'D'
	AND cl.IsExportDone = 1;