﻿/* 
	Add files here that should be executed against every environment BEFORE deploy occurs:
	Example: table script to drop or archive data before table alter statement
	Use SQLCMD mode to add files here
*/
:r .\CSV_431INST_COLUMN_ALTER.sql
