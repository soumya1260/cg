TRUNCATE TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail];
TRUNCATE TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail];


ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS01_ClaimAdjustmentGroup_1] varchar(100)  null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS02_ClaimAdjustmentReason_1] varchar(100) null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_5] varchar(100) null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_1] varchar(100) null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_2] varchar(100) null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS02_ClaimAdjustmentReason_2] varchar(100) null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_2] varchar(100) null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_3] varchar(100) null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS02_ClaimAdjustmentReason_3] varchar(100) null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_3] varchar(100) null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_5] varchar(100) null;
ALTER TABLE EDIFECS.[staging].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS02_ClaimAdjustmentReason_5] varchar(100) null;

ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS01_ClaimAdjustmentGroup_1] varchar(100)  null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS02_ClaimAdjustmentReason_1] varchar(100) null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_1] varchar(100) null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_2] varchar(100) null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS02_ClaimAdjustmentReason_2] varchar(100) null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_2] varchar(100) null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_3] varchar(100) null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS02_ClaimAdjustmentReason_3] varchar(100) null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_3] varchar(100) null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_5] varchar(100) null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS02_ClaimAdjustmentReason_5] varchar(100) null;
ALTER TABLE EDIFECS.[dbo].[EE_CSV_431I_Rec_Detail] ALTER COLUMN [2430_CAS03_ClaimAdjustmentAmount_5] varchar(100) null;
