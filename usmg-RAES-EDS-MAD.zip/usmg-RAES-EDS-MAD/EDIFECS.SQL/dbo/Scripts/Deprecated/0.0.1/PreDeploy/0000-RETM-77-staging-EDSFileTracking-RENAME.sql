﻿--GO
--IF (SELECT COUNT(*) FROM staging.EDSFileTracking opdh) > 0 
--	AND OBJECT_ID('staging.EDSFileTracking_backup_09212022', 'U') IS NULL BEGIN  

--		SELECT
--			etb.InternalClaimID
--		   ,etb.Encounterid
--		   ,etb.Vendor_Source
--		   ,etb.Supplmental_Flag_Indicator
--		   ,etb.DOSYear
--		   ,etb.ClaimStatFilename
--		   ,etb.Hplan_Extract_File_Name
--		   ,etb.raw999Filename
--		   ,etb.raw277Filename
--		   ,etb.rawMAO02Filename
--		   ,etb.prop999Filename
--		   ,etb.prop277Filename
--		   ,etb.propMAO01Filename
--		   ,etb.propMAO02Filename
--		INTO staging.EDSFileTracking_backup_09212022 etb
--		FROM staging.EDSFileTracking;

--		DELETE FROM staging.EDSFileTracking;
--END;