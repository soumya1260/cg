﻿/* 
	Add files here that should be executed against every environment BEFORE deploy occurs:
	Example: table script to drop or archive data before table alter statement
	Use SQLCMD mode to add files here
*/
--:r .\0000-RETM-77-Archive-OUTB_PROF_DETAIL_HIST_Archive.sql
--:r .\0001-RETM-77-VE-Table-DROP.sql

--:r .\0000-RETM-77-staging-EDSFileTracking-RENAME.sql