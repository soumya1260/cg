﻿/* 
	Add files here that should be executed against every environment AFTER deploy occurs:
	Example: table script to drop or archive data before table alter statement
	Use SQLCMD mode to add files here
*/

--:r .\0000-RETM-77-Insert-staging.EDSFileTracking.sql