﻿GO
IF (SELECT COUNT(*) FROM staging.EDSFileTracking et) = 0 
	AND OBJECT_ID('staging.EDSFileTracking-backup_09212022', 'U') IS NOT NULL BEGIN  
	INSERT INTO staging.EDSFileTracking 
		(InternalClaimID, EncounterClaimID, VendorClaimID, Vendor_Source,
		Supplmental_Flag_Indicator, DOSYear, ClaimStatFilename, Hplan_Extract_File_Name,
		raw999Filename, raw277Filename, prop999Filename, prop277Filename, raw837Filename,
		propSupp999Filename, propSuppMAO002Filename, rawMAO002Filename, propSupp277Filename, propMAO002Filename)
	SELECT
		et.InternalClaimID
	   ,et.EncounterClaimID
	   ,et.VendorClaimID
	   ,et.Vendor_Source
	   ,et.Supplmental_Flag_Indicator
	   ,et.DOSYear
	   ,et.ClaimStatFilename
	   ,et.Hplan_Extract_File_Name
	   ,et.raw999Filename
	   ,et.raw277Filename
	   ,et.prop999Filename
	   ,et.prop277Filename
	   ,et.raw837Filename
	   ,et.propSupp999Filename
	   ,et.propSuppMAO002Filename
	   ,et.rawMAO002Filename
	   ,et.propSupp277Filename
	   ,et.propMAO002Filename
	FROM staging.EDSFileTracking_backup_09212022 et;
END;