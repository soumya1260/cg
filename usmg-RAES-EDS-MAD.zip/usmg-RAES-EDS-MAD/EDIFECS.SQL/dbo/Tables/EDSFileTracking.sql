﻿CREATE TABLE [dbo].[EDSFileTracking] (
    [InternalClaimID]            VARCHAR (50)  NULL,
    [EncounterClaimID]           VARCHAR (50)  NULL,
    [VendorClaimID]              VARCHAR (50)  NULL,
    [Vendor_Source]              VARCHAR (15)  NULL,
    [Supplmental_Flag_Indicator] VARCHAR (6)   NULL,
    [DOSYear]                    DATE          NULL,
    [ClaimStatFilename]          VARCHAR (100) NULL,
    [Hplan_Extract_File_Name]    VARCHAR (100) NULL,
    [raw999Filename]             VARCHAR (100) NULL,
    [raw277Filename]             VARCHAR (100) NULL,
    [prop999Filename]            VARCHAR (100) NULL,
    [prop277Filename]            VARCHAR (100) NULL,
    [raw837Filename]             VARCHAR (100) NULL,
    [propSupp999Filename]        VARCHAR (100) NULL,
    [propSuppMAO002Filename]     VARCHAR (100) NULL,
    [rawMAO002Filename]          VARCHAR (100) NULL,
    [propSupp277Filename]        VARCHAR (100) NULL,
    [propMAO002Filename]         VARCHAR (100) NULL,
    CONSTRAINT [Chk_Val] CHECK ([Supplmental_Flag_Indicator]='' OR [Supplmental_Flag_Indicator]=NULL OR [Supplmental_Flag_Indicator]='99' OR [Supplmental_Flag_Indicator]='88')
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20220106-150021]
    ON [dbo].[EDSFileTracking]([InternalClaimID] ASC, [EncounterClaimID] ASC, [VendorClaimID] ASC, [Vendor_Source] ASC, [prop277Filename] ASC, [raw837Filename] ASC, [propSupp999Filename] ASC, [propSuppMAO002Filename] ASC, [rawMAO002Filename] ASC, [propSupp277Filename] ASC, [propMAO002Filename] ASC);

