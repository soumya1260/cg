﻿CREATE TABLE [dbo].[EDSFileTracking_History] (
    [InternalClaimID]            VARCHAR (50)  NULL,
    [EncounterClaimID]           VARCHAR (50)  NULL,
    [VendorClaimID]              VARCHAR (50)  NULL,
    [Vendor_Source]              VARCHAR (15)  NULL,
    [Supplmental_Flag_Indicator] VARCHAR (6)   NULL,
    [DOSYear]                    DATE          NULL,
    [ClaimStatFilename]          VARCHAR (100) NULL,
    [Hplan_Extract_File_Name]    VARCHAR (100) NULL,
    [raw999Filename]             VARCHAR (100) NULL,
    [raw277Filename]             VARCHAR (100) NULL,
    [prop999Filename]            VARCHAR (100) NULL,
    [prop277Filename]            VARCHAR (100) NULL,
    [raw837Filename]             VARCHAR (100) NULL,
    [propSupp999Filename]        VARCHAR (100) NULL,
    [propSuppMAO002Filename]     VARCHAR (100) NULL,
    [rawMAO002Filename]          VARCHAR (100) NULL,
    [propSupp277Filename]        VARCHAR (100) NULL,
    [propMAO002Filename]         VARCHAR (100) NULL,
    [Date_Archived]              DATE          NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20220110-084455]
    ON [dbo].[EDSFileTracking_History]([InternalClaimID] ASC, [EncounterClaimID] ASC, [VendorClaimID] ASC, [Vendor_Source] ASC, [DOSYear] ASC, [raw277Filename] ASC, [prop999Filename] ASC, [raw837Filename] ASC, [propSupp999Filename] ASC, [rawMAO002Filename] ASC, [Date_Archived] ASC);

