﻿CREATE TABLE [dbo].[Resolve_Environment]
(
	[Server_Name] VARCHAR(50) NOT NULL,
	[Enviornment] VARCHAR(4) NOT NULL
);
GO

CREATE UNIQUE NONCLUSTERED INDEX IDXC_Server_Name
ON dbo.Resolve_Environment (Server_Name ASC) WITH (IGNORE_DUP_KEY = ON);