﻿CREATE TABLE [export].[INST_CLAIM_VOID] (
    [ClaimID]          VARCHAR (50) NULL,
    [ENCOUNTERCLAIMID] VARCHAR (50) NULL,
    [CMSICN]           VARCHAR (50) NULL,
    [LoadDateKey]      DATETIME     NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20200924-160254]
    ON [export].[INST_CLAIM_VOID]([ClaimID] ASC, [ENCOUNTERCLAIMID] ASC, [CMSICN] ASC, [LoadDateKey] ASC);

