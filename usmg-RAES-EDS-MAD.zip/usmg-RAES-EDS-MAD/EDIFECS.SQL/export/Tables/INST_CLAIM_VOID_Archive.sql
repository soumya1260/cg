﻿CREATE TABLE [export].[INST_CLAIM_VOID_Archive] (
    [ClaimID]          VARCHAR (50) NULL,
    [ENCOUNTERCLAIMID] VARCHAR (50) NULL,
    [CMSICN]           VARCHAR (50) NULL,
    [LoadDateKey]      DATETIME     NULL,
    [Archive_Date]     DATETIME     NULL
);


GO
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20200924-160323]
    ON [export].[INST_CLAIM_VOID_Archive]([ClaimID] ASC, [ENCOUNTERCLAIMID] ASC, [CMSICN] ASC, [LoadDateKey] ASC, [Archive_Date] ASC);

