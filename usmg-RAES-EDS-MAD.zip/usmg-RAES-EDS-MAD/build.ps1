param ($buildSql = 1, $buildSSIS = 1, $configuration = 'Release')
try {
    if (Test-Path -Path variable-overrides.ps1) { 
        Write-Host "Importing variable-overrides.ps1" -ForegroundColor DarkBlue -BackgroundColor White
        . .\variable-overrides.ps1
    }

    Write-Host "Current UserName:  $env:UserName" -ForegroundColor DarkBlue -BackgroundColor White
    Write-Host "Current UserDomain:  $env:UserDomain" -ForegroundColor DarkBlue -BackgroundColor White
    Write-Host "Current ComputerName:  $env:ComputerName" -ForegroundColor DarkBlue -BackgroundColor White

    if (Test-Path -Path build-assets/RAES-Build-Assets/README.md) { 
        Write-Host "Pulling build-assets/RAES-Build-Assets" -ForegroundColor DarkBlue -BackgroundColor White
        Push-Location build-assets/RAES-Build-Assets
        git pull
        Pop-Location
    }
    else {
        Write-Host "Cloning build-assets/RAES-Build-Assets" -ForegroundColor DarkBlue -BackgroundColor White
        Push-Location build-assets
        git clone git@github.sys.cigna.com:cigna/RAES-Build-Assets.git
        Pop-Location

    }

    if (Test-Path -Path build-assets/RAES-Build-Assets/publish.ps1) { 
        Write-Host "Importing from publish.ps1" -ForegroundColor DarkBlue -BackgroundColor White
        . .\build-assets/RAES-Build-Assets\publish.ps1
    }
    else {
        Write-Host "Could not find publish.ps1 file." -ForegroundColor DarkRed
        return;
    }

    $pathToDeployments = "$PSScriptRoot\builds"
    $currentBranch = git rev-parse --symbolic-full-name HEAD
    $releaseInfo = Get-VersionFromBranch $currentBranch # Get-VersionFromBranch is defined in jenkins.ps1

    $pathToDeployments = if ([string]::IsNullOrEmpty($pathToDeployments)) { "$PSScriptRoot\build" } else { $pathToDeployments }
    $pathToEnv = "$pathToDeployments\$($releaseInfo.Name)"
    $pathToSqlOutput = "$pathToEnv\sql"
    $pathToSSISOutput = "$pathToEnv\ssis"

    Write-Host "Publising to: $pathToDeployments" -ForegroundColor DarkBlue -BackgroundColor White

    Remove-Item $pathToEnv -Recurse -Force -Confirm:$false -ErrorAction Ignore

    #
    #     BUILD SQL
    #
    if ($buildSql -ne 0) {
        write-host "Building SQL Scripts for branch: $branchName"

        Publish-DacPack $pathToSqlOutput "$PSScriptRoot/EDIFECS.SQL/EDIFECS.SQL.sqlproj" "$PSScriptRoot/EDIFECS.SQL/bin/$configuration/EDIFECS.SQL.dacpac" "$PSScriptRoot/EDIFECS.SQL/EDIFECS.SQL.publish.xml"
        Publish-DacPack $pathToSqlOutput "$PSScriptRoot/WIPRO.SQL/WIPRO.SQL.sqlproj" "$PSScriptRoot/WIPRO.SQL/bin/$configuration/WIPRO.SQL.dacpac" "$PSScriptRoot/WIPRO.SQL/WIPRO.SQL.publish.xml"
        Publish-DacPack $pathToSqlOutput "$PSScriptRoot/WIPRO_Staging.SQL/WIPRO_Staging.SQL.sqlproj" "$PSScriptRoot/WIPRO_Staging.SQL/bin/$configuration/WIPRO_Staging.SQL.dacpac" "$PSScriptRoot/WIPRO_Staging.SQL/WIPRO_Staging.SQL.publish.xml"
        Publish-DacPack $pathToSqlOutput "$PSScriptRoot/EDPS_Data.SQL/EDPS_Data.SQL.sqlproj" "$PSScriptRoot/EDPS_Data.SQL/bin/$configuration/EDPS_Data.SQL.dacpac" "$PSScriptRoot/EDPS_Data.SQL/EDPS_Data.SQL.publish.xml"
    }


    #
    #     BUILD SSIS
    #
    if ($buildSSIS -ne 0) {
        write-host "Building SSIS ISPAC for branch: $branchName"

        Publish-SSIS $pathToSSISOutput $false "$PSScriptRoot/RAES_MAD_EDS_Submission.SSIS"
        Publish-SSIS $pathToSSISOutput $false "$PSScriptRoot/RAES_MAD_Misc_Other"
    }

    write-host "Finished.  Your files are here:  $pathToEnv"
}
catch {
    $_.Exception | Format-List -Force
}