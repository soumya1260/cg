﻿USE WIPRO;
GO
TRUNCATE TABLE dbo.Resolve_Environment;

INSERT INTO dbo.Resolve_Environment (Server_Name, Enviornment)
	VALUES	('cvwsqlxd20020', 'DEV'),('HDCSQLXDW082', 'DEV'),
			('cvwsqlxs20000', 'QA'),('HDCSQLXDW084', 'QA'),
			('CVWSQLXP20006', 'PROD');