﻿USE WIPRO;

UPDATE vvpap
SET Associated_POD_Code = 'IVIOIO'
FROM dbo.vw_VE_Provider_Associated_Podcodes vvpap
WHERE 1 = 1
	AND vvpap.Provider_Group_Name = 'VillageMD'
	AND vvpap.Associated_POD_Code = 'IVIO';