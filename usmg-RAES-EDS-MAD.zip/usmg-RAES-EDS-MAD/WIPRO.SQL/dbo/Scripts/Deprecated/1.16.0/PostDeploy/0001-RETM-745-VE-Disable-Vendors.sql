﻿USE WIPRO;
GO

UPDATE vpgc
SET Is_Active = 0,
	Modified_Date = GETDATE()
FROM dbo.VE_Provider_Group_Control vpgc
WHERE vpgc.Provider_Group_Name IN ('CMG','CFL_Aegis','Cano');