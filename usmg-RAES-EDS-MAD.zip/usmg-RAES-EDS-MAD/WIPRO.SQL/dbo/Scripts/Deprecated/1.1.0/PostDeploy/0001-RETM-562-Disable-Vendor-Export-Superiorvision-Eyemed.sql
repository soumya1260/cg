﻿USE WIPRO;

--disable Superiorvision and EyeMed
UPDATE vendor
SET Is_Active = 0,
	Modified_Date = GETDATE()
FROM dbo.VE_Provider_Group_Control vendor
WHERE 1 = 1
	AND vendor.Provider_Group_Name IN ('Superiorvision','EyeMed')
	AND vendor.Is_Active = 1
	AND vendor.Modified_Date < '2024-02-12'; --date disabled, update only if modified date is <=


--disable MOR for three vendors
UPDATE config
SET  config.Is_Active = 0
	,config.Modified_Date = GETDATE()
FROM dbo.VE_Provider_Group_Control vendor
JOIN dbo.VE_Vendor_Config config ON vendor.VE_PGC_ID = config.VE_PGC_ID
JOIN dbo.VE_Vendor_File_Types files ON config.VE_FT_ID = files.VE_VFT_ID
WHERE 1 = 1
	AND vendor.Provider_Group_Name IN ('CFL_Aegis','CFL_PhysicianTrust','CFL_PhysicianPartner')
	AND files.File_Type = 'MOR'
	AND config.Modified_Date <= '2024-02-12'; --date disabled, update only if modified date is <=