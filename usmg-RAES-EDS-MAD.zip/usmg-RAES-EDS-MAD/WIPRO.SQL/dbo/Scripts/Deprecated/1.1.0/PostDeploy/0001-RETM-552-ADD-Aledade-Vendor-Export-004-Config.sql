﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/


USE WIPRO;
GO

DECLARE @VE_PGC_ID INT
	   ,@VE_FT_ID INT
	   ,@File_Dump VARCHAR(8)
	   ,@Provider_Group_Name VARCHAR(100) = 'Aledade';

--insert Caremax into vendor table if not exists
IF NOT EXISTS (SELECT
			*
		FROM dbo.VE_Provider_Group_Control vpgc
		WHERE vpgc.Provider_Group_Name = @Provider_Group_Name)
BEGIN

	INSERT INTO dbo.VE_Provider_Group_Control (Provider_Group_Name, Is_Active, Modified_Date, Load_Date)
		VALUES (@Provider_Group_Name, 1, GETDATE(), DEFAULT);
END;

SELECT --Get vendor ID
	@VE_PGC_ID = vpgc.VE_PGC_ID
FROM dbo.VE_Provider_Group_Control vpgc
WHERE vpgc.Provider_Group_Name = @Provider_Group_Name;

SELECT --Get file type ID
	@VE_FT_ID = vvft.VE_VFT_ID
FROM dbo.VE_Vendor_File_Types vvft
WHERE vvft.File_Type = 'MAO-004';

--insert 002 + 004 configuration record into config table if not exists
IF NOT EXISTS (SELECT
			*
		FROM dbo.VE_Vendor_Config vvc
		JOIN dbo.VE_Provider_Group_Control vpgc
			ON vvc.VE_PGC_ID = vpgc.VE_PGC_ID
		JOIN dbo.VE_Vendor_File_Types vvft
			ON vvc.VE_FT_ID = vvft.VE_VFT_ID
		WHERE vpgc.Provider_Group_Name = @Provider_Group_Name
		AND vvft.File_Type = 'MAO-004')
BEGIN

	INSERT INTO dbo.VE_Vendor_Config (VE_PGC_ID, VE_FT_ID, Export_Directory, Archive_Directory,
	Email_To_List, Is_Active, Is_Special_Extract_Procedure, Special_Extract_Procedure_Name, Has_Temp_Run_Dates,
	Temp_Run_Date_From, Temp_Run_Date_To, Modified_Date, Vendor_Seed_Date)
		VALUES (@VE_PGC_ID, @VE_FT_ID, 'VE_Files\MAO-004\', '', NULL, 1, 0, NULL, 0, NULL, NULL, DEFAULT, '2022-01-01');
END;


--insert podcode
IF NOT EXISTS (SELECT
			*
		FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
		WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID
		AND vpgapc.Associated_POD_Code = 'MD1016')
BEGIN
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
		VALUES (@VE_PGC_ID, 'MD1016', 1, GETDATE(), DEFAULT);
END;

--insert podcode
IF NOT EXISTS (SELECT
			*
		FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
		WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID
		AND vpgapc.Associated_POD_Code = 'DC1001')
BEGIN
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
		VALUES (@VE_PGC_ID, 'DC1001', 1, GETDATE(), DEFAULT);
END;

--insert podcode
IF NOT EXISTS (SELECT
			*
		FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
		WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID
		AND vpgapc.Associated_POD_Code = 'DE0100')
BEGIN
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
		VALUES (@VE_PGC_ID, 'DE0100', 1, GETDATE(), DEFAULT);
END;
