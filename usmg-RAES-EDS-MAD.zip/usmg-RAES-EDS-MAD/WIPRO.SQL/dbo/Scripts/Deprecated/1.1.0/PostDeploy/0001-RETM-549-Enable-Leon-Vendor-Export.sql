﻿UPDATE vvc
SET Is_Active = 1,
	Modified_Date = GETDATE()
FROM dbo.VE_Provider_Group_Control vpgc
JOIN dbo.VE_Vendor_Config vvc ON vpgc.VE_PGC_ID = vvc.VE_PGC_ID
JOIN dbo.VE_Vendor_File_Types vvft ON vvc.VE_FT_ID = vvft.VE_VFT_ID
WHERE 1 = 1
	AND	vpgc.Provider_Group_Name = 'Leon' 
	AND vvft.File_Type = 'MAO-004'
	AND vpgc.Modified_Date < '2024-02-29';