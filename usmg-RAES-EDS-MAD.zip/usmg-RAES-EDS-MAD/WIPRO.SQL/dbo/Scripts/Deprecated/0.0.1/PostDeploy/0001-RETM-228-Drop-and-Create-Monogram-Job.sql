USE [msdb]
GO

/****** Object:  Job [Monogram_Member_List_Intake_v01]    Script Date: 5/9/2023 1:39:42 PM ******/
--BEGIN TRANSACTION
DECLARE @ReturnCode INT = 0
--/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 5/9/2023 1:39:42 PM ******/
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Monogram_Member_List_Intake_v01')
	EXEC msdb.dbo.sp_delete_job @job_name=N'Monogram_Member_List_Intake_v01', @delete_unused_schedule=1

--END

EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Monogram_Member_List_Intake_v01', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Monogram_Member_List_Intake_v01', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'INTERNAL\M74693', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Execute the SSIS package - Source Data Key is defined in SET VALUES for the package]    Script Date: 5/9/2023 1:39:43 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Execute the SSIS package - Source Data Key is defined in SET VALUES for the package', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/ISSERVER "\"\SSISDB\RAES_MAD_Misc_Other\RAES_MAD_Misc_Other\MOR_File_Import.dtsx\\"" /SERVER "\"HSTNEDSDEVDB01.healthspring.inside\"" /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQLMDQOProxyDEV'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Monogram Monthly Member Import', 
		@enabled=1, 
		@freq_type=16, 
		@freq_interval=2, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20230307, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'b18f61fd-b683-4668-bef5-3ca683a5c2fc'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


