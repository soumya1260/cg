﻿GO
IF  (SELECT COUNT(*) FROM ARCHIVED_MAO_004_Files_Processed) = 0
	AND OBJECT_ID('dbo.ARCHIVED_MAO_004_Files_Processed_09212022', 'U') IS NOT NULL 
BEGIN  
	SET IDENTITY_INSERT ARCHIVED_MAO_004_Files_Processed ON;
	INSERT INTO dbo.ARCHIVED_MAO_004_Files_Processed 
	(TableID, FileName, ProcessFlag, ProcessErrorText, SubmissionInterchangeNo, datetimestamp)	
	SELECT
		amfp.TableID
	   ,amfp.FileName
	   ,amfp.ProcessFlag
	   ,amfp.ProcessErrorText
	   ,amfp.SubmissionInterchangeNo   
	   ,amfp.datetimestamp
	FROM dbo.ARCHIVED_MAO_004_Files_Processed amfp;
	SET IDENTITY_INSERT ARCHIVED_MAO_004_Files_Processed OFF;
END;