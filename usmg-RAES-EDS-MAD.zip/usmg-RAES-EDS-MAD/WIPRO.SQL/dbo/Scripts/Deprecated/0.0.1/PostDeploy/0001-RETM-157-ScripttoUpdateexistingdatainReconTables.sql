/* --------------------------------------------------------------------------------------------------
	RETM-157	December 2022	Scott Waller
   -------------------------------------------------------------------------------------------------- 
*/

USE WIPRO
GO

-------------------------------------------------------------------------------------------
-- First, the dbo.EDS_Claims_Master_Recon table
-------------------------------------------------------------------------------------------
-- regular claims 

	UPDATE	dbo.EDS_Claims_Master_Recon
	SET		EndServiceDate		= CD.EndServiceDateKey,
			BillingProvNPI		= CD.VENDORNPI,
			Gender				= MD.Gender,
			RenderingProvNPI	= (	SELECT	MAX(CDD.PROVIDERNPI)
										FROM	EDPS_Data.dbo.ClaimDetailDim CDD
										WHERE	CDD.sourcedatakey	= ECMR.sourcedatakey
										AND		CDD.claimid			= ECMR.claimid )
	FROM	dbo.EDS_Claims_Master_Recon ECMR
	INNER JOIN EDPS_Data.dbo.CLAIMDIM CD
		ON	CD.SOURCEDATAKEY		= ECMR.sourcedatakey
		AND	CD.CLAIMID				= ECMR.claimid
	LEFT OUTER JOIN	MDQOLib.dbo.MemberDim MD
		ON	MD.MemberID				= ECMR.memberid
-- JUST FYI... 44043600 rows affected 33 min 48 sec in DEV

-------------------------------------------------------------------------------------------
-- encounter claims next....
	UPDATE	dbo.EDS_Claims_Master_Recon
	SET		EndServiceDate		= ECD.EndServiceDateKey,
			BillingProvNPI		= ECD.VendorID,
			Gender				= MD.Gender,
			RenderingProvNPI	= ECD.ProviderID
	FROM	dbo.EDS_Claims_Master_Recon ECMR
	INNER JOIN EDPS_Data.dbo.encounterclaimdim ECD
		ON	ECD.SOURCEDATAKEY		= ECMR.sourcedatakey
		AND	ECD.ClaimNum				= ECMR.claimid
	LEFT OUTER JOIN	MDQOLib.dbo.MemberDim MD
		ON	MD.MemberID				= ECMR.memberid
	WHERE	ECD.ClaimFrequencyCode	= '1' 
	AND		ECD.BeginServiceDateKey	>= 20150101 
    AND		ECD.sourcedatakey			= 4 
	AND		ECD.claimlinenum			= 1
-- 2095733 rows affected 11 min 48 sec in DEV


-------------------------------------------------------------------------------------------
-- Second, the dbo.EDS_Claims_Master_Recon_Archive table
-------------------------------------------------------------------------------------------
-- regular claims 

	UPDATE	dbo.EDS_Claims_Master_Recon_archive
	SET		EndServiceDate		= CD.EndServiceDateKey,
			BillingProvNPI		= CD.VENDORNPI,
			Gender				= MD.Gender,
			RenderingProvNPI	= (	SELECT	MAX(CDD.PROVIDERNPI)
										FROM	EDPS_Data.dbo.ClaimDetailDim CDD
										WHERE	CDD.sourcedatakey	= ECMR.sourcedatakey
										AND		CDD.claimid			= ECMR.claimid )
	FROM	dbo.EDS_Claims_Master_Recon_Archive ECMR
	INNER JOIN EDPS_Data.dbo.CLAIMDIM CD
		ON	CD.SOURCEDATAKEY		= ECMR.sourcedatakey
		AND	CD.CLAIMID				= ECMR.claimid
	LEFT OUTER JOIN	MDQOLib.dbo.MemberDim MD
		ON	MD.MemberID				= ECMR.memberid
-- JUST FYI... 1 rows affected 2 min 16 sec in DEV

-------------------------------------------------------------------------------------------
-- encounter claims next....
	UPDATE	dbo.EDS_Claims_Master_Recon_Archive
	SET		EndServiceDate		= ECD.EndServiceDateKey,
			BillingProvNPI		= ECD.VendorID,
			Gender				= MD.Gender,
			RenderingProvNPI	= ECD.ProviderID
	FROM	dbo.EDS_Claims_Master_Recon_Archive ECMR
	INNER JOIN EDPS_Data.dbo.encounterclaimdim ECD
		ON	ECD.SOURCEDATAKEY		= ECMR.sourcedatakey
		AND	ECD.ClaimNum				= ECMR.claimid
	LEFT OUTER JOIN	MDQOLib.dbo.MemberDim MD
		ON	MD.MemberID				= ECMR.memberid
	WHERE	ECD.ClaimFrequencyCode	= '1' 
	AND		ECD.BeginServiceDateKey	>= 20150101 
    AND		ECD.sourcedatakey			= 4 
	AND		ECD.claimlinenum			= 1
-- 85845 rows affected 56 sec in DEV
