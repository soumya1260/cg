﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'RAES_MAD_EDS WIPRO - Clean up the EDS_CLAIM_FILE_SUMMARY_REPORT')
	EXEC msdb.dbo.sp_delete_job @job_name=N'RAES_MAD_EDS WIPRO - Clean up the EDS_CLAIM_FILE_SUMMARY_REPORT', @delete_unused_schedule=1
GO

USE [msdb]
GO

/****** Object:  Job [RAES_MAD_EDS WIPRO - Clean up the EDS_CLAIM_FILE_SUMMARY_REPORT]    Script Date: 4/18/2023 1:59:15 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 4/18/2023 1:59:15 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'RAES_MAD_EDS WIPRO - Clean up the EDS_CLAIM_FILE_SUMMARY_REPORT', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'RAES_MAD_EDS WIPRO - Clean up the EDS_CLAIM_FILE_SUMMARY_REPORT replaces this job: EDS WIPRO - Clean up the EDS_CLAIM_FILE_SUMMARY_REPORT', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'INTERNAL\C59013', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Step 1]    Script Date: 4/18/2023 1:59:16 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Step 1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/ISSERVER "\"\SSISDB\RAES_MAD_Misc_Other\RAES_MAD_Misc_Other\RAES-MAD-Job_Step_Package.dtsx\"" /SERVER "\"hstnedsdevdb02.healthspring.inside\"" /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /SET "\"\Package.Variables[User::vJobName].Properties[Value]\"";"\"EDS WIPRO - Clean up the EDS_CLAIM_FILE_SUMMARY_REPORT\"" /CALLERINFO SQLAGENT /REPORTING E', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQLMDQOProxyDEV'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO
