﻿/*
Re-insert data after table modification by auto-deploy process
*/


IF NOT EXISTS(SELECT * FROM dbo.SUPP_RAPS_CI_DATA srcd) BEGIN;
INSERT INTO dbo.SUPP_RAPS_CI_DATA
	SELECT
		srcdbr.CMCR_ID
	   ,srcdbr.Member_ID
	   ,srcdbr.Review_Status
	   ,srcdbr.Market_Abbr
	   ,srcdbr.Review_Type
	   ,srcdbr.Event_Type_Desc
	   ,srcdbr.Submit_Source
	   ,srcdbr.Created_Date
	   ,srcdbr.Last_Modified_Date
	   ,srcdbr.Chart_Prov
	   ,srcdbr.Start_Date
	   ,srcdbr.End_Date
	   ,srcdbr.DOS_Results_ID
	   ,srcdbr.Document_Prov_ID
	   ,srcdbr.CMS_Extract_Date
	   ,srcdbr.DX_Code_Result_ID
	   ,srcdbr.ICD_Code
	   ,srcdbr.DX_Code_ID
	   ,srcdbr.Chart_Prov_Spec
	   ,srcdbr.Doc_Prov_Spec
	   ,srcdbr.Appr_Rvw_Stat
	   ,srcdbr.Appr_Spec
	   ,srcdbr.Dos_err
	   ,srcdbr.Dx_Err
	   ,srcdbr.Dos_del
	   ,srcdbr.Dx_del
	   ,srcdbr.CMS_Extract_Elig
	   ,srcdbr.Do_Not_Extract
	   ,srcdbr.DX_Code_Version
	   ,srcdbr.RA_Prov_Type
	   ,srcdbr.Load_Date
	   ,Load_Key = 9999
	   ,srcdbr.CLM_NO
	FROM SUPP_RAPS_CI_DATA_BK_RETM_501_20231114 srcdbr;

	IF @@rowcount > 0 BEGIN; --drop backup table after data reinsertion 
    	DROP TABLE SUPP_RAPS_CI_DATA_BK_RETM_501_20231114;
    END;
    
END;