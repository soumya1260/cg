﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
USE [WIPRO];
GO

/*
This script is just to update the config path on the migrated server.
After the migration, this script is no longer needed.
*/

UPDATE vvc
SET vvc.Export_Directory = IIF(@@servername LIKE 'CVWSQLX%',CONCAT('VE_Files\',vvft.File_Type,'\'),vvc.Export_Directory)
FROM dbo.VE_Vendor_Config vvc
JOIN dbo.VE_Vendor_File_Types vvft ON vvc.VE_FT_ID = vvft.VE_VFT_ID;