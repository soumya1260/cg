﻿USE WIPRO;




/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/


USE WIPRO;
GO

DECLARE @VE_PGC_ID INT,
		@VE_FT_ID INT,
		@File_Dump VARCHAR(8);

--insert Caremax into vendor table if not exists
IF NOT EXISTS (	SELECT
					*
				FROM dbo.VE_Provider_Group_Control vpgc 
				WHERE vpgc.Provider_Group_Name = 'Caremax') BEGIN 

	INSERT INTO dbo.VE_Provider_Group_Control (Provider_Group_Name, Is_Active, Modified_Date, Load_Date)
		VALUES ('Caremax', 1, GETDATE(), DEFAULT);			
END;

SELECT --Get vendor ID
	@VE_PGC_ID = vpgc.VE_PGC_ID
FROM dbo.VE_Provider_Group_Control vpgc
WHERE vpgc.Provider_Group_Name = 'Caremax';

SELECT --Get file type ID
	@VE_FT_ID = vvft.VE_VFT_ID
FROM dbo.VE_Vendor_File_Types vvft
WHERE vvft.File_Type = 'MAO-004';

SET @File_Dump = (SELECT TOP 1 IIF(vee.Server_Environment = 'PROD',NULL,vee.Server_Environment) FROM dbo.vw_EDS_Environment vee);



--insert Caremax 002 + 004 configuration record into config table if not exists
IF NOT EXISTS (	SELECT
					*
				FROM dbo.VE_Vendor_Config vvc
					JOIN dbo.VE_Provider_Group_Control vpgc ON vvc.VE_PGC_ID = vpgc.VE_PGC_ID
					JOIN dbo.VE_Vendor_File_Types vvft ON vvc.VE_FT_ID = vvft.VE_VFT_ID
				WHERE vpgc.Provider_Group_Name = 'Caremax' AND vvft.File_Type = 'MAO-004') BEGIN 

	INSERT INTO dbo.VE_Vendor_Config (VE_PGC_ID, VE_FT_ID, Export_Directory, Archive_Directory,
		Email_To_List, Is_Active, Is_Special_Extract_Procedure, Special_Extract_Procedure_Name, Has_Temp_Run_Dates, 
		Temp_Run_Date_From, Temp_Run_Date_To, Modified_Date, Vendor_Seed_Date)
		VALUES (@VE_PGC_ID,
				@VE_FT_ID,
				CONCAT('VE_Files\MAO-004\',	@File_Dump),
				'',
				NULL,
				1,
				0,
				NULL,
				0,
				NULL,
				NULL,
				DEFAULT,
				'2022-01-01');	
END;

SELECT --Get file type ID
	@VE_FT_ID = vvft.VE_VFT_ID
FROM dbo.VE_Vendor_File_Types vvft
WHERE vvft.File_Type = 'MAO-002';

IF NOT EXISTS (	SELECT
					*
				FROM dbo.VE_Vendor_Config vvc
					JOIN dbo.VE_Provider_Group_Control vpgc ON vvc.VE_PGC_ID = vpgc.VE_PGC_ID
					JOIN dbo.VE_Vendor_File_Types vvft ON vvc.VE_FT_ID = vvft.VE_VFT_ID
				WHERE vpgc.Provider_Group_Name = 'Caremax' AND vvft.File_Type = 'MAO-002') BEGIN 

	INSERT INTO dbo.VE_Vendor_Config (VE_PGC_ID, VE_FT_ID, Export_Directory, Archive_Directory,
		Email_To_List, Is_Active, Is_Special_Extract_Procedure, Special_Extract_Procedure_Name, Has_Temp_Run_Dates, 
		Temp_Run_Date_From, Temp_Run_Date_To, Modified_Date, Vendor_Seed_Date)
		VALUES (@VE_PGC_ID,
				@VE_FT_ID,
				CONCAT('VE_Files\MAO-002\',	@File_Dump),
				'',
				NULL,
				1,
				0,
				NULL,
				0,
				NULL,
				NULL,
				DEFAULT,
				'2022-01-01');	
END;

--insert single podcode for Caremax
IF NOT EXISTS( 	SELECT * 
				FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
				WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID AND vpgapc.Associated_POD_Code = 'CT0006 ')
BEGIN 
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
	VALUES (@VE_PGC_ID, 'CT0006 ', 1, GETDATE(), DEFAULT);
END;

IF NOT EXISTS( 	SELECT * 
				FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
				WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID AND vpgapc.Associated_POD_Code = 'FL9006')
BEGIN 
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
	VALUES (@VE_PGC_ID, 'FL9006', 1, GETDATE(), DEFAULT);
END;

IF NOT EXISTS( 	SELECT * 
				FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
				WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID AND vpgapc.Associated_POD_Code = 'FL9007')
BEGIN 
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
	VALUES (@VE_PGC_ID, 'FL9007', 1, GETDATE(), DEFAULT);
END;

IF NOT EXISTS( 	SELECT * 
				FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
				WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID AND vpgapc.Associated_POD_Code = 'IL0098')
BEGIN 
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
	VALUES (@VE_PGC_ID, 'IL0098', 1, GETDATE(), DEFAULT);
END;

IF NOT EXISTS( 	SELECT * 
				FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
				WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID AND vpgapc.Associated_POD_Code = 'MO0010 ')
BEGIN 
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
	VALUES (@VE_PGC_ID, 'MO0010 ', 1, GETDATE(), DEFAULT);
END;

IF NOT EXISTS( 	SELECT * 
				FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
				WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID AND vpgapc.Associated_POD_Code = 'TN0362')
BEGIN 
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
	VALUES (@VE_PGC_ID, 'TN0362', 1, GETDATE(), DEFAULT);
END;

IF NOT EXISTS( 	SELECT * 
				FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
				WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID AND vpgapc.Associated_POD_Code = 'NY0031')
BEGIN 
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
	VALUES (@VE_PGC_ID, 'NY0031', 1, GETDATE(), DEFAULT);
END;

IF NOT EXISTS( 	SELECT * 
				FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
				WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID AND vpgapc.Associated_POD_Code = 'OH0026')
BEGIN 
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
	VALUES (@VE_PGC_ID, 'OH0026', 1, GETDATE(), DEFAULT);
END;

IF NOT EXISTS( 	SELECT * 
				FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
				WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID AND vpgapc.Associated_POD_Code = 'PA0118')
BEGIN 
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
	VALUES (@VE_PGC_ID, 'PA0118', 1, GETDATE(), DEFAULT);
END;

IF NOT EXISTS( 	SELECT * 
				FROM dbo.VE_Provider_Group_Associated_POD_Codes vpgapc
				WHERE vpgapc.VE_PGC_ID = @VE_PGC_ID AND vpgapc.Associated_POD_Code = 'TX1446')
BEGIN 
	INSERT INTO dbo.VE_Provider_Group_Associated_POD_Codes (VE_PGC_ID, Associated_POD_Code, Is_Active, Modified_Date, Load_Date)
	VALUES (@VE_PGC_ID, 'TX1446', 1, GETDATE(), DEFAULT);
END;