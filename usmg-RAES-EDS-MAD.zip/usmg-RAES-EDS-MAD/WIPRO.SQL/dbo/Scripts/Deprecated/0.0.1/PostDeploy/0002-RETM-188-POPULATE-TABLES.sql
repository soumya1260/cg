-- RETM-186	Scott Waller	April 2023
-- populate the Job/Step Runner Tables


-- RETM-188
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDIFECS EDS_ADJUSTMENT_HISTORY_BUILD', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDIFECS EDS_ADJUSTMENT_HISTORY_BUILD', 1, 'SCRIPT',
		 'EXEC EDIFECS.dbo.pr_OUTB_ADJUSTMENTS_PROC_DIAG_COMP', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDIFECS EDS_ADJUSTMENT_HISTORY_BUILD', 2, 'SCRIPT',
		 'EXEC WIPRO.dbo.pr_BUILD_OUTB_ADJUSTMENTS_HISTORICAL', 'N' )


-- RETM-189
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS - Claims Master Recon ARCHIVE', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS - Claims Master Recon ARCHIVE', 1, 'SCRIPT',
		 'EXEC dbo.EDS_Claims_Master_Recon_Archive_Data', 'N' )


-- RETM-190
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS - Claims Master Recon LOAD', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS - Claims Master Recon LOAD', 1, 'SCRIPT',
		 'EXEC dbo.EDS_Claims_Master_Recon_LOAD', 'N' )
		 

-- RETM-191
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS - Update Master Recon HCC Eligible', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS - Update Master Recon HCC Eligible', 1, 'SCRIPT',
		 'EXEC [dbo].[usp_update_Master_Recon_Table]', 'N' )


-- RETM-192
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS WIPRO - Claim Exclusions Build v2', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Claim Exclusions Build v2', 1, 'SCRIPT',
		 'EXEC WIPRO.dbo.EXSP_CLAIM_RECON_MMAI', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Claim Exclusions Build v2', 2, 'SCRIPT',
		 'EXEC WIPRO.dbo.EXSP_CLAIM_EXCLUSION_HIST', 'N' )

-- this job for the past couple years, has skipped over step # 3.  It's a recon task that we just dont do/use anymore

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Claim Exclusions Build v2', 4, 'SCRIPT',
		 'EXEC WIPRO.dbo.BUILD_ENCOUNTER_CLAIM_EXCLUSIONS', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Claim Exclusions Build v2', 5, 'SCRIPT',
		 'EXEC WIPRO.dbo.pr_BUILD_ENCOUNTER_DME', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Claim Exclusions Build v2', 6, 'SCRIPT',
'INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG (PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
VALUES (''Delete Accepted Claims'', ''6'', GETDATE(), NULL, NULL, 0, GETDATE() )

DELETE ext 
FROM WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST ext 
WHERE EXISTS (SELECT * 
              FROM WIPRO.dbo.OUTB_CLAIM_STATUS ocs 
              WHERE 1 = 1 
              AND ocs.CLAIM_ID = ext.claim_id 
              AND ocs.SOURCEDATAKEY = ext.SOURCEDATAKEY 
              AND ocs.CLMSTAT_STATUS IN ( ''A'', ''A-999'',''A-277'',''A-ICN'')) 
			  
UPDATE WIPRO.dbo.EXT_SYS_RUNLOG 
SET END_DT = GETDATE(), RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()), ENTRYDT = GETDATE()
WHERE PROC_NAME = ''Delete Accepted Claims'' 
AND END_DT IS NULL', 
'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Claim Exclusions Build v2', 7, 'SCRIPT',
'INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG (PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT) 
VALUES(''Claim Exclusion Hist to Archive Job'', ''7'', GETDATE(), NULL, NULL, 0, GETDATE() ) 

delete from EXT_CLAIM_EXCLUSION_HIST_Archive 
where INSERT_RUN_DT < dateadd(m,-2,getdate()) 

INSERT INTO Wipro.dbo.EXT_CLAIM_EXCLUSION_HIST_Archive 
(claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type, INSERT_RUN_DT) 
select claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type, getdate() 
from Wipro.dbo.EXT_CLAIM_EXCLUSION_HIST 

UPDATE WIPRO.dbo.EXT_SYS_RUNLOG 
SET END_DT = GETDATE(), RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()), ENTRYDT = GETDATE() 
WHERE PROC_NAME = ''Claim Exclusion Hist to Archive Job'' 
AND END_DT IS NULL ', 
'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Claim Exclusions Build v2', 8, 'SCRIPT',
		 'EXEC WIPRO.dbo.pr_Compliance_Filter', 'N' )


-- RETM-193
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS WIPRO - Clean up the EDS_CLAIM_FILE_SUMMARY_REPORT', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Clean up the EDS_CLAIM_FILE_SUMMARY_REPORT', 1, 'SCRIPT',
		 ' delete from OUTB_CLAIM_STATUS where fileid in (select fileid from OUTB_FILE_HIST where filename = ''{Undefined}'')  
		   delete from outb_file_hist where filename = ''{Undefined}''', 'N' )


-- RETM-194
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS WIPRO - Report Tables Daily Build', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Report Tables Daily Build', 1, 'SCRIPT',
		 'EXEC WIPRO.reporting.pr_ConsolidatedClaimRejects_Build', 'Y' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Report Tables Daily Build', 2, 'SCRIPT',
		 'EXEC WIPRO.reporting.pr_ClaimRejectSummary_Build', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Report Tables Daily Build', 3, 'SCRIPT',
		 'EXEC WIPRO.reporting.pr_ClaimExclusionSummary_Build', 'N' )

-- job parameters
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_PARAMETERS
	(JOBNAME, STEPNO, Parameter_Number, Parameter_String, Parameter_Value)
VALUES	('EDS WIPRO - Report Tables Daily Build', 1, 1, 'N', '1')


-- RETM-195
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS WIPRO - Run EDS_Audit prBIDWLoadAudit Procedure', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS WIPRO - Run EDS_Audit prBIDWLoadAudit Procedure', 1, 'SCRIPT',
		 'EXEC EDS_Audit.dbo.prBIDWLoadAudit', 'N' )


-- RETM-196
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS_ADJUSTMENT_HISTORY_BUILD', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS_ADJUSTMENT_HISTORY_BUILD', 1, 'SCRIPT',
		 'EXEC WIPRO.dbo.pr_BUILD_OUTB_ADJUSTMENTS_HISTORICAL', 'N' )
		 

-- RETM-197
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS_Claim_Supplemental_MAO004', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS_Claim_Supplemental_MAO004', 1, 'SCRIPT',
		 'EXEC WIPRO.dbo.usp_Load_EDS_Claim_Supplemental_MAO004', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS_Claim_Supplemental_MAO004', 2, 'SCRIPT',
		 'EXEC WIPRO.dbo.usp_Load_EDS_Claim_Supplemental_MAO004_update', 'N' )


-- RETM-198
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS_Service_Line_Dup_Processing', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS_Service_Line_Dup_Processing', 1, 'SCRIPT',
		 'EXEC WIPRO.dbo.USP_LOAD_Service_Line_Dup_Processing

declare @cnt int, @bodys varchar(1000)

set @bodys = ''HSTNEDSDB01: Service_Line_Dup_Processing complete - insert into Test bed''

EXEC msdb.dbo.sp_send_dbmail @profile_name = NULL,
									 
@recipients = ''MDQOEDSSupport@cigna.com;Subhash.Achara@cigna.com;Ashwini.Maravanthe@healthspring.com;mandy.payne@cigna.com'', @body = @bodys, @subject = ''HSTNEDSDB01: Service_Line_Dup_Processing complete - insert into Test bed'';', 'N' )


-- RETM-199
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EXECUTE_EDS_ComplianceFilter_Hold', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EXECUTE_EDS_ComplianceFilter_Hold', 1, 'SCRIPT',
		 'WAITFOR DELAY ''00:30:00''

DECLARE @JOB_NAME SYSNAME = N''EDS_ComplianceFilter_Hold'';

-- Make sure to only execute if there are claims to be loaded
IF EXISTS (
SELECT TOP 1 1 
FROM WIPRO.STAGING.DX_COMPLIANCE_HOLD 
WHERE CONVERT(DATE,ETL_DATE) = CONVERT(DATE,GETDATE()) )

EXEC MSDB.DBO.SP_START_JOB @JOB_NAME
', 'N' )


-- RETM-200
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('Identify_Serviceline_Duplicates', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('Identify_Serviceline_Duplicates', 1, 'SCRIPT',
		 'Execute WIPRO.dbo.usp_Service_Line_Dup_Processing_table_load', 'N' )


-- RETM-201
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('Supp_Populate_Supplement_Input_From_Sources', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('Supp_Populate_Supplement_Input_From_Sources', 1, 'SCRIPT',
		 'EXEC WIPRO.dbo.pr_SUPP_CLM_DIAG_COUNTS', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('Supp_Populate_Supplement_Input_From_Sources', 2, 'SCRIPT',
		 'EXEC WIPRO.dbo.pr_SUPP_RAPS_CI_DATA', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('Supp_Populate_Supplement_Input_From_Sources', 3, 'SCRIPT',
		 'EXEC WIPRO.dbo.pr_SUPP_ADHOC_INPUT', 'N' )


-- RETM-202
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('Supp_Run_ALL_Supplemental_Filters', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('Supp_Run_ALL_Supplemental_Filters', 1, 'SCRIPT',
		 'EXEC WIPRO.dbo.pr_SUPP_CLM_DIAG_COUNTS', 'N' )


-- RETM-215
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS EDIFECS - Claim Adjustment Submissions JOBS', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS EDIFECS - Claim Adjustment Submissions JOBS', 45, 'SCRIPT',
		 'INSERT INTO WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS_BKUP
SELECT * 
FROM  WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS 
WHERE CLAIMID IN (SELECT CLAIM_ID FROM WIPRO.dbo.OUTB_CLAIM_STATUS) 

DELETE a
FROM WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS a
WHERE CLAIMID IN (SELECT CLAIM_ID FROM WIPRO.dbo.OUTB_CLAIM_STATUS)

INSERT INTO WIPRO.dbo.Leon_Adjustments_Archive
SELECT *, GETDATE() 
FROM  WIPRO.dbo.Leon_Adjustments
WHERE Adjustment_claim_id IN (SELECT CLAIM_ID FROM WIPRO.dbo.OUTB_CLAIM_STATUS) 

DELETE a
FROM WIPRO.dbo.Leon_Adjustments a
WHERE Adjustment_claim_id IN (SELECT CLAIM_ID FROM WIPRO.dbo.OUTB_CLAIM_STATUS)', 'N' )


-- RETM-216
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS EDIFECS OUTB_CLAIM_STATUS', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS EDIFECS OUTB_CLAIM_STATUS', 2, 'SCRIPT',
		 'UPDATE P
SET p.CMS_ICN = T.CMS_ICN
,p.CLMSTAT_STATUS = T.CLMSTAT_STATUS
,p.LAST_UPD_DATE = convert(Datetime,substring(T.LAST_UPD_DATE,1,19)) 
,P.SecondaryPlanClaimNumber = ''EdifecsUpdate''
,p.WIPRO_CLAIM_ID = t.WIPRO_CLAIM_ID
,p.STAT_REJ_REA_ID = LEFT(t.STAT_REJ_REA_ID,8)
,p.REJ_REA_MSG = LEFT(t.REJ_REA_MSG,200) 
FROM [WIPRO].STAGING.[OUTB_CLAIM_STATUS] T
JOIN [WIPRO].[DBO].[OUTB_CLAIM_STATUS] P
ON 1 = 1
AND t.[CLAIM_ID] = p.claim_id 
AND t.fileID  = p.FILEID
AND P.FILEDATE > ''20200701''
where (isnull(p.CLMSTAT_STATUS,'''') <> ''A-ICN'' )', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS EDIFECS OUTB_CLAIM_STATUS', 3, 'SCRIPT',
		 'UPDATE P 
SET p.CMS_ICN = T.CMS_ICN 
,p.CLMSTAT_STATUS = T.CLMSTAT_STATUS 
,p.LAST_UPD_DATE = convert(Datetime,substring(T.LAST_UPD_DATE,1,19)) 
,P.SecondaryPlanClaimNumber = ''EdifecsUpdate'' 
,p.WIPRO_CLAIM_ID = t.WIPRO_CLAIM_ID 
,p.STAT_REJ_REA_ID = LEFT(t.STAT_REJ_REA_ID,8) 
,p.REJ_REA_MSG = LEFT(t.REJ_REA_MSG,200) 
FROM [WIPRO].STAGING.[OUTB_CLAIM_STATUS] T 
JOIN [WIPRO].[DBO].[OUTB_CLAIM_STATUS] P 
ON 1 = 1 
AND t.[CLAIM_ID] = p.claim_id  
AND t.fileID  = p.FIELD_TYPE 
AND P.FILEDATE > ''20200701'' 
where (isnull(p.CLMSTAT_STATUS,'''') <> ''A-ICN'' )', 'N' ) 

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS EDIFECS OUTB_CLAIM_STATUS', 4, 'SCRIPT',
		 ';WITH CTE AS ( 
SELECT CLAIM_ID, SOURCEDATAKEY 
FROM WIPRO.DBO.[EXT_CLAIM_EXCLUSION_HIST] ) 
UPDATE  RE 
SET RE.CLAIM_STATUS = ''EXCLUSION'' 
,RE.LASTMODIFIEDDATE = GETDATE() 
from WIPRO.dbo.EDS_Claims_Master_Recon re 
join cte c 
ON  C.CLAIM_ID       = RE.CLAIMID 
AND C.SOURCEDATAKEY  = RE.SOURCEDATAKEY 

;WITH CTE AS ( 
SELECT CLMSTAT_STATUS,LAST_UPD_DATE,CMS_ICN, CLAIM_ID, SOURCEDATAKEY, FILEDATE 
, ROW_NUMBER() OVER(PARTITION BY  CLAIM_ID, SOURCEDATAKEY ORDER BY  FILEDATE DESC) AS RWNUM 
FROM WIPRO.DBO.OUTB_CLAIM_STATUS ) 
UPDATE  RE 
SET RE.CLAIM_STATUS = C.CLMSTAT_STATUS 
, RE.STATUSDATE = C.LAST_UPD_DATE 
,RE.LASTMODIFIEDDATE = GETDATE() 
,RE.CMS_ICN = C.CMS_ICN 
FROM (SELECT * FROM WIPRO.DBO.EDS_CLAIMS_MASTER_RECON 
		WHERE (ISNULL(CLAIM_STATUS,'''') NOT IN  (''A-ICN'') )) RE 
JOIN CTE C 
ON  C.CLAIM_ID       = RE.CLAIMID 
AND C.SOURCEDATAKEY  = RE.SOURCEDATAKEY 
WHERE C.RWNUM = 1 
and RE.SOURCEDATAKEY in (''30'',''50'') 

;WITH CTE AS ( 
SELECT CLMSTAT_STATUS,LAST_UPD_DATE,CMS_ICN, CLAIM_ID, SOURCEDATAKEY, FILEDATE 
, case when fileid like ''%.ADV%'' then  ''ADVOCATE'' 
       when fileid like ''%.SUP%'' then  ''SUPERIORVISION'' 
	   when fileid like ''%.WEL%'' then ''WELLMED''  
	   when fileid like ''%.PROS%'' then  ''PROSPECT'' 
	   when fileid like ''%.SWE%'' then  ''SWEDISH'' 
	    when fileid like ''%.EYE%'' then  ''EYEMED'' END AS sourcedesc 
, ROW_NUMBER() OVER(PARTITION BY  CLAIM_ID, SOURCEDATAKEY ORDER BY  FILEDATE DESC) AS RWNUM 
FROM WIPRO.DBO.OUTB_CLAIM_STATUS ) 
UPDATE  RE 
SET RE.CLAIM_STATUS = C.CLMSTAT_STATUS 
, RE.STATUSDATE = C.LAST_UPD_DATE 
,RE.LASTMODIFIEDDATE = GETDATE() 
,RE.CMS_ICN = C.CMS_ICN 
FROM (SELECT * FROM WIPRO.DBO.EDS_CLAIMS_MASTER_RECON 
		WHERE (ISNULL(CLAIM_STATUS,'''') NOT IN  (''A-ICN'') )) RE 
JOIN CTE C 
ON  C.CLAIM_ID       = RE.CLAIMID 
AND C.SOURCEDATAKEY  = RE.SOURCEDATAKEY 
and c.sourcedesc = re.sourcedesc 
WHERE C.RWNUM = 1 
and RE.SOURCEDATAKEY in (''4'') 

EXEC msdb.dbo.sp_send_dbmail @profile_name = NULL,
@recipients = ''MDQOEDSSupport@cigna.com;Subhash.Achara@cigna.com;Ashwini.Maravanthe@healthspring.com'',
 @body = ''HSTNEDSDB01: EDS_CLAIMS_MASTER_RECON update Successful'',
 @subject = ''HSTNEDSDB01: EDS_CLAIMS_MASTER_RECON update Successful'';
', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS EDIFECS OUTB_CLAIM_STATUS', 5, 'SCRIPT',
		 'update a 
SET a.Response_Status_Reserverd_1 = left(b.CLMSTAT_STATUS,50) --take first 50 
,a.reserved_3 = left(b.STAT_REJ_REA_ID,50)--8 
from [WIPRO].[dbo].[Supplemental_OUTPUT] a 
JOIN [WIPRO].STAGING.[OUTB_CLAIM_STATUS] b 
ON a.Edifecs_Claim_Id = left(b.WIPRO_CLAIM_ID,len(b.WIPRO_CLAIM_ID)-2) 
where isnull(a.Response_Status_Reserverd_1,'''') <> isnull(left(b.CLMSTAT_STATUS,50),'''') 

EXEC msdb.dbo.sp_send_dbmail @profile_name = NULL, 
@recipients = ''MDQOEDSSupport@cigna.com;Subhash.Achara@cigna.com;Ashwini.Maravanthe@healthspring.com'', 
 @body = ''HSTNEDSDB01: Supplemental_OUTPUT update Successful'', 
 @subject = ''HSTNEDSDB01: Supplemental_OUTPUT update Successful''; ', 'N' )


-- RETM-217
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS EDIFECS - Single File Job - FRIDAY MORNING JOBS', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS EDIFECS - Single File Job - FRIDAY MORNING JOBS', 27, 'SCRIPT',
		 'DECLARE	@LOW_ID	INT, @HIGH_ID INT, @archive_datetime datetime 

SELECT @LOW_ID	= LOW_ID, @HIGH_ID = HIGH_ID 
FROM dbo.EXT_SYS_JOB_RANGE 
WHERE NAME = ''2000s''

SELECT @archive_datetime = getdate() 

INSERT INTO dbo.OUTB_WIPRO_TEST_BED_Archive 
           (TESTID, TEST_DESC, CLAIMID, FormTypeCode, typecode, DeniedFlag, SOURCEDATAKEY, CLAIM_TYPE, CLM_IND, 
            CLMSTAT_STATUS, LAST_UPD_DATE, DOS_MONTH, ORIG_BIDW_EXTRACT_DT, LAST_BIDW_EXTRACT_DT, CMS_ICN, 
            FILEID, LOBCODE, PRODUCTTYPE, SERVICEPLACECODE, HPLAN, PAPER_IND, SOURCEDESC, HRP_CLAIM_ID, 
            OUTBOUNDVHCLAIMID, INBOUNDFILENAME, ARCHIVE_DT) 
SELECT	   TESTID, TEST_DESC, CLAIMID, FormTypeCode, typecode, DeniedFlag, SOURCEDATAKEY, CLAIM_TYPE,
           CLM_IND, CLMSTAT_STATUS, LAST_UPD_DATE, DOS_MONTH, ORIG_BIDW_EXTRACT_DT, LAST_BIDW_EXTRACT_DT, 
           CMS_ICN, FILEID, LOBCODE, PRODUCTTYPE, SERVICEPLACECODE, HPLAN, PAPER_IND, SOURCEDESC, 
           HRP_CLAIM_ID, OUTBOUNDVHCLAIMID, INBOUNDFILENAME, @archive_datetime 
FROM	WIPRO.dbo.OUTB_WIPRO_TEST_BED 
WHERE	TESTID BETWEEN @LOW_ID AND @HIGH_ID 

DELETE	WIPRO.dbo.OUTB_WIPRO_TEST_BED 
WHERE	TESTID BETWEEN @LOW_ID AND @HIGH_ID 
', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS EDIFECS - Single File Job - FRIDAY MORNING JOBS', 28, 'SCRIPT',
		 'update dup 
set Has_Been_Resubmitted = 1 
from WIPRO.dbo.Service_Line_Dup_Processing dup 
join wipro.[dbo].[OUTB_WIPRO_TEST_BED_archive] a 
on dup.claim_id = a.claimid 
and dup.sourcedatakey = a.sourcedatakey 
where Is_Resubmission_Eligible = ''1'' 
AND Has_Been_Resubmitted = ''0'' 
and Error_Code = ''98325'' 
and TEST_DESC = ''98325_Resub'' ', 'N' )


-- RETM-218
INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_CONFIGS
	(JOBNAME, Completion_Message, Failure_Message)
VALUES	('EDS EDIFECS Encounter � Single File Job � Saturday Morning RESUB JOBS', 'job completed successfully', 'job failed')

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS EDIFECS Encounter � Single File Job � Saturday Morning RESUB JOBS', 15, 'SCRIPT',
		 'DECLARE @archiveDate DATETIME = GETDATE(); 

        INSERT INTO WIPRO.dbo.OUTB_WIPRO_TEST_BED_Archive 
        SELECT 
            owtb.TESTID 
           ,owtb.TEST_DESC 
           ,owtb.CLAIMID 
           ,owtb.FormTypeCode 
           ,owtb.typecode 
           ,owtb.DeniedFlag 
           ,owtb.SOURCEDATAKEY 
           ,owtb.CLAIM_TYPE 
           ,owtb.CLM_IND 
           ,owtb.CLMSTAT_STATUS 
           ,owtb.LAST_UPD_DATE 
           ,owtb.DOS_MONTH 
           ,owtb.ORIG_BIDW_EXTRACT_DT 
           ,owtb.LAST_BIDW_EXTRACT_DT 
           ,owtb.CMS_ICN 
           ,owtb.FILEID 
           ,owtb.LOBCODE 
           ,owtb.PRODUCTTYPE 
           ,owtb.SERVICEPLACECODE 
           ,owtb.HPLAN 
           ,owtb.PAPER_IND 
           ,owtb.SOURCEDESC 
           ,owtb.HRP_CLAIM_ID 
           ,owtb.OUTBOUNDVHCLAIMID 
           ,owtb.INBOUNDFILENAME 
           ,@archiveDate AS [ARCHIVE_DT] 
        FROM WIPRO.dbo.OUTB_WIPRO_TEST_BED owtb 
        WHERE owtb.TESTID IN (5001, 5002) 

        DELETE  FROM WIPRO.dbo.OUTB_WIPRO_TEST_BED 
        WHERE TESTID IN (5001, 5002) ', 'N' )

INSERT INTO		WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
	(JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES	('EDS EDIFECS Encounter � Single File Job � Saturday Morning RESUB JOBS', 16, 'SCRIPT',
		 'update dup 
set Has_Been_Resubmitted = 1 
from WIPRO.dbo.Service_Line_Dup_Processing dup 
join wipro.[dbo].[OUTB_WIPRO_TEST_BED_archive] a 
on dup.claim_id = a.claimid 
and dup.sourcedatakey = a.sourcedatakey 
where Is_Resubmission_Eligible = ''1'' 
AND Has_Been_Resubmitted = ''0'' 
and Error_Code = ''98325'' 
and TEST_DESC = ''98325_Resub'' ', 'N' )


-- end.