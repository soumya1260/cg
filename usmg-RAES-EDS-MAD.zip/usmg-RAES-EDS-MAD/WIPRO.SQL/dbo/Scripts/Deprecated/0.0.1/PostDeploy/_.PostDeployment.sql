﻿/* 
	Add files here that should be executed against every environment AFTER deploy occurs:
	Example: table script to drop or archive data before table alter statement
	Use SQLCMD mode to add files here
*/

--:r .\0000-RETM-77-Insert-OUTB_PROF_DETAIL_HIST_Archive.sql
--:r .\0001-RETM-77-INSERT-ARCHIVED_MAO_004_Detail.sql
--:R .\0002-RETM-77-INSERT-ARCHIVED_MAO_004_Files_Processed.sql
--:r .\0001-RETM-157-ScripttoUpdateexistingdatainReconTables.sql
--:r .\0001-RETM-182-Insert-Agilon-Jackson-004-Config.sql
--:r .\0001-RETM-157-ScripttoUpdateexistingdatainReconTables.sql
--:r .\0000-RETM-141-INSERT-MONOGRAM-004-DATA.sql --insert monogram data for 004 pull (if not exists)
--:r .\0001-RETM-182-Insert-Agilon-Jackson-004-Config.sql
--:r .\0001-RETM-182-Insert-Agilon-Peidmont-004-Config.sql
:r .\0001-RETM-185-INSERT-ARCHWELL-VE-CONFIG.sql
--:r .\0001-RETM-157-ScripttoUpdateexistingdatainReconTables.sql
--:r .\0000-RETM-141-INSERT-MONOGRAM-004-DATA.sql --insert monogram data for 004 pull (if not exists)
--
--:r .\0001-RETM-188-CREATE-TABLES.sql
--:r .\0001-RETM-228-Drop-and-Create-Monogram-Job.sql
--:r .\0001-RETM-188-CREATE-TABLES.sql
--:r .\0001-RETM-188-POPULATE-TABLES.sql
--:r .\0001-RETM-157-ScripttoUpdateexistingdatainReconTables.sql
--:r .\0001-RETM-193-RAES_MAD_EDS-WIPRO-CleanuptheEDS_CLAIM.sql
:r .\0001-RETM-501-TABLE-REPOPULATE.sql
:r .\0001-Vendor-Export-Config-Maintenance.sql --Must be run last