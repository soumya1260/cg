﻿--GO
--IF (SELECT COUNT(*) FROM dbo.OUTB_PROF_DETAIL_HIST opdh) > 0 
--	AND OBJECT_ID('dbo.OUTB_PROF_DETAIL_HIST_Archive_RETM_77_backup_09212022', 'U') IS NULL BEGIN  
	
--	EXEC sys.sp_rename @objname = N'dbo.OUTB_PROF_DETAIL_HIST_Archive'
--					  ,@newname = N'OUTB_PROF_DETAIL_HIST_Archive_RETM_77_backup_09212022';					  
--END;

