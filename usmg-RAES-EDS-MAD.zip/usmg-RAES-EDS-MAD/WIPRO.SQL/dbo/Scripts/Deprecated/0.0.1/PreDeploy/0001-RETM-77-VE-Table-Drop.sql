﻿GO

IF OBJECT_ID('dbo.VE_Export_File', 'U') IS NOT NULL
	DROP TABLE dbo.VE_Export_File;

IF OBJECT_ID('dbo.VE_Vendor_Config', 'U') IS NOT NULL
	DROP TABLE dbo.VE_Vendor_Config;

IF OBJECT_ID('dbo.VE_Provider_Group_Log_Table', 'U') IS NOT NULL
	DROP TABLE dbo.VE_Provider_Group_Log_Table;

IF OBJECT_ID('dbo.VE_Provider_Group_Associated_POD_Codes', 'U') IS NOT NULL
	DROP TABLE dbo.VE_Provider_Group_Associated_POD_Codes;

IF OBJECT_ID('dbo.VE_Vendor_File_Types', 'U') IS NOT NULL
	DROP TABLE dbo.VE_Vendor_File_Types;

IF OBJECT_ID('dbo.VE_Provider_Group_Control', 'U') IS NOT NULL
	DROP TABLE dbo.VE_Provider_Group_Control;

