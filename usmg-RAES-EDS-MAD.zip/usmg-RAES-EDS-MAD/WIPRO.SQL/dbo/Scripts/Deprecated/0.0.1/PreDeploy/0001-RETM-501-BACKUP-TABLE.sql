﻿/*
This script is here to backup the table data in SUPP_RAPS_CI_DATA before a datatype is modified below.
Tables need to be empty before the auto-deploy can safely make the modification.
After the modification is made, this script should default to not running.
Companion script in post-deploy folder: 0001-RETM-501-TABLE-REPOPULATE.sql
*/


IF EXISTS (	SELECT
			*
			FROM INFORMATION_SCHEMA.TABLES t
			JOIN INFORMATION_SCHEMA.COLUMNS c
				ON t.TABLE_NAME = c.TABLE_NAME
				AND t.TABLE_SCHEMA = c.TABLE_SCHEMA
			WHERE 1 = 1 
				AND t.TABLE_NAME = 'SUPP_RAPS_CI_DATA'
				AND c.COLUMN_NAME IN (
					'Created_Date',
					'Last_Modified_Date',
					'Start_Date',
					'End_Date',
					'CMS_Extract_Date')
					AND c.DATA_TYPE = 'datetime') 
	AND OBJECT_ID('SUPP_RAPS_CI_DATA_BK_RETM_501_20231114', 'U') IS NULL
BEGIN;

	IF OBJECT_ID('SUPP_RAPS_CI_DATA_BK_RETM_501_20231114', 'U') IS NOT NULL
    	DROP TABLE SUPP_RAPS_CI_DATA_BK_RETM_501_20231114;

	SELECT
		srcd.CMCR_ID
	   ,srcd.Member_ID
	   ,srcd.Review_Status
	   ,srcd.Market_Abbr
	   ,srcd.Review_Type
	   ,srcd.Event_Type_Desc
	   ,srcd.Submit_Source
	   ,Created_Date = TRY_CAST(srcd.Created_Date AS DATE)
	   ,Last_Modified_Date = TRY_CAST(srcd.Last_Modified_Date AS DATE)
	   ,srcd.Chart_Prov
	   ,Start_Date = TRY_CAST(srcd.Start_Date AS DATE)
	   ,End_Date = TRY_CAST(srcd.End_Date AS DATE)
	   ,srcd.DOS_Results_ID
	   ,srcd.Document_Prov_ID
	   ,CMS_Extract_Date = TRY_CAST(srcd.CMS_Extract_Date AS DATE)
	   ,srcd.DX_Code_Result_ID
	   ,srcd.ICD_Code
	   ,srcd.DX_Code_ID
	   ,srcd.Chart_Prov_Spec
	   ,srcd.Doc_Prov_Spec
	   ,srcd.Appr_Rvw_Stat
	   ,srcd.Appr_Spec
	   ,srcd.Dos_err
	   ,srcd.Dx_Err
	   ,srcd.Dos_del
	   ,srcd.Dx_del
	   ,srcd.CMS_Extract_Elig
	   ,srcd.Do_Not_Extract
	   ,srcd.DX_Code_Version
	   ,srcd.RA_Prov_Type
	   ,srcd.Load_Date
	   ,srcd.Load_Key
	   ,srcd.CLM_NO
	INTO SUPP_RAPS_CI_DATA_BK_RETM_501_20231114
	FROM dbo.SUPP_RAPS_CI_DATA srcd WITH (TABLOCK);

	TRUNCATE TABLE dbo.SUPP_RAPS_CI_DATA; -->>-- Clean table for modification by auto-deploy
	TRUNCATE TABLE staging.SUPP_RAPS_CI_DATA; -->>-- Clean table for stage modification. Data backup not needed for this table
END;