﻿--GO
--IF (SELECT COUNT(*) FROM dbo.ARCHIVED_MAO_004_Detail opdh) > 0 
--	AND OBJECT_ID('dbo.ARCHIVED_MAO_004_Detail_09212022', 'U') IS NULL BEGIN  
	
--	EXEC sys.sp_rename @objname = N'dbo.ARCHIVED_MAO_004_Detail'
--					  ,@newname = N'ARCHIVED_MAO_004_Detail_09212022';					  
--END;