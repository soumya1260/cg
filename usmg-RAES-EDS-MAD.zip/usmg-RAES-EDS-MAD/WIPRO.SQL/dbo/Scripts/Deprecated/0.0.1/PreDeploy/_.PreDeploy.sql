﻿/* 
	Add files here that should be executed against every environment BEFORE deploy occurs:
	Example: table script to drop or archive data before table alter statement
	Use SQLCMD mode to add files here
*/
--:r .\0000-RETM-77-Archive-OUTB_PROF_DETAIL_HIST_Archive.sql
--:r .\0001-RETM-77-VE-Table-DROP.sql
--:r .\0002-RETM-77-TABLE-DROP-CMS_MAO_004_Detail_BK06152021.sql
--:r .\0003-RETM-77-RENAME-TABLE-dbo.ARCHIVED_MAO_004_Detail.sql
:r .\0001-RETM-501-BACKUP-TABLE.sql
