﻿USE WIPRO;
GO
--insert MOR-M file type if not exists
IF NOT EXISTS (SELECT *
			   FROM dbo.VE_Vendor_File_Types vvft
			   WHERE vvft.File_Type = 'MOR-M') 
BEGIN;
	INSERT INTO dbo.VE_Vendor_File_Types (File_Type, Is_Active)
	VALUES ('MOR-M', 1);
END;