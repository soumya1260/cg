﻿USE WIPRO;
GO
--insert and activate new file type of MOR-L
IF NOT EXISTS (SELECT * FROM dbo.VE_Vendor_File_Types vvft WHERE vvft.File_Type = 'MOR-L') BEGIN;

	INSERT INTO dbo.VE_Vendor_File_Types (File_Type, Is_Active)
	VALUES ('MOR-L', 1);
	
END;