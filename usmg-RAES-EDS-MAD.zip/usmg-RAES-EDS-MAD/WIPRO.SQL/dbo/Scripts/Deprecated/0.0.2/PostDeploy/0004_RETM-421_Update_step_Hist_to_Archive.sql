use wipro
go 

delete from wipro.dbo.RAES_MAD_JOB_STEP_CONFIGS
where jobname = 'EDS WIPRO - Claim Exclusions Build v2'
and        STEPNO = 7

-- INSERT statement with the 2 new columns
INSERT INTO           WIPRO.dbo.RAES_MAD_JOB_STEP_CONFIGS
     (JOBNAME, STEPNO, SCRIPTTYPE, EXECUTION_COMMAND, SPROC_PARAMETERS)
VALUES     ('EDS WIPRO - Claim Exclusions Build v2', 7, 'SCRIPT',
'INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG (PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT) 
VALUES(''Claim Exclusion Hist to Archive Job'', ''7'', GETDATE(), NULL, NULL, 0, GETDATE() ) 

delete from EXT_CLAIM_EXCLUSION_HIST_Archive 
where INSERT_RUN_DT < dateadd(m,-2,getdate()) 

INSERT INTO Wipro.dbo.EXT_CLAIM_EXCLUSION_HIST_Archive 
(claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type, INSERT_RUN_DT, beginservicedate, endservicedate) 
select claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type, getdate(), beginservicedate, endservicedate
from Wipro.dbo.EXT_CLAIM_EXCLUSION_HIST 

UPDATE WIPRO.dbo.EXT_SYS_RUNLOG 
SET END_DT = GETDATE(), RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()), ENTRYDT = GETDATE() 
WHERE PROC_NAME = ''Claim Exclusion Hist to Archive Job'' 
AND END_DT IS NULL ', 
'N' )


