﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
--:r .\0004_RETM-421_Update_step_Hist_to_Archive.sql
:r .\0001-RETM-79-INSERT-Monogram-MMR-Config.sql
:r .\0001-RETM-330-INSERT-New-Vendor-File-Type.sql
:r .\0002-RETM-330-INSERT-New-Monogram-MOR-L-Config.sql