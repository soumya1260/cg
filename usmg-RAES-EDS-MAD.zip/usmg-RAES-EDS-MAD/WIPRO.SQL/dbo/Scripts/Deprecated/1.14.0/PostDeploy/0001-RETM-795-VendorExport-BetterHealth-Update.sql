﻿USE WIPRO;
GO

--update provider group name to new name
UPDATE vpgc
SET Provider_Group_Name = 'Better_Health'
FROM dbo.VE_Provider_Group_Control vpgc
WHERE vpgc.Provider_Group_Name = 'CFL_PhysicianPartner';

DECLARE @id int;
SELECT
	@id = vpgc.VE_PGC_ID
from dbo.VE_Provider_Group_Control vpgc
WHERE vpgc.Provider_Group_Name = 'Better_Health';

DECLARE @Activate_Pods TABLE
(
	Associated_POD_Code varchar(15),
	Is_Active BIT
);
insert INTO @Activate_Pods (Associated_POD_Code, Is_Active)
	VALUES  ('FL1021',1),
			('FL1036',1),
			('FL3014',1),
			('FL4009',1),
			('FL1040',1),
			('FL4012',1),
			('FL5006',1),
			('AL0112',1),
			('FL0101',1),
			('FL9018',1),
			('GA0082',1),
			('OK0008',1),
			('TN0380',1),
			('TX1455',1),
			('FL2004',0),
			('FL2017',0),
			('FL2038',0),
			('FL3003',0),
			('FL3010',0),
			('FL5001',0),
			('FL5004',0),
			('FL6009',0),
			('FL1012',0),
			('FL3002',0),
			('FL6007',0);


WITH update_pop AS (
	SELECT
		pod.VE_PGC_ID,
		pod.Associated_POD_Code,
		pod.Is_Active
	FROM dbo.VE_Provider_Group_Control vendor
		JOIN dbo.VE_Provider_Group_Associated_POD_Codes pod ON vendor.VE_PGC_ID = pod.VE_PGC_ID
	WHERE vendor.Provider_Group_Name = 'Better_Health')
MERGE update_pop AS target	
USING @Activate_Pods AS source
ON source.Associated_POD_Code = target.Associated_POD_Code
WHEN NOT MATCHED BY TARGET 
THEN INSERT (VE_PGC_ID, Associated_POD_Code,Is_Active)
VALUES (@id, source.Associated_POD_Code,source.Is_Active)
WHEN MATCHED AND source.Is_Active != target.Is_Active 
THEN UPDATE SET target.Is_Active = source.Is_Active;

--set temp lookback dates
UPDATE vvc
SET Temp_Run_Date_From = '2024-01-01',
	Temp_Run_Date_To = '2024-12-05'
FROM dbo.VE_Provider_Group_Control vpgc
JOIN dbo.VE_Vendor_Config vvc ON vpgc.VE_PGC_ID = vvc.VE_PGC_ID
JOIN dbo.VE_Vendor_File_Types vvft ON vvc.VE_FT_ID = vvft.VE_VFT_ID
WHERE 1 = 1
	and vpgc.Provider_Group_Name = 'Better_Health'
	AND vvft.File_Type = 'MAO-004';

--deactivate 002 config
UPDATE config
SET config.Is_Active = 0
FROM dbo.VE_Provider_Group_Control vendor
JOIN dbo.VE_Vendor_Config config ON vendor.VE_PGC_ID = config.VE_PGC_ID
JOIN dbo.VE_Vendor_File_Types ft ON config.VE_FT_ID = ft.VE_VFT_ID
WHERE 1 = 1
	AND vendor.Provider_Group_Name = 'Better_Health'
	AND ft.File_Type IN ('MAO-002','MOR');
