﻿
CREATE PROCEDURE [dbo].[EXSP_WIPRO_MA0_002_Historical_CleanUp]
AS
/***************************************************************************************************
** CREATE DATE: 09/22/2018
**
** AUTHOR: Subhash Acharya
**
** DESCRIPTION: Procedure will update the OUTB_CLAIM_STATUS from historical Table.
**				
** Sample invocation: Exec [dbo].[EXSP_WIPRO_MA0_002_Historical_CleanUp]
**
**
Modification History
=========================================================================
Date			Author				  Description
09/22/2018		Subhash Acharya		  This is created as part of 1810

-----------------------------------------------------------------------------------------------------
*****************************************************************************************************/	

IF OBJECT_ID('dbo.OUTB_CLAIM_STATUS_Backup_1820', 'U') IS NULL 

BEGIN

CREATE TABLE [dbo].[OUTB_CLAIM_STATUS_Backup_1820]
			(
			[CLAIM_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLAIM_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FILEID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLM_IND] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SOURCEDATAKEY] [int] NULL,
			[MEMBER_ID] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[HICN_NUM] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[BILL_PROV_GRP_ID] [char] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[BILL_PROV_ID] [char] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REF_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REF_PCP_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[ATTN_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLMSTAT_STATUS] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_CLM_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[WIPRO_CLAIM_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CMS_ICN] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_FATAL_ERR_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_REJ_REA_ID] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REJ_REA_MSG] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[LINE_SEQ_NO] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[OTH_PAYER_ID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_TYPE] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SUBTYPE] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_SUB_QUAL] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_POS] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_ERR] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[VAL_ERR] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FILEDATE] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[LAST_UPD_DATE] [datetime] NULL,
			[DOS_MONTH] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SecondaryPlanClaimNumber] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[EffectiveEncounterFlag] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[OriginalPlanClaimID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
			) ON [PRIMARY]


END


IF OBJECT_ID('dbo.OUTB_CLAIM_STATUS_Backup_1820', 'U') IS NOT NULL 

BEGIN

	IF (SELECT COUNT(*) FROM dbo.OUTB_CLAIM_STATUS_Backup_1820) <> 
							(SELECT COUNT(*) FROM dbo.OUTB_CLAIM_STATUS)
	  BEGIN
		
		--PRINT 'Need to DROP and Reload the Table'
		
		DROP TABLE OUTB_CLAIM_STATUS_Backup_1820; 
		
		CREATE TABLE [dbo].[OUTB_CLAIM_STATUS_Backup_1820]
			(
			[CLAIM_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLAIM_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FILEID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLM_IND] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SOURCEDATAKEY] [int] NULL,
			[MEMBER_ID] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[HICN_NUM] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[BILL_PROV_GRP_ID] [char] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[BILL_PROV_ID] [char] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REF_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REF_PCP_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[ATTN_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLMSTAT_STATUS] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_CLM_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[WIPRO_CLAIM_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CMS_ICN] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_FATAL_ERR_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_REJ_REA_ID] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REJ_REA_MSG] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[LINE_SEQ_NO] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[OTH_PAYER_ID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_TYPE] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SUBTYPE] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_SUB_QUAL] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_POS] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_ERR] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[VAL_ERR] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FILEDATE] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[LAST_UPD_DATE] [datetime] NULL,
			[DOS_MONTH] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SecondaryPlanClaimNumber] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[EffectiveEncounterFlag] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[OriginalPlanClaimID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
			) ON [PRIMARY]
		
			--Back up Table [WIPRO].[dbo].[OUTB_CLAIM_STATUS_Backup_1820]
			
			INSERT INTO [dbo].[OUTB_CLAIM_STATUS_Backup_1820]
			SELECT  * FROM [dbo].[OUTB_CLAIM_STATUS]
			
			

	  END 		
	END

IF (SELECT COUNT(*) FROM dbo.OUTB_CLAIM_STATUS_Backup_1820) = 
							(SELECT COUNT(*) FROM dbo.OUTB_CLAIM_STATUS)

BEGIN

UPDATE a
			SET	a.CLMSTAT_STATUS = CASE 
									--Accepted
									WHEN a.CLMSTAT_STATUS = 'A'     AND b.RecordType = 'A'            THEN 'A-ICN'
									WHEN a.CLMSTAT_STATUS = 'A-277' AND b.RecordType = 'A'            THEN 'A-ICN'
									WHEN a.CLMSTAT_STATUS = 'A-999' AND b.RecordType = 'A'            THEN 'A-ICN'
									WHEN a.CLMSTAT_STATUS = 'R'     AND b.RecordType = 'A'            THEN 'A-ICN'
									WHEN a.CLMSTAT_STATUS = 'R-277' AND b.RecordType = 'A'            THEN 'A-ICN'
									WHEN a.CLMSTAT_STATUS = 'R-999' AND b.RecordType = 'A'            THEN 'A-ICN'
									WHEN a.CLMSTAT_STATUS = 'R-ICN' AND b.RecordType = 'A'            THEN 'A-ICN'
									WHEN a.CLMSTAT_STATUS IS NULL   AND b.RecordType = 'A'            THEN 'A-ICN'
									WHEN a.CLMSTAT_STATUS = 'NULL'  AND b.RecordType = 'A'            THEN 'A-ICN'
									--Rejected
									WHEN a.CLMSTAT_STATUS = 'A'     AND b.RecordType = 'R'            THEN 'R-ICN'
									WHEN a.CLMSTAT_STATUS = 'A-277' AND b.RecordType = 'R'            THEN 'R-ICN'
									WHEN a.CLMSTAT_STATUS = 'A-999' AND b.RecordType = 'R'            THEN 'R-ICN'
									WHEN a.CLMSTAT_STATUS = 'R'     AND b.RecordType = 'R'            THEN 'R-ICN'
									WHEN a.CLMSTAT_STATUS = 'R-277' AND b.RecordType = 'R'            THEN 'R-ICN'
									WHEN a.CLMSTAT_STATUS = 'R-999' AND b.RecordType = 'R'            THEN 'R-ICN'
									WHEN a.CLMSTAT_STATUS IS NULL   AND b.RecordType = 'R'            THEN 'R-ICN'
									WHEN a.CLMSTAT_STATUS = 'NULL'  AND b.RecordType = 'R'            THEN 'R-ICN'
								   END
			FROM [WIPRO].[dbo].[OUTB_CLAIM_STATUS] a
			JOIN [WIPRO].[dbo].[MAO_002_Detail] b ON RTRIM(LTRIM(a.CLAIM_ID)) = RTRIM(LTRIM(b.PlanClaimNumber)) AND RTRIM(LTRIM(a.WIPRO_CLAIM_ID)) = RTRIM(LTRIM(b.WIPRO_UNQ_ID))
			WHERE 1= 1
			AND b.ServiceLineSequenceNumber = '000' 
			AND TRY_CONVERT(INT,LEFT(a.DOS_MONTH,4)) >= 2015 
			AND
			(
			   (a.CLMSTAT_STATUS = 'A'			AND b.RecordType = 'A')          
			OR (a.CLMSTAT_STATUS = 'A-277'		AND b.RecordType = 'A')
			OR (a.CLMSTAT_STATUS = 'A-999'		AND b.RecordType = 'A')
			OR (a.CLMSTAT_STATUS = 'R'			AND b.RecordType = 'A')          
			OR (a.CLMSTAT_STATUS = 'R-277'		AND b.RecordType = 'A')
			OR (a.CLMSTAT_STATUS = 'R-999'		AND b.RecordType = 'A')
			OR (a.CLMSTAT_STATUS = 'R-ICN'		AND b.RecordType = 'A')
			OR (a.CLMSTAT_STATUS IS NULL		AND b.RecordType = 'A')    
			OR (a.CLMSTAT_STATUS = 'NULL'		AND b.RecordType = 'A')
			OR(a.CLMSTAT_STATUS = 'A'			AND b.RecordType = 'R')
			OR(a.CLMSTAT_STATUS = 'A-277'		AND b.RecordType = 'R')
			OR(a.CLMSTAT_STATUS = 'A-999'		AND b.RecordType = 'R')
			OR(a.CLMSTAT_STATUS = 'R'			AND b.RecordType = 'R')
			OR(a.CLMSTAT_STATUS = 'R-277'		AND b.RecordType = 'R')
			OR(a.CLMSTAT_STATUS = 'R-999'		AND b.RecordType = 'R')
			OR(a.CLMSTAT_STATUS IS NULL			AND b.RecordType = 'R')
			OR(a.CLMSTAT_STATUS = 'NULL'		AND b.RecordType = 'R') 
			)


END



