﻿








CREATE PROCEDURE [dbo].[BUILD_OUTB_PROF_CLM_DETAIL]
AS
/***************************************************************************************************
** CREATE DATE: 06/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM LINE 
**              INFORMATION. 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
2012-10-19		Dwight Staggs	Remove database name from table references
2012-10-26		Loyal Ricks		Updated logic for CONTRACT_CODE (if claimdetaildim.PROVIDERCAPITATIONSTATUS
								= 'Y' then '05' else ' '
2012-11-01		Loyal Ricks		Add CONTRAC_TYPE "' '" TO EXT_HRP_CLAIM INSERT
2012-11-19		Loyal Ricks		Add Adjustment Segements 1-1-1 to 1-5
11/27/12		LOYAL RICKS		REVISED USE OF TEMPDB, RENAME ##TMP TO ##TMPDEV TO ALLOW FOR MULTIPLE
								PROCESSING IN EDPS & EDPS_PROD
2013-05-14		Loyal Ricks		Add Parse UNKNOWN values from ProcedureCode & OTH_PAYER1_PROC_CD supporting
								outbound Facets Claim file
				Loyal Ricks		Default Facets CONTRACT_CODE & CONTRACT_TYPE = ' '

2013-07-16      Loyal Ricks		Add Optional Reporting Ind1 Logic for "Interest Claims", claims with 
								PROC_CODE IN ('0L6','$INT'). 
2013-10-01		Dwight Staggs	Had to qualify occurances of BeginServiceDate as it is now in both 
								ClaimDim and ClaimDetailDim
2013-10-16		Loyal Ricks		Remove default value for CONTRACT_CODE per onsite meeting on 10/15/13
2013-10-25		Loyal Ricks	    Add procedurecode data scrub removing decimal and spaces 
								replace(REPLACE(procedurecode,'.',' '),' ','')
2013-11-21		Loyal Ricks		Remove logic for setting Facets Contract Type to blank. 
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation						
2015-07-23		Loyal Ricks		TETDM-274 Revision Contract_type logic -  switch claimdetaildim.PROVIDERCAPITATIONSTATUS 
								with claimdetaildim.CAPITATEDLINEFLAG	
2016-08-30		Loyal Ricks		TETDM-937 - 	CMS Reject-  Procedure description must be present if Proc Cd does not definitively describe the service 
2017-01-09		Loyal Ricks		TETDM-1217 - Add Claimlineadditionaldatadim.emergencyflag
2017-01-09		Loyal Ricks		TETDM-1217 - Revision Claimlineadditionaldatadim.emergencyflag = Y	
2017-05-09      John Bartholomay TETDM-1490 - Matching change for SDK=30 Modifiers on Claimline	
2017-11-07		Mike Vega		TETDM-1613 changed table in 3 areas from: claimrevenuecodedim to: ClaimLineRevenueCodeDim													    
2018-01-10      John Bartholomay TETDM-1710  Anes Modifier update based on service dates
2018-01-24		Mike Vega		TETDM-1613 Remove Updates to REV_CD2 and REV_CD3 per request. The should be NULL in outb File
2018-04-17      John Bartholomay TETDM-1780 Modification to Anes Modifier, remove date requirements
2019-07-09      Henry Faust     TETDM-2081 remove duplicate PROC_MOD codes for 2,3,4 and keep the 
2024-27-02		Anthony Ulmer	Refactor procedure modifier code due to bad data from upstream
*****************************************************************************************************/	
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_PROF_CLMDETAIL'
				,'3'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
------------------------- Temp Table		TETDM-2081	

	IF OBJECT_ID('TEMPDB..#procmod') <> 0
		DROP TABLE #tprocmod
	
	CREATE TABLE #tprocmod
	(
		ClaimID		VARCHAR(20),
		ClaimLine   INTEGER,
		proc_cd  VARCHAR(5),
		proc_mod VARCHAR(2),
		SEQUENCE int
	)
	IF OBJECT_ID('TEMPDB..#procmod') <> 0
		DROP TABLE #procmod
	
	CREATE TABLE #procmod
	(
		ClaimID		VARCHAR(20),
		ClaimLine   INTEGER,
		proc_cd  VARCHAR(5),
		proc_mod VARCHAR(2),
		SEQUENCE int
	)		
	----------------------
--OUTB_PROF_DETAIL
----------------------

		BEGIN TRANSACTION 
			INSERT INTO DBO.OUTB_PROF_DETAIL
			SELECT 'L'
				,claimid
				,claimlineid
				,CD.beginservicedatekey
				,CD.endservicedatekey
				,' ' --revenue code 1
				,' '--revenue code 2
				,' '--revenue code 3
				,'HC'--Product or Service ID Qualifier
				,case replace(REPLACE(procedurecode,'.',' '),' ','') WHEN 'UNKNOWN' THEN  ' ' ELSE replace(REPLACE(procedurecode,'.',' '),' ','') END--procedure code
				,' '--procedure modifier1
				,' '
				,' '
				,' '
				,' '
				,ltrim(requestedamt)
				,' '
				,'UN'--Anesthesia Flag
				,' '
				,quantity
				,serviceplacecode
				,' '--PRIM_DIAG_CD
				,' '
				,' '
				,' '
				,' '--DIAG_CD5
				,' '
				,' '
				,' '
				,' '
				,' '--DIAG_CD10
				,' '
				,' '
				,' '
				,' '
				,' '--DIAG_CD15
				,' '
				,' '
				,' '
				,' '
				,' '--DIAG_CD20
				,' '
				,' '
				,' '
				,' '
				,' '--DIAG_CD25
				,' '
				,' '
				,' '
				,' '
				,' '--diag_cd30
				,' '--emer_flag
				,' '--copay_Ex_flag
				,claimlineid
				,' '----clia_no
				,' '--CLIAReferralNumber--ref_clia_fac_no_qual
				,' '--OTH_PAYER1_PRIMEID	
				,ltrim(PaymentAmount)--OTH_PAYER1_PAID_AMT	CHAR(18),
				,case replace(REPLACE(procedurecode,'.',' '),' ','') WHEN 'UNKNOWN' THEN  ' ' ELSE replace(REPLACE(procedurecode,'.',' '),' ','') END--OTH_PAYER1_PROC_CD	CHAR(8),
				,Quantity--OTH_PAYER1_PAID_QTY	CHAR(9),
				,' '--OTH_PAYER1_ADJ_BUNDLE	CHAR(6),
				,'CO'--CLM_ADJ_GRP1		CHAR(30),
				/*,'45'--CLM_ADJ_REASON1		CHAR(50),
				,' '--CLM_ADJ_AMT1		CHAR(18),
				,' '----CLM_ADJ_QTY1		CHAR(18),
				,'PI'--CLM_ADJ_GRP12		CHAR(30),
				,'3'--CLM_ADJ_REASON121	CHAR(50),
				,ltrim(CoPayAmt)--CLM_ADJ_AMT121		CHAR(18),
				' '--[CLM_ADJ_GRP111] ' '--[char](30) ,*/
				,'45'--[CLM_ADJ_REASON111] ,
				,' '--[CLM_ADJ_AMT111] ,
				,' '--[CLM_ADJ_QTY111] ,
				,' '--[CLM_ADJ_REASON112] ,
				,' '--[CLM_ADJ_AMT112] ,
				,' '--[CLM_ADJ_QTY112] ,
				,' '--[CLM_ADJ_REASON113] ,
				,' '--[CLM_ADJ_AMT113] ,
				,' '--[CLM_ADJ_QTY113] ,
				,' '--[CLM_ADJ_REASON114] ,
				,' '--[CLM_ADJ_AMT114] ,
				,' '--[CLM_ADJ_QTY114] ,
				,' '--[CLM_ADJ_REASON115] ,
				,' '--[CLM_ADJ_AMT115] ,
				,' '--[CLM_ADJ_QTY115] ,
				,' '--[CLM_ADJ_REASON116] ,
				,' '--[CLM_ADJ_AMT116] ,
				,' '--[CLM_ADJ_QTY116] ,	
				,'PI'--[CLM_ADJ_GRP12] ' '--[char](30) ,
				,'3'--[CLM_ADJ_REASON121] ,
				,' '--[CLM_ADJ_AMT121] ,
				,' '--[CLM_ADJ_QTY121] ,
				,' '--[CLM_ADJ_REASON122] ,
				,' '--[CLM_ADJ_AMT122] ,
				,' '--[CLM_ADJ_QTY122] ,
				,' '--[CLM_ADJ_REASON123] ,
				,' '--[CLM_ADJ_AMT123] ,
				,' '--[CLM_ADJ_QTY123] ,
				,' '--[CLM_ADJ_REASON124] ,
				,' '--[CLM_ADJ_AMT124] ,
				,' '--[CLM_ADJ_QTY124] ,
				,' '--[CLM_ADJ_REASON125] ,
				,' '--[CLM_ADJ_AMT125] ,
				,' '--[CLM_ADJ_QTY125] ,
				,' '--[CLM_ADJ_REASON126] ,
				,' '--[CLM_ADJ_AMT126] ,
				,' '--[CLM_ADJ_QTY126] ,
				,' '--[CLM_ADJ_GRP13] ,' '--[char](30) ,
				,' '--[CLM_ADJ_REASON131] ,
				,' '--[CLM_ADJ_AMT131] ,
				,' '--[CLM_ADJ_QTY131] ,
				,' '--[CLM_ADJ_REASON132] ,
				,' '--[CLM_ADJ_AMT132] ,
				,' '--[CLM_ADJ_QTY132] ,
				,' '--[CLM_ADJ_REASON133] ,
				,' '--[CLM_ADJ_AMT133] ,
				,' '--[CLM_ADJ_QTY133] ,
				,' '--[CLM_ADJ_REASON134] ,
				,' '--[CLM_ADJ_AMT134] ,
				,' '--[CLM_ADJ_QTY134] ,
				,' '--[CLM_ADJ_REASON135] ,
				,' '--[CLM_ADJ_AMT135] ,
				,' '--[CLM_ADJ_QTY135] ,
				,' '--[CLM_ADJ_REASON136] ,
				,' '--[CLM_ADJ_AMT136] ,
				,' '--[CLM_ADJ_QTY136] ,
				,' '--[CLM_ADJ_GRP14] ,' '--[char](30) ,
				,' '--[CLM_ADJ_REASON141] ,
				,' '--[CLM_ADJ_AMT141] ,
				,' '--[CLM_ADJ_QTY141] ,
				,' '--[CLM_ADJ_REASON142] ,
				,' '--[CLM_ADJ_AMT142] ,
				,' '--[CLM_ADJ_QTY142] ,
				,' '--[CLM_ADJ_REASON143] ,
				,' '--[CLM_ADJ_AMT143] ,
				,' '--[CLM_ADJ_QTY143] ,
				,' '--[CLM_ADJ_REASON144] ,
				,' '--[CLM_ADJ_AMT144] ,
				,' '--[CLM_ADJ_QTY144] ,
				,' '--[CLM_ADJ_REASON145] ,
				,' '--[CLM_ADJ_AMT145] ,
				,' '--[CLM_ADJ_QTY145] ,
				,' '--[CLM_ADJ_REASON146] ,
				,' '--[CLM_ADJ_AMT146] ,
				,' '--[CLM_ADJ_QTY146] ,
				,' '--[CLM_ADJ_GRP15] ,' '--[char](30) ,
				,' '--[CLM_ADJ_REASON151] ,
				,' '--[CLM_ADJ_AMT151] ,
				,' '--[CLM_ADJ_QTY151] ,
				,' '--[CLM_ADJ_REASON152] ,
				,' '--[CLM_ADJ_AMT152] ,
				,' '--[CLM_ADJ_QTY152] ,
				,' '--[CLM_ADJ_REASON153] ,
				,' '--[CLM_ADJ_AMT153] ,
				,' '--[CLM_ADJ_QTY153] ,
				,' '--[CLM_ADJ_REASON154] ,
				,' '--[CLM_ADJ_AMT154] ,
				,' '--[CLM_ADJ_QTY154] ,
				,' '--[CLM_ADJ_REASON155] ,
				,' '--[CLM_ADJ_AMT155] ,
				,' '--[CLM_ADJ_QTY155] ,
				,' '--[CLM_ADJ_REASON156] ,
				,' '--[CLM_ADJ_AMT156] ,
				,' '--[CLM_ADJ_QTY156] ,
				,ltrim(PaidDateKey)--OTH_PAYER1_ADJ_DT	CHAR(10),
				,sourcedatakey
				,' '--FeeCalculationCode ONLY USED FOR REPRICING
				,' '--CASE PROVIDERCAPITATIONSTATUS WHEN 'Y' THEN  '05' ELSE ' ' END--CONTACT CODE
				--TETDM-274
				,CASE CAPITATEDLINEFLAG WHEN 'Y' THEN  '05' ELSE ' ' END--CONTACT TYPE
				,' ' --OPTIONAL_RPT_IND1
			from EDPS_DATA.dbo.claimdetaildim CD
			where claimid in (select CLAIM_ID from dbo.OUTB_PROF_HEADER)
				--added after 4/19 BIDW REFRESH - CLAIM LINE PROCEDURE CODES INCLUDED WITH THIS UPDATE
				AND LEN(ProcedureCode) <= 5
			ORDER BY CD.ClaimID,CD.ClaimLineID
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
			--UPDATE EXT_HRP_CLAIM.CMS_CONTRACT_NUM USING DOS OF CLAIM TO GET APPROPRIATE ELIGIBILITY
			--HRP CLAIM HEADER - CMS_CONTRACT_NUM & OTH_PAYER1_PLANID UPDATES
	--		--use claimline dos to determine eligibility row from mmr that will be used. Code will be based on datasourcekey and claim to mmr relationship.
	--			SELECT  C.CLAIM_ID,C.MEMBER_ID,SUBSTRING(MIN(CD.SERV_START_DT),1,6) AS 'DOS',C.SOURCEDATAKEY
	--			INTO ##TMPDEV_ELIG
	--			FROM EXT_HRP_CLAIM C
	--				,OUTB_PROF_DETAIL CD
	--			WHERE C.CLAIM_ID = CD.CLAIM_ID
	--			GROUP BY C.CLAIM_ID,C.MEMBER_ID,C.SOURCEDATAKEY
	--			ORDER BY C.MEMBER_ID,C.CLAIM_ID
	--	--MEMBER ELIGIBILITY - USE MIN(CLAIMDETAILDIM.BEGINSERVICEDATEKEY)
	--	--MHC ELGIBILITY
	--		--UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO
	--	BEGIN TRANSACTION 
	--		UPDATE EXT_HRP_CLAIM
	--		SET CMS_CONTRACT_NUM = MR.[PLAN]
	--				,OTH_PAYER1_PLANID = MR.[PLAN]
	--		FROM EXT_HRP_CLAIM C
	--			 ,##TMPDEV_ELIG T
	--			,MDQOLib.dbo.MMR MR
	--		WHERE C.CLAIM_ID = T.CLAIM_ID
	--			AND REPLACE(C.MEMBER_ID,'-','*')  = MR.MEM_ID
	--			AND substring(mr.[plan],1,1) <> 'S'
	--			AND MR.[payt_dt] = T.DOS
	--			AND C.SOURCEDATAKEY = '2'
	--		if @@ERROR <> 0
	--		begin
	--			rollback 
	--		end
	--	commit
		
	--	--QNXT ELIGIBILITY - USE MIN(CLAIMDETAILDIM.BEGINSERVICEDATEKEY)
		
			
	----UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO
	--	BEGIN TRANSACTION 
	--		UPDATE EXT_HRP_CLAIM
	--		SET CMS_CONTRACT_NUM = MR.[PLAN]
	--		,OTH_PAYER1_PLANID = MR.[PLAN]
	--		FROM EXT_HRP_CLAIM C
	--			 ,##TMPDEV_ELIG T
	--			 ,MDQOLib.dbo.MMR MR
	--		--REMOVE JOIN ON MEMBER_ID 5/29 MDQOLIB.DBO.MMR.MEM_ID IS NULL
	--		--ON REPLACE(MEMBER_ID,'-','*')  = MR.MEM_ID
	--		WHERE C.CLAIM_ID = T.CLAIM_ID
	--			AND C.HICN_NUM = MR.Medicare
	--			AND substring(mr.[plan],1,1) <> 'S'
	--			AND MR.[payt_dt] = T.DOS
	--			AND C.SOURCEDATAKEY = '50'
	--		if @@ERROR <> 0
	--		begin
	--			rollback 
	--		end
	--	commit
		--UPDATE OTH_PAYER1_PRIMEID
		BEGIN TRANSACTION 
			UPDATE OUTB_PROF_DETAIL
			SET OTH_PAYER1_PRIMEID = C.CMS_CONTRACT_NUM 
			FROM OUTB_PROF_DETAIL CD
			JOIN OUTB_PROF_HEADER C
			ON C.CLAIM_ID = CD.CLAIM_ID
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		
		DECLARE @sourcedatakey INT
	    SET @sourcedatakey = (SELECT DISTINCT SOURCEDATAKEY FROM DBO.OUTB_PROF_DETAIL);
		-------------------------------------
		-- sdk=50/2
        -------------------------------------
		
	 	 /*
		RETM-605
			The below will re-order the modifier code based on the order it arrived minus duplicate entries.
			The first CTE groups and assigns the order based on the MIN sequence
			The second CTE pivots the data based on the modifier position
			The update applies the modifier to the detail table based on the prior CTE ordering
			The claimline is cast as INT as it should really be an integer but isn't in the tables.  This assist with Leon data.
			If a claim has more than 4 modifier codes, they will fall out of this query (more than 4 codes isn't valid for submission anyways).
			Modifiers are cast as varchar(2).
		*/
		WITH re_sequencer AS (
   			SELECT 
       			cm.CLAIMID, cm.CLAIMLINEID, cm.MODIFIERCODE, cm.PROCEDURECODE,        
       			MOD_SEQUENCE = CONCAT('MOD-',ROW_NUMBER() OVER (PARTITION BY cm.CLAIMID, cm.CLAIMLINEID, cm.PROCEDURECODE ORDER BY MIN(cm.SEQUENCE) ASC))
   			FROM EDPS_Data.dbo.CLAIMMODIFIERDIM cm 
   			WHERE EXISTS (SELECT * FROM dbo.OUTB_PROF_DETAIL opd WHERE opd.CLAIM_ID = cm.CLAIMID)
   			GROUP BY cm.CLAIMID, cm.CLAIMLINEID, cm.MODIFIERCODE, cm.PROCEDURECODE
		),
   			results AS (
   			SELECT
       			CLAIMID
       		   ,CLAIMLINEID   
       		   ,PROCEDURECODE
       		   ,p.[MOD-1]
       		   ,p.[MOD-2]
       		   ,p.[MOD-3]
       		   ,p.[MOD-4]    
   			FROM re_sequencer
   			PIVOT (
       			MAX(MODIFIERCODE)
       			FOR MOD_SEQUENCE IN ([MOD-1],[MOD-2],[MOD-3],[MOD-4])
   			)p
		)
		UPDATE opd
		SET  opd.PROC_MOD1 = ISNULL(TRY_CAST(rs.[MOD-1] AS VARCHAR(2)),'') 
   			,opd.PROC_MOD2 = ISNULL(TRY_CAST(rs.[MOD-2] AS VARCHAR(2)),'')
   			,opd.PROC_MOD3 = ISNULL(TRY_CAST(rs.[MOD-3] AS VARCHAR(2)),'')
   			,opd.PROC_MOD4 = ISNULL(TRY_CAST(rs.[MOD-4] AS VARCHAR(2)),'')
		FROM dbo.OUTB_PROF_DETAIL opd
		JOIN results rs
   			ON rs.CLAIMID = opd.CLAIM_ID
   			AND CAST(rs.CLAIMLINEID AS INT) = CAST(opd.CLAIM_LINE_NO AS INT)
   			AND opd.PROC_CD = rs.PROCEDURECODE; 


		--1490 end
		------------------------------------------------
		------------------------------------------------
		--UPDATE EMER_FLAG
-- commenting out per TETDM-1217 SWALLER
		--begin transaction 
		--	update dbo.OUTB_PROF_DETAIL
		--	set EMER_FLAG = EAD.AdmissionTypeCode
		--	FROM dbo.OUTB_PROF_HEADER EC
		--		,dbo.OUTB_PROF_DETAIL ECD
		--		,EDPS_DATA.dbo.EventAdmissionDim EAD
		--	WHERE EC.CLAIM_ID = ECD.CLAIM_ID
		--		AND EC.REFERRAL_NO = EAD.AuthorizationID
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		
			
		--UPDATE REV_CD1
		begin transaction 
			update dbo.OUTB_PROF_DETAIL
			set REV_CD1 = CR.revenuecode
			FROM dbo.OUTB_PROF_DETAIL ECD
				,EDPS_DATA.DBO.ClaimLineRevenueCodeDim CR
			WHERE ECD.CLAIM_ID = CR.claimid
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	

		----TETDM-1613 REMOVED REV_CD2 AND REV_CD3 UPDATES BY MVEGA PER REQUEST
		----UPDATE REV_CD2
		--begin transaction 
		--	update dbo.OUTB_PROF_DETAIL
		--	set REV_CD2 = CR.revenuecode
		--	FROM dbo.OUTB_PROF_DETAIL ECD
		--		,EDPS_DATA.dbo.ClaimLineRevenueCodeDim CR
		--	WHERE ECD.CLAIM_ID = CR.claimid
		--		AND REV_CD1 <> CR.revenuecode
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit	


		----UPDATE REV_CD3
		--begin transaction 
		--	update dbo.OUTB_PROF_DETAIL
		--	set REV_CD3 = CR.revenuecode
		--	FROM dbo.OUTB_PROF_DETAIL ECD
		--		,EDPS_DATA.dbo.ClaimLineRevenueCodeDim CR
		--	WHERE ECD.CLAIM_ID = CR.claimid
		--		AND REV_CD1 <> CR.revenuecode
		--		AND REV_CD2 <> CR.revenuecode
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		
			--ANESTHESIA FLAG UPDATE
		--BEGIN TRANSACTION 
		--	UPDATE dbo.OUTB_PROF_DETAIL
		--	SET ANES_FLAG =  'MJ'
		--	WHERE PROC_CD BETWEEN '00100' AND '01999'
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
	

		 --TETDM-1710
        --------------------------------
		--ANES_2018
		--------------------------------
		UPDATE D 
		SET ANES_FLAG = 'MJ'
		FROM
		  dbo.OUTB_PROF_DETAIL D,
          dbo.ANES_2018 A
		WHERE A.ANES_CODE = D.PROC_CD
		 -- AND D.SERV_START_DT >= '20180101'

		-------------------------------
		-- ANES MODIFIER 2014-2017
		-------------------------------
		UPDATE D 
		SET ANES_FLAG = 'MJ'
		FROM
		  dbo.OUTB_PROF_DETAIL D,
          dbo.ANES_2014_2017 A
		WHERE A.ANES_CODE = D.PROC_CD
		--  AND D.SERV_START_DT >= '20140101'
		--  AND D.SERV_END_DT <= '20171231'

       


		--FACETS CONTRACT_CODE,CONTRACT_TYPE UPDATES
		--UPDATE OUTB_PROF_DETAIL
		--SET CONTRACT_CODE = ' '
		--	,CONTRACT_TYPE = ' '
		--WHERE SOURCEDATAKEY = '30'
		
		--
		UPDATE OUTB_PROF_DETAIL
		SET OPTIONAL_RPT_IND1 = 'I'
		WHERE PROC_CD IN  ('0L6','$INT')
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RESEND


		--TETDM-937 - 	CMS Reject-  Procedure description must be present if Proc Cd does not definitively describe the service 
		UPDATE outb_prof_detail 
		SET PROC_DESC = SUBSTRING(PM.PROCEDUREDESC,1,80)
		FROM OUTB_PROF_DETAIL D
		INNER JOIN edps_data.dbo.PROCEDURECODEDIM PM 
		ON D.SOURCEDATAKEY = PM.SOURCEDATAKEY 
		AND D.PROC_CD = PM.procedurecode	
		AND PM.ACTIVE = '1'
		
			
		---TETDM-1217
		UPDATE OUTB_PROF_DETAIL 
		SET EMER_FLAG = RTRIM(CA.EmergencyFlag)
		FROM edps_data.dbo.claimlineadditionaldatadim ca
		INNER JOIN OUTB_PROF_DETAIL P
		ON CA.SOURCEDATAKEY = P.SOURCEDATAKEY 
		AND CA.CLAIMID = P.CLAIM_ID 
		AND CONVERT(INT, CA.CLAIMLINEID) = CONVERT(INT, P.CLAIM_LINE_NO)
		WHERE CA.EmergencyFlag = 'Y'
		
				 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_DETAIL)
									
		----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_PROF_CLMDETAIL'
							AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
						















