﻿



CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_PROF_REMOVE_DUP_ADJUSTMENTS]

AS

/***************************************************************************************************
** CREATE DATE:	10/2017
**
** AURTHOR: John Bartholomay
**
** DESCRIPTION: Procedure will Remove duplicates causing balancing issue, identified in
**              TETDM-1645
**
**             
**              
**             
**
**
Modification History
====================
Date                Who                        Description
----------------------------------------------------------------------------------------------------
10/20/2017     John Bartholomay     TETDM-1645 Remove Duplicate Adjusments causing balancing at WIPRO


-----------------------------------------------------------------------------------------------------*/


     -------------------------------------------
     --Init Run controls
	 ------------------------------------------
       INSERT INTO EXT_SYS_RUNLOG
                    (PROC_NAME
                    ,STEP
                    ,START_DT
                    ,END_DT
                    ,RUN_MINUTES
                    ,TOTAL_RECORDS
                    ,ENTRYDT
                    )
                    VALUES('pr_BUILD_OUTB_PROF_REMOVE_DUP_ADJUSTMENTS'
                                 ,'2'
                                 ,GETDATE()
                                 ,NULL
                                 ,NULL
                                 ,0
                                 ,GETDATE()
                                 )

      ---------------------------------------------------
      -- IDENTIFY ADJUSTS THAT ARE THE SAME
      -- ONLY SEND ONE
      ---------------------------------------------------
	  if OBJECT_ID ('tempdb..#TEMP_REMOVE_ADJUSTMENTS') <> 0
 	 drop table #TEMP_REMOVE_ADJUSTMENTS
	

	  SELECT B.CLAIM_ID,B.CLAIM_LINE_NO, B.CLM_ADJ_REASON121, B.CLM_ADJ_GRP12,B.CLM_ADJ_AMT121
      INTO #TEMP_REMOVE_ADJUSTMENTS
      FROM dbo.OUTB_PROF_DETAIL A, 
           dbo.OUTB_PROF_DETAIL B
      WHERE A.CLAIM_ID = B.CLAIM_ID
        AND A.CLAIM_LINE_NO = B.CLAIM_LINE_NO
        AND A.CLM_ADJ_GRP111 IN ('CO','OA')
        AND A.CLM_ADJ_AMT111 = B.CLM_ADJ_AMT121
     --------------------------------------------------
     --REMOVE DUPLICATE ADJUSTMENT REASONS AND AMOUNTS
     --------------------------------------------------
      UPDATE CD  
      SET  CLM_ADJ_REASON121 = '',
           CLM_ADJ_GRP12 = '',
	       CLM_ADJ_AMT121 = ''
      FROM dbo.OUTB_PROF_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 IN ('CO','OA')
        AND CD.CLM_ADJ_AMT111 = T.CLM_ADJ_AMT121



      --------------------------------------------
      --     Update Run Controls
      --------------------------------------------
       DECLARE @TOTAL_RECORDS INT
                    
       SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #TEMP_REMOVE_ADJUSTMENTS)
                                               
       
             UPDATE 
                    EXT_SYS_RUNLOG
             SET END_DT = GETDATE()     
                    ,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
                    ,TOTAL_RECORDS = @TOTAL_RECORDS
                    ,ENTRYDT = GETDATE()
             WHERE 
                    PROC_NAME = 'pr_BUILD_OUTB_PROF_REMOVE_DUP_ADJUSTMENTS' 
                    AND END_DT IS NULL




