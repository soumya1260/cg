﻿CREATE PROCEDURE [dbo].[EDS_Generic_Retraction_Stage]
/********************************************************************************************************************************************************************
Notes:
	This procedure is used exclusively by the SSIS package Generic_Submission_Export_RETRACTION_Stage

	Initial Creation: 2024-12-09 Aaron Ridley 
	
	Modifications
	-------------


*********************************************************************************************************************************************************************/
AS

INSERT INTO dbo.EDS_Claims_Processing WITH (TABLOCK)
(CLAIMID, CLAIM_TYPE, LOB, LOB_CODE, HCFACODE, PBPCODE, SOURCEDATAKEY, SOURCEDESC, REGULATORYMARKET,
ISDENIED, ISDME, ISDMR, ISADJUSTMENT, ISMEDICAID, ISMEDICARE, ISRESUB, ISRETRACTION, RETRACTION_TYPE, ISEncounter, ENCOUNTERSOURCENAME, LOADDATE)
SELECT DISTINCT
	CLAIMID = smmcha.CLM_ID,
	CLAIM_TYPE = smmcha.CLM_TY,
	LOB = CASE smmcha.PRODT_TY
          	WHEN 'Medicare' THEN 'MAO'
			WHEN 'Medicaid' THEN 'Caid'
          	ELSE NULL
          END,
	LOB_CODE = NULL, --??--
	HCFACODE = IIF(LEN(smmcha.CNTRCT_NUM) <= 5,smmcha.CNTRCT_NUM,NULL),
	PBPCODE = IIF(LEN(smmcha.PBP_NUM) <= 3,smmcha.PBP_NUM,NULL),
	SOURCEDATAKEY = smmcha.SRC_DATA_KEY,
	SOURCEDESC = smmcha.SRC_DATA_DESC,
	REGULATORYMARKET = smmcha.REGLTY_MRKT,
	ISDENIED = CASE WHEN smmcha.CLM_STAT_TY_DESC = 'DENIED' THEN 1 ELSE 0 END, --??? 
	ISDME = CASE 
            	WHEN smmcha.CLM_TY = 'INSTITUTIONAL' THEN 0
            	ELSE IIF(smmcha.PROV_TAXNMY_CD IN ('332B00000X','332BC3200X','332BD1200X','332BN1400X','332BX2000X'),1,0) --DME taxonomy codes
            END,
	ISDMR = NULL, --???--medicaid only
	ISADJUSTMENT = 0,--IIF(smmcha.FREQ_CD IN ('7','8'),1,0),
	ISMEDICAID = IIF(smmcha.PRODT_TY = 'Medicaid',1,0),
	ISMEDICARE = IIF(smmcha.PRODT_TY = 'Medicare',1,0),
	ISRESUB = 0,
	ISRETRACTION = 1,
	RETRACTION_TYPE = RII.RETRACTION_TYPE,
	ISEncounter = IIF(smmcha.IS_ENCNTR_IND = 'Y' AND smmcha.SRC_DATA_KEY IN (144,142),1,0),
	ENCOUNTERSOURCENAME = smmcha.ENCNTR_SRC_VENDR_NM,
	LOADDATE = GETDATE()
FROM WIPRO.dbo.Retraction_Input_Interim RII
INNER JOIN OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD smmcha ON RII.ClaimID = smmcha.CLM_ID -- Potentially match on the DiagnosisCodes based on left 13 of ClaimID (sdk=40)
--LEFT JOIN EDIFECS.dbo.OSS_CLAIM_EXCLUSION_HIST excl ON smmcha.CLM_ID = excl.CLAIM_ID AND smmcha.SRC_DATA_KEY = excl.SOURCEDATAKEY
--LEFT JOIN WIPRO.dbo.RAES_OSS_COLLECTIONS_CONFIG rocc ON LEFT(smmcha.[HLTHPLN_IK],5) = rocc.HPLAN 
--														AND smmcha.SRC_DATA_KEY = rocc.SRC_DATA_KEY
--														AND smmcha.SVC_START_DT BETWEEN rocc.START_DT AND rocc.TERM_DT
--														AND rocc.ACTIVE = '1'
WHERE 1 = 1
	AND smmcha.[FNLZ_CLM_IND] = 'Y'
	AND RII.Retraction_status IS NULL
	AND NOT EXISTS (	SELECT
							*
						FROM dbo.EDS_Claims_Processing t
						WHERE 1 = 1
							AND t.CLAIMID = smmcha.CLM_ID
							AND t.CLAIM_TYPE = smmcha.CLM_TY
							AND t.SOURCEDATAKEY = smmcha.SRC_DATA_KEY);

/*---------------------------------------------------------------------------
Update recrods that already exist in the EDS Claims Processing table  
-----------------------------------------------------------------------------*/
UPDATE ecp
SET ecp.ISRETRACTION = 1,
    ecp.MEDICARESUBMISSIONDATE = NULL
FROM WIPRO.dbo.EDS_Claims_Processing ecp
WHERE 1 = 1
	AND EXISTS (SELECT * 
				FROM WIPRO.dbo.Retraction_Input_Interim RII
				WHERE 1 = 1
					AND RII.CLAIMID = ecp.CLAIMID 
					AND RII.Retraction_status IS NULL
					);

/*---------------------------------------------------------------------------
  Execute SDO data move from staging schema to target dbo schema 
-----------------------------------------------------------------------------*/

EXEC WIPRO.dbo.OSS_SDO_ClaimStage;

/*---------------------------------------------------------------------------
  Execute CSV data move from staging schema to target dbo schema 
-----------------------------------------------------------------------------*/

EXEC EDIFECS.dbo.OSS_INST_SDO_to_CSV_MAP @ISRETRACTION = 1;
EXEC EDIFECS.dbo.OSS_PROF_SDO_to_CSV_MAP @ISRETRACTION = 1;


/*---------------------------------------------------------------------------
  Start Export table updates 
-----------------------------------------------------------------------------*/

SELECT DISTINCT
	ecp.CLAIM_TYPE
   ,ecp.LOB
   ,ecp.SOURCEDATAKEY
   ,0 as ISADJUSTMENT
   ,ENCOUNTERSOURCENAME = IIF(ecp.ISEncounter = 0,NULL,ecp.ENCOUNTERSOURCENAME) 
   ,ecp.ISDME   
   ,ecp.ISRetraction
   ,RII.RETRACTION_TYPE
   ,ID = IDENTITY(INT, 1,1)
INTO #retraction_run_items
FROM WIPRO.dbo.EDS_Claims_Processing ecp
INNER JOIN WIPRO.dbo.Retraction_Input_Interim RII ON ecp.CLAIMID = RII.CLAIMID
WHERE ISRetraction = 1 
	AND MEDICARESUBMISSIONDATE IS NULL;


DECLARE @count INT,
		@LOB VARCHAR(25),
		@ISDME BIT,
		@CLAIM_TYPE VARCHAR(20),		
		@SOURCEDATAKEY INT ,		
		@ISADJUSTMENT BIT,
		@ENCOUNTERSOURCENAME VARCHAR(120), --Optional, if not provided, only non-encounters pulled.
		@IsResub BIT,  --Optional, if not provided, run regular claims;
		@IsRetraction BIT,
		@RETRACTION_TYPE VARCHAR(20);

WHILE EXISTS(SELECT * FROM #retraction_run_items) BEGIN  
	SELECT TOP 1
		 @count = ID
		,@LOB = LOB
		,@ISDME = ISDME
		,@CLAIM_TYPE = CLAIM_TYPE
		,@SOURCEDATAKEY = SOURCEDATAKEY
		,@ISADJUSTMENT = ISADJUSTMENT
		,@ENCOUNTERSOURCENAME = ENCOUNTERSOURCENAME
		,@IsResub = 0
		,@IsRetraction = IsRetraction
		,@RETRACTION_TYPE = RETRACTION_TYPE
	FROM #retraction_run_items;
	
	SELECT 1
	EXEC WIPRO.dbo.EDS_Claims_Processing_CSV_Insert @LOB = @LOB
												   ,@ISDME = @ISDME
												   ,@CLAIM_TYPE = @CLAIM_TYPE
												   ,@SOURCEDATAKEY = @SOURCEDATAKEY
												   ,@ISADJUSTMENT = @ISADJUSTMENT
												   ,@ENCOUNTERSOURCENAME = @ENCOUNTERSOURCENAME
												   ,@IsResub = @IsResub
												   ,@IsRetraction = @IsRetraction
												   ,@RETRACTION_TYPE = @RETRACTION_TYPE;
	
	
	DELETE 
	FROM #retraction_run_items 
	WHERE ID = @count;

END;