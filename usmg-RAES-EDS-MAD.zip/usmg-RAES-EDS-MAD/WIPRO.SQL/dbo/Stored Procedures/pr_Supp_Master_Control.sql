﻿CREATE PROCEDURE [dbo].[pr_Supp_Master_Control]
/******************************************
Create Date: 7/24/2019
Author: Anthony Ulmer

NOTES:
TETDM-2457 Removed Encounters (work done in "Specific Filters" now)
*/
AS

SET NOCOUNT ON;

DECLARE @Run_Date_Start_Time DATETIME2 = GETDATE(),
		@proc VARCHAR(1000) = NULL,
		@time DATETIME2 = NULL,
		@query NVARCHAR(MAX),
		@runstart DATETIME2 = NULL;

DECLARE @run_procedures TABLE
(
    RunProcedure VARCHAR(100),
    StartDate datetime2,
	ExecOrder int
);

--DECLARE @run_time_Table TABLE --DEBUG ONLY
--(
--	exec_time INT NULL,
--	proc_name VARCHAR(150) NULL
--);

--Blanket filters    
INSERT INTO @run_procedures (ExecOrder, RunProcedure)
	VALUES (1,'pr_Supp_Status_Code_111');
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (2,'pr_Supp_Status_Code_222', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (3,'pr_Supp_Status_Code_333', @Run_Date_Start_Time);

--Specific Filters
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (4,'pr_Supp_Status_Code_001', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (5,'pr_Supp_Status_Code_002', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (6,'pr_Supp_Status_Code_003', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (7,'pr_Supp_Status_Code_004_MAO004', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (8,'pr_Supp_Status_Code_004_MAO002', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (9,'pr_Supp_Status_Code_005_REJ', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (10,'pr_Supp_Status_Code_005_SUB', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (11,'pr_Supp_Status_Code_006_Provider_Preclusion', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (12,'pr_Supp_Status_Code_007_Claim_Exclusion', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (13,'pr_Supp_Status_Code_008_NPI_A_R', @Run_Date_Start_Time); 
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (14,'pr_Supp_Status_Code_008_NPI_SUB', @Run_Date_Start_Time); 
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (15,'pr_Supp_Status_Code_008_CLM_A_R', @Run_Date_Start_Time); 
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (16,'pr_Supp_Status_Code_008_CLM_SUB', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (17,'pr_Supp_Status_Code_008_MBR_A_R', @Run_Date_Start_Time);
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (18,'pr_Supp_Status_Code_008_MBR_SUB', @Run_Date_Start_Time);

--Encounters --DEPRECATED
--INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate) 
--	VALUES (19,'pr_Supp_Status_Code_009_E_NPI_A_R', @Run_Date_Start_Time);
--INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate) 
--	VALUES (20,'pr_Supp_Status_Code_009_E_NPI_SUB', @Run_Date_Start_Time);
--INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
--	VALUES (21,'pr_Supp_Status_Code_009_E_CLM_A_R', @Run_Date_Start_Time);
--INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
--	VALUES (22,'pr_Supp_Status_Code_009_E_CLM_SUB', @Run_Date_Start_Time);
--INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
--	VALUES (23,'pr_Supp_Status_Code_009_E_MBR_A_R', @Run_Date_Start_Time);
--INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
--	VALUES (24,'pr_Supp_Status_Code_009_E_MBR_SUB', @Run_Date_Start_Time);

--Run updates to table
INSERT INTO @run_procedures (ExecOrder, RunProcedure, StartDate)
	VALUES (25,'pr_Supp_Update_Supplemental_Table', @Run_Date_Start_Time);

DECLARE cur CURSOR FAST_FORWARD READ_ONLY LOCAL FOR
	SELECT 
		RunProcedure, StartDate
	FROM @run_procedures
	ORDER BY ExecOrder;

OPEN cur;

FETCH NEXT FROM cur INTO @proc, @time;

WHILE @@FETCH_STATUS = 0 BEGIN

	SET @runstart = GETDATE();
	SET @query = CONCAT('EXECUTE wipro.dbo.', @proc, IIF(@time IS NOT NULL,CONCAT(' @Run_Date_Start_Time = ''',@time,''''),'') );
	--SELECT @proc, @time, @query; --DEBUG ONLY
	EXEC sys.sp_executesql @query;
	--INSERT INTO @run_time_Table (exec_time, proc_name)
	--	SELECT DATEDIFF(MINUTE,@runstart, GETDATE()), @proc; --DEBUG ONLY

	FETCH NEXT FROM cur INTO @proc, @time;

END;

CLOSE cur;
DEALLOCATE cur;

--rebuild indexes
ALTER INDEX ALL ON WIPRO.dbo.Supplemental_INPUT REBUILD;

SET NOCOUNT OFF;

