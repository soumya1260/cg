﻿CREATE PROCEDURE [dbo].[EXSP_WIPRO_CLAIM_EXCLUSION]     
	(@sourcedatekey int,     
	 @exclusionmode CHAR(1) = 'R' --Migration Exclusions     
	)     
AS     

SET NOCOUNT ON;
/***************************************************************************************************     
** CREATE DATE: 10/26/2012     
**     
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM     
**     
** DESCRIPTION: Procedure will identify all HS Claims eligible for HRP Claim Encounter File Exclusion.     
**               HRP Claim File Exclusion Logic:     
**				 #1 - HRP CMS ICN Claims - Exclude all claims from current outbound claim file(s) that      
**				 have a current HRP claim status of Accepted AND a CMS ICN number.      
**				 #2 - HRP Accpeted Claims - Exclude all claims from current claim file(s) that have a      
**				 current HRP claim status of Accepted.      
**				 #3 - HRP Rejected Claim - Exclude all claims from current claim file(s) that have a      
**				 current status of Rejected AND the last EDPS update is within last 31 days.      
**				 #4 - HRP Recently submitted Claim - Exclude all claims from current claim file(s) that do not      
**				 have a current status AND the last EDPS update is within last 14 days.      
**     
Modification History     
====================     
Date			Who				Description     
     
-----------------------------------------------------------------------------------------------------     
01/03/13		LOYAL RICKS		ADD HPLAN EXCLUSION LOGIC     
01/05/2013		LOYAL RICKS		ADD PARAMERTER VALUES @EXCL_DAYS,@REJ_EXCL_DAYS	     
01/17/13		LOYAL RICKS		REMOVE USE OF ##EDPSPROD_CLMSTAT, REPLACE WITH VW_CLAIM_STATUS     
02/18/13		LOYAL RICKS		USE #TMP INSTEAD OF ##TMP     
03/06/2012		LOYAL RICKS		HPLAN EXCLUDE REVISION WHERE ACTIVE_FLAG = 'Y', ONLY ACTIVE ROWS     
03/06/2012		LOYAL RICKS		ADD NEW CLAIM EXCLUSION LOGIC - EXCLUDE FROM OUTBOUND SUBMISSION      
								ALL CLAIMS THAT HAVE A CLAIMDETAILDIM LILNE WITH AT LEAST 1 BEGINSERVICEDATEKEY     
								ON OR AFTER THE FIRST DAY OF THE PREVIOUS MONTH FOR THE DAY OF EXECUTION.     
								EXAMPLE: Process is executed on 3/6/13, all claims with at least 1 service line     
								beginservicedatekey is >= 2/1/13 (Greater than or equal to)      
03/22/2012		LOYAL RICKS		EZCap Intrest claims exlcusion added to invalid procedure code list     
								EZCap invalid diagnosis code added	     
03/26/2013						Remove 2013 DOS Exclusions		     
04/07/13						Add Provider exclusion logic     
04/23/2013						Add exclusion for claims that are not in claimdiagnosisdim, these claims     
								are missing pointer information. Additional logic may be needed to derrive     
								pointers.     
05/13/2012		Loyal Ricks		Alter EXT_HRP_CLAIM_EXCLUSION - Add EXCL_ID on insert for every exclusion category     
								Revise process to support required maintenance to support EXT_HRP_CLAIM_EXCLUSION_HIST      
								table which will be used via RRS reporting.	     
05/14/2013		Loyal Ricks		Invalid PlaceofServiceCode (claimdetaildim)	     
06/25/2013		Loyal Ricks		Revise Exclusion Code 9001, 360 & Exams to include wild card seach 	     
07/02/2013		Loyal Ricks		Append Exclusion Code History (9000 Series) from EXT_HRP_CLAIM_EXCLUSION_HIST - SHOULD      
								decrease processing by using existing data on every execution.	     
03/18/2014		Loyal Ricks		Reassign default value from R (Regular Exclusions) to M (Migration exclusions)     
								Add If block when @Exclusionmode <> 'M' to run process in "regular mode"     
-----------------------------------------------------------------------------------------------------------------------     
	WIPRO Implementation     
	     
08/05/2014		Loyal Ricks		WIPRO required revisions		     
09/23/2014		Loyal Ricks		Add Adjustments to exclusion. Need to ensure these are not submitted	     
11/12/2014		Loyal Ricks		10W40/Missing WIPRO Clmstat revision - temp rivisions to support QA due to missing      
								clmstat     
								Add logic to exclude any claim that has been submitted in a QA file     
11/13/2014		Loyal Ricks		Increase #migrate_fileid.fileid length from 20 to 50     
06/17/15		Loyal Ricks		Revise MAO002 Exclusion, add CLMSTAT_STATUS IN ('A-ICN','R-ICN')     
09/24/15		Loyal Ricks		Add logic to exclude clmstat_status ('A-ICN','R-ICN') with no check for ICN_NUMBER      
								due to current issue of no ICN being populated from the inbound MAO-002 file.      
								EDS team to do additional research to identify root cause. Due to this gap duplicate     
								claims are being submitted because the existing logic checks the status and existence     
								of a ICN_NUMBER.     
07/05/2016		Loyal Ricks		TETDM-783 - Add "MAO-004" to Exclusion Id -1 in order to prevent resubmission of claims with a stauts of MAO-004     
								TETDM-784 - Add "A-999" to Exclusion id 1 to prevent resubmission of accepted 999, add Exclusion Id 5 for rejected     
								999 status to prevent resubmission based on parameter days value.     
								TETDM-785- Add "A-277" to Exclusion id 1 to prevent resubmission of accepted 999, add Exclusion Id 6 for rejected     
								277 status to prevent resubmission based on parameter days value     
09/19/2016		Loyal Ricks		TETDM-1040 Add logic to not pull encounter exclusion. Current encoutner exclusion     
								--is duplicate encounter excl_id - 444444444. EDS team will use max(filename) to select      
								--appropriate encounterclaimdim record. Do not include this excl_id in exclusion build     
								--in order for max(filename) record to be eligible for selection.     
07/20/2017		Subhash Acharya JIRA TETDM-1570 fix to the resubmission of claims before desired time frame.  
09/20/2017		Mike Vega		TETDM-1570 reversed Subash's fix above, changed Type '3' condition logic from '>' back to '<'.  
01/17/2017		Scott Waller	TETDM-1719 Performance Enhancements to EXSP_WIPRO_CLAIM_EXCLUSION  
09/18/2018		Anthony Ulmer	TETDM-1598 Added @MAO002_Rej_Excl_days exclusion to procedure, removed 'R-ICN' from lines 191 and 199
05/09/19		Scott Waller	TETDM-2011 Remove redundant logic for Excl_ID = 1, and also there are INSERT statements that join 
								to ClaimDetailDim and ClaimDiagnosisDim and insert the claimid into the table once for each row in those
								two tables.  It just needs to be in the table ONCE in order to be excluded.
								Also, use a single GETDATE value for BATCH_RUN_DT so DISTINCT statements work correctly.
01/25/2020      Aaron Ridley    TETDM-2215 Add Logic for SOS exclusions 7000/7001. Moving recs from Excl History 
                                 to the Exclusion table when the sourcedatakeys do not match SDK=4
03/04/2020      Aaron Ridley    TETDM-2247 Add logic for SOS exclusions 7000/7001. Moving recs to Excl Historu
                                to the Excl table when sourcedatakeys do not match SDK not equal 4 
11/05/2020      Henry Faust     TETDM-2364 Remove Exclusion ID 7
                                I also updatd the SYS_RUNLOG entry to be EXSP_WIPRO_CLAIM_EXCLUSION
12/04/2020      Aaron Ridley	TETDM-2429 Add R-ICN exclusion back into process. Uncomment code
03/11/2021		Anthony Ulmer	TETDM-2474 Refactored exclusion pull for the <> 'M' path to increase performance
*****************************************************************************************************/	     
		DECLARE     
			@TOTAL_RECORDS INT     
			,@EXCL_DAYS		INT     
			,@REJ_EXCL_DAYS	INT     
			,@FILEID VARCHAR(20)     
			,@REJ_999_EXCL_DAYS INT  
			,@REJ_277_EXCL_DAYS INT
			,@MAO002_Rej_Excl_days INT
			,@CURRENTDATE date;

		select @CURRENTDATE = getdate()
			     
			--HRP_CLAIM_FILE Run controls     
			     
					INSERT INTO EXT_SYS_RUNLOG     
							(PROC_NAME     
							,STEP     
							,START_DT     
							,END_DT     
							,RUN_MINUTES     
							,TOTAL_RECORDS     
							,ENTRYDT     
							)     
					VALUES('EXSP_WIPRO_CLAIM_EXCLUSION'
							,'1'     
							,GETDATE()     
							,NULL     
							,NULL     
							,0     
							,GETDATE()     
							)     
					     
			     
		--ASSIGN VARIABLES      
		--GET VALUES FROM EXT_SYS_CLM_JOBCNTRL     
			     
		     
				SET @EXCL_DAYS = (SELECT CNTRL_VAL FROM EXT_SYS_CLM_JOBCNTRL     
												WHERE CNTRL_DESC = 'EXCLUSION DAYS'     
													and CNTRL_STATUS = 'A'     
													AND SOURCEDATAKEY = @sourcedatekey);     
				SET @REJ_EXCL_DAYS  = (SELECT CNTRL_VAL FROM EXT_SYS_CLM_JOBCNTRL      
												WHERE CNTRL_DESC = 'REJECTION EXCLUSION DAYS'     
													and CNTRL_STATUS = 'A'     
													AND SOURCEDATAKEY = @sourcedatekey);     
				SET @REJ_999_EXCL_DAYS  = (SELECT CNTRL_VAL FROM EXT_SYS_CLM_JOBCNTRL      
												WHERE CNTRL_DESC = '999 Rejection Exclusion Days'     
													and CNTRL_STATUS = 'A'     
													AND SOURCEDATAKEY = @sourcedatekey);     
				SET @REJ_277_EXCL_DAYS  = (SELECT CNTRL_VAL FROM EXT_SYS_CLM_JOBCNTRL      
												WHERE CNTRL_DESC = '277 Rejection Exclusion Days'     
													and CNTRL_STATUS = 'A'     
													AND SOURCEDATAKEY = @sourcedatekey);     
     			
--TETDM-1598
				SET @MAO002_Rej_Excl_days  = (	SELECT 
													CNTRL_VAL 
												FROM EXT_SYS_CLM_JOBCNTRL      
												WHERE CNTRL_DESC = 'MAO002 Rejection Exclusion days'     
													and CNTRL_STATUS = 'A'     
													AND SOURCEDATAKEY = @sourcedatekey);     
     
     
     
				--GET beginning fileid for current cycle     
				SET @FILEID = (SELECT RTRIM(CNTRL_TXT) FROM EXT_SYS_CLM_JOBCNTRL     
												WHERE SOURCEDATAKEY = '999'     
														AND CNTRL_STATUS = 'A');     
								     
								IF OBJECT_ID('TEMPDB..#EXT_CLAIM_EXCLUSION') <> 0     
								DROP TABLE #EXT_CLAIM_EXCLUSION     
								     
								CREATE TABLE #EXT_CLAIM_EXCLUSION     
								(	ID BIGINT IDENTITY(1,1) PRIMARY KEY CLUSTERED,
									CLAIM_ID VARCHAR(20)     
									,SOURCDATAKEY INT     
									,BATCH_RUN_DT datetime     
									,EXCL_ID int     
									,FILEID VARCHAR(50)     
									     
								)WITH (DATA_COMPRESSION = PAGE);
								
								
			TRUNCATE TABLE  WIPRO.dbo.EXT_CLAIM_EXCLUSION     

			ALTER INDEX ALL ON WIPRO.dbo.EXT_CLAIM_EXCLUSION     
			DISABLE;

			if @exclusionmode <> 'M' --Migration Exclusions     
								     
			begin          
										--Exclusion #1 - CLAIMS WITH CMS ICN NUMBERS     
/* TETDM-2011 this INSERT is rundunant logic.  
   The next statement captures the same claims as this one does										     
										INSERT INTO #EXT_CLAIM_EXCLUSION     
										select DISTINCT CLAIM_ID,SOURCEDATAKEY,@CURRENTDATE AS 'BATCH_RUNDT',1,FILEID     
										from OUTB_CLAIM_STATUS     
										where len(CMS_ICN) > 0     
												and CLMSTAT_STATUS IN ('A-ICN','MAO-004')     
												and SOURCEDATAKEY = @sourcedatekey     
-- TETDM-1719							ORDER BY SOURCEDATAKEY,CLAIM_ID     
*/
										--09-24-15 Revision     
--	TETDM-2011 join to encounterclaimdim or claimdim tables so that we only INSERT claims that 
--	are currently in our master tables.
--	ONLY putting this logic on on Exclusion #1 because these account for at least 75% of all the exlcusions that are collected


/*
TETDM-2474
	This update was to improve the runtime of this procedure
	The prior individual filters were consolidated into the section below.
	The unpivot provides the same output that was present in the previous individual filters.
	The exist statement is to provide similar functionality to the existance check towards the end of this procedure
		The exist makes sure we are only looking at claims we have present in our claims table vs the entire catalog of sent claims in the outbound claim status table
	This refactoring ONLY affected the "NOT M" path of this procedure There were no functional changes to the "M" path of this procedure
*/


							IF @sourcedatekey = 4
								BEGIN
										INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION  WITH (TABLOCK) 
											(CLAIM_ID,SOURCEDATAKEY,BATCH_RUN_DT,EXCL_ID) 
										SELECT DISTINCT a.CLAIM_ID, a.SOURCEDATAKEY, @CURRENTDATE AS 'BATCH_RUNDT', 1    
										FROM OUTB_CLAIM_STATUS a										
										WHERE 1 = 1
											AND a.CLMSTAT_STATUS IN ('A-ICN','MAO-004','A-999','A-277')     
											AND a.SOURCEDATAKEY = @sourcedatekey     
											AND EXISTS (SELECT * FROM EDPS_Data.dbo.encounterclaimdim e WHERE e.ClaimNum = CLAIM_ID); --don't need SDK join here, all items in encounterclaimdim are SDK 4


										INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION  WITH (TABLOCK) 
											(CLAIM_ID,SOURCEDATAKEY,BATCH_RUN_DT,EXCL_ID)
										SELECT DISTINCT
											upvt.CLAIM_ID,
											upvt.sourcedatakey,
											upvt.BATCH_RUN_DT,
											upvt.Exclusion_ID
										FROM (
												SELECT
													vcs.CLAIM_ID
													,vcs.sourcedatakey
													,@CURRENTDATE AS 'BATCH_RUN_DT'
													,vcs.FILEID
													,IIF(ocs.CLMSTAT_STATUS = 'A' ,2,NULL) AS 'Excl_2'
													,IIF(ocs.CLMSTAT_STATUS = 'R' AND DATEDIFF(D,ocs.LAST_UPD_DATE,@CURRENTDATE) <  @REJ_EXCL_DAYS,3,NULL) AS 'Excl_3'
													,IIF(ocs.CLMSTAT_STATUS IS NULL AND DATEDIFF(D,ocs.LAST_UPD_DATE,@CURRENTDATE) <  @EXCL_DAYS,4,NULL) AS 'Excl_4'
													,IIF(ocs.CLMSTAT_STATUS = 'R-999' AND DATEDIFF(D,ocs.LAST_UPD_DATE,@CURRENTDATE) <  @REJ_999_EXCL_DAYS,5,NULL) AS 'Excl_5'
													,IIF(ocs.CLMSTAT_STATUS = 'R-277' AND DATEDIFF(D,ocs.LAST_UPD_DATE,@CURRENTDATE) <  @REJ_277_EXCL_DAYS,6,NULL) AS 'Excl_6'
													,IIF(ocs.CLMSTAT_STATUS = 'R-ICN' AND DATEDIFF(D,ocs.LAST_UPD_DATE,@CURRENTDATE) <  @MAO002_Rej_Excl_days,7,NULL) AS 'Excl_7'
												FROM WIPRO.dbo.VW_CLAIM_STATUS vcs
												JOIN WIPRO.dbo.OUTB_CLAIM_STATUS ocs
													ON vcs.CLAIM_ID = ocs.CLAIM_ID
													AND vcs.FILEID = ocs.FILEID
													AND vcs.sourcedatakey = ocs.SOURCEDATAKEY										
												WHERE 1 = 1
													AND ocs.sourcedatakey = @sourcedatekey
													AND EXISTS (SELECT * FROM EDPS_Data.dbo.encounterclaimdim e WHERE e.ClaimNum = ocs.CLAIM_ID)) sub --All claims in encounterclaimdim are SDK 4, no need for extra SDK clause here
										UNPIVOT ( Exclusion_ID FOR ex_no IN (sub.Excl_2,sub.Excl_3,sub.Excl_4,sub.Excl_5,sub.Excl_6,sub.Excl_7)) upvt
										--unpivot will eliminate nulls (where all items resolve to null) but that is ok here (we don't want items that don't pass "test")
										OPTION (OPTIMIZE FOR (@sourcedatekey = 4));

										SET @TOTAL_RECORDS = @@rowcount;

								END
							ELSE
								BEGIN				
										INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION  WITH (TABLOCK) 
											(CLAIM_ID,SOURCEDATAKEY,BATCH_RUN_DT,EXCL_ID)    
										SELECT DISTINCT a.CLAIM_ID, a.SOURCEDATAKEY, @CURRENTDATE AS 'BATCH_RUNDT', 1  
										FROM OUTB_CLAIM_STATUS a
										WHERE 1 = 1
											AND a.CLMSTAT_STATUS IN ('A-ICN','MAO-004','A-999','A-277')     
											AND a.SOURCEDATAKEY = @sourcedatekey
											AND EXISTS (SELECT * FROM EDPS_Data.dbo.CLAIMDIM c WHERE c.CLAIMID = a.CLAIM_ID AND c.SOURCEDATAKEY = a.SOURCEDATAKEY)

										INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION  WITH (TABLOCK) 
											(CLAIM_ID,SOURCEDATAKEY,BATCH_RUN_DT,EXCL_ID) 
										SELECT DISTINCT
											upvt.CLAIM_ID,
											upvt.sourcedatakey,
											upvt.BATCH_RUN_DT,
											upvt.Exclusion_ID
										FROM (
												SELECT
													vcs.CLAIM_ID
													,vcs.sourcedatakey
													,@CURRENTDATE AS 'BATCH_RUN_DT'
													,vcs.FILEID
													,IIF(ocs.CLMSTAT_STATUS = 'A' ,2,NULL) AS 'Excl_2'
													,IIF(ocs.CLMSTAT_STATUS = 'R' AND DATEDIFF(D,ocs.LAST_UPD_DATE,@CURRENTDATE) <  @REJ_EXCL_DAYS,3,NULL) AS 'Excl_3'
													,IIF(ocs.CLMSTAT_STATUS IS NULL AND DATEDIFF(D,ocs.LAST_UPD_DATE,@CURRENTDATE) <  @EXCL_DAYS,4,NULL) AS 'Excl_4'
													,IIF(ocs.CLMSTAT_STATUS = 'R-999' AND DATEDIFF(D,ocs.LAST_UPD_DATE,@CURRENTDATE) <  @REJ_999_EXCL_DAYS,5,NULL) AS 'Excl_5'
													,IIF(ocs.CLMSTAT_STATUS = 'R-277' AND DATEDIFF(D,ocs.LAST_UPD_DATE,@CURRENTDATE) <  @REJ_277_EXCL_DAYS,6,NULL) AS 'Excl_6'
													,IIF(ocs.CLMSTAT_STATUS = 'R-ICN' AND DATEDIFF(D,ocs.LAST_UPD_DATE,@CURRENTDATE) <  @MAO002_Rej_Excl_days,7,NULL) AS 'Excl_7'
												FROM WIPRO.dbo.VW_CLAIM_STATUS vcs
												JOIN WIPRO.dbo.OUTB_CLAIM_STATUS ocs
													ON vcs.CLAIM_ID = ocs.CLAIM_ID
													AND vcs.FILEID = ocs.FILEID
													AND vcs.sourcedatakey = ocs.SOURCEDATAKEY										
												WHERE 1 = 1
													AND ocs.sourcedatakey = @sourcedatekey
													AND EXISTS (SELECT * FROM EDPS_Data.dbo.CLAIMDIM c WHERE c.CLAIMID = ocs.CLAIM_ID AND c.SOURCEDATAKEY = ocs.SOURCEDATAKEY)) sub
										UNPIVOT ( Exclusion_ID FOR ex_no IN (sub.Excl_2,sub.Excl_3,sub.Excl_4,sub.Excl_5,sub.Excl_6,sub.Excl_7)) upvt
										--unpivot will eliminate nulls (where all items resolve to null) but that is ok here (we don't want items that don't pass "test")
										OPTION (OPTIMIZE FOR (@sourcedatekey = 50));

										SET @TOTAL_RECORDS = @@rowcount;
								END

								/*
								TETDM-2389
								NOTE:
									This was added to capture the below status during a "regular" job run
									A similar statement is in the EXT_CLAIM_EXCLUSION_HIST build procedure as well
									These exclusions are "permanent" but the claims are updated daily for this status via another external process
										so we need to run this as often as possible.
									These exclusions need to be present for all runs hence why they are going into the HIST table (this is more of a hack).
									The items from the HIST table are always added in the non-hist table at the end of this procedure (kind of a round-robin).
								*/
								INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST 
									(claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type)
								SELECT
									 ocs.CLAIM_ID
									,ocs.SOURCEDATAKEY
									,@CURRENTDATE
									,5
									,ocs.CLAIM_TYPE
								FROM WIPRO.dbo.OUTB_CLAIM_STATUS ocs
								WHERE 1 = 1
									AND ocs.CLMSTAT_STATUS IN ('A-Ace','UnWrk')
									AND NOT EXISTS (SELECT
														*
													FROM WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST eceh
													WHERE 1 = 1
														AND eceh.claim_id = ocs.CLAIM_ID
														AND eceh.claim_type = ocs.CLAIM_TYPE
														AND eceh.SOURCEDATAKEY = ocs.SOURCEDATAKEY
														AND eceh.EXCL_ID = 5);



/* Section removed via TETDM-2474
-- end TETDM-2011							     
										--Exclusion #2 -  HRP Accpeted Claims     
     
										INSERT INTO #EXT_CLAIM_EXCLUSION     
										select DISTINCT CS.CLAIM_ID,CS.SOURCEDATAKEY,@CURRENTDATE AS 'BATCH_RUN_DT',2,EC.FILEID     
										from #resovle_VW_CLAIM_STATUS EC     
												,OUTB_CLAIM_STATUS CS     
										where EC.CLAIM_ID = CS.CLAIM_ID     
											AND EC.FILEID = CS.FILEID      
											AND CS.CLMSTAT_STATUS = 'A'     
											and CS.SOURCEDATAKEY = @sourcedatekey     
-- TETDM-1719							ORDER BY CLAIM_ID     
										     
										     
										--Exclusion #3 -  HRP Rejected Claims     
										--Exclude all rejects that have been reported in the last @REJ_EXCL_DAYS     
     
									     
										INSERT INTO #EXT_CLAIM_EXCLUSION     
										select DISTINCT CS.CLAIM_ID,CS.SOURCEDATAKEY,@CURRENTDATE AS 'BATCH_RUN_DT',3,EC.FILEID     
										FROM #resovle_VW_CLAIM_STATUS EC     
												,OUTB_CLAIM_STATUS CS     
										where EC.CLAIM_ID = CS.CLAIM_ID     
											AND EC.FILEID = CS.FILEID      
											AND CS.CLMSTAT_STATUS = 'R'     
											and CS.SOURCEDATAKEY = @sourcedatekey     
											AND  DATEDIFF(D,CS.LAST_UPD_DATE,@CURRENTDATE) <  @REJ_EXCL_DAYS     
-- TETDM-1719							ORDER BY CLAIM_ID     
									     
										     
										--Exclusion #4 -  HRP Recently Submitted Claims     
      
										INSERT INTO #EXT_CLAIM_EXCLUSION     
										select DISTINCT CS.CLAIM_ID,CS.SOURCEDATAKEY,@CURRENTDATE AS 'BATCH_RUN_DT',4,EC.FILEID     
										FROM #resovle_VW_CLAIM_STATUS EC     
												,OUTB_CLAIM_STATUS CS     
										where EC.CLAIM_ID = CS.CLAIM_ID     
											AND EC.FILEID = CS.FILEID      
											AND CS.CLMSTAT_STATUS is null     
											and CS.SOURCEDATAKEY = @sourcedatekey     
											AND  DATEDIFF(D,CS.LAST_UPD_DATE,@CURRENTDATE) < @EXCL_DAYS     
-- TETDM-1719							ORDER BY CLAIM_ID     
											     
     
										---Exclusion #5 - Rejected 999 claims      
     
										INSERT INTO #EXT_CLAIM_EXCLUSION     
										select DISTINCT CS.CLAIM_ID,CS.SOURCEDATAKEY,@CURRENTDATE AS 'BATCH_RUN_DT',5,EC.FILEID     
										FROM #resovle_VW_CLAIM_STATUS EC     
												,OUTB_CLAIM_STATUS CS     
										where EC.CLAIM_ID = CS.CLAIM_ID     
											AND EC.FILEID = CS.FILEID      
											AND CS.CLMSTAT_STATUS = 'R-999'     
											and CS.SOURCEDATAKEY = @sourcedatekey     
											AND  DATEDIFF(D,CS.LAST_UPD_DATE,@CURRENTDATE) <  @REJ_999_EXCL_DAYS     
-- TETDM-1719							ORDER BY CLAIM_ID     
     
										---Exclusion #6 - Rejected 999 claims      
     
										INSERT INTO #EXT_CLAIM_EXCLUSION     
										select DISTINCT CS.CLAIM_ID,CS.SOURCEDATAKEY,@CURRENTDATE AS 'BATCH_RUN_DT',6,EC.FILEID     
										FROM #resovle_VW_CLAIM_STATUS EC     
												,OUTB_CLAIM_STATUS CS     
										where EC.CLAIM_ID = CS.CLAIM_ID     
											AND EC.FILEID = CS.FILEID      
											AND CS.CLMSTAT_STATUS = 'R-277'     
											and CS.SOURCEDATAKEY = @sourcedatekey     
											AND  DATEDIFF(D,CS.LAST_UPD_DATE,@CURRENTDATE) <  @REJ_277_EXCL_DAYS     

										
--TETDM-1598
--TETDM-2364  Remove Exclusion 7
--TETDM-2429 - Add exclusion 7
										INSERT INTO #EXT_CLAIM_EXCLUSION     
										select DISTINCT CS.CLAIM_ID,CS.SOURCEDATAKEY,@CURRENTDATE AS 'BATCH_RUN_DT',7,EC.FILEID     
										FROM #resovle_VW_CLAIM_STATUS EC     
												,OUTB_CLAIM_STATUS CS     
										where EC.CLAIM_ID = CS.CLAIM_ID     
											AND EC.FILEID = CS.FILEID      
											AND CS.CLMSTAT_STATUS = 'R-ICN'     
											and CS.SOURCEDATAKEY = @sourcedatekey     
											AND  DATEDIFF(D,CS.LAST_UPD_DATE,@CURRENTDATE) <  @MAO002_Rej_Excl_days  


-- TETDM-1719							ORDER BY CLAIM_ID     
--End TETDM-2474 removal
*/										     
										----Exclusion #5 -  Adjusted Claims     
     
										--BEGIN TRANSACTION      
										--INSERT INTO #EXT_CLAIM_EXCLUSION     
										--select CLAIMID,SOURCEDATAKEY,@CURRENTDATE AS 'BATCH_RUN_DT',5,' '     
										--FROM EDPS_Data.dbo.claimdim     
										--where (charindex('R',claimid) > 0     
										--		or charindex('A',claimid) > 0)     
										--		and sourcedatakey =@sourcedatekey     
										--ORDER BY CLAIMID     
										--	IF @@ERROR <> 0     
										--			BEGIN      
										--					ROLLBACK      
										--			END     
										--COMMIT     
										     
											     
										--exclude all claims submitted from EDPS_PROD     
										--A recent copy of EDPS_PROD.OUTB_CLAIM_STATUS is required     
										--INSERT INTO #EXT_CLAIM_EXCLUSION     
										--select claim_id,sourcedatakey,@CURRENTDATE,1     
										--from OUTB_CLAIM_STATUS_PROD     
										--where SOURCEDATAKEY = @sourcedatekey     
										--	and FILEID in (select FILEID from EXT_MAP_HIST_PROD     
										--					where CHARINDEX('PROD',HRPHEADER) > 0     
										--					OR FILEID IN ('CLAIM20121127151349','CLAIM20121127102607'))     
										--group by CLAIM_ID,SOURCEDATAKEY     
										--order by SOURCEDATAKEY,CLAIM_ID     
															     
										     
								end     
								     
								--Production Migration Exclusions     
								--Exclude all claims except Accepted claims from current cycle     
								     
								if @exclusionmode = 'M' --Migration Exclusions     
								     
								begin     
											--GET ALL CYCLE FILEID FOR SOURCEDATAKEY     
											IF OBJECT_ID('TEMPDB..#migrate_fileid') <> 0     
												DROP TABLE #migrate_fileid     
												     
											create table #migrate_fileid     
											(fileid VARCHAR(50)     
											)     
											     
											--Get all EDPS_DEV fileid from current cycle     
																	     
											     
											INSERT INTO #migrate_fileid     
											SELECT DISTINCT fileid     
											FROM OUTB_CLAIM_STATUS     
											WHERE SOURCEDATAKEY = @sourcedatekey     
												--AND FILEID >= @FILEID     
												and SUBSTRING(FILEID,1,8) = 'HSCE.DEV'     
												     
											--Get all Accepted Claims for current cycle     
											IF OBJECT_ID('TEMPDB..#migrate_claimid') <> 0     
												DROP TABLE #migrate_claimid     
												     
											create table #migrate_claimid     
											(     
											claim_id varchar(20)     
											)     
												insert into #migrate_claimid     
												select VS.CLAIM_ID      
													from dbo.VW_CLAIM_STATUS VS     
													JOIN OUTB_CLAIM_STATUS CS     
													ON VS.CLAIM_ID = CS.CLAIM_ID     
													AND VS.sourcedatakey = CS.SOURCEDATAKEY     
													AND VS.FILEID = CS.FILEID     
									-----note     
									--11/12/14     
									---remove logic due to 10W40 and missing WIPRO clmstat     
									---modify process once "normal" processing is resumed     
													WHERE /*VS.FILEID >= @FILEID      
														AND CS.CLMSTAT_STATUS = 'A'     
														and*/ SUBSTRING(vs.FILEID,1,8) = 'HSCE.DEV'     
														AND CS.SOURCEDATAKEY = @sourcedatekey     
												     
												     
											--PURGE ALL CURRENT CYCLE FILEID,CLAIMID FROM #EXT_HRP_CLAIM_EXCLUSION     
											--This step will delete all claims associated with a migration fileid      
											--from temp exclusion table. This potentially will include multiple     
											--submissions (Rejected, Pend, Accepted) of a claim from testing     
											      
											DELETE FROM #EXT_CLAIM_EXCLUSION     
											WHERE fileid IN (SELECT fileid FROM #migrate_fileid)     
												     
											     
											--Purge all claims targeted for migration from #EXT_HRP_CLAIM_EXCLUSION     
											--This will include all excluded claims     
											--Exclusions may have been lifted during cycle but still exist in exclusion     
											--table because exclusion table has not been rebuilt. Exclusion rebuild     
											--normally happens before or after dev cycle.     
											     
											--begin transaction      
											--delete from #EXT_HRP_CLAIM_EXCLUSION     
											--where CLAIM_ID in (select CLAIM_ID from #migrate_claimid)     
											--IF @@ERROR <> 0     
											--		BEGIN      
											--				ROLLBACK      
											--		END     
											--COMMIT     
										     
											IF OBJECT_ID('TEMPDB..#all_claims') <> 0     
												DROP TABLE #all_claims     
												     
											create table #all_claims     
											(claimid varchar(20)     
											,sourcedatakey int     
											)     
											     
											insert into #all_claims     
											select distinct claimid,SOURCEDATAKEY     
											from CLAIMDIM     
											where SOURCEDATAKEY = @sourcedatekey     
											order by CLAIMID     
											     
											     
											delete      
											from #all_claims      
											where claimid in (select CLAIM_ID from #migrate_claimid)     
										     
											     
											--APPEND #all_claims into exclusions     
											insert into #EXT_CLAIM_EXCLUSION     
											select claimid,sourcedatakey,@CURRENTDATE,'9999',' '     
											from #all_claims     
											where claimid not in (select claim_id from #EXT_CLAIM_EXCLUSION)     
											     
											--Get all claims that have a "PROD" FILEID     
											     
											IF OBJECT_ID('TEMPDB..#prod_fileid') <> 0     
												DROP TABLE #prod_fileid     
												     
													create table #prod_fileid     
													(     
													fileid varchar(50)     
													)     
														     
														insert into #prod_fileid     
														SELECT FILEID     
														FROM OUTB_FILE_HIST     
														where FILE_TYPE = 'Claim Encounter'     
															AND CHARINDEX('PROD',FILEHEADER) > 0     
														ORDER BY ENTRYDT DESC     
																		     
															insert into #EXT_CLAIM_EXCLUSION     
															SELECT CLAIM_ID,SOURCEDATAKEY,@CURRENTDATE,'1',' '     
															FROM OUTB_CLAIM_STATUS CS     
															INNER JOIN #prod_fileid T     
															ON CS.FILEID = T.fileid     
															WHERE SOURCEDATAKEY = @sourcedatekey     
															order by sourcedatakey,claim_id     
														     
											----Append all claims associated to a HSCE.QA FILE     
															     
															insert into #EXT_CLAIM_EXCLUSION     
															SELECT CLAIM_ID,SOURCEDATAKEY,@CURRENTDATE,'1',' '     
															FROM OUTB_CLAIM_STATUS CS     
															WHERE SOURCEDATAKEY = @sourcedatekey     
																AND SUBSTRING(FILEID,1,7) = 'HSCE.QA'     
															order by sourcedatakey,claim_id   
															
									--TETDM-2474 added this segment to the "M" path to make sure it is run for code that uses this pathway (not sure if any jobs use this path)
									--  This is not needed for the "Not M" path as it was incorporated in the changes above.

									--	TETDM-2011 join to encounterclaimdim or claimdim tables so that we only INSERT claims that 
									--	are currently in our master tables.
									IF @sourcedatekey = 4
										BEGIN
											INSERT INTO EXT_CLAIM_EXCLUSION WITH (TABLOCK)  
											SELECT DISTINCT a.CLAIM_ID     
													,a.SOURCDATAKEY     
													,a.BATCH_RUN_DT     
													,a.EXCL_ID     
											 FROM #EXT_CLAIM_EXCLUSION a
											 INNER JOIN EDPS_Data.dbo.encounterclaimdim b
												on	b.sourcedatakey		= a.SOURCDATAKEY
												and	b.claimnum			= a.CLAIM_ID
										END
									ELSE
										BEGIN				
											INSERT INTO EXT_CLAIM_EXCLUSION WITH (TABLOCK)    
											SELECT DISTINCT a.CLAIM_ID     
													,a.SOURCDATAKEY     
													,a.BATCH_RUN_DT     
													,a.EXCL_ID     
											 FROM #EXT_CLAIM_EXCLUSION a
											 INNER JOIN EDPS_Data.dbo.claimdim b
												on	b.sourcedatakey		= a.SOURCDATAKEY
												and	b.CLAIMID			= a.CLAIM_ID
										END		


								end     


/*	removed in TETDM-2474							     
--APPEND EXCLUSIONS     
--	TETDM-2011 join to encounterclaimdim or claimdim tables so that we only INSERT claims that 
--	are currently in our master tables.
--							IF @sourcedatekey = 4
--								BEGIN
--									INSERT INTO EXT_CLAIM_EXCLUSION WITH (TABLOCK)  
--									SELECT DISTINCT a.CLAIM_ID     
--											,a.SOURCDATAKEY     
--											,a.BATCH_RUN_DT     
--											,a.EXCL_ID     
--									 FROM #EXT_CLAIM_EXCLUSION a
--									 INNER JOIN EDPS_Data.dbo.encounterclaimdim b
--										on	b.sourcedatakey		= a.SOURCDATAKEY
--										and	b.claimnum			= a.CLAIM_ID
--								END
--							ELSE
--								BEGIN				
--									INSERT INTO EXT_CLAIM_EXCLUSION WITH (TABLOCK)    
--									SELECT DISTINCT a.CLAIM_ID     
--											,a.SOURCDATAKEY     
--											,a.BATCH_RUN_DT     
--											,a.EXCL_ID     
--									 FROM #EXT_CLAIM_EXCLUSION a
--									 INNER JOIN EDPS_Data.dbo.claimdim b
--										on	b.sourcedatakey		= a.SOURCDATAKEY
--										and	b.CLAIMID			= a.CLAIM_ID
--								END		
---- end TETDM-2011
						     
---- TETDM-1719  
--								SET @TOTAL_RECORDS = @@ROWCOUNT  
*/  
								--Append exclusion history     
								--TETDM-1040 Add logic to not pull encounter exclusion. Current encoutner exclusion     
								--is duplicate encounter excl_id - 444444444. EDS team will use max(filename) to select      
								--appropriate encounterclaimdim record. Do not include this excl_id in exclusion build     
								--in order for max(filename) record to be eligible for selection.     

-- TETDM-2011	add DISTINCT to this insert statement so that any claim/sdk/excl_id combo is in the 
--				EXT_CLAIM_EXCLUSION_HIST table multiple times, aren't inserted multiple times in the
--				EXT_CLAIM_EXCLUSION table.  That currently happens.  We have a ticket to fix that, but 
--				this will take care of it in the mean time
--	TETDM-2011 join to encounterclaimdim or claimdim tables so that we only INSERT claims that 
--	are currently in our master tables.								
							IF @sourcedatekey = 4
								BEGIN
									INSERT INTO EXT_CLAIM_EXCLUSION WITH (TABLOCK)
									SELECT  a.CLAIM_ID     
											,a.sourcedatakey     
											,@CURRENTDATE	-- BATCH_RUN_DT     TETDN-2011
											,a.EXCL_ID     
									FROM EXT_CLAIM_EXCLUSION_HIST     a
									INNER JOIN EDPS_Data.dbo.encounterclaimdim b
										on	b.sourcedatakey		= a.SOURCEDATAKEY
										and	b.claimnum			= a.CLAIM_ID
									where a.sourcedatakey = @sourcedatekey     
									UNION  -- TETDM-2215 - Adding logic for SOS 7000/7001 to exclusion. SDK Mismatches
									SELECT CLAIM_ID, sourcedatakey,  @CURRENTDATE, EXCL_ID from EXT_CLAIM_EXCLUSION_HIST WHERE EXCL_ID in ('7000','7001')
								END
							ELSE
								BEGIN
									INSERT INTO EXT_CLAIM_EXCLUSION WITH (TABLOCK)  
									SELECT DISTINCT a.CLAIM_ID     
										,a.SOURCeDATAKEY     
										,@CURRENTDATE	-- BATCH_RUN_DT     TETDN-2011
										,a.EXCL_ID     
									FROM EXT_CLAIM_EXCLUSION_HIST     a
									 INNER JOIN EDPS_Data.dbo.claimdim b
										on	b.sourcedatakey		= a.SOURCEDATAKEY
										and	b.CLAIMID			= a.CLAIM_ID
									where a.sourcedatakey = @sourcedatekey   
									UNION  -- TETDM-2247 - Adding logic for SOS 7000/7001 to exclusion. SDK Mismatches
									SELECT CLAIM_ID, sourcedatakey,  @CURRENTDATE, EXCL_ID from EXT_CLAIM_EXCLUSION_HIST WHERE EXCL_ID in ('7000','7001')  
								END		-- end TETDM-2011
-- TETDM-1882 Turn off exclusion id 44444444 for prof and institutional
									--and EXCL_ID  <> 444444444     
-- TETDM-1882 END     
								SET @TOTAL_RECORDS = @TOTAL_RECORDS + @@ROWCOUNT  -- TETDM-1719  
														     
-- TETDM-2011
								ALTER INDEX ALL ON WIPRO.dbo.EXT_CLAIM_EXCLUSION     
								REBUILD;     
     
				--ASSIGN TOTAL RECORDS		     
-- TETDM-1719				SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EXT_CLAIM_EXCLUSION)	     
				  
				---HRP_CLAIM_FILE Update Run Controls     
						     
						UPDATE EXT_SYS_RUNLOG     
						SET END_DT = GETDATE()	     
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())     
							,TOTAL_RECORDS = @TOTAL_RECORDS     
							,ENTRYDT = GETDATE()     
						WHERE PROC_NAME = 'EXSP_WIPRO_CLAIM_EXCLUSION'
								AND END_DT IS NULL

SET NOCOUNT OFF;