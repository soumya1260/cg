﻿
CREATE PROCEDURE [dbo].[EXSP_WIPRO_BAD_FILE_v2]
(@FILEID VARCHAR(50), @EXCLUDE_ID VARCHAR(20) )
AS
/***************************************************************************************************
** CREATE DATE: 12/2014
**
** AUTHOR: LOYAL RICKS - LOYAL RICKS
**
** DESCRIPTION: Procedure will be used to identify bad files, archive all associate claimid and
**				reset associated claims making them available for additional outbound files.
**				Restting associated claims will be done by:
**				1 - OUTB_FILE_HIST Updates 
**					Set  REJ_FILE_ID = 'BAD FILE', REJ_FILE_DT = @ARCHIVE_DT, LAST_UPD_DT = @ARCHIVE_DT,
**						FILEDESC = RTRIM(FILEDESC) +'-' + 'WIPRO BAD FILE'
**				2 - OUTB_CLAIM_STATUS_ARCHIVE - Append all associated claims from OUTB_CLAIM_STATUS table
**				3 - deleting all records for the specified fileid from the OUTB_CLAIM_STATUS table.
**
**
**
**
**
Modification History
====================
Date			Who				Description
07/21/2017   John Bartholomay   Add logic to exclude an Claim ID from being Reset

09/25/2018	Scott Waller		Clone this from the original and then enhance it to either
									- reset a file completely 
									- reset a file but exclude claimid's that are in the
									  WIPRO_FileReset_ClaimsToExclude table
11/06/2024	Sasi T	RETM-783	-- reset claim status so it can be resubmittable 

--------------------------------------------------------------------------------------------------------------------------------------------------------------
*******************************************************************************************************************************************************************/
--DECLARE VARIABLES

	DECLARE	@TOTAL_RECORDS INT,
			@ARCHIVE_DT DATETIME

	SET @ARCHIVE_DT = GETDATE();
	SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_CLAIM_STATUS WHERE FILEID = @FILEID)

--HRP_CLAIM_FILE Run controls
	INSERT INTO EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT
			)
	VALUES('EXSP_WIPRO_BAD_FILE_v2' + ' - '+ RTRIM(@FILEID)
			,'1'
			,GETDATE()
			,NULL
			,NULL
			,0
			,GETDATE()
			)
					
--begin standard archiving. Save all existing records to _ARCHIVE tables. 
	if OBJECT_ID ('tempdb..#OUTB_CLAIM_STATUS_ARCHIVE') <> 0
		drop table #OUTB_CLAIM_STATUS_ARCHIVE
				
CREATE TABLE [#OUTB_CLAIM_STATUS_ARCHIVE](
	[CLAIM_ID] [varchar](20) NULL,
	[CLAIM_TYPE] [varchar](1) NULL,
	[FILEID] [char](50) NULL,
	[CLM_IND] [varchar](20) NULL,
	[SOURCEDATAKEY] [int] NULL,
	[MEMBER_ID] [char](80) NULL,
	[HICN_NUM] [char](20) NULL,
	[BILL_PROV_GRP_ID] [char](40) NULL,
	[BILL_PROV_ID] [char](40) NULL,
	[REF_PROV_ID] [char](50) NULL,
	[REF_PCP_PROV_ID] [char](50) NULL,
	[ATTN_PROV_ID] [char](50) NULL,
	[CLMSTAT_STATUS] [varchar](1) NULL,
	[STAT_CLM_TYPE] [varchar](1) NULL,
	[WIPRO_CLAIM_ID] [varchar](20) NULL,
	[CMS_ICN] [varchar](20) NULL,
	[STAT_FATAL_ERR_FLAG] [varchar](1) NULL,
	[STAT_REJ_REA_ID] [varchar](8) NULL,
	[REJ_REA_MSG] [varchar](200) NULL,
	[LINE_SEQ_NO] [varchar](4) NULL,
	[OTH_PAYER_ID] [varchar](50) NULL,
	[FIELD_TYPE] [varchar](100) NULL,
	[SUBTYPE] [varchar](50) NULL,
	[FIELD_SUB_QUAL] [varchar](15) NULL,
	[FIELD_POS] [varchar](50) NULL,
	[FIELD_ERR] [varchar](100) NULL,
	[VAL_ERR] [varchar](1024) NULL,
	[FILEDATE] [varchar](14) NULL,
	[LAST_UPD_DATE] [datetime] NULL,
	[DOS_MONTH] [varchar](6) NULL,
	[SecondaryPlanClaimNumber] [varchar](20) NULL,
	[EffectiveEncounterFlag] [char](1) NULL,
	[OriginalPlanClaimID] [varchar](20) NULL
) 

--Archive existing table 
--Append associated bad file claims to archive table 
		insert into OUTB_CLAIM_STATUS_ARCHIVE
		select *,@ARCHIVE_DT
		from OUTB_CLAIM_STATUS
		where FILEID = @FILEID 	
		
--- Delete associated bad file claims from OUTB_CLAIM_STATUS		
		IF @EXCLUDE_ID = 'ALL'
			BEGIN

				UPDATE p							-- RETM-783
				SET medicaresubmissiondate = NULL
				FROM dbo.eds_claims_processing p
					JOIN dbo.OUTB_CLAIM_STATUS o
						ON p.CLAIMID = o.CLAIM_ID
							AND  FILEID = @FILEID

				DELETE 
				FROM OUTB_CLAIM_STATUS
				WHERE FILEID = @FILEID  
				
				SET @TOTAL_RECORDS = @@ROWCOUNT  
			END

---- Exclude Claim from Status being Reset
		IF @EXCLUDE_ID <> 'ALL'
			BEGIN

			UPDATE p								-- RETM-783
				SET medicaresubmissiondate = NULL
				FROM dbo.eds_claims_processing p
					JOIN dbo.OUTB_CLAIM_STATUS o
						ON p.CLAIMID = o.CLAIM_ID
							AND  FILEID = @FILEID
							AND CLAIM_ID NOT IN (SELECT	CLAIM_ID
										FROM		WIPRO_FileReset_ClaimsToExclude
										WHERE		FILEID = @FILEID )
				DELETE
				FROM dbo.OUTB_CLAIM_STATUS
				WHERE FILEID = @FILEID
					AND CLAIM_ID NOT IN (SELECT	CLAIM_ID
										FROM		WIPRO_FileReset_ClaimsToExclude
										WHERE		FILEID = @FILEID )

				SET @TOTAL_RECORDS = @@ROWCOUNT  
			END
							
--Set file to bad file status in OUTB_FILE_HIST 
		UPDATE OUTB_FILE_HIST 
		SET REJ_FILE_ID = 'BAD FILE',
			REJ_REA_MSG ='BAD FILE',
			REJ_REA_CD='BAD FILE',
			LAST_UPD_DT = @ARCHIVE_DT--,
			--FILEDESC = RTRIM(FILEDESC) +'-' + 'WIPRO BAD FILE' 
		WHERE FILEID = @FILEID            
							
		UPDATE EXT_SYS_RUNLOG
		SET END_DT = GETDATE()	
			,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
			,TOTAL_RECORDS = @TOTAL_RECORDS
			,ENTRYDT = GETDATE()
		WHERE PROC_NAME = 'EXSP_WIPRO_BAD_FILE_v2' + ' - '+ RTRIM(@FILEID)
						and END_DT is null
							