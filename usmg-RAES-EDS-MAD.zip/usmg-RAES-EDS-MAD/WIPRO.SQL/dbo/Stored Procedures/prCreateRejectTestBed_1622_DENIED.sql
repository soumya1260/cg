﻿
CREATE PROCEDURE [dbo].[prCreateRejectTestBed_1622_DENIED] (@RejectReason VARCHAR(20),@FILEID VARCHAR(01),@DENIEDFLAG INT)
AS
/* 
Instructions:  set the reject reason id variable, FILEID

*/



   ---------------------------------------------------------------
   -- DETAIL TEST BED = 1622
   ---------------------------------------------------------------
   DELETE FROM [dbo].[OUTB_WIPRO_TEST_BED] WHERE TESTID = '1622'


 
  -------------------------------------------
  --TEST BED
  -------------------------------------------
  INSERT INTO [dbo].[OUTB_WIPRO_TEST_BED]
           ([TESTID]
           ,[TEST_DESC]
           ,[CLAIMID]
           ,[SOURCEDATAKEY]
           ,[CLAIM_TYPE] 
	   ,[typecode]
	   ,[ORIG_BIDW_EXTRACT_DT]
	   ,[LAST_BIDW_EXTRACT_DT]
           )
   SELECT DISTINCT
      '1622' ,
      'DENIED CLAIMS RESUBMISSION' ,
      CLAIM_ID ,
      '50'   ,
      'I'    ,
      'MAO'  ,
      GETDATE() AS ORIG_BIDW_EXTRACT_DT,
      GETDATE() AS LAST_BIDW_EXTRACT_DT
  FROM
      DENIED_CLAIMS_JIRA_1622 D,
      EDPS_Data.dbo.CLAIMDIM C
  WHERE D.CLAIM_ID = C.CLAIMID
    AND FILEID = @FILEID
    AND C.DENIEDFLAG = @DENIEDFLAG

	  


IF @@ERROR <> 0 SET NOEXEC ON
