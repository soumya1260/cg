﻿

CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_CONDITIONCODE]

AS
/***************************************************************************************************
** CREATE DATE: 09/2013
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM CONDITION
**				CODE INFORMATION USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.2. 
**				THE SOURCE TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES.  
**              
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
11/27/13		Loyal Ricks		Revise to include MDQO standards	
11/14/17        John Bartholomay TETDM-1587 Correct Conditional table to look in correct env						 
*****************************************************************************************************/			
DECLARE

@TOTAL_RECORDS INT

	--HRP_CLAIM_FILE Run controls
	INSERT INTO EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT
			)
			VALUES('pr_BUILD_INST_CONDITIONCODE'
					,'9'
					,GETDATE()
					,null
					,' '
					,0
					,GETDATE()
					)
			-----C_OCC CURSOR
			----occurance code updates 
				IF OBJECT_ID('TEMPDB..#tmp_cond_cd') <> 0
					DROP TABLE #tmp_cond_cd
					
					CREATE TABLE #tmp_cond_cd
					( claimconditionkey int
						,claimid varchar(20)
						,conditioncode char(5)
						,cond_seq int
					)
					
					begin transaction 
					insert into #tmp_cond_cd
			select distinct claimconditionkey
							,ClaimID
							,conditioncode
							, ROW_NUMBER() OVER ( PARTITION BY ClaimID ORDER BY claimconditionkey,CLAIMID) 
			
			from EDPS_Data.dbo.ClaimConditionDim CC --J 1587 AB corrected table reference
			join OUTB_INST_HEADER CI
			ON CC.ClaimID = CI.CLAIM_ID
			AND CC.SourceDataKey = CI.SOURCEDATAKEY
			where Deleted = 0
			order by claimconditionkey
							,ClaimID
							,conditioncode
			commit
			BEGIN TRANSACTION 
				UPDATE OUTB_INST_HEADER
				SET CONDITION1 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 1
				IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION2 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 2
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION3 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 3
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION4 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 4
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION5 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 5
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION6 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 6
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION7 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 7
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION8 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 8
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION9 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 9
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION10 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 10
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION11 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 11
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
			
			BEGIN TRANSACTION 	
				UPDATE OUTB_INST_HEADER
				SET CONDITION12 = conditioncode
				FROM OUTB_INST_HEADER CI
				JOIN #tmp_cond_cd T
				ON CI.CLAIM_ID = T.claimid
				WHERE cond_seq = 12
					IF @@ERROR <> 0
					BEGIN 
						ROLLBACK
					END
			COMMIT
				
				--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #tmp_cond_cd)
		----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_INST_CONDITIONCODE'
								AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
						
						
						
						
						
