﻿

CREATE PROCEDURE [dbo].[EXSP_WIPRO_MA0_002_ARCHIVE]
AS

/***************************************************************************************************

** CREATE DATE: 03/2014

**

** AUTHOR: LOYAL RICKS - Loyal Ricks

**

** DESCRIPTION: Procedure will archive inbound MAO002 data from "MAO002 Daily Tables" to 

**				apropriate "MAO002 Non Daily" tables. 

**				Archive process designed to execute before daily execution of MAO002 job.

**				Archiving daily before process will allow business group access to daily

**				update data for auditing and validation.

**				Daily MAO002 tables will be truncated after archiving.

**				

**

Modification History

====================

Date			Who				Description

-----------------------------------------------------------------------------------------------------

03/27/2015		Loyal Ricks		WIPRO MAO002 - TETDM-53 - Revised procedure append to EXT_SYS_RUNLOG

								replacing Verisk label with WIPRO label.

04/08/2015		Loyal Ricks		TETDM-73 MAO-002 Version 1.1.0 Updates -MAO_002_DETAIL/MAO_002_DETAIL_DAILY

08/03/2017		Subhash Acharya TETDM-1526

05/31/2019		Subhash Acharya TETDM-2056 LoadDate

09/10/2019      Subhash Acharya TETDM-2117 updated update on Patient_control_no and Reserve_2

03/06/2022		Subhash Acharya RETM-43/44	

05/06/2022		Subhash Acharya RETM-41	

08/08/2022      Subhash Acharya RETM-109

*****************************************************************************************************/

--DECLARE VARIABLES

--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND

DECLARE @TOTAL_RECORDS INT;





--HRP_CLAIM_FILE Run controls



INSERT INTO EXT_SYS_RUNLOG
(
    PROC_NAME,
    STEP,
    START_DT,
    END_DT,
    RUN_MINUTES,
    TOTAL_RECORDS,
    ENTRYDT
)
VALUES
('EXSP_WIPRO_MA0_002_ARCHIVE', '1', GETDATE(), NULL, NULL, 0, GETDATE());





--Archive MAO_002_FILESTATUS



INSERT INTO [dbo].[MAO_002_FileStatus]
(
    [InboundFileName],
    [FileID],
    [RecordType],
    [ClaimsReceived],
    [ClaimsAccepted],
    [ClaimsRejected],
    [CMSTransactionDate]
)
SELECT [InboundFileName],
       [FileID],
       [RecordType],
       [ClaimsReceived],
       [ClaimsAccepted],
       [ClaimsRejected],
       [CMSTransactionDate]
FROM MAO_002_FileStatus_Daily;







--Archive MAO_002_HEADER



INSERT INTO [dbo].[MAO_002_Header]
(
    [InboundFileName],
    [RecordType],
    [WIPROHeaderVersion],
    [FileCategory],
    [FileCategoryTrailerVersion],
    [FileStandardBody],
    [FileType],
    [FileVersion],
    [FileSubType],
    [FileID],
    [FileRevision],
    [FileCreateDate],
    [ProductionIndicator],
    [ClientID],
    [VendorID],
    [SystemSource],
    [Reserved1],
    [Reserved2],
    [Reserved3],
    [Reserved4],
    [Reserved5],
    [Reserved6]
)
SELECT [InboundFileName],
       [RecordType],
       [WIPROHeaderVersion],
       [FileCategory],
       [FileCategoryTrailerVersion],
       [FileStandardBody],
       [FileType],
       [FileVersion],
       [FileSubType],
       [FileID],
       [FileRevision],
       [FileCreateDate],
       [ProductionIndicator],
       [ClientID],
       [VendorID],
       [SystemSource],
       [Reserved1],
       [Reserved2],
       [Reserved3],
       [Reserved4],
       [Reserved5],
       [Reserved6]
FROM MAO_002_Header_Daily;





---Archive MAO_002_DAILY





INSERT INTO dbo.MAO_002_Detail
(
    InboundFileName,
    FileID,
    RecordType,
    ClaimType,
    PaperClaimFlag,
    DMEFlag,
    PlanClaimNumber,
    WIPRO_UNQ_ID,
    WIPRO_FILE_ICN,
    CMSICN,
    Patient_control_no,
    RESERVED2,
    OriginalPlanClaimID,
    HICN,
    ServiceLineSequenceNumber,
    ServiceStartDate,
    ServiceEndDate,
    RejectReasonID,
    RejectReasonMessage,
    SubmissionType,
	PRELIMRaFlag,
	PRELIMReasonCode,
	Billing_Prov_NPI

)
SELECT [InboundFileName],
       [FileID],
       [RecordType],
       [ClaimType],
       [PaperClaimFlag],
       [DMEFlag],
       [PlanClaimNumber],
       [WIPRO_UNQ_ID],
       [WIPRO_FILE_ICN],
       [CMSICN],
       Patient_control_no,
       [RESERVED2],
       [OriginalPlanClaimID],
       [HICN],
       [ServiceLineSequenceNumber],
       [ServiceStartDate],
       [ServiceEndDate],
       [RejectReasonID],
       [RejectReasonMessage],
       [SubmissionType],
	   [PRELIMRaFlag],
	   [PRELIMReasonCode],
	   Billing_Prov_NPI
FROM MAO_002_Detail_Daily;





--Archive MAO_002 Trailer



INSERT INTO [dbo].[MAO_002_Trailer]
(
    [InboundFileName],
    [RecordType],
    [FileID],
    [TotalAcceptedRecords],
    [TotalRejectedRecords]
)
SELECT [InboundFileName],
       [RecordType],
       [FileID],
       [TotalAcceptedRecords],
       [TotalRejectedRecords]
FROM MAO_002_Trailer_Daily;











--ASSIGN @TOTAL_RECORDS - GET RECORD COUNTS For table being archived



SET @TOTAL_RECORDS =
(
    SELECT COUNT(*) FROM MAO_002_Header_Daily
);

SET @TOTAL_RECORDS = @TOTAL_RECORDS +
                     (
                         SELECT COUNT(*) FROM MAO_002_FileStatus_Daily
                     );

SET @TOTAL_RECORDS = @TOTAL_RECORDS +
                     (
                         SELECT COUNT(*) FROM MAO_002_Detail_Daily
                     );

SET @TOTAL_RECORDS = @TOTAL_RECORDS +
                     (
                         SELECT COUNT(*) FROM MAO_002_Trailer_Daily
                     );





--Truncate Daily tables



TRUNCATE TABLE MAO_002_Header_Daily;

TRUNCATE TABLE MAO_002_FileStatus_Daily;

TRUNCATE TABLE MAO_002_Detail_Daily;

TRUNCATE TABLE MAO_002_Trailer_Daily;



----HRP_CLAIM_FILE Update Run Controls



UPDATE EXT_SYS_RUNLOG
SET END_DT = GETDATE(),
    RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()),
    TOTAL_RECORDS = @TOTAL_RECORDS,
    ENTRYDT = GETDATE()
WHERE PROC_NAME = 'EXSP_WIPRO_MA0_002_ARCHIVE'
      AND END_DT IS NULL;
												
						
						


