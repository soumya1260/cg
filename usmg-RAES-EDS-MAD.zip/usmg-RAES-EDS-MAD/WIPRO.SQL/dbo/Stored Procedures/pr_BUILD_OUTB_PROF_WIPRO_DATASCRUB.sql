﻿
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_PROF_WIPRO_DATASCRUB]

AS
/******************************************************************************************************************
** CREATE DATE: 09/10/2014
**
** AUTHOR: LOYAL RICKS 
**
** DESCRIPTION: PROCEDURE WILL Remove non required WIPRO data elements from outbound file.
**             Scurb being performed in separate sp due to fk and other DML that is required  
**             for processing outbound file that may be impacted by removing these field in 
**				earlier steps of the process.
Modification History
====================
Date			Who				Description
-------------------------------------------------------------------------------------------------------------------
09/25/13		Loyal Ricks		EDS-397 - Update the following provider data elements to blank for all claim provider types:
								Plan Provider Id, UPIN, State License Number, Location Number
02/17/15		Loyal Ricks		Add Scrub for Rendering Prov Org Name - Set value = blank when value = 'NO PROVIDER'
								This value being populated from source. 
02/17/15		Loyal Ricks		Performance and fine tuning - removal of explicit transaction blocks
07/14/15		Loyal Ricks		Add Anesthesia Exclusion Edit - TETDM-262 - Remove Anesthesia claims from outbound file
07/15/15		Loyal Ricks		Add Ambulance Exclusion Edit - TETDM-263 - Remove Ambulance Claims from outbound file 
								using Taxonomy Codes.
07/20/15		Loyal Ricks		Modify Ambulance Exclusion Edit - TETDM-263 - Split Taxonomy Code driven exclusions 
								into individual bucket (ExclusionId 8003).
04/02/16		Loyal Ricks		TETDM-667 Remove edit exclusion logic
04/08/16		Loyal Ricks		TETDM-738 Rendering Provider Org Nmae "NO PROVIDER" scrub
05/10/16		Loyal Ricks		TETDM-796 Remove Refferal No when Ref Prov Info does not exist.
05/11/16		Loyal Ricks		TETDM-758 Remove edit exclusion logic 
07//12/16       John Bartholomay TETDM-1821 Zero QNXT Denied lines
01/10/2019      Henry Faust     TETDM-1893 Not sending the requested amount at the line level
05/21/2019		Scott Waller	TETDM-2063 Improve Performance of sproc 
*******************************************************************************************************************/
	DECLARE	@TOTAL_RECORDS INT,
			@SDK	int = 0		-- TETDM-2063
		
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_BUILD_OUTB_PROF_WIPRO_DATASCRUB'
							,'10'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
		-----
		-- Note 
		------ EDS-397 Claim Provider data element removal

					--Billing Provider Info
					 
						update OUTB_PROF_HEADER
						SET BILL_PROV_GRP_ID = ' ',
							BILL_PROV_ID = ' ',
							BILL_PROV_UPIN = ' ',
							BILL_PROV_LICENSE_NO = ' '
				

					--Rendering Provider Info
					
						update OUTB_PROF_HEADER
						SET RENDERING_PROV_ID = ' ',
							RENDERING_PROV_GRP_ID = ' ' 
						



					--Referring Provider Info
					 
						update OUTB_PROF_HEADER
						SET REF_PROV_ID = ' ',
							REF_PROV_UPIN = ' ',
							REF_PROV_LICENSE_NO = ' '
						

					--Referring Pcp Provider Info
				
						update OUTB_PROF_HEADER
						SET REF_PCP_PROV_ID = ' ',
							REF_PCP_PROV_UPIN = ' ',
							REF_PCP_LICENSE_NO = ' '
			

					--Attneding Provider Info
			 
						update OUTB_PROF_HEADER
						SET ATTN_PROV_ID = ' ',
							ATTN_PROV_UPIN = ' ',
							ATTN_PROV_LICENSE_NO = ' ',
							ATTN_PROV_LOC_NO = ' '
					

					--02/17/15 BIDW data issue fix. 
					UPDATE OUTB_PROF_HEADER
					SET RENDERING_PROV_ORG_NAME = ' '
					WHERE RENDERING_PROV_ORG_NAME = 'NO PROVIDER' 

					--TETDM-262 Anesthia Exclusion Edit 
					--TETDM-758 Remove logic
					--IF OBJECT_ID('TEMPDB..#TMP_EXCLID_8001') <> 0
					--				DROP TABLE #TMP_EXCLID_8001
		
					--					CREATE TABLE #TMP_EXCLID_8001
		
					--					( CLAIMID VARCHAR(20),
					--						SOURCEDATAKEY INT 
					--					)
					--	INSERT INTO #TMP_EXCLID_8001
					--	select DISTINCT CLAIM_ID,SOURCEDATAKEY
					--	from OUTB_PROF_DETAIL
					--	WHERE ANES_FLAG = 'MJ'

					--	--log claim into OUTB_CLAIM_EXCLUSION_HIST for capturing history of claims found as exclusion
					--	INSERT INTO OUTB_CLAIM_EXCLUSION_HIST
					--	select DISTINCT H.CLAIM_ID,H.SOURCEDATAKEY,GETDATE(),8001,CLAIM_TYPE
					--	from OUTB_PROF_DETAIL P
					--	INNER JOIN OUTB_PROF_HEADER H
					--	ON P.CLAIM_ID = H.CLAIM_ID 
					--	WHERE P.ANES_FLAG = 'MJ'

					--	--Append EXT_CLAIM_EXCLUSION_HIST 

					--	Insert into EXT_CLAIM_EXCLUSION_HIST
					--	SELECT O.*
					--	FROM OUTB_CLAIM_EXCLUSION_HIST O
					--	LEFT OUTER JOIN EXT_CLAIM_EXCLUSION_HIST H
					--	ON O.SOURCEDATAKEY = H.SOURCEDATAKEY 
					--	AND O.CLAIM_ID = H.CLAIM_ID 
					--	WHERE H.CLAIM_ID IS NULL

					--	--REMOVE CLAIMS FROM OUTBOUND FILE 
					--	DELETE 
					--	FROM OUTB_PROF_HEADER
					--	WHERE CLAIM_ID IN (SELECT CLAIMID FROM #TMP_EXCLID_8001)

					--	DELETE 
					--	FROM OUTB_PROF_DETAIL
					--	WHERE CLAIM_ID IN (SELECT CLAIMID FROM #TMP_EXCLID_8001)

					--	INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST
					--			select distinct cd.ClaimID,cd.SOURCEDATAKEY,GETDATE(),8001,CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE c.formtypecode END 
					--					from #TMP_EXCLID_8001 T
					--					INNER JOIN  EDPS_Data.dbo.claimdetaildim cd
					--					on T.sourcedatakey = cd.sourcedatakey
					--					and T.claimid = cd.claimid
					--					inner join EDPS_dATA.dbo.claimdim c
					--					on cd.sourcedatakey = c.sourcedatakey
					--					and cd.claimid = c.claimid

						--TETDM-738 Rendering Provider Org Nmae "NO PROVIDER" scrub
						UPDATE OUTB_PROF_HEADER 
						SET RENDERING_PROV_ORG_NAME = ' '
						WHERE RENDERING_PROV_ORG_NAME = 'NO PROVIDER'

					--TETDM-263 Ambulance Exclusion Edit 
					--TETDM-667 Remove edit exclusion logic

							
								---Update Billing Provider Taxonomy Code when Taxonomy 
							
					--			UPDATE OUTB_INST_HEADER
					--			SET BILL_PROV_TAXONOMY_CD = HealthcareProviderTaxonomyCode
					--			FROM OUTB_INST_HEADER P
					--			INNER JOIN EDPS_Data.IDQ.CMSTaxonomy T
					--			ON P.BILL_PROV_GRP_NPI = T.NPI
					--			where len(P.BILL_PROV_TAXONOMY_CD) = 0
					--				AND T.HealthcareProviderTaxonomyCode IN ('343900000X','341600000X','3416A0800X','3416L0300X','3416S0300X')
								
								

					--IF OBJECT_ID('TEMPDB..#TMP_EXCLID_8003') <> 0
					--				DROP TABLE #TMP_EXCLID_8003
		
					--					CREATE TABLE #TMP_EXCLID_8003
		
					--					( CLAIMID VARCHAR(20),
					--						SOURCEDATAKEY INT 
					--					)

					--	--Identify current exclusions
					--	insert into #TMP_EXCLID_8003
					--	select claim_id,sourcedatakey
					--	from OUTB_PROF_header
					--	WHERE BILL_PROV_TAXONOMY_CD IN ('343900000X','341600000X','3416A0800X','3416L0300X','3416S0300X')

					--	--log claim into OUTB_CLAIM_EXCLUSION_HIST for capturing history of claims found as exclusion
					--	INSERT INTO OUTB_CLAIM_EXCLUSION_HIST
					--	select DISTINCT CLAIM_ID,SOURCEDATAKEY,GETDATE(),8003,CLAIM_TYPE
					--	from OUTB_PROF_header
					--	WHERE BILL_PROV_TAXONOMY_CD IN ('343900000X','341600000X','3416A0800X','3416L0300X','3416S0300X')

					--	--Append EXT_CLAIM_EXCLUSION_HIST 

					--	Insert into EXT_CLAIM_EXCLUSION_HIST
					--	SELECT O.*
					--	FROM OUTB_CLAIM_EXCLUSION_HIST O
					--	LEFT OUTER JOIN EXT_CLAIM_EXCLUSION_HIST H
					--	ON O.SOURCEDATAKEY = H.SOURCEDATAKEY 
					--	AND O.CLAIM_ID = H.CLAIM_ID 
					--	WHERE H.CLAIM_ID IS NULL

					--	--REMOVE CLAIMS FROM OUTBOUND FILE 
					--	DELETE 
					--	FROM OUTB_PROF_HEADER
					--	WHERE CLAIM_ID IN (SELECT CLAIMID FROM #TMP_EXCLID_8003)

					--	DELETE 
					--	FROM OUTB_PROF_DETAIL
					--	WHERE CLAIM_ID IN (SELECT CLAIMID FROM #TMP_EXCLID_8003)

					--TETDM-796
					update OUTB_PROF_HEADER 
					SET REFERRAL_NO = ' '
					WHERE LEN(REFERRAL_NO) > 0 
					AND (LEN(REF_PROV_LNAME) = 0 
							OR LEN(REF_PROV_FNAME) = 0)
                  
					---------------------------------------------
					--TETDM-1821 ZERO QNXT DENIED LINES
					--------------------------------------------
					IF OBJECT_ID('TEMPDB..#TEMP_DENIED') <> 0
						DROP TABLE #TEMP_DENIED
	
						create table  #TEMP_DENIED
						(CLAIM_ID varchar(20)
						,CLAIM_LINE_NO int
						,RULEID VARCHAR(15)
						)
					   
--					   INSERT INTO #TEMP_DENIED
--					   SELECT DISTINCT Q.claimid,Q.claimline,Q.ruleid
--                       FROM EDPS_Data.DBO.CLAIMDETAILDIM C, 
--                            EDPS_DATA.DBO.QNXT_claimedit Q,
--	                        OUTB_PROF_DETAIL P
--                       WHERE  Q.claimid = C.CLAIMID
--                         AND  C.CLAIMID = P.CLAIM_ID
--						 AND  Q.claimline = C.CLAIMLINEID
--						 AND  P.CLAIM_LINE_NO = C.CLAIMLINEID
----						 AND  REPLACE(Q.reason,'.','') BETWEEN '800' AND '899'
--						 AND  REPLACE(Q.ruleid,'.','') BETWEEN '800' AND '899'  --TETDM-1893  chage to ruleid
----						 AND  LEN(REPLACE(Q.reason,'.','') ) = 3
--						 AND  LEN(REPLACE(Q.ruleid,'.','') ) = 3
--                         AND C.DetailSourceType = 'B'                            --TETDM-1893  remove comment
/*
-- TETDM-1893 Begin
  					   INSERT INTO #TEMP_DENIED
						SELECT qce.claimid, qce.claimline, qce.ruleid             -- get claim, line and ruleid for lines to zero out
						FROM EDPS_DATA.DBO.QNXT_claimedit qce
						  JOIN
							(SELECT DISTINCT cdd.CLAIMID                           -- 2 part process get claims that any line has a 'B'
							 FROM dbo.OUTB_PROF_DETAIL opd
							 JOIN EDPS_Data.DBO.CLAIMDETAILDIM cdd ON opd.CLAIM_ID = cdd.CLAIMID
							 WHERE cdd.DetailSourceType = 'B') opd ON qce.claimid = opd.CLAIMID
							   AND  REPLACE(qce.ruleid,'.','') BETWEEN '800' AND '899'
							   AND REPLACE(qce.ruleid,'.','') NOT IN ( '828', '801','802')
	                        --   AND REPLACE(qce.reason,'.','') BETWEEN '800' AND '899'


--TETDM-1893 END
*/

-- TETDM-2063 BEGIN		This block is only necessary if QNXT (SDK = 50).  Only QNXT data in QNXT_claimedit table.
--						Use SDK in jobin to CLAIMDETAILDIM in order to be sure you are using it's index (it is claimid & sdk)
--						Insert all rows from QNXT_claimedit into the temp table, without the REPLACE() in the  WHERE clause logic 
--							as that causes SQL Server to ignore the indexes, and tablescan every time.  That 
--							table has 50+ million rows in it.  Put the REPLACE function on the INSERT into the temp table
--						Next delete data in #TEMP_DENIED that doesn't meet your RULEID logic
--						Add an index to #TEMP_DENIED because you will be updating OUTB_PROF_DETAIL table from it, and 
--							OUTB_PROF_DETAIL does not have any indexes on it.

				SET	@SDK = (SELECT	TOP 1	SOURCEDATAKEY FROM	OUTB_PROF_HEADER)
				IF	(@SDK = 50)
					BEGIN
						IF OBJECT_ID('TEMPDB..#TEMP_CLAIMIDS') <> 0
							DROP TABLE #TEMP_CLAIMIDS
						
						CREATE TABLE  #TEMP_CLAIMIDS
							(CLAIM_ID		varchar(20))

						INSERT	INTO #TEMP_CLAIMIDS
						SELECT	DISTINCT cdd.CLAIMID                           -- 2 part process get claims that any line has a 'B'
						FROM	dbo.OUTB_PROF_DETAIL opd
						JOIN	EDPS_Data.DBO.CLAIMDETAILDIM cdd 
							ON	opd.CLAIM_ID		= cdd.CLAIMID
							AND	opd.SOURCEDATAKEY	= cdd.SOURCEDATAKEY
						WHERE	cdd.DetailSourceType = 'B'

						INSERT	INTO #TEMP_DENIED
						SELECT	qce.claimid, qce.claimline, REPLACE(qce.ruleid,'.','')              -- get claim, line and ruleid for lines to zero out
						FROM	EDPS_DATA.DBO.QNXT_claimedit qce
						JOIN	#TEMP_CLAIMIDS tcids
							ON	tcids.CLAIM_ID		= qce.claimid

						DELETE	#TEMP_DENIED
						WHERE	RULEID	BETWEEN '800' AND '899'
						AND		RULEID	NOT IN	( '828', '801','802')

						CREATE NONCLUSTERED INDEX tIndex ON #TEMP_DENIED 
							(CLAIM_ID ASC)
					END
-- TETDM-2063 END
                      ----------------
					  --ZERO OUT LINES
					  ----------------
					  UPDATE CD
					  SET CD.TOTAL_CHRG_AMT = '0.00'
					  FROM dbo.OUTB_PROF_DETAIL CD,
	                        #TEMP_DENIED IC
	                   WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                     AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO 

					  UPDATE CD 
                       SET CLM_ADJ_AMT111 = '',
                           CLM_ADJ_REASON111 = '',
                           CLM_ADJ_QTY111 = '',
		                   CLM_ADJ_GRP111 = ''
                       FROM dbo.OUTB_PROF_DETAIL CD,
	                        #TEMP_DENIED IC
	                   WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                     AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO 
	
	                   UPDATE CD 
                       SET CLM_ADJ_AMT112 = '',
	                       CLM_ADJ_REASON112 = '',
		                   CLM_ADJ_QTY112 = ''
	                  FROM dbo.OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                  WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                   AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO

	                  UPDATE CD 
		              SET CLM_ADJ_AMT113 = '',
		                  CLM_ADJ_REASON113 = '',
			              CLM_ADJ_QTY113 = ''
	                  FROM dbo.OUTB_PROF_DETAIL CD,
		                   #TEMP_DENIED IC
	                  WHERE CD.CLAIM_ID = IC.CLAIM_ID
		                AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO

	                  UPDATE CD 
                      SET CLM_ADJ_AMT114 = '',
		                  CLM_ADJ_REASON114 = '',
		                  CLM_ADJ_QTY114  = ''
	                  FROM dbo.OUTB_PROF_DETAIL CD,
		                   #TEMP_DENIED IC 
	                  WHERE CD.CLAIM_ID = IC.CLAIM_ID
		                AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
 	 
	                  UPDATE CD 
	                  SET CLM_ADJ_AMT115 = '', 
	                      CLM_ADJ_REASON115 = '',
		                  CLM_ADJ_QTY115 = ''
	                 FROM dbo.OUTB_PROF_DETAIL CD,
	                      #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                   AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
	 
                     UPDATE CD 
	                 SET CLM_ADJ_AMT116 = '',
	                     CLM_ADJ_REASON116 = '',
		                 CLM_ADJ_QTY116 = ''
	                 FROM OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                       AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
	  
	                 UPDATE CD 
                     SET  CLM_ADJ_AMT121 = '',
		                  CLM_ADJ_REASON121 = '',
			              CLM_ADJ_QTY121 = '',
			              CLM_ADJ_GRP12 = ''
		             FROM OUTB_PROF_DETAIL CD,
		                   #TEMP_DENIED IC
		             WHERE CD.CLAIM_ID = IC.CLAIM_ID
		                   AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
   
	                 UPDATE CD 
		             SET CLM_ADJ_AMT122 = '',
		                 CLM_ADJ_REASON122 = '',
			             CLM_ADJ_QTY122 = ''
		             FROM OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                       AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
       
	                 UPDATE CD
		             SET  CLM_ADJ_AMT123 = '',
			              CLM_ADJ_REASON123 = '',
		                  CLM_ADJ_QTY123 = ''
                     FROM OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                   AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
     
	                 UPDATE CD
		             SET  CLM_ADJ_AMT124 = '',
			              CLM_ADJ_REASON124 = '',
			              CLM_ADJ_QTY124 = ''
		             FROM OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                   AND CD.CLAIM_LINE_NO= IC.CLAIM_LINE_NO

		             UPDATE CD
		             SET  CLM_ADJ_AMT125 = '',
			              CLM_ADJ_REASON125 = '',
			              CLM_ADJ_QTY125 = ''
                     FROM OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                   AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
        
		             UPDATE CD
		             SET  CLM_ADJ_AMT126 = '',
		                  CLM_ADJ_REASON126 = '',
			              CLM_ADJ_QTY126 = ''
                     FROM OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                   AND CD.CLAIM_LINE_NO= IC.CLAIM_LINE_NO
        
		             UPDATE CD
		             SET CLM_ADJ_AMT131 = '',
		                 CLM_ADJ_REASON131 = '',
			             CLM_ADJ_QTY131 = '',
			             CLM_ADJ_GRP13 = ''
                     FROM OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                   AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
        
		             UPDATE CD
		             SET  CLM_ADJ_AMT132  = '',
		                  CLM_ADJ_REASON132 = '',
			              CLM_ADJ_QTY132 = ''
                     FROM OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                   AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
        
		             UPDATE CD
		             SET  CLM_ADJ_AMT133 = '',
		                  CLM_ADJ_REASON133 = '',
			              CLM_ADJ_QTY133 = ''
                     FROM OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                   AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
         
		             UPDATE CD
		             SET  CLM_ADJ_AMT134 = '',
			              CLM_ADJ_REASON134 = '',
				          CLM_ADJ_QTY134 = ''
                     FROM OUTB_PROF_DETAIL CD,
	                       #TEMP_DENIED IC
	                 WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                   AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO

		            UPDATE CD
		            SET  CLM_ADJ_AMT135 = '',
			             CLM_ADJ_REASON135 = '',
			             CLM_ADJ_QTY135 = ''
                    FROM OUTB_PROF_DETAIL CD,
	                     #TEMP_DENIED IC
	                WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                  AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO

		           UPDATE CD 
		           SET  CLM_ADJ_AMT136 = '',
			            CLM_ADJ_REASON136 = '',
			            CLM_ADJ_QTY136 = ''
                   FROM OUTB_PROF_DETAIL CD,
	                    #TEMP_DENIED IC
	               WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                 AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
         
		           UPDATE CD
		           SET  CLM_ADJ_AMT141 = '',
			            CLM_ADJ_REASON141 = '',
			            CLM_ADJ_QTY141 = '',
			            CLM_ADJ_GRP14 = ''
                  FROM OUTB_PROF_DETAIL CD,
	                   #TEMP_DENIED IC
	              WHERE CD.CLAIM_ID = IC.CLAIM_ID
	                AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
         
		          UPDATE CD
		          SET  CLM_ADJ_AMT142 = '',
			           CLM_ADJ_REASON142 = '',
				       CLM_ADJ_QTY142 = ''
                 FROM OUTB_PROF_DETAIL CD,
	                  #TEMP_DENIED IC
	             WHERE CD.CLAIM_ID = IC.CLAIM_ID
	               AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO 
         
		        UPDATE CD
		        SET  CLM_ADJ_AMT143 = '',
			         CLM_ADJ_REASON143 = '',
			         CLM_ADJ_QTY143 = ''
               FROM OUTB_PROF_DETAIL CD,
	                #TEMP_DENIED IC
	           WHERE CD.CLAIM_ID = IC.CLAIM_ID
	             AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO

		       UPDATE CD
		       SET  CLM_ADJ_AMT144 = '',
		            CLM_ADJ_REASON144 = '',
			        CLM_ADJ_QTY144 = ''
               FROM OUTB_PROF_DETAIL CD,
	                #TEMP_DENIED IC
	           WHERE CD.CLAIM_ID = IC.CLAIM_ID
	            AND CD.CLAIM_LINE_NO= IC.CLAIM_LINE_NO
         
		       UPDATE CD
		       SET  CLM_ADJ_AMT145 = '',
			        CLM_ADJ_REASON145 = '',
			        CLM_ADJ_QTY145 = '' 
               FROM OUTB_PROF_DETAIL CD,
	                #TEMP_DENIED IC
	           WHERE CD.CLAIM_ID = IC.CLAIM_ID
	             AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
         
		      UPDATE CD
		      SET  CLM_ADJ_AMT146 = '',
			       CLM_ADJ_REASON146 = '',
			       CLM_ADJ_QTY146 = ''
              FROM OUTB_PROF_DETAIL CD,
	               #TEMP_DENIED IC
	          WHERE CD.CLAIM_ID = IC.CLAIM_ID
	            AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
          
		      UPDATE CD
			   SET CLM_ADJ_AMT151 = '',
			       CLM_ADJ_REASON151 = '',
				   CLM_ADJ_QTY151 = '',
				   CLM_ADJ_GRP15 = ''
              FROM OUTB_PROF_DETAIL CD,
	               #TEMP_DENIED IC
	          WHERE CD.CLAIM_ID = IC.CLAIM_ID
	            AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
           
		      UPDATE CD
			  SET CLM_ADJ_AMT152 = '',
			      CLM_ADJ_REASON152 = '',
				  CLM_ADJ_QTY152 = ''
              FROM OUTB_PROF_DETAIL CD,
	               #TEMP_DENIED IC
	          WHERE CD.CLAIM_ID = IC.CLAIM_ID
	            AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
            			
			  UPDATE CD
			  SET CLM_ADJ_AMT153 = '',
				  CLM_ADJ_REASON153 = '',
				  CLM_ADJ_QTY153 = ''
              FROM OUTB_PROF_DETAIL CD,
	               #TEMP_DENIED IC
	          WHERE CD.CLAIM_ID = IC.CLAIM_ID
	            AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
            
			  UPDATE CD
			  SET CLM_ADJ_AMT154 = '',
				  CLM_ADJ_REASON154 = '',
				  CLM_ADJ_QTY154 = ''
              FROM OUTB_PROF_DETAIL CD,
	               #TEMP_DENIED IC
	          WHERE CD.CLAIM_ID = IC.CLAIM_ID
	            AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO
           
		     UPDATE CD
			 SET CLM_ADJ_AMT155 = '',
			     CLM_ADJ_REASON155 = '',
				 CLM_ADJ_QTY155 = ''
             FROM OUTB_PROF_DETAIL CD,
	              #TEMP_DENIED IC
	         WHERE CD.CLAIM_ID = IC.CLAIM_ID
	           AND CD.CLAIM_LINE_NO= IC.CLAIM_LINE_NO

            
			  UPDATE CD
			  SET CLM_ADJ_AMT156 = '',
				  CLM_ADJ_REASON156 = '',
			      CLM_ADJ_QTY156 = ''
               FROM OUTB_PROF_DETAIL CD,
	                #TEMP_DENIED IC
	           WHERE CD.CLAIM_ID = IC.CLAIM_ID
	             AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO

              UPDATE CD
			  SET CLM_ADJ_AMT156 = '',
				  CLM_ADJ_REASON156 = '',
			      CLM_ADJ_QTY156 = ''
               FROM OUTB_PROF_DETAIL CD,
	                #TEMP_DENIED IC
	           WHERE CD.CLAIM_ID = IC.CLAIM_ID
	             AND CD.CLAIM_LINE_NO = IC.CLAIM_LINE_NO


			--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_HEADER)
			
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_OUTB_PROF_WIPRO_DATASCRUB'
										and END_DT is null
							
