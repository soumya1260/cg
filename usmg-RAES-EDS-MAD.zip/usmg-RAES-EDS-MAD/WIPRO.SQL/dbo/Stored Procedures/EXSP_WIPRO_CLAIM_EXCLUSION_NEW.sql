﻿

CREATE PROCEDURE [dbo].[EXSP_WIPRO_CLAIM_EXCLUSION_NEW]
(@sourcedatekey int
	, @exclusionmode CHAR(1) = 'R' --Migration Exclusions
	)
AS

/***************************************************************************************************
** CREATE DATE: 10/26/2012
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: Procedure will identify all HS Claims eligible for HRP Claim Encounter File Exclusion.
**               HRP Claim File Exclusion Logic:
**				 #1 - HRP CMS ICN Claims - Exclude all claims from current outbound claim file(s) that 
**				 have a current HRP claim status of Accepted AND a CMS ICN number. 
**				 #2 - HRP Accpeted Claims - Exclude all claims from current claim file(s) that have a 
**				 current HRP claim status of Accepted. 
**				 #3 - HRP Rejected Claim - Exclude all claims from current claim file(s) that have a 
**				 current status of Rejected AND the last EDPS update is within last 31 days. 
**				 #4 - HRP Recently submitted Claim - Exclude all claims from current claim file(s) that do not 
**				 have a current status AND the last EDPS update is within last 14 days. 
**
Modification History
====================
Date			Who				Description

-----------------------------------------------------------------------------------------------------
01/03/13		LOYAL RICKS		ADD HPLAN EXCLUSION LOGIC
01/05/2013		LOYAL RICKS		ADD PARAMERTER VALUES @EXCL_DAYS,@REJ_EXCL_DAYS	
01/17/13		LOYAL RICKS		REMOVE USE OF ##EDPSPROD_CLMSTAT, REPLACE WITH VW_CLAIM_STATUS
02/18/13		LOYAL RICKS		USE #TMP INSTEAD OF ##TMP
03/06/2012		LOYAL RICKS		HPLAN EXCLUDE REVISION WHERE ACTIVE_FLAG = 'Y', ONLY ACTIVE ROWS
03/06/2012		LOYAL RICKS		ADD NEW CLAIM EXCLUSION LOGIC - EXCLUDE FROM OUTBOUND SUBMISSION 
								ALL CLAIMS THAT HAVE A CLAIMDETAILDIM LILNE WITH AT LEAST 1 BEGINSERVICEDATEKEY
								ON OR AFTER THE FIRST DAY OF THE PREVIOUS MONTH FOR THE DAY OF EXECUTION.
								EXAMPLE: Process is executed on 3/6/13, all claims with at least 1 service line
								beginservicedatekey is >= 2/1/13 (Greater than or equal to) 
03/22/2012		LOYAL RICKS		EZCap Intrest claims exlcusion added to invalid procedure code list
								EZCap invalid diagnosis code added	
03/26/2013						Remove 2013 DOS Exclusions		
04/07/13						Add Provider exclusion logic
04/23/2013						Add exclusion for claims that are not in claimdiagnosisdim, these claims
								are missing pointer information. Additional logic may be needed to derrive
								pointers.
05/13/2012		Loyal Ricks		Alter EXT_HRP_CLAIM_EXCLUSION - Add EXCL_ID on insert for every exclusion category
								Revise process to support required maintenance to support EXT_HRP_CLAIM_EXCLUSION_HIST 
								table which will be used via RRS reporting.	
05/14/2013		Loyal Ricks		Invalid PlaceofServiceCode (claimdetaildim)	
06/25/2013		Loyal Ricks		Revise Exclusion Code 9001, 360 & Exams to include wild card seach 	
07/02/2013		Loyal Ricks		Append Exclusion Code History (9000 Series) from EXT_HRP_CLAIM_EXCLUSION_HIST - SHOULD 
								decrease processing by using existing data on every execution.	
03/18/2014		Loyal Ricks		Reassign default value from R (Regular Exclusions) to M (Migration exclusions)
								Add If block when @Exclusionmode <> 'M' to run process in "regular mode"
-----------------------------------------------------------------------------------------------------------------------
	WIPRO Implementation
	
08/05/2014		Loyal Ricks		WIPRO required revisions		
09/23/2014		Loyal Ricks		Add Adjustments to exclusion. Need to ensure these are not submitted	
11/12/2014		Loyal Ricks		10W40/Missing WIPRO Clmstat revision - temp rivisions to support QA due to missing 
								clmstat
								Add logic to exclude any claim that has been submitted in a QA file
11/13/2014		Loyal Ricks		Increase #migrate_fileid.fileid length from 20 to 50
12/05/14		Loyal Ricks		Performance & fine tuning
*****************************************************************************************************/	
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
		
			@TOTAL_RECORDS INT
			,@EXCL_DAYS		INT
			,@REJ_EXCL_DAYS	INT
			,@FILEID VARCHAR(20)
			,@BATCH_RUN_DT DATETIME
								
							--ASSIGN @@BATCH_RUN_DT TO EXECUTION DATETIME

								SET @BATCH_RUN_DT = (GETDATE())
			
			
			--HRP_CLAIM_FILE Run controls
		
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('EXSP_CLAIM_EXCLUSION'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					
			
		--ASSIGN VARIABLES 
		--GET VALUES FROM EXT_SYS_CLM_JOBCNTRL
			
		
				SET @EXCL_DAYS = (SELECT CNTRL_VAL FROM EXT_SYS_CLM_JOBCNTRL
												WHERE CNTRL_DESC = 'EXCLUSION DAYS'
													and CNTRL_STATUS = 'A'
													AND SOURCEDATAKEY = @sourcedatekey);
				SET @REJ_EXCL_DAYS  = (SELECT CNTRL_VAL FROM EXT_SYS_CLM_JOBCNTRL 
												WHERE CNTRL_DESC = 'REJECT EXCLUSION DAYS'
													and CNTRL_STATUS = 'A'
													AND SOURCEDATAKEY = @sourcedatekey);
				--GET beginning fileid for current cycle
				SET @FILEID = (SELECT RTRIM(CNTRL_TXT) FROM EXT_SYS_CLM_JOBCNTRL
												WHERE SOURCEDATAKEY = '999'
														AND CNTRL_STATUS = 'A');
								
								--IF OBJECT_ID('TEMPDB..EXT_CLAIM_EXCLUSION') <> 0
								--DROP TABLE EXT_CLAIM_EXCLUSION
								
								--CREATE TABLE EXT_CLAIM_EXCLUSION
								--(CLAIM_ID VARCHAR(20)
								--	,SOURCDATAKEY INT
								--	,BATCH_RUN_DT datetime
								--	,EXCL_ID int
								--	,FILEID VARCHAR(50)
									
								--)
									if @exclusionmode <> 'M' --Migration Exclusions
								
								begin

										--Exclusion #1 - CLAIMS WITH CMS ICN NUMBERS
										 
										INSERT INTO EXT_CLAIM_EXCLUSION
										select DISTINCT CLAIM_ID,SOURCEDATAKEY,@BATCH_RUN_DT,1
										from OUTB_CLAIM_STATUS
										where len(CMS_ICN) > 0
												and CLMSTAT_STATUS = 'A'
												and SOURCEDATAKEY = @sourcedatekey
										----ORDER BY SOURCEDATAKEY,CLAIM_ID
											
																
										--Exclusion #2 -  HRP Accpeted Claims

										 
										INSERT INTO EXT_CLAIM_EXCLUSION
										select DISTINCT CS.CLAIM_ID,CS.SOURCEDATAKEY,@BATCH_RUN_DT,2
										from VW_CLAIM_STATUS EC
												,OUTB_CLAIM_STATUS CS
										where EC.CLAIM_ID = CS.CLAIM_ID
											AND EC.FILEID = CS.FILEID 
											AND CS.CLMSTAT_STATUS = 'A'
											and CS.SOURCEDATAKEY = @sourcedatekey
										----ORDER BY CLAIM_ID
											
										
										
										--Exclusion #3 -  HRP Rejected Claims
										--Exclude all rejects that have been reported in the last @REJ_EXCL_DAYS

										 
										INSERT INTO EXT_CLAIM_EXCLUSION
										select DISTINCT CS.CLAIM_ID,CS.SOURCEDATAKEY,@BATCH_RUN_DT ,3
										FROM VW_CLAIM_STATUS EC
												,OUTB_CLAIM_STATUS CS
										where EC.CLAIM_ID = CS.CLAIM_ID
											AND EC.FILEID = CS.FILEID 
											AND CS.CLMSTAT_STATUS = 'R'
											and CS.SOURCEDATAKEY = @sourcedatekey
											AND  DATEDIFF(D,CS.LAST_UPD_DATE,@BATCH_RUN_DT) <  @REJ_EXCL_DAYS
										----ORDER BY CLAIM_ID
											
										
										--Exclusion #4 -  HRP Recently Submitted Claims

										 
										INSERT INTO EXT_CLAIM_EXCLUSION
										select DISTINCT CS.CLAIM_ID,CS.SOURCEDATAKEY,@BATCH_RUN_DT,4
										FROM VW_CLAIM_STATUS EC
												,OUTB_CLAIM_STATUS CS
										where EC.CLAIM_ID = CS.CLAIM_ID
											AND EC.FILEID = CS.FILEID 
											AND CS.CLMSTAT_STATUS is null
											and CS.SOURCEDATAKEY = @sourcedatekey
											AND  DATEDIFF(D,CS.LAST_UPD_DATE,@BATCH_RUN_DT) < @EXCL_DAYS
										--ORDER BY CLAIM_ID
											
										
										----Exclusion #5 -  Adjusted Claims

										-- 
										--INSERT INTO EXT_CLAIM_EXCLUSION
										--select CLAIMID,SOURCEDATAKEY,@BATCH_RUN_DT AS 'BATCH_RUN_DT',5,' '
										--FROM EDPS_Data.dbo.claimdim
										--where (charindex('R',claimid) > 0
										--		or charindex('A',claimid) > 0)
										--		and sourcedatakey =@sourcedatekey
										----ORDER BY CLAIMID
										--	IF @@ERROR <> 0
										--			BEGIN 
										--					ROLLBACK 
										--			END
										--
										
											
										--exclude all claims submitted from EDPS_PROD
										--A recent copy of EDPS_PROD.OUTB_CLAIM_STATUS is required
										--INSERT INTO EXT_CLAIM_EXCLUSION
										--select claim_id,sourcedatakey,@BATCH_RUN_DT,1
										--from OUTB_CLAIM_STATUS_PROD
										--where SOURCEDATAKEY = @sourcedatekey
										--	and FILEID in (select FILEID from EXT_MAP_HIST_PROD
										--					where CHARINDEX('PROD',HRPHEADER) > 0
										--					OR FILEID IN ('CLAIM20121127151349','CLAIM20121127102607'))
										--group by CLAIM_ID,SOURCEDATAKEY
										----ORDER BY SOURCEDATAKEY,CLAIM_ID
															
										
								end
								
								--Production Migration Exclusions
								--Exclude all claims except Accepted claims from current cycle
								
								if @exclusionmode = 'M' --Migration Exclusions
								
								begin
											--GET ALL CYCLE FILEID FOR SOURCEDATAKEY
											IF OBJECT_ID('TEMPDB..#migrate_fileid') <> 0
												DROP TABLE #migrate_fileid
												
											create table #migrate_fileid
											(fileid VARCHAR(50)
											)
											
											--Get all EDPS_DEV fileid from current cycle
																	
											
											INSERT INTO #migrate_fileid
											SELECT DISTINCT fileid
											FROM OUTB_CLAIM_STATUS
											WHERE SOURCEDATAKEY = @sourcedatekey
												--AND FILEID >= @FILEID
												and SUBSTRING(FILEID,1,8) = 'HSCE.DEV'
												
											--Get all Accepted Claims for current cycle
											IF OBJECT_ID('TEMPDB..#migrate_claimid') <> 0
												DROP TABLE #migrate_claimid
												
											create table #migrate_claimid
											(
											claim_id varchar(20)
											)
												 
												insert into #migrate_claimid
												select VS.CLAIM_ID 
													from VW_CLAIM_STATUS VS
													JOIN OUTB_CLAIM_STATUS CS
													ON VS.CLAIM_ID = CS.CLAIM_ID
													AND VS.sourcedatakey = CS.SOURCEDATAKEY
													AND VS.FILEID = CS.FILEID
									-----note
									--11/12/14
									---remove logic due to 10W40 and missing WIPRO clmstat
									---modify process once "normal" processing is resumed
													WHERE /*VS.FILEID >= @FILEID 
														AND CS.CLMSTAT_STATUS = 'A'
														and*/ SUBSTRING(vs.FILEID,1,8) = 'HSCE.DEV'
														AND CS.SOURCEDATAKEY = @sourcedatekey
												IF @@ERROR <> 0
													BEGIN 
															ROLLBACK 
													END
											
												
											--PURGE ALL CURRENT CYCLE FILEID,CLAIMID FROM #EXT_HRP_CLAIM_EXCLUSION
											--This step will delete all claims associated with a migration fileid 
											--from temp exclusion table. This potentially will include multiple
											--submissions (Rejected, Pend, Accepted) of a claim from testing
											
											 
											--DELETE FROM EXT_CLAIM_EXCLUSION
											--WHERE fileid IN (SELECT fileid FROM #migrate_fileid)
											--	IF @@ERROR <> 0
											--		BEGIN 
											--				ROLLBACK 
											--		END
											
											
											--Purge all claims targeted for migration from #EXT_HRP_CLAIM_EXCLUSION
											--This will include all excluded claims
											--Exclusions may have been lifted during cycle but still exist in exclusion
											--table because exclusion table has not been rebuilt. Exclusion rebuild
											--normally happens before or after dev cycle.
											
											-- 
											--delete from #EXT_HRP_CLAIM_EXCLUSION
											--where CLAIM_ID in (select CLAIM_ID from #migrate_claimid)
											--IF @@ERROR <> 0
											--		BEGIN 
											--				ROLLBACK 
											--		END
											--
										
											IF OBJECT_ID('TEMPDB..#all_claims') <> 0
												DROP TABLE #all_claims
												
											create table #all_claims
											(claimid varchar(20)
											,sourcedatakey int
											)
											
											insert into #all_claims
											select distinct claimid,SOURCEDATAKEY
											from CLAIMDIM
											where SOURCEDATAKEY = @sourcedatekey
											--ORDER BY CLAIMID
											
											 
											delete 
											from #all_claims 
											where claimid in (select CLAIM_ID from #migrate_claimid)
											IF @@ERROR <> 0
												BEGIN 
													ROLLBACK 
												END
											
											
											--APPEND #all_claims into exclusions
											insert into EXT_CLAIM_EXCLUSION
											select claimid,sourcedatakey,@BATCH_RUN_DT,'9999'
											from #all_claims
											where claimid not in (select claim_id from EXT_CLAIM_EXCLUSION)
											
											--Get all claims that have a "PROD" FILEID
											
											IF OBJECT_ID('TEMPDB..#prod_fileid') <> 0
												DROP TABLE #prod_fileid
												
													create table #prod_fileid
													(
													fileid varchar(50)
													)
														 
														insert into #prod_fileid
														SELECT FILEID
														FROM OUTB_FILE_HIST
														where FILE_TYPE = 'Claim Encounter'
															AND CHARINDEX('PROD',FILEHEADER) > 0
														--ORDER BY ENTRYDT DESC
														if @@ERROR <> 0 
														begin 
															rollback
														end
														

																		
															insert into EXT_CLAIM_EXCLUSION
															SELECT CLAIM_ID,SOURCEDATAKEY,@BATCH_RUN_DT,'1'
															FROM OUTB_CLAIM_STATUS CS
															INNER JOIN #prod_fileid T
															ON CS.FILEID = T.fileid
															WHERE SOURCEDATAKEY = @sourcedatekey
															--ORDER BY sourcedatakey,claim_id
																IF @@ERROR <> 0
															BEGIN 
																	ROLLBACK 
															END
													
								
											----Append all claims associated to a HSCE.QA FILE
																
															insert into EXT_CLAIM_EXCLUSION
															SELECT CLAIM_ID,SOURCEDATAKEY,@BATCH_RUN_DT,'1'
															FROM OUTB_CLAIM_STATUS CS
															WHERE SOURCEDATAKEY = @sourcedatekey
																AND SUBSTRING(FILEID,1,7) = 'HSCE.QA'
															--ORDER BY sourcedatakey,claim_id
																IF @@ERROR <> 0
															BEGIN 
																	ROLLBACK 
															END
													
											
											
								end
								
																					
								--TRUNCATE EXT_HRP_CLAIM_EXCLUSION TABLE   
								TRUNCATE TABLE  EXT_CLAIM_EXCLUSION
								
								----APPEND EXCLUSIONS
								 
								--	INSERT INTO EXT_CLAIM_EXCLUSION
								--	SELECT CLAIM_ID
								--			,SOURCDATAKEY
								--			,@BATCH_RUN_DT
								--			,EXCL_ID
								--	 FROM EXT_CLAIM_EXCLUSION
								--	IF @@ERROR <> 0
								--		BEGIN 
								--				ROLLBACK 
								--		END
								
								
								--Append exclusion history
								 
									INSERT INTO EXT_CLAIM_EXCLUSION
									SELECT CLAIM_ID
											,SOURCeDATAKEY
											,@BATCH_RUN_DT
											,EXCL_ID
									 FROM EXT_CLAIM_EXCLUSION_HIST
									where sourcedatakey = @sourcedatekey
									IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
								


				--ASSIGN TOTAL RECORDS		
				SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EXT_CLAIM_EXCLUSION)	
				---HRP_CLAIM_FILE Update Run Controls
						
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = @BATCH_RUN_DT	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,@BATCH_RUN_DT)
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'EXSP_CLAIM_EXCLUSION'
								AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						
						
						
						
						
								
							
