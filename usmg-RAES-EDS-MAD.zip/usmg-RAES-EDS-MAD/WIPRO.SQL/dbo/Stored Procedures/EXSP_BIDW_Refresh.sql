﻿

CREATE Procedure [dbo].[EXSP_BIDW_Refresh]

AS
/***************************************************************************************************
** CREATE DATE: 07/2012
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: Procedure executes the following  post EDS BIDW Refresh jobs.
**
**				Claim Exclusion History build - refresh of EDS excluded claims
**				Claim Inventory - updates to the EDS claim inventory table 
**				Claim MMAI Inventory - updates to the EDS MMAI claim inventory table
**
**
**
**
**
**
**
Modification History
====================
Date			Who				Description
09/20/2018		Scott Waller	TETDM-1881  We found out that the EXSP_CLAIM_EXCLUSION_HIST sproc 
								populates the Exclusion table and for the 9020, it bases the claimid's
								on those in the EDS MMAI Product table.  That table at this point still
								has all the claims from the last month's refresh.
								So EXSP_CLAIM_RECON_MMAI needs to be run first, before 
								EXSP_CLAIMI_EXCLUSION_HIST
-----------------------------------------------------------------------------------------------------

*****************************************************************************************************/	

	DECLARE
										
								@TOTAL_RECORDS INT,
								@ENTRYDT DATETIME
								
							--ASSIGN @ENTRYDT TO EXECUTION DATETIME

								SET @ENTRYDT = (GETDATE())
							--EXSP_HRP_CLAIM_RECON RUN CONTROLS
							INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('EXSP_BIDW_Refresh'
											,'BIDW Post Jobs'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE()
											)
-- TETDM-1881	Scott Waller
-- make EXSP_CLAIM_RECON_MMAI the first sproc executed, as opposed to third

								--Refresh EDS MMAI (Care/Caid) Inventory 
								Execute EXSP_CLAIM_RECON_MMAI
								--Build EDS Exclusions 
								Execute EXSP_CLAIM_EXCLUSION_HIST
								--Update EDS Inventory with recently added BIDW refresh claims
								Execute EXSP_CLAIM_RECON


		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RECON
											 
							SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EXT_CLAIM_EXCLUSION_HIST)
							SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM EXT_EDPS_CLAIM_STATUS)
							SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM EXT_MMAI_CLAIM_PRODUCT)						
						----EXSP_HRP_CLAIM_RECON UPDATE RUN CONTROLS
								
										UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EXSP_BIDW_Refresh'
													AND END_DT IS NULL
										
