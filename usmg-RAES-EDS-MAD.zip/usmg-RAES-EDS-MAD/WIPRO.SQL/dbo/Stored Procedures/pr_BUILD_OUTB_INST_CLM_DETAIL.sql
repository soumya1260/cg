﻿  
  
  
  
  
  
  
  
CREATE  PROCEDURE [dbo].[pr_BUILD_OUTB_INST_CLM_DETAIL]  
AS  
/***************************************************************************************************  
** CREATE DATE: 06/2013  
**  
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM  
**  
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT Institutional CLAIM LINE   
**              INFORMATION.   
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.2. THE SOURCE    
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES.   
**  
**  
Modification History  
====================  
Date			Who				Description  
---------------------------------------------------------------------------------------------------------  
2013-09-23		Loyal Ricks		Add updates to conditionally update procedure code related data elemtns  
								set to ' ' where procedurecodedim.procedurecodetype = 'R' (Revenue Code).  
2013-09-25		Loyal Ricks		Add Revenue Code Updates from EDPS_Data.dbo.ClaimLineRevenueCodeDim  
2013-10-01		Dwight Staggs	Had to qualify occurances of BeginServiceDate as it is now in both   
								ClaimDim and ClaimDetailDim  
2013-10-25		Loyal Ricks		Add procedurecode data scrub removing decimal and spaces   
								replace(REPLACE(procedurecode,'.',' '),' ','')  
2014-01-27		Loyal Ricks		Revenue Code value updates - Add leading zero to all revenue codes that  
								are not 4 characters in length.  
2014-02-21		Loyal Ricks		Remove HPPS Service Qulaifier & Other payer proc cd qualifier mapping. Result  
								of team review on 2/20. Additional logic required to accurately perform mapping  
								by sourcedatakey (specific to sourcedatakey).  
2014-03-02		Loyal Ricks		OPT_REPT_IND1 Set value = 'I' WHERE PROC_CD IN  ('0L6','$INT')  
2014-04-07		Loyal Ricks		Revenue Code char length adjustments from 4char to 5char  
2014-04-10		Loyal Ricks		PROC_CD & OTH_PAYER1_PROC_CD Update when value = 'UNKNO'  
2014-05-04		Loyal Ricks		Modify REV_CD logic - When length of rev_cd(1-3) = 3 then apply default first  
								character of '0' to make rev_cd 4 characters.   
2014-05-12		Loyal ricks		Remove QTY_UNITS updates from REV_CD logic (claimlinerevenuecode) updates. Updates  
								were incorrectly removing units from outbound claim lines.  
2014-06-16		Loyal Ricks		HIPPS qualifier assignment add using the EXT_HIPPS_CD table. When a valid code is   
								found set the qualifier and other payer qualifier to the appropriate HIPPS value (HP)  
2016-02-10		Loyal Ricks		TETDM-631 Remove Updates of claim header serv_begin_dt & serv_end_dt from using   
								the claimdim begin and end dos fields  
2016-05-03		Loyal Ricks		TETDM-793 Facets Rev Code updates add updates for all sdk and only Facets sdk due   
								to claimlineid format issues between claim line detail tables  
2016-07-20		Loyal Ricks		TETDM-793 - Remove Facets specific logic due to adjustments in BIDW		  
2016-07-20		Loyal Ricks		TETDM-896 - Add logic for calc of line level paymentamt when Facets and withhold > 0  
2016-08-29		Loyal Ricks		TETDM-922 CMS Reject Code 22400- HP Qualifier Must Exist for HIPPS Code  
2016-08-31		Loyal Ricks		TETDM-922 CMS Reject Code 22400- HP Qualifier Must Exist for HIPPS Code, REVISE where criteria  
2016-10-26		Loyal Ricks		TETDM-1022 Remove Multiple instances of REV_CD 0023  
2017-01-08		Loyal Ricks		TETDM 1022 -Revision - When RevCd 0023 present only ClaimLineNo = 1 Rev_cd1 value should be 0023  
2017-06-19      John Bartholomay TETDM-1582 - Remove Line win RevCd 0023 is null  
2017-07-14		Subhash Acharya  TETDM-1522   
2017-11-02      John Bartholomay TETDM-1617  Add procedure code description  
2017-11-07		Mike Vega		TETDM-1613 changed table in 3 areas from: claimrevenuecodedim to: ClaimLineRevenueCodeDim  
2018-01-03		Mike Vega		TETDM-1653 Removed limitation by REC_CD1 also added update check by OTH_PAYER1_PAID_QTY = 0 and QTY_UNITS  
2018-01-24		Mike Vega		TETDM-1613 Comment out REV_CD2 and REV_CD3 Update logic.   
2019-08-19		Noe Leiva		TETDM-2094 Added CLM LINE NO Dynamic Logic to the PROC_MOD logic 
*********************************************************************************************************/	  
--DECLARE VARIABLES  
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM OUTB_INST_HEADER_RESEND  
			DECLARE  
			  
			@TOTAL_RECORDS INT,  
			@sourcedatakey int  
  
			set @sourcedatakey = (select distinct sourcedatakey from OUTB_INST_HEADER);  
  
  
--HRP_CLAIM_FILE Run controls  
INSERT INTO EXT_SYS_RUNLOG  
		(PROC_NAME  
		,STEP  
		,START_DT  
		,END_DT  
		,RUN_MINUTES  
		,TOTAL_RECORDS  
		,ENTRYDT  
		)  
		VALUES('pr_BUILD_OUTB_INST_CLMDETAIL'  
				,'3'  
				,GETDATE()  
				,NULL  
				,NULL  
				,0  
				,GETDATE()  
				)  
				  
--CREATE WORK TABLE   
IF OBJECT_ID('TEMPDB..#OUTB_INST_DETAIL') <> 0  
				DROP TABLE #OUTB_INST_DETAIL  
CREATE TABLE [#OUTB_INST_DETAIL](  
	[RECORD_TYPE] [char](1) NULL,  
	[CLAIM_ID] [char](20) NULL,  
	[CLAIM_LINE_NO] [char](5) NULL,  
	[SERV_START_DT] [char](10) NULL,  
	[SERV_END_DT] [char](10) NULL,  
	[REV_CD1] [char](5) NULL,  
	[REV_CD2] [char](5) NULL,  
	[REV_CD3] [char](5) NULL,  
	[SERV_ID_QUAL] [char](2) NULL,  
	[PROC_CD] [char](5) NULL,  
	[PROC_MOD1] [char](2) NULL,  
	[PROC_MOD2] [char](2) NULL,  
	[PROC_MOD3] [char](2) NULL,  
	[PROC_MOD4] [char](2) NULL,  
	[PROC_DESC] [char](80) NULL,  
	[TOTAL_CHRG_AMT] [char](18) NULL,  
	[NON_COV_AMT] [char](18) NULL,  
	[QTY_DAYS] [char](15) NULL,  
	[QTY_UNITS] [char](15) NULL,  
	[LINE_CNTRL_NO] [CHAR] (30),  
	[GS_TAX_AMT] [CHAR] (18),  
	[FAC_TAX_AMT] [CHAR] (18),  
	[INST_PRINCIPAL_PROC_TYPE_IND] [CHAR] (10),  
	[OTH_PAYER1_PRIMEID] [char](80) NULL,  
	[OTH_PAYER1_PAID_AMT] [char](18) NULL,  
	[OTH_PAYER1_PROC_CD] [char](8) NULL,  
	[OTH_PAYER1_PAID_QTY] [char](9) NULL,  
	[OTH_PAYER1_ADJ_BUNDLE] [char](6) NULL,  
	[CLM_ADJ_GRP111] [char](30) NULL,  
	[CLM_ADJ_REASON111] [char](50) NULL,  
	[CLM_ADJ_AMT111] [char](18) NULL,  
	[CLM_ADJ_QTY111] [char](18) NULL,  
	[CLM_ADJ_REASON112] [char](50) NULL,  
	[CLM_ADJ_AMT112] [char](18) NULL,  
	[CLM_ADJ_QTY112] [char](18) NULL,  
	[CLM_ADJ_REASON113] [char](50) NULL,  
	[CLM_ADJ_AMT113] [char](18) NULL,  
	[CLM_ADJ_QTY113] [char](18) NULL,  
	[CLM_ADJ_REASON114] [char](50) NULL,  
	[CLM_ADJ_AMT114] [char](18) NULL,  
	[CLM_ADJ_QTY114] [char](18) NULL,  
	[CLM_ADJ_REASON115] [char](50) NULL,  
	[CLM_ADJ_AMT115] [char](18) NULL,  
	[CLM_ADJ_QTY115] [char](18) NULL,  
	[CLM_ADJ_REASON116] [char](50) NULL,  
	[CLM_ADJ_AMT116] [char](18) NULL,  
	[CLM_ADJ_QTY116] [char](18) NULL,  
	[CLM_ADJ_GRP12] [char](30) NULL,  
	[CLM_ADJ_REASON121] [char](50) NULL,  
	[CLM_ADJ_AMT121] [char](18) NULL,  
	[CLM_ADJ_QTY121] [char](18) NULL,  
	[CLM_ADJ_REASON122] [char](50) NULL,  
	[CLM_ADJ_AMT122] [char](18) NULL,  
	[CLM_ADJ_QTY122] [char](18) NULL,  
	[CLM_ADJ_REASON123] [char](50) NULL,  
	[CLM_ADJ_AMT123] [char](18) NULL,  
	[CLM_ADJ_QTY123] [char](18) NULL,  
	[CLM_ADJ_REASON124] [char](50) NULL,  
	[CLM_ADJ_AMT124] [char](18) NULL,  
	[CLM_ADJ_QTY124] [char](18) NULL,  
	[CLM_ADJ_REASON125] [char](50) NULL,  
	[CLM_ADJ_AMT125] [char](18) NULL,  
	[CLM_ADJ_QTY125] [char](18) NULL,  
	[CLM_ADJ_REASON126] [char](50) NULL,  
	[CLM_ADJ_AMT126] [char](18) NULL,  
	[CLM_ADJ_QTY126] [char](18) NULL,  
	[CLM_ADJ_GRP13] [char](30) NULL,  
	[CLM_ADJ_REASON131] [char](50) NULL,  
	[CLM_ADJ_AMT131] [char](18) NULL,  
	[CLM_ADJ_QTY131] [char](18) NULL,  
	[CLM_ADJ_REASON132] [char](50) NULL,  
	[CLM_ADJ_AMT132] [char](18) NULL,  
	[CLM_ADJ_QTY132] [char](18) NULL,  
	[CLM_ADJ_REASON133] [char](50) NULL,  
	[CLM_ADJ_AMT133] [char](18) NULL,  
	[CLM_ADJ_QTY133] [char](18) NULL,  
	[CLM_ADJ_REASON134] [char](50) NULL,  
	[CLM_ADJ_AMT134] [char](18) NULL,  
	[CLM_ADJ_QTY134] [char](18) NULL,  
	[CLM_ADJ_REASON135] [char](50) NULL,  
	[CLM_ADJ_AMT135] [char](18) NULL,  
	[CLM_ADJ_QTY135] [char](18) NULL,  
	[CLM_ADJ_REASON136] [char](50) NULL,  
	[CLM_ADJ_AMT136] [char](18) NULL,  
	[CLM_ADJ_QTY136] [char](18) NULL,  
	[CLM_ADJ_GRP14] [char](30) NULL,  
	[CLM_ADJ_REASON141] [char](50) NULL,  
	[CLM_ADJ_AMT141] [char](18) NULL,  
	[CLM_ADJ_QTY141] [char](18) NULL,  
	[CLM_ADJ_REASON142] [char](50) NULL,  
	[CLM_ADJ_AMT142] [char](18) NULL,  
	[CLM_ADJ_QTY142] [char](18) NULL,  
	[CLM_ADJ_REASON143] [char](50) NULL,  
	[CLM_ADJ_AMT143] [char](18) NULL,  
	[CLM_ADJ_QTY143] [char](18) NULL,  
	[CLM_ADJ_REASON144] [char](50) NULL,  
	[CLM_ADJ_AMT144] [char](18) NULL,  
	[CLM_ADJ_QTY144] [char](18) NULL,  
	[CLM_ADJ_REASON145] [char](50) NULL,  
	[CLM_ADJ_AMT145] [char](18) NULL,  
	[CLM_ADJ_QTY145] [char](18) NULL,  
	[CLM_ADJ_REASON146] [char](50) NULL,  
	[CLM_ADJ_AMT146] [char](18) NULL,  
	[CLM_ADJ_QTY146] [char](18) NULL,  
	[CLM_ADJ_GRP15] [char](30) NULL,  
	[CLM_ADJ_REASON151] [char](50) NULL,  
	[CLM_ADJ_AMT151] [char](18) NULL,  
	[CLM_ADJ_QTY151] [char](18) NULL,  
	[CLM_ADJ_REASON152] [char](50) NULL,  
	[CLM_ADJ_AMT152] [char](18) NULL,  
	[CLM_ADJ_QTY152] [char](18) NULL,  
	[CLM_ADJ_REASON153] [char](50) NULL,  
	[CLM_ADJ_AMT153] [char](18) NULL,  
	[CLM_ADJ_QTY153] [char](18) NULL,  
	[CLM_ADJ_REASON154] [char](50) NULL,  
	[CLM_ADJ_AMT154] [char](18) NULL,  
	[CLM_ADJ_QTY154] [char](18) NULL,  
	[CLM_ADJ_REASON155] [char](50) NULL,  
	[CLM_ADJ_AMT155] [char](18) NULL,  
	[CLM_ADJ_QTY155] [char](18) NULL,  
	[CLM_ADJ_REASON156] [char](50) NULL,  
	[CLM_ADJ_AMT156] [char](18) NULL,  
	[CLM_ADJ_QTY156] [char](18) NULL,  
	[OTH_PAYER1_ADJ_DT] [char](10) NULL,  
	[OPT_REPT_IND1] [CHAR] (30) NULL,--Optional Reporting Indicator 1  
	[OPT_REPT_IND2] [CHAR] (30) NULL,--Optional Reporting Indicator 2  
	[OPT_REPT_IND3] [CHAR] (30) NULL,--Optional Reporting Indicator 3  
	[EPSDT_IND] [CHAR] (1)								,--EPSDT Indicator  
	[FAM_PLAN_IND] [CHAR] (1) ,--Family Planning Indicator  
	[OBSTET_ANES_UNITS] [CHAR] (15) NULL,--Obstetrical Anesthesia Additional Units  
	[OTH_PAYER1_PROC_CD_QUAL] [CHAR] (2), --Other Payer 1 Procedure Code Qualifier  
	[OTH_PAYER2_PROC_CD_QUAL] [CHAR] (2), --Other Payer 2 Procedure Code Qualifier  
	[SOURCEDATAKEY] [int] NULL  
)   
INSERT INTO #OUTB_INST_DETAIL  
			SELECT 'L'  
				,claimid  
				,claimlineid  
				,CD.beginservicedatekey  
				,endservicedatekey  
				,' ' --revenue code 1  
				,' '--revenue code 2  
				,' '--revenue code 3  
				,'HC'--Product or Service ID Qualifier (HCPC/CPT Codes Default)  
				,case replace(REPLACE(procedurecode,'.',' '),' ','') WHEN 'UNKNOWN' THEN  ' ' ELSE replace(REPLACE(procedurecode,'.',' '),' ','') END--procedure code  
				,' '--procedure modifier1  
				,' '  
				,' '  
				,' '  
				,' '--PROC_DESC  
				,ltrim(requestedamt) --total_chrg_amt  
				,' '  
				--,'UN'--Anesthesia Flag  
				,' '--qty_days  
				,quantity --qty units  
				,claimlineid--line item control number  
				,' ' --gs_tax_amt  
				,' '--fac_tax_amt  
				,' '--INST_PRICIPAL_PROC_TYPE_IND  
				,' '--OTH_PAYER1_PRIMEID	  
				,ltrim(PaymentAmount)--OTH_PAYER1_PAID_AMT	CHAR(18),  
				,case replace(REPLACE(procedurecode,'.',' '),' ','') WHEN 'UNKNOWN' THEN  ' ' ELSE replace(REPLACE(procedurecode,'.',' '),' ','') END--OTH_PAYER1_PROC_CD	CHAR(8),  
				,Quantity--OTH_PAYER1_PAID_QTY	CHAR(9),  
				,' '--OTH_PAYER1_ADJ_BUNDLE	CHAR(6),  
				,'CO'--CLM_ADJ_GRP1		CHAR(30),  
				,'45'--[CLM_ADJ_REASON111] ,  
				,' '--[CLM_ADJ_AMT111] ,  
				,' '--[CLM_ADJ_QTY111] ,  
				,' '--[CLM_ADJ_REASON112] ,  
				,' '--[CLM_ADJ_AMT112] ,  
				,' '--[CLM_ADJ_QTY112] ,  
				,' '--[CLM_ADJ_REASON113] ,  
				,' '--[CLM_ADJ_AMT113] ,  
				,' '--[CLM_ADJ_QTY113] ,  
				,' '--[CLM_ADJ_REASON114] ,  
				,' '--[CLM_ADJ_AMT114] ,  
				,' '--[CLM_ADJ_QTY114] ,  
				,' '--[CLM_ADJ_REASON115] ,  
				,' '--[CLM_ADJ_AMT115] ,  
				,' '--[CLM_ADJ_QTY115] ,  
				,' '--[CLM_ADJ_REASON116] ,  
				,' '--[CLM_ADJ_AMT116] ,  
				,' '--[CLM_ADJ_QTY116] ,	  
				,'PI'--[CLM_ADJ_GRP12] ' '--[char](30) ,  
				,'3'--[CLM_ADJ_REASON121] ,  
				,' '--[CLM_ADJ_AMT121] ,  
				,' '--[CLM_ADJ_QTY121] ,  
				,' '--[CLM_ADJ_REASON122] ,  
				,' '--[CLM_ADJ_AMT122] ,  
				,' '--[CLM_ADJ_QTY122] ,  
				,' '--[CLM_ADJ_REASON123] ,  
				,' '--[CLM_ADJ_AMT123] ,  
				,' '--[CLM_ADJ_QTY123] ,  
				,' '--[CLM_ADJ_REASON124] ,  
				,' '--[CLM_ADJ_AMT124] ,  
				,' '--[CLM_ADJ_QTY124] ,  
				,' '--[CLM_ADJ_REASON125] ,  
				,' '--[CLM_ADJ_AMT125] ,  
				,' '--[CLM_ADJ_QTY125] ,  
				,' '--[CLM_ADJ_REASON126] ,  
				,' '--[CLM_ADJ_AMT126] ,  
				,' '--[CLM_ADJ_QTY126] ,  
				,' '--[CLM_ADJ_GRP13] ,' '--[char](30) ,  
				,' '--[CLM_ADJ_REASON131] ,  
				,' '--[CLM_ADJ_AMT131] ,  
				,' '--[CLM_ADJ_QTY131] ,  
				,' '--[CLM_ADJ_REASON132] ,  
				,' '--[CLM_ADJ_AMT132] ,  
				,' '--[CLM_ADJ_QTY132] ,  
				,' '--[CLM_ADJ_REASON133] ,  
				,' '--[CLM_ADJ_AMT133] ,  
				,' '--[CLM_ADJ_QTY133] ,  
				,' '--[CLM_ADJ_REASON134] ,  
				,' '--[CLM_ADJ_AMT134] ,  
				,' '--[CLM_ADJ_QTY134] ,  
				,' '--[CLM_ADJ_REASON135] ,  
				,' '--[CLM_ADJ_AMT135] ,  
				,' '--[CLM_ADJ_QTY135] ,  
				,' '--[CLM_ADJ_REASON136] ,  
				,' '--[CLM_ADJ_AMT136] ,  
				,' '--[CLM_ADJ_QTY136] ,  
				,' '--[CLM_ADJ_GRP14] ,' '--[char](30) ,  
				,' '--[CLM_ADJ_REASON141] ,  
				,' '--[CLM_ADJ_AMT141] ,  
				,' '--[CLM_ADJ_QTY141] ,  
				,' '--[CLM_ADJ_REASON142] ,  
				,' '--[CLM_ADJ_AMT142] ,  
				,' '--[CLM_ADJ_QTY142] ,  
				,' '--[CLM_ADJ_REASON143] ,  
				,' '--[CLM_ADJ_AMT143] ,  
				,' '--[CLM_ADJ_QTY143] ,  
				,' '--[CLM_ADJ_REASON144] ,  
				,' '--[CLM_ADJ_AMT144] ,  
				,' '--[CLM_ADJ_QTY144] ,  
				,' '--[CLM_ADJ_REASON145] ,  
				,' '--[CLM_ADJ_AMT145] ,  
				,' '--[CLM_ADJ_QTY145] ,  
				,' '--[CLM_ADJ_REASON146] ,  
				,' '--[CLM_ADJ_AMT146] ,  
				,' '--[CLM_ADJ_QTY146] ,  
				,' '--[CLM_ADJ_GRP15] ,' '--[char](30) ,  
				,' '--[CLM_ADJ_REASON151] ,  
				,' '--[CLM_ADJ_AMT151] ,  
				,' '--[CLM_ADJ_QTY151] ,  
				,' '--[CLM_ADJ_REASON152] ,  
				,' '--[CLM_ADJ_AMT152] ,  
				,' '--[CLM_ADJ_QTY152] ,  
				,' '--[CLM_ADJ_REASON153] ,  
				,' '--[CLM_ADJ_AMT153] ,  
				,' '--[CLM_ADJ_QTY153] ,  
				,' '--[CLM_ADJ_REASON154] ,  
				,' '--[CLM_ADJ_AMT154] ,  
				,' '--[CLM_ADJ_QTY154] ,  
				,' '--[CLM_ADJ_REASON155] ,  
				,' '--[CLM_ADJ_AMT155] ,  
				,' '--[CLM_ADJ_QTY155] ,  
				,' '--[CLM_ADJ_REASON156] ,  
				,' '--[CLM_ADJ_AMT156] ,  
				,' '--[CLM_ADJ_QTY156] ,  
				,ltrim(PaidDateKey)--OTH_PAYER1_ADJ_DT	CHAR(10),  
				,' '--OPT_REPT_IND1  
				,' '--OPT_REPT_IND2  
				,' '--OPT_REPT_IND3  
				,' '--EPSDT_IND  
				,' '--FAM_PLAN_IND  
				,' '--OBSTET_ANES_UNITS  
				,'HC'--OTH_PAYER1_PROC_CD_QUAL (HCPC/CPT Codes Default)  
				,' '--OTH_PAYER2_PROC_CD_QUAL  
				,CD.SOURCEDATAKEY  
			from EDPS_Data.dbo.claimdetaildim CD  
			JOIN OUTB_INST_HEADER CI  
			ON CD.CLAIMID = CI.CLAIM_ID   
			AND CD.SOURCEDATAKEY = CI.SOURCEDATAKEY  
			--where claimid in (select CLAIM_ID FROM OUTB_INST_HEADER)  
				--added after 4/19 BIDW REFRESH - CLAIM LINE PROCEDURE CODES INCLUDED WITH THIS UPDATE  
			WHERE LEN(ProcedureCode) <= 5  
			ORDER BY CD.ClaimID,CD.ClaimLineID  
			--UPDATE EXT_HRP_CLAIM.CMS_CONTRACT_NUM USING DOS OF CLAIM TO GET APPROPRIATE ELIGIBILITY  
			--HRP CLAIM HEADER - CMS_CONTRACT_NUM & OTH_PAYER1_PLANID UPDATES  
			--use claimline dos to determine eligibility row from mmr that will be used. Code will be based on datasourcekey and claim to mmr relationship.  
			IF OBJECT_ID('TEMPDB..#INST_ELIG') <> 0  
				DROP TABLE #INST_ELIG  
			  
				SELECT  C.CLAIM_ID,C.MEMBER_ID,SUBSTRING(MIN(CD.SERV_START_DT),1,6) AS 'DOS',C.SOURCEDATAKEY  
				INTO #INST_ELIG  
				FROM OUTB_INST_HEADER C  
					,#OUTB_INST_DETAIL CD  
				WHERE C.CLAIM_ID = CD.CLAIM_ID  
				GROUP BY C.CLAIM_ID,C.MEMBER_ID,C.SOURCEDATAKEY  
				ORDER BY C.MEMBER_ID,C.CLAIM_ID  
		--MEMBER ELIGIBILITY - USE MIN(CLAIMDETAILDIM.BEGINSERVICEDATEKEY)  
		--MHC ELGIBILITY  
			--UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO  
		  
			--UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO  
		IF OBJECT_ID('TEMPDB..#INST_HPLAN') <> 0  
				DROP TABLE #INST_HPLAN	  
		 SELECT CLAIMID,CD.LOBCODE,HCFACODE  
		 INTO #INST_HPLAN  
		 FROM OUTB_INST_HEADER C  
			,CLAIMDIM CD  
			,MDQOLib.dbo.LineofBusinessDim L  
		 WHERE C.CLAIM_ID = CD.CLAIMID  
				--AND CD.LOBCODE = L.LOBCode  
   
 		  
			UPDATE OUTB_INST_HEADER  
			SET CMS_CONTRACT_NUM = T.HCFACode  
					,OTH_PAYER1_PLANID = T.HCFACode  
			FROM OUTB_INST_HEADER C  
				 ,#INST_HPLAN T			  
			WHERE C.CLAIM_ID = T.CLAIMID  
			  
			  
			UPDATE #OUTB_INST_DETAIL  
			SET OTH_PAYER1_PRIMEID = CI.OTH_PAYER1_PLANID  
			FROM OUTB_INST_HEADER CI  
			JOIN #OUTB_INST_DETAIL CID  
			ON CI.CLAIM_ID = CID.CLAIM_ID  
			  
						  
		--UPDATE OTH_PAYER1_PRIMEID  
		  
			UPDATE #OUTB_INST_DETAIL  
			SET OTH_PAYER1_PRIMEID = C.CMS_CONTRACT_NUM   
			FROM #OUTB_INST_DETAIL CD  
			JOIN OUTB_INST_HEADER C  
			ON C.CLAIM_ID = CD.CLAIM_ID  
	  
	  
	    --UPDATE PROC_MOD1  
		   
			UPDATE #OUTB_INST_DETAIL  
			SET PROC_MOD1 = CMD.MODIFIERCODE  
			FROM #OUTB_INST_DETAIL ECD  
				,EDPS_DATA.DBO.CLAIMMODIFIERDIM CMD  
			WHERE ECD.CLAIM_ID = CMD.CLAIMID  
			AND RIGHT('000' + CONVERT(VARCHAR(4),ECD.CLAIM_LINE_NO),4) = RIGHT('000' + CONVERT(VARCHAR(4),CMD.CLAIMLINEID),4) -- TETDM2094
			AND CMD.SEQUENCE = '1'  
			  
		--UPDATE PROC_MOD2  
		  
			UPDATE #OUTB_INST_DETAIL  
			SET PROC_MOD2 = CMD.MODIFIERCODE  
			FROM #OUTB_INST_DETAIL ECD  
				,EDPS_DATA.DBO.CLAIMMODIFIERDIM CMD  
			WHERE ECD.CLAIM_ID = CMD.CLAIMID  
			AND RIGHT('000' + CONVERT(VARCHAR(4),ECD.CLAIM_LINE_NO),4) = RIGHT('000' + CONVERT(VARCHAR(4),CMD.CLAIMLINEID),4)
			AND CMD.SEQUENCE = '2'  
			  
		--UPDATE PROC_MOD3  
		  
			UPDATE #OUTB_INST_DETAIL  
			SET PROC_MOD3 = CMD.MODIFIERCODE  
			FROM #OUTB_INST_DETAIL ECD  
				,EDPS_DATA.DBO.CLAIMMODIFIERDIM CMD  
			WHERE ECD.CLAIM_ID = CMD.CLAIMID  
			AND RIGHT('000' + CONVERT(VARCHAR(4),ECD.CLAIM_LINE_NO),4) = RIGHT('000' + CONVERT(VARCHAR(4),CMD.CLAIMLINEID),4)
			AND CMD.SEQUENCE = '3'  
			  
		--UPDATE PROC_MOD4  
		  
			UPDATE #OUTB_INST_DETAIL  
			SET PROC_MOD4 = CMD.MODIFIERCODE  
			FROM #OUTB_INST_DETAIL ECD  
				,EDPS_DATA.DBO.CLAIMMODIFIERDIM CMD  
			WHERE ECD.CLAIM_ID = CMD.CLAIMID  
			AND RIGHT('000' + CONVERT(VARCHAR(4),ECD.CLAIM_LINE_NO),4) = RIGHT('000' + CONVERT(VARCHAR(4),CMD.CLAIMLINEID),4)
			AND CMD.SEQUENCE = '4'  
		  
		  
			  
		--UPDATE EMER_FLAG  
		--begin transaction   
		--	update #OUTB_INST_DETAIL  
		--	set EMER_FLAG = EAD.AdmissionTypeCode  
		--	FROM OUTB_INST_HEADER EC  
		--		,#OUTB_INST_DETAIL ECD  
		--		,EventAdmissionDim EAD  
		--	WHERE EC.CLAIM_ID = ECD.CLAIM_ID  
		--		AND EC.REFERRAL_NO = EAD.AuthorizationID  
		--	if @@ERROR <> 0  
		--	begin  
		--		rollback   
		--	end  
		--commit	  
		--UPDATE REV_CD1  
		  
			update #OUTB_INST_DETAIL  
			set REV_CD1 = CR.revenuecode  
			FROM #OUTB_INST_DETAIL ECD  
				,EDPS_Data.dbo.ClaimLineRevenueCodeDim CR  
			WHERE ECD.CLAIM_ID = CR.claimid  
			  
	----TETDM-1613 REMOVED BY MIKE VEGA  
		----UPDATE REV_CD2  
		  
		--	update #OUTB_INST_DETAIL  
		--	set REV_CD2 = CR.revenuecode  
		--	FROM #OUTB_INST_DETAIL ECD  
		--		,EDPS_Data.dbo.ClaimLineRevenueCodeDim CR  
		--	WHERE ECD.CLAIM_ID = CR.claimid  
		--		AND REV_CD1 <> CR.revenuecode  
			  
		----UPDATE REV_CD3  
		  
		--	update #OUTB_INST_DETAIL  
		--	set REV_CD3 = CR.revenuecode  
		--	FROM #OUTB_INST_DETAIL ECD  
		--		,EDPS_Data.dbo.ClaimLineRevenueCodeDim CR  
		--	WHERE ECD.CLAIM_ID = CR.claimid  
		--		AND REV_CD1 <> CR.revenuecode  
		--		AND REV_CD2 <> CR.revenuecode  
			  
		  
			--ANESTHESIA FLAG UPDATE  
		--BEGIN TRANSACTION   
		--	UPDATE #OUTB_INST_DETAIL  
		--	SET ANES_FLAG =  'MJ'  
		--	WHERE PROC_CD BETWEEN '00100' AND '01999'  
		--	if @@ERROR <> 0  
		--	begin  
		--		rollback   
		--	end  
		--commit  
		  
		---REV_CD1 is temporary while claimlinerevenuedim is added to refresh  
			  
			Update #OUTB_INST_DETAIL  
			SET  REV_CD1 = PROC_CD  
				,PROC_CD = ' '  
				,SERV_ID_QUAL = ' '  
				,OTH_PAYER1_PROC_CD = ' '  
				,OTH_PAYER1_PROC_CD_QUAL = ' '  
			FROM #OUTB_INST_DETAIL CD  
			JOIN EDPS_Data.dbo.PROCEDURECODEDIM P  
			ON RTRIM(CD.PROC_CD) = RTRIM(P.procedurecode)  
			WHERE P.proceduretypecode = 'R'  
				  
		--Outbound rev code temporary table  
			IF OBJECT_ID('TEMPDB..#TMP_OUB_REVCD') <> 0  
					DROP TABLE #TMP_OUB_REVCD  
					  
				create table #TMP_OUB_REVCD  
				(  
					CLAIM_ID CHAR(20)  
					,CLAIM_LINE_NO CHAR(5)  
					,REV_CD1 CHAR(5)  
					,REV_CD2 CHAR(5)  
					,REV_CD3 CHAR(5)  
					,QTY_UNITS int  
				)  
				  
				INSERT INTO #TMP_OUB_REVCD  
				SELECT CLAIM_ID  
						,CLAIM_LINE_NO  
						,REV_CD1  
						,REV_CD2  
						,REV_CD3  
						,' '  
				FROM #OUTB_INST_DETAIL  
				ORDER BY CLAIM_ID,CLAIM_LINE_NO  
				  
				  
			---BIDW rev code temporary table  
			--TETDM-793 Facets Rev Code updates add updates for all sdk and only Facets sdk due to claimlineid format issues between claim line detail tables  
			IF OBJECT_ID('TEMPDB..#TMP_BIDW_REVCD') <> 0  
					DROP TABLE #TMP_BIDW_REVCD  
  
			Create Table #TMP_BIDW_REVCD  
			(  
			CLAIMID VARCHAR(20)  
			,CLAIMLINEID VARCHAR(5)  
			,REVENUECODE VARCHAR(5)  
			,QUANTITY int  
  
			)  
  
			--TETDM-793 - Remove Facets specific logic due to adjustments in BIDW  
			  
			--IF @SOURCEDATAKEY <> 30   
			--	BEGIN  
			INSERT INTO #TMP_BIDW_REVCD  
			SELECT CR.CLAIMID  
				,CR.CLAIMLINEID  
				,CR.REVENUECODE  
				,CR.QUANTITY  
			FROM EDPS_Data.dbo.ClaimLineRevenueCodeDim CR  
			JOIN #TMP_OUB_REVCD T  
			ON CR.ClaimID = T.CLAIM_ID  
			AND CR.ClaimLineID = T.CLAIM_LINE_NO  
			ORDER BY CR.ClaimID,CR.ClaimLineID  
				--END  
  
			--IF @SOURCEDATAKEY = 30   
			--	BEGIN   
			--				INSERT #TMP_BIDW_REVCD  
			--				SELECT CR.CLAIMID  
			--				,CONVERT(CHAR, CONVERT(INT, CR.CLAIMLINEID))  
			--				,CR.REVENUECODE  
			--				,CR.QUANTITY  
			--			FROM EDPS_Data.dbo.ClaimLineRevenueCodeDim CR  
			--			JOIN #TMP_OUB_REVCD T  
			--			ON CR.ClaimID = T.CLAIM_ID  
			--			AND convert(int,CR.ClaimLineID) = T.CLAIM_LINE_NO  
			--			ORDER BY CR.ClaimID,CR.ClaimLineID  
			--	END  
  
			--UPDATE REV CODES & Quantity  
			--REV_CD1 Update  
			  
			UPDATE #TMP_OUB_REVCD  
			SET REV_CD1 = TB.REVENUECODE  
				,QTY_UNITS = TB.QUANTITY  
			FROM #TMP_OUB_REVCD ID  
			JOIN #TMP_BIDW_REVCD TB  
			ON ID.CLAIM_ID = TB.CLAIMID  
			AND ID.CLAIM_LINE_NO = TB.CLAIMLINEID  
			  
			----TETDM-1613 REMOVE REV_CD2 AND REV_CD3 UPDATES PER REQUEST  
			----REV_CD2 Update  
			  
			--UPDATE #TMP_OUB_REVCD  
			--SET REV_CD2 = TB.REVENUECODE  
			--	--,QTY_UNITS = TB.QUANTITY  
			--FROM #TMP_OUB_REVCD ID  
			--JOIN #TMP_BIDW_REVCD TB  
			--ON ID.CLAIM_ID = TB.CLAIMID  
			--AND ID.CLAIM_LINE_NO = TB.CLAIMLINEID  
			--WHERE ID.REV_CD1 <> TB.REVENUECODE  
			  
			----REV_CD3 Update  
			  
			--UPDATE #TMP_OUB_REVCD  
			--SET REV_CD3 = TB.REVENUECODE  
			--	--,QTY_UNITS = TB.QUANTITY  
			--FROM #TMP_OUB_REVCD ID  
			--JOIN #TMP_BIDW_REVCD TB  
			--ON ID.CLAIM_ID = TB.CLAIMID  
			--AND ID.CLAIM_LINE_NO = TB.CLAIMLINEID  
			--WHERE ID.REV_CD1 <> TB.REVENUECODE  
			--	and id.REV_CD2 <> TB.REVENUECODE  
			  
			   
			   
			UPDATE #OUTB_INST_DETAIL  
			SET  REV_CD1 = TB.REV_CD1  
				----TETDM-1613 REMOVED BY MVEGA PER REQUEST  
				--,REV_CD2 = TB.REV_CD2  
				--,REV_CD3 = TB.REV_CD3  
				--  
				--note 5/12/14  
				--remove updates causing claim lines to submit with zero units  
				--,QTY_UNITS = TB.QTY_UNITS  
			FROM #OUTB_INST_DETAIL ID  
			JOIN #TMP_OUB_REVCD TB  
			ON ID.CLAIM_ID = TB.CLAIM_ID  
			AND ID.CLAIM_LINE_NO = TB.CLAIM_LINE_NO	  
					  
			---  
			--- Update Rev Codes to Valid 4 character value by adding a leading zero  
			---  
			  
			   
				update #OUTB_INST_DETAIL  
				SET REV_CD1 = '0' +''+ RTRIM(REV_CD1)  
				WHERE LEN(REV_CD1) = 3  
			  
			  
				----TETDM-1613 REMOVED (REV_CD2 / REV_CD3) BY MVEGA PER REQUEST			  
				--update #OUTB_INST_DETAIL  
				--SET REV_CD2 = '0' +''+ RTRIM(REV_CD2)  
				--WHERE LEN(REV_CD2) = 3  
			  
				--update #OUTB_INST_DETAIL  
				--SET REV_CD3 = '0' +''+ RTRIM(REV_CD3)  
				--WHERE LEN(REV_CD3) = 3  
  
				-------------------------------------  
				--TETDM-1582 BEGIN jab  
				--SELECT MAX SERV DT ROWS FOR 0023  
				-------------------------------------  
				--CREATE WORK TABLE   
                IF OBJECT_ID('TEMPDB..#OUTB_INST_DETAIL_0023') <> 0  
				DROP TABLE #OUTB_INST_DETAIL_0023  
                CREATE TABLE [#OUTB_INST_DETAIL_0023]  
				(  
	            [RECORD_TYPE] [char](1) NULL,  
	            [CLAIM_ID] [char](20) NULL,  
	            [CLAIM_LINE_NO] [char](5) NULL,  
	            [SERV_START_DT] [char](10) NULL,  
	            [SERV_END_DT] [char](10) NULL,  
	            [REV_CD1] [char](5) NULL,  
	            [REV_CD2] [char](5) NULL,  
	            [REV_CD3] [char](5) NULL,  
	            [SERV_ID_QUAL] [char](2) NULL,  
	            [PROC_CD] [char](5) NULL,  
	            [PROC_MOD1] [char](2) NULL,  
	            [PROC_MOD2] [char](2) NULL,  
	            [PROC_MOD3] [char](2) NULL,  
	            [PROC_MOD4] [char](2) NULL,  
	            [PROC_DESC] [char](80) NULL,  
	            [TOTAL_CHRG_AMT] [char](18) NULL,  
	            [NON_COV_AMT] [char](18) NULL,  
	            [QTY_DAYS] [char](15) NULL,  
	            [QTY_UNITS] [char](15) NULL,  
	            [LINE_CNTRL_NO] [CHAR] (30),  
	            [GS_TAX_AMT] [CHAR] (18),  
	            [FAC_TAX_AMT] [CHAR] (18),  
 	            [INST_PRINCIPAL_PROC_TYPE_IND] [CHAR] (10),  
	            [OTH_PAYER1_PRIMEID] [char](80) NULL,  
	            [OTH_PAYER1_PAID_AMT] [char](18) NULL,  
	            [OTH_PAYER1_PROC_CD] [char](8) NULL,  
	            [OTH_PAYER1_PAID_QTY] [char](9) NULL,  
	            [OTH_PAYER1_ADJ_BUNDLE] [char](6) NULL,  
	            [CLM_ADJ_GRP111] [char](30) NULL,  
	            [CLM_ADJ_REASON111] [char](50) NULL,  
	            [CLM_ADJ_AMT111] [char](18) NULL,  
	            [CLM_ADJ_QTY111] [char](18) NULL,  
	            [CLM_ADJ_REASON112] [char](50) NULL,  
	            [CLM_ADJ_AMT112] [char](18) NULL,  
	            [CLM_ADJ_QTY112] [char](18) NULL,  
	            [CLM_ADJ_REASON113] [char](50) NULL,  
	            [CLM_ADJ_AMT113] [char](18) NULL,  
	            [CLM_ADJ_QTY113] [char](18) NULL,  
	            [CLM_ADJ_REASON114] [char](50) NULL,  
	            [CLM_ADJ_AMT114] [char](18) NULL,  
	            [CLM_ADJ_QTY114] [char](18) NULL,  
	            [CLM_ADJ_REASON115] [char](50) NULL,  
	            [CLM_ADJ_AMT115] [char](18) NULL,  
	            [CLM_ADJ_QTY115] [char](18) NULL,  
	            [CLM_ADJ_REASON116] [char](50) NULL,  
	            [CLM_ADJ_AMT116] [char](18) NULL,  
	            [CLM_ADJ_QTY116] [char](18) NULL,  
	            [CLM_ADJ_GRP12] [char](30) NULL,  
	            [CLM_ADJ_REASON121] [char](50) NULL,  
	            [CLM_ADJ_AMT121] [char](18) NULL,  
	            [CLM_ADJ_QTY121] [char](18) NULL,  
	            [CLM_ADJ_REASON122] [char](50) NULL,  
	            [CLM_ADJ_AMT122] [char](18) NULL,  
	            [CLM_ADJ_QTY122] [char](18) NULL,  
	            [CLM_ADJ_REASON123] [char](50) NULL,  
	            [CLM_ADJ_AMT123] [char](18) NULL,  
	            [CLM_ADJ_QTY123] [char](18) NULL,  
	            [CLM_ADJ_REASON124] [char](50) NULL,  
	            [CLM_ADJ_AMT124] [char](18) NULL,  
	            [CLM_ADJ_QTY124] [char](18) NULL,  
	            [CLM_ADJ_REASON125] [char](50) NULL,  
	            [CLM_ADJ_AMT125] [char](18) NULL,  
	            [CLM_ADJ_QTY125] [char](18) NULL,  
	            [CLM_ADJ_REASON126] [char](50) NULL,  
	            [CLM_ADJ_AMT126] [char](18) NULL,  
	            [CLM_ADJ_QTY126] [char](18) NULL,  
	            [CLM_ADJ_GRP13] [char](30) NULL,  
	            [CLM_ADJ_REASON131] [char](50) NULL,  
	            [CLM_ADJ_AMT131] [char](18) NULL,  
	            [CLM_ADJ_QTY131] [char](18) NULL,  
	            [CLM_ADJ_REASON132] [char](50) NULL,  
	            [CLM_ADJ_AMT132] [char](18) NULL,  
	            [CLM_ADJ_QTY132] [char](18) NULL,  
	            [CLM_ADJ_REASON133] [char](50) NULL,  
	            [CLM_ADJ_AMT133] [char](18) NULL,  
	            [CLM_ADJ_QTY133] [char](18) NULL,  
	            [CLM_ADJ_REASON134] [char](50) NULL,  
	            [CLM_ADJ_AMT134] [char](18) NULL,  
	            [CLM_ADJ_QTY134] [char](18) NULL,  
	            [CLM_ADJ_REASON135] [char](50) NULL,  
	            [CLM_ADJ_AMT135] [char](18) NULL,  
	            [CLM_ADJ_QTY135] [char](18) NULL,  
	            [CLM_ADJ_REASON136] [char](50) NULL,  
	            [CLM_ADJ_AMT136] [char](18) NULL,  
	            [CLM_ADJ_QTY136] [char](18) NULL,  
	            [CLM_ADJ_GRP14] [char](30) NULL,  
  	            [CLM_ADJ_REASON141] [char](50) NULL,  
	            [CLM_ADJ_AMT141] [char](18) NULL,  
	            [CLM_ADJ_QTY141] [char](18) NULL,  
	            [CLM_ADJ_REASON142] [char](50) NULL,  
	            [CLM_ADJ_AMT142] [char](18) NULL,  
	            [CLM_ADJ_QTY142] [char](18) NULL,  
	            [CLM_ADJ_REASON143] [char](50) NULL,  
	            [CLM_ADJ_AMT143] [char](18) NULL,  
	            [CLM_ADJ_QTY143] [char](18) NULL,  
	            [CLM_ADJ_REASON144] [char](50) NULL,  
	            [CLM_ADJ_AMT144] [char](18) NULL,  
	            [CLM_ADJ_QTY144] [char](18) NULL,  
	            [CLM_ADJ_REASON145] [char](50) NULL,  
	            [CLM_ADJ_AMT145] [char](18) NULL,  
	            [CLM_ADJ_QTY145] [char](18) NULL,  
	            [CLM_ADJ_REASON146] [char](50) NULL,  
	            [CLM_ADJ_AMT146] [char](18) NULL,  
	            [CLM_ADJ_QTY146] [char](18) NULL,  
	            [CLM_ADJ_GRP15] [char](30) NULL,  
	            [CLM_ADJ_REASON151] [char](50) NULL,  
	            [CLM_ADJ_AMT151] [char](18) NULL,  
	            [CLM_ADJ_QTY151] [char](18) NULL,  
	            [CLM_ADJ_REASON152] [char](50) NULL,  
	            [CLM_ADJ_AMT152] [char](18) NULL,  
	            [CLM_ADJ_QTY152] [char](18) NULL,  
	            [CLM_ADJ_REASON153] [char](50) NULL,  
	            [CLM_ADJ_AMT153] [char](18) NULL,  
	            [CLM_ADJ_QTY153] [char](18) NULL,  
	            [CLM_ADJ_REASON154] [char](50) NULL,  
	            [CLM_ADJ_AMT154] [char](18) NULL,  
	            [CLM_ADJ_QTY154] [char](18) NULL,  
	            [CLM_ADJ_REASON155] [char](50) NULL,  
	            [CLM_ADJ_AMT155] [char](18) NULL,  
	            [CLM_ADJ_QTY155] [char](18) NULL,  
	            [CLM_ADJ_REASON156] [char](50) NULL,  
	            [CLM_ADJ_AMT156] [char](18) NULL,  
	            [CLM_ADJ_QTY156] [char](18) NULL,  
	            [OTH_PAYER1_ADJ_DT] [char](10) NULL,  
	            [OPT_REPT_IND1] [CHAR] (30) NULL,--Optional Reporting Indicator 1  
	            [OPT_REPT_IND2] [CHAR] (30) NULL,--Optional Reporting Indicator 2  
	            [OPT_REPT_IND3] [CHAR] (30) NULL,--Optional Reporting Indicator 3  
	            [EPSDT_IND] [CHAR] (1)								,--EPSDT Indicator  
	            [FAM_PLAN_IND] [CHAR] (1) ,--Family Planning Indicator  
	            [OBSTET_ANES_UNITS] [CHAR] (15) NULL,--Obstetrical Anesthesia Additional Units  
	            [OTH_PAYER1_PROC_CD_QUAL] [CHAR] (2), --Other Payer 1 Procedure Code Qualifier  
	            [OTH_PAYER2_PROC_CD_QUAL] [CHAR] (2), --Other Payer 2 Procedure Code Qualifier  
	            [SOURCEDATAKEY] [int] NULL  
               )   
			     
  
			   INSERT INTO #OUTB_INST_DETAIL_0023  
				(  
				   [RECORD_TYPE] ,  
	               [CLAIM_ID] ,  
	               [CLAIM_LINE_NO],  
	               [SERV_START_DT] ,  
	               [SERV_END_DT] ,  
	               [REV_CD1] ,  
	               [REV_CD2] ,  
	               [REV_CD3] ,  
	               [SERV_ID_QUAL],  
	               [PROC_CD] ,  
	               [PROC_MOD1] ,  
	               [PROC_MOD2] ,  
	               [PROC_MOD3] ,  
	               [PROC_MOD4] ,  
	               [PROC_DESC] ,  
	               [TOTAL_CHRG_AMT] ,  
	               [NON_COV_AMT] ,  
	               [QTY_DAYS] ,  
	               [QTY_UNITS] ,  
	               [LINE_CNTRL_NO] ,  
	               [GS_TAX_AMT] ,  
	               [FAC_TAX_AMT] ,  
 	               [INST_PRINCIPAL_PROC_TYPE_IND] ,  
	               [OTH_PAYER1_PRIMEID] ,  
	               [OTH_PAYER1_PAID_AMT] ,  
	               [OTH_PAYER1_PROC_CD] ,  
	               [OTH_PAYER1_PAID_QTY],   
	               [OTH_PAYER1_ADJ_BUNDLE] ,  
	               [CLM_ADJ_GRP111] ,  
	               [CLM_ADJ_REASON111] ,  
	               [CLM_ADJ_AMT111] ,  
	               [CLM_ADJ_QTY111] ,  
	               [CLM_ADJ_REASON112] ,  
	               [CLM_ADJ_AMT112] ,  
	               [CLM_ADJ_QTY112] ,  
	               [CLM_ADJ_REASON113] ,  
	               [CLM_ADJ_AMT113] ,  
	               [CLM_ADJ_QTY113] ,  
	               [CLM_ADJ_REASON114] ,  
	               [CLM_ADJ_AMT114] ,  
	               [CLM_ADJ_QTY114] ,  
	               [CLM_ADJ_REASON115] ,  
	               [CLM_ADJ_AMT115] ,  
	               [CLM_ADJ_QTY115] ,  
	               [CLM_ADJ_REASON116] ,  
	               [CLM_ADJ_AMT116],  
	               [CLM_ADJ_QTY116],  
	               [CLM_ADJ_GRP12] ,  
	               [CLM_ADJ_REASON121],  
	               [CLM_ADJ_AMT121] ,  
	               [CLM_ADJ_QTY121] ,  
	               [CLM_ADJ_REASON122] ,  
	               [CLM_ADJ_AMT122] ,  
	               [CLM_ADJ_QTY122],  
	               [CLM_ADJ_REASON123] ,  
	               [CLM_ADJ_AMT123] ,  
	               [CLM_ADJ_QTY123] ,  
	               [CLM_ADJ_REASON124] ,  
	               [CLM_ADJ_AMT124] ,  
	               [CLM_ADJ_QTY124] ,  
	               [CLM_ADJ_REASON125],  
	               [CLM_ADJ_AMT125] ,  
	               [CLM_ADJ_QTY125] ,  
	               [CLM_ADJ_REASON126],  
	               [CLM_ADJ_AMT126] ,  
	               [CLM_ADJ_QTY126] ,  
	               [CLM_ADJ_GRP13] ,  
	               [CLM_ADJ_REASON131] ,  
	               [CLM_ADJ_AMT131] ,  
	               [CLM_ADJ_QTY131] ,  
	               [CLM_ADJ_REASON132] ,  
	               [CLM_ADJ_AMT132] ,  
	               [CLM_ADJ_QTY132] ,  
	               [CLM_ADJ_REASON133] ,  
	               [CLM_ADJ_AMT133] ,  
	               [CLM_ADJ_QTY133] ,  
	               [CLM_ADJ_REASON134] ,  
	               [CLM_ADJ_AMT134] ,  
	               [CLM_ADJ_QTY134] ,  
	               [CLM_ADJ_REASON135] ,  
	               [CLM_ADJ_AMT135] ,  
	               [CLM_ADJ_QTY135] ,  
	               [CLM_ADJ_REASON136] ,  
	               [CLM_ADJ_AMT136] ,  
	               [CLM_ADJ_QTY136] ,  
	               [CLM_ADJ_GRP14]  ,  
  	               [CLM_ADJ_REASON141],  
	               [CLM_ADJ_AMT141] ,  
	               [CLM_ADJ_QTY141] ,  
	               [CLM_ADJ_REASON142] ,  
	               [CLM_ADJ_AMT142] ,  
	               [CLM_ADJ_QTY142] ,  
	               [CLM_ADJ_REASON143] ,  
	               [CLM_ADJ_AMT143] ,  
	               [CLM_ADJ_QTY143] ,  
	               [CLM_ADJ_REASON144] ,  
	               [CLM_ADJ_AMT144] ,  
	               [CLM_ADJ_QTY144] ,  
	               [CLM_ADJ_REASON145] ,  
	               [CLM_ADJ_AMT145] ,  
	               [CLM_ADJ_QTY145] ,  
	               [CLM_ADJ_REASON146] ,  
	               [CLM_ADJ_AMT146] ,  
	               [CLM_ADJ_QTY146] ,  
	               [CLM_ADJ_GRP15] ,  
	               [CLM_ADJ_REASON151] ,  
	               [CLM_ADJ_AMT151] ,  
	               [CLM_ADJ_QTY151] ,  
	               [CLM_ADJ_REASON152] ,  
	               [CLM_ADJ_AMT152] ,  
	               [CLM_ADJ_QTY152] ,  
	               [CLM_ADJ_REASON153] ,  
	               [CLM_ADJ_AMT153] ,  
	               [CLM_ADJ_QTY153] ,  
	               [CLM_ADJ_REASON154] ,  
	               [CLM_ADJ_AMT154] ,  
	               [CLM_ADJ_QTY154] ,  
	               [CLM_ADJ_REASON155] ,  
	               [CLM_ADJ_AMT155] ,  
	               [CLM_ADJ_QTY155] ,  
	               [CLM_ADJ_REASON156],  
	               [CLM_ADJ_AMT156] ,  
	               [CLM_ADJ_QTY156] ,  
	               [OTH_PAYER1_ADJ_DT] ,  
	               [OPT_REPT_IND1] ,  
	               [OPT_REPT_IND2] ,  
	               [OPT_REPT_IND3] ,  
	               [EPSDT_IND] ,							  
	               [FAM_PLAN_IND] ,  
	               [OBSTET_ANES_UNITS] ,  
	               [OTH_PAYER1_PROC_CD_QUAL] ,   
	               [OTH_PAYER2_PROC_CD_QUAL] ,   
	               [SOURCEDATAKEY]   
                 )  
				SELECT   
				   [RECORD_TYPE] ,  
	               [CLAIM_ID] ,  
	               [CLAIM_LINE_NO],  
	               [SERV_START_DT] ,  
	               [SERV_END_DT] ,  
	               [REV_CD1] ,  
	               [REV_CD2] ,  
	               [REV_CD3] ,  
	               [SERV_ID_QUAL],  
	               [PROC_CD] ,  
	               [PROC_MOD1] ,  
	               [PROC_MOD2] ,  
	               [PROC_MOD3] ,  
	               [PROC_MOD4] ,  
	               [PROC_DESC] ,  
	               [TOTAL_CHRG_AMT] ,  
	               [NON_COV_AMT] ,  
	               [QTY_DAYS] ,  
	               [QTY_UNITS] ,  
	               [LINE_CNTRL_NO] ,  
	               [GS_TAX_AMT] ,  
	               [FAC_TAX_AMT] ,  
 	               [INST_PRINCIPAL_PROC_TYPE_IND] ,  
	               [OTH_PAYER1_PRIMEID] ,  
	               [OTH_PAYER1_PAID_AMT] ,  
	               [OTH_PAYER1_PROC_CD] ,  
	               [OTH_PAYER1_PAID_QTY] ,  
	               [OTH_PAYER1_ADJ_BUNDLE] ,  
	               [CLM_ADJ_GRP111] ,  
	               [CLM_ADJ_REASON111] ,  
	               [CLM_ADJ_AMT111] ,  
	               [CLM_ADJ_QTY111] ,  
	               [CLM_ADJ_REASON112] ,  
	               [CLM_ADJ_AMT112] ,  
	               [CLM_ADJ_QTY112] ,  
	               [CLM_ADJ_REASON113] ,  
	               [CLM_ADJ_AMT113] ,  
	               [CLM_ADJ_QTY113] ,  
	               [CLM_ADJ_REASON114] ,  
	               [CLM_ADJ_AMT114] ,  
	               [CLM_ADJ_QTY114] ,  
	               [CLM_ADJ_REASON115] ,  
	               [CLM_ADJ_AMT115] ,  
	               [CLM_ADJ_QTY115] ,  
	               [CLM_ADJ_REASON116] ,  
	               [CLM_ADJ_AMT116],  
	               [CLM_ADJ_QTY116],  
	               [CLM_ADJ_GRP12] ,  
	               [CLM_ADJ_REASON121],  
	               [CLM_ADJ_AMT121] ,  
	               [CLM_ADJ_QTY121] ,  
	               [CLM_ADJ_REASON122] ,  
	               [CLM_ADJ_AMT122] ,  
	               [CLM_ADJ_QTY122],  
	               [CLM_ADJ_REASON123] ,  
	               [CLM_ADJ_AMT123] ,  
	               [CLM_ADJ_QTY123] ,  
	               [CLM_ADJ_REASON124] ,  
	               [CLM_ADJ_AMT124] ,  
	               [CLM_ADJ_QTY124] ,  
	               [CLM_ADJ_REASON125],  
	               [CLM_ADJ_AMT125] ,  
	               [CLM_ADJ_QTY125] ,  
	               [CLM_ADJ_REASON126],  
	               [CLM_ADJ_AMT126] ,  
	               [CLM_ADJ_QTY126] ,  
	               [CLM_ADJ_GRP13] ,  
	               [CLM_ADJ_REASON131] ,  
	               [CLM_ADJ_AMT131] ,  
	               [CLM_ADJ_QTY131] ,  
	               [CLM_ADJ_REASON132] ,  
	               [CLM_ADJ_AMT132] ,  
	               [CLM_ADJ_QTY132] ,  
	               [CLM_ADJ_REASON133] ,  
	               [CLM_ADJ_AMT133] ,  
	               [CLM_ADJ_QTY133] ,  
	               [CLM_ADJ_REASON134] ,  
	               [CLM_ADJ_AMT134] ,  
	               [CLM_ADJ_QTY134] ,  
	               [CLM_ADJ_REASON135] ,  
	               [CLM_ADJ_AMT135] ,  
	               [CLM_ADJ_QTY135] ,  
	               [CLM_ADJ_REASON136] ,  
	               [CLM_ADJ_AMT136] ,  
	               [CLM_ADJ_QTY136] ,  
	               [CLM_ADJ_GRP14]  ,  
  	               [CLM_ADJ_REASON141],  
	               [CLM_ADJ_AMT141] ,  
	               [CLM_ADJ_QTY141] ,  
	               [CLM_ADJ_REASON142] ,  
	               [CLM_ADJ_AMT142] ,  
	               [CLM_ADJ_QTY142] ,  
	               [CLM_ADJ_REASON143] ,  
	               [CLM_ADJ_AMT143] ,  
	               [CLM_ADJ_QTY143] ,  
	               [CLM_ADJ_REASON144] ,  
	               [CLM_ADJ_AMT144] ,  
	               [CLM_ADJ_QTY144] ,  
	               [CLM_ADJ_REASON145] ,  
	               [CLM_ADJ_AMT145] ,  
	               [CLM_ADJ_QTY145] ,  
	               [CLM_ADJ_REASON146] ,  
	               [CLM_ADJ_AMT146] ,  
	               [CLM_ADJ_QTY146] ,  
	               [CLM_ADJ_GRP15] ,  
	               [CLM_ADJ_REASON151] ,  
	               [CLM_ADJ_AMT151] ,  
	               [CLM_ADJ_QTY151] ,  
	               [CLM_ADJ_REASON152] ,  
	               [CLM_ADJ_AMT152] ,  
	               [CLM_ADJ_QTY152] ,  
	               [CLM_ADJ_REASON153] ,  
	               [CLM_ADJ_AMT153] ,  
	               [CLM_ADJ_QTY153] ,  
	               [CLM_ADJ_REASON154] ,  
	               [CLM_ADJ_AMT154] ,  
	               [CLM_ADJ_QTY154] ,  
	               [CLM_ADJ_REASON155] ,  
	               [CLM_ADJ_AMT155] ,  
	               [CLM_ADJ_QTY155] ,  
	               [CLM_ADJ_REASON156],  
	               [CLM_ADJ_AMT156] ,  
	               [CLM_ADJ_QTY156] ,  
	               [OTH_PAYER1_ADJ_DT] ,  
	               [OPT_REPT_IND1] ,  
	               [OPT_REPT_IND2] ,  
	               [OPT_REPT_IND3] ,  
	               [EPSDT_IND] ,							  
	               [FAM_PLAN_IND] ,  
	               [OBSTET_ANES_UNITS] ,  
	               [OTH_PAYER1_PROC_CD_QUAL] ,   
	               [OTH_PAYER2_PROC_CD_QUAL] ,   
	               [SOURCEDATAKEY]   
				FROM #OUTB_INST_DETAIL D  
				WHERE SERV_START_DT IN (SELECT MAX(SERV_START_DT)  
				                        FROM #OUTB_INST_DETAIL C  
										WHERE LTRIM(RTRIM(REV_CD1)) = '0023'  
										 AND D.CLAIM_ID = C.CLAIM_ID  
										)  
				AND REV_CD1 = '0023'  
  
				-------------------------------------------------  
				-- REMOVE ALL OO23 FROM #OUTB FILE  
				-------------------------------------------------  
				DELETE #OUTB_INST_DETAIL  
				WHERE LTRIM(RTRIM(REV_CD1)) = '0023'  
				  
				DELETE #OUTB_INST_DETAIL  
				WHERE LTRIM(RTRIM(REV_CD2)) = '0023'  
				  
				DELETE #OUTB_INST_DETAIL  
				WHERE LTRIM(RTRIM(REV_CD3)) = '0023'  
				  
				--------------------------------------------  
				-- INSERT FROM #0023 INTO #OUTB_INST_DETAIL  
				-- MAX ROW NUMBER - ONLY 1 VALUE FOR 0023  
				--------------------------------------------  
				INSERT INTO #OUTB_INST_DETAIL  
				        ( RECORD_TYPE ,  
				          CLAIM_ID ,  
				          CLAIM_LINE_NO ,  
				          SERV_START_DT ,  
				          SERV_END_DT ,  
				          REV_CD1 ,  
				          REV_CD2 ,  
				          REV_CD3 ,  
				          SERV_ID_QUAL ,  
				          PROC_CD ,  
				          PROC_MOD1 ,  
				          PROC_MOD2 ,  
				          PROC_MOD3 ,  
				          PROC_MOD4 ,  
				          PROC_DESC ,  
				          TOTAL_CHRG_AMT ,  
				          NON_COV_AMT ,  
				          QTY_DAYS ,  
				          QTY_UNITS ,  
				          LINE_CNTRL_NO ,  
				          GS_TAX_AMT ,  
				          FAC_TAX_AMT ,  
				          INST_PRINCIPAL_PROC_TYPE_IND ,  
				          OTH_PAYER1_PRIMEID ,  
				          OTH_PAYER1_PAID_AMT ,  
				          OTH_PAYER1_PROC_CD ,  
				          OTH_PAYER1_PAID_QTY ,  
				          OTH_PAYER1_ADJ_BUNDLE ,  
				          CLM_ADJ_GRP111 ,  
				          CLM_ADJ_REASON111 ,  
				          CLM_ADJ_AMT111 ,  
				          CLM_ADJ_QTY111 ,  
				          CLM_ADJ_REASON112 ,  
				          CLM_ADJ_AMT112 ,  
				          CLM_ADJ_QTY112 ,  
				          CLM_ADJ_REASON113 ,  
				          CLM_ADJ_AMT113 ,  
				          CLM_ADJ_QTY113 ,  
				          CLM_ADJ_REASON114 ,  
				          CLM_ADJ_AMT114 ,  
				          CLM_ADJ_QTY114 ,  
				          CLM_ADJ_REASON115 ,  
				          CLM_ADJ_AMT115 ,  
				          CLM_ADJ_QTY115 ,  
				          CLM_ADJ_REASON116 ,  
				          CLM_ADJ_AMT116 ,  
				          CLM_ADJ_QTY116 ,  
				          CLM_ADJ_GRP12 ,  
				          CLM_ADJ_REASON121 ,  
				          CLM_ADJ_AMT121 ,  
				          CLM_ADJ_QTY121 ,  
				          CLM_ADJ_REASON122 ,  
				          CLM_ADJ_AMT122 ,  
				          CLM_ADJ_QTY122 ,  
				          CLM_ADJ_REASON123 ,  
				          CLM_ADJ_AMT123 ,  
				          CLM_ADJ_QTY123 ,  
				          CLM_ADJ_REASON124 ,  
				          CLM_ADJ_AMT124 ,  
				          CLM_ADJ_QTY124 ,  
				          CLM_ADJ_REASON125 ,  
				          CLM_ADJ_AMT125 ,  
				          CLM_ADJ_QTY125 ,  
				          CLM_ADJ_REASON126 ,  
				          CLM_ADJ_AMT126 ,  
				          CLM_ADJ_QTY126 ,  
				          CLM_ADJ_GRP13 ,  
				          CLM_ADJ_REASON131 ,  
				          CLM_ADJ_AMT131 ,  
				          CLM_ADJ_QTY131 ,  
				          CLM_ADJ_REASON132 ,  
				          CLM_ADJ_AMT132 ,  
				          CLM_ADJ_QTY132 ,  
				          CLM_ADJ_REASON133 ,  
				          CLM_ADJ_AMT133 ,  
				          CLM_ADJ_QTY133 ,  
				          CLM_ADJ_REASON134 ,  
				          CLM_ADJ_AMT134 ,  
				          CLM_ADJ_QTY134 ,  
				          CLM_ADJ_REASON135 ,  
				          CLM_ADJ_AMT135 ,  
				          CLM_ADJ_QTY135 ,  
				          CLM_ADJ_REASON136 ,  
				          CLM_ADJ_AMT136 ,  
				          CLM_ADJ_QTY136 ,  
				          CLM_ADJ_GRP14 ,  
				          CLM_ADJ_REASON141 ,  
				          CLM_ADJ_AMT141 ,  
				          CLM_ADJ_QTY141 ,  
				          CLM_ADJ_REASON142 ,  
				          CLM_ADJ_AMT142 ,  
				          CLM_ADJ_QTY142 ,  
				          CLM_ADJ_REASON143 ,  
				          CLM_ADJ_AMT143 ,  
				          CLM_ADJ_QTY143 ,  
				          CLM_ADJ_REASON144 ,  
				          CLM_ADJ_AMT144 ,  
				          CLM_ADJ_QTY144 ,  
				          CLM_ADJ_REASON145 ,  
				          CLM_ADJ_AMT145 ,  
				          CLM_ADJ_QTY145 ,  
				          CLM_ADJ_REASON146 ,  
				          CLM_ADJ_AMT146 ,  
				          CLM_ADJ_QTY146 ,  
				          CLM_ADJ_GRP15 ,  
				          CLM_ADJ_REASON151 ,  
				          CLM_ADJ_AMT151 ,  
				          CLM_ADJ_QTY151 ,  
				          CLM_ADJ_REASON152 ,  
				          CLM_ADJ_AMT152 ,  
				          CLM_ADJ_QTY152 ,  
				          CLM_ADJ_REASON153 ,  
				          CLM_ADJ_AMT153 ,  
				          CLM_ADJ_QTY153 ,  
				          CLM_ADJ_REASON154 ,  
				          CLM_ADJ_AMT154 ,  
				          CLM_ADJ_QTY154 ,  
				          CLM_ADJ_REASON155 ,  
				          CLM_ADJ_AMT155 ,  
				          CLM_ADJ_QTY155 ,  
				          CLM_ADJ_REASON156 ,  
				          CLM_ADJ_AMT156 ,  
				          CLM_ADJ_QTY156 ,  
				          OTH_PAYER1_ADJ_DT ,  
				          OPT_REPT_IND1 ,  
				          OPT_REPT_IND2 ,  
				          OPT_REPT_IND3 ,  
				          EPSDT_IND ,  
				          FAM_PLAN_IND ,  
				          OBSTET_ANES_UNITS ,  
				          OTH_PAYER1_PROC_CD_QUAL ,  
				          OTH_PAYER2_PROC_CD_QUAL ,  
				          SOURCEDATAKEY  
				        )  
				SELECT DISTINCT  
				          I.RECORD_TYPE ,  
				          I.CLAIM_ID ,  
				          I.CLAIM_LINE_NO ,  
				          I.SERV_START_DT ,  
				          SERV_END_DT ,  
				          REV_CD1 ,  
				          REV_CD2 ,  
				          REV_CD3 ,  
				          SERV_ID_QUAL ,  
				          I.PROC_CD ,  
				          PROC_MOD1 ,  
				          PROC_MOD2 ,  
				          PROC_MOD3 ,  
				          PROC_MOD4 ,  
				          PROC_DESC ,  
				          TOTAL_CHRG_AMT ,  
				          NON_COV_AMT ,  
				          QTY_DAYS ,  
				          QTY_UNITS ,  
				          I.LINE_CNTRL_NO ,  
				          GS_TAX_AMT ,  
				          FAC_TAX_AMT ,  
				          INST_PRINCIPAL_PROC_TYPE_IND ,  
				          OTH_PAYER1_PRIMEID ,  
				          OTH_PAYER1_PAID_AMT ,  
				          OTH_PAYER1_PROC_CD ,  
				          OTH_PAYER1_PAID_QTY ,  
				          OTH_PAYER1_ADJ_BUNDLE ,  
				          CLM_ADJ_GRP111 ,  
				          CLM_ADJ_REASON111 ,  
				          CLM_ADJ_AMT111 ,  
				          CLM_ADJ_QTY111 ,  
				          CLM_ADJ_REASON112 ,  
				          CLM_ADJ_AMT112 ,  
				          CLM_ADJ_QTY112 ,  
				          CLM_ADJ_REASON113 ,  
				          CLM_ADJ_AMT113 ,  
				          CLM_ADJ_QTY113 ,  
				          CLM_ADJ_REASON114 ,  
				          CLM_ADJ_AMT114 ,  
				          CLM_ADJ_QTY114 ,  
				          CLM_ADJ_REASON115 ,  
				          CLM_ADJ_AMT115 ,  
				          CLM_ADJ_QTY115 ,  
				          CLM_ADJ_REASON116 ,  
				          CLM_ADJ_AMT116 ,  
				          CLM_ADJ_QTY116 ,  
				          CLM_ADJ_GRP12 ,  
				          CLM_ADJ_REASON121 ,  
				          CLM_ADJ_AMT121 ,  
				          CLM_ADJ_QTY121 ,  
				          CLM_ADJ_REASON122 ,  
				          CLM_ADJ_AMT122 ,  
				          CLM_ADJ_QTY122 ,  
				          CLM_ADJ_REASON123 ,  
				          CLM_ADJ_AMT123 ,  
				          CLM_ADJ_QTY123 ,  
				          CLM_ADJ_REASON124 ,  
				          CLM_ADJ_AMT124 ,  
				          CLM_ADJ_QTY124 ,  
				          CLM_ADJ_REASON125 ,  
				          CLM_ADJ_AMT125 ,  
				          CLM_ADJ_QTY125 ,  
				          CLM_ADJ_REASON126 ,  
				          CLM_ADJ_AMT126 ,  
				          CLM_ADJ_QTY126 ,  
				          CLM_ADJ_GRP13 ,  
				          CLM_ADJ_REASON131 ,  
				          CLM_ADJ_AMT131 ,  
				          CLM_ADJ_QTY131 ,  
				          CLM_ADJ_REASON132 ,  
				          CLM_ADJ_AMT132 ,  
				          CLM_ADJ_QTY132 ,  
				          CLM_ADJ_REASON133 ,  
				          CLM_ADJ_AMT133 ,  
				          CLM_ADJ_QTY133 ,  
				          CLM_ADJ_REASON134 ,  
				          CLM_ADJ_AMT134 ,  
				          CLM_ADJ_QTY134 ,  
				          CLM_ADJ_REASON135 ,  
				          CLM_ADJ_AMT135 ,  
				          CLM_ADJ_QTY135 ,  
				          CLM_ADJ_REASON136 ,  
				          CLM_ADJ_AMT136 ,  
				          CLM_ADJ_QTY136 ,  
				          CLM_ADJ_GRP14 ,  
				          CLM_ADJ_REASON141 ,  
				          CLM_ADJ_AMT141 ,  
				          CLM_ADJ_QTY141 ,  
				          CLM_ADJ_REASON142 ,  
				          CLM_ADJ_AMT142 ,  
				          CLM_ADJ_QTY142 ,  
				          CLM_ADJ_REASON143 ,  
				          CLM_ADJ_AMT143 ,  
				          CLM_ADJ_QTY143 ,  
				          CLM_ADJ_REASON144 ,  
				          CLM_ADJ_AMT144 ,  
				          CLM_ADJ_QTY144 ,  
				          CLM_ADJ_REASON145 ,  
				          CLM_ADJ_AMT145 ,  
				          CLM_ADJ_QTY145 ,  
				          CLM_ADJ_REASON146 ,  
				          CLM_ADJ_AMT146 ,  
				          CLM_ADJ_QTY146 ,  
				          CLM_ADJ_GRP15 ,  
				          CLM_ADJ_REASON151 ,  
				          CLM_ADJ_AMT151 ,  
				          CLM_ADJ_QTY151 ,  
				          CLM_ADJ_REASON152 ,  
				          CLM_ADJ_AMT152 ,  
				          CLM_ADJ_QTY152 ,  
				          CLM_ADJ_REASON153 ,  
				          CLM_ADJ_AMT153 ,  
				          CLM_ADJ_QTY153 ,  
				          CLM_ADJ_REASON154 ,  
				          CLM_ADJ_AMT154 ,  
				          CLM_ADJ_QTY154 ,  
				          CLM_ADJ_REASON155 ,  
				          CLM_ADJ_AMT155 ,  
				          CLM_ADJ_QTY155 ,  
				          CLM_ADJ_REASON156 ,  
				          CLM_ADJ_AMT156 ,  
				          CLM_ADJ_QTY156 ,  
				          OTH_PAYER1_ADJ_DT ,  
				          OPT_REPT_IND1 ,  
				          OPT_REPT_IND2 ,  
				          OPT_REPT_IND3 ,  
				          EPSDT_IND ,  
				          FAM_PLAN_IND ,  
				          OBSTET_ANES_UNITS ,  
				          OTH_PAYER1_PROC_CD_QUAL ,  
				          OTH_PAYER2_PROC_CD_QUAL ,  
				          SOURCEDATAKEY  
                   FROM #OUTB_INST_DETAIL_0023 I  
                   INNER Join (SELECT CLAIM_ID,   
				              MAX(CLAIM_LINE_NO) AS MAXCLAIM_LINE_NO  
				              FROM #OUTB_INST_DETAIL_0023   
							  GROUP BY CLAIM_ID) L  
              	   on I.CLAIM_ID = L.CLAIM_ID  
				   AND I.CLAIM_LINE_NO = L.MAXCLAIM_LINE_NO  
										   			     
               --------------------------------------------------  
               --TETDM 1582 END jab  
			   --------------------------------------------------  
  
  
				---10/26/16 - TETDM-1022 Remove Multiple instances of REV_CD 0023  
  
				update #OUTB_INST_DETAIL  
				SET REV_CD2 = ' '  
				WHERE LTRIM(RTRIM(REV_CD2)) = '0023'  
					AND LTRIM(RTRIM(REV_CD1)) = '0023'  
  
				update #OUTB_INST_DETAIL  
				SET REV_CD3 = ' '  
				WHERE LTRIM(RTRIM(REV_CD3)) = '0023'  
					AND LTRIM(RTRIM(REV_CD1)) = '0023'  
  
                DELETE #OUTB_INST_DETAIL  
				WHERE REV_CD1 = ' '  
  
				----TETDM 1022 -Revision - When RevCd 0023 present only ClaimLineNo = 1 Rev_cd1 value should be 0023  
  
				  
			--	update #OUTB_INST_DETAIL  
			--	SET REV_CD1 = ' '  
			--	WHERE REV_CD1 = '0023'   
			--		AND convert(int, claim_line_no) <> 1  
			  
			    
			-- Note  
			---2014-03-02		Loyal Ricks		OPT_REPT_IND1 Set value = 'I' WHERE PROC_CD IN  ('0L6','$INT')  
			  
				UPDATE #OUTB_INST_DETAIL  
				SET OPT_REPT_IND1 = 'I'  
				WHERE PROC_CD IN  ('0L6','$INT')  
				  
			  
			  
			  
			update #OUTB_INST_DETAIL  
			set PROC_CD = ' ',  
				OTH_PAYER1_PROC_CD = ' '  
			where PROC_CD = 'UNKNO'  
			  
			--  
			-- Note  
			--2014-02-21 - Value will be defaulted until HPPS and other requirements are identified. Use of default   
						 -- is expected to reject when submitted to Verisk.  
			  
			---HPPS CODE SERV_ID_QUAL & OTH_PAYER_PROC_CD_QUAL UPDATE  
			  
				update #OUTB_INST_DETAIL  
				set SERV_ID_QUAL = 'HP'  
					,OTH_PAYER1_PROC_CD_QUAL = 'HP'  
				from #OUTB_INST_DETAIL id  
				join EXT_HIPPS_CD eh  
				on RTRIM(id.PROC_CD) = RTRIM(eh.HIPPS_CD)  
			  
			--TETDM-896  
				IF OBJECT_ID('TEMPDB..#PAID_AMT') <> 0  
				DROP TABLE #PAID_AMT  
				  
				CREATE TABLE #PAID_AMT(  
				CLAIMID VARCHAR(20),  
				CLAIMLINEID VARCHAR(5),  
				PAYMENTAMOUNT MONEY,  
				WITHHOLDAMT MONEY,  
				OTH_PAYER1_PAID_AMT CHAR(18)  
				)  
  
				INSERT INTO #PAID_AMT   
				SELECT CD.CLAIMID,  
						CD.CLAIMLINEID,  
						CD.PAYMENTAMOUNT,  
						CD.WITHHOLDAMT,  
						LTRIM(SUM(CD. PaymentAmount - CD.WITHHOLDAMT))  
				FROM EDPS_DATA.DBO.CLAIMDETAILDIM CD   
				INNER JOIN #OUTB_INST_DETAIL OD  
				ON OD.SOURCEDATAKEY = CD.SOURCEDATAKEY   
				AND OD.CLAIM_ID = CD.CLAIMID  
				AND OD.CLAIM_LINE_NO = CD.CLAIMLINEID  
				WHERE OD.SOURCEDATAKEY = 30   
					AND CD.WITHHOLDAMT > 0  
				GROUP BY CD.CLAIMID,  
						CD.CLAIMLINEID,  
						CD.PAYMENTAMOUNT,  
						CD.WITHHOLDAMT  
				ORDER BY CD.CLAIMID,  
						CD.CLAIMLINEID  
  
				update #OUTB_INST_DETAIL   
				SET OTH_PAYER1_PAID_AMT = CD.OTH_PAYER1_PAID_AMT--OTH_PAYER1_PAID_AMT  
				FROM #OUTB_INST_DETAIL OD  
				INNER JOIN  #PAID_AMT CD  
				ON OD.CLAIM_ID = CD.CLAIMID  
				AND OD.CLAIM_LINE_NO = CD.CLAIMLINEID  
				  
				--TETDM-922  
				Update #OUTB_INST_DETAIL   
				SET SERV_ID_QUAL = 'HP'  
					,OTH_PAYER1_PROC_CD_QUAL = 'HP'  
				FROM #OUTB_INST_DETAIL ID  
				INNER JOIN EDPS_DATA.DBO.PROCEDURECODEDIM P  
				ON ID.SOURCEDATAKEY = P.SOURCEDATAKEY   
				AND ID.PROC_CD = P.PROCEDURECODE   
				WHERE proceduretypecode = 'O'  
				  
--jira 1522				  
				  
				-------------------------------------------  
				--TETDM-1616  
				-------------------------------------------  
				update D   
		        SET PROC_DESC = SUBSTRING(PM.PROCEDUREDESC,1,80)  
		        FROM #OUTB_INST_DETAIL D  
		        INNER JOIN edps_data.dbo.PROCEDURECODEDIM PM   
		           ON D.SOURCEDATAKEY = PM.SOURCEDATAKEY   
		          AND D.PROC_CD = PM.procedurecode  
				  AND PM.ACTIVE = '1'
				  
								  
				UPDATE a  
				SET OTH_PAYER1_PAID_QTY = 1  
				   ,QTY_UNITS = 1  
				--SELECT top 10 REV_CD1,quantity, OTH_PAYER1_PAID_QTY AS [other payer 1 paid Quantity], QTY_UNITS AS [Line Quantity Units],*   
				    FROM #OUTB_INST_DETAIL a   
				    JOIN edps_data.dbo.claimdetaildim b   
				          ON LTRIM(RTRIM(a.CLAIM_ID)) = LTRIM(RTRIM(b.CLAIMID))  
				--WHERE REV_CD1 IN (0022,0023,0024)  
				--AND b.Quantity = 0  	  
				WHERE b.Quantity = 0		---> TETDM-1653 remove REC_CD1 limitation	  
		  
		-- APPEND  OUTB_INST_DETAIL  
		  
			INSERT INTO  OUTB_INST_DETAIL  
			SELECT *  
			FROM  #OUTB_INST_DETAIL  
  
--UPDATE a  
--SET OTH_PAYER1_PAID_QTY = 1  
--   ,QTY_UNITS = 1  
----SELECT top 10 REV_CD1,quantity, OTH_PAYER1_PAID_QTY AS [other payer 1 paid Quantity], QTY_UNITS AS [Line Quantity Units],*   
--    FROM WIPRO..OUTB_INST_DETAIL a   
--    JOIN edps_data.dbo.claimdetaildim b   
--          ON LTRIM(RTRIM(a.CLAIM_ID)) = LTRIM(RTRIM(b.CLAIMID))  
--WHERE REV_CD1 IN (0022,0023,0024)  
--AND b.Quantity = 0    
  
  
  
				  
		--temporarily use min(begin_serv_dt) as BEGIN_STATEMENT_DT and max(end_serv_dt) as END_STATMENT_DT  
		--	IF OBJECT_ID('TEMPDB..#tmp_statement_dts') <> 0  
		--		DROP TABLE #tmp_statement_dts  
				  
		--		select claim_id,MIN(serv_start_dt) as 'begin_statement_dt', MAX(serv_end_dt) as 'end_statement_dt'  
		--		into #tmp_statement_dts  
		--		from OUTB_INST_DETAIL  
		--		group by claim_id  
		--		order by claim_id  
				  
		--		begin transaction  
		--		UPDATE OUTB_INST_HEADER  
		--		SET STATE_BEGIN_DT = T.BEGIN_STATEMENT_DT  
		--			,STATE_END_DT = T.END_STATEMENT_DT  
		--		FROM OUTB_INST_HEADER E  
		--		JOIN #tmp_statement_dts T  
		--		ON E.CLAIM_ID = T.CLAIM_ID  
		--					if @@ERROR <> 0  
		--	begin  
		--		rollback   
		--	end  
		--commit  
				  
		  
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_INST_HEADER_RESEND  
							   
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_DETAIL)  
									  
		----HRP_CLAIM_FILE Update Run Controls  
				BEGIN TRANSACTION  
						UPDATE EXT_SYS_RUNLOG  
						SET END_DT = GETDATE()	  
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
							,TOTAL_RECORDS = @TOTAL_RECORDS  
							,ENTRYDT = GETDATE()  
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_CLMDETAIL'  
							AND END_DT IS NULL  
							IF @@ERROR <> 0  
										BEGIN   
												ROLLBACK   
										END  
						COMMIT