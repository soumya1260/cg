﻿
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_ENCOUNTER_FILE]
(--@runcode varchar(5)= '*' --DEFAULT VALUE -- PASS WHEN ALL FILES ARE DESIRED, VALID VALUES ('*' - GENERATE ALL FILES (CLAIM, CLAIM DME/HHC), 'D' - (DME/HHC ONLY CLAIMS) )
--@BEGIN_DOS CHAR(8) 
--,@END_DOS CHAR(8) 
@LOB CHAR(10)  --Valid Values (MMAI,MOA)
,@LOBCODE			VARCHAR(15) = ' '
,@JOBID INT = 1	
,@SOURCEDESC VARCHAR(60)
--,@SOURCE_ENVIRONMENT VARCHAR(10) 
,@exclusionmode CHAR(1) ='R'	-- TETDM-1760 changed default value from M to R as it was ddoing the wrong type of Exclusion Build
)
AS
/**********************************************************************************************************************************
** CREATE DATE: 09/2016
**
** AUTHOR: LOYAL RICKS 
**
** DESCRIPTION: PROCEDURE WILL EXECUTE REQUIRD STEPS FOR COMPILING HRP MHC CLAIM SUBMISSIONS.
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
10/28/12		LOYAL RICKS		REMOVED EXSP_HRP_CLAIM_RESEND procedure call, replaed with 
								EXSP_HRP_CLAIM_EXCLUSION procedure call
02/18/13		LOYAL RICKS		ADD DEFAULT PROCESSING USING PLACEOFSERVICECODE INSTEAD OF CLAIM_TYPE
								FOR SeniorCarePartners,Swedish,MED3000,MedSolutions.		
								ADD EXSP_HRP_CLAIM_PROF_ENCOUNTER_CLMDETAIL INPUT PARMS: @SOURCEDESC,@SOURCE_ENVIRONMENT
02/27/13		LOYAL RICKS 	Medsolutions claim_type is null in the 2/26 ODS-UAT Encounter refresh. Switch to use POS_CD to determine claim_type					
03/06/2013		LOYAL RICKS		ADD CATCHALL REQUIRED TABLE TO PROCESS - EXECUTE EXSP_HRP_CLAIM_REQ5010
06/12/2013		LOYAL RICKS     ADD EDI PROF 5010 TABLE TO PROCESS - EXECUTE EXSP_HRP_CLAIM_ENCEDI_PROF_5010 @SOURCEDESC
01/09/2014		Loyal Ricks		Remove Med3000 from using POS_CD xwalk. Med3000 now utilizing encounterclaimdim.claim_type
07/15/2016		Loyal Ricks		Remove input parameters @SOURCE_ENVIRONMENT
								job will utilize exclusion build "DP" logic for selection of valid claims. All PROD
								only claims will be selected. Functionality to select UAT claims removed, no longer 
								needed.		
08/25/16		Loyal Ricks		Replace --EXECUTE pr_BUILD_OUTB_PROF_ENCOUNTER_PROVIDER @SOURCEDESC with 
								EXECUTE pr_BUILD_OUTB_PROF_ENCOUNTER_HISTORICAL_CLAIM @SOURCEDESC
03/20/2018		Scott Waller	TETDM-1760 The code that collects claims is getting multiple records for the same claimid/sourcedesc/lob/hicfa
								So even though it gets 50000, there is only a small number of distinct claims (like hundreds to low thousands)
11/13/2018		Anthony Ulmer	TETDM-1889 removed [pr_BUILD_OUTB_INST_ENCOUNTER_ADJUSTMENTS_ADJ] execution (changes moved to detail procedure)
01/15/2020      Aaron Ridley    TETDM-2155 Commented out the condition code responsible for exec the Exclusion sproc. 
**********************************************************************************************************************************/	
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT
			,@SOURCEDATAKEY INT
			
			SET @SOURCEDATAKEY = '4'; --ENCOUNTER

--Purge logs for all job completed 31 days or more days ago
		 
				
				
--HRP_CLAIM_FILE Run controls
			
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_BUILD_OUTB_INST_ENCOUNTER_FILE'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					
			
			 
			--IF @JOBID NOT IN (5001,5002) BEGIN  --skip exclusions if resub job (Commented out TEDM-2215)
   --         	EXECUTE EXSP_WIPRO_CLAIM_EXCLUSION @SOURCEDATAKEY ,@exclusionmode
   --         END
			EXECUTE EXSP_WIPRO_CLAIM_EXCLUSION @SOURCEDATAKEY ,@exclusionmode
			EXECUTE pr_BUILD_OUTB_INST_ENCOUNTER_CLAIM_HEADER @SOURCEDATAKEY,@SOURCEDESC ,@LOB ,@LOBCODE,@JOBID---/*@BEGIN_DOS,@END_DOS,*/ @SOURCEDESC--,@SOURCE_ENVIRONMENT
			EXECUTE pr_BUILD_OUTB_INST_ENCOUNTER_DETAIL  @SOURCEDESC--,@SOURCE_ENVIRONMENT
			EXECUTE BUILD_OUTB_INST_ENCOUNTER_DIAG @SOURCEDATAKEY
			EXECUTE pr_BUILD_OUTB_INST_ENCOUNTER_HISTORICAL_CLAIM @SOURCEDESC
			EXECUTE pr_BUILD_OUTB_INST_ENCOUNTER_HISTORICAL_CLAIM_COND_OCCCD @SOURCEDESC--,@SOURCE_ENVIRONMENT
			--EXECUTE pr_BUILD_OUTB_INST_ENCOUNTER_ADJUSTMENTS_ADJ @SOURCEDESC
			--EXECUTE pr_BUILD_OUTB_INST_ENCOUNTER_ADJUSTMENTS_SIMCONFIG @SOURCEDESC
			--EXECUTE BUILD_OUTB_CLAIM_REQ5010
			EXECUTE pr_BUILD_OUTB_INST_WIPRO_DATASCRUB
			EXECUTE pr_BUILD_OUTB_INST_ENCOUNTER_MAP @LOB,@LOBCODE,@JOBID,@SOURCEDESC
			
		---- Update Run Controls
				
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = 0
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_ENCOUNTER_FILE'
									and END_DT is null

