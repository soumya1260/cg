﻿CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_PROF_ENCOUNTER_CLM_HEADER] 
(@SOURCEDESC VARCHAR(50),@LOB CHAR(10),@LOBCODE VARCHAR(15) = ' ',@JOBID INT) 
---@BEGIN_DOS CHAR(8), @END_DOS CHAR(8),@SOURCEDESC VARCHAR(50),@SOURCE_ENVIRONMENT VARCHAR(10) ) 
AS 
/*************************************************************************************************** 
** CREATE DATE: 1/2013 
** 
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM 
** 
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM INFORMATION  
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE   
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES.  
** 
** 
Modification History 
==================== 
Date			Who				Description 
----------------------------------------------------------------------------------------------------- 
01/08/13	LOYAL RICKS			REMOVE @BEGIN_DOS & @END_DOS DEFAULT ASSIGNMENT 
								REPLACED DEFAULT ASSIGNMENT TO PROCEDURE INPUT PARAMETER FOR TESTING 
01/09/13	LOYAL RICKS			MAP REVIEW ADDED INSURANCE TYPE, POA_IND DEFAULT 'N', ADMISSION,	 
								SERVICE DATE AND OTHER MAPPING/VALUES 
2013-03-06		Loyal Ricks		Remove DOS claim selection criteria	 
06/04/2013	Loyal Ricks			Remove MEMBER_AMT_PAID amount from populating. Do not submit 
								causes rej_rea_id 103 due to trigger of HRP member COB edits 
06/13/2013  	Loyal Ricks		Remap default code for OTH_INSR_TYPECD1 to CLM_FIL_INDCD1  
								Due to CMS 999 rejection issue. 		 
------------------------------------------------------------------------------------------------------ 
11/02/2015		Loyal Ricks		WIPRO Revisions 
02/03/2016		Loyal Ricks		Add logic for identifying Member HPLAN when HPLAN is unknown. Existing 
								logic uses the MDQOLib.MMR. When a HPLAN can not be derrived this  
								additional logic uses the MDQOLib.Membereligibilty to attempt to  
								find the HPLAN. 
07/15/2016		Loyal Ricks		Add transportation pickup and dropoff data elements		 
07/15/2016		Loyal Ricks		Remove input parameters Beginservicedatekey,endservicedatekey,	@SOURCE_ENVIRONMENT 
								job will utilize exclusion build "DP" logic for selection of valid claims. All PROD 
								only claims will be selected. Functionality to select UAT claims removed, no longer  
								needed.	 
07/25/2016		Loyal Ricks		TETDM-906 Apply default value of blank to ProviderPaytoFlag 
07/25/2016		Loyal Ricks		TETDM-907 Remove decimal from Dx1-Dx10 
08/16/2016		Loyal Ricks		TETDM-969 Diag code qualifier logic 
08/16/2016		Loyal Ricks		TETDM-979 Remove Sourceenvironment references	 
08/18/2016		Loyal Ricks		--->Add formatting to remove spaces in data element claim header Total_Charge 
09/06/2016		Loyal Ricks		Add DME logic for submissions 
09/07/2016		Loyal Ricks	    Add Claim frequency to logic for identifying original claims (1) 
09/14/2016		Loyal Ricks		TETDM-1008 Primary Diag Qualifer revisions (BF and ABF) 
09/14/2016		Loyal Ricks		TETDM-1012 Diag Qualifer 1-10 revisions (BF AND BK) 
09/15/2016		Loyal Ricks		TETDM-1008 Primary Diag Qualifer revisions (BK and ABK) 
09/15/2016		Loyal Ricks		TETDM-1012 Diag Qualifer 1-10 revisions (BF AND ABF) 
09/26/2016		Loyal Ricks		TETDM-1012 Fat finger fix change when assigning  DIAG_CD_QUAL2,  
								logic in statement incorrectly pointed to dx1. Revision change statement 
								LEN(DIAG_CD1) > 0  to LEN(DIAG_CD2) > 0  
10/07/2016		Loyal Ricks		TETDM-1103 Add dos between elig span logic 
10/26/2016		Loyal Ricks		Add logic for MMAI DME claims selection 
10/28/2016		Loyal Ricks		TETDM-1222 - Add logic - and b.reportdatekey  between b.begincoveragedatekey and b.endcoveragedatekey
03/20/2018		Scott Waller	TETDM-1760 The code that collects claims is getting multiple records for the same claimid/sourcedesc/lob/hicfa
								So even though it gets 50000, there is only a small number of distinct claims (like hundreds to low thousands)
08/20/2018		Anthony Ulmer	TETDM-1772 Refactored to help filter out the duplicate claims in the header table
								The changes in this will mimic some changes done in TETDM-1630
								Please see additional notes tagged with TETDM-1772 below.
10/24/2018		Anthony Ulmer	TETDM-1865 Code added to accomodate encounter resubmissions.
01/14/2019		Anthony Ulmer	TETDM-1945/1944 Updated to account for missing claims in HistoricalClaimDim Table
02/01/2019      Henry faust     TETDM-1931 Professional claim/POS 21,51,61 Admission date SDK4
09/24/2019		Anthony Ulmer	TETDM-2114 Removed ReportDateKey check in @LOB checks
01/22/2020      Aaron Ridley    TETDM-2215 SOS Exclusions - Include exclusions for resubs 
07/10/2020		Anthony Ulmer	TETDM-2318
	Updated this:
                        (IsDME = CASE WHEN @JobID = 1 THEN 0 END AND sub.IsExclusion = 0) --REGULAR
                    OR  (IsDME = CASE WHEN @JobID = 2 THEN 1 END AND sub.IsExclusion = 0) --DME Regular
                    OR  (IsDME = CASE WHEN @JobID = 5001 THEN 0 END AND IsResub = 1 AND sub.IsExclusion IN(1,0)) --REGULAR RESUB
                    OR  (IsDME = CASE WHEN @JobID = 5002 THEN 1 END AND IsResub = 1 AND sub.IsExclusion IN(1,0)) --DME RESUB
	to add the "IsExclusion" part.  The regular runs will exclude claims in the exclusion table
	while the resub will include excluded and regular.
02/22/2021		Anthony Ulmer   TETDM-2414
								Removed extra check for resubs to exclude claims in exclusions (we want them now)
								Added check to exclude claims in (7000,7001) exclusion (compliance holds)
02/25/2021     Aaron Ridley     TETDM-2359 - Added logic to accommodate 3000 job series for Adjustment submissions
2021/03/23     Anthony Ulmer	TETDM-2479 
								REMOVED items from TETDM-1889 that were in place to filter duplicate claims
									dup filter not needed since inbound data was cleaned up at source
07/02/2021    Aaron Ridley	    TETDM-2506 - Added logic to accommodate the population of NULL requestedamt 
                                             in the summary of the claims header totals. 
*****************************************************************************************************/			 
/* 
DECLARE @SourceDesc VARCHAR(60) =  
DECLARE  
	@BEGIN_DOS CHAR(8) = '20120101',  
	@END_DOS CHAR(8) = '20121231' 
-- 
--	Set to pull for a specific SourceDesc... 
-- 
 
SET @SourceDesc = 'Swedish' 
*/ 
SET NOCOUNT ON;
DECLARE 
			 
			@TOTAL_RECORDS INT, 
			@ExtractCount INT 
 
 
--HRP_CLAIM_FILE Run controls 
INSERT INTO EXT_SYS_RUNLOG 
		(PROC_NAME 
		,STEP 
		,START_DT 
		,END_DT 
		,RUN_MINUTES 
		,TOTAL_RECORDS 
		,ENTRYDT 
		) 
		VALUES('pr_OUTB_PROF_ENCOUNTER_CLM_HEADER' 
				,'2' 
				,GETDATE() 
				,NULL 
				,NULL 
				,0 
				,GETDATE() 
				) 
				 
-- 
--	Added 10-29-2013 to use ManualMaxClaimsPerFile in param table and eliminate hardcoded value in this SP 
-- 
		SELECT 
			@ExtractCount = ManualMaxClaimsPerFile 
		FROM 
			dbo.EDS_ClaimExtractParams	 
		WHERE 
			SourceDataKey = 4 
			AND CLAIM_TYPE ='P' 
	 
	IF OBJECT_ID('TEMPDB..#ELIG_CLM') <> 0 
		DROP TABLE #ELIG_CLM 
 
	CREATE TABLE #ELIG_CLM 
	( 
		ClaimId			VARCHAR(20), 
		SOURCEDESC		VARCHAR(60), 
		LOBCode			VARCHAR(15), 
		HCFACode		VARCHAR(5) 
	) 
 
	IF OBJECT_ID('TEMPDB..#tmplob') <> 0 
		DROP TABLE #tmplob 
 
	CREATE TABLE #tmplob 
	( 
		LOBCode			VARCHAR(15) 
	) 
 
	IF OBJECT_ID('TEMPDB..#OUTB_ENC_HSUB') <> 0 
		DROP TABLE #OUTB_ENC_HSUB 
 
		Create TABLE #OUTB_ENC_HSUB 
	(SOURCEDESC VARCHAR(60) NULL, 
		CLAIMNUM VARCHAR(50) NULL, 
		FILENAME VARCHAR(256) NULL 
		) 

	/**********************************************
	* TETDM-1772 CTEs added for claim filtering
	* Now NEW and IMPROVED!!!
	* Taken from TETDM-1630 INST Encounter claims
	**********************************************/
    	;WITH ClaimBasket AS 
		(
			SELECT
			*
			FROM (
					SELECT
						e.*
                        ,IIF(owtb.TESTID IS NULL,0,1) AS [IsResub] --Testbed TestCode
						,IIF(owtba.CLAIMID IS NULL,0,1) AS [IsAdjustment] -- TETDM-2359                        
                        ,IIF(eed.CLAIMNUM IS NULL, 0,1) AS [IsDME] --1 = Identified as DME claim
						,CASE 
                         	WHEN ece.claim_id IS NULL THEN 0
							WHEN owtba.CLAIMID IS NOT NULL AND ece.claim_id IS NOT NULL AND ech.EXCL_ID = 9019 THEN 0
                         	WHEN ece.claim_id IS NOT NULL AND ece.EXCL_ID = 4 THEN 1  --carveout for exclusion ID 3                       	
                         END AS [IsExclusion]
						 ,IIF( (ece.claim_id IS NOT NULL AND ece.EXCL_ID IN (7000,7001)) OR (ech.claim_id IS NOT NULL AND ech.EXCL_ID IN (7000,7001)),1,0 ) AS 'Is_Compliance_Hold'
						--TETDM 1772 NOTE: The sort order in this over partition by is critical in the selection of the claims.  This will determine which claim from a set of duplicates will be picked up.
					    ,latest = ROW_NUMBER() OVER (PARTITION BY e.CLAIMNUM, e.ClaimLineNum, e.ClaimType, e.MemberID, e.SOURCEDESC ORDER BY  e.LoadDateKey DESC, e.BeginServiceDateKey, e.FILENAME DESC)
					   FROM EDPS_Data.dbo.encounterclaimdim e
                            LEFT JOIN WIPRO.dbo.OUTB_WIPRO_TEST_BED owtb
                                ON e.ClaimNum = owtb.CLAIMID
                                AND owtb.TESTID = @JobID --test code
						    LEFT JOIN WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS owtba -- TETDM-2359 (Integrating Adjustments) 
                                ON e.ClaimNum = owtba.CLAIMID
                                AND owtba.TESTID = @JobID
                            LEFT OUTER JOIN WIPRO.dbo.EXT_CLAIM_EXCLUSION ece
                                ON e.ClaimNum = ece.claim_id
							LEFT OUTER JOIN WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST ech
                                ON e.ClaimNum = ech.claim_id
                            LEFT JOIN WIPRO.dbo.EXT_ENCOUNTER_DME eed
                                ON e.ClaimNum = eed.CLAIMNUM
                                AND e.SourceDesc = eed.SOURCEDESC	
					   WHERE 1 = 1
							AND e.SourceDesc = @SourceDesc
							AND e.ClaimType = 'P'
							AND e.ClaimFrequencyCode = (IIF(@JobID IN (3006,3001, 3066, 3061),'7','1'))  --TETDM-2359
							--AND NOT EXISTS (SELECT * FROM WIPRO.dbo.EXT_CLAIM_EXCLUSION ece1 WHERE ece1.claim_id = e.ClaimNum AND ece1.SOURCEDATAKEY = 4 AND ece1.EXCL_ID IN (7000,7001))
							--AND ece.claim_id is NULL    -- TETDM-2215 - Include exclusions for resubs 
				)sub
			WHERE 1 = 1
                AND sub.latest = 1
				AND sub.Is_Compliance_Hold = 0
                AND (
                        (IsDME = CASE WHEN @JobID = 1 THEN 0 END AND sub.[IsExclusion] = 0) --REGULAR
                    OR  (IsDME = CASE WHEN @JobID = 2 THEN 1 END AND sub.[IsExclusion] = 0) --DME Regular
                    OR  (IsDME = CASE WHEN @JobID = 5001 THEN 0 END AND IsResub = 1) --REGULAR RESUB
                    OR  (IsDME = CASE WHEN @JobID = 5002 THEN 1 END AND IsResub = 1) --DME RESUB
					OR  (IsDME = CASE WHEN @JobID = 3001 THEN 0 END AND sub.IsAdjustment = 1 AND sub.IsExclusion = 0) -- ADJ Regular RESUB
					OR  (IsDME = CASE WHEN @JobID = 3061 THEN 0 END AND sub.IsAdjustment = 1 AND sub.IsExclusion = 0) -- ADJ as Orig Regular RESUB
                    OR  (IsDME = CASE WHEN @JobID = 3006 THEN 1 END AND sub.IsAdjustment = 1 AND sub.IsExclusion = 0) --ADJ DME RESUB
					OR  (IsDME = CASE WHEN @JobID = 3066 THEN 1 END AND sub.IsAdjustment = 1 AND sub.IsExclusion = 0) --ADJ as Orig DME RESUB
                    )
		),
	 clm_totals AS (
			SELECT
				e.ClaimNum,
				e.SourceDesc,
				e.ClaimType,
				e.ClaimFrequencyCode,
				e.MemberID,
				MIN(e.BeginServiceDateKey) AS 'MIN_BeginServiceDateKey',
				MAX(e.EndServiceDateKey) AS 'MAX_EndServiceDateKey',
				SUM(e.RequestedAmt) AS 'SUM_RequestedAmt',
				SUM(e.CoPayAmt) AS 'SUM_CoPayAmt',
				SUM(e.PaidAmt) AS 'SUM_PaidAmt'
			FROM EDPS_Data.dbo.encounterclaimdim e
			GROUP BY
				e.ClaimNum,
				e.SourceDesc,
				e.ClaimType,
				e.ClaimFrequencyCode,
				e.MemberID
	)
	SELECT
		EncounterClaimKey
	   ,ProviderID
	   ,ReferringProviderID
	   ,CB.MemberID
	   ,MedicareID
	   ,PCPID
	   ,PCPLastName
	   ,PCPFirstName
	   ,PCPMiddleName
	   ,CB.ClaimNum
	   ,ProvTaxonomyCode
	   ,ProvSpecialtyCode
	   ,BillTypeCode
	   ,DateReceivedKey
	   ,DateEnteredKey
	   ,AdmissionTypeCode
	   ,AdmissionSourceCode
	   ,DischargeStatusCode
	   ,BeginServiceDateKey
	   ,EndServiceDateKey
	   ,PaidDateKey
	   ,ReversedClaimNum
	   ,Quantity
	   ,DeniedServiceQuantity
	   ,PlaceOfServiceCode
	   ,RequestedAmt
	   ,EligibleFeeAmt
	   ,CoPayAmt
	   ,CoInsuranceAmt
	   ,DeductibleAmt
	   ,COBAmt
	   ,PaidAmt
	   ,WithholdAmt
	   ,MaxFeeAmt
	   ,AdmissionDateKey
	   ,AdmissionDiagnosisTypeCode
	   ,ProcedureCode
	   ,ModifierCode1
	   ,ModifierCode2
	   ,ModifierCode3
	   ,ModifierCode4
	   ,FederalTaxID
	   ,VendorID
	   ,VendorLastName
	   ,VendorFirstName
	   ,AdjustmentCode
	   ,CheckNum
	   ,RevenueCode
	   ,DeniedReasonCode
	   ,ICD9ProcedureCode1
	   ,ICD9ProcedureDateKey1
	   ,ICD9ProcedureCode2
	   ,ICD9ProcedureDateKey2
	   ,ICD9ProcedureCode3
	   ,ICD9ProcedureDateKey3
	   ,AuthorizationID
	   ,ClaimLineNum
	   ,DX1
	   ,DiagQual1
	   ,DX2
	   ,DiagQual2
	   ,DX3
	   ,DiagQual3
	   ,DX4
	   ,DiagQual4
	   ,DX5
	   ,DiagQual5
	   ,DX6
	   ,DiagQual6
	   ,DX7
	   ,DiagQual7
	   ,DX8
	   ,DiagQual8
	   ,DX9
	   ,DiagQual9
	   ,DX10
	   ,DiagQual10
	   ,TaxonomyCode
	   ,ClaimLineStatus
	   ,FileName
	   ,CB.SourceDesc
	   ,SourceDataKey
	   ,Active
	   ,Deleted
	   ,LoadDateKey
	   ,EnterpriseID
	   ,CB.ClaimType
	   ,InpatientInd
	   ,CB.ClaimFrequencyCode
	   ,MIN_BeginServiceDateKey
	   ,SUM_RequestedAmt
	   ,SUM_CoPayAmt
	   ,SUM_PaidAmt
	   ,IsAdjustment
	INTO #RoughEncounterClaims
	FROM ClaimBasket CB
	LEFT JOIN clm_totals ct
		ON CB.ClaimNum = ct.ClaimNum
		AND CB.SourceDesc = ct.SourceDesc
		AND CB.ClaimType = ct.ClaimType
		AND CB.ClaimFrequencyCode = ct.ClaimFrequencyCode
		AND CB.MemberID = ct.MemberID
	WHERE 1 = 1
        AND ClaimLineNum = 1; --only need first claim line "header" information



/***************************************
--TETDM-1772
updated member pull  
max member with active and deleted flag
 ***************************************/
  
  IF OBJECT_ID('TEMPDB..#Members') <> 0 
      DROP TABLE #Members 
       
      ;WITH cteCurrMember AS  
      ( 
            SELECT 
                  MemberKey, 
                  MemberID
            FROM 
            MDQOLib.dbo.MemberDim   m 
            WHERE 1 = 1
				AND	MemberKey = (SELECT MAX(MemberKey) FROM MDQOLib.dbo.MemberDim WHERE MemberID = m.MemberID)
				AND m.Active = 1
				AND m.Deleted = 0 
                AND EXISTS (SELECT 1 FROM #RoughEncounterClaims rec WHERE rec.MemberID = m.MemberID)
      ) 
      SELECT DISTINCT 
            md.*   
      INTO 
            #Members 
      FROM 
            #RoughEncounterClaims ed 
      JOIN 
            MDQOLib.dbo.MemberDim   md 
            ON ed.MemberID = md.MemberID 
      JOIN 
            cteCurrMember                 c 
            ON md.MemberKey = c.MemberKey 
	 WHERE 1 = 1
		AND md.Active = 1 --active members only
		AND md.Deleted = 0 --members that are not deleted


-- TETDM-1760
	create nonclustered index ncidx_tmp_Members on #Members(MemberID);



		---Populate #tmplob using @LOB input parameter  
--TETDM-1865: NOTE: added job series 3000 for encounters
		if @LOB = 'MAO' 
			BEGIN  
						 
					INSERT INTO  
						#tmplob 
					(  
						LOBCode 
					) 
					SELECT 
						LOBCode 
					FROM 
						MDQOLib.dbo.LineofBusinessDim 
					WHERE	 
						ProductType = 'Medicare' 
					AND Active = 1 
					ORDER BY LOBCode 
 			 
					INSERT INTO #ELIG_CLM 
					select TOP(@ExtractCount) a.claimnum, 
									a.SOURceDESC, 
									b.LOBCODE, 
									b.HCFACODE
					FROM #RoughEncounterClaims a 
					--Removed join TETDM-1945/1944
					--JOIN EDPS_DATA.DBO.HistoricalClaim H 
					--	ON A.CLAIMNUM = H.CLM01
					--	AND a.ClaimType = H.ClaimType --TETDM-1772
					JOIN edps_data.dbo.monthlymembershipdim b  
						on a.memberid = b.memberid  
					JOIN #tmplob c 
						on b.lobcode = c.lobcode 
					WHERE 1 = 1
						AND a.beginservicedatekey between b.begincoveragedatekey and b.endcoveragedatekey
						--AND b.reportdatekey  between b.begincoveragedatekey and b.endcoveragedatekey	--TETDM-2114
					GROUP BY 	a.claimnum, a.SOURceDESC, b.LOBCODE, b.HCFACODE 	

			END 
 
--TETDM-1865: NOTE: added job series 3000 for encounters
			if @LOB IN ('MMAI','CAID') 
			BEGIN  
						 
					INSERT INTO  
						#tmplob 
					(  
						LOBCode 
					) 
					SELECT 
						LOBCode 
					FROM 
						MDQOLib.dbo.LineofBusinessDim 
					WHERE	 
						ProductType = 'Care-Caid' 
					AND Active = 1 
					ORDER BY LOBCode 
			 
					INSERT INTO #ELIG_CLM 
					select TOP(@ExtractCount)  a.claimnum, 
									a.SOURceDESC, 
									b.LOBCODE, 
									b.HCFACODE 
					FROM #RoughEncounterClaims a
					--Removed join TETDM-1945/1944
					--JOIN EDPS_DATA.DBO.HistoricalClaim H 
					--	ON A.CLAIMNUM = H.CLM01
					--	AND a.ClaimType = H.ClaimType --TETDM-1772 
					JOIN EDPS_Data.dbo.monthlymembershipdim b  
						ON a.memberid = b.memberid  
					JOIN #tmplob c 
						ON b.lobcode = c.lobcode 
					WHERE 1 = 1
						AND a.beginservicedatekey between b.begincoveragedatekey and b.endcoveragedatekey 
						--AND b.reportdatekey  between b.begincoveragedatekey and b.endcoveragedatekey --TETDM-2114
						AND b.lobcode = @lobcode 
					GROUP BY 	a.claimnum, a.SOURceDESC, b.LOBCODE, b.HCFACODE 
			END 



 
IF OBJECT_ID('TEMPDB..#OUTB_PROF_HEADER') <> 0 
DROP TABLE #OUTB_PROF_HEADER 
  
CREATE TABLE #OUTB_PROF_HEADER( 
	[RECORD_TYPE] [char](1) , 
	[CLAIM_TYPE] [char](1) , 
	[SYSTEM_SOURCE] [char](30) , 
	[CMS_CONTRACT_NUM] [char](5) , 
	[HICN_NUM] [char](20) , 
	[CLAIM_ID] [char](20) , 
	[PAT_CNTRL_NO] [char](20) , 
	[MEMBER_ID] [char](80) , 
	[MEMBER_LAST_NAME] [char](60) , 
	[MEMBER_FIRST_NAME] [char](35) , 
	[MEMBER_MID_INIT] [char](25) , 
	[MEMBER_SFX] [char](10) , 
	[MEMBER_ADDR1] [char](55) , 
	[MEMBER_ADDR2] [char](55) , 
	[MEMBER_CITY] [char](30) , 
	[MEMBER_STATE] [char](2) , 
	[MEMBER_ZIP] [char](5) , 
	[MEMBER_ZIP4] [char](4) , 
	[MEMBER_CTY] [char](30) , 
	[MEMBER_CTRY] [char](3) , 
	[MEMBER_CTRY_SUBD] [char](3) , 
	[MEMBER_GROUP_NO] [char](50) , 
	[INSURANCE_TYPE] [char](30) , 
	[MEMBER_DOB] [char](10) , 
	[MEMBER_GENDER] [char](15) , 
	[MEMBER_SSN] [char](11) , 
	[POS] [char](15) , 
	[INST_PRINCIPAL_DIAG_CD] [char](10) , 
	[INST_PRINCIPAL_POA_CD] [char](15) , 
	[INST_ADM_DIAG_CD] [char](10) , 
	[DIAG_CD1] [char](10) , 
	[POA_IND1] [char](15) , 
	[DIAG_CD2] [char](10) , 
	[POA_IND2] [char](15) , 
	[DIAG_CD3] [char](10) , 
	[POA_IND3] [char](15) , 
	[DIAG_CD4] [char](10) , 
	[POA_IND4] [char](15) , 
	[DIAG_CD5] [char](10) , 
	[POA_IND5] [char](15) , 
	[DIAG_CD6] [char](10) , 
	[POA_IND6] [char](15) , 
	[DIAG_CD7] [char](10) , 
	[POA_IND7] [char](15) , 
	[DIAG_CD8] [char](10) , 
	[POA_IND8] [char](15) , 
	[DIAG_CD9] [char](10) , 
	[POA_IND9] [char](15) , 
	[DIAG_CD10] [char](10) , 
	[POA_IND10] [char](15) , 
	[DIAG_CD11] [char](10) , 
	[POA_IND11] [char](15) , 
	[DIAG_CD12] [char](10) , 
	[POA_IND12] [char](15) , 
	[DIAG_CD13] [char](10) , 
	[POA_IND13] [char](15) , 
	[DIAG_CD14] [char](10) , 
	[POA_IND14] [char](15) , 
	[DIAG_CD15] [char](10) , 
	[POA_IND15] [char](15) , 
	[DIAG_CD16] [char](10) , 
	[POA_IND16] [char](15) , 
	[DIAG_CD17] [char](10) , 
	[POA_IND17] [char](15) , 
	[DIAG_CD18] [char](10) , 
	[POA_IND18] [char](15) , 
	[DIAG_CD19] [char](10) , 
	[POA_IND19] [char](15) , 
	[DIAG_CD20] [char](10) , 
	[POA_IND20] [char](15) , 
	[DIAG_CD21] [char](10) , 
	[POA_IND21] [char](15) , 
	[DIAG_CD22] [char](10) , 
	[POA_IND22] [char](15) , 
	[DIAG_CD23] [char](10) , 
	[POA_IND23] [char](15) , 
	[DIAG_CD24] [char](10) , 
	[POA_IND24] [char](15) , 
	[DIAG_CD25] [char](10) , 
	[POA_IND25] [char](15) , 
	[DIAG_CD26] [char](10) , 
	[POA_IND26] [char](15) , 
	[DIAG_CD27] [char](10) , 
	[POA_IND27] [char](15) , 
	[DIAG_CD28] [char](10) , 
	[POA_IND28] [char](15) , 
	[DIAG_CD29] [char](10) , 
	[POA_IND29] [char](15) , 
	[DIAG_CD30] [char](10) , 
	[POA_IND30] [char](15) , 
	[BILL_PROV_NPI] [char](10) , 
	[BILL_PROV_GRP_ID] [char](40) , 
	[BILL_PROV_GRP_NPI] [char](10) , 
	[BILL_PROV_ORG_NAME] [char](60) , 
	[BILL_PROV_LNAME] [char](60) , 
	[BILL_PROV_FNAME] [char](35) , 
	[BILL_PROV_MID_INIT] [char](25) , 
	[BILL_PROV_SFX] [char](10) , 
	[BILL_PROV_ADDR1] [char](55) , 
	[BILL_PROV_ADDR2] [char](55) , 
	[BILL_PROV_CITY] [char](30) , 
	[BILL_PROV_STATE] [char](2) , 
	[BILL_PROV_ZIP] [char](5) , 
	[BILL_PROV_ZIP4] [char](4) , 
	[BILL_PROV_CTRY] [char](3) , 
	[BILL_PROV_CTRY_SUBD] [char](3) , 
	[BILL_PROV_TAXONOMY_CD] [char](10) , 
	[BILL_PROV_TAX_ID] [char](11) , 
	[BILL_PROV_SSN] [char](11) , 
	[BILL_PROV_UPIN] [char](50) , 
	[BILL_PROV_LICENSE_NO] [char](50) , 
	[BILL_PROV_ID] [char](40) , 
	[PAYTO_ADDR_TYPE_FLAG] [char](15) , 
	[PAYTO_ADDR1] [char](55) , 
	[PAYTO_ADDR2] [char](55) , 
	[PAYTO_CITY] [char](30) , 
	[PAYTO_STATE] [char](2) , 
	[PAYTO_ZIP] [char](5) , 
	[PAYTO_ZIP4] [char](4) , 
	[PAYTO_CTRY] [char](3) , 
	[PAYTO_CTRY_SUBD] [char](3) , 
	[PAYER_RESP] [char](30) , 
	[TOT_CHRG_AMT] [char](18) , 
	[MEMBER_AMT_PAID] [char](18) , 
	[PATIENT_EST_AMT_DUE] [char](18) , 
	[CLM_IND] [char](20) , 
	[PROV_ASSGN_IND] [char](15) , 
	[INSR_BEN_ASSGN_IND] [char](15) , 
	[SERV_DT] [char](10) , 
	[ADM_TYPE_CD] [char](30) , 
	[ADM_SOURCE_CD] [char](30) , 
	[ADM_DT] [char](10) , 
	[ADM_TIME] [char](10) , 
	[STATE_BEGIN_DT] [char](10) , 
	[STATE_END_DT] [char](10) , 
	[DISCHRG_DT] [char](10) , 
	[DISCHRG_TIME] [char](10) , 
	[PATIENT_STATUS_CD] [char](10) , 
	[REFERRAL_NO] [char](50) , 
	[CPO_NPI] [char](10) , 
	[PRICE_METHOD] [char](50) , 
	[REF_PROV_LNAME] [char](60) , 
	[REF_PROV_FNAME] [char](35) , 
	[REF_PROV_MID_INIT] [char](25) , 
	[REF_PROV_SFX] [char](10) , 
	[REF_PROV_NPI] [char](10) , 
	[REF_PROV_TAXONOMY_CD] [char](10) , 
	[REF_PROV_LICENSE_NO] [char](50) , 
	[REF_PROV_UPIN] [char](50) , 
	[REF_PROV_ID] [char](50) , 
	[REF_PCP_LNAME] [char](60) , 
	[REF_PCP_FNAME] [char](35) , 
	[REF_PCP_MID_INIT] [char](25) , 
	[REF_PCP_SFX] [char](10) , 
	[REF_PCP_PROV_NPI] [char](10) , 
	[REF_PCP_TAXONOMY_CD] [char](10) , 
	[REF_PCP_LICENSE_NO] [char](50) , 
	[REF_PCP_PROV_UPIN] [char](50) , 
	[REF_PCP_PROV_ID] [char](50) , 
	[ATTN_PROV_LNAME] [char](60) , 
	[ATTN_PROV_FNAME] [char](35) , 
	[ATTN_PROV_MIDINIT] [char](25) , 
	[ATTN_PROV_SFX] [char](10) , 
	[ATTN_PROV_NPI] [char](10) , 
	[ATTN_PROV_TAXONOMY_CD] [char](10) , 
	[ATTN_PROV_TAXONOMY_CD2] [char](10) , 
	[ATTN_PROV_UPIN] [char](50) , 
	[ATTN_PROV_LOC_NO] [char](10) , 
	[ATTN_PROV_ID] [char](50) , 
	[ATTN_PROV_LICENSE_NO] [char](50) , 
	[EMER_FLAG] [char](15) , 
	[PROC_DESC] [char](80) , 
	[ANES_FLAG] [char](15) , 
	[PAYER_RESP1] [char](60) , 
	[REL_CD1] [char](35) , 
	[OTH_INSR_GRPNO1] [char](50) , 
	[OTH_INSR_GRPNAME] [char](60) , 
	[OTH_INSR_TYPECD1] [char](10) , 
	[CLM_FIL_INDCD1] [char](10) , 
	[CLM_ADJ_GRP_TYPE1] [char](2) , 
	[CLM_ADJ_REA_CD1] [char](5) , 
	[CLM_ADJ_AMT1] [char](18) , 
	[CLM_ADJ_UNIT1] [char](18) , 
	[AMOUNT_PAID] [char](18) , 
	[PAID_DATE] [char](10) , 
	[COB_TOTAL] [char](18) , 
	[NONCOV_CHRG] [char](18) , 
	[OTH_PAYER1_NAME] [char](60) , 
	[OTH_PAYER1_PLANID] [char](80) , 
	[OTH_PAYER1_ADDRESS1] [char](55) , 
	[OTH_PAYER1_ADDRESS2] [char](55) , 
	[OTH_PAYER1_CITY] [char](30) , 
	[OTH_PAYER1_STATE] [char](2) , 
	[OTH_PAYER1_ZIP] [char](5) , 
	[OTH_PAYER1_ZIP4] [char](4) , 
	[PAYER1_PAID_DT] [char](10) , 
	[SOURCEDATAKEY] [int] , 
	[PROV_SIGNATURE_FLAG] [varchar](15) , 
	[REL_OF_INFO_FLAG] [varchar](15) , 
	[ASSIGN_BEN_IND1] [char](15) , 
	[PAYER_CLAIM_CNTRL_NUM] [char](50) , 
	[OPTIONAL_REPORTING_IND] [varchar](30) , 
	[RENDERING_PROV_LAST_NAME] [char](60) NULL, 
	[RENDERING_PROV_FIRST_NAME] [char](35) NULL, 
	[RENDERING_PROV_MID_INIT] [char](25) NULL, 
	[RENDERING_PROV_SFX] [char](10) NULL, 
	[RENDERING_PROV_NPI] [char](10) NULL, 
	[RENDERING_PROV_ID] [char](50) NULL, 
	[RENDERING_PROV_TAXONOMY] [char](10) NULL, 
	[RENDERING_PROV_ORG_NAME] [char](60) NULL, 
	[RENDERING_PROV_GRP_ID] [char](50) NULL, 
	[PRINCIPAL_DIAG_QUAL] [varchar](3) NULL, 
	[ADMITDIAG_QUAL] [varchar](3) NULL, 
	[REA_VISITDIAG_QUAL1] [varchar](3) NULL, 
	[REA_VISITDIAG_QUAL2] [varchar](3) NULL, 
	[REA_VISITDIAG_QUAL3] [varchar](3) NULL, 
	[DIAG_CD_QUAL1] [varchar](3) NULL, 
	[DIAG_CD_QUAL2] [varchar](3) NULL, 
	[DIAG_CD_QUAL3] [varchar](3) NULL, 
	[DIAG_CD_QUAL4] [varchar](3) NULL, 
	[DIAG_CD_QUAL5] [varchar](3) NULL, 
	[DIAG_CD_QUAL6] [varchar](3) NULL, 
	[DIAG_CD_QUAL7] [varchar](3) NULL, 
	[DIAG_CD_QUAL8] [varchar](3) NULL, 
	[DIAG_CD_QUAL9] [varchar](3) NULL, 
	[DIAG_CD_QUAL10] [varchar](3) NULL, 
	[DIAG_CD_QUAL11] [varchar](3) NULL, 
	[DIAG_CD_QUAL12] [varchar](3) NULL, 
	[DIAG_CD_QUAL13] [varchar](3) NULL, 
	[DIAG_CD_QUAL14] [varchar](3) NULL, 
	[DIAG_CD_QUAL15] [varchar](3) NULL, 
	[DIAG_CD_QUAL16] [varchar](3) NULL, 
	[DIAG_CD_QUAL17] [varchar](3) NULL, 
	[DIAG_CD_QUAL18] [varchar](3) NULL, 
	[DIAG_CD_QUAL19] [varchar](3) NULL, 
	[DIAG_CD_QUAL20] [varchar](3) NULL, 
	[DIAG_CD_QUAL21] [varchar](3) NULL, 
	[DIAG_CD_QUAL22] [varchar](3) NULL, 
	[DIAG_CD_QUAL23] [varchar](3) NULL, 
	[DIAG_CD_QUAL24] [varchar](3) NULL, 
	[DIAG_CD_QUAL25] [varchar](3) NULL, 
	[DIAG_CD_QUAL26] [varchar](3) NULL, 
	[DIAG_CD_QUAL27] [varchar](3) NULL, 
	[DIAG_CD_QUAL28] [varchar](3) NULL, 
	[DIAG_CD_QUAL29] [varchar](3) NULL, 
	[DIAG_CD_QUAL30] [varchar](3) NULL, 
	[TRANS_PICKUP_ADDR1] [varchar](55) NULL, 
	[TRANS_PICKUP_CITY] [varchar](30) NULL, 
	[TRANS_PICKUP_STATE] [varchar](2) NULL, 
	[TRANS_PICKUP_ZIP] [varchar](5) NULL, 
	[TRANS_PICKUP_ZIP4] [varchar](4) NULL, 
	[TRANS_DROPOFF_ADDR1] [varchar](55) NULL, 
	[TRANS_DROPOFF_CITY] [varchar](30) NULL, 
	[TRANS_DROPOFF_STATE] [varchar](2) NULL, 
	[TRANS_DROPOFF_ZIP] [varchar](5) NULL, 
	[TRANS_DROPOFF_ZIP4] [varchar](4) NULL 
) ON [PRIMARY] 
 



	  
		insert into #OUTB_PROF_HEADER 
		select	distinct  
			'C'												'Record_Type' 
			,substring(ClaimType,1,1)											'Claim_Type' 
--			,'EDPS-Encounter'								'System_Source' 
			,'EDPS-' + rtrim(ecd.SourceDesc) --+'-'+ rtrim(ecd.SourceEnvironment)	'System_Source' 
			,e.HCFACode							'CMS_Contract_Num' 
			,mb.MedicareID									'HICN_NUM' 
			,LEFT(ecd.ClaimNum, 20)							'Claim_ID' 
			,' '											'Pat_Cntrl_No' 
			,REPLACE(ecd.MemberID,'*','-')					'Member_ID' 
			,mb.lastname									'Member_Last_Name'		 
			,mb.firstname									'Member_First_Name' 
			,CASE mb.middlename  
				WHEN 'UNKNOWN' THEN ' ' 
				ELSE mb.middlename 
			 END											'Member_Mid_Init' 
			 ,' '											'Member_Sfx' 
			,mb.AddressLine1								'Member_Addr1' 
			,CASE mb.AddressLine2 
				WHEN 'UNKNOWN' THEN ' ' 
				ELSE mb.AddressLine2 
			 END											'Member_Addr2' 
			,mb.City										'Member_City' 
			,mb.State										'Member_State' 
			,CASE substring(mb.Zip,1,5) WHEN 'UNKNO' THEN '99999' WHEN 'NY' THEN '99999' WHEN 'WA' THEN '99999' ELSE SUBSTRING(mb.Zip,1,5) END 
			,CASE substring(mb.Zip,6,4) WHEN 'WN' THEN '9999' WHEN 'NY' THEN '9999' WHEN 'WA' THEN '9999' WHEN '    ' THEN '9999' ELSE SUBSTRING(mb.Zip,6,4) END 
			,' '											'MEMBER_CTY' 
			,' '											'MEMBER_CTRY' 
			,' '											'MEMBER_CTRY_SUBD' 
			,' '											'Member_Group_No' 
			,'14'											'Insurance_Type' --PROFESSIONAL CLAIM DEFAULT = '14' 
			,mb.DOBDateKey									'Member_DOB' 
			,mb.Gender										'Member_Gender' 
			,IIF(mb.SSN = 'UNKNOWN',' ',MB.ssn)	--TETDM-1772										'Member_SSN' 
			,SUBSTRING(PlaceofServiceCode,1,15)											'POS' 
			,ISNULL(REPLACE(ecd.DX1,'.',''),' ')			'INST_PRINCIPAL_DIAG_CD' 
			,CASE isnull(ecd.DX1	,' ') WHEN ' ' THEN ' ' ELSE 'N' END		'INST_PRINCIPAL_POA_CD' 
			,' '											'INST_ADM_DIGA_CD' 
			,ISNULL(REPLACE(ecd.DX1,'.',''),' ')									'DIAG_CD1' 
			,CASE isnull(ecd.DX1	,' ') WHEN ' ' THEN ' ' ELSE 'N' END											'POA_IND1' 
			,ISNULL(REPLACE(ecd.DX2,'.',''),' ')									'DIAG_CD1' 
			,CASE isnull(ecd.DX2	,' ') WHEN ' ' THEN ' ' ELSE 'N' END											'POA_IND1' 
			,isnull(REPLACE(ecd.DX3,'.',''),' ')							'DIAG_CD2' 
			,CASE isnull(ecd.DX3,' ') WHEN ' ' THEN ' ' ELSE 'N' END	'POA_IND2' 
			,isnull(REPLACE(ecd.DX4,'.',''),' ')								'DIAG_CD3' 
			,CASE isnull(ecd.DX4	,' ') WHEN ' ' THEN ' ' ELSE 'N' END											'POA_IND3' 
			,isnull(REPLACE(ecd.DX5,'.',''),' ')										'DIAG_CD4' 
			,CASE isnull(ecd.DX5	,' ') WHEN ' ' THEN ' ' ELSE 'N' END											'POA_IND4' 
			,isnull(REPLACE(ecd.DX6,'.',''),' ')									'DIAG_CD5' 
			,CASE isnull(ecd.DX6	,' ') WHEN ' ' THEN ' ' ELSE 'N' END											'POA_IND5' 
			,isnull(REPLACE(ecd.DX7,'.',''),' ')								'DIAG_CD6' 
			,CASE isnull(ecd.DX7	,' ') WHEN ' ' THEN ' ' ELSE 'N' END											'POA_IND6' 
			,isnull(REPLACE(ecd.DX8,'.',''),' ')									'DIAG_CD7' 
			,CASE isnull(ecd.DX8	,' ') WHEN ' ' THEN ' ' ELSE 'N' END											'POA_IND7' 
			,isnull(REPLACE(ecd.DX9,'.',''),' ')								'DIAG_CD8' 
			,CASE isnull(ecd.DX9	,' ') WHEN ' ' THEN ' ' ELSE 'N' END											'POA_IND8' 
			,isnull(REPLACE(ecd.DX10,'.',''),' ')										'DIAG_CD9' 
			,CASE isnull(ecd.DX10	,' ') WHEN ' ' THEN ' ' ELSE 'N' END											'POA_IND9' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' '--DIAG_CD20 
			,' '--POA_IND20 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' '--DIAG_CD30 
			,' '--POA_IND30 
			,' '--BILL_PROV_NPI 
			,' '--BILL-PROV_GRP_ID 
			,' '--BILL-PROV_GRP_NPI 
			,' '--BILL_PROV_ORG_NAME 
			,' '--ISNULL(ECD.VENDORLASTNAME,' ') --BILL_PROV_LNAME 
			,' '--ISNULL(ECD.VENDORFIRSTNAME,' ') --BILL_PROV_FNAME 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' --epd.FederalTaxId			--	BILL_PROV_TAX_ID 
			,' '			--	BILL_PROV_SSN 
			,' '			--	BILL_PROV_UPIN 
			,' '--isnull(epd.StateLicenseNum,' ')			--BILL_PROV_LICENSE_NO 
			,ISNULL(ecd.VendorID,' ')						'Bill_Prov_ID' 
			,' '								-- PayTo_Addr_Type_Flag 
			,' '--PAYTO_ADDR1 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,'P'--PAYER_RESP 
			, ecd.SUM_RequestedAmt --TETDM-1772  --' ' -- ecd.RequestedAmt								'TOT_CHRG_AMT'		--		??????????		ltrim(cd.ClaimBilledAmt)	 
			,' ' -- ecd.CoPayAmt								'MEMBER_AMT_PAID'	--		??????????		ltrim(cd.MemberPaidAmt)	 
			, ' '								'PATIENT_EST_AMT_DUE'	--	??????????			 
			,case WHEN ecd.IsAdjustment ='1' AND @JOBID <> 3061 THEN ecd.ClaimFrequencyCode ELSE '1' END    'CLM_IND'		--	tetdm-2359			??????????		CASE cd.PreviousClaimID WHEN 'N/A' THEN '1' ELSE '7' END	 
			, 'C'								'PROV_ASSGN_IND'	--		??????????			 
			, 'Y'								'INS_BEN_ASSGN_IND'	--	??????????			 
			, ecd.MIN_BeginServiceDateKey -- TETDM-1772' '--ecd.BeginServiceDateKey			'SERV_DT' 
			,isnull(ecd.AdmissionTypeCode,' ')				'ADM_TYPE_CD' 
			,isnull(ecd.AdmissionSourceCode,' ')			'ADM_SOURCE_CD' 
			 
--		H E R E	 TETDM-1931 		 
--			,CASE isnull(AdmissionDateKey,' ')	WHEN '0' THEN ' ' ELSE 	isnull(AdmissionDateKey,' ') END			'ADM_DT'		--				??????????		case cd.admissiondatekey when '-1' then ' ' when '0' then ' ' else cd.AdmissionDateKey end 
			,CASE 	WHEN AdmissionDateKey is NULL OR AdmissionDateKey = 0 THEN beginservicedatekey ELSE 	isnull(AdmissionDateKey,' ') END			'ADM_DT'		--				??????????		case cd.admissiondatekey when '-1' then ' ' when '0' then ' ' else cd.AdmissionDateKey end 
			,' '								'ADM_TIME' 
			,' '								'STATE_BEGIN_DT' 
			,' '								'STATE_END_DT' 
			,' '								'DISCHARGE_DT'		--		??????????		case cd.dischargedatekey when '-1' then ' '  when '0' then ' ' else cd.DischargeDateKey end 
			,' '								'DISCHARGE_TIME' 
			,' '								'PATIENT_STATUS_CD'	--	??????????		CASE cd.DispositionCode WHEN 'N/A' THEN ' ' ELSE cd.DispositionCode END 
			,isnull(ecd.AuthorizationID	,' ')			'REFERRAL_NO'	--			??????????		'CASE replace(cd.AuthorizationID,'*','-') WHEN 'UNKNOWN' THEN ' ' ELSE replace(cd.AuthorizationID,'*','-')  END 
			,' '--CPO_NPI 
			,' '--PRICE_METHOD 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' '--REF_PROV_UPIN 
			,ecd.ProviderID								'REF_PROV_id'	--			????????????	CASE cd.ReferringPhysicianID WHEN 'UNKNOWN' THEN ' ' ELSE cd.ReferringPhysicianID END 
			,' '--REF_PCP_LNAME 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' '--REF_PCP_PROV_UPIN 
			,' '								'REF_PCP_PROV_id'	--		????????????	cd.PCPID 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' '--ATTN_PROV_LOC_NO 
			,' '								'ATTN_PROV_ID'	--		????????????	CASE cd.AttendingPhysicianID WHEN 'UNKNOWN' THEN ' ' ELSE cd.AttendingPhysicianID END 
			,' '--ATTN_PROV_LICENSE_NO 
			,' '--EMER_FLAG 
			,' '--PROD_DESC 
			,' '--ANES_FLAG 
			,'P'--PAYER_RESP1 default values for CMS COB 
			,'18'--REL_CD1 default values for CMS COB 
			,' '--OTH_INSR_GRPNO1 CHAR(50), 
			,'HealthSpring'--OTH_INSR_GRPNAME CHAR(60), 
			,' '--OTH_INSR_TYPECD1 CHAR(10), 
			,'16'--CLM_FIL_INDCD1 CHAR(10), 
			,' '--CLM_ADJ_GRP_TYPE1 CHAR(2), 
			,' '--CLM_ADJ_REA_CD1 CHAR(5), 
			,' '--SUM(CD.CLAIMBILLEDAMT - cd.TotalPaid)--CLM_ADJ_AMT1 CHAR(18), 
			,' '--CLM_ADJ_UNIT1 CHAR(18) 
			, ecd.SUM_PaidAmt --TETDM-1772 ' ' --ecd.PaidAmt									'AMOUNT_PAID'	--				???????????????	AMOUNT_PAID ltrim(cd.TotalPaid) 
			,' '--cd.MHCFinancialDateKey--EDPS_Prod CLAIMAGG PAYDATEKEY WHICH IS  
			,' '--ltrim(cd.MemberPaidAmt) 
			,' ' 
			,'HealthSpring'--OTHER PAYER 1 NAME 
			,e.HCFACode---OTHER PAYER1 PLAN ID 
			,'530 GREAT CIRCLE' --OTHER PAYER1 ADDRESS 
			,' '  --OTHER PAYER1 ADDRESS2 
			,'NASHVILLE'--OTHER PAYER1 CITY 
			,'TN' --OTHER PAYER1 STATE 
			,'37228'--OTH PAYER1 ZIP 
			,'9999' -- OTHER PAYER1 ZIP4 
			,' '--cd.MHCFinancialDateKey 
			,CONVERT(CHAR, ecd.SourceDataKey)								'cd.sourcedatakey' 
			,'Y'--PROV_SIGNATURE_FLAG 
			,'Y'--REL_OF_INFO_FLAG 
			,'Y'--ASSIGN_BEN_IND1 
			,case when @JOBID = 3061 THEN '' ELSE ecd.ReversedClaimNum END  'PAYER_CLAIM_CNTRL_NUM' -- TETDM-2359 	??????????????	CASE cd.PreviousClaimID WHEN 'N/A' THEN ' ' WHEN 'UNKNOWN' THEN ' ' ELSE cd.PreviousClaimID END 
			,' '--OPTIONAL REPORTING INDICATOR 
			,' '--rendoring provider  
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' ' 
			,' '--rendering prov taxonomy 
			,' '--rendering provider org name 
			,' '--rendering provider group id 
			,case diagqual1 when '9' then 'BK' when '0' then 'ABK' else isnull(diagqual1,' ') end--[PRINCIPAL_DIAG_QUAL] [varchar](3) NULL, 
			,' '--[ADMITDIAG_QUAL] [varchar](3) NULL, 
			,' '--[REA_VISITDIAG_QUAL1] [varchar](3) NULL, 
			,' '--[REA_VISITDIAG_QUAL2] [varchar](3) NULL, 
			,' '--[REA_VISITDIAG_QUAL3] [varchar](3) NULL, 
			,case diagqual1 when '9' then 'BF' when '0' then 'ABF' else isnull(diagqual1,' ') end --[DIAG_CD_QUAL1] [varchar](3) NULL, 
			,case diagqual2 when '9' then 'BF' when '0' then 'ABF' else isnull(diagqual2,' ') end --[DIAG_CD_QUAL2] [varchar](3) NULL, 
			,case diagqual3 when '9' then 'BF' when '0' then 'ABF' else isnull(diagqual3,' ') end --[DIAG_CD_QUAL3] [varchar](3) NULL, 
			,case diagqual4 when '9' then 'BF' when '0' then 'ABF' else isnull(diagqual4,' ') end --[DIAG_CD_QUAL4] [varchar](3) NULL, 
			,case diagqual5 when '9' then 'BF' when '0' then 'ABF' else isnull(diagqual5,' ') end --[DIAG_CD_QUAL5] [varchar](3) NULL, 
			,case diagqual6 when '9' then 'BF' when '0' then 'ABF' else isnull(diagqual6,' ') end --	[DIAG_CD_QUAL6] [varchar](3) NULL, 
			,case diagqual7 when '9' then 'BF' when '0' then 'ABF' else isnull(diagqual7,' ') end --[DIAG_CD_QUAL7] [varchar](3) NULL, 
			,case diagqual8 when '9' then 'BF' when '0' then 'ABF' else isnull(diagqual8,' ') end ' '--[DIAG_CD_QUAL8] [varchar](3) NULL, 
			,case diagqual9 when '9' then 'BF' when '0' then 'ABF' else isnull(diagqual9,' ') end --[DIAG_CD_QUAL9] [varchar](3) NULL, 
			,case diagqual10 when '9' then 'BF' when '0' then 'ABF' else isnull(diagqual10,' ') end --[DIAG_CD_QUAL10] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL11] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL12] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL13] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL14] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL15] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL16] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL17] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL18] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL19] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL20] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL21] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL22] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL23] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL24] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL25] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL26] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL27] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL28] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL29] [varchar](3) NULL, 
			,' '--[DIAG_CD_QUAL30] [varchar](3) NULL 
			,' '--[TRANS_PICKUP_ADDR1] [varchar](55) NULL, 
			,' '--[TRANS_PICKUP_CITY] [varchar](30) NULL, 
			,' '--[TRANS_PICKUP_STATE] [varchar](2) NULL, 
			,' '--[TRANS_PICKUP_ZIP] [varchar](5) NULL, 
			,' '--[TRANS_PICKUP_ZIP4] [varchar](4) NULL, 
			,' '--[TRANS_DROPOFF_ADDR1] [varchar](55) NULL, 
			,' '--[TRANS_DROPOFF_CITY] [varchar](30) NULL, 
			,' '--[TRANS_DROPOFF_STATE] [varchar](2) NULL, 
			,' '--[TRANS_DROPOFF_ZIP] [varchar](5) NULL, 
			,' '--[TRANS_DROPOFF_ZIP4] [varchar](4) NULL
		FROM #RoughEncounterClaims ecd
		LEFT JOIN #Members mb 			
			ON ecd.MemberID = mb.MemberID 
		LEFT JOIN #ELIG_CLM e 
			ON ecd.ClaimNum = e.ClaimId
			AND ecd.SourceDesc = e.SOURCEDESC 
		WHERE 1 = 1
			AND e.ClaimId IS NOT NULL;			 
		 

		   
		 --REMOVE DEFAULT ADM_DT VALUE 
			UPDATE #OUTB_PROF_HEADER 
			SET ADM_DT = ' ' 
			WHERE ADM_DT = '0' 
			 
		---Update diag code qualifiers 
		--TETDM-1012 remove logic due to updated requirements 
			--update #OUTB_PROF_HEADER  
			--SET DIAG_CD_QUAL1 = 'BF' 
			--WHERE LEN(DIAG_CD1) > 0   
 
 
			--update #OUTB_PROF_HEADER  
			--SET DIAG_CD_QUAL2 = 'BF' 
			--WHERE LEN(DIAG_CD2) > 0   
 
 
			--update #OUTB_PROF_HEADER  
			--SET DIAG_CD_QUAL3 = 'BF' 
			--WHERE LEN(DIAG_CD3) > 0   
 
 
			--update #OUTB_PROF_HEADER  
			--SET DIAG_CD_QUAL4 = 'BF' 
			--WHERE LEN(DIAG_CD4) > 0   
 
 
 
			--update #OUTB_PROF_HEADER  
			--SET DIAG_CD_QUAL5 = 'BF' 
			--WHERE LEN(DIAG_CD5) > 0   
 
 
			--update #OUTB_PROF_HEADER  
			--SET DIAG_CD_QUAL6 = 'BF' 
			--WHERE LEN(DIAG_CD6) > 0   
 
 
			--update #OUTB_PROF_HEADER  
			--SET DIAG_CD_QUAL7 = 'BF' 
			--WHERE LEN(DIAG_CD7) > 0   
 
 
			--update #OUTB_PROF_HEADER  
			--SET DIAG_CD_QUAL8 = 'BF' 
			--WHERE LEN(DIAG_CD8) > 0   
 
			--UPDATE #OUTB_PROF_HEADER --TETDM-1772
			--SET MEMBER_SSN = ' ' 
			--WHERE MEMBER_SSN = 'UNKNOWN' 
 
			IF @JOBID IN (2,5002,3006,3066) 
				BEGIN  
					UPDATE #OUTB_PROF_HEADER 
					SET CLAIM_TYPE = 'E' 
				END 

			
			IF @JOBID IN (3066,3061) 
			   BEGIN  
					UPDATE #OUTB_PROF_HEADER 
					SET CLM_IND = '1' 
				END 
 
			 
			TRUNCATE TABLE OUTB_PROF_HEADER 
			TRUNCATE TABLE OUTB_PROF_DETAIL 
			 
			INSERT INTO OUTB_PROF_HEADER 
			SELECT * 
			FROM #OUTB_PROF_HEADER 
 
			---2/3/16 hplan adjustments 
												  
			select member_id,serv_dt,claim_id,CMS_CONTRACT_NUM 
			into  #tmp_mem_hplan 
			from outb_prof_header 
			where len(cms_contract_num) = 0  
 
			update #tmp_mem_hplan 
			set CMS_CONTRACT_NUM = rtrim(contractnumber) 
			from #tmp_mem_hplan t 
			inner join MDQOLib.dbo.MemberEligibility me 
			on replace(t.member_id,'-','*') = me.memberid  
			where serv_dt between convert(char, eligstartdate) and convert(char, eligenddate) 
 
			update OUTB_PROF_HEADER 
			SET CMS_CONTRACT_NUM = T.CMS_CONTRACT_NUM, 
				OTH_PAYER1_PLANID = T.CMS_CONTRACT_NUM 
			FROM OUTB_PROF_HEADER PH 
			INNER JOIN #tmp_mem_hplan T 
			ON PH.CLAIM_ID = T.CLAIM_ID  
			 
			 
			 ---qualifer assignments when encounterclaimdim info is null 
 
			 ---TETDM-1008  
			 UPDATE OUTB_PROF_HEADER 
			 SET PRINCIPAL_DIAG_QUAL = 'ABK' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(INST_PRINCIPAL_DIAG_CD) > 0  
					AND LEN(PRINCIPAL_DIAG_QUAL) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET PRINCIPAL_DIAG_QUAL = 'BK' 
			 WHERE serv_dt < '20151001' 
					AND LEN(INST_PRINCIPAL_DIAG_CD) > 0  
					AND LEN(PRINCIPAL_DIAG_QUAL) = 0 
 
			---TETDM-1012 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL1 = 'ABF' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(DIAG_CD1) > 0  
					AND LEN(DIAG_CD_QUAL1) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL1 = 'BF' 
			 WHERE serv_dt < '20151001' 
					AND LEN(DIAG_CD1) > 0  
					AND LEN(DIAG_CD_QUAL1) = 0 
 
			---TETDM-1012 Fat finer fix 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL2 = 'ABF' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(DIAG_CD2) > 0  
					AND LEN(DIAG_CD_QUAL2) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL2 = 'BF' 
			 WHERE serv_dt < '20151001' 
					AND LEN(DIAG_CD2) > 0  
					AND LEN(DIAG_CD_QUAL2) = 0 
 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL3 = 'ABF' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(DIAG_CD3) > 0  
					AND LEN(DIAG_CD_QUAL3) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL3 = 'BF' 
			 WHERE serv_dt < '20151001' 
					AND LEN(DIAG_CD3) > 0  
					AND LEN(DIAG_CD_QUAL3) = 0 
 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL4 = 'ABF' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(DIAG_CD4) > 0  
					AND LEN(DIAG_CD_QUAL4) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL4 = 'BF' 
			 WHERE serv_dt < '20151001' 
					AND LEN(DIAG_CD4) > 0  
					AND LEN(DIAG_CD_QUAL4) = 0 
 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL5 = 'ABF' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(DIAG_CD5) > 0  
					AND LEN(DIAG_CD_QUAL5) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL5 = 'BF' 
			 WHERE serv_dt < '20151001' 
					AND LEN(DIAG_CD5) > 0  
					AND LEN(DIAG_CD_QUAL5) = 0 
 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL6 = 'ABF' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(DIAG_CD6) > 0  
					AND LEN(DIAG_CD_QUAL6) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL6 = 'BF' 
			 WHERE serv_dt < '20151001' 
					AND LEN(DIAG_CD6) > 0  
					AND LEN(DIAG_CD_QUAL6) = 0 
 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL7 = 'ABF' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(DIAG_CD7) > 0  
					AND LEN(DIAG_CD_QUAL7) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL7 = 'BF' 
			 WHERE serv_dt < '20151001' 
					AND LEN(DIAG_CD7) > 0  
					AND LEN(DIAG_CD_QUAL7) = 0 
 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL8 = 'ABF' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(DIAG_CD8) > 0  
					AND LEN(DIAG_CD_QUAL8) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL8 = 'BF' 
			 WHERE serv_dt < '20151001' 
					AND LEN(DIAG_CD8) > 0  
					AND LEN(DIAG_CD_QUAL8) = 0 
 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL9 = 'ABF' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(DIAG_CD9) > 0  
					AND LEN(DIAG_CD_QUAL9) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL9 = 'BF' 
			 WHERE serv_dt < '20151001' 
					AND LEN(DIAG_CD9) > 0  
					AND LEN(DIAG_CD_QUAL9) = 0 
 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL10 = 'ABF' 
			 WHERE serv_dt >= '20151001' 
					AND LEN(DIAG_CD10) > 0  
					AND LEN(DIAG_CD_QUAL10) = 0 
 
			 UPDATE OUTB_PROF_HEADER 
			 SET DIAG_CD_QUAL10 = 'BF' 
			 WHERE serv_dt < '20151001' 
					AND LEN(DIAG_CD10) > 0  
					AND LEN(DIAG_CD_QUAL10) = 0 
 
			----DME Updates 
			update OUTB_PROF_HEADER
			SET CLAIM_TYPE = E.CLAIM_TYPE
			FROM OUTB_PROF_HEADER H
			INNER JOIN EXT_ENCOUNTER_DME E
			ON H.CLAIM_ID = E.CLAIMNUM 
			WHERE E.SOURCEDESC = @SOURCEDESC

			if @jobid NOT IN (2,5002,3006,3066)
			begin 
			
			
				--DME Edit Run controls 
				INSERT INTO EXT_SYS_RUNLOG 
						select 'pr_OUTB_PROF_ENCOUNTER_CLM_HEADER-DME Edit' 
								,'2' 
								,GETDATE() 
								,GETDATE() 
								,COUNT(*)
								,count(*)
								,GETDATE() 
						from outb_prof_header 
						where claim_type = 'E'
				 
				-----REMOVE DME CLAIMS 
				DELETE FROM OUTB_PROF_HEADER 
				WHERE CLAIM_TYPE = 'E'

			end
	 


		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RESEND 
							  
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_HEADER) 
									 
		----HRP_CLAIM_FILE Update Run Controls 
				 
						UPDATE EXT_SYS_RUNLOG 
						SET END_DT = GETDATE()	 
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()) 
							,TOTAL_RECORDS = @TOTAL_RECORDS 
							,ENTRYDT = GETDATE() 
						WHERE PROC_NAME = 'pr_OUTB_PROF_ENCOUNTER_CLM_HEADER' 
								AND END_DT IS NULL
SET NOCOUNT OFF;