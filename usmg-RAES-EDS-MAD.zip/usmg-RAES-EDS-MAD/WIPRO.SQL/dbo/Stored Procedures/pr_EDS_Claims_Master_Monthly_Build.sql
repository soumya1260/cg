﻿


CREATE PROCEDURE [dbo].[pr_EDS_Claims_Master_Monthly_Build]
/* 

07/19/2017	Mike Vega		Create pr_EDPS_Data_Claims_Master_Monthly_Build stored 
							procedure to be used to automate the monthly population
							of the WIPRO.dbo.EDS_Claims_Master table for the 
							EDS team.

							This will do all the "heavy lifting" work in the
							EDPS_Data.reporting db/schema before moving the final results
							to tables in the WIPRO.dbo db/schema.
---------------------------------------------------------------------------
Modifications
Date		Developer		Description
---------------------------------------------------------------------------
Oct / Nov 2018 Scott Waller	TETDM-1892 & TETDM-1896

11/20/2018	Scott Waller	TETDM-1900

04/27/2021	Scott Waller	TETDM-2510
							We identified why the counts from the EDS_Claims_Master did not match
							the BIDW Refresh LoadAudit spreadsheet.  It occured when a claimid existed
							in more than one SourceDataKey.  This ticket is to correct that from
							happening again.

08/04/2021	Scott Waller	TETDM-2530 correct the SDK 4 claim collection.  
							It is grabbing all rows for each claim, not just the header.
							Which over inflates the claim counts.

------------------------------------------------------------------------------ */
AS 
    BEGIN
        DECLARE @TOTAL_RECORDS INT

        INSERT  INTO dbo.EXT_SYS_RUNLOG
                ( PROC_NAME ,
                  STEP ,
                  START_DT ,
                  END_DT ,
                  RUN_MINUTES ,
                  TOTAL_RECORDS ,
                  ENTRYDT
                )
        VALUES  ( 'dbo.pr_EDS_Claims_Master_Monthly_Build' ,
                  '1' ,
                  GETDATE() ,
                  NULL ,
                  NULL ,
                  0 ,
                  GETDATE()
                )

-- start by collecting info on the claims we need to delete
        TRUNCATE TABLE	reporting.MonthlyRefreshClaimsCount     
        TRUNCATE TABLE	reporting.EDS_Claims_Master
        TRUNCATE TABLE	reporting.EDS_Claims_Master_Beginning_Counts

-- archive Last Month's data
        INSERT  INTO WIPRO.dbo.EDS_Claims_Master_Archive
                SELECT  *
                FROM    WIPRO.dbo.EDS_Claims_Master_Controlled

        TRUNCATE TABLE	WIPRO.dbo.EDS_Claims_Master
        TRUNCATE TABLE	WIPRO.dbo.EDS_Claims_Master_Controlled

-------------------------------------------------------------------------------------
-- Build the data in the reporting.MonthlyRefreshClaimsCount table
-------------------------------------------------------------------------------------

-- get a single static date/time that will act as the unique idenifier to this set of data being loaded
        DECLARE @vCurrentDateTime DATETIME
        SET @vCurrentDateTime = GETDATE()	

        INSERT  INTO reporting.EDS_Claims_Master
			(claimid, sourcedatakey, CreationDate) 
                SELECT  a.claimid ,
                        a.sourcedatakey ,
                        @vCurrentDateTime AS CreationDate
                FROM    EDPS_Data.dbo.claimdim a
-- TETDM-2510
--                WHERE   claimid NOT IN (
--                        SELECT  claimid
--                        FROM    WIPRO.dbo.EDS_Claims_Master_Archive )
				left outer join WIPRO.dbo.EDS_Claims_Master_Archive b
					on	b.sourcedatakey		= a.SOURCEDATAKEY
					and b.claimid			= a.CLAIMID
                WHERE   b.claimid IS NULL
-- end TETDM-2510 


/*	TETDM-1900
	I am commenting out the original ENCOUNTERCLAIMDIM logic because 
	right after I added it is when I discovered that it is not correct
	which lead to 3 separate tickets correcting this logic in other sprocs
	that need to be corrected

-- TETDM-1892
INSERT  INTO reporting.EDS_Claims_Master 
	(claimid, sourcedatakey, CreationDate,Sourcedesc,memberid)
  
                SELECT  DISTINCT 
                        ClaimNum , 
                        c.sourcedatakey , 
                        @vCurrentDateTime AS CreationDate, 
						c.Sourcedesc,
						C.memberid
                FROM    edps_data.dbo.encounterclaimdim c 
				INNER JOIN EDS_Audit.dbo.EDS_Encounter_SourceDesc s
					ON	c.SourceDesc			= s.SourceDesc
					AND BeginServiceDateKey		BETWEEN startdate AND enddate
                INNER JOIN EDPS_Data.dbo.MonthlyMembershipDim mmd
					ON	mmd.MemberID			= c.MemberID
					AND c.BeginServiceDateKey	BETWEEN mmd.ModifiedReportDateKey - 14
												AND     mmd.ReportDateKey
                LEFT JOIN dbo.EDS_Claims_Master_Archive a 
					ON	a.claimid				= c.ClaimNum 
                    AND a.sourcedatakey			= c.SourceDataKey 
					AND A.sourcedesc			= c.sourcedesc 
					AND A.memberid				= C.memberid
                WHERE   BeginServiceDateKey >= 20150101 
                        AND c.sourcedatakey = 4 
                        AND claimlinenum = 1 
                        AND a.claimid IS NULL
*/
-- TETDM-1900
       ;WITH EncounterClaimBasket AS 
       (	SELECT	*
			FROM ( SELECT
						e.ClaimNum , 
                        e.sourcedatakey , 
                        @vCurrentDateTime AS CreationDate, 
						e.Sourcedesc,
						e.memberid,
						e.claimlinenum,
						e.beginservicedatekey,
                        latest = ROW_NUMBER() OVER (PARTITION BY e.CLAIMNUM, e.ClaimLineNum, e.MemberID, e.SOURCEDESC ORDER BY  e.LoadDateKey DESC, e.BeginServiceDateKey, e.FILENAME DESC)
                   FROM	EDPS_Data.dbo.encounterclaimdim e
				   	INNER JOIN EDS_Audit.dbo.EDS_Encounter_SourceDesc s
						ON	e.SourceDesc			= s.SourceDesc
						AND e.BeginServiceDateKey		BETWEEN startdate AND enddate
					INNER JOIN EDPS_Data.dbo.MonthlyMembershipDim mmd
						ON	mmd.MemberID			= e.MemberID
						AND e.BeginServiceDateKey	BETWEEN mmd.ModifiedReportDateKey - 14
													AND     mmd.ReportDateKey
					LEFT JOIN dbo.EDS_Claims_Master_Archive a 
						ON	a.claimid				= e.ClaimNum 
						AND a.sourcedatakey			= e.SourceDataKey 
						AND A.sourcedesc			= e.sourcedesc 
						AND A.memberid				= e.memberid
                   WHERE	1 = 1
                   AND	e.ClaimFrequencyCode	= '1' 
				   AND	e.BeginServiceDateKey	>= 20150101 
                   AND  e.sourcedatakey			= 4 
				   AND	e.ClaimLineNum			= 1		-- TETDM-2530
                   AND  a.claimid				IS NULL) sub
              WHERE sub.latest = 1
       )

	   INSERT  INTO reporting.EDS_Claims_Master 
		(claimid, sourcedatakey, CreationDate,Sourcedesc,memberid)
                 SELECT  DISTINCT 
                        c.ClaimNum , 
                        c.sourcedatakey , 
                        c.CreationDate, 
						c.Sourcedesc,
						C.memberid
                FROM    EncounterClaimBasket c 
-- end TETDM-1900

        SELECT  @TOTAL_RECORDS = COUNT(*)
        FROM    reporting.EDS_Claims_Master 

-- hold beginning record counts, to compare against the counts after data is deleted
        INSERT  INTO reporting.EDS_Claims_Master_Beginning_Counts
                SELECT  sourcedatakey ,
                        CreationDate ,
                        COUNT(*) AS SdkCount
                FROM    reporting.EDS_Claims_Master
                GROUP BY sourcedatakey ,
                        CreationDate
                ORDER BY sourcedatakey ,
                        CreationDate

-- update Run Controls
        UPDATE  dbo.EXT_SYS_RUNLOG
        SET     END_DT = GETDATE() ,
                RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
                TOTAL_RECORDS = @TOTAL_RECORDS ,
                ENTRYDT = GETDATE()
        WHERE   PROC_NAME = 'dbo.pr_EDS_Claims_Master_Monthly_Build'
                AND END_DT IS NULL
                AND STEP = '1'

-- build temp tables
        IF OBJECT_ID('TEMPDB..#hold_claims_to_remove') <> 0 
            DROP TABLE #hold_claims_to_remove

        IF OBJECT_ID('TEMPDB..#CignaAZCLaims') <> 0 
            DROP TABLE #CignaAZClaims

        IF OBJECT_ID('TEMPDB..#SPlanClaims') <> 0 
            DROP TABLE #SPlanClaims

        IF OBJECT_ID('TEMPDB..#CommercialClaims') <> 0 
            DROP TABLE #CommercialClaims

        IF OBJECT_ID('TEMPDB..#RXClaims') <> 0 
            DROP TABLE #RXClaims

        IF OBJECT_ID('TEMPDB..#PDPClaims') <> 0 
            DROP TABLE #PDPClaims

        CREATE TABLE #hold_claims_to_remove
            (
              BeforeOrAfter CHAR(15) ,
              sourcedatakey INT ,
              CType CHAR(20) ,
              TypeCount INT DEFAULT 0
            )

        CREATE TABLE #CignaAZClaims
            (
              sourcedatakey INT ,
              CType CHAR(20) ,
              TypeCount INT DEFAULT 0
            )	
		
        CREATE TABLE #SPlanClaims
            (
              sourcedatakey INT ,
              CType CHAR(20) ,
              TypeCount INT DEFAULT 0
            )

        CREATE TABLE #CommercialClaims
            (
              sourcedatakey INT ,
              CType CHAR(20) ,
              TypeCount INT DEFAULT 0
            )

        CREATE TABLE #RXClaims
            (
              sourcedatakey INT ,
              CType CHAR(20) ,
              TypeCount INT DEFAULT 0
            )

        CREATE TABLE #PDPClaims
            (
              sourcedatakey INT ,
              CType CHAR(20) ,
              TypeCount INT DEFAULT 0
            )

-----------------------------------------------------------------------------------
-- collect each of the Claim Type's record count into their respective temp tables
-----------------------------------------------------------------------------------
        INSERT  INTO dbo.EXT_SYS_RUNLOG
                ( PROC_NAME ,
                  STEP ,
                  START_DT ,
                  END_DT ,
                  RUN_MINUTES ,
                  TOTAL_RECORDS ,
                  ENTRYDT
                )
        VALUES  ( 'dbo.pr_EDS_Claims_Master_Monthly_Build' ,
                  '2' ,
                  GETDATE() ,
                  NULL ,
                  NULL ,
                  0 ,
                  GETDATE()
                )

-- Cigna AZ Claims
        INSERT  INTO #CignaAZClaims
                ( sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  sourcedatakey ,
                        'CignaAZClaims' AS CType ,
                        COUNT(*) AS TypeCount
                FROM    reporting.EDS_Claims_master
                WHERE   sourcedatakey = 40
                GROUP BY sourcedatakey

-- S Plan Claims
        INSERT  INTO #SPlanClaims
                ( sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  a.sourcedatakey ,
                        'SPlanClaims' AS CType ,
                        COUNT(*) AS TypeCount
                FROM    reporting.EDS_Claims_master a
                        INNER JOIN EDPS_Data.dbo.claimdim b ON b.claimid = a.claimid
                        INNER JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
                WHERE   lob.HCFACode LIKE 'S%'
                GROUP BY a.sourcedatakey
                ORDER BY a.sourcedatakey

-- Commercial Claims
        INSERT  INTO #CommercialClaims
                ( sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  a.sourcedatakey ,
                        'CommercialClaims' AS CType ,
                        COUNT(*) AS TypeCount
                FROM    reporting.EDS_Claims_master a
                        INNER JOIN EDPS_Data.dbo.claimdim b ON b.claimid = a.claimid
                        LEFT JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
                WHERE   ISNULL(lob.ProductType, '') = 'Commercial'
                        OR a.sourcedatakey = 3 -- TETDM-1146
                GROUP BY a.sourcedatakey
                ORDER BY a.sourcedatakey

-- RX Claims
        INSERT  INTO #RXClaims
                ( sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  a.sourcedatakey ,
                        'RXClaims' AS CType ,
                        COUNT(*) AS TypeCount
                FROM    reporting.EDS_Claims_master a
                        INNER JOIN EDPS_Data.dbo.claimdim b ON b.claimid = a.claimid
                        INNER JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
                WHERE   lob.ProductType = 'RX'
                GROUP BY a.sourcedatakey
                ORDER BY a.sourcedatakey

-- PDP Claims
        INSERT  INTO #PDPClaims
                ( sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  a.sourcedatakey ,
                        'PDPClaims' AS CType ,
                        COUNT(*) AS TypeCount
                FROM    reporting.EDS_Claims_master a
                        INNER JOIN EDPS_Data.dbo.claimdim b ON b.claimid = a.claimid
                        INNER JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
                WHERE   lob.ProductType = 'PDP'
                GROUP BY a.sourcedatakey
                ORDER BY a.sourcedatakey

-- 
        INSERT  INTO reporting.MonthlyRefreshClaimsCount
                ( BeforeOrAfter ,
                  sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  'BEFORE' AS BeforeOrAfter ,
                        sourcedatakey ,
                        CType ,
                        TypeCount
                FROM    #CignaAZClaims
                UNION
                SELECT  'BEFORE' AS BeforeOrAfter ,
                        sourcedatakey ,
                        CType ,
                        TypeCount
                FROM    #SPlanClaims
                UNION
                SELECT  'BEFORE' AS BeforeOrAfter ,
                        sourcedatakey ,
                        CType ,
                        TypeCount
                FROM    #CommercialClaims
                UNION
                SELECT  'BEFORE' AS BeforeOrAfter ,
                        sourcedatakey ,
                        CType ,
                        TypeCount
                FROM    #RXClaims
                UNION
                SELECT  'BEFORE' AS BeforeOrAfter ,
                        sourcedatakey ,
                        CType ,
                        TypeCount
                FROM    #PDPClaims

        SELECT  @TOTAL_RECORDS = COUNT(*)
        FROM    reporting.MonthlyRefreshClaimsCount

-- update Run Controls
        UPDATE  dbo.EXT_SYS_RUNLOG
        SET     END_DT = GETDATE() ,
                RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
                TOTAL_RECORDS = @TOTAL_RECORDS ,
                ENTRYDT = GETDATE()
        WHERE   PROC_NAME = 'dbo.pr_EDS_Claims_Master_Monthly_Build'
                AND END_DT IS NULL
                AND STEP = '2'

-- Now Delete the claims
        INSERT  INTO EXT_SYS_RUNLOG
                ( PROC_NAME ,
                  STEP ,
                  START_DT ,
                  END_DT ,
                  RUN_MINUTES ,
                  TOTAL_RECORDS ,
                  ENTRYDT
                )
        VALUES  ( 'dbo.pr_EDS_Claims_Master_Monthly_Build' ,
                  '3' ,
                  GETDATE() ,
                  NULL ,
                  NULL ,
                  0 ,
                  GETDATE()
                )

/*  HEADS UP!	--waller

There are cases where a claim can fit 2 categories.  
When this happens, the first category DELETE will remove the records.
The second category will attempt to delete the claim, but it
will already be gone.  So the records deleted will not always match up
to the counts taken and stored in the reporting.MonthlyRefreshCount table.

Here is an example of a claim that is a PDP claim, but is also an SPlan claim.

	select	lob.*
	from	reporting.EDS_Claims_master	a
	inner join	EDPS_Data.dbo.claimdim	b
		on	b.claimid	= a.claimid
	inner join	MDQOLib.dbo.LineofBusinessDim	lob	
		on	lob.LOBCode	= b.LOBCODE
	where	lob.HCFACode like 'S%'
	and		a.claimid = '13199E22606A1'
*/

-- remove Cigna AZ Claims
        DELETE  reporting.EDS_Claims_Master
        FROM    reporting.EDS_Claims_Master a
        WHERE   a.sourcedatakey = 40

-- remove SPlan Claims
        DELETE  reporting.EDS_Claims_Master
        FROM    reporting.EDS_Claims_Master a
                INNER JOIN dbo.claimdim b ON b.claimid = a.claimid
                INNER JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
        WHERE   lob.HCFACode LIKE 'S%'

-- remove Commercial Claims
        DELETE  reporting.EDS_Claims_Master
        FROM    reporting.EDS_Claims_Master a
                INNER JOIN dbo.claimdim b ON b.claimid = a.claimid
                LEFT JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
        WHERE   ISNULL(lob.ProductType, '') = 'Commercial'
                OR b.SOURCEDATAKEY = 3 -- TETDM-1146

-- remove RX Claims
        DELETE  reporting.EDS_Claims_Master
        FROM    reporting.EDS_Claims_Master a
                INNER JOIN dbo.claimdim b ON b.claimid = a.claimid
                INNER JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
        WHERE   lob.ProductType = 'RX'

-- remove PDP Claims
        DELETE  reporting.EDS_Claims_Master
        FROM    reporting.EDS_Claims_Master a
                INNER JOIN dbo.claimdim b ON b.claimid = a.claimid
                INNER JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
        WHERE   lob.ProductType = 'PDP'

---------------------------------------------------------------------
-- Now collect the AFTER record counts for each type and update the 
-- reporting.MonthlyRefreshClaimsCount table
---------------------------------------------------------------------
-- truncate the tables first to get rid of the BEFORE counts
        TRUNCATE TABLE #CignaAZClaims
        TRUNCATE TABLE #SPlanClaims
        TRUNCATE TABLE #CommercialClaims
        TRUNCATE TABLE #RXClaims
        TRUNCATE TABLE #PDPClaims

-- Cigna AZ Claims
        INSERT  INTO #CignaAZClaims
                ( sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  sourcedatakey ,
                        'CignaAZClaims' AS CType ,
                        COUNT(*) AS TypeCount
                FROM    reporting.EDS_Claims_master
                WHERE   sourcedatakey = 40
                GROUP BY sourcedatakey

-- S Plan Claims
        INSERT  INTO #SPlanClaims
                ( sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  a.sourcedatakey ,
                        'SPlanClaims' AS CType ,
                        COUNT(*) AS TypeCount
                FROM    reporting.EDS_Claims_master a
                        INNER JOIN dbo.claimdim b ON b.claimid = a.claimid
                        INNER JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
                WHERE   lob.HCFACode LIKE 'S%'
                GROUP BY a.sourcedatakey
                ORDER BY a.sourcedatakey

-- Commercial Claims
        INSERT  INTO #CommercialClaims
                ( sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  a.sourcedatakey ,
                        'CommercialClaims' AS CType ,
                        COUNT(*) AS TypeCount
                FROM    reporting.EDS_Claims_master a
                        INNER JOIN dbo.claimdim b ON b.claimid = a.claimid
                        LEFT JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
                WHERE   ISNULL(lob.ProductType, '') = 'Commercial'
                        OR b.sourcedatakey = 3 -- TETDM-1146
                GROUP BY a.sourcedatakey
                ORDER BY a.sourcedatakey

-- RX Claims
        INSERT  INTO #RXClaims
                ( sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  a.sourcedatakey ,
                        'RXClaims' AS CType ,
                        COUNT(*) AS TypeCount
                FROM    reporting.EDS_Claims_master a
                        INNER JOIN dbo.claimdim b ON b.claimid = a.claimid
                        INNER JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
                WHERE   lob.ProductType = 'RX'
                GROUP BY a.sourcedatakey
                ORDER BY a.sourcedatakey

-- PDP Claims
        INSERT  INTO #PDPClaims
                ( sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  a.sourcedatakey ,
                        'PDPClaims' AS CType ,
                        COUNT(*) AS TypeCount
                FROM    reporting.EDS_Claims_master a
                        INNER JOIN dbo.claimdim b ON b.claimid = a.claimid
                        INNER JOIN MDQOLib.dbo.LineofBusinessDim lob ON lob.LOBCode = b.LOBCODE
                WHERE   lob.ProductType = 'PDP'
                GROUP BY a.sourcedatakey
                ORDER BY a.sourcedatakey

-- 
        INSERT  INTO reporting.MonthlyRefreshClaimsCount
                ( BeforeOrAfter ,
                  sourcedatakey ,
                  CType ,
                  TypeCount
                )
                SELECT  'AFTER' AS BeforeOrAfter ,
                        sourcedatakey ,
                        CType ,
                        TypeCount
                FROM    #CignaAZClaims
                UNION
                SELECT  'AFTER' AS BeforeOrAfter ,
                        sourcedatakey ,
                        CType ,
                        TypeCount
                FROM    #SPlanClaims
                UNION
                SELECT  'AFTER' AS BeforeOrAfter ,
                        sourcedatakey ,
                        CType ,
                        TypeCount
                FROM    #CommercialClaims
                UNION
                SELECT  'AFTER' AS BeforeOrAfter ,
                        sourcedatakey ,
                        CType ,
                        TypeCount
                FROM    #RXClaims
                UNION
                SELECT  'AFTER' AS BeforeOrAfter ,
                        sourcedatakey ,
                        CType ,
                        TypeCount
                FROM    #PDPClaims

-- if there are no rows found for any of the above SELECT statements within the INSERT,
-- then all counts were down to zero, which is what you want.

        SELECT  @TOTAL_RECORDS = COUNT(*)
        FROM    reporting.MonthlyRefreshClaimsCount

-- update Run Controls
        UPDATE  dbo.EXT_SYS_RUNLOG
        SET     END_DT = GETDATE() ,
                RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
                TOTAL_RECORDS = @TOTAL_RECORDS ,
                ENTRYDT = GETDATE()
        WHERE   PROC_NAME = 'dbo.pr_EDS_Claims_Master_Monthly_Build'
                AND END_DT IS NULL
                AND STEP = '3'

----------------------------------------------------------------------------------
-- If you have made it this far, you have successfully collected the row counts,
-- deleted the specific claims, and verified that no claims were missed
--
-- Time to archive the WIPRO.dbo.EDS_Claims_Master data, truncate the table
-- and then populate it with the claim data we have left in 
-- reporting.EDS_Claims_Master
------------------------------------------------------------------------------
        INSERT  INTO dbo.EXT_SYS_RUNLOG
                ( PROC_NAME ,
                  STEP ,
                  START_DT ,
                  END_DT ,
                  RUN_MINUTES ,
                  TOTAL_RECORDS ,
                  ENTRYDT
                )
        VALUES  ( 'dbo.pr_EDS_Claims_Master_Monthly_Build' ,
                  '4' ,
                  GETDATE() ,
                  NULL ,
                  NULL ,
                  0 ,
                  GETDATE()
                )

        INSERT  INTO WIPRO.dbo.EDS_Claims_Master
			(claimid, sourcedatakey, CreationDate, Sourcedesc,memberid)
                SELECT  claimid, sourcedatakey, CreationDate, Sourcedesc,memberid
                FROM    reporting.EDS_Claims_Master

        INSERT  INTO WIPRO.dbo.EDS_Claims_Master_Controlled
			(claimid, sourcedatakey, CreationDate, Sourcedesc,memberid)
                SELECT claimid, sourcedatakey, CreationDate, Sourcedesc,memberid
                FROM    reporting.EDS_Claims_Master

        SELECT  @TOTAL_RECORDS = COUNT(*)
        FROM    WIPRO.dbo.EDS_Claims_Master

-- update Run Controls
        UPDATE  dbo.EXT_SYS_RUNLOG
        SET     END_DT = GETDATE() ,
                RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
                TOTAL_RECORDS = @TOTAL_RECORDS ,
                ENTRYDT = GETDATE()
        WHERE   PROC_NAME = 'dbo.pr_EDS_Claims_Master_Monthly_Build'
                AND END_DT IS NULL
                AND STEP = '4'
  
    END


