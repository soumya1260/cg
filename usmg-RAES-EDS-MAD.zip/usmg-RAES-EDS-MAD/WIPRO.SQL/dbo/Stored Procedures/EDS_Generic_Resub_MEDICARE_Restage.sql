﻿CREATE PROCEDURE [dbo].[EDS_Generic_Resub_MEDICARE_Restage]
/********************************************************************************************************************************************************************
Notes:
	This procedure is used exclusively by the SSIS package Generic_Submission_Export_RESUB_MEDICARE

	Initial Creation: 2024-09-24 ASU
	
	Modifications
	-------------
	2024-10-31	ASU
		RETM-793 removed denied field from loop table (caused duplicates)

*********************************************************************************************************************************************************************/
AS
UPDATE egrm
SET	Is_Missing = 1
FROM WIPRO.staging.EDS_Generic_Resub_Medicare egrm
WHERE NOT EXISTS (SELECT * 
				  FROM dbo.EDS_Claims_Processing ecp 
				  WHERE 1 = 1
						AND ecp.CLAIMID = egrm.CLAIMID 
						AND ecp.SOURCEDATAKEY = egrm.SOURCEDATAKEY);

WITH resub AS (
SELECT
	 ecp.CLAIMID
	,ecp.SOURCEDATAKEY
	,ENCOUNTERSOURCENAME = ISNULL(NULLIF(ecp.ENCOUNTERSOURCENAME,''), '')
FROM WIPRO.staging.EDS_Generic_Resub_Medicare ecp )
UPDATE ecp
SET ecp.ISRESUB = 1
FROM WIPRO.dbo.EDS_Claims_Processing ecp
WHERE 1 = 1
	AND EXISTS (SELECT * 
				FROM resub r 
				WHERE 1 = 1
					AND r.CLAIMID = ecp.CLAIMID 
					AND r.SOURCEDATAKEY = ecp.SOURCEDATAKEY 
					AND r.ENCOUNTERSOURCENAME = IIF(ecp.ISEncounter = 1, ecp.ENCOUNTERSOURCENAME,''));


EXEC EDIFECS.dbo.OSS_INST_SDO_to_CSV_MAP @IsResub = 1;
EXEC EDIFECS.dbo.OSS_PROF_SDO_to_CSV_MAP @IsResub = 1;


WITH resub AS (
SELECT
	 ecp.CLAIMID
	,ecp.SOURCEDATAKEY
	,ENCOUNTERSOURCENAME = ISNULL(NULLIF(ecp.ENCOUNTERSOURCENAME,''), '')
FROM WIPRO.staging.EDS_Generic_Resub_Medicare ecp
WHERE ecp.Is_Missing = 0)
SELECT DISTINCT
	ecp.CLAIM_TYPE
   ,ecp.LOB
   ,ecp.SOURCEDATAKEY
   ,ecp.ISADJUSTMENT
   ,ENCOUNTERSOURCENAME = IIF(ecp.ISEncounter = 0,NULL,ecp.ENCOUNTERSOURCENAME) 
   ,ecp.ISDME   
   ,IS_Resub = 1
   ,ID = IDENTITY(INT, 1,1)
INTO #resub_run_items
FROM WIPRO.dbo.EDS_Claims_Processing ecp
WHERE 1 = 1
	AND EXISTS (SELECT * 
				FROM resub r 
				WHERE 1 = 1
					AND r.CLAIMID = ecp.CLAIMID 
					AND r.SOURCEDATAKEY = ecp.SOURCEDATAKEY 
					AND r.ENCOUNTERSOURCENAME = IIF(ecp.ISEncounter = 1, ecp.ENCOUNTERSOURCENAME,'')
					);

DECLARE @count INT,
		@LOB VARCHAR(25),
		@ISDME BIT,
		@CLAIM_TYPE VARCHAR(20),		
		@SOURCEDATAKEY INT ,		
		@ISADJUSTMENT BIT,
		@ENCOUNTERSOURCENAME VARCHAR(120), --Optional, if not provided, only non-encounters pulled.
		@IsResub BIT; --Optional, if not provided, run regular claims;

WHILE EXISTS(SELECT * FROM #resub_run_items) BEGIN  
	SELECT TOP 1
		 @count = ID
		,@LOB = LOB
		,@ISDME = ISDME
		,@CLAIM_TYPE = CLAIM_TYPE
		,@SOURCEDATAKEY = SOURCEDATAKEY
		,@ISADJUSTMENT = ISADJUSTMENT
		,@ENCOUNTERSOURCENAME = ENCOUNTERSOURCENAME
		,@IsResub = IS_Resub
	FROM #resub_run_items;
	
	SELECT 1
	EXEC WIPRO.dbo.EDS_Claims_Processing_CSV_Insert @LOB = @LOB
												   ,@ISDME = @ISDME
												   ,@CLAIM_TYPE = @CLAIM_TYPE
												   ,@SOURCEDATAKEY = @SOURCEDATAKEY
												   ,@ISADJUSTMENT = @ISADJUSTMENT
												   ,@ENCOUNTERSOURCENAME = @ENCOUNTERSOURCENAME
												   ,@IsResub = @IsResub;
	
	
	DELETE 
	FROM #resub_run_items 
	WHERE ID = @count;

END;
