﻿CREATE PROCEDURE [dbo].[MMR_Non_Parsed_INSERT]
AS

--disable indexes for insert (won't disable clustered index)
EXEC dbo.utility_disable_enable_index @Table_Name = N'MMR_Non_Parsed'
									 ,@Schema = N'dbo';

--get light parsed data from stage minus items already inserted
WITH MMR_parse AS (
	SELECT
		mnp.File_Name,
		MBI = SUBSTRING(mnp.Data_Row,20,12),
		Contract_Number = SUBSTRING(mnp.Data_Row,1,5),
		Run_Date = CAST(SUBSTRING(mnp.Data_Row,6,8) AS DATE),
		Payment_Date = SUBSTRING(mnp.Data_Row,14,6),
		mnp.Data_Row
	FROM staging.MMR_Non_Parsed mnp
	WHERE NOT EXISTS (SELECT * FROM dbo.MMR_Non_Parsed mnp1 WHERE mnp1.File_Name = mnp.File_Name)
)
INSERT INTO dbo.MMR_Non_Parsed (FILE_NAME, MBI, Contract_Number, Run_Date, Payment_Date, Data_Row)
SELECT
	mp.File_Name
   ,mp.MBI
   ,mp.Contract_Number
   ,mp.Run_Date
   ,mp.Payment_Date
   ,mp.Data_Row
FROM MMR_parse mp;

--enable disabled indexes after load
EXEC dbo.utility_disable_enable_index @Table_Name = N'MMR_Non_Parsed'
									 ,@Schema = N'dbo'
									 ,@Enable = 1;


/*
	The below select statement is used in the SSIS package MOR_File_Import
	Any alterations to this statement will require an update to the SSIS package as well.
*/
SELECT
	mnp.File_Name,
	File_Record_Count = FORMAT(COUNT(*),'N0')	
FROM dbo.MMR_Non_Parsed mnp
WHERE EXISTS (SELECT * FROM staging.MMR_Non_Parsed mfn WHERE mfn.File_Name = mnp.File_Name) 
--compare dbo to stage to figure out what loaded for counts
GROUP BY mnp.File_Name;