﻿


/*********************************************************************************************************************************
-- =============================================
-- Author:		Sasi Tripuraneni
-- Create date: 08/19/2022
-- Description:	Filter each row of adhoc submission files to avoid error in processing of files.
--              THis is used with SSIS package EDS_AdhocSubmissionandRowFiltering.dtsx

	Modification History:
	DATE			Author				RTD			Description
	2022-08-19		SasiT			RETM-114	initial creation

-- =============================================

  -- execute adhoc_SUBMISSION_FilterBadRows

  *********************************************************************************************************************************/
  CREATE  PROCEDURE [dbo].[adhoc_SUBMISSION_FilterBadRows] 
  AS


SET NOCOUNT ON;



-- Check for any NULL or blank values
UPDATE e 
SET ErrorMessage = 'One or more columns is blank or NULL'
FROM Staging.Submission_ErrorData e
WHERE ISNULL(mem_id, '') = ''
		OR ISNULL(medicare_no, '') = ''
		OR ISNULL([plan], '') = ''
		OR ISNULL(prov_type, '') = ''
		OR ISNULL(dos_dt, '') = ''
		OR ISNULL(dos_thru_dt, '') = ''
		OR ISNULL(diagnosis_code, '') = ''
		OR ISNULL(clm_no, '') = ''
		OR ISNULL(clmsource, '') = ''
		OR ISNULL(icdversion, '') = ''
				

					
--one medicareno per memid  

UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; medicareno for mltiple members'
FROM Staging.Submission_ErrorData e
WHERE Id IN (SELECT Id FROM Staging.Submission_ErrorData
				WHERE medicare_no IN ( SELECT medicare_no FROM (SELECT mem_id, medicare_no 
																FROM Staging.Submission_ErrorData  
																GROUP BY  mem_id, medicare_no ) a
										GROUP BY medicare_no HAVING COUNT (*) > 1 ) )
	
-- dos_dt Date not valid format

UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Invalid dos_dt'
FROM Staging.Submission_ErrorData e
WHERE ISDATE(dos_dt ) = 0
      OR LEN(dos_dt) <> 8 OR CAST(SUBSTRING(dos_dt, 5, 2) AS INT ) NOT BETWEEN 1 AND 12  
	  OR CAST(SUBSTRING(dos_dt, 7, 2) AS INT ) NOT BETWEEN 1 and 31
	  OR dos_dt  NOT LIKE '[1-2][0-9][0-9][0-9][0-1][0-9][0-3][0-9]'
		 

--dos_thru_dt Date not valid format

UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Invalid dos_thru_dt'
FROM Staging.Submission_ErrorData e
WHERE ISDATE(dos_thru_dt ) = 0
		OR LEN(dos_thru_dt) <> 8 OR  CAST(SUBSTRING(dos_thru_dt, 5, 2) AS INT ) NOT BETWEEN 1 and 12  
		OR CAST(SUBSTRING( dos_thru_dt, 7, 2) AS INT ) NOT BETWEEN 1 and 31
		OR  dos_thru_dt NOT LIKE '[1-2][0-9][0-9][0-9][0-1][0-9][0-3][0-9]'

-- prov_type validation

UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Invalid Prov_Type'
FROM Staging.Submission_ErrorData e
WHERE prov_type NOT IN ( '01','02','10','20')
				

-- diagnosis_code validation

UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Invalid diagnosis_code'
FROM Staging.Submission_ErrorData e
WHERE diagnosis_code LIKE '%.%'		

UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Invalid diagnosis_code'
FROM Staging.Submission_ErrorData e
WHERE LEN(diagnosis_code) NOT BETWEEN 3 AND 7

--Claim has more than one MemID


UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Claim for mltiple members'
FROM Staging.Submission_ErrorData e
WHERE Id IN (SELECT Id FROM Staging.Submission_ErrorData
				WHERE clm_no IN ( SELECT clm_no FROM (SELECT mem_id, clm_no 
																FROM Staging.Submission_ErrorData  
																GROUP BY  mem_id, clm_no ) a
										GROUP BY clm_no HAVING COUNT (*) > 1 ) )	
											
						

--DATE RANGE IS OFF, DOSDATE BIGGER THAN ENDDATE

UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Invalid dos dates'
FROM Staging.Submission_ErrorData e
WHERE DOS_DT > dos_thru_dt 

				
--DATE RANGE VS ICD 9 0R ICD 10

UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Invalid dos dates'
FROM Staging.Submission_ErrorData e
WHERE ((dos_thru_dt >= '20151001' AND icdversion <> '10') 
		OR (dos_thru_dt < '20151001' AND icdversion <> '9'  ))
				
				
 -- DOS check for 2 years 
 
--UPDATE e 
--SET ErrorMessage = ISNULL(ErrorMessage,'') + ' Invalid dos_thru_dt date'
--FROM Staging.Submission_ErrorData e
--WHERE DATEDIFF(YEAR,DOS_THRU_DT,GETDATE()) > 2
	
-- claim format check
UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Invalid claim format'
FROM Staging.Submission_ErrorData e
WHERE CLM_NO LIKE '%[^_a-Z0-9]%' -- Data should only be Alpha Numeric

-- plan format check
UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Invalid plan'
FROM Staging.Submission_ErrorData e
WHERE LEN([PLAN]) > 5

/*				
--•Hplan is only a valid hplan for CHS (compare to table) ****USE [RAPS_Submissions].[dbo].[Raps_Plans]


/*SELECT * from ##TMPbULKRET a left join 
[RAPS_Submissions].[dbo].[Raps_Plans]  b on
a.[plan] =b.plan_id
WHERE  b.plan_id is null
*/

		
--•sourcedesc not consistent with crosswalk TABLE (Create table)colored text ***USE [RAPS].[DBO].[RAPS_SOURCE_SOURCE_DESC_TYPE]****
 
 /*
 SELECT * from ##TMPbULKRET a left join 
 [RAPS].[DBO].[RAPS_SOURCE_SOURCE_DESC_TYPE] b on
REPLACE ( a.clmsource, '_RET', '')  =b.SOURCEDESC WHERE  b.SOURCEDESC is null


*/
--- SELECT * from [RAPS].[DBO].[RAPS_SOURCE_SOURCE_DESC_TYPE]  where SOURCEDESC ='leon'


				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
				SELECT cast (BulkInsId AS INT )  , @FilName, @filetype, 
				 Column0,
				 15 , SYSTEM_USER from BulkInsertContainer 
				 WHERE BulkInsId IN 
					(SELECT BulkInsId FROM ##TMPbULKRET a left join 
					[RAPS].[DBO].[RAPS_SOURCE_SOURCE_DESC_TYPE] b 
					on b.source = CASE WHEN  @filetype = 'CHSRAPR.'  THEN '990' ELSE '980' END -- 2 years for submissions 980 for retraction 990 
					AND (  a.clmsource  = b.SOURCEDESC
							OR a.clmsource  = b.originated )
					 WHERE  b.SOURCEDESC is null )  
					--a.clmsource=b.SOURCEDESC WHERE  b.SOURCEDESC is null )    */

-- provider NPI check it can be blank or number, can't have letters


UPDATE e 
SET ErrorMessage = ISNULL(ErrorMessage,'') + '; Invalid PROVIDERNPI'
FROM Staging.Submission_ErrorData e
WHERE ISNUMERIC(CASE WHEN LEN(LTRIM(RTRIM(PROVIDERNPI))) = 0 THEN '0' 
						ELSE REPLACE(LTRIM(RTRIM(ISNULL(PROVIDERNPI,'0'))),'','0') END) = 0 

DELETE FROM Staging.Submission_ErrorData
WHERE ErrorMessage IS NULL

SELECT COUNT(*) AS BadRowCount
FROM Staging.Submission_ErrorData