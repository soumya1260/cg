﻿


CREATE  PROCEDURE [dbo].[BUILD_OUTB_PROF_DIAG_POINTERS_FACETS_ICD10]
AS
/***************************************************************************************************
** CREATE DATE: 06/2012
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM HEADER 
**              AND LINE LEVE DIAGNOSIS POINTER INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation		
2016-02-08		Loyal Ricks		Facets ICD10 Adjustment temporary fix while BIDW changes are made
								to the claimdetaildiagnosisdim table to remove additional decimals
								from the daignosis code fields 																		    
*****************************************************************************************************/	
--UPDATE DIAGNOSIS POINTERS
		--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT
--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_PROF_DIAG_POINTERS_FACETS_ICD10'
				,'5'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
		
		--UPDATE PRIMARY DIAG_CD
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET PRIM_DIAG_CD = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.PRIM_DIAG_CD = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET PRIM_DIAG_CD = REPLACE(PRIM_DIAG_CD,0,'')
			FROM OUTB_PROF_DETAIL 
			WHERE SUBSTRING(PRIM_DIAG_CD,1,1) = '0'
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD2
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD2 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD2 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		
		----HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD2 = REPLACE(DIAG_CD2,0,'')
			FROM OUTB_PROF_DETAIL 
			WHERE SUBSTRING(DIAG_CD2,1,1) = '0'
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD3
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD3 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD3 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30

		----HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD3 = REPLACE(DIAG_CD3,0,'')
			FROM OUTB_PROF_DETAIL 
			WHERE SUBSTRING(DIAG_CD3,1,1) = '0'
				
		----UPDATE DIAG_CD4
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD4 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD4 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30

		----HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD4 = REPLACE(DIAG_CD4,0,'')
			FROM OUTB_PROF_DETAIL 
			WHERE SUBSTRING(DIAG_CD4,1,1) = '0'
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD5
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD5 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD5 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD5 = REPLACE(DIAG_CD5,0,'')
			FROM OUTB_PROF_DETAIL 
			WHERE SUBSTRING(DIAG_CD5,1,1) = '0'
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD6
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD6 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD6 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
				

		----HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD6 = REPLACE(DIAG_CD6,0,'')
			FROM OUTB_PROF_DETAIL 
			WHERE SUBSTRING(DIAG_CD6,1,1) = '0'
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD7
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD7 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD7 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30

		----HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD7 = REPLACE(DIAG_CD7,0,'')
			FROM OUTB_PROF_DETAIL 
			WHERE SUBSTRING(DIAG_CD7,1,1) = '0'
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD8
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD8 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD8 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD8 = REPLACE(DIAG_CD8,0,'')
			FROM OUTB_PROF_DETAIL 
			WHERE SUBSTRING(DIAG_CD8,1,1) = '0'
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD9
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD9 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD9 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD9 = REPLACE(DIAG_CD9,0,'')
			FROM OUTB_PROF_DETAIL 
			WHERE SUBSTRING(DIAG_CD9,1,1) = '0'
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD10
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD10 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD10 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD11
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD11 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD11 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30

		----UPDATE DIAG_CD12
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD12 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD12 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD13
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD13 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD13 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD14
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD14 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD14 = REPLACE(CDD.diagnosiscode,'.','')
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD15
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD15 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD15 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD16
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD16 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD16 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30	
		----UPDATE DIAG_CD17
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD17 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD17 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD18
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD18 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD18 = REPLACE(CDD.diagnosiscode,'.','')
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD19
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD19 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD19 = REPLACE(CDD.diagnosiscode,'.','')
		--		IF @@ERROR <> 0 
		--		begin
		--		rollback 
		--	end
		--commit
		----UPDATE DIAG_CD20
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD20 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD20 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD21
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD21 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD21 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD22
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD22 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD22 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD23
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD23 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD23 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD24
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD24 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD24 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD25
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD25 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD25 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD26
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD26 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD26 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		----UPDATE DIAG_CD27
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD27 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD27 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		--UPDATE DIAG_CD28
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD28 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD28 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30	
		--UPDATE DIAG_CD29
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD29 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD29 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		--UPDATE DIAG_CD30
		--BEGIN TRANSACTION
			UPDATE OUTB_PROF_DETAIL
			SET DIAG_CD30 = CDD.Sequence
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.ClaimID
				AND ECD.DIAG_CD30 = REPLACE(CDD.diagnosiscode,'.','')
				and ECD.sourcedatakey = 30
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_DETAIL)
		----HRP_CLAIM_FILE Update Run Controls
				--BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_PROF_DIAG_POINTERS_FACETS_ICD10'
								AND END_DT IS NULL
						--	IF @@ERROR <> 0
						--				BEGIN 
						--						ROLLBACK 
						--				END
						--COMMIT

