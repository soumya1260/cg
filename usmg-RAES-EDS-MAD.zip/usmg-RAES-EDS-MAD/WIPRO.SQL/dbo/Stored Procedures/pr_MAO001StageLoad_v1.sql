﻿CREATE PROCEDURE [dbo].[pr_MAO001StageLoad_v1]
(
	@InboundFileName				VARCHAR(256) = 'Undefined'
)
AS

/**********************************************************************************************
PROCEDURE:	
PURPOSE:	Load the four MAO-001 Staging tables from the raw data records
			imported into Staging.staging.cms_mao_004_Raw



Date				Author				Description
------------------------------------------------------------------------------------------------
Feb 03 2021			Subhash Acharya		Initial Creation
				

*************************************************************************************************/




	SET NOCOUNT ON;

	DECLARE @CatchErrorMessage VARCHAR(2200);

	DECLARE	@DTStamp DATETIME = GETDATE(),
			@SourceDataKey INT,
			@SourceDesc varchar(60)
				


	IF OBJECT_ID('TEMPDB..#tempHeader') <> 0
		DROP TABLE #tempHeader

 
	IF OBJECT_ID('TEMPDB..#tempDetail') <> 0
		DROP TABLE #tempDetail
 
	IF OBJECT_ID('TEMPDB..#tempTrailer') <> 0
		DROP TABLE #tempTrailer
 
	TRUNCATE TABLE WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail
	TRUNCATE TABLE WIPRO_Staging.staging.TEMP_CMS_MAO_001_Header
	TRUNCATE TABLE WIPRO_Staging.staging.TEMP_CMS_MAO_001_Trailer


--SELECT * FROM	staging.cms_mao_004_Raw	0 1 9


--DROP TABLE #tempHeader

BEGIN TRY
	--
	--	Process Header Record
	--
	 ;WITH cteSplitColumn AS
	(
	SELECT
		j.MAO001ID,
		split.ItemNumber, 
		RTRIM(LTRIM(REPLACE(split.Item, '*', ''))) AS 'Item'	--	Get rid of End of Line character...
	FROM
		WIPRO_Staging.staging.cms_mao_001_Raw			j
	CROSS APPLY
		dbo.DelimitedSplit8K(j.[RawDataRow], '*') split
	WHERE
		LEFT(j.[RawDataRow], 1) = '0'		
	)
	SELECT * 
	INTO #tempHeader
	FROM cteSplitColumn

--SELECT * FROM #tempHeader

--SELECT * FROM staging.TEMP_CMS_MAO_001_Header

--DECLARE @InboundFileName VARCHAR(250) SET @InboundFileName = 'H7811.MAO00433.D181116.T1600570'
	
	INSERT INTO 
		WIPRO_Staging.staging.TEMP_CMS_MAO_001_Header
				( 
				  [InboundFileName]	
				, [RecordType]		
				, [ReportID]			
				, [ReportDate]		
				, [ReportDescription] 
				, [SubmissionInterchangeNo] 
				, [SubmissionFileType]		
				, [Claimtype]					
				)
		SELECT
				@InboundFileName,
				CASE when [RecordType] = '0' THEN 'H' END,
				x.[ReportID] ,
				x.[ReportDate] ,
				x.[ReportDescription] ,
				x.[SubmissionInterchangeNo] ,
				x.[SubmissionFileType] ,
				x.[Claimtype] 
		FROM			
	(
		SELECT	
		[RecordType] = (SELECT TOP 1 Item FROM #tempHeader WHERE ItemNumber = 1),
		[ReportID] = (SELECT TOP 1 Item FROM #tempHeader WHERE ItemNumber = 2),
		[ReportDate] = (SELECT TOP 1 Item FROM #tempHeader WHERE ItemNumber = 3),
		[ReportDescription] = (SELECT TOP 1 Item FROM #tempHeader WHERE ItemNumber = 5),
		[SubmissionInterchangeNo] = (SELECT TOP 1 Item FROM #tempHeader WHERE ItemNumber = 7),
		[SubmissionFileType] = (SELECT TOP 1 Item FROM #tempHeader WHERE ItemNumber = 9),
		[Claimtype] = (SELECT TOP 1 Item FROM #tempHeader WHERE ItemNumber = 8)
		
	)		x

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

/*

BEGIN TRY
	--
	--	Process FileStatus Record
	--
	;WITH cteSplitColumn AS
	(
	SELECT
		j.MAO002ID,
		split.ItemNumber, 
		RTRIM(LTRIM(REPLACE(split.Item, '*', ''))) AS 'Item'	--	Get rid of End of Line character...
	FROM
		staging.MAO002Raw			j
	CROSS APPLY
		dbo.DelimitedSplit8K(j.[RawDataRow], '*') split
	WHERE
		LEFT(j.[RawDataRow], 1) = 'F'		
	)
	SELECT * 
	INTO #tempFileStatus
	FROM cteSplitColumn

	INSERT INTO
		staging.TEMP_MAO_002_FileStatus
					( InboundFileName ,
				  FileID ,
				  RecordType ,
				  ClaimsReceived ,
				  ClaimsAccepted ,
				  ClaimsRejected ,
				  CMSTransactionDate	-- Scott Waller March 2014
				)
	SELECT 	        

				@InboundFileName,
				(SELECT TOP 1 FileID FROM staging.TEMP_MAO_002_Header),
				'F',
				x.ClaimsReceived,
				x.ClaimsAccepted,
				x.ClaimsRejected,
				x.CMSTransactionDate	-- Scott Waller March 2014
				
		FROM			
	(
		SELECT	
		ClaimsReceived = (SELECT TOP 1 Item FROM #tempFileStatus WHERE ItemNumber = 2),
		ClaimsAccepted = (SELECT TOP 1 Item FROM #tempFileStatus WHERE ItemNumber = 3),
		ClaimsRejected = (SELECT TOP 1 Item FROM #tempFileStatus WHERE ItemNumber = 4),
		CMSTransactionDate = (SELECT TOP 1 Item FROM #tempFileStatus WHERE ItemNumber = 5)  -- Scott Waller March 2014
	) x
		

	
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

*/

--SELECT * FROM #tempTrailer

--DROP TABLE #tempTrailer

--SELECT * FROM staging.TEMP_CMS_MAO_004_Trailer

BEGIN TRY
	--
	--	Process Trailer Record
	--


	;WITH cteSplitColumn AS
	(
	SELECT
		j.MAO001ID,
		split.ItemNumber, 
		RTRIM(LTRIM(REPLACE(split.Item, '*', ''))) AS 'Item'	--	Get rid of End of Line character...
	FROM
		WIPRO_Staging.staging.cms_mao_001_Raw			j
	CROSS APPLY
		dbo.DelimitedSplit8K(j.[RawDataRow], '*') split
	WHERE
		LEFT(j.[RawDataRow], 1) = '9'		
	)
	SELECT * 
	INTO #tempTrailer
	FROM cteSplitColumn

--SELECT * FROM #tempTrailer

--DECLARE @InboundFileName VARCHAR(250) SET @InboundFileName = 'H7811.MAO00433.D181116.T1600570'

	INSERT INTO
		WIPRO_Staging.staging.TEMP_CMS_MAO_001_Trailer
		        ( 
				  [InboundFileName] 
				, [RecordType]      
				, [ReportID] 
				, [LinesRej] 
				, [LinesSub] 
				, [TotalEncSub]
		        )
	SELECT 	        
				@InboundFileName,
				CASE WHEN x.RecordType = '9' THEN 'T' END,
				x.ReportID,
				cast(x.[LinesRej] as int),
				cast(x.[LinesSub] as int),
				cast([TotalEncSub]as int)
				--CASE WHEN TRY_CONVERT(INT,x.TotalRecords) != 0 THEN TRY_CONVERT(INT,x.TotalRecords) ELSE x.TotalRecords END
		FROM			
	(
		SELECT	
		RecordType = (SELECT TOP 1 Item FROM #tempTrailer WHERE ItemNumber = 1),
		ReportID = (SELECT TOP 1 Item FROM #tempTrailer WHERE ItemNumber = 2),
		[LinesRej] = (SELECT TOP 1 Item FROM #tempTrailer WHERE ItemNumber = 3),
		[LinesSub] = (SELECT TOP 1 Item FROM #tempTrailer WHERE ItemNumber = 4),
		[TotalEncSub] = (SELECT TOP 1 Item FROM #tempTrailer WHERE ItemNumber = 5)
	) x


/*
select * from 
staging.TEMP_CMS_MAO_001_Trailer

*/


END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY
	--
	--	Process Detail Records
	--
	;WITH cteSplitColumn AS
	(
	SELECT
		j.MAO001ID,
		split.ItemNumber, 
		RTRIM(LTRIM(REPLACE(split.Item, '*', ''))) AS 'Item'	--	Get rid of End of Line character...
	FROM
		WIPRO_Staging.staging.cms_mao_001_Raw			j
	CROSS APPLY
		dbo.DelimitedSplit8K(j.[RawDataRow], '*') split
	WHERE
		LEFT(j.[RawDataRow], 1) IN ('1')		
	)
	SELECT * 
	INTO #tempDetail
	FROM cteSplitColumn
	
	CREATE NONCLUSTERED INDEX tIndex ON #tempDetail (MAO001ID ASC, ItemNumber ASC)

/*
drop table #tempDetail

SELECT * FROM staging.cms_mao_004_Raw		

SELECT * FROM #tempDetail

SELECT * FROM staging.TEMP_MAO_002_Detail

SELECT * FROM staging.TEMP_CMS_MAO_001_Detail

select * from wipro..CMS_MAO_004_detail

select * from staging.cms_mao_004_Raw	

TRUNCATE TABLE staging.TEMP_CMS_MAO_001_Detail

*/


--	Init each detail record, populating the RecordType 
/*
 [DetailID] 
,[InboundFileName]	
,[RecordType]		
,[ReportID]			
,[HPLAN]        
,[Source]	   
,[EncounterID]  
,[ClaimId]	   
,[EncounterICN] 
,[EncLineNumber]
,[DupPlanEncID]		
,[DupClaimId]		
,[DupPlanEncICN]		
,[DupEncLineNumber]	
,[MBI]				
,[DOS]				
,[ErrorCode]			
*/



--DECLARE @InboundFileName VARCHAR(250) SET @InboundFileName = 'H7811.MAO00433.D181116.T1600570'
	INSERT INTO
			WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail
					(  
					  DetailID	,
					  InboundFileName ,
					  RecordType 
					)
	SELECT
		MAO001ID,
		@InboundFileName,
		'D'
	FROM
		#tempDetail
	WHERE	
		ItemNumber = 1		        

/*

SELECT * FROM staging.TEMP_CMS_MAO_001_Detail	        
	--
	--	Update remaining Detail columns
	--

SELECT * FROM #tempDetail		

*/
		
    UPDATE  d
    SET     ReportID = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 2;


    UPDATE  d
    SET     d.HPLAN = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 3;
		
   UPDATE  d
    SET     d.EncounterID = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 4;

	

    Update WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail
	SET Sourcedatakey = 
			   case when EncounterID like '50%' THEN '50'
			        when EncounterID like '51%' THEN '50'
					when EncounterID like '52%' THEN '50'
			        when EncounterID like '30%' THEN '30'
				    when EncounterID like '41%' THEN '4'
				    when EncounterID like '43%' THEN '4'
				    when EncounterID like '44%' THEN '4'
				    when EncounterID like '44%' THEN '4'
				    when EncounterID like 'U%' THEN  '88' 
				    when EncounterID like 'L%' THEN  '99' 
				    when EncounterID like 'V%' THEN  '55'
				    when EncounterID like 'D%' THEN  '30'
					when EncounterID like 'E%' THEN  '50'
					when EncounterID like 'C%' THEN  '4'
					when EncounterID like '40%' THEN  '40'
					when EncounterID like '210%' THEN  '210'
					END


    Update WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail
	SET ClaimId = 
			   case when EncounterID like 'U%' THEN  LEFT(EncounterID, len(EncounterID) -2)
				    when EncounterID like 'L%' THEN  LEFT(EncounterID, len(EncounterID) -2) 
				    when EncounterID like 'V%' THEN  LEFT(EncounterID, len(EncounterID) -2)

				    when EncounterID like 'E%' THEN  EncounterID
					when EncounterID like 'D%' THEN  EncounterID
					when EncounterID like 'C%' THEN  EncounterID
				    
					when HPLAN = 'H0354' and EncounterID like '210%' then Substring(EncounterID,4,len(EncounterID) -5)

					ELSE Substring(EncounterID,3,len(EncounterID) -4)
					END
			


    UPDATE  d
    SET     d.EncounterICN = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 5;



	   UPDATE  d
    SET     d.EncLineNumber = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 6;


    UPDATE  d
    SET     d.DupPlanEncID = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 7;



	Update WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail
	SET DupClaimID = 
			   case when DupPlanEncID like 'U%' THEN  LEFT(DupPlanEncID, len(DupPlanEncID) -2)
				    when DupPlanEncID like 'L%' THEN  LEFT(DupPlanEncID, len(DupPlanEncID) -2) 
				    when DupPlanEncID like 'V%' THEN  LEFT(DupPlanEncID, len(DupPlanEncID) -2)
				    
					when DupPlanEncID like 'E%' THEN  DupPlanEncID
					when DupPlanEncID like 'D%' THEN  DupPlanEncID
					when DupPlanEncID like 'C%' THEN  DupPlanEncID
					
					when HPLAN = 'H0354' and EncounterID like '40%' then DupPlanEncID
					when HPLAN = 'H0354' and EncounterID like '210%' then Substring(DupPlanEncID,4,len(DupPlanEncID) -5)
					
					ELSE Substring(DupPlanEncID,3,len(DupPlanEncID) -4)
					END
		


    UPDATE  d
    SET     d.DupPlanEncICN = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 8;
    
	
	UPDATE  d
    SET     d.DupEncLineNumber = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 9;
	
    UPDATE  d
    SET     d.MBI = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 10; 

    UPDATE  d
    SET     d.DOS = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 11;

    UPDATE  d
    SET     d.ErrorCode = t.Item
	--SELECT t.Item,* 
    FROM    WIPRO_Staging.staging.TEMP_CMS_MAO_001_Detail d
            INNER JOIN #tempDetail t ON d.DetailID = t.MAO001ID
                                        AND t.ItemNumber = 12;







--SELECT * FROM  staging.TEMP_CMS_MAO_001_Detail



END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

-- Scott Waller March 2014
-- call the new validation stored proc
	--EXEC staging.pr_MAO002Validation_v3 @InboundFileName

-- end

	IF OBJECT_ID('TEMPDB..#tempHeader') <> 0
		DROP TABLE #tempHeader

	IF OBJECT_ID('TEMPDB..#tempFileStatus') <> 0
		DROP TABLE #tempFileStatus
 
	IF OBJECT_ID('TEMPDB..#tempDetail') <> 0
		DROP TABLE #tempDetail
 
	IF OBJECT_ID('TEMPDB..#tempTrailer') <> 0
		DROP TABLE #tempTrailer
 

/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()

BEGIN TRANSACTION

	EXEC [staging].[pr_MAO002StageLoad]
		@InboundFileName = 'MyInbound_MAO-002_File.MAO002'
		
ROLLBACK TRANSACTION

SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/
GO

