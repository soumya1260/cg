﻿CREATE PROCEDURE [dbo].[pr_BUILD_PROF_DME]
(@jobid int)

AS
/***************************************************************************************************
** CREATE DATE: 08/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE will identify compiled DME claims and reomve them from current outbound
**				Professional claim file. Procedure will also update EXT_EDPS_CLAIM_STATUS table 
**				CLAIM_TYPE to "E" (DME). 
**				Procedure will also temporarily append DME claimid to exclusion history to prevent 
**				future submissions during WIPRO development of required DME logic. 
**				Remove Exclusion History append once WIPRO logic is in place. 
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
08/17/16		Loyal Ricks		Remove exclusion tracking of claims identified as DME. Continue to 
								identify DME claims in order to support DME submissions. Add @jobid 
								as input parameter to support the removal of any known DME claims from 
								outbound professional claim files. 
11/05/2018      Henry Faust	    TETDM-1783 create way to rerun DME claims TESTID 2020-2028
04/19/2024		Anthony Ulmer	RETM-575 Update to make DME table insert columns explicit
*****************************************************************************************************/	
--DECLARE VARIABLES

			DECLARE
			
			@TOTAL_RECORDS INT
		

--HRP_CLAIM_FILE Run controls
			
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_BUILD_PROF_DME'
							,'12'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
				
			
			begin 
				set @TOTAL_RECORDS =(select count(*) from OUTB_PROF_HEADER WHERE CLAIM_TYPE ='E')
			END


INSERT INTO dbo.EXT_CLAIM_DME 
(CLAIMID, VENDORID, vendornpi, PROVIDERID, PROVIDERNPI, 
SourceDataKey, VENDOR_TAXONOMY_CD, PROVIDER_TAXONOMY_CD, CLAIM_TYPE)
SELECT CLAIM_ID
		,BILL_PROV_GRP_ID
		,BILL_PROV_GRP_NPI
		,BILL_PROV_ID
		,BILL_PROV_NPI
		,PH.SOURCEDATAKEY
		,BILL_PROV_TAXONOMY_CD
		,BILL_PROV_TAXONOMY_CD
		,PH.CLAIM_TYPE
FROM OUTB_PROF_HEADER PH
LEFT OUTER JOIN EXT_CLAIM_DME CD
ON PH.SOURCEDATAKEY = CD.SOURCEDATAKEY
AND PH.CLAIM_ID = CD.CLAIMID
WHERE PH.CLAIM_TYPE ='E'
	AND CD.CLAIMID IS NULL

	----Remove logging to exclusions for all DME claims. Do not log to exclusion any longer because these claims should get submitted. 
----Add claim to exclusion history
--INSERT INTO EXT_CLAIM_EXCLUSION_HIST
--SELECT OP.CLAIM_ID,OP.SOURCEDATAKEY,GETDATE(),9999,OP.CLAIM_TYPE
--FROM OUTB_PROF_HEADER OP 
----left outer join EXT_CLAIM_EXCLUSION_HIST EH
----ON OP.SOURCEDATAKEY = EH.SOURCEDATAKEY 
----AND OP.CLAIM_ID = EH.CLAIM_ID 
--WHERE  OP.CLAIM_TYPE = 'E'
----AND EH.CLAIM_ID IS NULL 

--tetdm-1846
		if @jobid <> 2 AND @jobid NOT BETWEEN 2020 AND 2028

			begin 
-----MANUALLY REMOVE DME CLAIMS AS NEEDED

				DELETE FROM OUTB_PROF_DETAIL
				WHERE CLAIM_ID IN (SELECT CLAIM_ID  FROM OUTB_PROF_HEADER 
				WHERE CLAIM_TYPE = 'E')

				DELETE FROM OUTB_PROF_HEADER 
				WHERE CLAIM_TYPE = 'E'
			end

						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_PROF_DME' 
										and END_DT is null
							



