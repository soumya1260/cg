﻿


CREATE PROCEDURE [dbo].[EXSP_WIPRO_A_277_Historical_CleanUp]
AS
/***************************************************************************************************
** CREATE DATE: 09/22/2018
**
** AUTHOR: Subhash Acharya
**
** DESCRIPTION: Procedure will update the OUTB_CLAIM_STATUS from historical Table.
**				
** Sample invocation: Exec [dbo].[EXSP_WIPRO_A_277_Historical_CleanUp]
**
**
Modification History
=========================================================================
Date			Author				  Description
09/22/2018		Subhash Acharya		  This is created as part of 1894 --1810

-----------------------------------------------------------------------------------------------------
*****************************************************************************************************/	

IF OBJECT_ID('dbo.OUTB_CLAIM_STATUS_Backup_1894', 'U') IS NULL 

BEGIN

CREATE TABLE [dbo].[OUTB_CLAIM_STATUS_Backup_1894]
			(
			[CLAIM_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLAIM_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FILEID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLM_IND] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SOURCEDATAKEY] [int] NULL,
			[MEMBER_ID] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[HICN_NUM] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[BILL_PROV_GRP_ID] [char] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[BILL_PROV_ID] [char] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REF_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REF_PCP_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[ATTN_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLMSTAT_STATUS] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_CLM_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[WIPRO_CLAIM_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CMS_ICN] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_FATAL_ERR_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_REJ_REA_ID] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REJ_REA_MSG] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[LINE_SEQ_NO] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[OTH_PAYER_ID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_TYPE] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SUBTYPE] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_SUB_QUAL] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_POS] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_ERR] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[VAL_ERR] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FILEDATE] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[LAST_UPD_DATE] [datetime] NULL,
			[DOS_MONTH] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SecondaryPlanClaimNumber] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[EffectiveEncounterFlag] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[OriginalPlanClaimID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
			) ON [PRIMARY]


END


IF OBJECT_ID('dbo.OUTB_CLAIM_STATUS_Backup_1894', 'U') IS NOT NULL 

BEGIN

	IF (SELECT COUNT(*) FROM dbo.OUTB_CLAIM_STATUS_Backup_1894) <> 
							(SELECT COUNT(*) FROM dbo.OUTB_CLAIM_STATUS)
	  BEGIN
		
		--PRINT 'Need to DROP and Reload the Table'
		
		DROP TABLE OUTB_CLAIM_STATUS_Backup_1894; 
		
		CREATE TABLE [dbo].[OUTB_CLAIM_STATUS_Backup_1894]
			(
			[CLAIM_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLAIM_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FILEID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLM_IND] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SOURCEDATAKEY] [int] NULL,
			[MEMBER_ID] [char] (80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[HICN_NUM] [char] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[BILL_PROV_GRP_ID] [char] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[BILL_PROV_ID] [char] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REF_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REF_PCP_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[ATTN_PROV_ID] [char] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CLMSTAT_STATUS] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_CLM_TYPE] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[WIPRO_CLAIM_ID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[CMS_ICN] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_FATAL_ERR_FLAG] [varchar] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[STAT_REJ_REA_ID] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[REJ_REA_MSG] [varchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[LINE_SEQ_NO] [varchar] (4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[OTH_PAYER_ID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_TYPE] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SUBTYPE] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_SUB_QUAL] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_POS] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FIELD_ERR] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[VAL_ERR] [varchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[FILEDATE] [varchar] (14) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[LAST_UPD_DATE] [datetime] NULL,
			[DOS_MONTH] [varchar] (6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[SecondaryPlanClaimNumber] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[EffectiveEncounterFlag] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
			[OriginalPlanClaimID] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
			) ON [PRIMARY]
		
			--Back up Table [WIPRO].[dbo].[OUTB_CLAIM_STATUS_Backup_1894]
			
			INSERT INTO [dbo].[OUTB_CLAIM_STATUS_Backup_1894]
			SELECT  * FROM [dbo].[OUTB_CLAIM_STATUS]
			
			

	  END 		
	END

IF (SELECT COUNT(*) FROM dbo.OUTB_CLAIM_STATUS_Backup_1894) = 
							(SELECT COUNT(*) FROM dbo.OUTB_CLAIM_STATUS)

BEGIN
--UPdate 

UPDATE  c
SET     c.CLMSTAT_STATUS = 'A-277'
--select * 
FROM    dbo.OUTB_CLAIM_STATUS AS c
        INNER JOIN ( SELECT CLAIM_ID ,
                            MAX(LAST_UPD_DATE) AS MAXdate
                     FROM   dbo.OUTB_CLAIM_STATUS
                     GROUP BY CLAIM_ID
                   ) AS m ON RTRIM(LTRIM(c.CLAIM_ID)) = RTRIM(LTRIM(m.CLAIM_ID))
                             AND c.LAST_UPD_DATE = m.MAXdate
        INNER JOIN dbo.WIPRO_277_Accepted a ON RTRIM(LTRIM(c.CLAIM_ID)) = RTRIM(LTRIM(a.PlanClaimNumber)) AND RTRIM(LTRIM(c.WIPRO_CLAIM_ID)) = RTRIM(LTRIM(a.WIPROID))
	WHERE		( c.FILEID LIKE '%HSCE.PROD.MMAI.DTXT08.%.%.CAID.%' OR	c.FILEID LIKE '%HSCE.PROD.MMAI.DILT09.%.%.CAID.%' )
			AND ( c.CLMSTAT_STATUS = 'A' )
			AND ( c.DOS_MONTH > '201701' )
			AND ( a.ProviderStatusActionCode = 'WQ' )
			AND ( a.StatusActionCode = 'WQ' )
			AND ( c.DOS_MONTH > '201701' )



END




