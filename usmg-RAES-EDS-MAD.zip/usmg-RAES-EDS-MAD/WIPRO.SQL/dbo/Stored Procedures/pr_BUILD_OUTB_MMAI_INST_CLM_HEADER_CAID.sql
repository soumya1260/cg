﻿
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_MMAI_INST_CLM_HEADER_CAID]
(@SOURCEDATAKEY INT, @LOBCODE CHAR(15) = ' ',@JOBID	INT = 1,@LOB CHAR(10)) --DEFAULT VALUE)--, @DOS_BEGIN CHAR(8), @DOS_END CHAR(8))--, @BEGIN_BILLTYPECODE CHAR(5) , @END_BILLTYPECODE CHAR(5))
AS
/***************************************************************************************************
** CREATE DATE: 09/2013
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@N-TEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT Institutional CLAIM INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.2. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
2013-09-23		Loyal Ricks		Add OUTB_INST_HEADER.REL_OF_INFO_FLAG default value "Y"	
2013-11-05		Loyal Ricks		Add Input parameter to allow range of BillType Codes
2013-11-13		Loyal Ricks		Remove ub92admissiondim.admissiondiagnosistypecode evaluation from
								updates. Value is required and institutional claims can be both inpatient
								or outpatient services. (UB.admissiondiagnosistypecode = 'A')	
2013-11-25		Loyal Ricks		Add EDPS_Data.dbo.CLAIMDIM.accidentdatekey
2014-01-27		Loyal Ricks		Add default value = '9' to Admission Type & Admission Source codes	
2014-02-28		Loyal Ricks		Remove Admission Source code Update. value will be defaulted to "9"	
2014-02-28		Loyal Ricks		Remove MDQOLib references (Memberdim, Lineofbusinessdim)
2014-02-28		Loyal Ricks		Additional invalid EDI character parsing - member first & last name	
2014-03-18		Loyal Ricks		Add input parameter @REJ_REA_ID to allow resubmission by Verisk REJ_REA_ID
								Default value assignment = ' '			
2014-05-04		Loyal Ricks		Add reference to MDQOLIB for lineofbusinessdim and memberdim tables 
2014-06-24		Loyal Ricks		Add logic to default MemberZip = '99998' when len(Member_zip) <> 5 
								and MemberZip4 = '9994' when MemberZip4 <> 4
2014-07-30		Loyal Ricks		Added Qualifier Codes (Principal, Institutional Visit, Daig Code) and 
								logic for updating appropriate codes for this sp.
2014-10-29		Loyal Ricks		Add @sourcedatakey to system source of claim header
2015-04-03		Loyal Ricks		TETDM-57 Remove evaluation of Payto Entity Flag, submit blank value
2015-04-07		Loyal Ricks		Revise LineofBusinessdim selection criteria from ProductType = 'Other' to
								ProductType = 'Care-Caid' due to Lineofbusinessdim revision.
2015-06-25		Loyal Ricks		Add parameter @LOBCODE
								Remove parameter @rej_rea_id
2015-08-24		Loyal Ricks		TETDM-319 Admission Source Revision - Revise logic replacing update of 
								Adm_type_code to Adm_source_code
2015-10-13		Loyal Ricks		Add table EXT_MMAI_CLAIM_PRODUCT whch is used to determine MMAI Claim 
								line product type (Medicare, Medicaid, dual , unknown).Only claims that 
								are 100% Medicare will be selected. Additional development required including
								the removal of this logic for the submission of Dual eligible claims.
2015-10-27		Loyal Ricks		Added EXT_MMAI_CLAIM_PRODUCT. UPPER(EMC.EDS_MMAI_PRODUCT) = 'MEDICARE'
2015-10-28		Loyal Ricks		TETDM-444 ICD-10 Qualifier Revisions
2015-10-30		Loyal Ricks		TETDM-448 Add @ExtractCount=EDS_ClaimExtractParams.Claim_Type ='I'	
2015-11-09		Loyal Ricks		Add @JOBID to support MMAI Production Water fall 
2016-02-03		Loyal Ricks		TETDM-319 - ADM_TYPE_CD Updates
2016-02-10		Loyal Ricks		TETDM-631 Add Claimdim.beginservicedatekey & claimdim.endservicedateky
								to outbound claim header state_begin_dt & state_end_dt
2016-03-14		Loyal Ricks		TETDM-671 - Add Institutional Admitting Diagnosis Code
2016-03-14		Loyal Ricks		TETDM-672 - Add Institutional External Cause of Injury Code and 
								Institutional External Cause of Injury Code Present on Admission default
2016-04-12		Loyal Ricks		TETDM-671- Move code block up above TETDM-444 ICD10 specific logic. This default logic was firing after ICD-10 causing incorrect submissions.
***************************************************************************************************************/			
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT,
			@ExtractCount INT,
			@SYSTEM_SOURCE CHAR(30),
			@PRODUCTTYPE VARCHAR(50)
			
			BEGIN
			
			SET @SYSTEM_SOURCE = (CASE @SOURCEDATAKEY WHEN '2' THEN 'EDPS-MHC'
													  WHEN '3' THEN 'EDPS-EZCap'
													  WHEN '30' THEN 'EDPS-Facets'
													  when '50' then 'EDPS-QNXT'
										END);
			END
			
			--	Added 10-29-2013 to use ManualMaxClaimsPerFile in param table and eliminate hardcoded value in this SP
			--
					SELECT
						@ExtractCount = ManualMaxClaimsPerFile
					FROM
						dbo.EDS_ClaimExtractParams	
					WHERE
						SourceDataKey = @sourcedatakey
					and claim_type ='I'

--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('pr_BUILD_OUTB_MMAI_INST_CLM_HEADER'
				,'2'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
if OBJECT_ID ('tempdb..#INST_lob') <> 0
	drop table #INST_lob
	
SELECT LOBCode
into  #INST_lob
FROM MDQOLIB.dbo.LineofBusinessDim
WHERE ProductType = 'Care-Caid'
	and LOBCODE = @LOBCODE
	and Active = 1
order by LOBCode

--12/4/15 --MMAI Care vs. Caid input evaluation 

			
				IF @LOB = 'MMAI'
					BEGIN 
						SET @PRODUCTTYPE = 'MEDICARE'
					END
				IF @LOB = 'CAID'
					BEGIN 
						SET @PRODUCTTYPE = 'MEDICAID'
					END

IF OBJECT_ID('TEMPDB..#INST_CLM') <> 0
				DROP TABLE #INST_CLM
				CREATE TABLE #INST_CLM
			(
				CLAIMID VARCHAR(20),
				BILLTYPECODE VARCHAR(4),
				LOBCODE	VARCHAR(15),
				HPLAN VARCHAR(5),
				FORMTYPECODE VARCHAR(1)
			)
	--STANDARD SUBMISSION LOGIC		
	IF @JOBID = 1
			BEGIN
				
				
	--STANDARD SUBMISSION LOGIC	
				
					INSERT INTO #INST_CLM	
					SELECT  DISTINCT TOP(@ExtractCount) U.claimid
							,BILLTYPECODE
							,C.LOBCODE
							,SPACE(5) AS 'HPLAN'
							,c.FORMTYPECODE
					FROM EDPS_Data.dbo.UB921ADMISSIONDIM U
					join EDPS_Data.dbo.CLAIMDIM C
					on U.CLAIMID = C.CLAIMID
					AND U.SourceDataKey = C.SOURCEDATAKEY
					join EDPS_Data.dbo.claimdetaildim cd
					on c.claimid = cd.claimid 
					and c.sourcedatakey = cd.sourcedatakey
					join EXT_MMAI_CLAIM_PRODUCT EMC  ---> MMAI 10/2015 revisions
					ON C.CLAIMID = EMC.CLAIMID			--->MMAI 10/2015 revisions
					AND C.LOBCODE = EMC.LOBCODE		--->	MMAI 10/2015 revisions
					join #INST_lob l
					on c.LOBCODE = l.LOBCode
					LEFT OUTER JOIN EXT_CLAIM_EXCLUSION CE
					ON C.SOURCEDATAKEY = CE.SOURCEDATAKEY 
					AND C.CLAIMID = CE.CLAIM_ID
					WHERE  C.SourceDataKey = @SOURCEDATAKEY
						and FormTypeCode = 'U'
						and DENIEDFLAG = 0
						and [C].[DELETED]= 0
						AND [C].[ACTIVE] = 1
						and UPPER(EMC.EDS_MMAI_PRODUCT) = @PRODUCTTYPE--->	MMAI 10/2015 revisions
						AND CE.CLAIM_ID IS NULL
					ORDER BY U.claimid
					
			END

				IF @JOBID <> 1
			BEGIN 
			INSERT INTO #INST_CLM	
					SELECT  DISTINCT TOP(@ExtractCount) U.claimid
							,BILLTYPECODE
							,C.LOBCODE
							,SPACE(5) AS 'HPLAN'
							,c.FORMTYPECODE
					FROM EDPS_Data.dbo.UB921ADMISSIONDIM U
					join EDPS_Data.dbo.CLAIMDIM C
					on U.CLAIMID = C.CLAIMID
					AND U.SourceDataKey = C.SOURCEDATAKEY
					join EDPS_Data.dbo.claimdetaildim cd
					on c.claimid = cd.claimid 
					and c.sourcedatakey = cd.sourcedatakey
					join EXT_MMAI_CLAIM_PRODUCT EMC  ---> MMAI 10/2015 revisions
					ON C.CLAIMID = EMC.CLAIMID			--->MMAI 10/2015 revisions
					AND C.LOBCODE = EMC.LOBCODE		--->	MMAI 10/2015 revisions
					join #INST_lob l
					on c.LOBCODE = l.LOBCode
					LEFT OUTER JOIN EXT_CLAIM_EXCLUSION CE
					ON C.SOURCEDATAKEY = CE.SOURCEDATAKEY 
					AND C.CLAIMID = CE.CLAIM_ID
					INNER JOIN OUTB_WIPRO_TEST_BED WT
					ON C.SOURCEDATAKEY = WT.SOURCEDATAKEY 
					AND C.CLAIMID = WT.CLAIMID
					WHERE  C.SourceDataKey = @SOURCEDATAKEY
						AND WT.TESTID = @JOBID 
						and FormTypeCode = 'U'
						and DENIEDFLAG = 0
						and [C].[DELETED]= 0
						AND [C].[ACTIVE] = 1
						and UPPER(EMC.EDS_MMAI_PRODUCT) = @PRODUCTTYPE--->	MMAI 10/2015 revisions
						AND CE.CLAIM_ID IS NULL
					ORDER BY U.claimid
					
			END

			/* TEDM-2231 Suppressing submission of Claims with SourceDataKey mismatches to the 
			exclusion table  */

			DELETE a
			FROM #INST_CLM a
			INNER JOIN WIPRO.DBO.EXT_CLAIM_EXCLUSION b on a.CLAIMID = b.CLAIM_ID
			where Excl_id IN ('7000','7001')


			--UPDATE #INST_CLM.HPLAN
			BEGIN TRANSACTION
				UPDATE #INST_CLM
				SET HPLAN = RTRIM(L.HCFACode)
				FROM #INST_CLM C
					,MDQOLIB.dbo.LineofBusinessDim L
				WHERE C.LOBCODE = L.LOBCode
				IF @@ERROR <> 0 
							BEGIN 
								ROLLBACK
							END
		COMMIT

--CREATE WORK TABLE 
IF OBJECT_ID('TEMPDB..#OUTB_INST_HEADER') <> 0
				DROP TABLE #OUTB_INST_HEADER
				
CREATE TABLE [#OUTB_INST_HEADER](
	[RECORD_TYPE] [char](1) NULL,
	[CLAIM_TYPE] [char](1) NULL,
	[SYSTEM_SOURCE] [char](30) NULL,
	[CMS_CONTRACT_NUM] [char](5) NULL,
	[HICN_NUM] [char](20) NULL,
	[CLAIM_ID] [char](20) NULL,
	[PAT_CNTRL_NO] [char](20) NULL,
	[MEMBER_ID] [char](80) NULL,
	[MEMBER_LAST_NAME] [char](60) NULL,
	[MEMBER_FIRST_NAME] [char](35) NULL,
	[MEMBER_MID_INIT] [char](25) NULL,
	[MEMBER_SFX] [char](10) NULL,
	[MEMBER_ADDR1] [char](55) NULL,
	[MEMBER_ADDR2] [char](55) NULL,
	[MEMBER_CITY] [char](30) NULL,
	[MEMBER_STATE] [char](2) NULL,
	[MEMBER_ZIP] [char](5) NULL,
	[MEMBER_ZIP4] [char](4) NULL,
	[MEMBER_CTY] [char](30) NULL,
	[MEMBER_CTRY] [char](3) NULL,
	[MEMBER_CTRY_SUBD] [char](3) NULL,
	[MEMBER_GROUP_NO] [char](50) NULL,
	[INSURANCE_TYPE] [char](30) NULL,
	[MEMBER_DOB] [char](10) NULL,
	[MEMBER_GENDER] [char](15) NULL,
	[MEMBER_SSN] [char](11) NULL,
	[POS] [char](15) NULL,
	[INST_PRINCIPAL_DIAG_CD] [char](8) NULL,
	[INST_PRINCIPAL_POA_CD] [char](15) NULL,
	[INST_ADM_DIAG_CD] [char](8) NULL,
	[INST_VISIT_DIAG_CD1] [char](8) NULL,
	[INST_VISIT_DIAG_CD2] [char](8) NULL,
	[INST_VISIT_DIAG_CD3] [char](8) NULL,
	[INST_EXT_INJ_POA_IND1] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD1] [char](8) NULL,
	[INST_EXT_INJ_POA_IND2] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD2] [char](8) NULL,
	[INST_EXT_INJ_POA_IND3] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD3] [char](8) NULL,
	[INST_EXT_INJ_POA_IND4] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD4] [char](8) NULL,
	[INST_EXT_INJ_POA_IND5] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD5] [char](8) NULL,
	[INST_EXT_INJ_POA_IND6] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD6] [char](8) NULL,
	[INST_EXT_INJ_POA_IND7] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD7] [char](8) NULL,
	[INST_EXT_INJ_POA_IND8] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD8] [char](8) NULL,
	[INST_EXT_INJ_POA_IND9] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD9] [char](8) NULL,
	[INST_EXT_INJ_POA_IND10] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD10] [char](8) NULL,
	[INST_EXT_INJ_POA_IND11] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD11] [char](8) NULL,
	[INST_EXT_INJ_POA_IND12] [char](15) NULL,
	[INST_EXT_INJ_DIAG_CD12] [char](8) NULL,
	[INST_DIAG_DRG_CD]	[CHAR]	(8) NULL,
	[DIAG_CD1] [char](8) NULL,
	[POA_IND1] [char](15) NULL,
	[DIAG_CD2] [char](8) NULL,
	[POA_IND2] [char](15) NULL,
	[DIAG_CD3] [char](8) NULL,
	[POA_IND3] [char](15) NULL,
	[DIAG_CD4] [char](8) NULL,
	[POA_IND4] [char](15) NULL,
	[DIAG_CD5] [char](8) NULL,
	[POA_IND5] [char](15) NULL,
	[DIAG_CD6] [char](8) NULL,
	[POA_IND6] [char](15) NULL,
	[DIAG_CD7] [char](8) NULL,
	[POA_IND7] [char](15) NULL,
	[DIAG_CD8] [char](8) NULL,
	[POA_IND8] [char](15) NULL,
	[DIAG_CD9] [char](8) NULL,
	[POA_IND9] [char](15) NULL,
	[DIAG_CD10] [char](8) NULL,
	[POA_IND10] [char](15) NULL,
	[DIAG_CD11] [char](8) NULL,
	[POA_IND11] [char](15) NULL,
	[DIAG_CD12] [char](8) NULL,
	[POA_IND12] [char](15) NULL,
	[DIAG_CD13] [char](8) NULL,
	[POA_IND13] [char](15) NULL,
	[DIAG_CD14] [char](8) NULL,
	[POA_IND14] [char](15) NULL,
	[DIAG_CD15] [char](8) NULL,
	[POA_IND15] [char](15) NULL,
	[DIAG_CD16] [char](8) NULL,
	[POA_IND16] [char](15) NULL,
	[DIAG_CD17] [char](8) NULL,
	[POA_IND17] [char](15) NULL,
	[DIAG_CD18] [char](8) NULL,
	[POA_IND18] [char](15) NULL,
	[DIAG_CD19] [char](8) NULL,
	[POA_IND19] [char](15) NULL,
	[DIAG_CD20] [char](8) NULL,
	[POA_IND20] [char](15) NULL,
	[DIAG_CD21] [char](8) NULL,
	[POA_IND21] [char](15) NULL,
	[DIAG_CD22] [char](8) NULL,
	[POA_IND22] [char](15) NULL,
	[DIAG_CD23] [char](8) NULL,
	[POA_IND23] [char](15) NULL,
	[DIAG_CD24] [char](8) NULL,
	[POA_IND24] [char](15) NULL,
	[DIAG_CD25] [char](8) NULL,
	[POA_IND25] [char](15) NULL,
	[DIAG_CD26] [char](8) NULL,
	[POA_IND26] [char](15) NULL,
	[DIAG_CD27] [char](8) NULL,
	[POA_IND27] [char](15) NULL,
	[DIAG_CD28] [char](8) NULL,
	[POA_IND28] [char](15) NULL,
	[DIAG_CD29] [char](8) NULL,
	[POA_IND29] [char](15) NULL,
	[DIAG_CD30] [char](8) NULL,
	[POA_IND30] [char](15) NULL,
	[BILL_PROV_NPI] [char](10) NULL,
	[BILL_PROV_GRP_ID] [char](40) NULL,
	[BILL_PROV_GRP_NPI] [char](10) NULL,
	[BILL_PROV_ORG_NAME] [char](60) NULL,
	[BILL_PROV_LNAME] [char](60) NULL,
	[BILL_PROV_FNAME] [char](35) NULL,
	[BILL_PROV_MID_INIT] [char](25) NULL,
	[BILL_PROV_SFX] [char](10) NULL,
	[BILL_PROV_ADDR1] [char](55) NULL,
	[BILL_PROV_ADDR2] [char](55) NULL,
	[BILL_PROV_CITY] [char](30) NULL,
	[BILL_PROV_STATE] [char](2) NULL,
	[BILL_PROV_ZIP] [char](5) NULL,
	[BILL_PROV_ZIP4] [char](4) NULL,
	[BILL_PROV_CTRY] [char](3) NULL,
	[BILL_PROV_CTRY_SUBD] [char](3) NULL,
	[BILL_PROV_TAXONOMY_CD] [char](10) NULL,
	[BILL_PROV_TAX_ID] [char](11) NULL,
	[BILL_PROV_UPIN] [char](50) NULL,
	[BILL_PROV_LICENSE_NO] [char](50) NULL,
	[BILL_PROV_ID] [char](40) NULL,
	[PAYTO_ADDR_TYPE_FLAG] [char](15) NULL,
	[PAYTO_ADDR1] [char](55) NULL,
	[PAYTO_ADDR2] [char](55) NULL,
	[PAYTO_CITY] [char](30) NULL,
	[PAYTO_STATE] [char](2) NULL,
	[PAYTO_ZIP] [char](5) NULL,
	[PAYTO_ZIP4] [char](4) NULL,
	[PAYTO_CTRY] [char](3) NULL,
	[PAYTO_CTRY_SUBD] [char](3) NULL,
	[PAYER_RESP] [char](30) NULL,
	[TOT_CHRG_AMT] [char](18) NULL,
	[MEMBER_AMT_PAID] [char](18) NULL,
	[PATIENT_EST_AMT_DUE] [char](18) NULL,
	[CLM_IND] [char](20) NULL,
	[CONDITION1] [CHAR] (50) NULL,
	[CONDITION2] [CHAR] (50) NULL,
	[CONDITION3] [CHAR] (50) NULL,
	[CONDITION4] [CHAR] (50) NULL,
	[CONDITION5] [CHAR] (50) NULL,
	[CONDITION6] [CHAR] (50) NULL,
	[CONDITION7] [CHAR] (50) NULL,
	[CONDITION8] [CHAR] (50) NULL,
	[CONDITION9] [CHAR] (50) NULL,
	[CONDITION10] [CHAR] (50) NULL,
	[CONDITION11] [CHAR] (50) NULL,
	[CONDITION12] [CHAR] (50) NULL,
	[PROV_ASSGN_IND] [char](15) NULL,
	[INSR_BEN_ASSGN_IND] [char](15) NULL,
	[REL_OF_INFO_FLAG] [varchar](15) NULL,
	[AUTO_ACC_STATE]	[CHAR] (2),
	[AUTO_ACC_CTRY]		[CHAR] (3),
	[DELAY_REAS]		[CHAR] (100),
	[ADM_TYPE_CD] [char](30) NULL,
	[ADM_SOURCE_CD] [char](30) NULL,
	[ADM_DT] [char](10) NULL,
	[ADM_TIME] [char](10) NULL,
	[STATE_BEGIN_DT] [char](10) NULL,
	[STATE_END_DT] [char](10) NULL,
	[DISCHRG_TIME] [char](10) NULL,
	[PATIENT_STATUS_CD] [char](10) NULL,
	[REPRICER_REC_DT]	[CHAR] (10) NULL,
	[REFERRAL_NO] [char](50) NULL,
	[PRIOR_AUTH_NO] [CHAR] (50),
	[CLM_CNTRL_NO] [CHAR] (50),
	[REPRICE_CLM_REF_NO] [CHAR] (50),
	[ADJ_REPRICED_CLM_REF_NO] [CHAR] (50),
	[INVEST_DEV_EXEMP_NO] [CHAR] (50),
	[MEDICAL_REC_NO] [CHAR] (50),
	[PRICE_METHOD] [char](50) NULL,
	[REPRICED ALLOWED AMOUNT] [char](18) NULL,
	[REPRICED_SAVING AMOUNT] [char](18) NULL,
	[REPRICING ORGANIZATION IDENTIFIER] [char](50) NULL,
	[REPRICING PER DIEM OR FLAT RATE AMOUNT] [char](18) NULL,
	[REPRICED APPROVED AMBULATORY PATIENT GROUP CODE] [char](50) NULL,
	[REPRICED APPROVED AMBULATORY PATIENT GROUP AMOUNT] [char](18) NULL,
	[REPRICED APPROVED REVENUE CODE] [char](50) NULL,
	[REPRICED APPROVED SERVICE UNITS] [char](15) NULL,
	[REPRICED APPROVED SERVICE DAYS] [char](15) NULL,
	[REJECT_REASON_CODE] [char](80) NULL,
	[POLICY_COMPLIANCE_CODE] [char](50) NULL,
	[EXCEPTION_CODE] [char](50) NULL,
	[REF_PROV_LNAME] [char](60) NULL,
	[REF_PROV_FNAME] [char](35) NULL,
	[REF_PROV_MID_INIT] [char](25) NULL,
	[REF_PROV_SFX] [char](10) NULL,
	[REF_PROV_NPI] [char](10) NULL,
	[REF_PROV_LICENSE_NO] [char](50) NULL,
	[REF_PROV_UPIN] [char](50) NULL,
	[REF_PROV_ID] [char](50) NULL,
	[RENDERING_PROV_ORG_NAME] [char](60) NULL,
	[RENDERING_PROV_GRP_ID] [char](50) NULL,
	[RENDERING_PROV_LAST_NAME] [char](60) NULL,
	[RENDERING_PROV_FIRST_NAME] [char](35) NULL,
	[RENDERING_PROV_MID_INIT] [char](25) NULL,
	[RENDERING_PROV_SFX] [char](10) NULL,
	[RENDERING_PROV_NPI] [char](10) NULL,
	[RENDERING_PROV_UPIN] [CHAR] (50) NULL,
	[RENDERING_PROV_ID] [char](50) NULL,
	[SERVICE_FAC_NAME] [CHAR] (60) NULL,
	[SERVICE_FAC_NPI] [CHAR] (10) NULL,
	[SERVICE_FAC_PROV_LIC_NUM] [CHAR] (50) NULL,
	[SERVICE_FAC_PROV_LOC_NUM] [CHAR] (50) NULL,
	[ATTN_PROV_LNAME] [char](60) NULL,
	[ATTN_PROV_FNAME] [char](35) NULL,
	[ATTN_PROV_MIDINIT] [char](25) NULL,
	[ATTN_PROV_SFX] [char](10) NULL,
	[ATTN_PROV_NPI] [char](10) NULL,
	[ATTN_PROV_TAXONOMY_CD] [char](10) NULL,
	[ATTN_PROV_TAXONOMY_CD2] [char](10) NULL,
	[ATTN_PROV_UPIN] [char](50) NULL,
	[ATTN_PROV_LOC_NO] [char](10) NULL,
	[ATTN_PROV_ID] [char](50) NULL,
	[ATTN_PROV_LICENSE_NO] [char](50) NULL,
	[OPER_PHYS_LNAME] [CHAR] (60) NULL,
	[OPER_PHYS_FNAME] [CHAR] (35) NULL,
	[OPER_PHYS_MID_NAME] [CHAR] (25) NULL,
	[OPER_PHYS_SFX] [CHAR] (10) NULL,
	[OPER_PHYS_NPI] [CHAR] (10) NULL,
	[OPER_PHYS_PROV_ID] [CHAR] (50) NULL,
	[OTH_OPER_PHYS_LNAME] [CHAR] (60) NULL,
	[OTH_OPER_PHYS_FNAME] [CHAR] (35) NULL,
	[OTH_OPER_PHYS_MID_NAME] [CHAR] (25) NULL,
	[OTH_OPER_PHYS_SFX] [CHAR] (10) NULL,
	[OTH_OPER_PHYS_NPI] [CHAR] (10) NULL,
	[OTH_OPER_PHYS_PROV_ID] [CHAR] (50) NULL,
	[PAYER_RESP1] [char](60) NULL,
	[REL_CD1] [char](35) NULL,
	[OTH_INSR_GRPNAME] [char](60) NULL,
	[CLM_FIL_INDCD1] [char](10) NULL,
	[AMOUNT_PAID] [char](18) NULL,
	[ASSIGN_BEN_IND1] [char](15) NULL,
	[OTH_PAYER1_NAME] [char](60) NULL,
	[OTH_PAYER1_PLANID] [char](80) NULL,
	[OTH_PAYER1_ADDRESS1] [char](55) NULL,
	[OTH_PAYER1_ADDRESS2] [char](55) NULL,
	[OTH_PAYER1_CITY] [char](30) NULL,
	[OTH_PAYER1_STATE] [char](2) NULL,
	[OTH_PAYER1_ZIP] [char](5) NULL,
	[OTH_PAYER1_ZIP4] [char](4) NULL,
	[OTH_PROC_CD_TYPE_11]	 [char] (10),
	[OTH_PROC_CD_11]	 [char] (5),
	[OTH_PROC_CD_DT_11]	 [char] (10),
	[OTH_PROC_CD_TYPE_12]	 [char] (10),
	[OTH_PROC_CD_12]	 [char] (5),
	[OTH_PROC_CD_DT_12]	 [char] (10),
	[OTH_PROC_CD_TYPE_13]	 [char] (10),
	[OTH_PROC_CD_13]	 [char] (5),
	[OTH_PROC_CD_DT_13]	 [char] (10),
	[OTH_PROC_CD_TYPE_14]	 [char] (10),
	[OTH_PROC_CD_14]	 [char] (5),
	[OTH_PROC_CD_DT_14]	 [char] (10),
	[OTH_PROC_CD_TYPE_15] 	 [char] (10),
	[OTH_PROC_CD_15] [char] (5),
	[OTH_PROC_CD_DT_15]  [char] (10),
	[OTH_PROC_CD_TYPE_16]	 [char] (10),
	[OTH_PROC_CD_16]	 [char] (5),
	[OTH_PROC_CD_DT_16]	 [char] (10),
	[OTH_PROC_CD_TYPE_17]	 [char] (10),
	[OTH_PROC_CD_17]	 [char] (5),
	[OTH_PROC_CD_DT_17]	 [char] (10),
	[OTH_PROC_CD_TYPE_18]	 [char] (10),
	[OTH_PROC_CD_18]	 [char] (5),
	[OTH_PROC_CD_DT_18]	 [char] (10),
	[OTH_PROC_CD_TYPE_19]	 [char] (10),
	[OTH_PROC_CD_19]	 [char] (5),
	[OTH_PROC_CD_DT_19]	 [char] (10),
	[OTH_PROC_CD_TYPE_110]  [char] (10),
	[OTH_PROC_CD_110]   [char] (5),
	[OTH_PROC_CD_DT_110] 	 [char] (10),
	[OTH_PROC_CD_TYPE_111]	 [char] (10),
	[OTH_PROC_CD_111]	 [char] (5),
	[OTH_PROC_CD_DT_111]	 [char] (10),
	[OTH_PROC_CD_TYPE_112]	 [char] (10),
	[OTH_PROC_CD_112]	 [char] (5),
	[OTH_PROC_CD_DT_112]	 [char] (10),
	[OTH_PROC_CD_TYPE_21]	 [char] (10),
	[OTH_PROC_CD_21]	 [char] (5),
	[OTH_PROC_CD_DT_21]	 [char] (10),
	[OTH_PROC_CD_TYPE_22]	 [char] (10),
	[OTH_PROC_CD_22]	 [char] (5),
	[OTH_PROC_CD_DT_22]	 [char] (10),
	[OTH_PROC_CD_TYPE_23]	 [char] (10),
	[OTH_PROC_CD_23]	 [char] (5),
	[OTH_PROC_CD_DT_23]	 [char] (10),
	[OTH_PROC_CD_TYPE_24]	 [char] (10),
	[OTH_PROC_CD_24]	 [char] (5),
	[OTH_PROC_CD_DT_24]	 [char] (10),
	[OTH_PROC_CD_TYPE_]  [char] (10),
	[OTH_PROC_CD_] [char] (5),
	[OTH_PROC_CD_DT_]  [char] (10),
	[OTH_PROC_CD_TYPE_26]	 [char] (10),
	[OTH_PROC_CD_26]	 [char] (5),
	[OTH_PROC_CD_DT_26]	 [char] (10),
	[OTH_PROC_CD_TYPE_27]	 [char] (10),
	[OTH_PROC_CD_27]	 [char] (5),
	[OTH_PROC_CD_DT_27]	 [char] (10),
	[OTH_PROC_CD_TYPE_28]	 [char] (10),
	[OTH_PROC_CD_28]	 [char] (5),
	[OTH_PROC_CD_DT_28]	 [char] (10),
	[OTH_PROC_CD_TYPE_29]	 [char] (10),
	[OTH_PROC_CD_29]	 [char] (5),
	[OTH_PROC_CD_DT_29]	 [char] (10),
	[OTH_PROC_CD_TYPE_210]  	 [char] (10),
	[OTH_PROC_CD_210]  	 [char] (5),
	[OTH_PROC_CD_DT_210] 	 [char] (10),
	[OTH_PROC_CD_TYPE_211]	 [char] (10),
	[OTH_PROC_CD_211]	 [char] (5),
	[OTH_PROC_CD_DT_211]	 [char] (10),
	[OTH_PROC_CD_TYPE_212]	 [char] (10),
	[OTH_PROC_CD_212]	 [char] (5),
	[OTH_PROC_CD_DT_212]	 [char] (10),
	[OCC_SPAN_CD_11] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_11] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_11] [CHAR] (10) NULL,
	[OCC_SPAN_CD_12] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_12] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_12] [CHAR] (10) NULL,
	[OCC_SPAN_CD_13] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_13] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_13] [CHAR] (10) NULL,
	[OCC_SPAN_CD_14] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_14] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_14] [CHAR] (10) NULL,
	[OCC_SPAN_CD_15] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_15] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_15] [CHAR] (10) NULL,
	[OCC_SPAN_CD_16] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_16] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_16] [CHAR] (10) NULL,
	[OCC_SPAN_CD_17] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_17] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_17] [CHAR] (10) NULL,
	[OCC_SPAN_CD_18] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_18] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_18] [CHAR] (10) NULL,
	[OCC_SPAN_CD_19] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_19] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_19] [CHAR] (10) NULL,
	[OCC_SPAN_CD_110] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_110] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_110] [CHAR] (10) NULL,
	[OCC_SPAN_CD_111] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_111] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_111] [CHAR] (10) NULL,
	[OCC_SPAN_CD_112] [CHAR] (5) NULL,
	[OCC_SPAN_BEGIN_DT_112] [CHAR] (10) NULL,
	[OCC_SPAN_END_DT_112] [CHAR] (10) NULL,
	[OPTIONAL_REPORTING_IND1] [varchar](30) NULL,
	[OPTIONAL_REPORTING_IND2] [varchar](30) NULL,
	[OPTIONAL_REPORTING_IND3] [varchar](30) NULL,
	[PATIENT_DOD] [CHAR] (10) NULL,
	[PREGNANCY_IND] [CHAR] (15),
	[SPEC_PROG_CD] [CHAR] (2), --Special Program Code
	[LMP_DT] [CHAR] (10),
	[EPSDT_REF_COND_RESP_CD] [CHAR] (15),--EPSDT Referral Condition Response Code
	[EPSDT_REF_COND_IND1] [CHAR] (15),--	EPSDT Referral Condition Indicator 1
	[EPSDT_REF_COND_IND2] [CHAR] (15),--EPSDT Referral Condition Indicator 2
	[EPSDT_REF_COND_IND3] [CHAR] (15),--EPSDT Referral Condition Indicator 3
	[SOURCEDATAKEY] [int] NULL,
	[ACCIDENT_DATE] [CHAR] (10),
	[CONTRACT_TYPE] [CHAR]	(30),
	[PRINCIPAL_DIAG_QUAL] [varchar](3) NULL,
	[ADMIT_DIAG_QUAL] [varchar](3) NULL,
	[REA_VISIT_DIAG_QUAL1] [varchar](3) NULL,
	[REA_VISIT_DIAG_QUAL2] [varchar](3) NULL,
	[REA_VISIT_DIAG_QUAL3] [varchar](3) NULL,
	[DIAG_CD_QUAL1] [varchar](3) NULL,
	[DIAG_CD_QUAL2] [varchar](3) NULL,
	[DIAG_CD_QUAL3] [varchar](3) NULL,
	[DIAG_CD_QUAL4] [varchar](3) NULL,
	[DIAG_CD_QUAL5] [varchar](3) NULL,
	[DIAG_CD_QUAL6] [varchar](3) NULL,
	[DIAG_CD_QUAL7] [varchar](3) NULL,
	[DIAG_CD_QUAL8] [varchar](3) NULL,
	[DIAG_CD_QUAL9] [varchar](3) NULL,
	[DIAG_CD_QUAL10] [varchar](3) NULL,
	[DIAG_CD_QUAL11] [varchar](3) NULL,
	[DIAG_CD_QUAL12] [varchar](3) NULL,
	[DIAG_CD_QUAL13] [varchar](3) NULL,
	[DIAG_CD_QUAL14] [varchar](3) NULL,
	[DIAG_CD_QUAL15] [varchar](3) NULL,
	[DIAG_CD_QUAL16] [varchar](3) NULL,
	[DIAG_CD_QUAL17] [varchar](3) NULL,
	[DIAG_CD_QUAL18] [varchar](3) NULL,
	[DIAG_CD_QUAL19] [varchar](3) NULL,
	[DIAG_CD_QUAL20] [varchar](3) NULL,
	[DIAG_CD_QUAL21] [varchar](3) NULL,
	[DIAG_CD_QUAL22] [varchar](3) NULL,
	[DIAG_CD_QUAL23] [varchar](3) NULL,
	[DIAG_CD_QUAL24] [varchar](3) NULL,
	[DIAG_CD_QUAL25] [varchar](3) NULL,
	[DIAG_CD_QUAL26] [varchar](3) NULL,
	[DIAG_CD_QUAL27] [varchar](3) NULL,
	[DIAG_CD_QUAL28] [varchar](3) NULL,
	[DIAG_CD_QUAL29] [varchar](3) NULL,
	[DIAG_CD_QUAL30] [varchar](3) NULL,
	[INST_EXT_INJ_QUAL1] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL2] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL3] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL4] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL5] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL6] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL7] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL8] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL9] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL10] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL11] [VARCHAR] (3) NULL,
	[INST_EXT_INJ_QUAL12] [VARCHAR] (3) NULL



	
)

--build HRP record type C - Claim 
TRUNCATE TABLE dbo.OUTB_INST_HEADER
TRUNCATE TABLE dbo.OUTB_INST_DETAIL
	--begin transaction 
		insert into #OUTB_INST_HEADER--dbo.OUTB_INST_HEADER--OUTB_INST_HEADER--dbo.OUTB_INST_HEADER--dbo.OUTB_INST_HEADER
		select 'C'
			,case cd.formtypecode when 'H' then 'P'
				when 'U' then 'I'
				else cd.formtypecode
			end
			,rtrim(convert(char, @sourcedatakey))
			,QB.HPLAN--cd.sourcedatakey--CMS_CONTRACT_NUM
			,mb.MEDICAREID
			,cd.claimid
			,substring(cd.PatientID,1,20)
			,REPLACE(cd.MemberID,'*','-')
			,dbo.fn_edi_parse(mb.lastname)
			,dbo.fn_edi_parse(mb.firstname)
			,CASE dbo.fn_edi_parse(mb.middlename) 
				WHEN 'UNKNOWN' THEN ' '
				ELSE dbo.fn_edi_parse(mb.middlename)
			 END
			,' '--MEMBER_SFX
			,dbo.fn_edi_parse(substring(mb.AddressLine1,1,55))
			,CASE dbo.fn_edi_parse(substring(mb.AddressLine2,1,55))
				WHEN 'UNKNOWN' THEN ' '
				when '***' then ' '                                                    
				ELSE dbo.fn_edi_parse(substring(mb.AddressLine2,1,55))
			 END
			,mb.City
			,mb.State
			,CASE substring(mb.Zip,1,5) WHEN 'UNKNO' THEN '99999' ELSE SUBSTRING(mb.Zip,1,5) END
			,substring(mb.Zip,6,4) 
			,' '--MEMBER_CTY
			,' '--MEMBER_CTRY
			,' '--MEMBER_CTRY_SUBD
			,REPLACE(cd.GroupID,'*','-')
			,case cd.formtypecode 
				when 'H' then '14'
				else ' '
			end
			,mb.DOBDateKey
			,mb.Gender
			,CASE mb.SSN WHEN 'UNKNOWN' THEN ' ' ELSE mb.SSN END
			,' '--POS
			,' '--INST_PRINCIPAL_DIAG_CD
			,' '--INST_PRINCIPAL_POA_CD
			,' '--INST_ADM_DIGA_CD
			,' '--instit visit DIAG_CD1
			,' '
			,' '--instit visit DIAG_CD3
			,' '--inst_ext_inj_POA_IND1
			,' '--inst_ext_inj_diag_cd1
			,' '
			,' '
			,' '
			,' '
			,' '--inst_ext_inj_POA_IND4
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '--inst_ext_inj_POA_IND8
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '--inst_ext_inj_POA_IND12
			,' '--inst_ext_inj_diag_cd12
			,' '--INST_DIAG_DRG_CD
			,' '--diag_cd1
			,' '--POA_IND1
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '--diag_cd5
			,' '--POA_IND1
			,' '
			,' '
			,' '
			,' '
			,' '--diag_cd8
			,' '
			,' '--diag_cd9
			,' '--POA_IND9
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '--diag_cd13
			,' '--POA_IND13
			,' '
			,' '
			,' '
			,' '
			,' '--diag_cd16
			,' '
			,' '
			,' '
			,' '--diag_cd18
			,' '			
			,' '
			,' '
			,' '--DIAG_CD20
			,' '--POA_IND20
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '--DIAG_CD30
			,' '--POA_IND30
			,' '--BILL_PROV_NPI
			,cd.PCPVendor
			,' '--bill_prov_grp_npi
			,' '--bill_prov_org_name
			,' '
			,' '
			,' '
			,' '
			,' '--bill_prov_addr1
			,' '
			,' '
			,' '
			,' '
			,' '--bill_prov_zip4
			,' '
			,' '
			,' '--bill_prov_taxonomy_cd
			,' '--bill_prov_tin
			,' '
			,' '--BILL_PROV_LICENSE_NO
			,cd.PCPVendor
			,' '
			--Note
			--
			-- TETDM-57 Remove evaluation of Payto Entity Flag
			--,case cd.PayToVendorOrFamilyFlag 
			--	when 'V' then '1'
			--	else ' '
			--end
			,' '--PAYTO_ADDR1
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,'P'--PAYER_RESP
			,ltrim(cd.ClaimBilledAmt)
			,' '--ltrim(cd.MemberPaidAmt)
			,' '
			,CASE cd.PreviousClaimID WHEN 'N/A' THEN '1'  when 'UNKNOWN' THEN '1' ELSE '7' END --CLM_IND
			,' '--conidtion1
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '--conidtion12
			,'C'--PROV_ASSGN_IND
			,'Y'--INSR_BEN_ASSGN_IND
			,'Y'--rel_of_info_flag
			,' '--auto_acc_state
			,' '--auto_acc_ctry
			,' '--delay_reas			
			,'9'--adm_type_cd
			,'9'--adm_source_cd
			,case cd.admissiondatekey when '-1' then ' ' when '0' then ' ' WHEN '0000' THEN ' ' else cd.AdmissionDateKey end
			,' '--adm_time
			,cd.BeginServiceDateKey  --case cd.admissiondatekey when '-1' then ' ' when '0' then ' ' WHEN '0000' THEN ' ' else cd.AdmissionDateKey end--statement_begin_dt
			,cd.EndServiceDateKey     --case rtrim(cd.dischargedatekey) when '-1' then ' '  when '0' then ' ' WHEN '0000' THEN ' '  else rtrim(cd.dischargedatekey) end--statement_end_dt
			,case rtrim(cd.dischargedatekey) when '-1' then ' '  when '0' then ' ' WHEN '0000' THEN ' ' else rtrim(cd.dischargedatekey) end
			,CASE cd.DispositionCode WHEN 'N/A' THEN ' ' WHEN '--' THEN ' ' WHEN '0000' THEN ' ' ELSE cd.DispositionCode END --patient_status_cd
			,' '--repricer_rec_dt
			,' '--referral_no
			,CASE replace(cd.AuthorizationID,'*','-') WHEN 'UNKNOWN' THEN ' ' ELSE replace(cd.AuthorizationID,'*','-')  END--prior authorization
			,CASE cd.PreviousClaimID WHEN 'N/A' THEN ' ' when 'UNKNOWN' THEN ' ' ELSE cd.PreviousClaimID END --clm_cntrl_no			
			,' '--reprice_clm_ref_no
			,' '
			,' '
			,' '--medical_rec_no
			,' '--PRICE_METHOD
			,' '--repriced allowed amount
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '--repriced approved service days
			,' '--reject reason code
			,' '--policy compliance code
			,' '--exception code
			,' '--ref_prov__lname
			,' '
			,' '
			,' '
			,' '--REF_PROV_NPI
			,' '--REF_PROV_LICENSE_NO
			,' '--REF_PROV_UPIN
			,CASE cd.ReferringPhysicianID WHEN 'UNKNOWN' THEN ' ' ELSE cd.ReferringPhysicianID END
			,' '--rendering_prov_org_name
			,' '--rendering_prov_grp_id
			,' '
			,' '
			,' '
			,' '
			,' '--rendering_prov_npi
			,' '--rendering_PROV_UPIN
			,' '--rendering_prov_id
			,' '--service_fac_name
			,' '--service_fac_npi
			,' '--service_fac_prov_lic_num
			,' '--service_fac_PROV_LOC_NO
			,' '--ATTN_PROV_LNAME
			,' '---ATTN_PROV_FNAME
			,' '
			,' '
			,' '--ATTN_PROV_NPI
			,' '--ATTN_PROV_TAXONOMY_CD1
			,' '--ATTN_PROV_TAXONOMY_CD2
			,' '
			,' '--ATTN_PROV_LOC_NO
			,CASE cd.AttendingPhysicianID WHEN 'UNKNOWN' THEN ' ' ELSE cd.AttendingPhysicianID END--ATTN_PROV_ID
			,' '--ATTN_PROV_LICENSE_NO
			,' '--OPER_PHYS_LNAME
			,' '
			,' '
			,' '
			,' '--OPER_PHYS_NPI
			,' '--OPER_PHYS_PROV_ID
			,' '--OTH_OPER_PHYS_LNAME
			,' '
			,' '
			,' '
			,' '--OTH_OPER_PHYS_NPI
			,' '--OTH_OPER_PHYS_PROV_ID
			,'P'--PAYER_RESP1 default values for CMS COB
			,'18'--REL_CD1 default values for CMS COB
			,'HealthSpring'--OTH_INSR_GRPNAME CHAR(60),
			,'16'--CLM_FIL_INDCD1 CHAR(10),
			,ltrim(cd.TotalPaid)
			,'Y'--ASSIGN_BEN_IND1
			,'HealthSpring'--OTHER PAYER 1 NAME
			,QB.HPLAN---OTHER PAYER1 PLAN ID
			,'530 GREAT CIRCLE' --OTHER PAYER1 ADDRESS
			,' '  --OTHER PAYER1 ADDRESS2
			,'NASHVILLE'--OTHER PAYER1 CITY
			,'TN' --OTHER PAYER1 STATE
			,'37228'--OTH PAYER1 ZIP
			,'9999' -- OTHER PAYER1 ZIP4
			,' '--OTH_PROC_CD_TYPE_11]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_11]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_11]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_12]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_12]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_12]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_13]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_13]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_13]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_14]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_14]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_14]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_15] 	 ,' '--char] (10)
			,' '--OTH_PROC_CD_15] ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_15]  ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_16]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_16]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_16]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_17]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_17]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_17]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_18]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_18]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_18]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_19]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_19]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_19]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_110]  ,' '--char] (10)
			,' '--OTH_PROC_CD_110]   ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_110] 	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_111]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_111]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_111]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_112]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_112]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_112]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_21]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_21]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_21]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_22]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_22]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_22]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_23]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_23]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_23]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_24]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_24]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_24]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_]  ,' '--char] (10)
			,' '--OTH_PROC_CD_] ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_]  ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_26]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_26]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_26]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_27]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_27]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_27]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_28]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_28]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_28]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_29]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_29]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_29]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_210]  	 ,' '--char] (10)
			,' '--OTH_PROC_CD_210]  	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_210] 	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_211]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_211]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_211]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_TYPE_212]	 ,' '--char] (10)
			,' '--OTH_PROC_CD_212]	 ,' '--char] (5)
			,' '--,' '--OTH_PROC_CD_DT_212]	 ,' '--char] (10)
				,' '--[OCC_SPAN_CD_11] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_11] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_11] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_12] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_12] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_12] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_13] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_13] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_13] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_14] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_14] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_14] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_15] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_15] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_15] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_16] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_16] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_16] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_17] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_17] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_17] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_18] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_18] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_18] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_19] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_19] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_19] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_110] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_110] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_110] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_111] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_111] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_111] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_CD_112] [CHAR] (5) NULL,
	,' '--[OCC_SPAN_BEGIN_DT_112] [CHAR] (10) NULL,
	,' '--[OCC_SPAN_END_DT_112] [CHAR] (10) NULL,
			,' '--OPTIONAL_REPORTING_IND1
			,' '
			,' '--OPTIONAL_REPORTING_IND3
			,' '--PATIENT_DOD
			,' '
			,' '
			,' '--LMP_DT
			,' '--EPSDT_REF_COND_RESP_CD
			,' '
			,' '
			,' '--EPSDT_REF_COND_IND3
			,cd.sourcedatakey
			,case cd.ACCIDENTDATEKEY when '-1' then ' '  when '0' then ' ' else cd.ACCIDENTDATEKEY end
			,' ' --CONTRACT_TYPE
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
		from EDPS_Data.dbo.CLAIMDIM cd
		join MDQOLIB.dbo.MemberDim mb
		on cd.MEMBERID = mb.MemberID
		and cd.SOURCEDATAKEY = mb.SourceDataKey
		join #INST_CLM QB
		on cd.CLAIMID = QB.claimid
		ORDER BY cd.ClaimID
			
			
			--UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO
			--IF OBJECT_ID('TEMPDB..#dbo_TMPDEV_HPLAN') <> 0
			--	DROP TABLE #dbo_TMPDEV_HPLAN
				
		 --SELECT CLAIMID,CD.LOBCODE,HCFACODE
		 --INTO #dbo_TMPDEV_HPLAN
		 --FROM OUTB_INST_HEADER C
			--,EDPS_Data.dbo.CLAIMDIM CD
			--,dbo.LineofBusinessDim L
		 --WHERE C.CLAIM_ID = CD.CLAIMID
			--AND CD.LOBCODE = L.LOBCode
 
 		
			--UPDATE OUTB_INST_HEADER
			--SET CMS_CONTRACT_NUM = T.HCFACode
			--		,OTH_PAYER1_PLANID = T.HCFACode
			--FROM OUTB_INST_HEADER C
			--	 ,#dbo_TMPDEV_HPLAN T			
			--WHERE C.CLAIM_ID = T.CLAIMID
			
		
	--REMOVE PAID_DATE from claim header. Per conversation on 7/6/12 with Donna & Heidi the file should only include 
	--PAID_DATE at either the header or line, not both. recommendation was to remove from header to support claim line
	--level processing.
	--BEGIN TRANSACTION
	--		UPDATE dbo.OUTB_INST_HEADER
	--		SET PAYER1_PAID_DT = CA.PaidDateKey
	--			--,PAID_DATE = CA.PaidDateKey
	--		FROM OUTB_INST_HEADER HC
	--			,dbo.claimagg CA
	--		WHERE HC.CLAIM_ID = CA.CLAIMID
	--		if @@ERROR <> 0
	--		begin
	--			rollback 
	--		end
	--	commit

	--UPDATE ADM_DT AND DISCHRG_DT
	--ENSURE '0' DATA VALUES ARE REMOVED
	--BEGIN TRANSACTION 
			UPDATE #OUTB_INST_HEADER
			SET ADM_DT = ' '
			WHERE ADM_DT = '0'
	--		if @@ERROR <> 0
	--		begin
	--			rollback 
	--		end
	--	commit
	--BEGIN TRANSACTION 
			--UPDATE dbo.OUTB_INST_HEADER
			--SET DISCHRG_DT = ' '
			--WHERE DISCHRG_DT = '0'
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
	--UPDATE PROFESSIONAL CLAIM PLACE OF SERVICE
		--BEGIN TRANSACTION
		--	UPDATE dbo.OUTB_INST_HEADER
		--	SET POS = cd.ServicePlaceCode
		--	FROM dbo.OUTB_INST_HEADER E
		--		,dbo.claimdetaildim CD
		--	WHERE E.CLAIM_ID = CD.ClaimID
		--		and E.CLAIM_TYPE = 'P'
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		--UPDATE INSTITUTIONAL CLAIM PLACE OF SERVICE
		--BEGIN TRANSACTION
			UPDATE #OUTB_INST_HEADER
			SET POS = UA.billtypecode
			FROM #OUTB_INST_HEADER E
				,EDPS_Data.dbo.UB921ADMISSIONDIM UA
			WHERE E.CLAIM_ID = UA.ClaimID
				and E.SOURCEDATAKEY = UA.SourceDataKey
				and E.CLAIM_TYPE = 'I'
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
	--UPDATE INST_PRINCIPAL_DIAG_CD
		--BEGIN TRANSACTION
			UPDATE #OUTB_INST_HEADER
			SET INST_PRINCIPAL_DIAG_CD = replace(CDD.DIAGNOSISCODE,'.',''),
				INST_PRINCIPAL_POA_CD = case CDD.POAind when 'Y' then 'Y' else 'N' end,
				PRINCIPAL_DIAG_QUAL = 'BK'
			FROM #OUTB_INST_HEADER E
				,EDPS_Data.DBO.claimdiagnosisdim CDD
			WHERE E.CLAIM_ID = CDD.claimid
				AND CDD.diagnosistypecode = 'P'
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
	

		--UPDATE SERVICE DATE
		--BEGIN TRANSACTION 
		--UPDATE OUTB_INST_HEADER
		--SET SERV_DT = BeginServiceDateKey
		--FROM OUTB_INST_HEADER E
		--	,dbo.claimdetaildim CDD
		--WHERE E.CLAIM_ID = CDD.ClaimID
		--	AND CDD.ClaimLineID = '0001'
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		--UPDATE ADM_TYPE_CD
		--BEGIN TRANSACTION
		UPDATE #OUTB_INST_HEADER
		SET adm_source_cd = UB.admissioncode
		FROM #OUTB_INST_HEADER E
		inner join EDPS_Data.dbo.UB921ADMISSIONDIM UB
		on e.sourcedatakey = ub.sourcedatakey 
			and  E.CLAIM_ID = UB.claimid
			--AND UB.admissiondiagnosistypecode = 'A'
		-- 2/3/16 - TETDM-319
		
		UPDATE #OUTB_INST_HEADER
		SET ADM_TYPE_CD = C.TYPECODE
		FROM #OUTB_INST_HEADER E
		inner join EDPS_Data.dbo.CLAIMDIM C
		on  E.SOURCEDATAKEY = C.SOURCEDATAKEY 
		 AND E.CLAIM_ID = c.claimid
		WHERE C.TYPECODE IN ('1','2','3','4','5','9')


		UPDATE #OUTB_INST_HEADER
		SET ADM_TIME = case UB.admissionhour when 'N/A' then ' ' else ub.admissionhour end
		FROM #OUTB_INST_HEADER E
			,EDPS_Data.dbo.UB921ADMISSIONDIM UB
		WHERE E.CLAIM_ID = UB.claimid
			--AND UB.admissiondiagnosistypecode = 'A'
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		----UPDATE DISCHRG_TIME
		--BEGIN TRANSACTION
		UPDATE #OUTB_INST_HEADER
		SET DISCHRG_TIME = case UB.dischargehour when 'N/A' then ' ' when '0000' then ' ' else UB.dischargehour end
		FROM #OUTB_INST_HEADER E
			,EDPS_Data.dbo.UB921ADMISSIONDIM UB
		WHERE E.CLAIM_ID = UB.claimid
			--AND UB.admissiondiagnosistypecode = 'A'
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		--UPDATE DISCHRG_DT
		--BEGIN TRANSACTION
		--UPDATE dbo.OUTB_INST_HEADER
		--SET DISCHRG_DT = ' '
		--WHERE DISCHRG_DT = '0'
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--COMMIT
		--UPDATE ADM_DT DEFAULT VALUES
		
		BEGIN TRANSACTION
		UPDATE #OUTB_INST_HEADER
		SET ADM_DT = ' '
		WHERE ADM_DT = '0'
		if @@ERROR <> 0
			begin
				rollback 
			end
		COMMIT
		--UPDATE PRICE_METHOD - removed 3/11 based on HRP feedback, only send when claim has been repriced
		/*BEGIN TRANSACTION 
		UPDATE dbo.OUTB_INST_HEADER
		SET PRICE_METHOD = FeeCalculationCode
		FROM OUTB_INST_HEADER E
			,dbo.claimdetaildim CDD
		WHERE E.CLAIM_ID = CDD.ClaimID
			AND CDD.ClaimLineID = '0001'
		if @@ERROR <> 0
			begin
				rollback 
			end
		commit*/
	
		--UPDATE CMS_CONTRACT_NUMBER
		--BEGIN TRANSACTION
		--UPDATE dbo.OUTB_INST_HEADER
		--SET NONCOV_CHRG = ' '
		--WHERE CONVERT(INT, NONCOV_CHRG)< 0
		----add initial HRP test file criteria
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--COMMIT
		
		
		--CLAIM INDICATOR - CLAIM REVERSAL LOGIC
		--UPDATE CLAIM INDICATOR TO DELETE FOR R REVERSAL CLAIM 
		BEGIN TRANSACTION 
		UPDATE #OUTB_INST_HEADER 
		SET CLM_IND = '8'
			,CLM_CNTRL_NO = CA.PreviousClaimID
		FROM #OUTB_INST_HEADER C
			,EDPS_Data.dbo.claimagg CA
		WHERE C.CLAIM_ID = CA.CLAIMID
				AND CHARINDEX('R',ClaimID) > 0
		if @@ERROR <> 0
			begin
				rollback 
			end
		COMMIT
		
		--UPDATE CLAIM INDICATOR TO REPLACE FOR REPLACEMENT CLAIM
		--'A' (A1-A10)
		BEGIN TRANSACTION 
		UPDATE #OUTB_INST_HEADER
		SET CLM_IND = '7'
			,CLM_CNTRL_NO  = CA.PreviousClaimID
		FROM #OUTB_INST_HEADER C
			,EDPS_Data.dbo.claimagg CA
		WHERE C.CLAIM_ID = CA.CLAIMID
			
			AND CA.CurrentStatusCode = 'P'
			AND CA.PREVIOUSCLAIMID NOT IN ('N/A','UNKNOWN')
				AND (CHARINDEX('A',ClaimID) > 0 OR
				CHARINDEX('R',ClaimID) > 0 OR 
				CHARINDEX('D',ClaimID) > 0
				)
		if @@ERROR <> 0
			begin
				rollback 
			end
		COMMIT
		
		
		--PAPER CLAIM INDICATOR UPDATE
		--BEGIN TRANSACTION 
		UPDATE #OUTB_INST_HEADER
		SET OPTIONAL_REPORTING_IND1 = 'PAPER'
		WHERE CHARINDEX('E',CLAIM_ID) = 0
		--IF @@ERROR <> 0
		--BEGIN 
		--ROLLBACK
		--END
		--COMMIT
		
		---Update ADM_TIME - Remove Default, also remove when there is no ADM_DT
		update #OUTB_INST_HEADER
		SET ADM_TIME = ' '
		WHERE RTRIM(ADM_TIME) = '000'
			OR LEN(ADM_DT) = 0
			
		
		update #OUTB_INST_HEADER
		SET ACCIDENT_DATE = ' '
		WHERE ACCIDENT_DATE = '0'
			
		
		IF OBJECT_ID('TEMPDB..#TMP_HDR_CAP') <> 0
				DROP TABLE #TMP_HDR_CAP
				
		CREATE TABLE #TMP_HDR_CAP
		(CLAIMID VARCHAR(20),
		 CLAIMLINEID VARCHAR(5),
		 CAPSTATUS VARCHAR(2)
		 )

		BEGIN TRANSACTION 
		INSERT INTO #TMP_HDR_CAP
		SELECT CLAIMID,CLAIMLINEID, CASE PROVIDERCAPITATIONSTATUS WHEN 'Y' THEN  '05' ELSE ' ' END
		FROM EDPS_Data.dbo.claimdetaildim CD
		JOIN #OUTB_INST_HEADER CI
		ON CD.CLAIMID = CI.CLAIM_ID
		AND CD.SOURCEDATAKEY = CI.SOURCEDATAKEY
		ORDER BY PROVIDERCAPITATIONSTATUS DESC,CLAIMID,CLAIMLINEID
		COMMIT


		BEGIN TRANSACTION 
		UPDATE #OUTB_INST_HEADER
		SET CONTRACT_TYPE = CAPSTATUS
		FROM #OUTB_INST_HEADER CI
		JOIN #TMP_HDR_CAP TC
		ON CI.CLAIM_ID = TC.CLAIMID
		COMMIT
		
		--06/24/14 Additonal invalid Member Zip scrub

		begin transaction 
		update #OUTB_INST_HEADER
		set MEMBER_ZIP = '99998'
		where len(member_zip) <> 5
		commit

		--06/24/14 Additonal invalid Member Zip4 scrub
		begin transaction 
		update #OUTB_INST_HEADER
		set MEMBER_ZIP4 = '9998'
		where len(member_zip4) <> 4
		commit
			
			--PURGE EXITING DATA
				TRUNCATE TABLE dbo.OUTB_INST_HEADER
			--APPEND HEADER INFORMATION			
				INSERT INTO dbo.OUTB_INST_HEADER
				select *
				from #OUTB_INST_HEADER
			
				---TETDM-671
					--04/12/16 Move code block up above TETDM-444 ICD10 specific logic. This default logic was firing after ICD-10 causing incorrect submissions.
						update OUTB_INST_HEADER
						SET INST_ADM_DIAG_CD = REPLACE(UA.DIAGNOSISCODE,'.',''),
							ADMIT_DIAG_QUAL = 'BJ'
						FROM OUTB_INST_HEADER H
						INNER JOIN EDPS_DATA.DBO.UB921ADMISSIONDIM UA
						ON H.SOURCEDATAKEY = UA.SOURCEDATAKEY 
						AND H.CLAIM_ID = UA.CLAIMID 
						WHERE UA.diagnosiscode <> 'N/A'
							and admissiondiagnosistypecode = 'A'

			--TETDM-444 ICD-10 Qualifier Revisions
					--ICD-10 Principal Diag Qual
						Update OUTB_INST_HEADER 
						SET PRINCIPAL_DIAG_QUAL = 'A'+''+RTRIM(PRINCIPAL_DIAG_QUAL)
						FROM OUTB_INST_HEADER H
						INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
						ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
						AND H.CLAIM_ID = CDD.CLAIMID 
						WHERE diagnosiscodeversion = '0'
							AND LEN(H.PRINCIPAL_DIAG_QUAL) > 0


						--ICD-10 ADMIT_DIAG_QUAL
						Update OUTB_INST_HEADER 
						SET ADMIT_DIAG_QUAL = 'A'+''+RTRIM(ADMIT_DIAG_QUAL)
						FROM OUTB_INST_HEADER H
						INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
						ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
						AND H.CLAIM_ID = CDD.CLAIMID 
						WHERE diagnosiscodeversion = '0'
							AND LEN(H.ADMIT_DIAG_QUAL) > 0

						--ICD-10 REA_VISIT_DIAG_QUAL1
						Update OUTB_INST_HEADER 
						SET REA_VISIT_DIAG_QUAL1 = 'A'+''+RTRIM(REA_VISIT_DIAG_QUAL1)
						FROM OUTB_INST_HEADER H
						INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
						ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
						AND H.CLAIM_ID = CDD.CLAIMID 
						WHERE diagnosiscodeversion = '0'
							AND LEN(H.REA_VISIT_DIAG_QUAL1) > 0


						--ICD-10 REA_VISIT_DIAG_QUAL2
						Update OUTB_INST_HEADER 
						SET REA_VISIT_DIAG_QUAL2 = 'A'+''+RTRIM(REA_VISIT_DIAG_QUAL2)
						FROM OUTB_INST_HEADER H
						INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
						ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
						AND H.CLAIM_ID = CDD.CLAIMID 
						WHERE diagnosiscodeversion = '0'
							AND LEN(H.REA_VISIT_DIAG_QUAL2) > 0

						--ICD-10 REA_VISIT_DIAG_QUAL3
						Update OUTB_INST_HEADER 
						SET REA_VISIT_DIAG_QUAL3 = 'A'+''+RTRIM(REA_VISIT_DIAG_QUAL3)
						FROM OUTB_INST_HEADER H
						INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
						ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
						AND H.CLAIM_ID = CDD.CLAIMID 
						WHERE diagnosiscodeversion = '0'
							AND LEN(H.REA_VISIT_DIAG_QUAL3) > 0	

						
						---TETDM-671
						--update OUTB_INST_HEADER
						--SET INST_ADM_DIAG_CD = REPLACE(UA.DIAGNOSISCODE,'.',''),
						--	ADMIT_DIAG_QUAL = 'BJ'
						--FROM OUTB_INST_HEADER H
						--INNER JOIN EDPS_DATA.DBO.UB921ADMISSIONDIM UA
						--ON H.SOURCEDATAKEY = UA.SOURCEDATAKEY 
						--AND H.CLAIM_ID = UA.CLAIMID 
						--WHERE UA.diagnosiscode <> 'N/A'
						--	and admissiondiagnosistypecode = 'A'


						
						---TETDM-672
						IF OBJECT_ID('TEMPDB..#tmp_ext_inj') <> 0
								DROP TABLE #tmp_ext_inj
					
								create table #tmp_ext_inj
								(claimid varchar(20)
									,injurycode varchar(10)
									,inst_ext_inj_qual varchar(3)
									,inj_seq INT
								)
	                   
	       
							INSERT INTO #tmp_ext_inj           
							SELECT 
									ClaimID ,
									REPLACE(injurycode,'.',''),
									'BN',
									 ROW_NUMBER() OVER ( PARTITION BY ClaimID ORDER BY CLAIMID, injurycode ) AS 'inj_SEQ'
							FROM    EDPS_Data.dbo.UB921ADMISSIONDIM UA
							INNER JOIN OUTB_INST_HEADER H
							ON UA.SOURCEDATAKEY = H.SOURCEDATAKEY 
							AND UA.CLAIMID = H.CLAIM_ID 
							WHERE INJURYCODE <> 'N/A'
							order BY ClaimID ,
									injurycode 


							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD1 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND1 = 'U',
								INST_EXT_INJ_QUAL1 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 1

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD2 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND2 = 'U',
								INST_EXT_INJ_QUAL2 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 2

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD3 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND3 = 'U',
								INST_EXT_INJ_QUAL3 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 3

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD4 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND4 = 'U',
								INST_EXT_INJ_QUAL4 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 4

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD5 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND5 = 'U',
								INST_EXT_INJ_QUAL5 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 5

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD6 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND6 = 'U',
								INST_EXT_INJ_QUAL6 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 6

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD7 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND7 = 'U',
								INST_EXT_INJ_QUAL7 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 7

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD8 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND8 = 'U',
								INST_EXT_INJ_QUAL8 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 8

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD9 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND9 = 'U',
								INST_EXT_INJ_QUAL9 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 9

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD10 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND10 = 'U',
								INST_EXT_INJ_QUAL10 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 10

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD11 = T.INJURYCODE,
								INST_EXT_INJ_POA_IND11 = 'U',
								INST_EXT_INJ_QUAL11 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 11

							Update OUTB_INST_HEADER
							SET INST_EXT_INJ_DIAG_CD12= T.INJURYCODE,
								INST_EXT_INJ_POA_IND12 = 'U',
								INST_EXT_INJ_QUAL12 = INST_EXT_INJ_QUAL
							FROM OUTB_INST_HEADER H
							INNER JOIN #tmp_ext_inj T
							ON H.CLAIM_ID = T.CLAIMID 
							WHERE INJ_SEQ = 12

		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_HEADER)
				
				----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_OUTB_MMAI_INST_CLM_HEADER'
									AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
						

