﻿
CREATE PROCEDURE [dbo].[pr_Compliance_Filter]
AS
/*************************************************************************************************** 
** CREATE DATE: 11/28/2018
** 
** AURTHOR: Anthony Ulmer
** 
** DESCRIPTION: This procedure will add claims to the exclusion history table based on compliance 
**              filter data aquired from RAPS.  Records are also inserted into the compliance hold  
**              table for reporting purposes.
** 
** 
Modification History 
==================== 
Date			Who				Description 
----------------------------------------------------------------------------------------------------- 
10/24/2018		Anthony Ulmer	Initial Creation
02/26/2019      Anthony Ulmer   Update to add more release codes
11/14/2019		Anthony Ulmer	Added code 11 to release status
12/10/2019		Anthony Ulmer	Reversed prior changes (requirement change)
								Added new exclusion ID for code 11 (treated as hold for EDS now)
12/19/2019		Anthony Ulmer	Added insert into compliance run tables for recon
04/07/2021      Aaron Ridley	TETDM-2481 Added logic to accommodate the newly introduced SOS compliance Retract/Release statuses
								Note: Exclusion ID's 7000/7001 have been repurposed. 7000 now equals a replacement and 7001 equals retraction
*****************************************************************************************************/			 
BEGIN TRY
SET NOCOUNT ON;

	DECLARE @body NVARCHAR(MAX) = NULL,
			@subject VARCHAR(150) = NULL,
			@check_date AS DATETIME2 = GETDATE();
/*
Update any blank log entries to sql min
*/
    IF (SELECT 1 FROM WIPRO.dbo.EXT_SYS_RUNLOG esr WHERE esr.PROC_NAME = '' AND esr.END_DT IS NULL) > 0 BEGIN  
	    UPDATE WIPRO.dbo.EXT_SYS_RUNLOG
        SET END_DT = CAST(-53690 AS DATETIME)     
        WHERE PROC_NAME = 'pr_Compliance_Filter'
        AND END_DT IS NULL; 
    END;

    /*
    Log procedure start
    */
    INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG (PROC_NAME
    , STEP
    , START_DT
    , END_DT
    , RUN_MINUTES
    , TOTAL_RECORDS
    , ENTRYDT)
	    VALUES ('pr_Compliance_Filter', NULL, GETDATE(), NULL, NULL, 0, GETDATE()); 
     
	--take snapshot before compliance filter run and store results in table

	WITH cts AS (
		SELECT 
			sub.SOURCEDATAKEY,
			sub.claim_type,
			sub.EXCL_ID,
			Totals = COUNT(1)
		FROM (
			SELECT distinct
					claim_id =	dch.CLM_NO
					,SOURCEDATAKEY = TRY_CAST(LTRIM(RTRIM(dch.[SOURCE ])) AS INT)
					,dch.claim_type
					--,EXCL_ID = IIF(HOLD_TABLE_STATUS != 11, 7000, 7001) - Commented out TETDM-2481
					,EXCL_ID = CASE 
									WHEN dch.HOLD_TABLE_STATUS  = '1' AND dchb.CLM_NO IS NULL THEN 7000 	-- TETDM-2481 added Case statement								
									WHEN  dch.HOLD_TABLE_STATUS in ('4','7','16') THEN 7001
								END  --TETDM-2481
					FROM staging.DX_COMPLIANCE_HOLD dch 
					LEFT  JOIN staging.DX_COMPLIANCE_HOLD dchb on dch.clm_no = dchb.clm_no  
														and dch.claim_type = dchb.claim_type  
														and dchb.HOLD_TABLE_STATUS in  ('2','3','5', '11','12','13','14','15','17')
					WHERE dch.HOLD_TABLE_STATUS in ('1','4','7','16') )  sub
		WHERE sub.EXCL_ID in ('7000','7001')
		GROUP BY
			sub.SOURCEDATAKEY,
			sub.claim_type,
			sub.EXCL_ID	),
	exc_counts AS (
		SELECT
			eceh.SOURCEDATAKEY,
			eceh.claim_type,
			eceh.EXCL_ID,
			Totals = COUNT(1)
		FROM WIPRO..EXT_CLAIM_EXCLUSION_HIST eceh
		WHERE eceh.EXCL_ID IN (7000,7001)
		GROUP BY
			eceh.SOURCEDATAKEY,
			eceh.claim_type,
			eceh.EXCL_ID
	) 
	INSERT INTO WIPRO.dbo.Compliance_Exclusion_Run_Results 
	(Stage_SOURCEDATAKEY, Stage_Claim_Type, Stage_EXCL_ID, Stage_Totals,
		EXCL_Totals, EXCL_SOURCEDATAKEY, EXCL_Claim_Type, EXCL_EXCL_ID, Check_Date_Time, is_Before_Run)
	SELECT
		stage_SOURCEDATAKEY  = ec.SOURCEDATAKEY
	   ,stage_claim_type  = ec.claim_type
	   ,stage_EXCL_ID  = ec.EXCL_ID
	   ,stage_Totals  = ec.Totals
	   ,EXCL_Totals = cts.Totals
	   ,EXCL_SOURCEDATAKEY = cts.SOURCEDATAKEY
	   ,EXCL_CLAIM_TYPE = cts.CLAIM_TYPE
	   ,EXCL_EXCL_ID    = cts.EXCL_ID
	   ,Check_Date_Time = @check_date
	   ,is_Before_Run = 1 --denote this is before the update of the exclusion table
	FROM cts ec 
	FULL JOIN exc_counts cts
		ON cts.SOURCEDATAKEY = ec.SOURCEDATAKEY
		AND cts.CLAIM_TYPE = ec.claim_type
		AND cts.EXCL_ID = ec.EXCL_ID
		AND cts.Totals = ec.Totals
		AND cts.EXCL_ID in ('7000','7001');

     
    /*
    Insert/Delete compliance holds into Exclusion table
    */
	DECLARE @BATCH_RUN_DT DATETIME2 = GETDATE();

    WITH stage AS (
		SELECT distinct
				claim_id =	dch.CLM_NO
				,SOURCEDATAKEY = TRY_CAST(LTRIM(RTRIM(dch.[SOURCE ])) AS INT)
				,dch.claim_type
				--,EXCL_ID = IIF(HOLD_TABLE_STATUS != 11, 7000, 7001) - Commented out TETDM-2481
				,EXCL_ID = CASE 
								WHEN dch.HOLD_TABLE_STATUS  = '1' AND dchb.CLM_NO IS NULL THEN 7000 -- TETDM-2481 added Case statement
								WHEN  dch.HOLD_TABLE_STATUS in ('4','7','16') THEN 7001
							END  --TETDM-2481
				FROM staging.DX_COMPLIANCE_HOLD dch 
				LEFT JOIN staging.DX_COMPLIANCE_HOLD dchb on dch.clm_no = dchb.clm_no  
													and dch.claim_type = dchb.claim_type  
													and dchb.HOLD_TABLE_STATUS in ('2','3','5', '11','12','13','14','15','17')
			WHERE dch.HOLD_TABLE_STATUS in ('1','4','7','16')  
    )
    MERGE
    INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST AS TARGET 
    USING stage AS SOURCE
    ON SOURCE.claim_id = TARGET.claim_id
        AND SOURCE.SOURCEDATAKEY = TARGET.SOURCEDATAKEY
        AND SOURCE.CLAIM_TYPE = TARGET.claim_type
        AND SOURCE.EXCL_ID = TARGET.EXCL_ID 
    WHEN NOT MATCHED BY TARGET
		AND SOURCE.EXCL_ID IN (7000,7001)
        THEN INSERT (claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type)
                VALUES (SOURCE.claim_id, SOURCE.SOURCEDATAKEY, @BATCH_RUN_DT, SOURCE.EXCL_ID, SOURCE.claim_type)
    WHEN NOT MATCHED BY SOURCE
		AND TARGET.EXCL_ID IN (7000,7001)
        THEN DELETE;


	--take snapshot AFTER compliance filter run and store results in table
	WITH cts AS (
		SELECT 
			sub.SOURCEDATAKEY,
			sub.claim_type,
			sub.EXCL_ID,
			Totals = COUNT(1)
		FROM (
			SELECT distinct
					claim_id =	dch.CLM_NO
					,SOURCEDATAKEY = TRY_CAST(LTRIM(RTRIM(dch.[SOURCE ])) AS INT)
					,dch.claim_type
					--,EXCL_ID = IIF(HOLD_TABLE_STATUS != 11, 7000, 7001) - Commented out TETDM-2481
					,EXCL_ID = CASE 
									WHEN dch.HOLD_TABLE_STATUS  = '1' AND dchb.CLM_NO IS NULL THEN 7000 -- TETDM-2481 added Case statement
									WHEN  dch.HOLD_TABLE_STATUS in ('4','7','16') THEN 7001
								END  --TETDM-2481
					FROM staging.DX_COMPLIANCE_HOLD dch 
					LEFT JOIN staging.DX_COMPLIANCE_HOLD dchb on dch.clm_no = dchb.clm_no  
														and dch.claim_type = dchb.claim_type  
														and dchb.HOLD_TABLE_STATUS in ('2','3','5', '11','12','13','14','15','17')
				WHERE dch.HOLD_TABLE_STATUS in ('1','4','7','16')  ) sub
		WHERE sub.EXCL_ID in ('7000','7001')
		GROUP BY
			sub.SOURCEDATAKEY,
			sub.claim_type,
			sub.EXCL_ID	),
	exc_counts AS (
		SELECT
			eceh.SOURCEDATAKEY,
			eceh.claim_type,
			eceh.EXCL_ID,
			Totals = COUNT(1)
		FROM WIPRO..EXT_CLAIM_EXCLUSION_HIST eceh
		WHERE eceh.EXCL_ID IN (7000,7001)
		GROUP BY
			eceh.SOURCEDATAKEY,
			eceh.claim_type,
			eceh.EXCL_ID
	)
	INSERT INTO WIPRO.dbo.Compliance_Exclusion_Run_Results 
	(Stage_SOURCEDATAKEY, Stage_Claim_Type, Stage_EXCL_ID, Stage_Totals,
		EXCL_Totals, EXCL_SOURCEDATAKEY, EXCL_Claim_Type, EXCL_EXCL_ID, Check_Date_Time, is_Before_Run)
	SELECT
		stage_SOURCEDATAKEY  = ec.SOURCEDATAKEY
	   ,stage_claim_type  = ec.claim_type
	   ,stage_EXCL_ID  = ec.EXCL_ID
	   ,stage_Totals  = ec.Totals
	   ,EXCL_Totals = cts.Totals
	   ,EXCL_SOURCEDATAKEY = cts.SOURCEDATAKEY
	   ,EXCL_CLAIM_TYPE = cts.CLAIM_TYPE
	   ,EXCL_EXCL_ID    = cts.EXCL_ID
	   ,Check_Date_Time = @check_date
	   ,is_Before_Run = 0 --denote this is AFTER the update of the exclusion table
	FROM cts ec
	FULL JOIN exc_counts cts
		ON cts.SOURCEDATAKEY = ec.SOURCEDATAKEY
		AND cts.CLAIM_TYPE = ec.claim_type
		AND cts.EXCL_ID = ec.EXCL_ID
		AND cts.Totals = ec.Totals;



    /*Clear Compliance hold table*/
    TRUNCATE TABLE WIPRO.dbo.DX_COMPLIANCE_HOLD;

    /* Identify LOBCODE by utilizing MonthlyMembershipDim */
   SELECT DISTINCT
       MEMBERID
      ,CLM_NO
      ,LobCode
   INTO #tmplob
   FROM WIPRO.staging.DX_COMPLIANCE_HOLD a
   JOIN EDPS_Data.dbo.MonthlyMembershipDim b
       ON a.MEM_ID = b.MEMBERID
   WHERE REPLACE(DOS_DT, '-', '') BETWEEN BeginCoverageDateKey AND EndCoverageDateKey;
	--AND LEFT(REPLACE(DOS_DT,'-',''),6) = LEFT([ReportDateKey],6)
	
	/*
    Insert into Compliance Hold Table from stage hold table
    */
    INSERT INTO WIPRO.dbo.DX_COMPLIANCE_HOLD
	(	  [HNUMBER]
      ,[SOURCE ]
      ,[SOURCEDESC]
      ,[LOB]
      ,[ASSESSMENTFLAG]
      ,[FREQUENCY]
      ,[RETRACTION_FLAG]
      ,[CLM_NO]
      ,[MEM_ID]
      ,[MEDICARE_NO]
      ,[DOB]
      ,[DOS_DT]
      ,[DOS_THRU_DT]
      ,[HCFA_POS_CD]
      ,[BILL_TYPE]
      ,[PROV_ID]
      ,[PROVIDERNPI]
      ,[INGENIX_TAXONOMYCODE]
      ,[PRIM_SPEC_CD]
      ,[CLAIM_TYPE]
      ,[PROV_TYPE]
      ,[SVC_CD]
      ,[DIAGNOSIS_CODE]
      ,[LOGIC_FILTER]
      ,[HCC]
      ,[EDS_FILTER_ID]
      ,[ICDVERSION]
      ,[DIAGNOSISTYPECODE]
      ,[TRANSACTIONDATE]
      ,[SUBMIT_ERROR]
      ,[STATUS_CODE]
      ,[UNIQUEID]
      ,[HOLD_DATE]
      ,[RAPS_HOLD_CLAIM]
      ,[EDS_HOLD_CLAIM]
      ,[HOLD_TABLE_STATUS]
      ,[RELEASED_FOR_PROCESS_DATE]
      ,[RELEASED_UNABLE_TO_VALIDATE_DATE]
      ,[HOLD_STATUS_DESC]
      ,[STATUS_CODE_DESC]
      ,[STATE]
      ,[PBPCODE]
      ,[ETL_DATE] )
    SELECT DISTINCT
        dch.HNUMBER
       ,dch.[SOURCE ]
       ,dch.SOURCEDESC
       ,lob.LOBCODE
       ,dch.ASSESSMENTFLAG
       ,dch.FREQUENCY
       ,dch.RETRACTION_FLAG
       ,dch.CLM_NO
       ,dch.MEM_ID
       ,dch.MEDICARE_NO
       ,dch.DOB
       ,dch.DOS_DT
       ,dch.DOS_THRU_DT
       ,dch.HCFA_POS_CD
       ,dch.BILL_TYPE
       ,dch.PROV_ID
       ,dch.PROVIDERNPI
       ,dch.INGENIX_TAXONOMYCODE
       ,dch.PRIM_SPEC_CD
       ,dch.CLAIM_TYPE
       ,dch.PROV_TYPE
       ,dch.SVC_CD
       ,dch.DIAGNOSIS_CODE
       ,dch.LOGIC_FILTER
       ,dch.HCC
       ,dch.EDS_FILTER_ID
       ,dch.ICDVERSION
       ,dch.DIAGNOSISTYPECODE
       ,dch.TRANSACTIONDATE
       ,dch.SUBMIT_ERROR
       ,dch.STATUS_CODE
       ,dch.UNIQUEID
       ,dch.HOLD_DATE
       ,dch.RAPS_HOLD_CLAIM
       ,EDS_HOLD_CLAIM = IIF(dch.HOLD_TABLE_STATUS IN ('2','3','5','11','12','13','14','15'),'N','Y') -- TETDM-2481 updated 
       ,dch.HOLD_TABLE_STATUS
       ,dch.RELEASED_FOR_PROCESS_DATE
       ,dch.RELEASED_UNABLE_TO_VALIDATE_DATE
       ,dch.HOLD_STATUS_DESC
       ,dch.STATUS_CODE_DESC
	   ,dch.STATE
	   ,dch.PBPCode
	   ,dch.ETL_DATE
    FROM WIPRO.staging.DX_COMPLIANCE_HOLD dch
	left JOIN #tmplob lob on dch.mem_id = lob.memberid and dch.clm_no = lob.clm_no;

    /*
    Log procedure end
    */
    UPDATE WIPRO.dbo.EXT_SYS_RUNLOG
    SET END_DT = GETDATE()
       ,RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE())
       ,TOTAL_RECORDS = NULL
       ,ENTRYDT = GETDATE()
    WHERE PROC_NAME = 'pr_Compliance_Filter'
    AND END_DT IS NULL; 

	/*
	Send notification email
	*/
	--SET @body = CONCAT('The Compliance Filter procedure has completed.',
	--					CHAR(10),
	--					TRY_CONVERT(VARCHAR, GETDATE(),109),
	--					CHAR(10),
	--					CHAR(10),
	--					'Please check results in table: "WIPRO.dbo.Compliance_Exclusion_Run_Results"',
	--					CHAR(10),
	--					'Use this DATETIMESTAMP: ',						
	--					@check_date);
	--SET @subject = CONCAT('SUCCESS, Compliance Filter Procedure on: ', @@servername);
	--IF (SELECT @@servername) = 'HSTNEDSDEVDB02' BEGIN  
	--	EXEC msdb.dbo.sp_send_dbmail @profile_name = NULL,
	--								 @recipients = 'anthony.ulmer@cigna.com;Aaron.Ridley@healthspring.com;Tracy.Black@healthspring.com',
	--								 @body = @body,
	--								 @subject = @subject;
	--END;
	--ELSE BEGIN
	--	EXEC msdb.dbo.sp_send_dbmail @profile_name = NULL,
	--								 @recipients = 'MDQOEDSSupport@cigna.com',
	--								 @body = @body,
	--								 @subject = @subject;
	--END;


SET NOCOUNT OFF;
END TRY
BEGIN CATCH

    IF XACT_STATE() != 0 BEGIN  	    
        ROLLBACK TRANSACTION;
    END;

    UPDATE WIPRO.dbo.EXT_SYS_RUNLOG
    SET END_DT = GETDATE()
       ,RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE())
       ,TOTAL_RECORDS = NULL
       ,ENTRYDT = GETDATE()
    WHERE PROC_NAME = 'pr_Compliance_Filter'
    AND END_DT IS NULL; 

	--SET @body = CONCAT('The Compliance Filter procedure has failed.',CHAR(13), TRY_CONVERT(VARCHAR, GETDATE(),109));
	--SET	@subject = CONCAT('FAILURE, Compliance Filter Procedure on: ', @@servername);

	--IF (SELECT @@servername) = 'HSTNEDSDEVDB02' BEGIN  
	--	EXEC msdb.dbo.sp_send_dbmail @profile_name = NULL,
	--								 @recipients = 'anthony.ulmer@cigna.com;Aaron.Ridley@healthspring.com;Tracy.Black@healthspring.com',
	--								 @body = @body,
	--								 @subject = @subject;
	--END;
	--ELSE BEGIN
	--	EXEC msdb.dbo.sp_send_dbmail @profile_name = NULL,
	--								 @recipients = 'MDQOEDSSupport@cigna.com',
	--								 @body = @body,
	--								 @subject = @subject;
	--END;

END CATCH;



