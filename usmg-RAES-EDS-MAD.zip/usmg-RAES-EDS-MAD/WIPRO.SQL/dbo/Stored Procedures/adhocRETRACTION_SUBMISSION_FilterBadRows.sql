﻿CREATE PROCEDURE [dbo].[adhocRETRACTION_SUBMISSION_FilterBadRows]
AS

/*********************************************************************************************************************************
-- =============================================
-- Author:		Liv Gonzalez
-- Create date: 10/28/2018
-- Description:	Filter each row of adhoc submission and retraction files to avoid error in processing of files.
--              THis is used with SSIS package RAPS_AdhocSubmissionandRetractionRowFiltering.dtsx

	Modification History:
	DATE			WHO				RTD		Description
	2019-05-23		Noe Leiva		3307	-Submission/Retraction Check for empty ad hoc datafile
											-Retraction/Overpayment Check all dos thru dt DOSYR against (current year - 2) to flag records for review to determine if possible overpayment
											-Error out any special characters in clm_no column (i.e. +, *, #, @, &, %, ~, $, _, -, etc...)
	2019-09-24		Noe Leiva		3353	Added new logic to validate if NPI field exists (Error Code 2)
	2021-01-20		SasiT			RTD 3411	allow underscore to claim number so it wont fallout to error report 
											for retractions allow upto 6 years, check source for 990 not 980 for claim source validation
											each claim must have unique one mdeicareid, if not move to error row
											each mem id must have unique medicare id, if not move to error row
	2024-07-17		SasiT			RETM-674	moved from RAPS to EDS, updated one member can have multiple error logic


-- =============================================

  -- execute adhocRETRACTION_SUBMISSION_FilterBadRows

  *********************************************************************************************************************************/

  BEGIN 

SET NOCOUNT ON;


/*
IF OBJECT_ID ('tempdb..[##ADHOC_SUBMISSIONS_ERROR_CODES]', 'U') IS NOT NULL
DROP TABLE [dbo].[##ADHOC_SUBMISSIONS_ERROR_CODES];

Create table ##ADHOC_SUBMISSIONS_ERROR_CODES  (  AS_ERR_CODE INT,ERRORDESC varchar (800))
 
insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 1, 'LAST CHARACTER SHOULD BE EITHER ICD NUMBERS 9 OR 10'
  
insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 2, 'NOT ENOUGHT TABDELIMITERS'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 3,  'MEDICARE NO HAS MORE THAN ONE MEMID' 

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 4,   'MEMID HAS MORE THAN ONE MEDICARENO'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 5,   'NULL OR EMPTY VALUES IN COLUMNS'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 6,   'PROVIDER TYPE NOT IN 01, 02, 10, 20'
 
insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 7,   'DOS DATE NOT VALID DATE'
  
insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 8,   'DOS THRU DATE NOT VALID DATE'
    
insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 9,   'DIAGNOSIS CODE HAS PERIOD'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 10,   'DIAGNOSIS CODE DOES NOT HAVE CORRECT LENGTH' 

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 11,   'CLAIM NO IS NOT UNIQUE TO ONE MEMBER ID'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 12,   'CLAIM NO IS NOT UNIQUE TO ONE MEDICARE ID'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 14,   'NOT A VALID HEALTHPLAN'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 15,   'SOURCE DESC NOT CONSISTENT WITH CROSSWALK TABLE'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 16,   'RETRACTION FLAG, DOES NOT EQUAL CROSS REFERENCE TABLES FOR RETRACTIONS, SOURCEDESC FIELD MUST CONTAIN _RET'  --ONLY FOR RETRACTION

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 17,   'RETRACTION FILE DOES NOT CONTAIN LETTER D or D NOT IN CORRECT POSITION'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 18,   'LAYOUT NOT CONSISTENT WITH SPECS ATTACHED'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 19,   'LENGTH OF A COLUMN BIGGER THAN WHAT IS EXPECTED LENGTH ACCORDING TO VENDOR SPEC'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 20,   'WRONG DATE RANGE FOR ICD 9 OR 10'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 21,   'BAD DATE RANGE'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 22,   'LENGTH OF PLAN NAME IS GREATER THAN 5'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 23,   'DOS PASS SUBMISSION YEAR'

insert into  ##ADHOC_SUBMISSIONS_ERROR_CODES  select 24,   'SPECIAL CHARACTERS PRESENT'



*/





  IF OBJECT_ID('tempdb..##ErrorListsSubmissionRetractions') IS NOT NULL
 TRUNCATE TABLE ##ErrorListsSubmissionRetractions
 ELSE 
   CREATE TABLE ##ErrorListsSubmissionRetractions( ErrRecid INT IDENTITY  ( 1,1)  not null, BulkInsId INT, FilName VARCHAR (7800), filetype VARCHAR ( 10) , Col VARCHAR (7800), 
  ErrorCODE INT, TabErrorCode INT, editedby VARCHAR ( 200) , editedwhen datetime  DEFAULT CURRENT_TIMESTAMP )


IF OBJECT_ID('tempdb..##TMPbULKRET') IS NOT NULL
	TRUNCATE TABLE ##TMPbULKRET
ELSE
	Create TABLE ##tmpbulkret 
	(BulkInsId INT, 
	mem_id VARCHAR(20),	 
	medicare_no		VARCHAR(50)	 ,
	[plan]		VARCHAR(200)	, 
	prov_type	VARCHAR(50),	
	dos_dt	VARCHAR(20)	,
	dos_thru_dt		VARCHAR(20)	,
	retraction_flag		VARCHAR(20)	,
	diagnosis_code		VARCHAR(40)	 ,
	clm_no		VARCHAR(100)	 ,
	clmsource		VARCHAR(300)	,
	ICDVersion		INTEGER	, 
	ProviderNPI VARCHAR(10),
	filname VARCHAR ( 300),
	filetype VARCHAR ( 10) ) 
	--CREATE CLUSTERED INDEX IDX_C_tmpbulkret_BulkInsId ON ##tmpbulkret(BulkInsId);



--delete  BulkInsertContainer where isnull(Column0, '') =''

--    select * from BulkInsertContainer  order by bulkinsid
DECLARE @counterror AS INT, @FilName AS VARCHAR (  200), @filetype AS VARCHAR ( 200), @firststring AS VARCHAR ( 7800)
 
SET @FilName =  (SELECT TOP 1 filename from BulkInsertContainer )
--SET @filetype =   (SELECT left (REVERSE(left ( REVERSE( @FilName) , CHARINDEX (  '\' , REVERSE( @FilName) ) -1)),  CHARINDEX (  '.' ,REVERSE(left ( REVERSE( @FilName) , CHARINDEX (  '\' , REVERSE( @FilName) ) -1)))-1))
SET @filetype =   (SELECT left (REVERSE(left ( REVERSE( @FilName) , CHARINDEX (  '\' , REVERSE( @FilName) ) -1)),  CHARINDEX (  '.' ,REVERSE(left ( REVERSE( @FilName) , CHARINDEX (  '\' , REVERSE( @FilName) ) -1)))))
SET @firststring =(SELECT  REPLACE( ltrim(rtrim(COLUMN0)), CHAR(9),  ',')  FROM  BulkInsertContainer   WHERE BulkInsID =1)
--PRINT  '''' +  @filetype+ ''''



 IF OBJECT_ID('tempdb..##correctTableColumSequence') IS NOT NULL
 TRUNCATE TABLE ##correctTableColumSequence
 ELSE 
 CREATE TABLE  ##correctTableColumSequence  (Seqid INT IDENTITY  ( 1,1)  not null,  fieldnm VARCHAR ( 20), expectedlength INT )

--SELECT * from ##correctTableColumSequence

INSERT INTO ##correctTableColumSequence (fieldnm ,expectedlength ) VALUES ('mem_id',12)
INSERT INTO ##correctTableColumSequence (fieldnm ,expectedlength )  VALUES ('medicare_no',30)
INSERT INTO ##correctTableColumSequence (fieldnm ,expectedlength )  VALUES ('plan',5)
INSERT INTO ##correctTableColumSequence (fieldnm ,expectedlength )  VALUES ('prov_type',2)
INSERT INTO ##correctTableColumSequence (fieldnm ,expectedlength )  VALUES ('dos_dt',8)
INSERT INTO ##correctTableColumSequence (fieldnm ,expectedlength )  VALUES ('dos_thru_dt',8)
IF @filetype = 'CHSRAPR.' INSERT INTO ##correctTableColumSequence (fieldnm ,expectedlength )  VALUES ('retraction_flag',1)
INSERT INTO ##correctTableColumSequence (fieldnm ,expectedlength )  VALUES ('diagnosis_code',10)
INSERT INTO ##correctTableColumSequence (fieldnm ,expectedlength )  VALUES ('clm_no',16)
INSERT INTO ##correctTableColumSequence (fieldnm  ,expectedlength)  VALUES ('clmsource',12)
INSERT INTO ##correctTableColumSequence (fieldnm  ,expectedlength)  VALUES ('icdversion',2)




-- Error Code 2
IF @filetype = 'CHSRAPR.'

BEGIN
			-- THE LOGIC APPEARS TO BE VALIDATING THE TAB COUNT "LEN(CHAR(9))". 
			-- IN OTHER WORDS, IF THERE IS 10 TABS, THAT MEANS THAT THERE IS 11 COLUMNS. 
			-- A TAB BETWEEN EACH COLUMN 
			-- THE NOT LIKE '%MEM%MEDICARE%' WHERE CLAUSE WILL EXCLUDE THE HEADER ROW

		IF EXISTS 
		(
			SELECT 
				1 
			FROM BULKINSERTCONTAINER 
			WHERE CAST (BULKINSID AS INT ) = 1
			AND COLUMN0 LIKE '%NPI%'
		)
		BEGIN

			INSERT INTO ##ERRORLISTSSUBMISSIONRETRACTIONS ( BULKINSID, FILNAME, FILETYPE,  COL, ERRORCODE, EDITEDBY)
			SELECT 
				CAST (BULKINSID AS INT ) 
				,@FILNAME
				,@FILETYPE
				,COLUMN0
				,2 
				,SYSTEM_USER
			FROM BULKINSERTCONTAINER 
			WHERE (LEN(COLUMN0) - LEN(REPLACE(COLUMN0,CHAR(9),''))) / LEN(CHAR(9)) <> 11
			AND  COLUMN0 NOT LIKE '%MEM%MEDICARE%'
		END
		ELSE IF EXISTS 
		(
			SELECT 
				1 
			FROM BULKINSERTCONTAINER 
			WHERE CAST (BULKINSID AS INT ) = 1
			AND COLUMN0 NOT LIKE '%NPI%'
		)
		BEGIN
		
			INSERT INTO ##ERRORLISTSSUBMISSIONRETRACTIONS ( BULKINSID, FILNAME, FILETYPE,  COL, ERRORCODE, EDITEDBY)
			SELECT 
				CAST (BULKINSID AS INT ) 
				,@FILNAME
				,@FILETYPE
				,COLUMN0
				,2 
				,SYSTEM_USER
			FROM BULKINSERTCONTAINER 
			WHERE (LEN(COLUMN0) - LEN(REPLACE(COLUMN0,CHAR(9),''))) / LEN(CHAR(9)) <>10 
			AND  COLUMN0 NOT LIKE '%MEM%MEDICARE%'
		END
				
	
	--select count ( * )from 	BulkInsertContainer		
	--select * from 	BulkInsertContainer		where bulkinsid =1 

	-- select * from ##ErrorListsSubmissionRetractions
			--select * from ADHOC_SUBMISSIONS_ERROR_CODES
end;

IF @filetype = 'CHSRAPS.'

BEGIN 
		IF EXISTS 
		(
			SELECT 
				1 
			FROM BULKINSERTCONTAINER 
			WHERE CAST (BULKINSID AS INT ) = 1
			AND COLUMN0 LIKE '%NPI%'
		)
		BEGIN

			INSERT INTO ##ERRORLISTSSUBMISSIONRETRACTIONS ( BULKINSID, FILNAME, FILETYPE,  COL, ERRORCODE, EDITEDBY)
			SELECT 
				CAST (BULKINSID AS INT ) 
				,@FILNAME
				,@FILETYPE
				,COLUMN0
				,2 
				,SYSTEM_USER
			FROM BULKINSERTCONTAINER 
			WHERE (LEN(COLUMN0) - LEN(REPLACE(COLUMN0,CHAR(9),''))) / LEN(CHAR(9)) <> 10
			AND  COLUMN0 NOT LIKE '%MEM%MEDICARE%'
		END
		ELSE IF EXISTS 
		(
			SELECT 
				1 
			FROM BULKINSERTCONTAINER 
			WHERE CAST (BULKINSID AS INT ) = 1
			AND COLUMN0 NOT LIKE '%NPI%'
		)
		BEGIN
			
			/*NOT ENOUGH TAB DELIMITERS*/
			INSERT INTO ##ERRORLISTSSUBMISSIONRETRACTIONS ( BULKINSID, FILNAME, FILETYPE,  COL, ERRORCODE, EDITEDBY)
			SELECT 
				CAST (BULKINSID AS INT ) 
				,@FILNAME
				,@FILETYPE
				,COLUMN0
				,2 
				,SYSTEM_USER
			FROM BULKINSERTCONTAINER 
			WHERE (LEN(COLUMN0) - LEN(REPLACE(COLUMN0,CHAR(9),''))) / LEN(CHAR(9)) <>9
			AND  COLUMN0 NOT LIKE '%MEM%MEDICARE%'
		END
	

end;


-- NULL VALUES
--SELECT * from  BulkInsertContainer  order by bulkinsid WHERE column0 like '%'+ CHAR(9) + CHAR(9) +'%' 


 
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
				SELECT cast (BulkInsId AS INT ) , @FilName, @filetype,  Column0, 5 , SYSTEM_USER from BulkInsertContainer 
				 WHERE column0 like '%'+ CHAR(9) + CHAR(9) +'%' 
				 and  Column0 not like '%mem%medicare%';
			 
				 

--EMPTY STRING



--SELECT * from  BulkInsertContainer  WHERE  REPLACE (ltrim(rtrim(REPLACE( column0, CHAR(9) , '|'))) , ' ', '') like '%||%'
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
				SELECT cast (BulkInsId AS INT ) , @FilName, @filetype,  Column0, 5, SYSTEM_USER from BulkInsertContainer 
				 WHERE  REPLACE (ltrim(rtrim(REPLACE( column0, CHAR(9) , '|'))) , ' ', '') like '%||%'
				 and  Column0 not like '%mem%medicare%';
			

--			
---- IF there is no error yet, chop each row of data  ..  put this outside.
 


  IF OBJECT_ID('tempdb..##compareLengthAndSequence') IS NOT NULL
 TRUNCATE TABLE  ##compareLengthAndSequence
 ELSE 
 CREATE TABLE  ##compareLengthAndSequence
  ( seqid [int]  Not Null,
 fieldname VARCHAR ( 100) , 
 lengt int) ;




		-- TRUNCATE TABLE  ##tmpbulkret


		--select * from  ##tmpbulkret

IF @filetype = 'CHSRAPR.'
			BEGIN 

		
			INSERT INTO ##tmpbulkret (BulkInsId, mem_id, medicare_no, [plan], prov_type,dos_dt,dos_thru_dt,retraction_flag,diagnosis_code, clm_no,clmsource, icdversion,ProviderNPI,filname,filetype)
			
			SELECT cast( BulkInsId AS int)  BulkInsId ,
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 1))) mem_id, 
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 2))) medicare_no, 
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 3))) [plan], 
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 4))) prov_type, 
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 5))) dos_dt, 
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 6))) dos_thru_dt, 
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 7))) retraction_flag,
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 8))) diagnosis_code, 
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 9))) clm_no, 
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 10))) clmsource, 
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 11))) icdversion, 
			ltrim(rtrim([dbo].[NTH_WORD_TAB] (column0, 12))) ProviderNPI,
			 @FilName filname,  @filetype filetype --into ##tmpbulkret
			from BulkInsertContainer  WHERE BulkInsId  <> 1  and BulkInsId not in  (SELECT BulkInsId from  ##ErrorListsSubmissionRetractions  )
			 and  Column0 not like '%mem%medicare%'

			 --PRINT '1'



		
		INSERT INTO  ##compareLengthAndSequence ( SEQID,  fieldname, lengt) 
		SELECT SEQID, fieldname, lengt  from  
		(SELECT 1 SEQID,  'mem_id' AS fieldname, max(LEN(mem_id))  lengt from  ##TMPbULKRET
		union 
		SELECT  2,'medicare_no' AS fieldname, max(LEN(medicare_no))   from  ##TMPbULKRET
		union 
		SELECT  3,'plan' AS fieldname, max(LEN([plan]))   from  ##TMPbULKRET
		union 
		SELECT  4,'prov_type' AS fieldname, max(LEN(prov_type))   from  ##TMPbULKRET 
		union 
		SELECT  5,'dos_dt' AS fieldname, max(LEN(dos_dt))   from  ##TMPbULKRET 
		union 
		SELECT 6, 'dos_thru_dt' AS fieldname, max(LEN(dos_thru_dt))   from  ##TMPbULKRET 
		union 
		SELECT  7,'retraction_flag' AS fieldname, max(LEN(retraction_flag))   from  ##TMPbULKRET 
		union 
		SELECT 8, 'diagnosis_code' AS fieldname, max(LEN(diagnosis_code))   from  ##TMPbULKRET 
		union 
		SELECT  9,'clm_no' AS fieldname, max(LEN(clm_no))   from  ##TMPbULKRET 
		union 
		SELECT  10,'clmsource' AS fieldname, max(LEN(clmsource))   from  ##TMPbULKRET 
		union 
		SELECT  11,'icdversion' AS fieldname, max(LEN(icdversion))   from  ##TMPbULKRET )     a
	


			 --PRINT '2'


	
		INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, TabErrorCode, editedby)
		SELECT cast (BulkInsId AS INT ) ,  @FilName, @filetype, 
		 Column0, 5, SYSTEM_USER from BulkInsertContainer 
			WHERE  BulkInsId in ( 
			SELECT BulkInsId FROM ##TMPbULKRET  WHERE 
		( ISNULL(mem_id, '')			= ''
		OR ISNULL(medicare_no, '')		= ''
		OR ISNULL([plan], '')			= ''
		OR ISNULL(prov_type, '')		= ''
		OR ISNULL(dos_dt, '')			= ''
		OR ISNULL(dos_thru_dt, '')		= ''
		OR ISNULL(retraction_flag, '')		= ''
		OR ISNULL(diagnosis_code, '')	= ''
		OR ISNULL(clm_no, '')			= ''
		OR ISNULL(clmsource, '')		= ''
		OR ISNULL(icdversion, '')		= '')) 

			end;
					 --PRINT '3'

-- CHSRAPS means Submissions
IF @filetype = 'CHSRAPS.'
			BEGIN 

		
				INSERT INTO ##tmpbulkret (BulkInsId, mem_id, medicare_no, [plan], prov_type,dos_dt,dos_thru_dt,diagnosis_code,
				clm_no,clmsource, icdversion,ProviderNPI,filname,filetype)

				SELECT CAST(BulkInsId AS INT) , [dbo].[NTH_WORD_TAB] (column0, 1) mem_id, [dbo].[NTH_WORD_TAB] (column0, 2) medicare_no, 
				[dbo].[NTH_WORD_TAB] (column0, 3) [plan], [dbo].[NTH_WORD_TAB] (column0, 4) prov_type, 
				[dbo].[NTH_WORD_TAB] (column0, 5) dos_dt, [dbo].[NTH_WORD_TAB] (column0, 6) dos_thru_dt, 
				[dbo].[NTH_WORD_TAB] (column0, 7) diagnosis_code, [dbo].[NTH_WORD_TAB] (column0, 8) clm_no, 
				[dbo].[NTH_WORD_TAB] (column0, 9) clmsource, [dbo].[NTH_WORD_TAB] (column0, 10) icdversion ,  [dbo].[NTH_WORD_TAB] (column0, 11) ProviderNPI,@FilName,  @filetype
	
				 from BulkInsertContainer  WHERE BulkInsId  <> 1  and BulkInsId not in  (SELECT BulkInsId from  ##ErrorListsSubmissionRetractions  )
				 and  Column0 not like '%mem%medicare%'
	
			 --PRINT '4'
--truncate TABLE  SELECT * from  ##compareLengthAndSequence
--TRUNCATE TABLE ##compareLengthAndSequence

				INSERT INTO  ##compareLengthAndSequence ( SEQID,  fieldname, lengt) 
				SELECT SEQID, fieldname, lengt  from  
				(SELECT 1 SEQID,  'mem_id' AS fieldname, max(LEN(mem_id))  lengt from  ##TMPbULKRET
				union 
				SELECT 2,  'medicare_no' AS fieldname, max(LEN(medicare_no))   from  ##TMPbULKRET
				union 
				SELECT  3, 'plan' AS fieldname, max(LEN([plan]))   from  ##TMPbULKRET
				union 
				SELECT 4,  'prov_type' AS fieldname, max(LEN(prov_type))   from  ##TMPbULKRET 
				union 
				SELECT  5,'dos_dt' AS fieldname, max(LEN(dos_dt))   from  ##TMPbULKRET 
				union 
				SELECT 6, 'dos_thru_dt' AS fieldname, max(LEN(dos_thru_dt))   from  ##TMPbULKRET 
				union 
				SELECT 7, 'diagnosis_code' AS fieldname, max(LEN(diagnosis_code))   from  ##TMPbULKRET 
				union 
				SELECT 8, 'clm_no' AS fieldname, max(LEN(clm_no))   from  ##TMPbULKRET 
				union 
				SELECT 9, 'clmsource' AS fieldname, max(LEN(clmsource))   from  ##TMPbULKRET 
				union 
				SELECT 10, 'icdversion' AS fieldname, max(LEN(icdversion))   from  ##TMPbULKRET )     a

		 --PRINT '5'
	

				
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, filetype, Col, TabErrorCode, editedby)
				SELECT cast (BulkInsId AS INT ) , @FilName, @filetype,  Column0, 5, SYSTEM_USER from BulkInsertContainer 
				 WHERE  BulkInsId in ( 
				 SELECT BulkInsId FROM ##TMPbULKRET  WHERE 
				  ( ISNULL(mem_id, '')			= ''
				OR ISNULL(medicare_no, '')		= ''
				OR ISNULL([plan], '')			= ''
				OR ISNULL(prov_type, '')		= ''
				OR ISNULL(dos_dt, '')			= ''
				OR ISNULL(dos_thru_dt, '')		= ''
				OR ISNULL(diagnosis_code, '')	= ''
				OR ISNULL(clm_no, '')			= ''
				OR ISNULL(clmsource, '')		= ''
				OR ISNULL(icdversion, '')		= '')) 
				
				
			end;
 		 --PRINT '6'
 
-- IF sequence is wrong or length can be truncated


		/*

		SELECT * FROM ##correctTableColumSequence 
		SELECT * FROM ##compareLengthAndSequence
				
		SELECT * FROM ##correctTableColumSequence A LEFT JOIN 
		 ##compareLengthAndSequence B ON a.seqid = b.seqid    WHERE b.seqid is null


		*/


		SET @counterror = (SELECT count(*) FROM ##correctTableColumSequence A LEFT JOIN 
		 ##compareLengthAndSequence B ON a.seqid = b.seqid    WHERE b.seqid is null ) 

				IF @counterror  >0
				BEGIN			
							
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCode, editedby)
				SELECT 1 , @FilName, @filetype,  Column0, 18, SYSTEM_USER from BulkInsertContainer  WHERE bulkinsid = 1 or   Column0 like '%mem%medicare%'
				end;

				
		 
 
		SET @counterror = (SELECT COUNT(*) FROM ##correctTableColumSequence A LEFT JOIN 
		 ##compareLengthAndSequence B ON a.seqid = b.seqid    WHERE a.fieldnm <> b.fieldname ) 

				IF @counterror  >0
				BEGIN			
							
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCode, editedby)
				SELECT 1 , @FilName, @filetype,  
				Column0, 18, SYSTEM_USER from BulkInsertContainer  WHERE bulkinsid = 1 or   Column0 like '%mem%medicare%'
				end;

		/*		
		SELECT * FROM ##correctTableColumSequence A LEFT JOIN 
		 ##compareLengthAndSequence B ON a.seqid = b.seqid    WHERE 
		 ( a.fieldnm= b.fieldname AND A.expectedlength <b.lengt)
*/
		-- 3411 we need to ignore this condition   
		--SET @counterror = (  SELECT COUNT(*) FROM ##correctTableColumSequence A LEFT JOIN 
		-- ##compareLengthAndSequence B ON a.seqid = b.seqid    WHERE 
		-- ( a.fieldnm= b.fieldname AND A.expectedlength <b.lengt) )

		--		IF @counterror  >0
		--		BEGIN			
							
		--		INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCode, editedby)
		--		SELECT 1 , @FilName, @filetype,  
		--		Column0, 19, SYSTEM_USER from BulkInsertContainer  WHERE bulkinsid = 1 or   Column0 like '%mem%medicare%'
		--		end;



		 --PRINT '7'
	-- this is the end of by bulk filters. IF there is an error here , no need to go to the next filters because errors here would be the reason for the next errors, so escape proc.
				

				SET @counterror = ( SELECT count (*) from ##ErrorListsSubmissionRetractions) 
				IF @counterror  >0 
				RETURN;

 
	--one memid per medicareno   -- 3411 one member with more than 1 medicare id

				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)			
			
				SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0, 3 , SYSTEM_USER from BulkInsertContainer A
				JOIN 
				(SELECT BulkInsId FROM  ##TMPbULKRET WHERE  BulkInsId NOT IN ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions)  AND  mem_id IN  (SELECT mem_id FROM   (SELECT mem_id, medicare_no FROM ##TMPbULKRET  GROUP BY  mem_id, medicare_no ) B
				GROUP BY mem_id HAVING COUNT (*) > 1 )) C
				ON A.BulkInsId = C.BulkInsId ;
				



					
--one medicareno per memid  
	
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)

				SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0, 3, SYSTEM_USER from BulkInsertContainer A
				JOIN
				(SELECT BulkInsId FROM  ##TMPbULKRET WHERE  BulkInsId NOT IN ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions)  AND medicare_no IN  (SELECT medicare_no FROM   (SELECT mem_id, medicare_no FROM ##TMPbULKRET  GROUP BY  mem_id, medicare_no ) B
				GROUP BY medicare_no HAVING COUNT (*) > 1 )) C 
				ON A.BulkInsId = C.BulkInsId;
				




-- DATES NOT VALID FORMAT


				--
				--SELECT cast (BulkInsId AS INT ) , @FilName, @filetype,  Column0, 7, SYSTEM_USER from BulkInsertContainer 
				-- WHERE  BulkInsId in   (  SELECT BulkInsId  FROM ##TMPbULKRET  WHERE  isdate(dos_dt ) = 0
				--or  LEN(dos_dt) <> 8 or  cast (substring(  dos_dt, 5, 2)   AS INT ) not between 1 and 12  or 
				--cast (substring(  dos_dt, 7, 2) AS INT ) not between 1 and 31);
		 

		 --REWRITE:
		 INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
		 	SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0, 7, SYSTEM_USER 
			from BulkInsertContainer   A
			JOIN
				 (  SELECT BulkInsId  FROM ##TMPbULKRET  WHERE  BulkInsId NOT IN ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
					 AND (   isdate(dos_dt ) = 0
								OR  LEN(dos_dt) <> 8 or  cast (substring(  dos_dt, 5, 2)   AS INT ) not between 1 and 12  
								OR CAST(substring(  dos_dt, 7, 2) AS INT ) not between 1 and 31) 
								OR dos_dt  NOT LIKE '[1-2][0-9][0-9][0-9][0-1][0-9][0-3][0-9]')  B 
								ON A.BulkInsId = B.BulkInsId ;
		 

				--SELECT * from ##TMPbULKRET


---- delete this SET when you have proven that Cognizant code is useless

--				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname,FileType, Col, TabErrorCODE, editedby)
--				SELECT cast (BulkInsId AS INT ) , @FilName, @filetype,  Column0, 7, SYSTEM_USER from BulkInsertContainer  WHERE BulkInsId in 
--				( SELECT BulkInsId from ##TMPbULKRET  WHERE   LEN(dos_dt) <> 8 or   DATALENGTH(dos_dt) <> 8);
--				--and  Column0 not like '%mem%medicare%'
				


--Second Date not valid

			
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)

				SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0, 8, SYSTEM_USER 
				from BulkInsertContainer  A
				  JOIN  
					(  SELECT BulkInsId  FROM ##TMPbULKRET  WHERE  BulkInsId NOT IN 
						( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions)  AND  isdate(dos_thru_dt ) = 0
							or  LEN(dos_thru_dt) <> 8 or  cast (substring(  dos_thru_dt, 5, 2)   AS INT ) not between 1 and 12  
							or 	cast (substring(  dos_thru_dt, 7, 2) AS INT ) not between 1 and 31
							OR  dos_thru_dt  NOT LIKE '[1-2][0-9][0-9][0-9][0-1][0-9][0-3][0-9]') C 
		 				 ON A.BulkInsId = C.BulkInsId ;
				
		-----------------------------------------------------------------------------------------------------------------------------------		

		
		----cognizant code on second date

				
		--		INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, TabErrorCODE, editedby)
		--		SELECT cast (BulkInsId AS INT ) , @FilName, @filetype,  Column0, 8, SYSTEM_USER from BulkInsertContainer  WHERE BulkInsId in 
		--		( SELECT BulkInsId from ##TMPbULKRET  WHERE   LEN(dos_thru_dt) <> 8 or   DATALENGTH(dos_thru_dt) <> 8);
	


---* Valid prov type only equal 01, 02, 10, 20  -- there should be 0 before    - WHERE is this???

--SELECT * from ##TMPbULKRET WHERE prov_type not in  ( '01','02','10','20')
--SELECT [dbo].[NTH_WORD_TAB] (column0, 4) t,  * from BulkInsertContainer WHERE ltrim(rtrim( [dbo].[NTH_WORD_TAB] (column0, 4) )) not in  ( '01','02','10','20')

				
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, TabErrorCODE,editedby)
				SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0, 26,26, SYSTEM_USER from BulkInsertContainer A
				JOIN
				( SELECT BulkInsId from ##TMPbULKRET WHERE  BulkInsId NOT IN 
			    ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
				 AND prov_type not in  ( '01','02','10','20')) B
				 ON A.BulkInsId = B.BulkInsId ;
			

--diag code does not contain decimal    'DIAGNOSIS CODE HAS PERIOD' 
--SELECT [dbo].[NTH_WORD_TAB] (column0, 7) t,  * from BulkInsertContainer WHERE [dbo].[NTH_WORD_TAB] (column0, 7) LIKE '%.

							
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, TabErrorCODE, editedby)
				SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0, 9,9, SYSTEM_USER from BulkInsertContainer A
				JOIN 
				( SELECT BulkInsId from ##TMPbULKRET WHERE BulkInsId NOT IN 
			  ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
				 AND  diagnosis_code LIKE '%.%') B ON A.BulkInsId = B.BulkInsId ;


--* diag code only 3 to 7 characters  --

--SELECT [dbo].[NTH_WORD_TAB] (column0, 7) t,  * from BulkInsertContainer WHERE LEN( [dbo].[NTH_WORD_TAB] (column0, 7) ) NOT BETWEEN 3 AND 7
---'DIAGNOSIS CODE DOES NOT HAVE CORRECT LENGTH'
		
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, TabErrorCODE, editedby)
				SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0, 10, 10, SYSTEM_USER from BulkInsertContainer 
				A JOIN 
				 ( SELECT BulkInsId from ##TMPbULKRET WHERE  BulkInsId NOT IN 
			  ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
				 AND  LEN(diagnosis_code) NOT BETWEEN 3 AND 7) B
				ON A.BulkInsId = B.BulkInsId ;

--CLAIM has more than one MEMID

			
				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
				SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0,
				11 , SYSTEM_USER from BulkInsertContainer  A
				
				JOIN

				(SELECT BulkInsId FROM   ##TMPbULKRET WHERE BulkInsId NOT IN 
			  ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
				 AND clm_no IN 
				(SELECT clm_no FROM
				(SELECT mem_id, clm_no FROM ##TMPbULKRET  GROUP BY  mem_id, clm_no ) A
				GROUP BY clm_no HAVING COUNT (*) > 1 ) ) B ON A.BulkInsId = B.BulkInsId  ;

--  Claim has more than one medicare_no -- 3411 claim can have more than one medicare #

				--INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
				--SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0,
				--12 , SYSTEM_USER from BulkInsertContainer  A
				--JOIN
				
				--(SELECT BulkInsId FROM   ##TMPbULKRET WHERE BulkInsId NOT IN 
			 -- ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
				-- AND  clm_no IN 
				--(SELECT clm_no FROM
				--(SELECT medicare_no, clm_no FROM ##TMPbULKRET  GROUP BY  medicare_no, clm_no ) A
				--GROUP BY clm_no HAVING COUNT (*) > 1 ) ) B
				--	ON A.BulkInsId = B.BulkInsId ;			

			

--DATE RANGE IS OFF, DOSDATE BIGGER THAN ENDDATE
/*

( SELECT * FROM  BulkInsertContainer  WHERE BulkInsId IN 
(SELECT BulkInsId FROM ##TMPbULKRET  WHERE DOS_DT>dos_thru_dt  ) )

*/


				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
				SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  
				Column0, 21 , SYSTEM_USER from BulkInsertContainer A
				JOIN 
				(SELECT BulkInsId FROM ##TMPbULKRET  WHERE   BulkInsId NOT IN 
			  ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
				 AND DOS_DT >dos_thru_dt ) B ON A.BulkInsId = B.BulkInsId ;

				
--DATE RANGE VS ICD 9 0R ICD 10


--SELECT * FROM ##TMPbULKRET WHERE  	 (dos_thru_dt >= '20151001' AND icdversion <> '10') or 	(dos_thru_dt < '20151001' AND icdversion <> '9')


				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, TabErrorCode, editedby)
				SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0,
				 20 ,20,  SYSTEM_USER from BulkInsertContainer A
				 JOIN 
					(SELECT BulkInsId FROM ##TMPbULKRET  
				where BulkInsId NOT IN 
			  ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
				 AND 
				 ((dos_thru_dt >= '20151001' AND icdversion <> '10') 
				 or 
					(dos_thru_dt < '20151001' AND icdversion <> '9'  ) 
					)) B ON A.BulkInsId = B.BulkInsId; 
				
				


				--SELECT * FROM ##TMPbULKRET
				


	/*
		-Retraction/Overpayment Check all dos thru dt DOSYR against (current year - 2) to flag records for review to determine if possible overpayment
	*/
 --IF @filetype = 'CHSRAPS.' BEGIN  -- 3411 DOS check for 2 years for submission files only 
	--INSERT INTO ##ErrorListsSubmissionRetractions 
	--( 
	--	BulkInsId
	--	,Filname
	--	,FileType
	--	,Col
	--	,ErrorCODE
	--	,editedby
	--)
	--SELECT 
	--	CAST (A.BulkInsId AS INT ) 
	--	,@FilName
	--	,@filetype
	--	,Column0
	--	,23 
	--	,SYSTEM_USER 
	--FROM BulkInsertContainer A
	--JOIN ##TMPbULKRET B
	--	ON B.BulkInsId = A.BulkInsId
	--WHERE NOT EXISTS (
	--					SELECT 1
	--					FROM ##ErrorListsSubmissionRetractions C
	--					WHERE C.BulkInsId = B.BulkInsId
	--				)
	--AND DATEDIFF(YEAR,B.DOS_THRU_DT,GETDATE()) > 2
	----AND DATEDIFF(YEAR,B.DOS_THRU_DT,GETDATE()) > 6

	--END

	

	/*
		-Error out any special characters in clm_no column (i.e. +, *, #, @, &, %, ~, $, _, -, etc...)
	*/

	INSERT INTO ##ErrorListsSubmissionRetractions 
	( 
		BulkInsId
		,Filname
		,FileType
		,Col
		,ErrorCODE
		,editedby
	)
	SELECT 
		CAST (A.BulkInsId AS INT ) 
		,@FilName
		,@filetype
		,Column0
		,24 -- Need the error code for Non-Alpha Numeric Claim Number
		,SYSTEM_USER 
	FROM BulkInsertContainer A
	JOIN ##TMPbULKRET B
		ON B.BulkInsId = A.BulkInsId
	WHERE NOT EXISTS (
						SELECT 1
						FROM ##ErrorListsSubmissionRetractions C
						WHERE C.BulkInsId = B.BulkInsId
					)
	AND B.CLM_NO LIKE '%[^_a-Z0-9]%' -- Data should only be Alpha Numeric. Error Out anything that is not Alpha Numeric
									 -- added underscore _  to valid character in clm no 2 years




/* PLAN  LENGTH IS GREATER THAN 5

( SELECT * FROM  BulkInsertContainer  WHERE BulkInsId IN 
(SELECT BulkInsId FROM ##TMPbULKRET  WHERE LEN( [PLAN] ) > 5  ) 
)

*/

 			INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
			SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0,
			22 , SYSTEM_USER from BulkInsertContainer A
			JOIN  
			(SELECT BulkInsId FROM ##TMPbULKRET  WHERE BulkInsId NOT IN 
			  ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
				 AND  LEN( [PLAN] ) > 5  )  B 	ON A.BulkInsId = B.BulkInsId ;

				
--•Hplan is only a valid hplan for CHS (compare to table) ****USE [dbo].[Raps_Plans]


		

				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
				SELECT cast (Q.BulkInsId AS INT ) , @FilName, @filetype,  Column0,
				 14 , SYSTEM_USER from BulkInsertContainer Q
				 JOIN  
					(SELECT BulkInsId FROM ##TMPbULKRET a left join [dbo].[Raps_Plans]  b on
					a.[plan] =b.plan_id WHERE  BulkInsId NOT IN 
			  ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
				 AND  b.plan_id is null ) R ON Q.BulkInsId = R.BulkInsId  ;


--Retraction file has no ret. -- 4311 _RET not needed 

--IF @filetype = 'CHSRAPR.'  -- no RET in source
--			BEGIN 
--				INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
--				SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0,
--				 16 , SYSTEM_USER from BulkInsertContainer A
--				 JOIN 
--					(SELECT BulkInsId FROM ##TMPbULKRET  WHERE   BulkInsId NOT IN 
--			  ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
--				 AND RTRIM(clmsource) not like '%_RET' )   B
--				 ON A.BulkInsId = B.BulkInsId

				
--			end;


	/*
		-Retraction/Overpayment Check all dos thru dt DOSYR against (current year - 6) to flag records for review to determine if possible overpayment
	*/
	--IF @filetype = 'CHSRAPR.'  
	--		BEGIN 
	--		INSERT INTO ##ErrorListsSubmissionRetractions 
	--			( 
	--				BulkInsId
	--				,Filname
	--				,FileType
	--				,Col
	--				,ErrorCODE
	--				,editedby
	--			)
	--			SELECT 
	--				CAST (A.BulkInsId AS INT ) 
	--				,@FilName
	--				,@filetype
	--				,Column0
	--				,23 
	--				,SYSTEM_USER 
	--			FROM BulkInsertContainer A
	--			JOIN ##TMPbULKRET B
	--				ON B.BulkInsId = A.BulkInsId
	--			WHERE NOT EXISTS (
	--								SELECT 1
	--								FROM ##ErrorListsSubmissionRetractions C
	--								WHERE C.BulkInsId = B.BulkInsId
	--							)
	--			--AND DATEDIFF(YEAR,B.DOS_THRU_DT,GETDATE()) > 2
	--			AND DATEDIFF(YEAR,B.DOS_THRU_DT,GETDATE()) > 6

	--END


--SELECT * from ##TMPbULKRET  WHERE RTRIM(clmsource) not like '%_RET'


--•sourcedesc not consistent with crosswalk TABLE (Create table)colored text ***USE [DBO].[RAPS_SOURCE_SOURCE_DESC_TYPE]****
 

--- SELECT * from [RAPS].[DBO].[RAPS_SOURCE_SOURCE_DESC_TYPE]  where SOURCEDESC ='leon'


				--INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
				--SELECT cast (BulkInsId AS INT )  , @FilName, @filetype, 
				-- Column0,
				-- 15 , SYSTEM_USER from BulkInsertContainer 
				-- WHERE BulkInsId IN 
				--	(SELECT BulkInsId FROM ##TMPbULKRET a left join 
				--	[DBO].[RAPS_SOURCE_SOURCE_DESC_TYPE] b 
				--	on b.source = CASE WHEN  @filetype = 'CHSRAPR.'  THEN '990' ELSE '980' END -- 2 years for submissions 980 for retraction 990 
				--	AND (  a.clmsource  = b.SOURCEDESC
				--			OR a.clmsource  = b.originated )
				--	 WHERE  b.SOURCEDESC is null )  
					--a.clmsource=b.SOURCEDESC WHERE  b.SOURCEDESC is null )  

-- 3411 provider NPI check it can be blank or number can't have letters


			INSERT INTO ##ErrorListsSubmissionRetractions ( BulkInsId, Filname, FileType,  Col, ErrorCODE, editedby)
			SELECT cast (A.BulkInsId AS INT ) , @FilName, @filetype,  Column0,
			25, SYSTEM_USER from BulkInsertContainer A
			JOIN  
			(SELECT BulkInsId FROM ##TMPbULKRET  WHERE BulkInsId NOT IN 
			  ( SELECT BulkInsId FROM ##ErrorListsSubmissionRetractions) 
				 AND  ISNUMERIC(CASE WHEN LEN(LTRIM(RTRIM(PROVIDERNPI))) = 0 THEN '0' ELSE REPLACE(LTRIM(RTRIM(ISNULL(PROVIDERNPI,'0'))),'','0') END) = 0  )  B 	ON A.BulkInsId = B.BulkInsId ;
					

				  SET NOCOUNT OFF;

					

 --compare

	--  SELECT * from ##ADHOC_SUBMISSIONS_ERROR_CODES
	/*

 SELECT w.* , c.errorcode, d.taberrorcode from  
 	(SELECT a.col, a.BulkInsId, a.ErrorCODE,  b.errordesc, b.as_ERR_CODE   from ##ErrorListsSubmissionRetractions a  join ##ADHOC_SUBMISSIONS_ERROR_CODES b on a.errorcode = b.as_ERR_CODE  WHERE A.errorcode is not null AND A.errorcode NOT IN ( 1, 2)
	union 
	SELECT x.col,  x.BulkInsId, x.taberrorcode,  y.errordesc, y.as_ERR_CODE  from ##ErrorListsSubmissionRetractions x  join ##ADHOC_SUBMISSIONS_ERROR_CODES y on x.taberrorcode = y.as_ERR_CODE WHERE isnull(x.taberrorcode,'') <>'' ) w

	left join  ##ErrorListsSubmissionRetractions c on w.ErrorCODE = c.errorcode    and w.BulkInsId = c.BulkInsId  

	left join ##ErrorListsSubmissionRetractions d on w.ErrorCODE = d.taberrorcode    and w.BulkInsId = d.BulkInsId  

	--WHERE  w.BulkInsId <>1
	order by w.BulkInsId

	select DISTINCT w.COL , W.errordesc ,  w.BulkInsId ROWID   from  
 	(select a.col, a.BulkInsId, a.ErrorCODE,  b.errordesc, b.as_ERR_CODE   from ##ErrorListsSubmissionRetractions a  join ##ADHOC_SUBMISSIONS_ERROR_CODES b 
	on a.errorcode = b.as_ERR_CODE  where A.errorcode is not null -- AND A.errorcode NOT IN ( 1, 2)
	) W
	
	 join  ##ErrorListsSubmissionRetractions c on w.ErrorCODE = c.errorcode    and w.BulkInsId = c.BulkInsId  
	 
	where  w.BulkInsId <>1
	order by w.BulkInsId


	------------------
	 SELECT DISTINCT w.COL , W.errordesc ,  w.filname  filename,  w.BulkInsId ROWID from  
 	(SELECT a.col, a.BulkInsId, a.ErrorCODE,  b.errordesc, b.as_ERR_CODE ,a.filname  from ##ErrorListsSubmissionRetractions a  join ##ADHOC_SUBMISSIONS_ERROR_CODES b 
	on a.errorcode = b.as_ERR_CODE  WHERE A.errorcode is not null -- AND A.errorcode NOT IN ( 1, 2)
	) W
		 join  ##ErrorListsSubmissionRetractions c on w.ErrorCODE = c.errorcode    and w.BulkInsId = c.BulkInsId  
	 	order by w.BulkInsId
		--------------------------
	select * from ##ErrorListsSubmissionRetractions

				*/

	end 