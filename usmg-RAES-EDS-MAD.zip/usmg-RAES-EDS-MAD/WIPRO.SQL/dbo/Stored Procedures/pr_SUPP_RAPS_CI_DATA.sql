﻿CREATE PROCEDURE dbo.pr_SUPP_RAPS_CI_DATA
/******************************************
Creation Date 7/24/2019
Author: ASU
Loads "SUPP_RAPS_CI_DATA" items into Supplemental_Input

Notes:
-----------------------------------------------------
05/04/2023			ASU			RETM-235
								Updates to get NPI and TaxID
*/
AS

SET NOCOUNT ON;
SET ANSI_NULLS ON;
IF OBJECT_ID('tempdb.dbo.#fast_prov') IS NOT NULL
	DROP TABLE #fast_prov;

IF OBJECT_ID('tempdb.dbo.#Raw_Pull') IS NOT NULL
	DROP TABLE #Raw_Pull;

CREATE TABLE #Raw_Pull
(
	Plan_no VARCHAR(5),
	HicNo VARCHAR(20),
	X_HICN VARCHAR(12),
	X_MBI VARCHAR(11),
	MemberID VARCHAR(16),
	From_Date date,
	Thru_Date DATE,
	Provider_Type VARCHAR(2),
	DxCode VARCHAR(10),
	icdversion INT,
	SourceSystem VARCHAR(20),
	SourceSystemNumber VARCHAR(20),
	SourceType VARCHAR(200),
	Patient_Control_No VARCHAR(70),
	DOS_YR VARCHAR(4),
	Linked_Claim_number VARCHAR(20),
	WIPRO_CLAIM_NO VARCHAR(20),
	CHS_CLM_EDPS VARCHAR(20),
	CMS_ICN VARCHAR(20),
	Supp_Type VARCHAR(20),
	[Data_Source] VARCHAR(25),
	DocumentProvID VARCHAR(20),
	ChartProv VARCHAR(20),
	ChartChase_NPI VARCHAR(20),
	EXCL_ID VARCHAR(2),
	Status_Code VARCHAR(3) DEFAULT '000',
	Status_desc VARCHAR(20) DEFAULT 'New_Claims',
	Process_Date DATE,
	Last_Modified_Date DATE,
	PCP_ID VARCHAR(50),
	NPI_Source VARCHAR(50),
	Tax_ID VARCHAR(50)
);

CREATE CLUSTERED INDEX idx_RP
ON #Raw_Pull (MemberID, ChartProv, PCP_ID)
WITH (PAD_INDEX = ON);

--Get current load key from table
DECLARE @Process_Date DATE = GETDATE(),
		@Load_Key INT = (SELECT MAX(srcd1.Load_Key) FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd1);


/*begin npi data gather*/
IF OBJECT_ID('tempdb.dbo.#NPI_Source') IS NOT NULL
	DROP TABLE #NPI_Source;

CREATE TABLE #NPI_Source
(
	Provider_ID VARCHAR(50),
	NPI VARCHAR(50),
	NPI_Source VARCHAR(50),
	TAX_ID VARCHAR(25)
);

--create index to silently drop NPIs already gathered below
CREATE UNIQUE CLUSTERED INDEX idx_Provider_ID_npi
ON #NPI_Source (Provider_ID, NPI)
WITH (IGNORE_DUP_KEY = ON, PAD_INDEX = ON);

/**************************************
get npi data for use later
use NPI check function to validate NPI
***************************************/

INSERT INTO #NPI_Source (Provider_ID, NPI, NPI_Source)	
SELECT
	cp.ProviderID,
	cp.ProviderNPI,
	NPI_Source = 'Document PROVID'
FROM EDPS_Data.dbo.Common_Provider cp
CROSS APPLY (SELECT * FROM WIPRO.dbo.fn_NPI_Calculate_Check_Digit_Luhn(cp.ProviderNPI)) fnccdl
WHERE 1 = 1
	AND fnccdl.CheckDigit = TRY_CAST(RIGHT(cp.ProviderNPI, 1) AS INT)
	AND fnccdl.CheckDigit IS NOT NULL
	AND EXISTS (	SELECT * 
					FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd 
					WHERE srcd.Document_Prov_ID = cp.ProviderID AND srcd.Load_Key = @Load_Key)
UNION
SELECT
	pd.ProviderID,
	pd.NPID,
	NPI_Source = 'Document PROVID'
FROM EDPS_Data.dbo.ProviderDim pd
CROSS APPLY (SELECT * FROM WIPRO.dbo.fn_NPI_Calculate_Check_Digit_Luhn(pd.NPID)) fnccdl
WHERE 1 = 1
	AND fnccdl.CheckDigit = TRY_CAST(RIGHT(pd.NPID, 1) AS INT)
	AND fnccdl.CheckDigit IS NOT NULL
	AND pd.ProviderStatus = 'active'
	AND EXISTS (	SELECT *
					FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd
					WHERE srcd.Document_Prov_ID = pd.ProviderID AND srcd.Load_Key = @Load_Key);

--check same tables using chart_prov column
INSERT INTO #NPI_Source (Provider_ID, NPI, NPI_Source)	
SELECT
	cp.ProviderID,
	cp.ProviderNPI,
	NPI_Source = 'Chart NPI'
FROM EDPS_Data.dbo.Common_Provider cp
CROSS APPLY (SELECT * FROM WIPRO.dbo.fn_NPI_Calculate_Check_Digit_Luhn(cp.ProviderNPI)) fnccdl
WHERE 1 = 1
	AND fnccdl.CheckDigit = TRY_CAST(RIGHT(cp.ProviderNPI, 1) AS INT)
	AND fnccdl.CheckDigit IS NOT NULL
	AND EXISTS (	SELECT * 
					FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd 
					WHERE srcd.Chart_Prov = cp.ProviderID AND srcd.Load_Key = @Load_Key)
UNION
SELECT
	pd.ProviderID,
	pd.NPID,
	NPI_Source = 'Chart NPI'
FROM EDPS_Data.dbo.ProviderDim pd
CROSS APPLY (SELECT * FROM WIPRO.dbo.fn_NPI_Calculate_Check_Digit_Luhn(pd.NPID)) fnccdl
WHERE 1 = 1
	AND fnccdl.CheckDigit = TRY_CAST(RIGHT(pd.NPID, 1) AS INT)
	AND fnccdl.CheckDigit IS NOT NULL
	AND pd.ProviderStatus = 'active'
	AND EXISTS (	SELECT *
					FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd
					WHERE srcd.Chart_Prov = pd.ProviderID AND srcd.Load_Key = @Load_Key);
/********************
end npi data gather
*********************/

/***************************************************
get arbitrary MedicareID (could be a problem point)
****************************************************/
IF OBJECT_ID('tempdb.dbo.#member_mash') IS NOT NULL
	DROP TABLE #member_mash;

CREATE TABLE #member_mash
(
	MedicareID VARCHAR(250),
	MemberID VARCHAR(50)
);

CREATE UNIQUE CLUSTERED INDEX idxc_member_mash
ON #member_mash (MemberID, medicareID) WITH (IGNORE_DUP_KEY = ON, PAD_INDEX = ON);

WITH mem1 AS (
SELECT 
	md1.MedicareID,
	md1.MemberID,
	RN = ROW_NUMBER() OVER (PARTITION BY md1.MemberID ORDER BY md1.MemberKey DESC, md1.LoadDateKey DESC)
FROM MDQOLib.dbo.MemberDim md1
WHERE EXISTS (SELECT * FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd WHERE srcd.Member_ID = md1.MemberID AND srcd.Load_Key = @Load_Key))
INSERT INTO #member_mash
SELECT
	MedicareID
   ,MemberID
FROM mem1
WHERE RN = 1; --<<-- Take latest (arbitrary) record

WITH mem2 AS (
	SELECT
		md2.MedicareID,
		md2.MemberID,
		RN = ROW_NUMBER() OVER (PARTITION BY md2.MemberID ORDER BY md2.MemberKey DESC, md2.LoadDateKey DESC)
	FROM EDPS_Data.dbo.MemberDim md2
	WHERE EXISTS (SELECT * FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd WHERE srcd.Member_ID = md2.MemberID AND srcd.Load_Key = @Load_Key))
INSERT INTO #member_mash
SELECT
	MedicareID,
	MemberID
FROM mem2
WHERE 1 = 1
	AND RN = 1--<<-- Take latest (arbitrary) record
	AND NOT EXISTS (SELECT * FROM #member_mash mm WHERE mem2.MemberID = mm.MemberID); --<<-- don't look for memberID already found

/******************************
end arbitrary MedicareID gather
*******************************/



WITH source_type AS ( --get distinct source types
	SELECT DISTINCT
		srsdt.SourceDesc
	   ,srsdt.Type
	FROM WIPRO.dbo.SUPP_RAPS_Source_Desc_Type srsdt
	WHERE EXISTS (SELECT * FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd WHERE srcd.Submit_Source = srsdt.SourceDesc AND srcd.Load_Key = @Load_Key)
),
monthly_member AS ( --get subset of member data for below and cast dates from INTs for DATE to DATE compare
	SELECT DISTINCT
		mmd.MemberID,
		mmd.MedicareID,
		mmd.HCFACode,
		BeginCoverageDateKey_Convert = TRY_CAST(TRY_CAST(mmd.BeginCoverageDateKey AS VARCHAR(8)) AS DATE),
		EndCoverageDateKey_Convert = TRY_CAST(TRY_CAST(mmd.EndCoverageDateKey AS VARCHAR(8)) AS DATE),
		mmd.PCPID
	FROM EDPS_Data.dbo.MonthlyMembershipDim mmd
	WHERE 1 = 1
		AND (mmd.HCFACode NOT LIKE '%S%' AND mmd.HCFACode != '-----')
		AND EXISTS (SELECT * FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd WHERE srcd.Member_ID = mmd.MemberID AND srcd.Load_Key = @Load_Key)
),
Elig AS (
	SELECT DISTINCT
		me.Memberid,
		me.ContractNumber,
		me.EligStartDate,
		me.EligEndDate
	FROM EDPS_Data.dbo.MemberEligibility me
	WHERE 1 = 1	
		AND me.Deleted = 0
		AND (	   me.ContractNumber LIKE 'h%' 
				AND me.ContractNumber NOT IN ('-----', '')
				AND me.ContractNumber IS NOT NULL)
		AND EXISTS (SELECT * FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd WHERE srcd.Member_ID = me.Memberid AND srcd.Load_Key = @Load_Key)
),
Supp_input AS ( --get input data and pivot codes that are not equal to dx codes (pretty much all of them)
	SELECT srcd1.CMCR_ID
		  ,srcd1.Member_ID
		  ,srcd1.Review_Status
		  ,srcd1.Market_Abbr
		  ,srcd1.Review_Type
		  ,srcd1.Event_Type_Desc
		  ,srcd1.Submit_Source
		  ,srcd1.Created_Date
		  ,srcd1.Last_Modified_Date
		  ,srcd1.Chart_Prov
		  ,srcd1.Start_Date
		  ,srcd1.End_Date
		  ,srcd1.DOS_Results_ID
		  ,srcd1.Document_Prov_ID
		  ,srcd1.CMS_Extract_Date
		  ,srcd1.DX_Code_Result_ID
		  ,srcd1.ICD_Code
		  ,srcd1.Chart_Prov_Spec
		  ,srcd1.Doc_Prov_Spec
		  ,srcd1.Appr_Rvw_Stat
		  ,srcd1.Appr_Spec
		  ,srcd1.Dos_err
		  ,srcd1.Dx_Err
		  ,srcd1.Dos_del
		  ,srcd1.Dx_del
		  ,srcd1.CMS_Extract_Elig
		  ,srcd1.Do_Not_Extract
		  ,srcd1.DX_Code_Version
		  ,srcd1.RA_Prov_Type
		  ,srcd1.Load_Date
		  ,srcd1.Load_Key
		  ,End_Date_Convert = TRY_CAST(srcd1.End_Date AS DATE)
		  ,Start_Date_Convert = TRY_CAST(srcd1.Start_Date AS DATE)		  
	FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd1
	WHERE 1 = 1
		AND srcd1.Load_Key = @Load_Key
)
INSERT INTO #Raw_Pull ( PCP_ID,Plan_no, HicNo, X_HICN, X_MBI, MemberID, From_Date, Thru_Date, Provider_Type, DxCode, icdversion, SourceSystem,
						SourceSystemNumber, SourceType, Patient_Control_No, DOS_YR, Data_Source, DocumentProvID, ChartProv,
						ChartChase_NPI, Process_Date, Last_Modified_Date, NPI_Source)
SELECT 
	PCP_ID = LTRIM(RTRIM(mm.PCPID)),
	Plan_no = COALESCE(E.ContractNumber, LTRIM(RTRIM(mm.HCFACode))),
	HicNo = COALESCE(memmash.MedicareID, RTRIM(LTRIM(mm.MedicareID))), --original field was mixed with HicNo and MBI.  Field was split below to X_HICN and XMBI
	X_HICN = NULL,
	X_MBI = NULL,
	MemberID = srcd.Member_ID,
	From_Date = srcd.Start_Date,
	Thru_Date = srcd.End_Date,
	Provider_Type = '20',
	ICD_Code = srcd.ICD_Code,
	icdversion =  CASE 
               			WHEN srcd.DX_Code_Version = 'ICD10' THEN 10
               			WHEN srcd.DX_Code_Version = 'ICD9' THEN 9
               			ELSE 0
				  END, --srcd.ICD_Code,--srcd.DX_Code_Version,
	SourceSystem = srcd.Submit_Source,
	SourceSystemNumber = srcd.CMCR_ID,
	SourceType = srsdt.Type,
	Patient_Control_No = ISNULL(srcd.Member_ID,'') + '-' + ISNULL(srcd.Submit_Source,'') + '-' + ISNULL(TRY_CAST(srcd.CMCR_ID AS VARCHAR),''),
	DOS_YR = TRY_CAST(YEAR(srcd.End_Date) AS VARCHAR(4)),
	[DATA_SOURCE] = 'SUPP_RAPS_CI_DATA',
	DocumentProvID = srcd.Document_Prov_ID,
	ChartProv = srcd.Chart_Prov,
	ChartChase_NPI = mm.PCPID, 
	Process_Date = @Process_Date,
	Last_Modified_Date = @Process_Date,
	NPI_Source = IIF(mm.PCPID IS NOT NULL,'PCP ID',NULL)
FROM Supp_input srcd
LEFT JOIN source_type srsdt
	ON srcd.Submit_Source = srsdt.SourceDesc
LEFT JOIN monthly_member mm
	ON mm.MemberID = srcd.Member_ID
	AND srcd.Start_Date_Convert >= mm.BeginCoverageDateKey_Convert
	AND srcd.End_Date_Convert <= mm.EndCoverageDateKey_Convert
LEFT JOIN Elig E
	ON srcd.Member_ID = e.Memberid
	AND srcd.Start_Date_Convert >= E.EligStartDate
	AND srcd.End_Date_Convert <= E.EligEndDate
LEFT JOIN #member_mash memmash
	ON srcd.Member_ID = memmash.MemberID;

	
/************************************************
Go back and update ChartChase_NPI and NPI_Source
based on join criteria populated below
*************************************************/
UPDATE RP
SET RP.ChartChase_NPI = COALESCE(ns.NPI, ns1.NPI, ns2.NPI),
	RP.NPI_Source = COALESCE(ns.NPI_Source, ns1.NPI_Source, ns2.NPI_Source)
FROM #Raw_Pull RP
LEFT JOIN #NPI_Source ns
	ON RP.DocumentProvID = ns.Provider_ID
LEFT JOIN #NPI_Source ns1
	ON RP.ChartProv = ns1.Provider_ID
LEFT JOIN #NPI_Source ns2
	ON RP.PCP_ID = ns2.Provider_ID;


/*******************
Update Tax ID
********************/

WITH Taxes AS ( --check IngenixProviderDim first
	SELECT DISTINCT
		ipd.NPI,
		ipd.TaxID
	FROM MDQOLib.dbo.IngenixProviderDim ipd
	WHERE 1 = 1
		AND EXISTS (SELECT * FROM #Raw_Pull rp WHERE rp.ChartChase_NPI = ipd.NPI)
		AND NULLIF(ipd.TaxID, 'UNKNOWN') IS NOT NULL
)
UPDATE RP
SET Tax_ID = T.TaxID
FROM #Raw_Pull RP
JOIN Taxes T 
	ON RP.ChartChase_NPI = T.NPI;

WITH Taxes AS (
	SELECT
		pd.NPID,
		Tax_ID = SUBSTRING(LTRIM(RTRIM(pd.FIDN)),1,9)
	FROM EDPS_Data.dbo.ProviderDim pd
	WHERE 1 = 1
		AND EXISTS (SELECT * FROM #Raw_Pull rp WHERE rp.ChartChase_NPI = pd.NPID)
		AND NULLIF(pd.FIDN,'') IS NOT NULL
		AND pd.FIDN NOT IN ('0000','9999','UNKNOWN')
		AND pd.ProviderStatus = 'Active'
	UNION
	SELECT
		epd.ProviderNPI,
		SUBSTRING(LTRIM(RTRIM(epd.FederalTaxID)),1,9)
	FROM EDPS_Data.dbo.EncounterProviderDim epd
	WHERE 1 = 1
		AND EXISTS (SELECT * FROM #Raw_Pull rp WHERE rp.ChartChase_NPI = epd.ProviderNPI)
		AND NULLIF(epd.FederalTaxID,'') IS NOT NULL
		AND epd.FederalTaxID NOT IN ('0000','9999','UNKNOWN')
)
UPDATE RP
SET Tax_ID = T.Tax_ID
FROM #Raw_Pull RP
JOIN Taxes T
	ON RP.ChartChase_NPI = T.NPID
WHERE RP.Tax_ID IS NULL; --update where not found (or null) in prior tax ID update

INSERT INTO WIPRO.dbo.Supplemental_INPUT 
	(	Plan_No, Hic_No, X_HICN, X_MBI, Member_ID, From_Date, Thru_Date, Provider_Type,
		Dx_Code, icd_version, Source_System, Source_System_Number, Source_Type, Patient_Control_No,
		DOS_YR, Linked_Claim_number, WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type, Data_Source,
		Document_Prov_ID, Chart_Prov, Chart_Chase_NPI, Status_Code, Status_desc, Process_Date, Last_Modified,
		PCP_ID, NPI_Source, Input_File_Name)
	SELECT
		rp.Plan_no
	   ,rp.HicNo
	   ,rp.X_HICN
	   ,rp.X_MBI
	   ,rp.MemberID
	   ,rp.From_Date
	   ,rp.Thru_Date
	   ,rp.Provider_Type
	   ,rp.DxCode
	   ,rp.icdversion
	   ,rp.SourceSystem
	   ,rp.SourceSystemNumber
	   ,rp.SourceType
	   ,rp.Patient_Control_No
	   ,rp.DOS_YR
	   ,rp.Linked_Claim_number
	   ,rp.WIPRO_CLAIM_NO
	   ,rp.CHS_CLM_EDPS
	   ,rp.CMS_ICN
	   ,rp.Supp_Type
	   ,rp.Data_Source
	   ,rp.DocumentProvID
	   ,rp.ChartProv
	   ,rp.ChartChase_NPI
	   ,rp.Status_Code
	   ,rp.Status_desc
	   ,rp.Process_Date
	   ,rp.Last_Modified_Date
	   ,rp.PCP_ID
	   ,rp.NPI_Source
	   ,Input_File_Name = 'OSCR'
	FROM #Raw_Pull rp
	EXCEPT
	SELECT
		Plan_No
	   ,Hic_No
	   ,X_HICN
	   ,X_MBI
	   ,Member_ID
	   ,From_Date
	   ,Thru_Date
	   ,Provider_Type
	   ,Dx_Code
	   ,icd_version
	   ,Source_System
	   ,Source_System_Number
	   ,Source_Type
	   ,Patient_Control_No
	   ,DOS_YR
	   ,Linked_Claim_number
	   ,WIPRO_CLAIM_NO
	   ,CHS_CLM_EDPS
	   ,CMS_ICN
	   ,Supp_Type
	   ,Data_Source
	   ,Document_Prov_ID
	   ,Chart_Prov
	   ,Chart_Chase_NPI
	   ,Status_Code
	   ,Status_desc
	   ,Process_Date
	   ,Last_Modified
	   ,PCP_ID
	   ,NPI_Source
	   ,Input_File_Name
	FROM dbo.Supplemental_INPUT si;

--drop #temp tables
IF OBJECT_ID('tempdb.dbo.#fast_prov') IS NOT NULL
	DROP TABLE #fast_prov;
IF OBJECT_ID('tempdb.dbo.#Raw_Pull') IS NOT NULL
	DROP TABLE #Raw_Pull;

SET NOCOUNT OFF;

/***************************************************************************************
----------------------------------------------------------------------------------------
****************************************************************************************/

