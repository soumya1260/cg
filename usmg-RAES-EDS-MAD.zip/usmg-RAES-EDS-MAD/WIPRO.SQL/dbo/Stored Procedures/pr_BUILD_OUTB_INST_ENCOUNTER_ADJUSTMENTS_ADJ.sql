﻿


CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_ENCOUNTER_ADJUSTMENTS_ADJ]
(@SOURCEDESC VARCHAR(50))--,@SOURCE_ENVIRONMENT VARCHAR(10) )
AS
/***************************************************************************************************
** CREATE DATE: 08/17
**
** AUTHOR: John Bartholomay
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT ENCOUNTER CLAIM LINE 
**              ADJUSTMENT SEGMENTS (CAST SEGMENTS) INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------

08/24/2917	   John Bartholomay    MOVE DEDUCTIBLE ADJUSTMENT FROM GRP131 TO GRP 122

*****************************************************************************************************/	
	--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM OUTB_PROF_HEADER_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT
		


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('pr_BUILD_OUTB_INST_ENCOUNTER_ADJUSTMENTS_SIMCONFIG'
				,'6'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
				
		--02/19/13 - COBAmt adjustment - only use COBAmt from claimlinenum 1		
				IF OBJECT_ID('TEMPDB..#TMP_EncounterClaimDim') <> 0
					DROP TABLE #TMP_EncounterClaimDim
					
				CREATE TABLE #TMP_EncounterClaimDim
	(
			Claimnum varchar(50)
			,ClaimLineNum varchar(4)
			,RequestedAmt money
			,PaidAmt money
			,COBAmt money
			,DeductibleAmt money
			,CoPayAmt money
			,CoInsuranceAmt money
			,CapAmt money
			,Quantity int
			,TotalLines int
			,SourceDesc varchar(60)
			---,SourceEnvironment varchar(10)
			)
	
	
			insert into #TMP_EncounterClaimDim
			select ClaimNum
					,ClaimLineNum
					,RequestedAmt
					,PaidAmt
					,0
					,DeductibleAmt
					,CoPayAmt
					,CoInsuranceAmt
					,0
					,Quantity
					,0
					,SourceDesc
					---,SourceEnvironment
			from EDPS_DATA.DBO.EncounterClaimDim  CD
			INNER JOIN OUTB_INST_HEADER H
			ON CD.CLAIMNUM = H.CLAIM_ID 
			AND CD.SOURCEDESC = H.SYSTEM_SOURCE
			group by ClaimNum
					,ClaimLineNum
					,RequestedAmt
					,PaidAmt
					,DeductibleAmt
					,CoPayAmt
					,CoInsuranceAmt
					,Quantity
					,SourceDesc
					--,SourceEnvironment
					
				IF OBJECT_ID('TEMPDB..#tmplines') <> 0
			DROP TABLE #tmplines
				
			select claimnum,COUNT(*) as 'TotalLines'
			into #tmplines
			from #TMP_EncounterClaimDim
			group by ClaimNum
					
			update #TMP_EncounterClaimDim
			set TotalLines = t1.TotalLines
			from #TMP_EncounterClaimDim te
				, #tmplines t1
			where  te.Claimnum = t1.claimnum
			
			update #TMP_EncounterClaimDim
			set COBAmt = ec.COBAmt/TotalLines
			from #TMP_EncounterClaimDim t1
				,EDPS_DATA.DBO.EncounterClaimDim ec
			where t1.Claimnum = ec.ClaimNum
			and		t1.ClaimLineNum = ec.ClaimLineNum
			and t1.SourceDesc = ec.sourcedesc
			
			
			--update #TMP_EncounterClaimDim.CapAmt
			select Claimnum,ClaimLineNum, CONVERT(CHAR, (CONVERT(MONEY, RequestedAmt)))/*(RequestedAmt - PaidAmt - COBAMT - DEDUCTIBLEAMT - COPAYAMT - COINSURANCEAMT)*/ AS 'CapAmt' --* --claimnum,claiminenum
			into #tmpcap
			from #TMP_EncounterClaimDim
			order by Claimnum,ClaimLineNum
			
			update #TMP_EncounterClaimDim
			set CapAmt = tc.CapAmt
			from #TMP_EncounterClaimDim te
				, #tmpcap tc
			where te.Claimnum = tc.claimnum
			and te.ClaimLineNum = tc.claimlinenum
						
						
              --TETDM-912 Remove logic OTH_PAYER1_PAID_AMT = ' ' due to WIPRO balancing rejections
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 =  'CO'
					,CLM_ADJ_REASON111 = '24' 
					,CLM_ADJ_AMT111 =  LTRIM(CD.CapAmt) --is the requested amount
					,CLM_ADJ_QTY111 = 1
					,OTH_PAYER1_PAID_AMT = '0.00'
				FROM OUTB_INST_DETAIL EC
				JOIN #TMP_EncounterClaimDim CD
				ON CLAIM_ID = CD.ClaimNum
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineNum)
				WHERE  SourceDesc =  @SOURCEDESC 
		
				
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 = ' '
					,CLM_ADJ_REASON111 = ' '
				WHERE LEN(CLM_ADJ_AMT111) = 0
				
				
				--RESET CLM_ADJ_GRP12 WHEN NOT USED
			
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = ' '
					,CLM_ADJ_REASON121 = ' '
				WHERE LEN(CLM_ADJ_AMT121) = 0
				

		
				--UNIT TEST FIX DUE TO ABOVE UPDATE, UPDATING RECORDS WITH ZERO COPAYAMT
				
					UPDATE OUTB_INST_DETAIL
					SET CLM_ADJ_GRP13 = ' '
							,CLM_ADJ_REASON131 = ' '
							,CLM_ADJ_AMT131 = ' '
					WHERE CLM_ADJ_AMT131 = '0.00'
					
		
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_PROF_HEADER_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_DETAIL)
									
		----HRP_CLAIM_FILE Update Run Controls
			
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_ENCOUNTER_ADJUSTMENTS_SIMCONFIG'
								AND END_DT IS NULL							
						
						

