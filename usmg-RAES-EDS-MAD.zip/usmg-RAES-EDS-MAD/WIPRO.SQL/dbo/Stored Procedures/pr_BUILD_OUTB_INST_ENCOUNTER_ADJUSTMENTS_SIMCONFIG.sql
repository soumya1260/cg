﻿ 
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_ENCOUNTER_ADJUSTMENTS_SIMCONFIG] 
(@SOURCEDESC VARCHAR(50))--,@SOURCE_ENVIRONMENT VARCHAR(10) ) 
AS 
/*************************************************************************************************** 
** CREATE DATE: 01/2013 
** 
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM 
** 
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT ENCOUNTER CLAIM LINE  
**              ADJUSTMENT SEGMENTS (CAST SEGMENTS) INFORMATION  
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE   
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES.  
** 
Modification History 
==================== 
Date			Who				Description 
----------------------------------------------------------------------------------------------------- 
 
11/09/12		LOYAL RICKS     MOVE DEDUCTIBLE ADJUSTMENT FROM GRP131 TO GRP 122 
11/19/12		LOYAL RICKS		REVISED ADJUSTMENTS ALIGNING SEGEMENTS WITH APPROPRIATE GROUP CODE 
11/27/12		LOYAL RICKS		REVISED USE OF TEMPDB, RENAME ##TMP TO ##TMPDEV TO ALLOW FOR MULTIPLE 
								PROCESSING IN EDPS & EDPS_PROD 
02/19/2013		loyal ricks		COBAmt adjustment - only use COBAmt from claimlinenum 1 
02/21/2013		LOYAL RICKS		Remove COBAmt from CapAmt logic until EDS team documents use of encounteclaimdim.CobAmt 
02/02/2016		Loyal Ricks		Add logic to prevent CO-24 CAS segment from being created when CapAmt = 0 
07/15/2016		Loyal Ricks		Remove input parameters @SOURCE_ENVIRONMENT 
								job will utilize exclusion build "DP" logic for selection of valid claims. All PROD 
								only claims will be selected. Functionality to select UAT claims removed, no longer  
								needed.		 
07/26/2016		Loyal Ricks		TETDM-912 Remove logic OTH_PAYER1_PAID_AMT = ' ' due to WIPRO balancing rejections 
08/16/2016		Loyal Ricks		Remove Sourcenvionmet reference. EDS stopped importing UAT and Prod data. sourceenv. no  
								longer a valid data element. 
*****************************************************************************************************/	 
	--DECLARE VARIABLES 
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM OUTB_PROF_HEADER_RESEND 
			DECLARE 
			 
			@TOTAL_RECORDS INT 
		 
 
 
--HRP_CLAIM_FILE Run controls 
INSERT INTO EXT_SYS_RUNLOG 
		(PROC_NAME 
		,STEP 
		,START_DT 
		,END_DT 
		,RUN_MINUTES 
		,TOTAL_RECORDS 
		,ENTRYDT 
		) 
		VALUES('pr_BUILD_OUTB_INST_ENCOUNTER_ADJUSTMENTS_SIMCONFIG' 
				,'6' 
				,GETDATE() 
				,NULL 
				,NULL 
				,0 
				,GETDATE() 
				) 
				 
		--02/19/13 - COBAmt adjustment - only use COBAmt from claimlinenum 1		 
				IF OBJECT_ID('TEMPDB..#TMP_EncounterClaimDim') <> 0 
					DROP TABLE #TMP_EncounterClaimDim 
					 
				CREATE TABLE #TMP_EncounterClaimDim 
	( 
			Claimnum varchar(50) 
			,ClaimLineNum varchar(4) 
			,RequestedAmt money 
			,PaidAmt money 
			,COBAmt money 
			,DeductibleAmt money 
			,CoPayAmt money 
			,CoInsuranceAmt money 
			,CapAmt money 
			,Quantity int 
			,TotalLines int 
			,SourceDesc varchar(60) 
			---,SourceEnvironment varchar(10) 
			) 
	 
	 
			insert into #TMP_EncounterClaimDim 
			select ClaimNum 
					,ClaimLineNum 
					,RequestedAmt 
					,PaidAmt 
					,0 
					,DeductibleAmt 
					,CoPayAmt 
					,CoInsuranceAmt 
					,0 
					,Quantity 
					,0 
					,SourceDesc 
					---,SourceEnvironment 
			from EDPS_DATA.DBO.EncounterClaimDim  CD 
			INNER JOIN OUTB_INST_HEADER H 
			ON CD.CLAIMNUM = H.CLAIM_ID  
			AND CD.SOURCEDESC = H.SYSTEM_SOURCE 
			group by ClaimNum 
					,ClaimLineNum 
					,RequestedAmt 
					,PaidAmt 
					,DeductibleAmt 
					,CoPayAmt 
					,CoInsuranceAmt 
					,Quantity 
					,SourceDesc 
					--,SourceEnvironment 
					 
				IF OBJECT_ID('TEMPDB..#tmplines') <> 0 
			DROP TABLE #tmplines 
				 
			select claimnum,COUNT(*) as 'TotalLines' 
			into #tmplines 
			from #TMP_EncounterClaimDim 
			group by ClaimNum 
					 
			update #TMP_EncounterClaimDim 
			set TotalLines = t1.TotalLines 
			from #TMP_EncounterClaimDim te 
				, #tmplines t1 
			where  te.Claimnum = t1.claimnum 
			 
			update #TMP_EncounterClaimDim 
			set COBAmt = ec.COBAmt/TotalLines 
			from #TMP_EncounterClaimDim t1 
				,EDPS_DATA.DBO.EncounterClaimDim ec 
			where t1.Claimnum = ec.ClaimNum 
			and		t1.ClaimLineNum = ec.ClaimLineNum 
			and t1.SourceDesc = ec.sourcedesc 
			---and t1.SourceEnvironment = ec.SourceEnvironment 
			--and ec.ClaimLineNum = 1 
			--and t1.ClaimLineNum = 1 
			 
			--update #TMP_EncounterClaimDim.CapAmt 
			--2/21/13 Remove COBAmt from CapAmt logic until EDS team documents use of encounteclaimdim.CobAmt 
			select Claimnum,ClaimLineNum, CONVERT(CHAR, (CONVERT(MONEY, RequestedAmt)))/*(RequestedAmt - PaidAmt - COBAMT - DEDUCTIBLEAMT - COPAYAMT - COINSURANCEAMT)*/ AS 'CapAmt' --* --claimnum,claiminenum 
			into #tmpcap 
			from #TMP_EncounterClaimDim 
			order by Claimnum,ClaimLineNum 
			 
			update #TMP_EncounterClaimDim 
			set CapAmt = tc.CapAmt 
			from #TMP_EncounterClaimDim te 
				, #tmpcap tc 
			where te.Claimnum = tc.claimnum 
			and te.ClaimLineNum = tc.claimlinenum 
						 
						 
						 
			--UPDATE CLM_ADJ_GRP5 INFORMATION - PROVIDER CAPITATION 
				--CALCULATE CAPITATED AMOUNT 
				--USE ALSO TO DETERMINE WHETHER CLM_ADJ_GRP1 'CO' SHOULD BE POPULATED 
			/*	SELECT ClaimNum,ClaimLineNum, QUANTITY,SUM(RequestedAmt - PaidAmt - COBAMT - DEDUCTIBLEAMT - COPAYAMT - COINSURANCEAMT) as 'CAP_AMT' 
				INTO ##TMPDEV_CLMCAP 
				FROM #TMP_EncounterClaimDim  
				WHERE SourceDesc = @SOURCEDESC  
					AND SourceEnvironment = @SOURCE_ENVIRONMENT 
				GROUP BY ClaimNum,ClaimLineNum, QUANTITY 
				*/ 
				--build EncounterClaimAdjustment 
				--COBAMT ADJUSTMENT - ALL LINES HAVE THE TOTAL COBAMT - ONLY USE CLAIMLINENO = 1 
				 
 
	--UPDATE CLM_ADJ_GRP1 INFORMATION - CONTRACT ADJUSTMENT 
	--REVISED LOGIC 7/5/12 BASED ON HRP CALL. CO AMOUNT SHOULD EQUAL CONTRACTED WRITE OFF AMOUNT 
	--POTENTIAL FIX LOGIC REMOVED DUE TO EMAIL FROM K.DEHNKE VALIDATING THE USE OF MAXFEEAMT 
	--POTENTIAL FIX LOGIC WAS --LTRIM(RequestedAmt - MAXFEEAMT - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt) 
	--ADJUSTED BACK TO ORIGINAL LOGIC FROM 6/15 
	--7/19 ADD CHECK TO ONLY APPLY UPDATE WHEN CLAIM IS NOT CAPITATED 
	--02-20-213 EDIT OUT ALL LOOPS RELATED TO COBAMT UNTIL TRANSLATION FOR INBOUND COBAMT FOR EVERY CLAIM LINE IS IMPLEMENTED 
	--TETDM-912 Remove logic OTH_PAYER1_PAID_AMT = ' ' due to WIPRO balancing rejections 
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP111 = 'CR'-- 'CO' 
					,CLM_ADJ_REASON111 = '223'--'24' --24 = CAP,'45' CONTRACTED AMOUNT 
					,CLM_ADJ_AMT111 = LTRIM(CapAmt) -- LTRIM(CD.RequestedAmt - CD.PaidAmt - CD.COBAmt - CD.CoInsuranceAmt - CD.DeductibleAmt - CD.CoPayAmt) * -1 
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE. 
					,CLM_ADJ_QTY111 = QUANTITY 
					,OTH_PAYER1_PAID_AMT = '0.00' 
				FROM OUTB_INST_DETAIL EC 
				JOIN #TMP_EncounterClaimDim CD 
				ON CLAIM_ID = CD.ClaimNum 
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineNum) 
				WHERE  SourceDesc =  @SOURCEDESC  
					--AND SourceEnvironment = @SOURCE_ENVIRONMENT 
					and capamt <> 0 
					--AND (CD.RequestedAmt - CD.PaidAmt - CD.COBAmt - CD.CoInsuranceAmt - CD.DeductibleAmt - CD.CoPayAmt) > 0 
						--AND CLAIM_ID NOT IN (SELECT ClaimNum FROM ##TMPDEV_CLMCAP) 
				 
				---OTHER ADJUSTMENTS - WHEN TOTAL PAID AMOUNTS EXCEED TOTAL CHARGES 
			/*				BEGIN TRANSACTION  
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP12 = 'OA' 
					,CLM_ADJ_REASON121 = '94' 
					,CLM_ADJ_AMT121 = LTRIM(RequestedAmt - (PaidAmt + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)) 
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE. 
					,CLM_ADJ_QTY121 = QUANTITY 
				FROM OUTB_INST_DETAIL EC 
				JOIN #TMP_EncounterClaimDim CD 
				ON CLAIM_ID = CD.ClaimNum 
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineNum) 
				WHERE SourceDesc = @SOURCEDESC  
					AND SourceEnvironment = @SOURCE_ENVIRONMENT 
					AND RequestedAmt < (PaidAmt + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt) 
				IF @@ERROR <> 0 
					BEGIN  
							ROLLBACK  
					END 
				COMMIT 
				*/ 
				 
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP111 = ' ' 
					,CLM_ADJ_REASON111 = ' ' 
				WHERE LEN(CLM_ADJ_AMT111) = 0 
				 
				 
				--RESET CLM_ADJ_GRP12 WHEN NOT USED 
			 
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP12 = ' ' 
					,CLM_ADJ_REASON121 = ' ' 
				WHERE LEN(CLM_ADJ_AMT121) = 0 
				 
 
					--UPDATE CLM_ADJ_GRP2 INFORMATION - COPAY ADJUSTMENT 
			/*	BEGIN TRANSACTION  
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP13 = 'PR' 
					,CLM_ADJ_REASON131 = '3' 
					,CLM_ADJ_AMT131 = LTRIM(COPAYAMT) 
					,CLM_ADJ_QTY131 = QUANTITY 
				FROM OUTB_INST_DETAIL EC 
					,#TMP_EncounterClaimDim CD 
				WHERE SourceDesc = @SOURCEDESC  
					AND SourceEnvironment = @SOURCE_ENVIRONMENT 
					AND EC.CLAIM_ID = CD.ClaimNum 
					AND EC.CLAIM_LINE_NO = CD.ClaimLineNum 
					AND CD.COPAYAMT <> 0.00	 
								IF @@ERROR <> 0 
					BEGIN  
							ROLLBACK  
					END 
				COMMIT*/ 
				--UNIT TEST FIX DUE TO ABOVE UPDATE, UPDATING RECORDS WITH ZERO COPAYAMT 
				 
					UPDATE OUTB_INST_DETAIL 
					SET CLM_ADJ_GRP13 = ' ' 
							,CLM_ADJ_REASON131 = ' ' 
							,CLM_ADJ_AMT131 = ' ' 
					WHERE CLM_ADJ_AMT131 = '0.00' 
					 
					--UPDATE CLM_ADJ_GRP3 INFORMATION - DEDUCTIBLE ADJUSTMENT 
					--11/09/12 - MOVE DEDUCTIBLE ADJUSTMENT FROM GRP131 TO GRP 122 
			/*	BEGIN TRANSACTION  
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP13 = 'PR' 
					,CLM_ADJ_REASON132 = '1' 
					,CLM_ADJ_AMT132 = LTRIM(CD.DEDUCTIBLEAMT) 
					,CLM_ADJ_QTY132 = QUANTITY 
				FROM OUTB_INST_DETAIL EC 
					,#TMP_EncounterClaimDim CD 
				WHERE SourceDesc = @SOURCEDESC  
					AND SourceEnvironment = @SOURCE_ENVIRONMENT 
					AND EC.CLAIM_ID = CD.ClaimNum 
					AND EC.CLAIM_LINE_NO = CD.ClaimLineNum 
					AND CD.DEDUCTIBLEAMT <> 0.00 
				IF @@ERROR <> 0 
					BEGIN  
							ROLLBACK  
					END 
				COMMIT 
						--UPDATE CLM_ADJ_GRP4 INFORMATION - COINSURANCE ADJUSTMENT 
				BEGIN TRANSACTION  
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP13 = 'PR' 
					,CLM_ADJ_REASON133 = '2' 
					,CLM_ADJ_AMT133 = LTRIM(CD.COINSURANCEAMT) 
					,CLM_ADJ_QTY133 = QUANTITY 
				FROM OUTB_INST_DETAIL EC 
					,#TMP_EncounterClaimDim CD 
				WHERE SourceDesc = @SOURCEDESC  
					AND SourceEnvironment = @SOURCE_ENVIRONMENT 
					AND EC.CLAIM_ID = CD.ClaimNum 
					AND EC.CLAIM_LINE_NO = CD.ClaimLineNum 
					AND CD.COINSURANCEAMT <> 0.00 
				IF @@ERROR <> 0 
					BEGIN  
							ROLLBACK  
					END 
				COMMIT 
			*/	--UPDATE CLM_ADJ_GRP5 INFORMATION - PROVIDER CAPITATION 
-----------------------------------*********************01/10/13 NEED TO FIX ISSUE WITH BLOCK LRICKS 
			/*	BEGIN TRANSACTION  
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP15 = 'CR' 
					,CLM_ADJ_REASON151 = '223' 
					,CLM_ADJ_AMT151 = LTRIM(CAPAMT) 
					,CLM_ADJ_QTY151 = QUANTITY 
				FROM OUTB_INST_DETAIL EC 
					,#TMP_EncounterClaimDim CD 
				WHERE EC.CLAIM_ID = CD.ClaimNum 
					AND EC.CLAIM_LINE_NO = CD.ClaimLineNum 
					AND EC.CONTRACT_TYPE = '05' 
					AND TOTAL_CHRG_AMT <> OTH_PAYER1_PAID_AMT 
				IF @@ERROR <> 0 
					BEGIN  
							ROLLBACK  
					END 
				COMMIT	*/ 
				--RESET OTH_PAYER1_PAID_AMT & OTH_PAYER1_PAID_QTY WHEN OTH_PAYER1_PAID_AMT = 0 
				--remove code, 7/18 ONSITE HRP SESSION FINDINGS THERE MUST ALWAYS BE AN AMOUNT 
				--IN OTH_PAYER11_PAID_AMT DEFAULT = 0.00 
				 
				----REMOVE For Initial development of I claim adjustments since P claim adjust code being used as base 
				--UPDATE OUTB_INST_DETAIL 
				--SET OTH_PAYER1_PAID_AMT = '0.00' 
				--	--,OTH_PAYER1_PAID_QTY = ' ' 
				--WHERE (OTH_PAYER1_PAID_AMT = '0.00' OR LEN(OTH_PAYER1_PAID_AMT) = 0 ) 
				--	AND CONTRACT_CODE = '05' 
					 
				---07/09/12 UPDATE CLAIM ADJUSTMENT GROUP FOR 'PR' ADJUSTMENT 
				---ADJUSTMENT GROUPS GRP12 - GRP14 ARE 'PR' AND SHOULD ONLY HAVE 1 GROUP CODE SUBMITTED PER SEGMENT 
				--SET CLM_ADJ_GRP13 WHEN GRP12 IS NOT POPULATED 
			/*	BEGIN TRANSACTION  
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP13 = 'PR' 
				FROM OUTB_INST_DETAIL EC 
					,CLAIMDETAILDIM CD 
				WHERE EC.CLAIM_ID = CD.CLAIMID 
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID 
					AND CD.DEDUCTIBLEAMT <> 0.00 
					AND CLM_ADJ_GRP12 <> 'PR' 
					IF @@ERROR <> 0 
					BEGIN  
							ROLLBACK  
					END 
				COMMIT	 
				--SET CLM_ADJ_GRP14 WHEN GRP12 & GRP13 IS NOT POPULATED 
				BEGIN TRANSACTION  
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP14 = 'PR' 
				FROM OUTB_INST_DETAIL EC 
					,CLAIMDETAILDIM CD 
				WHERE EC.CLAIM_ID = CD.CLAIMID 
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID 
					AND CD.COINSURANCEAMT <> 0.00 
					AND CLM_ADJ_GRP12 <> 'PR' 
					AND CLM_ADJ_GRP13 <> 'PR' 
					IF @@ERROR <> 0 
					BEGIN  
							ROLLBACK  
					END 
				COMMIT	*/ 
				--MHC PENALTY PAYMENT UPDATES 
				/* 
				BEGIN TRANSACTION  
				UPDATE OUTB_INST_DETAIL 
				SET CLM_ADJ_GRP12 = 'OA' 
						,CLM_ADJ_REASON122 = '225' 
					,CLM_ADJ_AMT122 = OTH_PAYER1_PAID_AMT 
					,OTH_PAYER1_PROC_CD = ' ' 
					,SERV_ID_QUAL = ' ' 
					,PROC_CD = ' ' 
				FROM OUTB_INST_DETAIL 
				WHERE PROC_CD = '0L6' 
				COMMIT*/ 
				--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_PROF_HEADER_RESEND 
							  
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_DETAIL) 
									 
		----HRP_CLAIM_FILE Update Run Controls 
			 
						UPDATE EXT_SYS_RUNLOG 
						SET END_DT = GETDATE()	 
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()) 
							,TOTAL_RECORDS = @TOTAL_RECORDS 
							,ENTRYDT = GETDATE() 
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_ENCOUNTER_ADJUSTMENTS_SIMCONFIG' 
								AND END_DT IS NULL							 
						 
						 

