﻿CREATE PROCEDURE [dbo].[EDS_Claims_Processing_Insert]
AS
/*
Creation date: 6/11/2024
This procedure will insert records to the EDS_Claims_Processing.  Items in the table will not be reinserted if they exist.
Duplicates cannot be inserted into EDS_Claims_Processing table due to index restriction (duplicates are silently dropped)

NOTES:
	RETM-673	ASU	
		Initial Creation
		


*/

INSERT INTO dbo.EDS_Claims_Processing WITH (TABLOCK)
(CLAIMID, CLAIM_TYPE, LOB, LOB_CODE, HCFACODE, PBPCODE, SOURCEDATAKEY, SOURCEDESC, REGULATORYMARKET,
ISDENIED, ISDME, ISDMR, ISADJUSTMENT, ISMEDICAID, ISMEDICARE, ISRESUB, [ISEncounter], ENCOUNTERSOURCENAME, ISRETRACTION, LOADDATE)
SELECT DISTINCT
	CLAIMID = smmcha.CLM_ID,
	CLAIM_TYPE = smmcha.CLM_TY,
	LOB = CASE smmcha.PRODT_TY
          	WHEN 'Medicare' THEN 'MAO'
			WHEN 'Medicaid' THEN 'Caid'
          	ELSE NULL
          END,
	LOB_CODE = NULL, --??--
	HCFACODE = IIF(LEN(smmcha.CNTRCT_NUM) <= 5,smmcha.CNTRCT_NUM,NULL),
	PBPCODE = IIF(LEN(smmcha.PBP_NUM) <= 3,smmcha.PBP_NUM,NULL),
	SOURCEDATAKEY = smmcha.SRC_DATA_KEY,
	SOURCEDESC = smmcha.SRC_DATA_DESC,
	REGULATORYMARKET = smmcha.REGLTY_MRKT,
	ISDENIED = CASE WHEN smmcha.CLM_STAT_TY_DESC = 'DENIED' THEN 1 ELSE 0 END, --??? 
	ISDME = CASE 
            	WHEN smmcha.CLM_TY = 'INSTITUTIONAL' THEN 0
            	ELSE IIF(smmcha.PROV_TAXNMY_CD IN ('332B00000X','332BC3200X','332BD1200X','332BN1400X','332BX2000X'),1,0) --DME taxonomy codes
            END,
	ISDMR = NULL, --???--medicaid only
	ISADJUSTMENT = IIF(smmcha.FREQ_CD IN ('7','8'),1,0),
	ISMEDICAID = 0, --IIF(smmcha.PRODT_TY = 'Medicaid',1,0),
	ISMEDICARE = IIF(smmcha.PRODT_TY = 'Medicare',1,0),
	ISRESUB = 0,
	ISEncounter = IIF(smmcha.IS_ENCNTR_IND = 'Y' AND smmcha.SRC_DATA_KEY IN (144,142),1,0),
	ENCOUNTERSOURCENAME = smmcha.ENCNTR_SRC_VENDR_NM,
	ISRetraction = 0,
	LOADDATE = GETDATE()
FROM OSS.staging.SDO_MDQO_MED_CLM_HDR_ADJUD smmcha
LEFT JOIN EDIFECS.dbo.OSS_CLAIM_EXCLUSION_HIST excl ON smmcha.CLM_ID = excl.CLAIM_ID AND smmcha.SRC_DATA_KEY = excl.SOURCEDATAKEY
LEFT JOIN WIPRO.dbo.RAES_OSS_COLLECTIONS_CONFIG rocc ON LEFT(smmcha.[HLTHPLN_IK],5) = rocc.HPLAN 
														AND smmcha.SRC_DATA_KEY = rocc.SRC_DATA_KEY
														AND smmcha.SVC_START_DT BETWEEN rocc.START_DT AND rocc.TERM_DT
														AND rocc.ACTIVE = '1'
WHERE 1 = 1
     --AND smmcha.CLM_TY IN ('PROFESSIONAL','INSTITUTIONAL')
	AND excl.CLAIM_ID IS NULL
	AND rocc.ACTIVE IS NOT NULL
	AND smmcha.[FNLZ_CLM_IND] = 'Y'
	AND NOT EXISTS (	SELECT
							*
						FROM dbo.EDS_Claims_Processing t
						WHERE 1 = 1
							AND t.CLAIMID = smmcha.CLM_ID
							AND t.CLAIM_TYPE = smmcha.CLM_TY
							AND t.SOURCEDATAKEY = smmcha.SRC_DATA_KEY);

/* MASTER RECON TABLE INSERT OF SUBMITTABLE CLAIMS */ 

INSERT INTO WIPRO.dbo.EDS_Claims_Master_Recon WITH (TABLOCK)
(
  [claimid]
 ,[sourcedatakey]
 ,[Sourcedesc]
 ,[RefreshDate]
 ,[memberid]
 ,[DOS_Year]
 ,[BeginServiceDate]
 ,[LOB]
 ,[Claim_Status]
 ,[ClaimType]
 ,[StatusDate]
 ,[Gender]
 ,[EndServiceDate]
 ,[RenderingProvNPI]
 ,[BillingProvNPI]
  )
SELECT  
  CLM_ID
 ,CLMHDR.[SRC_DATA_KEY]
 ,CLMHDR.ENCNTR_SRC_VENDR_NM
 ,GETDATE()
 ,CLMHDR.[MBR_ID]
 ,CAST(YEAR([SVC_START_DT]) AS VARCHAR(4))
 ,CAST(CONVERT(VARCHAR, [SVC_START_DT], 112 ) AS INT)
 ,LOB = CASE PRODT_TY
          	WHEN 'Medicare' THEN 'MAO'
			WHEN 'Medicaid' THEN 'Caid'
          	ELSE NULL
          END
 ,NULL
 ,CASE WHEN CLM_TY = 'PROFESSIONAL' THEN 'P'
       WHEN CLM_TY = 'INSTITUTIONAL' THEN 'I'
	   WHEN CLM_TY = 'DENTAL' THEN 'D'
  ELSE 
	   'NOT PROVIDED'
  END 
 ,GETDATE()
 ,GENDR
 ,CAST(CONVERT(VARCHAR,[SVC_END_DT],112) AS INT)
 ,CLMHDR.[PROV_BILL_ENTTY_NPI]
 ,CLMHDR.[RNDRG_PROV_NPI]
  FROM OSS.STAGING.[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR
  INNER JOIN WIPRO.dbo.EDS_Claims_Processing ECP ON CLMHDR.CLM_ID = ECP.CLAIMID AND CLMHDR.SRC_DATA_KEY = ECP.SOURCEDATAKEY
  LEFT JOIN OSS.staging.[CDO_MBR_DEMG] MEM ON CLMHDR.MBR_ID = MEM.MBR_ID AND CLMHDR.SRC_DATA_KEY = MEM.SRC_DATA_KEY
  WHERE 1 = 1
   AND NOT EXISTS (SELECT * 
				 FROM WIPRO.[dbo].[EDS_Claims_Master_Recon] cmr
				      WHERE 1 = 1
					  AND cmr.ClaimID = CLMHDR.CLM_ID 
					  AND cmr.SourceDataKey = CLMHDR.SRC_DATA_KEY)
  UNION 
  SELECT  
      CLM_ID
	 ,CLMHDR.[SRC_DATA_KEY]
	 ,CLMHDR.ENCNTR_SRC_VENDR_NM
	 ,GETDATE()
	 ,CLMHDR.[MBR_ID]
	 ,CAST(YEAR([SVC_START_DT]) AS VARCHAR(4))
	 ,CAST(CONVERT(VARCHAR, [SVC_START_DT], 112 ) AS INT)
	 ,LOB = CASE PRODT_TY
          		WHEN 'Medicare' THEN 'MAO'
				WHEN 'Medicaid' THEN 'Caid'
          		ELSE NULL
			  END
	 ,'EXCLUSION'
	 ,CASE WHEN CLM_TY = 'PROFESSIONAL' THEN 'P'
		   WHEN CLM_TY = 'INSTITUTIONAL' THEN 'I'
		   WHEN CLM_TY = 'DENTAL' THEN 'D'
	  ELSE 
		   'NOT PROVIDED'
	  END 
	 ,GETDATE()
	 ,GENDR
	 ,CAST(CONVERT(VARCHAR,[SVC_END_DT],112) AS INT)
	 ,CLMHDR.[PROV_BILL_ENTTY_NPI]
	 ,CLMHDR.[RNDRG_PROV_NPI]
  FROM EDIFECS.[dbo].[OSS_CLAIM_EXCLUSION_HIST] EXCL
  INNER JOIN OSS.STAGING.[SDO_MDQO_MED_CLM_HDR_ADJUD] CLMHDR ON EXCL.claim_id = CLMHDR.CLM_ID AND EXCL.SOURCEDATAKEY = CLMHDR.SRC_DATA_KEY
  LEFT JOIN OSS.staging.[CDO_MBR_DEMG] MEM ON CLMHDR.MBR_ID = MEM.MBR_ID AND CLMHDR.SRC_DATA_KEY = MEM.SRC_DATA_KEY
    WHERE 1 = 1
    AND NOT EXISTS (SELECT * 
				      FROM WIPRO.[dbo].[EDS_Claims_Master_Recon] cmr
				      WHERE 1 = 1
					  AND cmr.ClaimID = CLMHDR.CLM_ID 
					  AND cmr.SourceDataKey = CLMHDR.SRC_DATA_KEY);  
					  
				     
   


