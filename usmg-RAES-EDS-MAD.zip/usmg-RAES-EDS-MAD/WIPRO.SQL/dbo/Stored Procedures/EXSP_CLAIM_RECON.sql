﻿


CREATE PROCEDURE [dbo].[EXSP_CLAIM_RECON]
AS
/***************************************************************************************************
** CREATE DATE: 07/2012
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL POPULATE EXT_HRP_CLAIM_RECON  & EXT_EDPS_CLAIM_STATUS TABLE WITH CLAIM INVENTORY
**			    DATA FROM THE MONTHLY BIDW EXTRACT. THIS DATA WILL BE USED TO ASSIST MDQO WITH 
**				AUDITING AND TRACKING CLAIM INVENTORY SENT TO HRP FOR EDS CMS SUBMISSIONS.
**				THIS PROCEDURE WILL RUN DIRECTLY AFTER EACH BIDW EXTRACT. THE EXT_HRP_CLAIM_RECON
**				TABLE IS A HISTORICAL TABLE. DATA WILL ALWAYS GET APPENDED BY CLAIM DOS MONTH (YYYYMM)
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------

1/02/13		LOYAL RICKS     HPLAN ADDED TO EXT_EDPS_CLAIM_STATUS. ADDED LOGIC FOR POPULATING THIS VALUE
1/25/13		Dwight Staggs	PAPER_IND was added to the table EXT_EDPS_CLAIM_STATUS
2/18/13		Loyal Ricks		Add Sourcedesc to "---APPEND INVENTORY INTO EXT_EDPS_CLAIM_STATUS"
2/18/13		Loyal Ricks		Add datasource 4 - Encounter to inventory updates
10/1/13		Dwight Staggs	Had to qualify occurances of BeginServiceDate as it is now in both 
							ClaimDim and ClaimDetailDim
12/31/31	Loyal Ricks		Add EXT_EDPS_CLAIM_STATUS.HRP_CLAIM_ID
02/20/14	Loyal Ricks		Add revision for EXT_EDPS_CLAIM_STATUS table definition revisions
07/03/14	Loyal Ricks		Add deletions of EXT_EDPS_CLAIM_STATUS table by: sourcedatakey, first char 
							of HPLAN and producttype. 
							Add attempt to identify HPLAN
09/08/14	Loyal Ricks		Add Archive table to capture deleted rows in the event an audit of deleted 
							records is required after the refresh. August 2014 required an audit of deleted
							rows to confirm that all deleted rows were non Medicare claims
09/19/14	Loyal Ricks	    comment out Extracted Data total section to increase run time performance. These
							totals currently being captured by SSIS package audit and are not needed.
10/07/14	Loyal Ricks		EDS-434 Add Encounter sdk-4 back to production inventory

----------------------------------------------------------------------------------------------------
01/05/15	Loyal Ricks		Remove/comment out all transaction statements to improve performance based on 
							current SQL server configuration. 
01/05/15	Loyal Ricks		WIPRO Revisions
09/25/16	Loyal Ricks		TETDM-1122 - Remove sourcedatakey 40 from populating in EDS iventory table
04/06/19	Scott Waller	TETDM-1995 add indexes to #temp tables to improve performance
							TETDM-1995 replace #temp tables with permanent tables

*****************************************************************************************************/	
		
		

			
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RECON WHERE ENTRYDT = @ENTRYDT
							DECLARE
										
								@TOTAL_RECORDS INT,
								@ENTRYDT DATETIME
								
							--ASSIGN @ENTRYDT TO EXECUTION DATETIME

								SET @ENTRYDT = (GETDATE())
							--EXSP_HRP_CLAIM_RECON RUN CONTROLS
							INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('EXSP_WIPRO_CLAIM_RECON'
											,'BIDW EXTRACT'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE() )

-- TETDM-1995
			TRUNCATE TABLE	WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_POS
			TRUNCATE TABLE	WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_CLMSTAT
			TRUNCATE TABLE	WIPRO_Staging.dbo.CLAIM_STATUS_HRPDEV_STATUS
			TRUNCATE TABLE	WIPRO_Staging.dbo.CLAIM_STATUS_TMP_PAPER
			TRUNCATE TABLE	WIPRO_Staging.dbo.CLAIM_STATUS_TMP_ELIG
-- end 
							IF OBJECT_ID('TEMPDB..#tmplob') <> 0
									DROP TABLE #tmplob

								CREATE TABLE #tmplob
								(
									LOBCode			VARCHAR(15)
								)

							INSERT INTO 
									#tmplob
								( 
									LOBCode
								)
								SELECT 
									LOBCode
								FROM
									MDQOLib.dbo.LineofBusinessDim
								WHERE ProductType in ('Medicare','Care-Caid')
								and Active = 1
								ORDER BY LOBCode

							--BEGIN TRANSACTION 
							--INSERT INTO EXT_HRP_CLAIM_RECON
							--SELECT CD.SOURCEDATAKEY,FORMTYPECODE,SUBSTRING(CONVERT(CHAR,CD.BEGINSERVICEDATEKEY),1,6),COUNT(DISTINCT CD.CLAIMID),@ENTRYDT
							--FROM CLAIMDIM C
							--	,CLAIMDETAILDIM CD
							--WHERE C.CLAIMID = CD.CLAIMID
							--	--AND BEGINSERVICEDATEKEY >= '20120101'
							--GROUP BY CD.SOURCEDATAKEY,FORMTYPECODE,SUBSTRING(CONVERT(CHAR,CD.BEGINSERVICEDATEKEY),1,6)
							--ORDER BY CD.SOURCEDATAKEY,FORMTYPECODE,SUBSTRING(CONVERT(CHAR,CD.BEGINSERVICEDATEKEY),1,6)
								--IF @@ERROR <> 0
								--		BEGIN
								--			ROLLBACK 
								--		END
								--COMMIT

-- TETDM-1995
/*								IF OBJECT_ID('TEMPDB..#TMPDEV_POS') <> 0
										DROP TABLE #TMPDEV_POS

								CREATE TABLE #TMPDEV_POS
								(CLAIMID VARCHAR(20),
								SOURCEDATAKEY INT,
								SERVICEPLACECODE VARCHAR(4) )
*/
				ALTER INDEX ALL ON WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_POS
				DISABLE;

							---APPEND BIDW INVENTORY INTO EXT_EDPS_CLAIM_STATUS
							--
							-- Add outboundvhclaimid due to alter table
							--BEGIN TRANSACTION 
							INSERT INTO dbo.EXT_EDPS_CLAIM_STATUS
							        ( CLAIMID ,
							          FormTypeCode ,
							          typecode ,
							          DeniedFlag ,
							          SOURCEDATAKEY ,
							          CLAIM_TYPE ,
							          CLM_IND ,
							          CLMSTAT_STATUS ,
							          LAST_UPD_DATE ,
							          DOS_MONTH ,
							          ORIG_BIDW_EXTRACT_DT ,
							          LAST_BIDW_EXTRACT_DT ,
							          CMS_ICN ,
							          FILEID ,
							          LOBCODE ,
							          PRODUCTTYPE ,
							          SERVICEPLACECODE ,
							          HPLAN ,
							          PAPER_IND,
							          SOURCEDESC,
							          HRP_CLAIM_ID,
							          OUTBOUNDVHCLAIMID
							          
							        )
							select distinct C.claimid	
									,C.formtypecode
								,C.typecode
								,C.deniedflag
								,C.SourceDataKey
								,CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE ISNULL(C.FORMTYPECODE,' ') END--CLAIM_TYPE
								,NULL--CLM_IND
								,NULL--CLMSTAT_STATUS
								,GETDATE()
								,SUBSTRING(convert(char, BEGINSERVICEDATEKEY),1,6) --DOS_MONTH
								,@ENTRYDT --USE BATCH_EXTRACT_DT
								,@ENTRYDT	--USE BATCH_EXTRACT_DT
								,NULL--CMS_ICN
								,NULL--FILEID
								,C.LOBCODE
								,NULL --PRODUCTTYPE
								,NULL --SERVICEPLACECODE
								,NULL --HPLAN	
								,NULL --PAPER_IND
								,' '  --sourcedesc
								,' '  --HRP CLAIM ID
								,' '--OUTBOUNDVHCLAIMID
							from EDPS_DATA.DBO.claimdim C
							LEFT OUTER JOIN EXT_EDPS_CLAIM_STATUS EE
							ON C.SOURCEDATAKEY = EE.SOURCEDATAKEY
							AND C.CLAIMID = EE.CLAIMID 
							inner join #tmplob t
							on c.lobcode = t.lobcode
							WHERE EE.CLAIMID IS NULL
							and c.sourcedatakey <> 40
							--convert(char, sourcedatakey) + ''+ ClaimID NOT IN (SELECT convert(char, sourcedatakey) + ''+ClaimID FROM EXT_EDPS_CLAIM_STATUS)
							--order by SourceDataKey,ClaimID
							--IF @@ERROR <> 0 
							--BEGIN 
							--	ROLLBACK 
							--END
							--COMMIT

							


							--*******ONLY GET DOS FOR THOSE CLAIMS MISSING DOS IN EXT_EDPS_CLAIM_STATUS
							--GET MAX SERVICE DATE
							--USE MAX TO GET THE LATEST DOS FROM ALL CLAIM LINES
							--SELECT CLAIMID,SOURCEDATAKEY,convert(char, MAX(BEGINSERVICEDATEKEY)) AS DOS_MONTH
							--INTO  #TMPDEV_DOS
							--FROM claimdetaildim
							--WHERE CLAIMID IN (SELECT CLAIMID FROM EXT_EDPS_CLAIM_STATUS 
							--						WHERE LEN(DOS_MONTH) = 0 
							--							OR DOS_MONTH IS NULL)
							--GROUP BY ClaimID,SourceDataKey
							--ORDER BY ClaimID,SourceDataKey

							----UPDATE EXT_EDPS_CLAIM_STATUS WITH MAX(DOS)
							----BEGIN TRANSACTION 
							--UPDATE EXT_EDPS_CLAIM_STATUS
							--SET DOS_MONTH = SUBSTRING(T1.DOS_MONTH,1,6)
							--FROM EXT_EDPS_CLAIM_STATUS E
							--	,#TMPDEV_DOS T1
							--WHERE E.ClaimID = T1.ClaimID
							--	AND E.SourceDataKey = T1.SourceDataKey
							--COMMIT
	
							--UPDATE PRODUCTTYPE FROM MDQOLIB.LINEOFBUSINESSDIM
							--BEGIN TRANSACTION 
							UPDATE EXT_EDPS_CLAIM_STATUS
							SET PRODUCTTYPE = LB.PRODUCTTYPE
								,HPLAN = LB.HCFACode
							FROM EXT_EDPS_CLAIM_STATUS ED
									,MDQOLib.DBO.LineofBusinessDim LB
							WHERE ED.LOBCODE = LB.LOBCode
									AND ED.HPLAN IS NULL
							--IF @@ERROR <> 0 
							--BEGIN 
							--	ROLLBACK 
							--END
							--COMMIT
							
							
							
							--UPDATE SERVICEPLACECODE FOR EZCAP & FACETS CLAIMS
--	TETDM-1995				INSERT INTO #TMPDEV_POS
							INSERT INTO WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_POS
							SELECT CLAIMID,SOURCEDATAKEY,MIN(SERVICEPLACECODE)
							FROM EDPS_DATA.DBO.CLAIMDETAILDIM
							--WHERE SOURCEDATAKEY IN ('3','30')
							GROUP BY CLAIMID,SOURCEDATAKEY,SERVICEPLACECODE
							--ORDER BY SOURCEDATAKEY,CLAIMID

/* -- Scott Waller 04/06/19	TETDM-1995
							CREATE NONCLUSTERED INDEX IDX_TMPDEV_POS_01
								ON #TMPDEV_POS (SOURCEDATAKEY, CLAIMID) 
-- end */
				ALTER INDEX ALL ON WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_POS
				REBUILD;

							--BEGIN TRANSACTION 
							UPDATE EXT_EDPS_CLAIM_STATUS
							SET SERVICEPLACECODE = T.SERVICEPLACECODE
							FROM EXT_EDPS_CLAIM_STATUS E
								,WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_POS T	--#TMPDEV_POS T
							WHERE E.SOURCEDATAKEY = T.SOURCEDATAKEY
								AND  E.CLAIMID = T.CLAIMID
							--IF @@ERROR <> 0
							--BEGIN 
							--ROLLBACK 
							--END 
							--COMMIT
							
							--APPEND ENCOUNTER CLAIMS 
							
							---APPEND BIDW INVENTORY INTO EXT_EDPS_CLAIM_STATUS
							--
							-- Add outboundvhclaimid due to alter table
							--
							-- Note
							-- 07/03/13 Comment out Encounter append. Per LB this 
							-- should be temporary until Encounters are in production
							--
							--BEGIN TRANSACTION 
							--INSERT INTO dbo.EXT_EDPS_CLAIM_STATUS
							--        ( CLAIMID ,
							--          FormTypeCode ,
							--          typecode ,
							--          DeniedFlag ,
							--          SOURCEDATAKEY ,
							--          CLAIM_TYPE ,
							--          CLM_IND ,
							--          CLMSTAT_STATUS ,
							--          LAST_UPD_DATE ,
							--          DOS_MONTH ,
							--          ORIG_BIDW_EXTRACT_DT ,
							--          LAST_BIDW_EXTRACT_DT ,
							--          CMS_ICN ,
							--          FILEID ,
							--          LOBCODE ,
							--          PRODUCTTYPE ,
							--          SERVICEPLACECODE ,
							--          HPLAN ,
							--          PAPER_IND,
							--          SOURCEDESC,
							--          HRP_CLAIM_ID,
							--          OUTBOUNDVHCLAIMID
							--        )
							--select distinct rtrim(claimnum)	
							--		,rtrim(ClaimType)
							--	,' '
							--	,' '--deniedflag
							--	,rtrim(EC.SourceDataKey)
							--	,rtrim(ClaimType)--CLAIM_TYPE
							--	,' '--CLM_IND
							--	,NULL--CLMSTAT_STATUS
							--	,GETDATE()
							--	,substring(convert(char, BeginServiceDateKey),1,6)--DOS_MONTH
							--	,GETDATE() --USE BATCH_EXTRACT_DT
							--	,GETDATE()	--USE BATCH_EXTRACT_DT
							--	,NULL--CMS_ICN
							--	,NULL--FILEID
							--	,' ' --LOBCODE
							--	,NULL --PRODUCTTYPE
							--	,case substring(PlaceOfServiceCode,1,4)when 'NPRO' THEN ' ' ELSE substring(PlaceOfServiceCode,1,4) END --SERVICEPLACECODE
							--	,NULL --HPLAN	
							--	,NULL --PAPER_IND
							--	,RTRIM(EC.SourceDesc)+'-'+RTRIM(EC.SourceEnvironment)  --sourcedesc
							--	,' '--HRP CLAIM ID
							--	,' '--OUTBOUNDVHCLAIMID
							--from EDPS_DATA.DBO.EncounterClaimDim EC
							--LEFT OUTER JOIN EXT_EDPS_CLAIM_STATUS EE
							--ON EC.SOURCEDATAKEY = EE.SOURCEDATAKEY
							--AND EC.CLAIMNUM = EE.CLAIMID
							--WHERE EE.CLAIMID IS NULL 
							--	AND  ClaimLineNum = '1'
							--order by 1
							--IF @@ERROR <> 0 
							--BEGIN 
							--	ROLLBACK 
							--END
							--COMMIT
	
	--##GET CURRENT STATUS FOR CLAIM IN ORDER TO UPDATE INVENTORY
				--STEP 1 GET MAX FILEID WHICH IDENTIFIES LATEST FILE CONTAINING OUTBOUND CLAIMS 

--TETDM-1995
				ALTER INDEX ALL ON WIPRO_Staging.dbo.CLAIM_STATUS_HRPDEV_STATUS
				DISABLE;
							
							INSERT INTO WIPRO_Staging.dbo.CLAIM_STATUS_HRPDEV_STATUS	
							(CLAIM_ID, FILEID)
							SELECT CLAIM_ID
									,MAX(FILEID) AS FILEID
							--INTO #HRPDEV_STATUS
							FROM OUTB_CLAIM_STATUS
							GROUP BY CLAIM_ID
-- SEW why?					ORDER BY CLAIM_ID
/*
-- Scott Waller 04/06/19	TETDM-1995
							CREATE NONCLUSTERED INDEX IDX_HRPDEV_STATUS_01
								ON #HRPDEV_STATUS (CLAIM_ID) 
-- end	
*/
				ALTER INDEX ALL ON WIPRO_Staging.dbo.CLAIM_STATUS_HRPDEV_STATUS
				REBUILD;


				--STEP 2 		
-- TETDM-1995
/*							SELECT CS.CLAIM_ID
									,CLM_IND
									,CS.CLAIM_TYPE
									,CS.FILEID
									,CS.CMS_ICN
									,ISNULL(CLMSTAT_STATUS,'P') AS 'CLMSTAT_STATUS'
									,SOURCEDATAKEY
									,STAT_REJ_REA_ID
									,LAST_UPD_DATE
							INTO #TMPDEV_CLMSTAT
							FROM OUTB_CLAIM_STATUS CS
									,#HRPDEV_STATUS HS
							WHERE CS.CLAIM_ID = HS.CLAIM_ID
								AND CS.FILEID = HS.FILEID
									---and SOURCEDATAKEY = @sourcedatekey
							GROUP BY CS.CLAIM_ID
									,CLM_IND
									,CS.CLAIM_TYPE
									,CS.FILEID
									,CS.CMS_ICN
									,CLMSTAT_STATUS
									,SOURCEDATAKEY
									,STAT_REJ_REA_ID
									,LAST_UPD_DATE
							ORDER BY SOURCEDATAKEY,CLMSTAT_STATUS,CS.CLAIM_ID	
*/
				ALTER INDEX ALL ON WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_CLMSTAT
				DISABLE;

						INSERT INTO WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_CLMSTAT
									(CLAIM_ID ,
									 CLM_IND,
									 CLAIM_TYPE,
									 FILEID,
									 CMS_ICN,
									 CLMSTAT_STATUS,
									 SOURCEDATAKEY,
									 STAT_REJ_REA_ID,
									 LAST_UPD_DATE)
							SELECT CS.CLAIM_ID
									,CLM_IND
									,CS.CLAIM_TYPE
									,CS.FILEID
									,CS.CMS_ICN
									,ISNULL(CLMSTAT_STATUS,'P') AS 'CLMSTAT_STATUS'
									,SOURCEDATAKEY
									,STAT_REJ_REA_ID
									,LAST_UPD_DATE
							FROM OUTB_CLAIM_STATUS CS
									,WIPRO_Staging.dbo.CLAIM_STATUS_HRPDEV_STATUS HS
							WHERE CS.CLAIM_ID = HS.CLAIM_ID
								AND CS.FILEID = HS.FILEID
									---and SOURCEDATAKEY = @sourcedatekey
							GROUP BY CS.CLAIM_ID
									,CLM_IND
									,CS.CLAIM_TYPE
									,CS.FILEID
									,CS.CMS_ICN
									,CLMSTAT_STATUS
									,SOURCEDATAKEY
									,STAT_REJ_REA_ID
									,LAST_UPD_DATE
-- SEW why?							ORDER BY SOURCEDATAKEY,CLMSTAT_STATUS,CS.CLAIM_ID	

				ALTER INDEX ALL ON WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_CLMSTAT
				REBUILD;
-- end TETDM-1995							
							--RESET CLAIMS WITH PREVIOUS CLMSTAT_STATUS OF PEND "SUBMITTED TO HRP"
							
							--BEGIN TRANSACTION 
							--UPDATE EXT_EDPS_CLAIM_STATUS
							--SET CLMSTAT_STATUS = ' '
							--WHERE CLMSTAT_STATUS = 'P'
							--	IF @@ERROR <> 0
							--BEGIN
							--	ROLLBACK
							--END
							--COMMIT
/*						
-- Scott Waller 04/06/19	TETDM-1995
							CREATE NONCLUSTERED INDEX IDX_TMPDEV_CLMSTAT_01
								ON #TMPDEV_CLMSTAT (SOURCEDATAKEY, CLAIM_ID) 
-- end	
*/	
							---UPDATE EXT_EDPS_CLAIM_STATUS WITH CURRENT 
							--BEGIN TRANSACTION 
							UPDATE EXT_EDPS_CLAIM_STATUS
							SET CLAIM_TYPE = TCS.CLAIM_TYPE
								,CLMSTAT_STATUS = TCS.CLMSTAT_STATUS
								,CLM_IND = TCS.CLM_IND
								,CMS_ICN = TCS.CMS_ICN
								,FILEID = TCS.FILEID
							FROM EXT_EDPS_CLAIM_STATUS ECS
								,WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_CLMSTAT TCS		-- TETDM-1995 #tmpdev_clmstat
							WHERE ECS.CLAIMID = TCS.CLAIM_ID
								AND ECS.SOURCEDATAKEY = TCS.SOURCEDATAKEY
								AND LEN(ISNULL(ECS.CLAIM_TYPE,' ')) = 0
							--IF @@ERROR <> 0
							--BEGIN
							--	ROLLBACK
							--END
							--COMMIT
								
							--UPDATE CLMSTAT_STATUS FOR DO NOT SUBMIT HPLANS
							--BEGIN TRANSACTION 
							UPDATE EXT_EDPS_CLAIM_STATUS
							SET CLMSTAT_STATUS = 'X'
							WHERE HPLAN IN (SELECT HPLAN FROM EXT_HPLAN_EXCLUDE)
							--	IF @@ERROR <> 0
							--BEGIN
							--	ROLLBACK
							--END
							--COMMIT
						
/* TETDM-1995				---UPDATE PAPER CLAIM FLAG
							IF OBJECT_ID('TEMPDB..#TMP_PAPER') <> 0
									DROP TABLE #TMP_PAPER
*/
				ALTER INDEX ALL ON WIPRO_Staging.dbo.CLAIM_STATUS_TMP_PAPER
				DISABLE;

							INSERT INTO WIPRO_Staging.dbo.CLAIM_STATUS_TMP_PAPER
							SELECT CLAIMID
									,SOURCEDATAKEY
							-- INTO #TMP_PAPER
							FROM EDPS_DATA.DBO.claimstatusdim
							WHERE AdjudicatorInitials = 'OCR'
-- SEW why?							ORDER BY SOURCEDATAKEY,CLAIMID

/*							
-- Scott Waller 04/06/19	TETDM-1995
							CREATE NONCLUSTERED INDEX IDX_TMP_PAPER_01
								ON #TMP_PAPER (SOURCEDATAKEY, CLAIMID) 
-- end								
*/
				ALTER INDEX ALL ON WIPRO_Staging.dbo.CLAIM_STATUS_TMP_PAPER
				REBUILD;
-- end TETDM-1995
							UPDATE EXT_EDPS_CLAIM_STATUS
							SET PAPER_IND = 'PAPER'
							FROM EXT_EDPS_CLAIM_STATUS E
							JOIN WIPRO_Staging.dbo.CLAIM_STATUS_TMP_PAPER  CS	-- #tmp_paper
							ON  E.CLAIMID = CS.ClaimID
							AND E.SOURCEDATAKEY = CS.SOURCEDATAKEY
							WHERE PAPER_IND <> 'PAPER'


							--Attempt to locate HPLAN
/* TETDM-1995					IF OBJECT_ID('TEMPDB..#TMP_ELIG') <> 0
										  DROP TABLE #TMP_ELIG

										CREATE TABLE #TMP_ELIG
										(
											claim_id	CHAR(20) NULL,
											HICN_NUM	CHAR(20) NULL,
											DOS			VARCHAR(6) NULL,
											[PLAN]		VARCHAR(5) NULL
										)
*/
				ALTER INDEX ALL ON WIPRO_Staging.dbo.CLAIM_STATUS_TMP_PAPER
				DISABLE;

										INSERT  INTO WIPRO_Staging.dbo.CLAIM_STATUS_TMP_ELIG	-- #TMP_ELIG
												SELECT  EP.claimid ,
														C.MEMBERID,
														SUBSTRING(CONVERT(CHAR(10), MIN(beginservicedatekey)), 1, 6) AS 'DOS' ,
														SPACE(5) AS 'PLAN'
												FROM    EXT_EDPS_CLAIM_STATUS EP
														JOIN EDPS_DATA.DBO.CLAIMDIM C ON EP.CLAIMID = C.CLAIMID
												WHERE	LEN(ISNULL(HPLAN,' ')) <> 5
												GROUP BY EP.claimid  ,
														 C.MEMBERID
/*
-- Scott Waller 04/06/19	TETDM-1995
							CREATE NONCLUSTERED INDEX IDX_TMP_ELIG_01
								ON #TMP_ELIG (CLAIM_ID) 
-- end		
*/
				ALTER INDEX ALL ON WIPRO_Staging.dbo.CLAIM_STATUS_TMP_ELIG
				DISABLE;
-- end TETDM-1995


										--UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO from MMR

										UPDATE	WIPRO_Staging.dbo.CLAIM_STATUS_TMP_ELIG	--#TMP_ELIG
										SET     [PLAN] = M.[PLAN]
										FROM	WIPRO_Staging.dbo.CLAIM_STATUS_TMP_ELIG T	--#TMP_ELIG T
												INNER JOIN MDQOLIB.DBO.MMR M ON T.HICN_NUM = M.MEM_ID -- M.Medicare
																				AND T.DOS = m.Payt_Dt
      
										  --BEGIN TRANSACTION 
										  UPDATE EXT_EDPS_CLAIM_STATUS
										  SET HPLAN = T.[PLAN]
										  FROM EXT_EDPS_CLAIM_STATUS EP
										  INNER JOIN WIPRO_Staging.dbo.CLAIM_STATUS_TMP_ELIG T	--#TMP_ELIG T
										  ON EP.CLAIMID = T.claim_id

								--
								--
								-- EDS-236 Data Scrub Scripts
								--
								-- Archive existing EXT_EDPS_CLAIM_STATUS table in order to save history of all deleted records
								-- Archive table EXT_EDPS_CLAIM_STATUS_ARCHIVE will be a historical record table capturing 
								-- all deleted rows due to the below code revisions
							
								
							--Begin Transaction 
							insert into EXT_EDPS_CLAIM_STATUS_Archive 
							select *,getdate()--@ENTRYDT
							from EXT_EDPS_CLAIM_STATUS
							--IF @@ERROR <> 0
							--	BEGIN 
							--		ROLLBACK 
							--	END
							--COMMIT
						

								-- Remove unwanted datasourcekey - Encounter append commentd out instead of deleted.
								-- Keep history of all deleted claims in EXT_EDPS_CLAIM_STATUS_DELETE
							--BEGIN TRANSACTION		
								---TETDM-1122 sdk 40 will not longer get appended to this table. removing append to "delete" table 
								---Below steps not required.

								--INSERT INTO EXT_EDPS_CLAIM_STATUS_DELETE
								--SELECT CS.*
								--FROM EXT_EDPS_CLAIM_STATUS CS
								--LEFT OUTER JOIN EXT_EDPS_CLAIM_STATUS_DELETE CSD
								--ON CS.SOURCEDATAKEY = CSD.SOURCEDATAKEY
								--AND CS.CLAIMID = CSD.CLAIMID
								--WHERE CSD.CLAIMID IS NULL 
								--	AND CS.SOURCEDATAKEY = 40

								--DELETE 
								--FROM EXT_EDPS_CLAIM_STATUS
								--WHERE SOURCEDATAKEY = 40
							--COMMIT

								--Remove S-PLAN
								INSERT INTO EXT_EDPS_CLAIM_STATUS_DELETE
								SELECT CS.*
								FROM EXT_EDPS_CLAIM_STATUS CS
								LEFT OUTER JOIN EXT_EDPS_CLAIM_STATUS_DELETE CSD
								ON CS.SOURCEDATAKEY = CSD.SOURCEDATAKEY
								AND CS.CLAIMID = CSD.CLAIMID
								WHERE CSD.CLAIMID IS NULL 
									AND SUBSTRING(CS.HPLAN,1,1) = 'S'

								DELETE 
								FROM EXT_EDPS_CLAIM_STATUS
								WHERE SUBSTRING(HPLAN,1,1) = 'S'
							--COMMIT
								
								--Remove Producttypes
								--MMAI PRODUCT TYPE = OTHER FROM MDQOLIB.LINEOFBUSINESSDIM UPDATE
							INSERT INTO EXT_EDPS_CLAIM_STATUS_DELETE
								SELECT CS.*
								FROM EXT_EDPS_CLAIM_STATUS CS
								LEFT OUTER JOIN EXT_EDPS_CLAIM_STATUS_DELETE CSD
								ON CS.SOURCEDATAKEY = CSD.SOURCEDATAKEY
								AND CS.CLAIMID = CSD.CLAIMID
								WHERE CSD.CLAIMID IS NULL 
									AND CS.PRODUCTTYPE IN ('Commercial','RX','Medicaid','PDP')

								DELETE 
								FROM EXT_EDPS_CLAIM_STATUS
								WHERE PRODUCTTYPE IN ('Commercial','RX','Medicaid','PDP')
							--COMMIT
/*						
-- Scott Waller 04/06/2019	TETDM-1995
			DROP TABLE	#TMPDEV_POS
			DROP TABLE	#TMPDEV_CLMSTAT
			DROP TABLE	#HRPDEV_STATUS
			DROP TABLE	#TMP_PAPER
			DROP TABLE	#TMP_ELIG
-- end												 
*/
-- TETDM-1995
			TRUNCATE TABLE	WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_POS
			TRUNCATE TABLE	WIPRO_Staging.dbo.CLAIM_STATUS_TMPDEV_CLMSTAT
			TRUNCATE TABLE	WIPRO_Staging.dbo.CLAIM_STATUS_HRPDEV_STATUS
			TRUNCATE TABLE	WIPRO_Staging.dbo.CLAIM_STATUS_TMP_PAPER
			TRUNCATE TABLE	WIPRO_Staging.dbo.CLAIM_STATUS_TMP_ELIG
-- end 

							SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EXT_EDPS_CLAIM_STATUS)
													
						----EXSP_HRP_CLAIM_RECON UPDATE RUN CONTROLS
								--BEGIN TRANSACTION
										UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EXSP_WIPRO_CLAIM_RECON'
													AND END_DT IS NULL

