﻿
/**********************************************************************/
CREATE Proc Update_004
AS
/***************************************************************************************************
** CREATE DATE: 09/2020
**
** AUTHOR: Subhash Acharya
**
** DESCRIPTION: 
**				
				Sample Invocation 
				EXEC [dbo].[Update_004]
**				
Modification History
====================
Date			Who				  Description
09/28/2020		Subhash Acharya   TETDM-2362
11/09/2020		Subhash Acharya   TETDM-2369
01/12/2022		Subhash Acharya   RETM-16
01/12/2022		Subhash Acharya   RETM-29

*****************************************************************************************************/	

--EXEC Update_004

;WITH UpdateLogic  AS (
SELECT Patient_Control_No,
SourceDecription =  CAST(CONCAT('<x>',REPLACE(Patient_Control_No,'-','</x><x>'),'</x>') AS XML),Source_desc
 FROM  [WIPRO].[dbo].[CMS_MAO_004_Detail] 
WHERE Source_desc IS NULL
AND ThroughDateofService > '20201231'
AND   ( WIPROClaimID Like 'L%' 
	 OR WIPROClaimID Like 'U%' 
	 OR WIPROClaimID Like 'D1%' 
	 OR WIPROClaimID Like '210%' 
	 OR WIPROClaimID Like '40%' 
	 OR WIPROClaimID Like 'D2%' 
	 OR WIPROClaimID Like 'D3%' 
	 OR WIPROClaimID Like 'D4%' 
	 OR WIPROClaimID Like 'D5%' 
	 OR WIPROClaimID Like 'D6%' 
	 OR WIPROClaimID Like 'V1%' 
	 OR WIPROClaimID Like 'V2%' 
	 OR WIPROClaimID Like 'V3%' 
	 OR WIPROClaimID Like 'V4%' 
	 OR WIPROClaimID Like 'V5%' 
	 OR WIPROClaimID Like 'V6%'
	  ) 
AND Patient_Control_No IS NOT NULL
)
UPDATE UpdateLogic SET Source_desc = LTRIM(RTRIM(SourceDecription.value('(./x)[2]','varchar(50)')))
--SELECT LTRIM(RTRIM(SourceDecription.value('(./x)[2]','varchar(50)'))),* 
FROM  UpdateLogic 



UPDATE WIPRO.[dbo].[CMS_MAO_004_Detail]
SET Source_desc = CASE  WHEN WIPROClaimID Like '30%'   THEN 'LEON'
						WHEN WIPROClaimID Like '41%'   THEN 'ADVOCATE'
						WHEN WIPROClaimID Like '43%'   THEN 'WELLMED'
						WHEN WIPROClaimID Like '44%'   THEN 'SUPERIORVISION'
						WHEN WIPROClaimID Like '45%'   THEN 'EYEMED'
						WHEN WIPROClaimID Like '210%'  THEN 'AZ'
						WHEN WIPROClaimID Like '40%'   THEN 'AZ'
						WHEN WIPROClaimID Like '50%'   THEN 'QNXT'
						WHEN WIPROClaimID Like '51%'   THEN 'QNXT'
						WHEN WIPROClaimID Like '52%'   THEN 'QNXT'
						WHEN WIPROClaimID Like 'C01%'  THEN 'PROSPECT'
						WHEN WIPROClaimID Like 'C02%'  THEN 'WELLMED'
						WHEN WIPROClaimID Like 'C03%'  THEN 'SUPERIORVISION'
						WHEN WIPROClaimID Like 'C04%'  THEN 'ADVOCATE'
						WHEN WIPROClaimID Like 'D0%'   THEN 'LEON'
						WHEN WIPROClaimID Like 'E0%'   THEN 'QNXT'   
			      ELSE NULL END
--SELECT Sourcedatakey,Source_desc,* FROM WIPRO.[dbo].[CMS_MAO_004_Detail]
WHERE Source_desc IS NULL
AND ThroughDateofService > '20201231' 

SET QUOTED_IDENTIFIER ON;  
UPDATE CMSMAO004D
SET  CMSMAO004D.ClaimId = MAO002D.PlanClaimNumber
FROM WIPRO.[dbo].[CMS_MAO_004_Detail] CMSMAO004D
JOIN WIPRO.[dbo].[MAO_002_Detail] MAO002D
ON MAO002D.CMSICN = CMSMAO004D.EncounterICN
WHERE CMSMAO004D.ClaimID IS NULL
AND CMSMAO004D.ThroughDateofService > '20201231';


SET QUOTED_IDENTIFIER ON; 
UPDATE CMSMAO004D
SET  CMSMAO004D.WIPROClaimID = MAO002D.WIPRO_UNQ_ID
FROM WIPRO.[dbo].[CMS_MAO_004_Detail] CMSMAO004D
JOIN WIPRO.[dbo].[MAO_002_Detail] MAO002D
ON MAO002D.CMSICN = CMSMAO004D.EncounterICN
WHERE CMSMAO004D.WIPROClaimID IS NULL
AND CMSMAO004D.ThroughDateofService > '20201231';


SET QUOTED_IDENTIFIER ON; 
UPDATE CMSMAO004D
SET  CMSMAO004D.Patient_Control_No = MAO002D.Patient_Control_No
FROM WIPRO.[dbo].[CMS_MAO_004_Detail] CMSMAO004D
JOIN WIPRO.[dbo].[MAO_002_Detail] MAO002D
ON MAO002D.CMSICN = CMSMAO004D.EncounterICN
WHERE CMSMAO004D.Patient_Control_No IS NULL
AND CMSMAO004D.ThroughDateofService > '20201231';


SET QUOTED_IDENTIFIER ON; 
UPDATE WIPRO.[dbo].[CMS_MAO_004_Detail]
SET Sourcedatakey = CASE 
						WHEN WIPROClaimID Like '30%'   THEN '30'
						WHEN WIPROClaimID Like '41%'   THEN '41'
						WHEN WIPROClaimID Like '43%'   THEN '43'
						WHEN WIPROClaimID Like '44%'   THEN '44'
						WHEN WIPROClaimID Like '50%'   THEN '50'
						WHEN WIPROClaimID Like '51%'   THEN '51'
						WHEN WIPROClaimID Like '52%'   THEN '52'
						
						WHEN WIPROClaimID Like '210%'  THEN 'AZ'
						WHEN WIPROClaimID Like '40%'   THEN 'AZ'
						
						WHEN WIPROClaimID Like 'C01%'   THEN '4'
						WHEN WIPROClaimID Like 'C02%'   THEN '43' 
						WHEN WIPROClaimID Like 'C03%'   THEN '44'
						WHEN WIPROClaimID Like '45%'    THEN '45' 
						WHEN WIPROClaimID Like 'C04%'   THEN '41' 
						WHEN WIPROClaimID Like 'D0%'    THEN '30'
						WHEN WIPROClaimID Like 'E0%'    THEN '50'
						WHEN WIPROClaimID Like 'L%'     THEN '99'
						WHEN WIPROClaimID Like 'U%'     THEN '88'
						WHEN WIPROClaimID Like 'D1%'    THEN '11'
						WHEN WIPROClaimID Like 'D2%'    THEN '12'
						WHEN WIPROClaimID Like 'D3%'    THEN '13'
						WHEN WIPROClaimID Like 'D4%'    THEN '14'
						WHEN WIPROClaimID Like 'D5%'    THEN '15'
						WHEN WIPROClaimID Like 'D6%'    THEN '16'
						WHEN WIPROClaimID Like 'V1%'    THEN '17'
						WHEN WIPROClaimID Like 'V2%'    THEN '18'
						WHEN WIPROClaimID Like 'V3%'    THEN '19'
						WHEN WIPROClaimID Like 'V4%'    THEN '20'
						WHEN WIPROClaimID Like 'V5%'    THEN '21'
						WHEN WIPROClaimID Like 'V6%'    THEN '22'
							 ELSE NULL END
WHERE Sourcedatakey IS NULL
AND ThroughDateofService > '20201231';


--SET QUOTED_IDENTIFIER ON; 
--UPDATE a
--SET RAPS_PCN_4 = mmd.PBPCode	
----select top 10 *
--FROM [WIPRO].[dbo].[CMS_MAO_004_Detail]	 a
--JOIN [EDPS_Data].[dbo].[MonthlyMembershipDim] mmd	
--        ON a.BeneficiaryHICN = mmd.MedicareID	
--        AND a.MedicareAdvContractID = mmd.HCFACode	
--WHERE 1 = 1	
--        AND EOMONTH(CAST(a.ThroughDateofService AS DATE)) = convert(date,CAST(mmd.ReportDateKey AS VARCHAR(8)))		
--        AND a.ThroughDateofService > '20201231'; 
