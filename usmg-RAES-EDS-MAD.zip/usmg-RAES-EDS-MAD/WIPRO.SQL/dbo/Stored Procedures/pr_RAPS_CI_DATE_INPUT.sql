﻿
CREATE PROCEDURE [dbo].[pr_RAPS_CI_DATE_INPUT] 

(@LastModifiedDate DATE,  @CreatedDate DATE, @Startdate DATE)

AS

/***************************************************************************************************
** CREATE DATE: 05/2019
** AUTHOR: Anthony Ulmer
** DESCRIPTION: 
	Creates date entries for Supp process to pull from MDQOLib DB on MDQO server
*****************************************************************************************************/	

INSERT INTO WIPRO.dbo.[SUPP_CI_Data_Collection_Run_Dates] (LastModifiedDate, CreatedDate, StartDate, CreatedBy, DateInserted)
	VALUES (@LastModifiedDate, @CreatedDate, @Startdate, DEFAULT, DEFAULT);

