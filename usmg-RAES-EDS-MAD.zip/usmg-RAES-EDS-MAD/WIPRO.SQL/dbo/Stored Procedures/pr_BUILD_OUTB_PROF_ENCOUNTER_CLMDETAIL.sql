﻿
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_PROF_ENCOUNTER_CLMDETAIL]
(@SOURCEDESC VARCHAR(50))--,@SOURCE_ENVIRONMENT VARCHAR(10))
AS
/***************************************************************************************************
** CREATE DATE: 01/2013
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM LINE 
**              INFORMATION. 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
02/18/13		LOYAL RICKS		ADD @SOURCEDESC * @SOURCE_ENVIRONMENT INPUT PARM
								ADD  @SOURCEDESC * @SOURCE_ENVIRONMENT TO #TMP_CLAIMLINE BUILD
								REMOVE LOGIC - --where ECD.CLAIMNUM in (select CLAIM_ID from dbo.EXT_HRP_CLAIM)
								USE #TMP INSTEAD OF #TMP
06/19/2013		LOYAL RICKS		INVALID CHARACTER MEMBER RECORD PARSE 
2013-07-16      Loyal Ricks		Add Optional Reporting Ind1 Logic for "Interest Claims", claims with 
								PROC_CODE IN ('0L6','$INT'). 
2013-10-01		Dwight Staggs	Had to qualify occurances of BeginServiceDate as it is now in both 
								ClaimDim and ClaimDetailDim
2013-10-25		Loyal Ricks		Add procedurecode data scrub replacing decimal and spaces
								replace(REPLACE(procedurecode,'.',' '),' ','')
2013-11-18		Loyal Ricks		Remove default value for CONTRACT_CODE per onsite meeting on 10/15/13
07/15/2016		Loyal Ricks		Remove input parameters @SOURCE_ENVIRONMENT
								job will utilize exclusion build "DP" logic for selection of valid claims. All PROD
								only claims will be selected. Functionality to select UAT claims removed, no longer 
								needed.	
08/16/2016		Loyal Ricks		TETDM-979 Remove Sourceenvironment references	
12/20/2016		Loyal Ricks		TETDM-1274 OTHER_PAYER1_ADJ_DT Update from encounterclaimdim.loaddatekey
03/05/2018      JohnBartholomay TETDM-1710  Anes Modifier updates
10/15/2018		Anthony Ulmer	TETDM-1889 Refactored initial claim pull to help reduce number of duplicate lines
02/25/2021      Aaron Ridley    TETDM-2359 Added logic to allow for frequency codes 7,8 to accom adjustment submissions 
*****************************************************************************************************/	
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('EXSP_HRP_CLAIM_PROF_ENCOUNTER_CLMDETAIL'
				,'3'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
				
	----------------------
--OUTB_PROF_DETAIL
----------------------



	;WITH RoughClaimBasket AS 
	(
		SELECT
		*
		FROM (
				SELECT
					e.*
					--TETDM 1772 NOTE: The sort order in this over partition by is critical in the selection of the claims.  This will determine which claim from a set of duplicates will be picked up.
					--TETDM 1889 NOTE: The sort order is for LoadDateKey and BeginServiceDateKey is reversed to try to account for latest claim lines (DETAIL PROCEDURE ONLY).
				   ,latest = ROW_NUMBER() OVER (PARTITION BY e.CLAIMNUM, e.ClaimLineNum, e.ClaimType, e.MemberID, e.SOURCEDESC ORDER BY  e.LoadDateKey DESC, e.BeginServiceDateKey, e.FILENAME DESC)
				   FROM EDPS_Data.dbo.encounterclaimdim e
				   WHERE 1 = 1
						AND e.SourceDesc = @SourceDesc
						AND e.ClaimType = 'P'
						AND e.ClaimFrequencyCode in ('1','7','8') -- 2359 added Frequency Code
                        AND EXISTS (SELECT 1 FROM WIPRO.DBO.OUTB_PROF_HEADER oih WHERE oih.CLAIM_ID = e.ClaimNum) 
			)sub
		WHERE sub.latest = 1
	)
	INSERT INTO OUTB_PROF_DETAIL
	SELECT 'L'
		,ECD.ClaimNum
		,ECD.ClaimLineNum
		,ECD.beginservicedatekey
		,ECD.endservicedatekey
		,isnull(RevenueCode,' ') --revenue code 1
		,' '--revenue code 2
		,' '--revenue code 3
		,'HC'--Product or Service ID Qualifier
		,replace(REPLACE(procedurecode,'.',' '),' ','')--procedure code
		,isnull(ModifierCode1,' ')--procedure modifier1
		,isnull(ModifierCode2,' ')
		,isnull(ModifierCode3,' ')
		,isnull(ModifierCode4,' ')
		,' '
		,ltrim(requestedamt)
		,' '
		,'UN'--Anesthesia Flag
		,' '
		,quantity
		,SUBSTRING(PlaceOfServiceCode,1,15)
		,CASE ISNULL(DX1,' ') WHEN ' ' THEN ' ' ELSE '1' END --PRIM_DIAG_CD
		,CASE ISNULL(DX2,' ') WHEN ' ' THEN ' ' ELSE '2' END --DIAG_CD2
		,CASE ISNULL(DX3,' ') WHEN ' ' THEN ' ' ELSE '3' END --DIAG_CD3
		,CASE ISNULL(DX4,' ') WHEN ' ' THEN ' ' ELSE '4' END --DIAG_CD4
		,CASE ISNULL(DX5,' ') WHEN ' ' THEN ' ' ELSE '5' END --DIAG_CD5
		,CASE ISNULL(DX6,' ') WHEN ' ' THEN ' ' ELSE '6' END --DIAG_CD6
		,CASE ISNULL(DX7,' ') WHEN ' ' THEN ' ' ELSE '7' END --DIAG_CD7
		,CASE ISNULL(DX8,' ') WHEN ' ' THEN ' ' ELSE '8' END --DIAG_CD8
		,CASE ISNULL(DX9,' ') WHEN ' ' THEN ' ' ELSE '9' END --DIAG_CD9
		,CASE ISNULL(DX10,' ') WHEN ' ' THEN ' ' ELSE '10' END --DIAG_CD10
		,' '
		,' '
		,' '
		,' '
		,' '--DIAG_CD15
		,' '
		,' '
		,' '
		,' '
		,' '--DIAG_CD20
		,' '
		,' '
		,' '
		,' '
		,' '--DIAG_CD25
		,' '
		,' '
		,' '
		,' '
		,' '--diag_cd30
		,isnull(AdmissionTypeCode,' ')--emer_flag
		,' '--copay_Ex_flag
		,ECD.ClaimLineNum
		,' '----clia_no
		,' '--CLIAReferralNumber--ref_clia_fac_no_qual
		,' '--OTH_PAYER1_PRIMEID	
		,IIF(ECD.RequestedAmt != 0, '0.00',ltrim(PaidAmt))--OTH_PAYER1_PAID_AMT	CHAR(18),
		,replace(REPLACE(procedurecode,'.',' '),' ','')--OTH_PAYER1_PROC_CD	CHAR(8),
		,Quantity--OTH_PAYER1_PAID_QTY	CHAR(9),
		,' '--OTH_PAYER1_ADJ_BUNDLE	CHAR(6),
		,CASE 
            --WHEN ECD.RequestedAmt != 0 THEN 'CR'
            WHEN ECD.RequestedAmt = 0 THEN ' '
            ELSE 'CO'
         END --CLM_ADJ_GRP111		CHAR(30),
		,CASE 
            WHEN ECD.RequestedAmt != 0 THEN '223'
            WHEN ECD.RequestedAmt = 0 THEN ' '
            ELSE '45'
         END --[CLM_ADJ_REASON111] ,
		,IIF(ECD.RequestedAmt != 0,LTRIM(RTRIM(TRY_CONVERT(CHAR, ECD.RequestedAmt))),' ') --[CLM_ADJ_AMT111] ,
		,IIF(ECD.RequestedAmt != 0, IIF(ECD.Quantity = 0,1,ECD.Quantity),' ')--[CLM_ADJ_QTY111] ,
		,' '--[CLM_ADJ_REASON112] ,
		,' '--[CLM_ADJ_AMT112] ,
		,' '--[CLM_ADJ_QTY112] ,
		,' '--[CLM_ADJ_REASON113] ,
		,' '--[CLM_ADJ_AMT113] ,
		,' '--[CLM_ADJ_QTY113] ,
		,' '--[CLM_ADJ_REASON114] ,
		,' '--[CLM_ADJ_AMT114] ,
		,' '--[CLM_ADJ_QTY114] ,
		,' '--[CLM_ADJ_REASON115] ,
		,' '--[CLM_ADJ_AMT115] ,
		,' '--[CLM_ADJ_QTY115] ,
		,' '--[CLM_ADJ_REASON116] ,
		,' '--[CLM_ADJ_AMT116] ,
		,' '--[CLM_ADJ_QTY116] ,	
		,' '--[CLM_ADJ_GRP12] ' '--[char](30) ,
		,' '--[CLM_ADJ_REASON121] ,
		,' '--[CLM_ADJ_AMT121] ,
		,' '--[CLM_ADJ_QTY121] ,
		,' '--[CLM_ADJ_REASON122] ,
		,' '--[CLM_ADJ_AMT122] ,
		,' '--[CLM_ADJ_QTY122] ,
		,' '--[CLM_ADJ_REASON123] ,
		,' '--[CLM_ADJ_AMT123] ,
		,' '--[CLM_ADJ_QTY123] ,
		,' '--[CLM_ADJ_REASON124] ,
		,' '--[CLM_ADJ_AMT124] ,
		,' '--[CLM_ADJ_QTY124] ,
		,' '--[CLM_ADJ_REASON125] ,
		,' '--[CLM_ADJ_AMT125] ,
		,' '--[CLM_ADJ_QTY125] ,
		,' '--[CLM_ADJ_REASON126] ,
		,' '--[CLM_ADJ_AMT126] ,
		,' '--[CLM_ADJ_QTY126] ,
		,' '--[CLM_ADJ_GRP13] ,' '--[char](30) ,
		,' '--[CLM_ADJ_REASON131] ,
		,' '--[CLM_ADJ_AMT131] ,
		,' '--[CLM_ADJ_QTY131] ,
		,' '--[CLM_ADJ_REASON132] ,
		,' '--[CLM_ADJ_AMT132] ,
		,' '--[CLM_ADJ_QTY132] ,
		,' '--[CLM_ADJ_REASON133] ,
		,' '--[CLM_ADJ_AMT133] ,
		,' '--[CLM_ADJ_QTY133] ,
		,' '--[CLM_ADJ_REASON134] ,
		,' '--[CLM_ADJ_AMT134] ,
		,' '--[CLM_ADJ_QTY134] ,
		,' '--[CLM_ADJ_REASON135] ,
		,' '--[CLM_ADJ_AMT135] ,
		,' '--[CLM_ADJ_QTY135] ,
		,' '--[CLM_ADJ_REASON136] ,
		,' '--[CLM_ADJ_AMT136] ,
		,' '--[CLM_ADJ_QTY136] ,
		,' '--[CLM_ADJ_GRP14] ,' '--[char](30) ,
		,' '--[CLM_ADJ_REASON141] ,
		,' '--[CLM_ADJ_AMT141] ,
		,' '--[CLM_ADJ_QTY141] ,
		,' '--[CLM_ADJ_REASON142] ,
		,' '--[CLM_ADJ_AMT142] ,
		,' '--[CLM_ADJ_QTY142] ,
		,' '--[CLM_ADJ_REASON143] ,
		,' '--[CLM_ADJ_AMT143] ,
		,' '--[CLM_ADJ_QTY143] ,
		,' '--[CLM_ADJ_REASON144] ,
		,' '--[CLM_ADJ_AMT144] ,
		,' '--[CLM_ADJ_QTY144] ,
		,' '--[CLM_ADJ_REASON145] ,
		,' '--[CLM_ADJ_AMT145] ,
		,' '--[CLM_ADJ_QTY145] ,
		,' '--[CLM_ADJ_REASON146] ,
		,' '--[CLM_ADJ_AMT146] ,
		,' '--[CLM_ADJ_QTY146] ,
		,' '--[CLM_ADJ_GRP15] ,' '--[char](30) ,
		,' '--[CLM_ADJ_REASON151] ,
		,' '--[CLM_ADJ_AMT151] ,
		,' '--[CLM_ADJ_QTY151] ,
		,' '--[CLM_ADJ_REASON152] ,
		,' '--[CLM_ADJ_AMT152] ,
		,' '--[CLM_ADJ_QTY152] ,
		,' '--[CLM_ADJ_REASON153] ,
		,' '--[CLM_ADJ_AMT153] ,
		,' '--[CLM_ADJ_QTY153] ,
		,' '--[CLM_ADJ_REASON154] ,
		,' '--[CLM_ADJ_AMT154] ,
		,' '--[CLM_ADJ_QTY154] ,
		,' '--[CLM_ADJ_REASON155] ,
		,' '--[CLM_ADJ_AMT155] ,
		,' '--[CLM_ADJ_QTY155] ,
		,' '--[CLM_ADJ_REASON156] ,
		,' '--[CLM_ADJ_AMT156] ,
		,' '--[CLM_ADJ_QTY156] ,
		,case ltrim(PaidDateKey) when '19000101' then '20121231' when '0' then '20121231' else LTRIM(paiddatekey) end--OTH_PAYER1_ADJ_DT	CHAR(10),
		,sourcedatakey
		,' '--FeeCalculationCode ONLY USED FOR REPRICING
		,' '--CASE PROVIDERCAPITATIONSTATUS WHEN 'Y' THEN  '05' ELSE ' ' END--CONTACT CODE
		,'05'--CASE PROVIDERCAPITATIONSTATUS WHEN 'Y' THEN  '05' ELSE ' ' END--CONTACT TYPE
		,' ' --OPTIONAL_RPT_IND1
	FROM RoughClaimBasket ECD;


		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
			--UPDATE EXT_HRP_CLAIM.CMS_CONTRACT_NUM USING DOS OF CLAIM TO GET APPROPRIATE ELIGIBILITY
			--HRP CLAIM HEADER - CMS_CONTRACT_NUM & OTH_PAYER1_PLANID UPDATES
			--use claimline dos to determine eligibility row from mmr that will be used. Code will be based on datasourcekey and claim to mmr relationship.
				SELECT  C.CLAIM_ID,C.MEMBER_ID,SUBSTRING(MIN(CD.SERV_START_DT),1,6) AS 'DOS',C.SOURCEDATAKEY
				INTO #TMPDEV_ELIG
				FROM OUTB_PROF_HEADER C
					,OUTB_PROF_DETAIL CD
				WHERE C.CLAIM_ID = CD.CLAIM_ID
				GROUP BY C.CLAIM_ID,C.MEMBER_ID,C.SOURCEDATAKEY
				ORDER BY C.MEMBER_ID,C.CLAIM_ID
		--MEMBER ELIGIBILITY - USE MIN(CLAIMDETAILDIM.BEGINSERVICEDATEKEY)
		--MHC ELGIBILITY
			--UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO
		--BEGIN TRANSACTION 
			UPDATE OUTB_PROF_HEADER
			SET CMS_CONTRACT_NUM = MR.[PLAN]
					,OTH_PAYER1_PLANID = MR.[PLAN]
			FROM OUTB_PROF_HEADER C
				 ,#TMPDEV_ELIG T
				,MDQOLib.dbo.MMR MR
			WHERE C.CLAIM_ID = T.CLAIM_ID
				AND REPLACE(C.MEMBER_ID,'-','*')  = MR.MEM_ID
				AND substring(mr.[plan],1,1) <> 'S'
				AND MR.[payt_dt] = T.DOS
				AND C.SOURCEDATAKEY = '4'
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		
		--QNXT ELIGIBILITY - USE MIN(CLAIMDETAILDIM.BEGINSERVICEDATEKEY)
		
			
	--UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO
		--BEGIN TRANSACTION 
			UPDATE OUTB_PROF_HEADER
			SET CMS_CONTRACT_NUM = MR.[PLAN]
			,OTH_PAYER1_PLANID = MR.[PLAN]
			FROM OUTB_PROF_HEADER C
				 ,#TMPDEV_ELIG T
				 ,MDQOLib.dbo.MMR MR
			--REMOVE JOIN ON MEMBER_ID 5/29 MDQOLIB.DBO.MMR.MEM_ID IS NULL
			--ON REPLACE(MEMBER_ID,'-','*')  = MR.MEM_ID
			WHERE C.CLAIM_ID = T.CLAIM_ID
				AND C.HICN_NUM = MR.Medicare
				AND substring(mr.[plan],1,1) <> 'S'
				AND MR.[payt_dt] = T.DOS
				AND C.SOURCEDATAKEY = '4'
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		--UPDATE OTH_PAYER1_PRIMEID
		--BEGIN TRANSACTION 
			UPDATE OUTB_PROF_DETAIL
			SET OTH_PAYER1_PRIMEID = C.CMS_CONTRACT_NUM 
			FROM OUTB_PROF_DETAIL CD
			JOIN OUTB_PROF_HEADER C
			ON C.CLAIM_ID = CD.CLAIM_ID
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		
	
			--ANESTHESIA FLAG UPDATE
		--BEGIN TRANSACTION 
			--UPDATE OUTB_PROF_DETAIL
			--SET ANES_FLAG =  'MJ'
			--WHERE PROC_CD BETWEEN '00100' AND '01999'
		--	if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		 
		 		
		--TETDM-1710
		-------------------------------
		-- ANES MODIFIER 2014-2017
		-------------------------------
		UPDATE D 
		SET ANES_FLAG = 'MJ'
		FROM
		  dbo.OUTB_PROF_DETAIL D,
          dbo.ANES_2014_2017 A
		WHERE A.ANES_CODE = D.PROC_CD
		  AND D.SERV_START_DT >= '20140101'
		  AND D.SERV_END_DT <= '20171231'

        --TETDM-1710
        --------------------------------
		--ANES_2018
		--------------------------------
		UPDATE D 
		SET ANES_FLAG = 'MJ'
		FROM
		  dbo.OUTB_PROF_DETAIL D,
          dbo.ANES_2018 A
		WHERE A.ANES_CODE = D.PROC_CD
		  AND D.SERV_START_DT >= '20180101'


		
		/*********************************************************************************************
		** 6/19/13 - INVALID CHARACTER MEMBER RECORD PARSE 
		*********************************************************************************************/
		UPDATE OUTB_PROF_HEADER
		SET MEMBER_LAST_NAME = REPLACE(MEMBER_LAST_NAME,'`',' ')
		WHERE CHARINDEX('`',MEMBER_LAST_NAME) > 0

		UPDATE OUTB_PROF_HEADER
		SET MEMBER_LAST_NAME = REPLACE(MEMBER_LAST_NAME,';',' ')
		WHERE CHARINDEX(';',MEMBER_LAST_NAME) > 0
		
		
		UPDATE OUTB_PROF_HEADER
		SET MEMBER_FIRST_NAME = REPLACE(MEMBER_FIRST_NAME,'`',' ')
		WHERE CHARINDEX('`',MEMBER_FIRST_NAME) > 0

		UPDATE OUTB_PROF_HEADER
		SET MEMBER_LAST_NAME = REPLACE(MEMBER_LAST_NAME,';',' ')
		WHERE CHARINDEX(';',MEMBER_LAST_NAME) > 0
		
		
		UPDATE OUTB_PROF_HEADER
		SET MEMBER_ADDR1 = REPLACE(MEMBER_ADDR1,'`',' ')
		WHERE CHARINDEX('`',MEMBER_ADDR1) > 0

		UPDATE OUTB_PROF_HEADER
		SET MEMBER_ADDR1 = REPLACE(MEMBER_ADDR1,';',' ')
		WHERE CHARINDEX(';',MEMBER_ADDR1) > 0
		
			
		update OUTB_PROF_HEADER
		set MEMBER_ADDR1 = REPLACE(member_addr1,'`;','')
		where CHARINDEX('`;',member_addr1) > 0 

		update OUTB_PROF_HEADER
		set MEMBER_ADDR2 = REPLACE(MEMBER_ADDR2,'`','')
		where CHARINDEX('`',MEMBER_ADDR2) > 0 
			
		UPDATE OUTB_PROF_HEADER
		SET MEMBER_ADDR2 = REPLACE(MEMBER_ADDR2,'~',' ')
		WHERE CHARINDEX('~',MEMBER_ADDR2) > 0

		UPDATE OUTB_PROF_HEADER
		SET MEMBER_ADDR2 = REPLACE(MEMBER_ADDR2,'`',' ')
		WHERE CHARINDEX('`',MEMBER_ADDR2) > 0


		UPDATE OUTB_PROF_HEADER
		SET MEMBER_ADDR2 = REPLACE(MEMBER_ADDR2,'*',' ')
		WHERE CHARINDEX('*',MEMBER_ADDR2) > 0

		UPDATE OUTB_PROF_HEADER
		SET MEMBER_ADDR2 = REPLACE(MEMBER_ADDR2,':',' ')
		WHERE CHARINDEX(':',MEMBER_ADDR2) > 0

		UPDATE OUTB_PROF_HEADER
		SET MEMBER_ADDR2 = REPLACE(MEMBER_ADDR2,'^',' ')
		WHERE CHARINDEX('^',MEMBER_ADDR2) > 0

		UPDATE OUTB_PROF_HEADER
		SET MEMBER_ADDR2 = REPLACE(MEMBER_ADDR2,' " "',' ')
		WHERE CHARINDEX('""',MEMBER_ADDR2) > 0
		
		--TETDM-1889 We are leaving this maxfilename piece in for now that updates the null paid dates with loaddatekey
			IF OBJECT_ID('TEMPDB..#OUTB_ENC_LSUB') <> 0
				DROP TABLE #OUTB_ENC_LSUB
			CREATE TABLE #OUTB_ENC_LSUB (
				SOURCEDESC VARCHAR(60) NULL
			   ,CLAIMNUM VARCHAR(50) NULL
			   ,FILENAME VARCHAR(256) NULL
			   ,LOADDATEKEY INT
			)

		----Get Max Filename for submissions

			INSERT INTO #OUTB_ENC_LSUB
			select ec.SOURCEDESC,CLAIMNUM,max(filename),LOADDATEKEY  
			from edps_data.dbo.encounterclaimdim ec
			inner join OUTB_PROF_HEADER PH
			on ec.sourcedesc = @SOURCEDESC
			and ec.claimnum = PH.CLAIM_ID
			GROUP BY ec.SOURCEDESC,CLAIMNUM,loaddatekey
			ORDER BY CLAIMNUM

		---TETDM-1274 OTHER_PAYER1_ADJ_DT Update from encounterclaimdim.loaddatekey
				---Update Claim Header PAYER1_PAID_DT
				UPDATE OUTB_PROF_HEADER 
				SET PAYER1_PAID_DT = convert(char, t.LOADDATEKEY)
				FROM OUTB_PROF_HEADER P
				INNER JOIN #OUTB_ENC_LSUB T
				ON P.CLAIM_ID = T.CLAIMNUM 
				AND P.PAYER1_PAID_DT IS NULL

				--update claim header OTHER_PAYER1_ADJ_DT
				UPDATE OUTB_PROF_DETAIL 
				SET OTH_PAYER1_ADJ_DT = convert(char, t.LOADDATEKEY)
				FROM OUTB_PROF_DETAIL P
				INNER JOIN #OUTB_ENC_LSUB T
				ON P.CLAIM_ID = T.CLAIMNUM 
				AND P.OTH_PAYER1_ADJ_DT IS NULL



		
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_PROF_HEADER_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_DETAIL)
									
		----HRP_CLAIM_FILE Update Run Controls
				--BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'EXSP_HRP_CLAIM_PROF_ENCOUNTER_CLMDETAIL'
							AND END_DT IS NULL
						--	IF @@ERROR <> 0
						--				BEGIN 
						--						ROLLBACK 
						--				END
						--COMMIT
						
						
						
						
						
						
						
						
						
