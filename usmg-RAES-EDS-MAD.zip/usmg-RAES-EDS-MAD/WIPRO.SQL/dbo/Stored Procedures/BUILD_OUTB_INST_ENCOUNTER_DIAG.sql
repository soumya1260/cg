﻿



--
						

CREATE PROCEDURE [dbo].[BUILD_OUTB_INST_ENCOUNTER_DIAG]
(@SOURCEDATAKEY INT)
AS
/***************************************************************************************************
** CREATE DATE: 08/2017
**
** AURTHOR: John Bartholomay
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM HEADER 
**              AND LINE LEVE DIAGNOSIS CODE INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------


																					    
*****************************************************************************************************/		

			DECLARE
			
			@TOTAL_HEADER_RECORDS INT,
			@TOTAL_DETAIL_RECORDS INT,
			@TOTAL_RECORDS INT
--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_CLAIM_INST_ENCOUNTER_DIAG'
				,'4'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
	IF OBJECT_ID('TEMPDB..#claimdetaildiagnosisdim') <> 0
					DROP TABLE #claimdetaildiagnosisdim
					
					CREATE TABLE #claimdetaildiagnosisdim
					(  claimid varchar(20)
						,CLAIMLINEID varchar(4)
						,DIAGNOSISCODE varchar(10)
						,SEQUENCE int
					)

--UPDATE DIAGNOSIS CODES
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD1 = replace(E.DIAG_CD1,'.',''),
			    POA_IND1 =  'N' ,
				DIAG_CD_QUAL1 = 'BF'
			FROM OUTB_INST_HEADER E
			WHERE LTRIM(RTRIM(e.DIAG_CD1)) <> ''
		
			
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD2 = replace(E.DIAG_CD2,'.',''),
			    POA_IND2 =  'N' ,
				DIAG_CD_QUAL2 = 'BF'
			FROM OUTB_INST_HEADER E
			WHERE LTRIM(RTRIM(e.DIAG_CD2)) <> ''

				 
			
		   UPDATE OUTB_INST_HEADER
			SET DIAG_CD3 = replace(E.DIAG_CD3,'.',''),
			    POA_IND3 =  'N' ,
				DIAG_CD_QUAL3 = 'BF'
			FROM OUTB_INST_HEADER E
			WHERE LTRIM(RTRIM(e.DIAG_CD3)) <> ''

			
			
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD4 = replace(E.DIAG_CD4,'.',''),
			    POA_IND4 =  'N' ,
				DIAG_CD_QUAL4 = 'BF'
			FROM OUTB_INST_HEADER E
			WHERE LTRIM(RTRIM(e.DIAG_CD4))<> ''
			
			
				 
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD5 = replace(E.DIAG_CD5,'.',''),
			    POA_IND5 =  'N' ,
				DIAG_CD_QUAL5 = 'BF'
			FROM OUTB_INST_HEADER E
			WHERE LTRIM(RTRIM(e.DIAG_CD5))<> ''
				 
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD6 = replace(E.DIAG_CD6,'.',''),
			    POA_IND6 =  'N' ,
				DIAG_CD_QUAL6 = 'BF'
			FROM OUTB_INST_HEADER E
			WHERE LTRIM(RTRIM(e.DIAG_CD6))<> ''
			
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD7 = replace(E.DIAG_CD7,'.',''),
			    POA_IND7 =  'N' ,
				DIAG_CD_QUAL7 = 'BF'
			FROM OUTB_INST_HEADER E
			WHERE LTRIM(RTRIM(e.DIAG_CD7))<> ''
			
				
		
		    UPDATE OUTB_INST_HEADER
			SET DIAG_CD8 = replace(E.DIAG_CD8,'.',''),
			    POA_IND8 =  'N' ,
				DIAG_CD_QUAL8 = 'BF'
			FROM OUTB_INST_HEADER E
			WHERE LTRIM(RTRIM(e.DIAG_CD8))<> ''
			
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD9 = replace(E.DIAG_CD9,'.',''),
			    POA_IND9 =  'N' ,
				DIAG_CD_QUAL9 = 'BF'
			FROM OUTB_INST_HEADER E
			WHERE LTRIM(RTRIM(e.DIAG_CD9))<> ''
					 
		
  		    UPDATE OUTB_INST_HEADER
			SET DIAG_CD10 = replace(E.DIAG_CD10,'.',''),
			    POA_IND10 =  'N' ,
				DIAG_CD_QUAL10 = 'BF'
			FROM OUTB_INST_HEADER E
			WHERE LTRIM(RTRIM(e.DIAG_CD10))<> ''
			
			    ----------------------------------------
				-- ICD9
				----------------------------------------
				--ICD-10 Principal Diag Qual
				Update OUTB_INST_HEADER 
				SET PRINCIPAL_DIAG_QUAL = 'BK'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT < 20151001
                  AND LTRIM(RTRIM(H.INST_PRINCIPAL_DIAG_CD)) <> '' 

			   	--ICD-10 DIAG_CD_QUAL1
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL1 = 'BF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT < 20151001
                  AND LTRIM(RTRIM(DIAG_CD1)) <> '' 

				--ICD-10 DIAG_CD_QUAL2
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL2 = 'BF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT  < 20151001
				  AND LTRIM(RTRIM(DIAG_CD2)) <> '' 

				--ICD-10 DIAG_CD_QUAL3
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL3 = 'BF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT < 20151001
				   AND LTRIM(RTRIM(DIAG_CD3)) <> '' 

				--ICD-10 DIAG_CD_QUAL4
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL4 = 'BF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT < 20151001
				   AND LTRIM(RTRIM(DIAG_CD4)) <> '' 

				--ICD-10 DIAG_CD_QUAL5
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL5 = 'BF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT < 20151001
				   AND LTRIM(RTRIM(DIAG_CD5)) <> '' 

				--ICD-10 DIAG_CD_QUAL6
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL6 = 'BF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT < 20151001
				   AND LTRIM(RTRIM(DIAG_CD6)) <> '' 

				--ICD-10 DIAG_CD_QUAL7
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL7 = 'BF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT < 20151001
				   AND LTRIM(RTRIM(DIAG_CD7)) <> '' 

				--ICD-10 DIAG_CD_QUAL8
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL8 = 'BF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT < 20151001
				   AND LTRIM(RTRIM(DIAG_CD8)) <> '' 

				--ICD-10 DIAG_CD_QUAL9
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL9 = 'BF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT < 20151001
				   AND LTRIM(RTRIM(DIAG_CD9)) <> '' 

				--ICD-10 DIAG_CD_QUAL1
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL10 = 'BF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT < 20151001
				   AND LTRIM(RTRIM(DIAG_CD10)) <> '' 
		

                -----------------------------------------	
				--TETDM-438 ICD-10 Qualifier Revisions
				-----------------------------------------
				--ICD-10 Principal Diag Qual
				Update OUTB_INST_HEADER 
				SET PRINCIPAL_DIAG_QUAL = 'ABK'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
                  AND LTRIM(RTRIM(H.PRINCIPAL_DIAG_QUAL)) <> '' 

			   	--ICD-10 DIAG_CD_QUAL1
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL1 = 'ABF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
                  AND LTRIM(RTRIM(DIAG_CD1)) <> '' 

				--ICD-10 DIAG_CD_QUAL2
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL2 = 'ABF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
				  AND LTRIM(RTRIM(DIAG_CD2)) <> '' 

				--ICD-10 DIAG_CD_QUAL3
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL3 = 'ABF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
				   AND LTRIM(RTRIM(DIAG_CD3)) <> '' 

				--ICD-10 DIAG_CD_QUAL4
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL4 = 'ABF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
				   AND LTRIM(RTRIM(DIAG_CD4)) <> '' 

				--ICD-10 DIAG_CD_QUAL5
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL5 = 'ABF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
				   AND LTRIM(RTRIM(DIAG_CD5)) <> '' 

				--ICD-10 DIAG_CD_QUAL6
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL6 = 'ABF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
				   AND LTRIM(RTRIM(DIAG_CD6)) <> '' 

				--ICD-10 DIAG_CD_QUAL7
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL7 = 'ABF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
				   AND LTRIM(RTRIM(DIAG_CD7)) <> '' 

				--ICD-10 DIAG_CD_QUAL8
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL8 = 'ABF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
				   AND LTRIM(RTRIM(DIAG_CD8)) <> '' 

				--ICD-10 DIAG_CD_QUAL9
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL9 = 'ABF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
				   AND LTRIM(RTRIM(DIAG_CD9)) <> '' 

				--ICD-10 DIAG_CD_QUAL1
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL10 = 'ABF'
				FROM OUTB_INST_HEADER H
				WHERE H.STATE_BEGIN_DT >=20151001
				   AND LTRIM(RTRIM(DIAG_CD10)) <> '' 

				
			
			
		
		
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_INST_HEADER_RES
			
			SET  @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_HEADER)		 
												
----HRP_CLAIM_FILE Update Run Controls
				
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_CLAIM_INST_ENCOUNTER_DIAG'
							AND END_DT IS NULL
							
										
												 
										
						


