﻿


CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_REMOVE_DUP_ADJUSTMENTS]

AS

/***************************************************************************************************
** CREATE DATE: 05/2017
**
** AURTHOR: John Bartholomay
**
** DESCRIPTION: Procedure will Remove duplicates causing balancing issue, identified in
**              TETDM-1645
**
**             
**              
**             
**
**
Modification History
====================
Date                Who                        Description
----------------------------------------------------------------------------------------------------
10/20/2017     John Bartholomay     TETDM-1645 Remove Duplicate Adjusments causing balancing at WIPRO
03/15/2018     John Bartholomay     TETDM-1715 Remove Segments with Zero dollar(CO,OA,PI,PR)
03/21/2018     John Bartholoay      TETDM-1715 Updates for Zero dollar fields
-----------------------------------------------------------------------------------------------------*/


     -------------------------------------------
     --Init Run controls
	 ------------------------------------------
       INSERT INTO EXT_SYS_RUNLOG
                    (PROC_NAME
                    ,STEP
                    ,START_DT
                    ,END_DT
                    ,RUN_MINUTES
                    ,TOTAL_RECORDS
                    ,ENTRYDT
                    )
                    VALUES('pr_BUILD_OUTB_INST_REMOVE_DUP_ADJUSTMENTS'
                                 ,'2'
                                 ,GETDATE()
                                 ,NULL
                                 ,NULL
                                 ,0
                                 ,GETDATE()
                                 )

      ---------------------------------------------------
      -- IDENTIFY ADJUSTS THAT ARE THE SAME
      -- ONLY SEND ONE  SEGMENT CO AND OA
      ---------------------------------------------------
	  if OBJECT_ID ('tempdb..#TEMP_REMOVE_ADJUSTMENTS') <> 0
 	 drop table #TEMP_REMOVE_ADJUSTMENTS
	

	  SELECT B.CLAIM_ID,
	         B.CLAIM_LINE_NO, 
			 B.CLM_ADJ_REASON121,
			 B.CLM_ADJ_AMT111,
			 B.CLM_ADJ_GRP12,
			 B.CLM_ADJ_AMT121,
			 B.CLM_ADJ_AMT122,
			 B.CLM_ADJ_AMT123,
			 B.CLM_ADJ_AMT124,
			 B.CLM_ADJ_AMT125,
			 B.CLM_ADJ_AMT126,
			 B.CLM_ADJ_AMT131,
			 B.CLM_ADJ_AMT132,
			 B.CLM_ADJ_AMT133,
			 B.CLM_ADJ_AMT134,
			 B.CLM_ADJ_AMT135,
			 B.CLM_ADJ_AMT136,
			 B.CLM_ADJ_AMT141,
			 B.CLM_ADJ_AMT142,
			 B.CLM_ADJ_AMT143,
			 B.CLM_ADJ_AMT144,
			 B.CLM_ADJ_AMT145,
			 B.CLM_ADJ_AMT146,
			 B.CLM_ADJ_AMT151,
			 B.CLM_ADJ_AMT152,
			 B.CLM_ADJ_AMT153,
			 B.CLM_ADJ_AMT154,
			 B.CLM_ADJ_AMT155,
			 B.CLM_ADJ_AMT156
      INTO #TEMP_REMOVE_ADJUSTMENTS
      FROM dbo.OUTB_INST_DETAIL A, 
           dbo.OUTB_INST_DETAIL B
      WHERE A.CLAIM_ID = B.CLAIM_ID
        AND A.CLAIM_LINE_NO = B.CLAIM_LINE_NO
       -- AND A.CLM_ADJ_GRP111 = 'CO'
      --  AND B.CLM_ADJ_GRP12 = 'OA'
        AND A.CLM_ADJ_AMT111 IN (B.CLM_ADJ_AMT121,B.CLM_ADJ_AMT122,B.CLM_ADJ_AMT123,B.CLM_ADJ_AMT124,B.CLM_ADJ_AMT125,
			                     B.CLM_ADJ_AMT126,B.CLM_ADJ_AMT131,B.CLM_ADJ_AMT132,B.CLM_ADJ_AMT133,B.CLM_ADJ_AMT134,
			                     B.CLM_ADJ_AMT135,B.CLM_ADJ_AMT136,B.CLM_ADJ_AMT141,B.CLM_ADJ_AMT142,B.CLM_ADJ_AMT143,
			                     B.CLM_ADJ_AMT144,B.CLM_ADJ_AMT145,B.CLM_ADJ_AMT146,B.CLM_ADJ_AMT151,B.CLM_ADJ_AMT152,
			                     B.CLM_ADJ_AMT153,B.CLM_ADJ_AMT154,B.CLM_ADJ_AMT155,B.CLM_ADJ_AMT156)
       ORDER BY A.CLAIM_ID,A.CLAIM_LINE_NO
     
     --------------------------------------------------
     --REMOVE DUPLICATE ADJUSTMENT REASONS AND AMOUNTS
	 -- CO SEGMENT
     --------------------------------------------------
      UPDATE CD  
      SET  CLM_ADJ_REASON121 = '',
           CLM_ADJ_GRP12 = '',
	       CLM_ADJ_AMT121 = '',
		   CLM_ADJ_QTY121 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT121)
		
      UPDATE CD  
      SET  CLM_ADJ_REASON122 = '',
           CLM_ADJ_GRP12 = '',
	       CLM_ADJ_AMT122 = '',
		   CLM_ADJ_QTY122 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT122)
		
      UPDATE CD  
      SET  CLM_ADJ_REASON123 = '',
           CLM_ADJ_GRP12 = '',
	       CLM_ADJ_AMT123 = '',
		   CLM_ADJ_QTY123 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT123)

     UPDATE CD  
      SET  CLM_ADJ_REASON124 = '',
           CLM_ADJ_GRP12 = '',
	       CLM_ADJ_AMT124 = '',
		   CLM_ADJ_QTY124 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT124) 

      UPDATE CD  
      SET  CLM_ADJ_REASON125 = '',
           CLM_ADJ_GRP12 = '',
	       CLM_ADJ_AMT125 = '',
		   CLM_ADJ_QTY125 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT125)

       UPDATE CD  
      SET  CLM_ADJ_REASON126 = '',
           CLM_ADJ_GRP12 = '',
	       CLM_ADJ_AMT126 = '',
		   CLM_ADJ_QTY126 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT126)

      UPDATE CD  
      SET  CLM_ADJ_REASON131 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT131 = '',
		   CLM_ADJ_QTY131 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT131)
		AND CD.CLM_ADJ_GRP13 <> 'PR'
      
	  UPDATE CD  
      SET  CLM_ADJ_REASON132 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT132 = '',
		   CLM_ADJ_QTY132 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT132)
		AND CD.CLM_ADJ_GRP13 <> 'PR'

	  UPDATE CD  
      SET  CLM_ADJ_REASON133 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT133 = '',
		   CLM_ADJ_QTY133 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT133)
		AND CD.CLM_ADJ_GRP13 <> 'PR'

	  UPDATE CD  
      SET  CLM_ADJ_REASON134 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT134 = '',
		   CLM_ADJ_QTY134 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT134)
		AND CD.CLM_ADJ_GRP13 <> 'PR'

	  UPDATE CD  
      SET  CLM_ADJ_REASON135 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT135 = '',
		   CLM_ADJ_QTY135 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT135)	
		AND CD.CLM_ADJ_GRP13 <> 'PR'
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON136 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT136 = '',
		   CLM_ADJ_QTY136 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT136)
		AND CD.CLM_ADJ_GRP13 <> 'PR'
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON141 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT141 = '',
		   CLM_ADJ_QTY141 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT141)	
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON142 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT142 = '',
		   CLM_ADJ_QTY142 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT142)
		
	 UPDATE CD  
      SET  CLM_ADJ_REASON143 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT143 = '',
		   CLM_ADJ_QTY143 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT143)
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON144 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT144 = '',
		   CLM_ADJ_QTY144 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT144)	
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON145 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT145 = '',
		   CLM_ADJ_QTY145 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT145)
						
	  UPDATE CD  
      SET  CLM_ADJ_REASON146 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT146 = '',
		   CLM_ADJ_QTY146 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT146)	
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON151 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT151 = '',
		   CLM_ADJ_QTY151 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT151)	
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON152 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT152 = '',
		   CLM_ADJ_QTY152 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT152)
		
										     
      UPDATE CD  
      SET  CLM_ADJ_REASON153 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT153 = '',
		   CLM_ADJ_QTY153 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT153)
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON154 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT154 = '',
		   CLM_ADJ_QTY154 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT154)
		
					
	  UPDATE CD  
      SET  CLM_ADJ_REASON155 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT155 = '',
		   CLM_ADJ_QTY155 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT155)			                     
        
      UPDATE CD  
      SET  CLM_ADJ_REASON156 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT156 = '',
		   CLM_ADJ_QTY156 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP111 = 'CO'
        AND CD.CLM_ADJ_AMT111 IN (T.CLM_ADJ_AMT156)	
       
      -------------------------------------------------
	  -- OA SEGMENT
	  -------------------------------------------------
	  UPDATE CD  
      SET  CLM_ADJ_REASON131 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT131 = '',
		   CLM_ADJ_QTY131 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT131)
      
	  UPDATE CD  
      SET  CLM_ADJ_REASON132 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT132 = '',
		   CLM_ADJ_QTY132 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT132)

	  UPDATE CD  
      SET  CLM_ADJ_REASON133 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT133 = '',
		   CLM_ADJ_QTY133 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT133)

	  UPDATE CD  
      SET  CLM_ADJ_REASON134 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT134 = '',
		   CLM_ADJ_QTY134 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT134)

	  UPDATE CD  
      SET  CLM_ADJ_REASON135 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT135 = '',
		   CLM_ADJ_QTY135 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT135)	
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON136 = '',
           CLM_ADJ_GRP13 = '',
	       CLM_ADJ_AMT136 = '',
		   CLM_ADJ_QTY136 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT136)
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON141 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT141 = '',
		   CLM_ADJ_QTY141 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT141)	
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON142 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT142 = '',
		   CLM_ADJ_QTY142 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT142)
		
	 UPDATE CD  
      SET  CLM_ADJ_REASON143 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT143 = '',
		   CLM_ADJ_QTY143 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT143)
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON144 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT144 = '',
		   CLM_ADJ_QTY144 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT144)	
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON145 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT145 = '',
		   CLM_ADJ_QTY145 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT145)
						
	  UPDATE CD  
      SET  CLM_ADJ_REASON146 = '',
           CLM_ADJ_GRP14 = '',
	       CLM_ADJ_AMT146 = '',
		   CLM_ADJ_QTY146 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT146)	
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON151 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT151 = '',
		   CLM_ADJ_QTY151 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT151)	
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON152 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT152 = '',
		   CLM_ADJ_QTY152 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT152)
		
										     
      UPDATE CD  
      SET  CLM_ADJ_REASON153 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT153 = '',
		   CLM_ADJ_QTY153 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT153)
		
	  UPDATE CD  
      SET  CLM_ADJ_REASON154 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT154 = '',
		   CLM_ADJ_QTY154 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT154)
		
					
	  UPDATE CD  
      SET  CLM_ADJ_REASON155 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT155 = '',
		   CLM_ADJ_QTY155 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT155)			                     
        
      UPDATE CD  
      SET  CLM_ADJ_REASON156 = '',
           CLM_ADJ_GRP15 = '',
	       CLM_ADJ_AMT156 = '',
		   CLM_ADJ_QTY156 = ''
      FROM dbo.OUTB_INST_DETAIL CD,
           #TEMP_REMOVE_ADJUSTMENTS T
      WHERE CD.CLAIM_ID = T.CLAIM_ID
        AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO
        AND CD.CLM_ADJ_GRP12 = 'OA'
        AND CD.CLM_ADJ_AMT121 IN (T.CLM_ADJ_AMT156)	
       

      --------------------------------------------
      --     Update Run Controls
      --------------------------------------------
       DECLARE @TOTAL_RECORDS INT
                    
       SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #TEMP_REMOVE_ADJUSTMENTS)
                                               
       
             UPDATE 
                    EXT_SYS_RUNLOG
             SET END_DT = GETDATE()     
                    ,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
                    ,TOTAL_RECORDS = @TOTAL_RECORDS
                    ,ENTRYDT = GETDATE()
             WHERE 
                    PROC_NAME = 'pr_BUILD_OUTB_INST_REMOVE_DUP_ADJUSTMENTS' 
                    AND END_DT IS NULL


