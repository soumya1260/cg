﻿CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_OCCURANCECODE]
--(@BEGIN_DOS CHAR(8), @END_DOS CHAR(8)  )
AS
/***************************************************************************************************
** CREATE DATE: 06/2013
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM OCCURANCE
**				CODE INFORMATION USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.2. 
**				THE SOURCE TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES.  
**              
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
2013-10-31		Loyal Ricks		Revise code to adherre to MDQO SQL Standards.							 
*****************************************************************************************************/			
DECLARE

@TOTAL_RECORDS INT

	--HRP_CLAIM_FILE Run controls
	INSERT INTO EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT
			)
			VALUES('pr_BUILD_INST_OCCURANCECODE'
					,'8'
					,GETDATE()
					,null
					,' '
					,0
					,GETDATE()
					)
			-----C_OCC CURSOR
			----occurance code updates 
			
				IF OBJECT_ID('TEMPDB..#tmp_occ_cd') <> 0
					DROP TABLE #tmp_occ_cd
					
					create table #tmp_occ_cd
					(claimid varchar(20)
						,occurancecode varchar(20)
						,occurancefromdatekey int
						,occurancetodatekey int
						,occ_seq INT
					)
	                   
	        BEGIN TRANSACTION 
				INSERT INTO #tmp_occ_cd           
				SELECT 
						ClaimID ,
						OccuranceCode ,
						OccuranceFromDateKey ,
						OccuranceToDateKey ,
						 ROW_NUMBER() OVER ( PARTITION BY ClaimID ORDER BY CLAIMID, OCCURANCEFROMDATEKEY, OCCURANCECODE ) AS 'OCC_SEQ'
				FROM    EDPS_Data.dbo.claimoccurancedim
				WHERE   claimid IN ( SELECT claim_id
									 FROM   OUTB_INST_HEADER ) 
				 order BY ClaimID ,
						OccuranceCode ,
						OccuranceFromDateKey ,
						OccuranceToDateKey  
						 IF @@ERROR <> 0 
							BEGIN 
								ROLLBACK 
							END
			COMMIT           
           
            


			UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_11 = OCCURANCECODE
					,OCC_SPAN_BEGIN_DT_11 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_11 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 1
				
				
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_12 = OCCURANCECODE
					,OCC_SPAN_BEGIN_DT_12 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_12 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 2
				
				
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_13 = OccuranceCode
					,OCC_SPAN_BEGIN_DT_13 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_13 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 3
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_14 = OccuranceCode
					,OCC_SPAN_BEGIN_DT_14 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_14 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 4
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_15 = OccuranceCode
					,OCC_SPAN_BEGIN_DT_15 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_15 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 5
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_16 = OccuranceCode
					,OCC_SPAN_BEGIN_DT_16 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_16 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 6
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_17 = OccuranceCode
					,OCC_SPAN_BEGIN_DT_17 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_17 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 7
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_18 = OccuranceCode
					,OCC_SPAN_BEGIN_DT_18 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_18 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 8
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_19 = OccuranceCode
					,OCC_SPAN_BEGIN_DT_19 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_19 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 9
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_110 = OccuranceCode
					,OCC_SPAN_BEGIN_DT_110 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_110 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 10
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_111 = OccuranceCode
					,OCC_SPAN_BEGIN_DT_111 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_111 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 11
				
				UPDATE OUTB_INST_HEADER
				SET OCC_SPAN_CD_112 = OccuranceCode
					,OCC_SPAN_BEGIN_DT_112 = OccuranceFromDateKey
					,OCC_SPAN_END_DT_112 = OccuranceToDateKey
				FROM OUTB_INST_HEADER CI
				join #tmp_occ_cd T
				on  CI.CLAIM_ID = T.ClaimID
				WHERE T.OCC_SEQ = 12
				
				
				
				--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #tmp_occ_cd)
		----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_INST_OCCURANCECODE'
								AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
