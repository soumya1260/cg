﻿











CREATE PROCEDURE [dbo].[BUILD_OUTB_INST_INSERT_CCCR]

AS
/************************************************************************************************************************
** CREATE DATE: 08/10/2017
**
** AUTHOR: Henry Faust
**
** DESCRIPTION: Populates the table OUTB_Prof_CCCR. The table is used to eliminate multiple DX codes
**              
**              
**
**
Modification History
====================
Date			Who				Description
--------------------------------------------------------------------------------------------------------------------------
 08/10/2017		Henry Faust   This procedure populates the table OUTB_PROF_CCCR with only the unique Diagnosis codes.
                              Primary Diag Code row number 1, the rest are offset by 1.     
 03/04/2019     Henry Faust	  TETDM-1879 claimdiagnosisdim table has changed, so need to add DiagnosisTypeCodeDesc	
 12/05/2019     Henry Faust   TETDM-2184 add DX code when sequence >30 (47 max)						
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2017-08-10		Henry Faust TETDM 1501		WIPRO Implementation																							    
2019-12-05      Henry Faust     TETDM-2184 get DX codes when sequence is >30 (47 max)	
                                 also removed a bunch of commented out code.	
*****************************************************************************************************/	
DECLARE
			@TOTAL_RECORDS INT

INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_INST_INSERT_CCCR'
				,'4'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)

--------------
--start new logic
--------------

	IF OBJECT_ID('TEMPDB..#CLMICDPS') <> 0
					DROP TABLE #CLMICDPS

	create table  #CLMICDPS
	(claimid varchar(20),
	  dgcd VARCHAR(10),
	  sequence varchar(2),
	  POAIND varchar(1))
   CREATE CLUSTERED INDEX cmsidcps_idx ON #CLMICDPS (claimid, sequence)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			  JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 1
			 WHERE cdd.DIAGNOSIStypeCODE IN ('P')  
--			 WHERE cdd.DIAGNOSIStypeCODE IN ('P','S')  
)x

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 1  
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 2  
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 3          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 4          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 5          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 6          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 7          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 8          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 9          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 10          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)
--------------
-- 11 - 20
--------------
INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 11
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 12  
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 13          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 14          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 15          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 16          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 17          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 18          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 19          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 20          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')   AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)
--------------
-- 21 - 30
--------------
INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 21
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')   AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 22  
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 23          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 24          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 25          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')   AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 26          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')   AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 27          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 28          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')   AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary') 
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 29          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 30          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

------------------------------------------31-40 ----------------------------------------------

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 31          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 32          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 33          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 34          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 35          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 36          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 37          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 37          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 38          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 39          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 40          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

-------------------------------------------------------------- 41-47--------------------------------------------------


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 41          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 42          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 43          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 44         
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 45          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)

INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 46          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)


INSERT INTO #CLMICDPS
        ( claimid, dgcd, sequence, POAIND)
SELECT x.CLAIMID , x.dgcd , x.SEQUENCE , x.POAIND
FROM ( 		
  SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id AND cdd.sequence = 47          
			 WHERE cdd.DIAGNOSIStypeCODE IN ('S')  AND cdd.DiagnosisTypeCodeDesc IN ( 'Secondary')  
)x
WHERE NOT EXISTS (SELECT * FROM #CLMICDPS a WHERE a.claimid = x.CLAIMID AND x.dgcd = a.dgcd)




-----
--insert into table
-----


TRUNCATE TABLE dbo.OUTB_INST_cccr

INSERT INTO dbo.OUTB_INST_cccr
        ( Rownum,
  claim_id , dgcd, POAIND
        )

		SELECT 
		  ROW_NUMBER() OVER(PARTITION BY claimid  ORDER BY claimid, sequence) AS Rownum,
		  claimid ,  dgcd,  POAIND
		FROM  
		(
		SELECT TOP 100 PERCENT claimid ,sequence, dgcd,  POAIND FROM #CLMICDPS
		 --group BY claimid, sequence, dgcd, poaind
		 ORDER BY claimid, sequence
		)q

--SELECT * FROM  dbo.OUTB_INST_cccr
--ORDER BY CLAIM_ID, ROWNUM


--SELECT 
--  ROW_NUMBER() OVER(PARTITION BY claimid ORDER BY claimid  ) AS Rownum,
--  claimid , dgcd,  POAIND
--FROM  
--(
--	SELECT distinct claimid,  dgcd ,   POAIND
--	FROM(
--			SELECT CLAIMID , DIAGNOSISCODE AS dgcd , cdd.SEQUENCE ,POAIND
--			 FROM [EDPS_Data].[dbo].[CLAIMDIAGNOSISDIM] cdd
--			 JOIN dbo.OUTB_INST_HEADER oih ON cdd.CLAIMID = oih.claim_id    
--        )z
--)y --end of Row Number Loop	


--------------
--end new logic
--------------

	
			SET  @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_HEADER)		 
						
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_INST_INSERT_CCCR'
							AND END_DT IS NULL						



















