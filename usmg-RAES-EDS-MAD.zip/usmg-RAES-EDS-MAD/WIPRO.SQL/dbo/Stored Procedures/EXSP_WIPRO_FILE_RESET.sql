﻿
CREATE PROCEDURE [dbo].[EXSP_WIPRO_FILE_RESET]
AS 
/**********************************************************************************************************
CREATE DATE: 09/24/2018

AUTHOR:			Scott Waller

DESCRIPTION:	This procedure is used to Reset a Claim Submission File.  It can reset a single file 
				completely, or a single file excluding a specific list of claimid's.
				The FileID and claimid's are provided by the BA team.
				Currently, they request the files they need reset by updating JIRA ticket TETDM-1252

Tables used:	WIPRO_FileReset_FileID
				WIPRO_FileReset_ClaimsToExclude
				WIPRO_FileReset_FileID_Archive
				WIPRO_FileReset_ClaimsToExclude_Archive
				WIPRO_FileReset_Notifications

Rules / How it works:
				Insert a single row for each FileID to be reset into the WIPRO_FileReset_FileID
				
				To reset a complete file, either insert a single row for the fileid with a claimid = 'ALL'
				into the WIPRO_FileReset_ClaimsToExclude table,  or don't insert any rows in the
				WIPRO_FileReset_ClaimsToExclude table.

				To exclude specific claimid's for a fileid, insert a row for each fileid & claimid into 
				the WIPRO_FileReset_ClaimsToExclude table.

Insert a row into the WIPRO_FileReset_Notifications table for each file and whether the reset was successful
or not.

Insert a row into EXT_SYS_RUNLOG table for each file and whether the reset was successful
or not.

Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------


************************************************************************************************************/
BEGIN
	SET NOCOUNT ON 
                     
	DECLARE @notificationstr		varchar(200),
			@cFILEID				varchar(50),
			@cEXCLUDECLAIMS			char(3),
			@TOTAL_RECORDS			int,
			@return_value			int,
			@RESET_DATE				datetime;

	INSERT INTO EXT_SYS_RUNLOG  
				(PROC_NAME  
				,STEP  
				,START_DT  
				,END_DT  
				,RUN_MINUTES  
				,TOTAL_RECORDS  
				,ENTRYDT  )  
		VALUES('EXSP_WIPRO_FILE_RESET' 
				,'1'  
				,GETDATE()  
				,NULL  
				,NULL  
				,0  
				,GETDATE()  )  

	TRUNCATE TABLE WIPRO_FileReset_Notifications
	
	SET @TOTAL_RECORDS  = (SELECT COUNT(*) FROM WIPRO_FileReset_FileID)  
	SET	@reset_date		= GETDATE()

	IF	@TOTAL_RECORDS = 0	-- verify there are fileid's in the table
	BEGIN
		SET	@notificationstr = 'There are no Files in the WIPRO_FileReset_FileID table to reset'
		INSERT INTO WIPRO_FileReset_Notifications
			(FILEID, RESET_STATUS)
		VALUES
			('none', @notificationstr)

		UPDATE EXT_SYS_RUNLOG  
		SET END_DT = GETDATE()	  
			,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
			,TOTAL_RECORDS = @TOTAL_RECORDS  
			,ENTRYDT = GETDATE()  
			WHERE	PROC_NAME = 'EXSP_WIPRO_FILE_RESET'  
			AND		END_DT is null  

		RETURN
	END

	DECLARE db_cursor CURSOR FOR
		SELECT	FILEID, EXCLUDECLAIMS
		FROM	WIPRO_FileReset_FileID
		ORDER BY FILEID

	OPEN db_cursor
	
	FETCH NEXT FROM db_CURSOR INTO @cFILEID, @cEXCLUDECLAIMS

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @cFILEID = RTRIM(@cFILEID)

		IF ((@cEXCLUDECLAIMS = '') OR (@cEXCLUDECLAIMS = 'ALL') OR (@cEXCLUDECLAIMS IS NULL))
			BEGIN
				EXEC	@return_value = dbo.EXSP_WIPRO_BAD_FILE_v2
					@FILEID			= @cFILEID,
					@EXCLUDE_ID		= N'ALL'
			END
		ELSE
			BEGIN
				EXEC	@return_value = dbo.EXSP_WIPRO_BAD_FILE_v2
					@FILEID			= @cFILEID,
					@EXCLUDE_ID		= N'EXCLUDE CLAIMS'
			END

		IF ((@cEXCLUDECLAIMS = '') OR (@cEXCLUDECLAIMS = 'ALL') OR (@cEXCLUDECLAIMS IS NULL))
			SET	@notificationstr = 'File reset: ' + @cFILEID + ' - all claims'
		ELSE
			SET	@notificationstr = 'File reset: ' + @cFILEID + ' - some claims excluded'

		INSERT INTO WIPRO_FileReset_Notifications
			(FILEID, RESET_STATUS)
		VALUES
			(@cFILEID, @notificationstr)

		FETCH NEXT FROM db_cursor INTO @cFILEID, @cEXCLUDECLAIMS
	END

	CLOSE		db_cursor  
	DEALLOCATE	db_cursor 

	INSERT INTO WIPRO_FileReset_FileID_Archive
	(FILEID, EXCLUDECLAIMS, RESET_DATE)
	SELECT	FILEID, EXCLUDECLAIMS, @RESET_DATE
	FROM	WIPRO_FileReset_FileID

	INSERT INTO	WIPRO_FileReset_ClaimsToExclude_Archive
	(FILEID, CLAIM_ID, RESET_DATE)
	SELECT	FILEID, CLAIM_ID, @RESET_DATE
	FROM	WIPRO_FileReset_ClaimsToExclude

	INSERT INTO	WIPRO_FileReset_Notifications_Archive
	(FILEID, RESET_STATUS, RESET_DATE)
	SELECT	FILEID, RESET_STATUS, @RESET_DATE
	FROM	WIPRO_FileReset_Notifications


	TRUNCATE TABLE	WIPRO_FileReset_FileID
	TRUNCATE TABLE	WIPRO_FileReset_ClaimsToExclude

-- Do not Truncate the WIPRO_FileReset_Notifications table because the SSIS package will create 
-- an email notification with the data in that table.  It will take care of Truncating it.

	UPDATE EXT_SYS_RUNLOG  
	SET END_DT = GETDATE()	  
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
		,TOTAL_RECORDS = @TOTAL_RECORDS  
		,ENTRYDT = GETDATE()  
		WHERE	PROC_NAME = 'EXSP_WIPRO_FILE_RESET'  
		AND		END_DT is null  

END

