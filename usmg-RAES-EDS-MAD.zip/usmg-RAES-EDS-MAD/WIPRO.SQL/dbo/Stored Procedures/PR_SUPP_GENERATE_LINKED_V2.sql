﻿CREATE PROCEDURE [dbo].[PR_SUPP_GENERATE_LINKED_v2]
/******************************************
Date			Author					Notes
07/06/2024		Subhash Acharya			Initital Creation


Select * FROM   [WIPRO].[dbo].[Supplemental_INPUT]

Select * FROM   [WIPRO].[dbo].[Supplemental_OUTPUT]

select *
FROM [WIPRO].[dbo].[Supplemental_INPUT]
WHERE STATUS_CODE IN ( '008', '009' )
      AND Submission_Indicator = '0'


select * from [WIPRO].[dbo].[Service_Line_Dup_Processing] 

update [EDS_Adjustments_Ash].dbo.SVS_LINE_RELOAD
set date_of_service = convert(date,date_of_service)

select convert(date,date_of_service),* from [EDS_Adjustments_Ash].dbo.SVS_LINE_RELOAD
select * from [EDS_Adjustments_Ash].dbo.testbed_reload 

Sample Innvocation: EXEC [dbo].[PR_SUPP_GENERATE_LINKED_v2]
********************************************/

AS 

	SET NOCOUNT ON;



BEGIN 

    UPDATE [WIPRO].[dbo].[Supplemental_INPUT]
    SET STATUS_CODE = '222',
        Status_desc = 'Data_Error_Missing_CLM_ICN',
        Submission_Indicator = '1'
    WHERE ISNULL(WIPRO_CLAIM_NO, '') = ''
          OR ISNULL(CHS_CLM_EDPS, '') = ''
          OR ISNULL(CMS_ICN, '') = ''
		  
	;
    WITH cte
    AS (SELECT Hic_No,
               From_Date,
               Thru_Date,
               Source_System_Number,
               Dx_Code,
               STATUS_CODE,
               Status_desc,
               ROW_NUMBER() OVER (PARTITION BY Hic_No,
                                               From_Date,
                                               Thru_Date, /*, source_system_number*/
                                               Dx_Code
                                  ORDER BY Source_System_Number
                                 ) AS RwNum
        FROM [WIPRO].[dbo].[Supplemental_INPUT] A
        WHERE A.STATUS_CODE IN ( '008', '009' ,'010')
              AND A.Submission_Indicator = '0')
    UPDATE cte
    SET STATUS_CODE = '222',
        Status_desc = 'Data_Error_Sub_Diag_Dup'
    WHERE cte.RwNum > 1;


/*
IF OBJECT_ID('TEMPDB..##SUPP_LINKED_READy') IS NOT NULL
    DROP TABLE ##SUPP_LINKED_READy
SELECT *
INTO ##SUPP_LINKED_READy
FROM [WIPRO].[dbo].[Supplemental_INPUT]
WHERE STATUS_CODE IN ( '008', '009','010' )
      AND Submission_Indicator = '0'
*/

/*
UPDATE ##SUPP_LINKED_READy
SET STATUS_CODE = '222',
    Status_desc = 'Data_Error_Missing_CLM_ICN',
    Submission_Indicator = '1'
WHERE ISNULL(WIPRO_CLAIM_NO, '') = ''
      OR ISNULL(CHS_CLM_EDPS, '') = ''
      OR ISNULL(CMS_ICN, '') = ''


;WITH cte
AS (SELECT Hic_No,
           From_Date,
           Thru_Date,
           Source_System_Number,
           Dx_Code,
           STATUS_CODE,
           Status_desc,
           ROW_NUMBER() OVER (PARTITION BY Hic_No,
                                           From_Date,
                                           Thru_Date /*, source_system_number*/,
                                           Dx_Code
                              ORDER BY Source_System_Number
                             ) AS RwNum
    FROM ##SUPP_LINKED_READy A
    WHERE A.STATUS_CODE IN ( '008', '009' ,'010')
          AND A.Submission_Indicator = '0')
UPDATE cte
SET STATUS_CODE = '222',
    Status_desc = 'Data_Error_Sub_Diag_Dup'
--SELECT * FROM cte
WHERE cte.RwNum > 1
*/

/**************when to do*****************************/
--set rowcount 0

UPDATE [WIPRO].[dbo].[Supplemental_INPUT]
SET STATUS_CODE = '999',
    Status_desc = 'Linked_SUB'
--SELECT COUNT(*) FROM ##SUPP_LINKED_READy 
WHERE STATUS_CODE IN ( '008', '009','010' )
      AND Submission_Indicator = '0'


--UPDATE ##SUPP_LINKED_READy
--SET STATUS_CODE = '888',
--    Status_desc = 'Linked_SUB'
----SELECT COUNT(*) FROM ##SUPP_LINKED_READy 
--WHERE STATUS_CODE IN ( '008', '009','010' )
--      AND Submission_Indicator = '0'

/**************when to do*****************************/


--get date ready for output
--Step 1
IF OBJECT_ID('TEMPDB..#Supplemental_OUTPUT') IS NOT NULL
    DROP TABLE #Supplemental_OUTPUT
SELECT --top 10000
'' as ENC_ID					--N/A : Defauled to Blank
,cast(NULL as INT) as RECEIVER_ID				--N/A : Defauled to Blank
,case when provider_type = 'P' Then 'PRO' 	
	 when provider_type in  ('I','N','O') Then 'INS'	END AS 	ENC_TYPE	--"IF [Supplemental_INPUT].provider_type = 'P' Then Populate ENC_TYPE = 'PROF' 						--IF [Supplemental_INPUT].provider_type = I,N,O =Then Populate ENC_TYPE = 'INST'"
,1 as CLAIM_IND				--Default to 1
,Hic_No HIC_NBR					--[Supplemental_INPUT].Hic_No
,Plan_No CMS_CONTRACT_NO			--[Supplemental_INPUT].Plan_No
,Provider_Type RAPS_PROV_TYPE			--[Supplemental_INPUT].Provider_Type
,J_From_Date_VARCHAR From_Date				--[Supplemental_INPUT].J_From_Date_VARCHAR
,J_Thru_Date_VARCHAR Thru_Date				--[Supplemental_INPUT].J_Thru_Date_VARCHAR
,Concat (member_id,'-',Source_system,'-',Source_system_number) RAPS_PCN				--Concatnate ([Supplemental_INPUT].member_id,"-",Source_system,"-",Source_system_number)
,WIPRO_CLAIM_NO CLAIM_NO				--[Supplemental_INPUT].WIPRO_CLAIM_NO
,CHS_CLM_EDPS CHS_CLM_EDPS			--[Supplemental_INPUT].CHS_CLM_EDPS
,CMS_ICN ICN_NO					--[Supplemental_INPUT].CMS_ICN
,'' NPI_EDPS				--Default to blank
,'' NPI_SUPP				--Default to blank
,Source_System_Number HS_CLAIM_NBR			--[Supplemental_INPUT].Source_System_Number
,1 FREQ_CD					--Default to 1
,'A' [ACTION]					--default to 'Add'
,'10' icd_version				--Default to 10
,'' DIAG01_CODE_QUAL		--
,dx_code DIAG01_CODE				--[Supplemental_INPUT].dx_code
,'' DIAG02_CODE_QUAL		--
,'' DIAG02_CODE				--
,'' DIAG03_CODE_QUAL		--
,'' DIAG03_CODE				--
,'' DIAG04_CODE_QUAL		--
,'' DIAG04_CODE				--
,'' DIAG05_CODE_QUAL		--
,'' DIAG05_CODE				--
,'' DIAG06_CODE_QUAL		--
,'' DIAG06_CODE				--
,'' DIAG07_CODE_QUAL		--
,'' DIAG07_CODE				--
,'' DIAG08_CODE_QUAL		--
,'' DIAG08_CODE				--
,'' DIAG09_CODE_QUAL		--
,'' DIAG09_CODE				--
,'' DIAG10_CODE_QUAL		--
,'' DIAG10_CODE				--
,'' DIAG11_CODE_QUAL		--
,'' DIAG11_CODE				--
,'' DIAG12_CODE_QUAL		--
,'' DIAG12_CODE				--
,'' DIAG13_CODE_QUAL		--
,'' DIAG13_CODE				--
,'' DIAG14_CODE_QUAL		--
,'' DIAG14_CODE				--
,'' DIAG15_CODE_QUAL		--
,'' DIAG15_CODE				--
,'' DIAG16_CODE_QUAL		--
,'' DIAG16_CODE				--
,'' DIAG17_CODE_QUAL		--
,'' DIAG17_CODE				--
,'' DIAG18_CODE_QUAL		--
,'' DIAG18_CODE				--
,'' DIAG19_CODE_QUAL		--
,'' DIAG19_CODE				--
,'' DIAG20_CODE_QUAL		--
,'' DIAG20_CODE				--
,'' DIAG21_CODE_QUAL		--
,'' DIAG21_CODE				--
,'' DIAG22_CODE_QUAL		--
,'' DIAG22_CODE				--
,'' DIAG23_CODE_QUAL		--
,'' DIAG23_CODE				--
,'' DIAG24_CODE_QUAL		--
,'' DIAG24_CODE				--
,'' BILLPROV_LAST_NAME		--Default to blank
,'' BILLPROV_ORG_NAME		--Default to blank
,'' BILLINGPROV_NPI			--Default to blank
,'' BILLINGPROV_GRP_NPI		--Default to blank
,'' BILLINGPROV_ADDRESS		--Default to blank
,'' BILLINGPROV_CITY		--Default to blank
,'' BILLINGPROV_STATE		--Default to blank
,'' BILLINGPROV_ZIPCODE		--Default to blank
,'' BILLINGPROV_TAX_ID		--Default to blank
,'' MEMBER_LAST_NAME		--Default to blank
,'' MEMBER_FIRST_NAME		--Default to blank
,'' MEMBER_MIDDLE_NAME		--Default to blank
,'' MEMBER_NAME_SUFX		--Default to blank
,'' MEMBER_ADDRESS			--Default to blank
,'' MEMBER_CITY				--Default to blank
,'' MEMBER_STATE			--Default to blank
,'' MEMBER_ZIPCODE			--Default to blank
,'' MEMBER_DOB				--Default to blank
,'' MEMBER_GENDER			--Default to blank
,Source_System_Number PLAN_CLAIM_NO			--[Supplemental_INPUT].Source_System_Number
,'' PLACE_OF_SERVICE		--Default to blank
,'LINKED_SUB' Supp_Type				--Default to 'LINKED_SUB'
,Source_System [Data_Source]				--[Supplemental_INPUT].Source_System
,'999' STATUS_CODE				--Defaul to '999'
,'LINKED_SUBMITTED' Status_desc				--Default to 'LINKED_SUBMITTED'
,getdate() Process_Date			--Get Date
,convert(varchar(250), NULL) [file_name]				--Refer to filename logic tab  --Subhash
,'' WIPRO_CLAIM_ID					--Default to blank , will be populated during response
,'' CMS_ICN							--Default to blank , will be populated during response
,'' CLM_ACK							--Default to blank , will be populated during response
,'' CLM_STATUS						--Default to blank , will be populated during response
,'' RSP_277							--Default to blank , will be populated during response
,'' RSP_999							--Default to blank , will be populated during response
,'' RSP_MAO002						--Default to blank , will be populated during response
,'' RSP_MAO004						--Default to blank , will be populated during response
,'' Response_Status_Reserverd_1		--Default to blank , will be populated during response
,'' Response_Status_Reserverd_2		--Default to blank , will be populated during response
,'' Reserved_3						--Default to blank , will be populated during response
,Convert(CHAR(8),getdate()+1,112) Cycle	--YYYYMMDD
,getdate() Generation_Timestamp	
--,CONCAT('L',replace(FORMAT (getdate(), 'MM-dd-yy'),'-',''),1,0001,) Edifecs_Claim_Id				--Refer to edifecsID logic tab
,cast('' as varchar(20)) Edifecs_Claim_Id		
 
INTO #Supplemental_OUTPUT
FROM [WIPRO].[dbo].[Supplemental_INPUT] a
--FROM ##SUPP_LINKED_READy A
WHERE A.STATUS_CODE IN ( '999' )
 AND Status_desc = 'Linked_SUB'
 

 --17
 ;
 with cte as
 (
select 
	ROW_NUMBER() over (order by cycle) as rn,
	*
from #Supplemental_OUTPUT
)
,cte1 as
(
select 
--,case when enc_type = 'P' and cms_contract_no <> 'H8423'
 CONCAT('L', left(REPLACE(CONVERT (CHAR(10), getdate(), 101),'/',''),6), right(replicate('0',4)+left(replace([Data_Source],'_','0'),4),4)
  ,ceiling(rn/99999.0) --99999
 ,right(replicate('0',5)+convert(varchar(10),rn),5))  as Edifecs_Claim_Id1
 ,ceiling(rn/99999.0) as batchnumber --99999
,*
from cte
)
--select * from cte1

update cte1
set Edifecs_Claim_Id = Edifecs_Claim_Id1
, receiver_id = batchnumber
,[file_name] = case when ENC_TYPE = 'PRO' and CMS_CONTRACT_NO <> 'H0354' THEN  CONCAT('HSCE.PROD.MAO.99.P',Cycle,'0000',receiver_id) 
			when ENC_TYPE = 'PRO' and CMS_CONTRACT_NO = 'H0354' THEN  CONCAT('HSCE.PROD.MAO.AZ.99.P',Cycle,'0000',receiver_id) 
			when ENC_TYPE = 'INS' and CMS_CONTRACT_NO <> 'H0354' THEN  CONCAT('HSCE.PROD.MAO.99.I',Cycle,'0000',receiver_id) 
			when ENC_TYPE = 'INS' and CMS_CONTRACT_NO = 'H0354' THEN  CONCAT('HSCE.PROD.MAO.AZ.99.I',Cycle,'0000',receiver_id) 
end

--truncate table  [dbo].[Supplemental_OUTPUT]
insert into [dbo].[Supplemental_OUTPUT]
(
ENC_ID	,RECEIVER_ID,	ENC_TYPE	,CLAIM_IND	,HIC_NBR	,CMS_CONTRACT_NO	,RAPS_PROV_TYPE,	From_Date	
,Thru_Date	,RAPS_PCN	,CLAIM_NO	,CHS_CLM_EDPS	,ICN_NO	,NPI_EDPS	,NPI_SUPP	,HS_CLAIM_NBR	
,FREQ_CD	,[ACTION]	,icd_version	,DIAG01_CODE_QUAL	,DIAG01_CODE		,DIAG02_CODE_QUAL	,DIAG02_CODE		,DIAG03_CODE_QUAL	
,DIAG03_CODE	,DIAG04_CODE_QUAL	,DIAG04_CODE	,DIAG05_CODE_QUAL	,DIAG05_CODE	    ,DIAG06_CODE_QUAL	,DIAG06_CODE	,DIAG07_CODE_QUAL	
,DIAG07_CODE	,DIAG08_CODE_QUAL	,DIAG08_CODE	,DIAG09_CODE_QUAL	,DIAG09_CODE	    ,DIAG10_CODE_QUAL	,DIAG10_CODE	,DIAG11_CODE_QUAL	
,DIAG11_CODE	,DIAG12_CODE_QUAL	,DIAG12_CODE	,DIAG13_CODE_QUAL	,DIAG13_CODE	    ,DIAG14_CODE_QUAL	,DIAG14_CODE	,DIAG15_CODE_QUAL	
,DIAG15_CODE	,DIAG16_CODE_QUAL	,DIAG16_CODE	,DIAG17_CODE_QUAL	,DIAG17_CODE	    ,DIAG18_CODE_QUAL	,DIAG18_CODE	,DIAG19_CODE_QUAL	
,DIAG19_CODE	,DIAG20_CODE_QUAL	,DIAG20_CODE	,DIAG21_CODE_QUAL	,DIAG21_CODE	    ,DIAG22_CODE_QUAL	,DIAG22_CODE	,DIAG23_CODE_QUAL	
,DIAG23_CODE	,DIAG24_CODE_QUAL	,DIAG24_CODE	
,BILLPROV_LAST_NAME	,BILLPROV_ORG_NAME	,BILLINGPROV_NPI	,BILLINGPROV_GRP_NPI	,BILLINGPROV_ADDRESS	,BILLINGPROV_CITY	
,BILLINGPROV_STATE	,BILLINGPROV_ZIPCODE	,BILLINGPROV_TAX_ID	,MEMBER_LAST_NAME	,MEMBER_FIRST_NAME	,MEMBER_MIDDLE_NAME	
,MEMBER_NAME_SUFX	,MEMBER_ADDRESS,	MEMBER_CITY	,MEMBER_STATE	,MEMBER_ZIPCODE	,MEMBER_DOB	,MEMBER_GENDER	,PLAN_CLAIM_NO	
,PLACE_OF_SERVICE	,Supp_Type	,[Data_Source]	, STATUS_CODE	,Status_desc	,Process_Date	,[file_name]	,WIPRO_CLAIM_ID	,CMS_ICN	,CLM_ACK	,CLM_STATUS	
,RSP_277	,RSP_999	,RSP_MAO002	,RSP_MAO004	,Response_Status_Reserverd_1	,Response_Status_Reserverd_2	,Reserved_3	,Cycle	,Generation_Timestamp	,Edifecs_Claim_Id 
)
select 
ENC_ID	,RECEIVER_ID,	ENC_TYPE	,CLAIM_IND	,HIC_NBR	,CMS_CONTRACT_NO	,RAPS_PROV_TYPE,	From_Date	
,Thru_Date	,RAPS_PCN	,CLAIM_NO	,CHS_CLM_EDPS	,ICN_NO	,NPI_EDPS	,NPI_SUPP	,HS_CLAIM_NBR	
,FREQ_CD	,[ACTION]	,icd_version	,DIAG01_CODE_QUAL	,DIAG01_CODE		,DIAG02_CODE_QUAL	,DIAG02_CODE		,DIAG03_CODE_QUAL	
,DIAG03_CODE	,DIAG04_CODE_QUAL	,DIAG04_CODE	,DIAG05_CODE_QUAL	,DIAG05_CODE	    ,DIAG06_CODE_QUAL	,DIAG06_CODE	,DIAG07_CODE_QUAL	
,DIAG07_CODE	,DIAG08_CODE_QUAL	,DIAG08_CODE	,DIAG09_CODE_QUAL	,DIAG09_CODE	    ,DIAG10_CODE_QUAL	,DIAG10_CODE	,DIAG11_CODE_QUAL	
,DIAG11_CODE	,DIAG12_CODE_QUAL	,DIAG12_CODE	,DIAG13_CODE_QUAL	,DIAG13_CODE	    ,DIAG14_CODE_QUAL	,DIAG14_CODE	,DIAG15_CODE_QUAL	
,DIAG15_CODE	,DIAG16_CODE_QUAL	,DIAG16_CODE	,DIAG17_CODE_QUAL	,DIAG17_CODE	    ,DIAG18_CODE_QUAL	,DIAG18_CODE	,DIAG19_CODE_QUAL	
,DIAG19_CODE	,DIAG20_CODE_QUAL	,DIAG20_CODE	,DIAG21_CODE_QUAL	,DIAG21_CODE	    ,DIAG22_CODE_QUAL	,DIAG22_CODE	,DIAG23_CODE_QUAL	
,DIAG23_CODE	,DIAG24_CODE_QUAL	,DIAG24_CODE	
,BILLPROV_LAST_NAME	,BILLPROV_ORG_NAME	,BILLINGPROV_NPI	,BILLINGPROV_GRP_NPI	,BILLINGPROV_ADDRESS	,BILLINGPROV_CITY	
,BILLINGPROV_STATE	,BILLINGPROV_ZIPCODE	,BILLINGPROV_TAX_ID	,MEMBER_LAST_NAME	,MEMBER_FIRST_NAME	,MEMBER_MIDDLE_NAME	
,MEMBER_NAME_SUFX	,MEMBER_ADDRESS,	MEMBER_CITY	,MEMBER_STATE	,MEMBER_ZIPCODE	,MEMBER_DOB	,MEMBER_GENDER	,PLAN_CLAIM_NO	
,PLACE_OF_SERVICE	,Supp_Type	,[Data_Source]	,'333' STATUS_CODE	,Status_desc	,Process_Date	,[file_name]	,WIPRO_CLAIM_ID	,CMS_ICN	,CLM_ACK	,CLM_STATUS	
,RSP_277	,RSP_999	,RSP_MAO002	,RSP_MAO004	,Response_Status_Reserverd_1	,Response_Status_Reserverd_2	,Reserved_3	,Cycle	,Generation_Timestamp	,RTRIM(LTRIM(Edifecs_Claim_Id))
--,CHS_CLM_EDPS 
from #Supplemental_OUTPUT
where len(Edifecs_Claim_Id) <= 17

/*

select count(*)
from #Supplemental_OUTPUT
where RECEIVER_ID =1 


select max(RECEIVER_ID)
from #Supplemental_OUTPUT

select *
from #Supplemental_OUTPUT
where RECEIVER_ID = 17

select *
from #Supplemental_OUTPUT
where len(Edifecs_Claim_Id) > 17

select distinct [file_name]--, RECEIVER_ID
from [Supplemental_OUTPUT]

select *
from [Supplemental_OUTPUT] 
where [file_name] = 'HSCE.PROD.MAO.99.I2024082200001'



select 
'PROF'	Claim_Type	--PROF
,'FALSE' DME	--FALSE
,'TRUE' Chart_Review_Data	---TRUE
,HIC_NBR HICN_MBI	---HIC_NBR
,CMS_CONTRACT_NO HPLAN	    --CMS_CONTRACT_NO
,HS_CLAIM_NBR Claim_No	--HS_CLAIM_NBR
,'1' Claim_Freq_Code	--1
,'Add' Claim_Indicator	    --Add
,'' Adjusted_Claim_No	--Blank
,CHS_CLM_EDPS Linked_Claim_No	--CHS_CLM_EDPS
,DIAG01_CODE DXCode_1	--DIAG01_CODE
,'' DXCode_2	 --blank
,'' DXCode_3	 --blank
,'' DXCode_4	 --blank
,'' DXCode_5	 --blank
,'' DXCode_6	 --blank
,'' DXCode_7	 --blank
,'' DXCode_8	 --blank
,'' DXCode_9	 --blank
,'' DXCode_10	 --blank
,'' DXCode_11	 --blank
,'' DXCode_12	 --blank
,RAPS_PCN Patient_control_number	--RAPS_PCN
,ICN_NO Linked_CMSICN	---ICN_NO
,CLAIM_NO Linked_ENC_ID	---CLAIM_NO
,Edifecs_Claim_ID	
, [file_name], receiver_id  
from [Supplemental_OUTPUT]
where STATUS_CODE = '333'
and enc_type in ('P','PRO')


select 
'INST'	Claim_Type	--PROF
,'FALSE' DME	--FALSE
,'TRUE' Chart_Review_Data	---TRUE
,HIC_NBR HICN_MBI	---HIC_NBR
,CMS_CONTRACT_NO HPLAN	    --CMS_CONTRACT_NO
,HS_CLAIM_NBR Claim_No	--HS_CLAIM_NBR
,'1' Claim_Freq_Code	--1
,'Add' Claim_Indicator	    --Add
,'' Adjusted_Claim_No	--Blank
,CHS_CLM_EDPS Linked_Claim_No	--CHS_CLM_EDPS
,DIAG01_CODE DXCode_1	--DIAG01_CODE
,'' DXCode_2	 --blank
,'' DXCode_3	 --blank
,'' DXCode_4	 --blank
,'' DXCode_5	 --blank
,'' DXCode_6	 --blank
,'' DXCode_7	 --blank
,'' DXCode_8	 --blank
,'' DXCode_9	 --blank
,'' DXCode_10	 --blank
,'' DXCode_11	 --blank
,'' DXCode_12	 --blank
,'' DXCode_13 --blank
,'' DXCode_14 --blank
,'' DXCode_15 --blank
,'' DXCode_16 --blank
,'' DXCode_17 --blank
,'' DXCode_18 --blank
,'' DXCode_19 --blank
,'' DXCode_21 --blank
,'' DXCode_22	 --blank
,'' DXCode_23	 --blank
,'' DXCode_24	 --blank
,RAPS_PCN Patient_control_number	--RAPS_PCN
,ICN_NO Linked_CMSICN	---ICN_NO
,CLAIM_NO Linked_ENC_ID	---CLAIM_NO
,Edifecs_Claim_ID	
, [file_name], receiver_id  
from [Supplemental_OUTPUT]
where STATUS_CODE = '333'
and enc_type in ('I','INS')

*/



/*
ENC_ID	RECEIVER_ID	ENC_TYPE	CLAIM_IND	HIC_NBR	CMS_CONTRACT_NO	RAPS_PROV_TYPE	From_Date	
Thru_Date	RAPS_PCN	CLAIM_NO	CHS_CLM_EDPS	ICN_NO	NPI_EDPS	NPI_SUPP	HS_CLAIM_NBR	
FREQ_CD	ACTION	icd_version	DIAG01_CODE_QUAL	DIAG01_CODE	DIAG02_CODE_QUAL	DIAG02_CODE	DIAG03_CODE_QUAL	
DIAG03_CODE	DIAG04_CODE_QUAL	DIAG04_CODE	DIAG05_CODE_QUAL	DIAG05_CODE	DIAG06_CODE_QUAL	DIAG06_CODE	DIAG07_CODE_QUAL	
DIAG07_CODE	DIAG08_CODE_QUAL	DIAG08_CODE	DIAG09_CODE_QUAL	DIAG09_CODE	DIAG10_CODE_QUAL	DIAG10_CODE	DIAG11_CODE_QUAL	
DIAG11_CODE	DIAG12_CODE_QUAL	DIAG12_CODE	DIAG13_CODE_QUAL	DIAG13_CODE	DIAG14_CODE_QUAL	DIAG14_CODE	DIAG15_CODE_QUAL	
DIAG15_CODE	DIAG16_CODE_QUAL	DIAG16_CODE	DIAG17_CODE_QUAL	DIAG17_CODE	DIAG18_CODE_QUAL	DIAG18_CODE	DIAG19_CODE_QUAL	
DIAG19_CODE	DIAG20_CODE_QUAL	DIAG20_CODE	DIAG21_CODE_QUAL	DIAG21_CODE	DIAG22_CODE_QUAL	DIAG22_CODE	DIAG23_CODE_QUAL	
DIAG23_CODE	DIAG24_CODE_QUAL	DIAG24_CODE	
BILLPROV_LAST_NAME	BILLPROV_ORG_NAME	BILLINGPROV_NPI	BILLINGPROV_GRP_NPI	BILLINGPROV_ADDRESS	BILLINGPROV_CITY	
BILLINGPROV_STATE	BILLINGPROV_ZIPCODE	BILLINGPROV_TAX_ID	MEMBER_LAST_NAME	MEMBER_FIRST_NAME	MEMBER_MIDDLE_NAME	
MEMBER_NAME_SUFX	MEMBER_ADDRESS	MEMBER_CITY	MEMBER_STATE	MEMBER_ZIPCODE	MEMBER_DOB	MEMBER_GENDER	PLAN_CLAIM_NO	
PLACE_OF_SERVICE	Supp_Type	Data_Source	STATUS_CODE	Status_desc	Process_Date	file_name	WIPRO_CLAIM_ID	CMS_ICN	CLM_ACK	CLM_STATUS	
RSP_277	RSP_999	RSP_MAO002	RSP_MAO004	Response_Status_Reserverd_1	Response_Status_Reserverd_2	Reserved_3	Cycle	Generation_Timestamp	Edifecs_Claim_Id

HSCE.PROD.MAO.99.P.20211027010000
HSCE.PROD.MAO.99.P       +YYYYMMDD0000+receiver
HSCE.PROD.MAO.AZ.99.P	 +
HSCE.PROD.MAO.99.I		 +
HSCE.PROD.MAO.AZ.99.I	 +


1.	We have two file types PROF and INST

IF [WIPRO].[dbo].[Supplemental_OUTPUT] .ENC_TYPE = ‘P’ then PROF , I = INST

2.	AZ and NON AZ files
[WIPRO].[dbo].[Supplemental_OUTPUT] .CMS_CONTRACT_NO <> ‘H0354’ = NON AZ
[WIPRO].[dbo].[Supplemental_OUTPUT] .CMS_CONTRACT_NO = ‘H0354’ = AZ

File naming convention for NON AZ PROF
1.	HSCE.PROD.MAO.99.P is the default followed by YYYYMMDD + 00000 (use the last digit to get the file number)
File naming convention for AZ PROF
1.	HSCE.PROD.MAO.AZ.99 is the default followed by YYYYMMDD + 00000 (use the last digit to get the file number)


File naming convention for NON AZ PROF
1.	HSCE.PROD.MAO.99.P is the default followed by YYYYMMDD + 00000 (use the last digit to get the file number)
File naming convention for AZ PROF
2.	HSCE.PROD.MAO.AZ.99.P is the default followed by YYYYMMDD + 00000 (use the last digit to get the file number)


File naming convention for NON AZ INST
1.	HSCE.PROD.MAO.99.I is the default followed by YYYYMMDD + 00000 (use the last digit to get the file number)
File naming convention for AZ INST
3.	HSCE.PROD.MAO.AZ.99.I is the default followed by YYYYMMDD + 00000 (use the last digit to get the file number)

*/

--where len(Edifecs_Claim_Id1) <> 17
--and batchnumber < 10
--where enc_type = 'P'


--first 99999 will be batch 1
---random 0001 - 99999


--00001 - 99999 batch 1  PROF/INST
--00001 - 99999 batch 2  PROF/INST

--where enc_type = 'I'



/*
select len('U082120WELL100089')
U081420Clar0001
FILE NAMIng convention - Sample     —  

HSCE.PROD.MAO.99.P.20211027010000  - Where enc_type = P and cms_contract_no <>H8423

HSCE.PROD.MMP.99.P.20211027010000 - Where enc_type = P and cms_contract_no = H8423

HSCE.PROD.MAO.99.I.20211027010000 - Where enc_type = I and cms_contract_no = H8423

HSCE.PROD.MMP.99.I.20211027010000 - Where enc_type = I  and cms_contract_no = H8423

HSCE.PROD.MAO.88.P.20211027010000  - Where enc_type = P and cms_contract_no = H8423

HSCE.PROD.MMP.88.P.20211027010000 -Where enc_type = P and cms_contract_no = H8423
*/


END
