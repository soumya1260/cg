﻿
CREATE PROCEDURE [dbo].[EDS_Claims_Master_Recon_Archive_Data]

/* ---------------------------------------------------------------------------------------------------
04/23/2021	Scott Waller	TETDM-2497.   New procedure to archive "finalized" claims to the
							EDS_Claims_Master_Recon_Archive_Data table
							
---------------------------------------------------------------------------
Modifications
Date		Developer		Description
---------------------------------------------------------------------------
10/26/2021	Scott Waller	TETDM-2459	Request to add HCC_Eligible column to the 2 Claims Master 
							tables (EDS_Claims_Master_Recon and EDS_Claims_Master_Archive).

09/21/2022	Scott Waller	RETM-132 make some changes to the logic that determines 
							what claims need to be archived.

12/07/2022	Scott Waller	RETM-157 add 4 columns to the archive process.

01/25/2023	Scott Waller	RETM-177 add StatusDate to this archive process.
------------------------------------------------------------------------------ */
AS 
	BEGIN
        DECLARE @TOTAL_RECORDS		INT = 0,
				@GRAND_TOTAL_RECS	INT = 0

        INSERT  INTO dbo.EXT_SYS_RUNLOG
                ( PROC_NAME ,
                  STEP ,
                  START_DT ,
                  END_DT ,
                  RUN_MINUTES ,
                  TOTAL_RECORDS ,
                  ENTRYDT
                )
        VALUES  ( 'EDS_Claims_Master_Recon_Archive_Data' ,
                  '1' ,
                  GETDATE() ,
                  NULL ,
                  NULL ,
                  0 ,
                  GETDATE()
                )


-- get a single static date/time that will act as the unique idenifier to this set of data being loaded
        DECLARE @vCurrentDateTime DATETIME
        SET @vCurrentDateTime = GETDATE()	

---------------------------------------------------------------------------------------------------
-- first, archive all claims that are no longer in the CLAIMDIM or ENCOUNTERCLAIMDIM tables 
-- primarily because we have changed our cutoff dates, so we don't bring their data down from
-- BIDW any more
        INSERT  INTO dbo.EXT_SYS_RUNLOG
                ( PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
        VALUES  ( 'EDS_Claims_Master_Recon_Archive_Data - old CLAIMDIM claims', '2', GETDATE(), NULL, NULL, 0, GETDATE() )

		IF OBJECT_ID('TEMPDB..#hold_old_claimdim_claims') <> 0
			DROP TABLE #hold_old_claimdim_claims

		SELECT	a.SOURCEDATAKEY, a.claimid
		INTO	#hold_old_claimdim_claims
		FROM	WIPRO.dbo.EDS_Claims_Master_Recon a
		LEFT OUTER JOIN EDPS_Data.dbo.CLAIMDIM b
			ON	b.SOURCEDATAKEY		= a.sourcedatakey
			AND b.CLAIMID			= a.claimid
		WHERE	a.sourcedatakey <> 4
		AND		b.CLAIMID IS NULL

        INSERT  INTO WIPRO.dbo.EDS_Claims_Master_Recon_Archive
			(claimid, sourcedatakey, RefreshDate, sourcedesc, memberid, DOS_Year, BeginServiceDate, 
			 LOB, Claim_status, CMS_ICN, ClaimType, ArchiveDate, HCC_Eligible,
			 gender, EndServiceDate, RenderingProvNPI, BillingProvNPI, StatusDate) -- RETM-157
                SELECT  a.claimid,
                        a.sourcedatakey,
						a.RefreshDate,
						a.Sourcedesc,
						a.memberid,
						a.DOS_Year,
						a.BeginServiceDate,
						a.LOB,
						a.Claim_Status, 
						a.CMS_ICN,
						a.ClaimType,
						@vCurrentDateTime AS ArchiveDate,
						a.HCC_Eligible,					-- TETDM-2457
						a.Gender,						-- RETM-157
						a.EndServiceDate, 
						a.RenderingProvNPI, 
						a.BillingProvNPI,
						a.StatusDate					-- RETM-177
                FROM    WIPRO.dbo.EDS_Claims_Master_Recon a
				INNER JOIN	#hold_old_claimdim_claims b
					ON	b.sourcedatakey		= a.sourcedatakey
					AND	b.claimid			= a.claimid

		SET		@TOTAL_RECORDS = @@ROWCOUNT
		SET		@GRAND_TOTAL_RECS = @GRAND_TOTAL_RECS + @TOTAL_RECORDS

		DELETE	a
		FROM	WIPRO.dbo.EDS_Claims_Master_Recon a
		INNER JOIN	#hold_old_claimdim_claims b
			ON	b.sourcedatakey		= a.sourcedatakey
			AND b.claimid			= a.claimid

		UPDATE  dbo.EXT_SYS_RUNLOG
        SET     END_DT = GETDATE() ,
                RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
                TOTAL_RECORDS = @TOTAL_RECORDS ,
                ENTRYDT = GETDATE()
        WHERE   PROC_NAME = 'EDS_Claims_Master_Recon_Archive_Data - old CLAIMDIM claims'
                AND END_DT IS NULL
                AND STEP = '2'

		IF OBJECT_ID('TEMPDB..#hold_old_claimdim_claims') <> 0
			DROP TABLE #hold_old_claimdim_claims

---------------------------------------------------------------------------------------------------
-- now ENCOUNTERCLAIMDIM claims
		IF OBJECT_ID('TEMPDB..#hold_old_encounterclaimdim_claims') <> 0
			DROP TABLE #hold_old_encounterclaimdim_claims

        INSERT  INTO dbo.EXT_SYS_RUNLOG
                ( PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
        VALUES  ( 'EDS_Claims_Master_Recon_Archive_Data - old ENCOUNTERCLAIMDIM claims', '3', GETDATE(), NULL, NULL, 0, GETDATE() )

		IF OBJECT_ID('TEMPDB..#hold_old_encounterclaimdim_claims') <> 0
			DROP TABLE #hold_old_claimdim_claims

		SELECT	a.SOURCEDATAKEY, a.claimid
		INTO	#hold_old_encounterclaimdim_claims
		FROM	WIPRO.dbo.EDS_Claims_Master_Recon a
		LEFT OUTER JOIN EDPS_Data.dbo.ENCOUNTERCLAIMDIM b
			ON	b.SOURCEDATAKEY		= a.sourcedatakey
			AND b.ClaimNum			= a.claimid
		WHERE	a.sourcedatakey = 4
		AND		b.ClaimNum IS NULL

        INSERT  INTO WIPRO.dbo.EDS_Claims_Master_Recon_Archive
			(claimid, sourcedatakey, RefreshDate, sourcedesc, memberid, DOS_Year, BeginServiceDate, 
			 LOB, Claim_status, CMS_ICN, ClaimType, ArchiveDate, HCC_Eligible,
			 gender, EndServiceDate, RenderingProvNPI, BillingProvNPI, StatusDate) -- RETM-157
                SELECT  a.claimid,
                        a.sourcedatakey,
						a.RefreshDate,
						a.Sourcedesc,
						a.memberid,
						a.DOS_Year,
						a.BeginServiceDate,
						a.LOB,
						a.Claim_Status, 
						a.CMS_ICN,
						a.ClaimType,
						@vCurrentDateTime AS ArchiveDate,
						a.HCC_Eligible,					-- TETDM-2457
						a.Gender,						-- RETM-157
						a.EndServiceDate, 
						a.RenderingProvNPI, 
						a.BillingProvNPI,
						a.StatusDate					-- RETM-177
                FROM    WIPRO.dbo.EDS_Claims_Master_Recon a
				INNER JOIN	#hold_old_encounterclaimdim_claims b
					ON	b.sourcedatakey		= a.sourcedatakey
					AND	b.claimid			= a.claimid

		SET		@TOTAL_RECORDS = @@ROWCOUNT
		SET		@GRAND_TOTAL_RECS = @GRAND_TOTAL_RECS + @TOTAL_RECORDS

		DELETE	a
		FROM	WIPRO.dbo.EDS_Claims_Master_Recon a
		INNER JOIN	#hold_old_encounterclaimdim_claims b
			ON	b.sourcedatakey		= a.sourcedatakey
			AND b.claimid			= a.claimid

		UPDATE  dbo.EXT_SYS_RUNLOG
        SET     END_DT = GETDATE() ,
                RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
                TOTAL_RECORDS = @TOTAL_RECORDS ,
                ENTRYDT = GETDATE()
        WHERE   PROC_NAME = 'EDS_Claims_Master_Recon_Archive_Data - old ENCOUNTERCLAIMDIM claims'
                AND END_DT IS NULL
                AND STEP = '3'

---------------------------------------------------------------------------------------------------
-- Next, archive all claims that have a status of A-ICN or UnWrk

        INSERT  INTO dbo.EXT_SYS_RUNLOG
                ( PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
        VALUES  ( 'EDS_Claims_Master_Recon_Archive_Data - A-ICN and UnWrk claims', '4', GETDATE(), NULL, NULL, 0, GETDATE() )

        INSERT  INTO WIPRO.dbo.EDS_Claims_Master_Recon_Archive
			(claimid, sourcedatakey, RefreshDate, sourcedesc, memberid, DOS_Year, BeginServiceDate, 
			 LOB, Claim_status, CMS_ICN, ClaimType, ArchiveDate, HCC_Eligible,
			 gender, EndServiceDate, RenderingProvNPI, BillingProvNPI, StatusDate) -- RETM-157
                SELECT  a.claimid,
                        a.sourcedatakey,
						a.RefreshDate,
						a.Sourcedesc,
						a.memberid,
						a.DOS_Year,
						a.BeginServiceDate,
						a.LOB,
						a.Claim_Status, 
						a.CMS_ICN,
						a.ClaimType,
						@vCurrentDateTime AS ArchiveDate,
						a.HCC_Eligible,					-- TETDM-2457
						a.Gender,						-- RETM-157
						a.EndServiceDate, 
						a.RenderingProvNPI, 
						a.BillingProvNPI,
						a.StatusDate					-- RETM-177
                FROM    WIPRO.dbo.EDS_Claims_Master_Recon a
				WHERE	a.Claim_Status IN ('A-ICN', 'UnWrk', 'U')

		SET		@TOTAL_RECORDS		= @@ROWCOUNT
		SET		@GRAND_TOTAL_RECS	= @GRAND_TOTAL_RECS + @TOTAL_RECORDS

		DELETE	FROM WIPRO.dbo.EDS_Claims_Master_Recon
		WHERE	Claim_Status IN ('A-ICN', 'UnWrk', 'U')

		UPDATE  dbo.EXT_SYS_RUNLOG
        SET     END_DT = GETDATE() ,
                RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
                TOTAL_RECORDS = @TOTAL_RECORDS ,
                ENTRYDT = GETDATE()
        WHERE   PROC_NAME = 'EDS_Claims_Master_Recon_Archive_Data - A-ICN and UnWrk claims'
                AND END_DT IS NULL
                AND STEP = '4'

---------------------------------------------------------------------------------------------------------
-- update Run Controls
        UPDATE  dbo.EXT_SYS_RUNLOG
        SET     END_DT = GETDATE() ,
                RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
                TOTAL_RECORDS = @GRAND_TOTAL_RECS ,
                ENTRYDT = GETDATE()
        WHERE   PROC_NAME = 'EDS_Claims_Master_Recon_Archive_Data'
                AND END_DT IS NULL
                AND STEP = '1'
  
    END
GO
