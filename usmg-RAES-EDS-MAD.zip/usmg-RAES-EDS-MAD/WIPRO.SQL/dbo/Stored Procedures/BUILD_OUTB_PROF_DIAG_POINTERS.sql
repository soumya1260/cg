﻿
 
   
   
   
   
   
CREATE PROCEDURE [dbo].[BUILD_OUTB_PROF_DIAG_POINTERS]   
AS   
/***************************************************************************************************   
** CREATE DATE: 06/2012   
**   
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM   
**   
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM HEADER    
**              AND LINE LEVE DIAGNOSIS POINTER INFORMATION    
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE     
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES.    
**   
*****************************************************************************************************	   
------------------------------------------------------------------------------------------------------   
******************************************************************************************************   
------------------------------------------------------------------------------------------------------   
   
2014-06-25		Loyal Ricks		WIPRO Implementation		   
2016-02-08		Loyal Ricks		Facets ICD10 Adjustment temporary fix while BIDW changes are made   
								to the claimdetaildiagnosisdim table to remove additional decimals   
								from the daignosis code fields 	   
2016-04-18		Loyal Ricks		TETDM-750 Add @sourcedatakey parameter to sp to evaluate sdk prior to transformations   
								existing logic was removing leading "0" values from Facets line leve dx codes    
								which caused issues with derriving pointers.		   
2016-07-20		Loyal Ricks		TETDM-899 Remove Facets specific logic due to BIDW adjustments to claimlineid	   
2017-11-08      Henry Faust     TETDM-1501 - remove duplicate diag codes from Header and Line records. The line level    
                                records use pointers instead of the actual diag codes																		       
*****************************************************************************************************/	   
--UPDATE DIAGNOSIS POINTERS   
		--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND   
		--Add @sourcedatakey to support temp Facets ICD10 fix   
			DECLARE   
			   
			@TOTAL_RECORDS INT,   
			@sourcedatakey int   
   
   
			set @sourcedatakey = (select distinct sourcedatakey from OUTB_PROF_HEADER)   
--HRP_CLAIM_FILE Run controls   
INSERT INTO EXT_SYS_RUNLOG   
		(PROC_NAME   
		,STEP   
		,START_DT   
		,END_DT   
		,RUN_MINUTES   
		,TOTAL_RECORDS   
		,ENTRYDT   
		)   
		VALUES('BUILD_OUTB_PROF_DIAG_POINTERS'   
				,'5'   
				,GETDATE()   
				,NULL   
				,NULL   
				,0   
				,GETDATE()   
				)   
   
	--TETDM-750 Remove Facets from code that removes leading zero from dx code   
	--TETDM-899 Remove Facets specific logic due to BIDW adjustments to claimlineid   
	--if @sourcedatakey <> 30    
	--	begin 	   
	--1501    
   
	EXECUTE BUILD_OUTB_PROF_INSERT_DETAIL_CCCR    --populate the table that holds all the updated    
     
       
				--UPDATE PRIMARY DIAG_CD   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET PRIM_DIAG_CD = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					----	AND ECD.PRIM_DIAG_CD = CDD.diagnosiscode   
   
					UPDATE dbo.OUTB_PROF_DETAIL 
					SET PRIM_DIAG_CD = '' 
						 
					UPDATE dbo.OUTB_PROF_DETAIL 
					SET PRIM_DIAG_CD = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE  opd.CLAIM_LINE_NO = dcccr.claimlineid 
						AND opd.CLAIM_ID = dcccr.CLAIM_ID 
						AND dcccr.ROWNUM = 1 
				   
				--HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)   
		   
					UPDATE OUTB_PROF_DETAIL   
					SET PRIM_DIAG_CD = REPLACE(PRIM_DIAG_CD,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(PRIM_DIAG_CD,1,1) = '0'   
			   
				--UPDATE DIAG_CD2   
  					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD2 = ''		   
	 
  					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD2 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE  opd.CLAIM_LINE_NO = dcccr.claimlineid 
						AND opd.CLAIM_ID = dcccr.CLAIM_ID 
						AND dcccr.ROWNUM = 2 
 
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD2 = CASE WHEN cccr.parent IS NULL THEN ' ' ELSE cccr.parent end   
					--FROM OUTB_PROF_DETAIL ECD   
					--	LEFT OUTER JOIN dbo.OUTB_PROF_DETAIL_CCCR cccr ON cccr.CLAIM_ID = ECD.CLAIM_ID AND cccr.ROWNUM = 2				   
				--HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)   
		   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD2 = REPLACE(DIAG_CD2,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD2,1,1) = '0'   
			   
				--UPDATE DIAG_CD3   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD3 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD3 = CDD.diagnosiscode   
 
  					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD3 = '' 
					   
  					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD3 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE  opd.CLAIM_LINE_NO = dcccr.claimlineid 
						AND opd.CLAIM_ID = dcccr.CLAIM_ID 
						AND dcccr.ROWNUM = 3 
   
				--HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)   
		   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD3 = REPLACE(DIAG_CD3,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD3,1,1) = '0'   
				   
				--UPDATE DIAG_CD4   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD4 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD4 = CDD.diagnosiscode   
  
   					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD4 = '' 
					  
  					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD4 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE  opd.CLAIM_LINE_NO = dcccr.claimlineid 
						AND opd.CLAIM_ID = dcccr.CLAIM_ID 
						AND dcccr.ROWNUM = 4 
										   
				--HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)   
		   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD4 = REPLACE(DIAG_CD4,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD4,1,1) = '0'   
				   
				--UPDATE DIAG_CD5   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD5 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD5 = CDD.diagnosiscode   
					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD5 = '' 
					   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD5 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE  opd.CLAIM_LINE_NO = dcccr.claimlineid 
						AND opd.CLAIM_ID = dcccr.CLAIM_ID 
						AND dcccr.ROWNUM = 5 
										   
				--HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)   
		   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD5 = REPLACE(DIAG_CD5,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD5,1,1) = '0'   
				   
				--UPDATE DIAG_CD6   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD6 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD6 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD6 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD6 = dcccr.DGCD					   
					    AND opd.CLAIM_LINE_NO = dcccr.claimlineid 
		   
				--HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)   
		   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD6 = REPLACE(DIAG_CD6,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD6,1,1) = '0'   
				   
				--UPDATE DIAG_CD7   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD7 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD7 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD7 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD7 = dcccr.DGCD		 
				   
				--HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)   
		   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD7 = REPLACE(DIAG_CD7,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD7,1,1) = '0'   
				   
				--UPDATE DIAG_CD8   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD8 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD8 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD8 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD8 = dcccr.DGCD		  
										   
				--HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)   
		   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD8 = REPLACE(DIAG_CD8,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD8,1,1) = '0'   
				   
				--UPDATE DIAG_CD9   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD9 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD9 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD9 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD9 = dcccr.DGCD		 
								   
				--HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)   
		   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD9 = REPLACE(DIAG_CD9,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD9,1,1) = '0'   
				   
				--UPDATE DIAG_CD10   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD10 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD10 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD10 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD10 = dcccr.DGCD 
							 
 				--HRP POINTER FORMAT, REMOVE LEADING ZERO FROM POINTER (EDPS_Data.dbo.claimdiagnosisdim.SEQUENCE)   
  
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD10 = REPLACE(DIAG_CD10,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD10,1,1) = '0'	   
														   
				--UPDATE DIAG_CD11   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD11 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD11 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD11 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD11 = dcccr.DGCD		   
					   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD11 = REPLACE(DIAG_CD11,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD11,1,1) = '0'									   
										   
				--UPDATE DIAG_CD12   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD12 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD12 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD12 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD12 = dcccr.DGCD 
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD12 = REPLACE(DIAG_CD12,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD12,1,1) = '0'						   
														   
				--UPDATE DIAG_CD13   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD13 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD13 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD13 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD13 = dcccr.DGCD			   
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD13 = REPLACE(DIAG_CD13,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD13,1,1) = '0'						   
															--UPDATE DIAG_CD14   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD14 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD14 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD14 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD14 = dcccr.DGCD  
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD14 = REPLACE(DIAG_CD14,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD14,1,1) = '0'						   
															   
				--UPDATE DIAG_CD15   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD15 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD15 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD15 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD15 = dcccr.DGCD 
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD15 = REPLACE(DIAG_CD15,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD15,1,1) = '0'						   
																							   
				--UPDATE DIAG_CD16   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD16 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD16 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD16 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD16 = dcccr.DGCD  
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD16 = REPLACE(DIAG_CD16,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD16,1,1) = '0'						   
														   
				--UPDATE DIAG_CD17   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD17 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD17 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD17 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD17 = dcccr.DGCD   
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD17 = REPLACE(DIAG_CD17,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD17,1,1) = '0'						   
														   
				--UPDATE DIAG_CD18   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD18 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD18 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD18 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD18 = dcccr.DGCD 
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD18 = REPLACE(DIAG_CD18,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD18,1,1) = '0'						   
												   
				   
				--UPDATE DIAG_CD19   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD19 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD19 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD19 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD19 = dcccr.DGCD  
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD19 = REPLACE(DIAG_CD19,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD19,1,1) = '0'						   
														   
				--UPDATE DIAG_CD20   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD20 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD20 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD20 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD20 = dcccr.DGCD  
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD20 = REPLACE(DIAG_CD20,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD20,1,1) = '0'						   
																				   
				--UPDATE DIAG_CD21   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD21 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DAIG_CD21 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD21 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD21 = dcccr.DGCD   
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD21 = REPLACE(DIAG_CD21,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD21,1,1) = '0'						   
										   
   
				--UPDATE DIAG_CD22   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD22 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD22 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD22 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD22 = dcccr.DGCD   
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD22 = REPLACE(DIAG_CD22,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD22,1,1) = '0'						   
												   
				--UPDATE DIAG_CD23   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD23 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD23 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD23 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD23 = dcccr.DGCD  
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD23 = REPLACE(DIAG_CD23,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD23,1,1) = '0'						   
															   
													   
				--UPDATE DIAG_CD24   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD24 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD24 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD24 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD24 = dcccr.DGCD   
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD24 = REPLACE(DIAG_CD24,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD24,1,1) = '0'						   
																   
																				   
				--UPDATE DIAG_CD25   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD25 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD25 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD25 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD25 = dcccr.DGCD   
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD25 = REPLACE(DIAG_CD25,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD25,1,1) = '0'						   
									   
			   
				--UPDATE DIAG_CD26   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD26 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD26 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD26 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD26 = dcccr.DGCD    
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD26 = REPLACE(DIAG_CD26,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD26,1,1) = '0'						   
									   
				--UPDATE DIAG_CD27   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD27 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD27 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD27 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD27 = dcccr.DGCD   
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD27 = REPLACE(DIAG_CD27,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD27,1,1) = '0'						   
																					   
										   
				--UPDATE DIAG_CD28   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD28 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD28 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD28 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD28 = dcccr.DGCD   
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD28 = REPLACE(DIAG_CD28,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD28,1,1) = '0'						   
																				   
				--UPDATE DIAG_CD29   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD29 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD29 = CDD.diagnosiscode   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD29 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD29 = dcccr.DGCD   
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD29 = REPLACE(DIAG_CD29,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD29,1,1) = '0'						   
														   
				--UPDATE DIAG_CD30   
		   
					--UPDATE OUTB_PROF_DETAIL   
					--SET DIAG_CD30 = CDD.Sequence   
					--FROM OUTB_PROF_DETAIL ECD   
					--	,EDPS_Data.dbo.claimdiagnosisdim CDD   
					--WHERE ECD.CLAIM_ID = CDD.ClaimID   
					--	AND ECD.DIAG_CD30 = CDD.diagnosiscode   
   
   
 					UPDATE dbo.OUTB_PROF_DETAIL 
					SET DIAG_CD30 = parent 
					FROM dbo.OUTB_PROF_DETAIL opd 
					    ,dbo.OUTB_PROF_DETAIL_CCCR dcccr 
                    WHERE opd.DIAG_CD30 = dcccr.DGCD  
   
					UPDATE OUTB_PROF_DETAIL   
					SET DIAG_CD30 = REPLACE(DIAG_CD30,0,'')   
					FROM OUTB_PROF_DETAIL    
					WHERE SUBSTRING(DIAG_CD30,1,1) = '0'						   
	   
		--end			   
   
   
		---temp Facets ICD10 fix   
		--TETDM-899 Remove Facets specific logic    
		--if @sourcedatakey = 30    
   
		--begin    
		--	execute BUILD_OUTB_PROF_DIAG_POINTERS_FACETS_ICD10   
		--end   
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RESEND   
							    
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_DETAIL)   
		----HRP_CLAIM_FILE Update Run Controls   
				BEGIN TRANSACTION   
						UPDATE EXT_SYS_RUNLOG   
						SET END_DT = GETDATE()	   
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())   
							,TOTAL_RECORDS = @TOTAL_RECORDS   
							,ENTRYDT = GETDATE()   
						WHERE PROC_NAME = 'BUILD_OUTB_PROF_DIAG_POINTERS'   
								AND END_DT IS NULL   
							IF @@ERROR <> 0   
										BEGIN    
												ROLLBACK    
										END   
						COMMIT   
   
   
   
 

