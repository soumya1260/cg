﻿
CREATE PROCEDURE [dbo].[pr_BUILD_ENCOUNTER_DME]  
AS  
/***************************************************************************************************  
** CREATE DATE: 09/2016  
**  
** AUTHOR: LOYAL RICKS -  
**  
** DESCRIPTION: PROCEDURE will identify compiled DME claims and reomve them from current outbound  
**				Professional claim file. Procedure will also update EXT_EDPS_CLAIM_STATUS table   
**				CLAIM_TYPE to "E" (DME).   
**				Procedure will also temporarily append DME claimid to exclusion history to prevent   
**				future submissions during WIPRO development of required DME logic.   
**				Remove Exclusion History append once WIPRO logic is in place.   
**  
Modification History  
====================  
Date			Who				Description  
-----------------------------------------------------------------------------------------------------  
09/09/16		Loyal Ricks		Identify encounterclaimdim claimnum that are potential DME Supplier   
								claims. Append to EXT_ENCOUNTER_DME table. All claimnum will be   
								submitted via an encounter DME file (ClaimType = E).  
10/10/16		Loyal Ricks		TETDM-1003 Update logic replacing incorrect list of DME taxonomy codes with  
								correct list of supplier DME codes.  
10/27/16		Loyal Ricks		TETDM-1103 Add dos between elig span logic   
								TETDM-1103 Exclude all recorded exclusions from build  
10/28/2016		Loyal Ricks		TETDM-1222 - Add logic - and b.reportdatekey  between b.begincoveragedatekey and b.endcoveragedatekey  

05/20/2019		Scott Waller	TETDM-2058  Performance of this sproc has gone downhill terribly.  
								To try and improve performance, we need to remove the RTRIM on the joins
								to HistoricalClaims.  It causes it to table scan and not use the indexes.
08/14/2020      Henry Faust     TETDM-2324  Stop Duplicate claim from getting into table
12/16/2021		Anthony Ulmer	TETDM-2626 Changed from hplan to HCFACode in query below
								Other misc changes as denoted below

06/20/2022		Scott Waller	RETM-80 Update to the encounter dme sproc for adjustments
04/19/2024		Anthony Ulmer	RETM-575 Update to make DME table insert columns explicit

*****************************************************************************************************/	  
--DECLARE VARIABLES  
  
			DECLARE  
			  
			@TOTAL_RECORDS INT  
		  
  
--HRP_CLAIM_FILE Run controls  
	SET NOCOUNT ON; --added this TETDM-2626

					INSERT INTO EXT_SYS_RUNLOG  
							(PROC_NAME  
							,STEP  
							,START_DT  
							,END_DT  
							,RUN_MINUTES  
							,TOTAL_RECORDS  
							,ENTRYDT  
							)  
					VALUES('pr_BUILD_ENCOUNTER_DME'  
							,'12'  
							,GETDATE()  
							,NULL  
							,NULL  
							,0  
							,GETDATE()  
							)  
				---Attempt to identify DME claims using taxonomy code  
  
						INSERT INTO dbo.EXT_ENCOUNTER_DME 
						(CLAIMNUM, SOURCEDESC, CLM01, LOBCODE, HPLAN, SourceDataKey, 
						BILLPROVID, BILLPROVNPI, BILLPROVTAXID, BILLPROVTAXONOMY, CLAIM_TYPE)	
						SELECT DISTINCT
							  ec.ClaimNum
							, ec.SourceDesc
							, ec.ClaimNum 
							, b.LobCode
							, HCFACode
							, ec.SourceDataKey
							, ec.ProviderID
							, ec.VendorID
							, ec.FederalTaxID
							, ec.[ProvTaxonomyCode]
							, 'E'
						FROM EDPS_Data.dbo.encounterclaimdim ec
						JOIN EDPS_DATA.dbo.monthlymembershipdim b   
							ON EC.memberid = b.memberid   
						LEFT OUTER JOIN EXT_ENCOUNTER_DME D  
							ON EC.CLAIMNUM = D.CLAIMNUM   
								AND EC.SOURCEDESC = D.SOURCEDESC  
-- RETM-80				LEFT OUTER JOIN EXT_CLAIM_EXCLUSION_HIST EH  
--							ON EC.SOURCEDATAKEY = EH.SOURCEDATAKEY   
--								AND EC.CLAIMNUM = EH.CLAIM_ID  
						WHERE 1 = 1
							AND ec.beginservicedatekey BETWEEN b.begincoveragedatekey AND b.endcoveragedatekey   
							AND b.reportdatekey  BETWEEN b.begincoveragedatekey AND b.endcoveragedatekey  
	--						and RTRIM(HC.BillProvTaxonomy) IN ('332B00000X','332BC3200X','332BD1200X','332BN1400X','332BX2000X')	  
							and RTRIM(ec.ProvTaxonomyCode) IN ('332B00000X','332BC3200X','332BD1200X','332BN1400X','332BX2000X')	  
							--AND D.CLAIMNUM IS NULL  --removed this TETDM-2626
-- RETM-80					AND EH.CLAIM_ID IS NULL 
							AND (D.CLAIMNUM IS NULL AND D.SOURCEDESC IS NULL)  --added this TETDM-2626 (don't put items in that already exists)						
							AND b.HCFACode NOT LIKE '-%' --changed from d.hplan to b.HCFACode TETDM-2626
--								select DISTINCT  
--								--HISTORICALCLAIMID,  
--								ec.claimnum,  
--								EC.SOURCEDESC,  
--								HC.CLM01,  
--								B.LOBCODE, --LOB   
--								HCFACode,--HPLAN  
--								EC.SOURCEDATAKEY,  
--								HC.BILLPROVID,  
--								HC.BILLPROVNPI,  
--								HC.BILLPROVTAXID,  
--								HC.BillProvTaxonomy,  
--								'E'  
--						from edps_data.dbo.HistoricalClaim HC  
--						inner join EDPS_Data.dbo.encounterclaimdim EC  
---- TETDM-2058			ON RTRIM(HC.CLM01)= RTRIM(EC.CLAIMNUM)  
--						ON HC.CLM01 = EC.CLAIMNUM  
--						INNER join EDPS_DATA.dbo.monthlymembershipdim b   
--						on EC.memberid = b.memberid   
--						LEFT OUTER JOIN EXT_ENCOUNTER_DME D  
--						ON EC.CLAIMNUM = D.CLAIMNUM   
--						AND EC.SOURCEDESC = D.SOURCEDESC  
--						LEFT OUTER JOIN EXT_CLAIM_EXCLUSION_HIST EH  
--						ON EC.SOURCEDATAKEY = EH.SOURCEDATAKEY   
--						AND EC.CLAIMNUM = EH.CLAIM_ID  
--						where ec.beginservicedatekey between b.begincoveragedatekey and b.endcoveragedatekey   
--						and b.reportdatekey  between b.begincoveragedatekey and b.endcoveragedatekey  
--						and RTRIM(HC.BillProvTaxonomy) IN ('332B00000X','332BC3200X','332BD1200X','332BN1400X','332BX2000X')	  
--						AND D.CLAIMNUM IS NULL  
--						AND EH.CLAIM_ID IS NULL  
  
  
						UPDATE EXT_SYS_RUNLOG  
						SET END_DT = GETDATE()	  
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
							,TOTAL_RECORDS = @TOTAL_RECORDS  
							,ENTRYDT = GETDATE()  
						WHERE PROC_NAME = 'pr_BUILD_ENCOUNTER_DME'   
										and END_DT is null  
						  

	SET NOCOUNT OFF;  --added this TETDM-2626