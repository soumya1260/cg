﻿

CREATE PROCEDURE [dbo].[BUILD_OUTB_INST_CLAIM_CKHSUM]
(@FILEID CHAR(50))
AS
/***************************************************************************************************
** CREATE DATE: 10/2012
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL REMOVE ALL UNBALANCED CLAIMS FROM OUTBOUND HRP FILE.   
**              AN UNBALANCED CLAIM IS IDENTIFIED WHEN THE TOTAL CLAIM HEADER CHARGES DO NOT EQUAL  
**              THE TOTAL CLAIM LINE CHARGES. ONCE ALL CLAIMS HAVE BEEN IDENTIFIED AND REMOVED FROM 
**				THE OUTBOUND HRP CLAIM FILE TABLES (OUTB_INST_HEADER & OUTB_INST_DETAIL) THE PROCESS
**				WILL PURGE ALL PREVIOUSLY GENERATED OUTB_INST_HEADER_MAP RECORDS AND WILL REPOPULATE THIS
**				TABLE WITH VALID CLAIMS THAT BALANCE.
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation																							    
*****************************************************************************************************/

		DECLARE
					
					@TOTAL_RECORDS INT


			--HRP_CLAIM_FILE Run controls
		INSERT INTO EXT_SYS_RUNLOG
				(PROC_NAME
				,STEP
				,START_DT
				,END_DT
				,RUN_MINUTES
				,TOTAL_RECORDS
				,ENTRYDT
				)
				VALUES('BUILD_OUTB_INST_CLAIM_CKHSUM'
						,'12'
						,GETDATE()
						,NULL
						,NULL
						,0
						,GETDATE()
						)
					--PURGE ALL OUTB_INST_HEADER_CHKSUM DATA OLDER THAN 7 DAYS
					
					/*BEGIN TRANSACTION 
					DELETE 
					FROM OUTB_INST_HEADER_CHKSUM
					WHERE BATCH_DT < DATEADD(D,-7,GETDATE())
					COMMIT*/

					SELECT CLAIM_ID,MEMBER_ID,SOURCEDATAKEY,SUM(CONVERT(MONEY,TOT_CHRG_AMT)) 'HDR_TOT_CHRG_AMT',SUM(convert(MONEY, LTRIM(TOT_CHRG_AMT)))  'LINE_TOT_CHRG_AMT'
					INTO  #CLM_TOT
					FROM OUTB_INST_HEADER
					GROUP BY CLAIM_ID,MEMBER_ID,SOURCEDATAKEY
					ORDER BY CLAIM_ID--,CLAIM_LINE_NO


					SELECT CLAIM_ID,SUM(CONVERT(MONEY,TOTAL_CHRG_AMT)) 'TOT_CHRG_AMT'
					INTO  #CLMLINE_TOT
					FROM OUTB_INST_DETAIL
					GROUP BY CLAIM_ID
					ORDER BY CLAIM_ID--,CLAIM_LINE_NO



					
					UPDATE #CLM_TOT
					SET LINE_TOT_CHRG_AMT = TOT_CHRG_AMT
					FROM #CLM_TOT C
						, #CLMLINE_TOT CD
					WHERE C.CLAIM_ID = CD.CLAIM_ID
					


					 
					 delete
					FROM #CLM_TOT
					WHERE HDR_TOT_CHRG_AMT = CONVERT(MONEY, LINE_TOT_CHRG_AMT)
					

					--SAVE CLAIMS CAUSING BALANCING ISSUES
					 
					INSERT INTO EXT_CLAIM_CHKSUM
					SELECT @FILEID, *, GETDATE() 
					FROM #CLM_TOT
					
					---Log exclusion to prevent claim from being selected

					--insert into EXT_CLAIM_EXCLUSION_HIST
					--select c.claim_id,c.sourcedatakey,getdate(),9023,c.claim_type
					--from OUTB_INST_HEADER C
					--INNER JOIN #CLM_TOT T
					--ON C.SOURCEDATAKEY = T.SOURCEDATAKEY
					--AND C.CLAIM_ID = T.CLAIM_ID 



					--REMOVE CLAIMS CAUSING BALANCE ISSUES FROM OUTBOUND HRP FILE
					
					DELETE FROM OUTB_INST_HEADER
					WHERE CLAIM_ID IN (SELECT CLAIM_ID FROM #CLM_TOT)
					

					 
					DELETE FROM OUTB_INST_DETAIL
					WHERE CLAIM_ID IN (SELECT CLAIM_ID FROM #CLM_TOT)
					

				

					--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_INST_HEADER_RESEND
										 
						SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EXT_CLAIM_CHKSUM
															WHERE FILEID = @FILEID)
					----HRP_CLAIM_FILE Update Run Controls
							
									UPDATE EXT_SYS_RUNLOG
									SET END_DT = GETDATE()	
										,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
										,TOTAL_RECORDS = @TOTAL_RECORDS
										,ENTRYDT = GETDATE()
									WHERE PROC_NAME = 'BUILD_OUTB_INST_CLAIM_CKHSUM'
											AND END_DT IS NULL
										
