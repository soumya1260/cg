﻿ 
 
CREATE PROCEDURE [dbo].[EXSP_WIPRO_999_ARCHIVE] 
 
AS 
/*************************************************************************************************** 
Scott Waller January 2016      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
 
The whole WIPRO 999 File Intake process was cloned from WIPRO's MAO002 process, which means that 
the table structures are similar, the stored procs are cloned, as is the SSIS package.  WIPRO 999  
files have their own folder structure, keeping them separate from MAO002 files. 
 
I am leaving the all original MAO002 comments in these WIPRO 999 stored procs for the sake of  
documentation. 
 
****************************************************************************************************/ 
 
/*************************************************************************************************** 
** CREATE DATE: 03/2014 
** 
** AUTHOR: LOYAL RICKS - Loyal Ricks 
** 
** DESCRIPTION: Procedure will archive inbound MAO002 data from "MAO002 Daily Tables" to  
**				apropriate "MAO002 Non Daily" tables.  
**				Archive process designed to execute before daily execution of MAO002 job. 
**				Archiving daily before process will allow business group access to daily 
**				update data for auditing and validation. 
**				Daily MAO002 tables will be truncated after archiving. 
**				 
Modification History 
==================== 
Date			Who				Description 
----------------------------------------------------------------------------------------------------- 
03/27/2015		Loyal Ricks		WIPRO MAO002 - TETDM-53 - Revised procedure append to EXT_SYS_RUNLOG 
								replacing Verisk label with WIPRO label. 
04/08/2015		Loyal Ricks		TETDM-73 MAO-002 Version 1.1.0 Updates -MAO_002_DETAIL/MAO_002_DETAIL_DAILY 
08/03/2017		Subhash Acharya TETDM-1526 Change delete to truncate 
05/31/2019		Subhash Acharya TETDM-2056 LoadDate
*****************************************************************************************************/	 
--DECLARE VARIABLES 
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND 
			DECLARE	@TOTAL_RECORDS INT 
		 
					INSERT INTO EXT_SYS_RUNLOG 
							(PROC_NAME 
							,STEP 
							,START_DT 
							,END_DT 
							,RUN_MINUTES 
							,TOTAL_RECORDS 
							,ENTRYDT 
							) 
					VALUES('EXSP_WIPRO_999_ARCHIVE' 
							,'1' 
							,GETDATE() 
							,NULL 
							,NULL 
							,0 
							,GETDATE() 
							) 
					 
						--Archive WIRPO_999_FILESTATUS 
							INSERT INTO dbo.WIPRO_999_FileStatus
							(
							    InboundFileName,
							    FileID,
							    RecordType,
							    ClaimsReceived,
							    ClaimsAccepted,
							    ClaimsRejected,
							    CMSTransactionDate
							)
							   SELECT	InboundFileName,  
										FileID,  
										RecordType,  
										ClaimsReceived,  
										ClaimsAccepted,  
										ClaimsRejected,  
										CMSTransactionDate 
							   FROM dbo.WIPRO_999_FileStatus_Daily 
 
						--Archive WIPRO_999_HEADER 
							INSERT INTO dbo.WIPRO_999_FILE_HEADER
							(
							    InboundFileName,
							    RecordType,
							    HeaderVersion,
							    Category,
							    CategoryTrailerVersion,
							    StandardBody,
							    FileType,
							    FileVersion,
							    SubType,
							    WIPRO_FileID,
							    FileCreateDate,
							    ProductionIndicator,
							    ClientId,
							    VendorId,
							    SystemSource
							)
							   SELECT	InboundFileName, 
										RecordType,  
										HeaderVersion,  
										Category,  
										CategoryTrailerVersion,  
										StandardBody,  
										FileType,  
										FileVersion,  
										SubType,  
										WIPRO_FileID,  
										FileCreateDate,  
										ProductionIndicator,  
										ClientId,  
										VendorId,  
										SystemSource 
							   FROM dbo.WIPRO_999_File_Header_Daily 
 
						---Archive WIPRO_999_Reject_Detail 
						   insert into dbo.WIPRO_999_REJECT_DETAIL
						   (
						       FileStatusID,
						       InboundFileName,
						       FileID,
						       RecordType,
						       Claim_Type,
						       Trans_Set_Syntax_Err_CD,
						       Trans_Set_Syntax_Err_Desc,
						       WIPRO_CLAIMID,
						       Claim_ID,
						       Segment_ID,
						       Segment_Position,
						       Loop_ID_CD,
						       Segment_Syntax_CD,
						       Data_Element_Syntax_Error_CD,
						       Data_Element_Syntax_Error_Desc,
						       CHS_File_Record_Level,
						       Field_Position,
						       Field_Error,
						       Service_Line_Sequence_Number,
						       Value_Error,
						       DetailID
						   )
						   select	FileStatusID,  
									InboundFileName,  
									FileID,  
									RecordType,  
									Claim_Type,  
									Trans_Set_Syntax_Err_CD,  
									Trans_Set_Syntax_Err_Desc,  
									WIPRO_CLAIMID,  
									Claim_ID,  
									Segment_ID,  
									Segment_Position,  
									Loop_ID_CD,  
									Segment_Syntax_CD,  
									Data_Element_Syntax_Error_CD,  
									Data_Element_Syntax_Error_Desc,  
									CHS_File_Record_Level,  
									Field_Position,  
									Field_Error,  
									Service_Line_Sequence_Number,  
									Value_Error, 
									DetailID 
							from WIPRO_999_Reject_Detail_Daily       
 
						---Archive WIPRO_999_Accepted_Detail 
						   insert into dbo.WIPRO_999_ACCEPTED_DETAIL
						   (
						       FileStatusID,
						       InboundFileName,
						       FileID,
						       RecordType,
						       Claim_Type,
						       ClaimID,
						       WIPRO_CLAIMID,
						       DetailID
						   )
						   select	FileStatusID, InboundFileName, FileID, RecordType, Claim_Type, ClaimID, WIPRO_CLAIMID, DetailID 
							from dbo.WIPRO_999_Accepted_Detail_Daily       
 
						--Archive 999_Trailer 
						   INSERT INTO [dbo].[WIPRO_999_Trailer]
						   (
						       [TrailerID],
						       [InboundFileName],
						       [RecordType],
						       [FileID],
						       [TotalAcceptedRecords],
						       [TotalRejectedRecords]
						   )
							   select	TrailerID,  
										InboundFileName,  
										RecordType,  
										FileID,  
										TotalAcceptedRecords,  
										TotalRejectedRecords 
							   from dbo.WIPRO_999_Trailer_Daily       
 
						--ASSIGN @TOTAL_RECORDS - GET RECORD COUNTS For table being archived 
								SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM dbo.WIPRO_999_File_Header_Daily) 
								SET @TOTAL_RECORDS =  @TOTAL_RECORDS + (SELECT COUNT(*) FROM dbo.WIPRO_999_FileStatus_Daily) 
								SET @TOTAL_RECORDS =  @TOTAL_RECORDS + (SELECT COUNT(*) FROM dbo.WIPRO_999_Accepted_Detail_DAILY) 
								SET @TOTAL_RECORDS =  @TOTAL_RECORDS + (SELECT COUNT(*) FROM dbo.WIPRO_999_Reject_Detail_DAILY) 
								SET @TOTAL_RECORDS =  @TOTAL_RECORDS + (SELECT COUNT(*) FROM dbo.WIPRO_999_Trailer_DAILY) 
					 
						--Truncate Daily tables 
								TRUNCATE TABLE dbo.WIPRO_999_File_Header_Daily 
								TRUNCATE TABLE dbo.WIPRO_999_FileStatus_Daily 
								TRUNCATE TABLE dbo.WIPRO_999_Accepted_Detail_DAILY 
								TRUNCATE TABLE dbo.WIPRO_999_Reject_Detail_DAILY 
								TRUNCATE TABLE dbo.WIPRO_999_Trailer_DAILY 
														 
							----HRP_CLAIM_FILE Update Run Controls 
									 
								UPDATE EXT_SYS_RUNLOG 
								SET END_DT = GETDATE()	 
									,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()) 
									,TOTAL_RECORDS = @TOTAL_RECORDS 
									,ENTRYDT = GETDATE() 
								WHERE PROC_NAME = 'EXSP_WIPRO_999_ARCHIVE' 
												and END_DT is null 
 
 
 

