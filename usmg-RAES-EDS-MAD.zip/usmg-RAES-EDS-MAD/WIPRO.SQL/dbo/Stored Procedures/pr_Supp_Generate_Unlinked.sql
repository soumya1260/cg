﻿CREATE PROCEDURE [dbo].[pr_Supp_Generate_Unlinked]
/******************************************
Creation Date 11/6/2019
Author: ASU
Loads items into the supplemental_output table for unlinked claims found in supplemental_input
Also updates errors found in final checks here back in the supplemental_input table


Notes:
UPDATE:
	--03/30/2020 ASU
	Updates to accommodate changes in file layout for EDIFECS processing
*/
AS BEGIN
	SET NOCOUNT ON;

	DECLARE @max_file_records INT = 100000, --max records per file
			@Max_ID INT = 1, -- (SELECT MAX(ID) FROM WIPRO.dbo.Supplemental_OUTPUT so);
			@Date_Format VARCHAR(6) = FORMAT(GETDATE(),'MMddyy'),
			@Max_Date_In_Table VARCHAR(6),			
			@Submission_Type VARCHAR(1) = 'U',
			@Query NVARCHAR(500) = NULL;
			

	/*Get max values from current output table*/
	SELECT
		@Max_Date_In_Table = MAX(SUBSTRING(so.Edifecs_Claim_Id,2,6))
	FROM WIPRO.dbo.Supplemental_OUTPUT so
	WHERE LEFT(so.Edifecs_Claim_Id,1) = @Submission_Type;

	--check if date is in table
	IF @Max_Date_In_Table = @Date_Format
	BEGIN
    	SELECT
			@Max_ID = MAX(RIGHT(so.Edifecs_Claim_Id,6))
		FROM WIPRO.dbo.Supplemental_OUTPUT so
		WHERE 1 = 1
			AND SUBSTRING(so.Edifecs_Claim_Id,2,6) = @Date_Format
			AND LEFT(so.Edifecs_Claim_Id,1) = @Submission_Type;		
	END;	

	SET @Query = CONCAT('ALTER SEQUENCE dbo.supp_edifecs_ID RESTART WITH ',@Max_ID);

	IF @Max_ID >= 999999 BEGIN  
    	THROW 51000, 'The daily process limit for this process has been reached by a prior run.',1;		
    END;
    ELSE IF OBJECT_ID('dbo.supp_edifecs_ID') IS NOT NULL BEGIN			
		EXEC (@Query);
	END;
	ELSE IF OBJECT_ID('dbo.supp_edifecs_ID') IS NULL BEGIN
		
		CREATE SEQUENCE dbo.supp_edifecs_ID AS 
			INT 
			START WITH 1 
			INCREMENT BY 1
			MINVALUE 1
			MAXVALUE 999999;
			--CYCLE;
		
		IF @Max_ID > 1 BEGIN  
        	EXEC (@Query);
        END;        
	END;



	IF OBJECT_ID('tempdb.dbo.#Normalized_Supplemental_Input') IS NOT NULL
		DROP TABLE #Normalized_Supplemental_Input;

	IF OBJECT_ID('tempdb.dbo.#working_claims') IS NOT NULL
		DROP TABLE #working_claims;
			

	--dump all claims into working temp to be reused
	--can only process 899,991 records per day due to the way the unique ID is generated
	--899,991 came from 9(as max threshold) x 99,999(as max records per threshold)
	SELECT
		*
		INTO #working_claims
	FROM WIPRO.dbo.Supplemental_INPUT si
	WHERE 1 = 1
		AND si.STATUS_CODE IN ('010')
		AND si.Submission_Indicator = 0;

	ALTER TABLE #working_claims REBUILD PARTITION = ALL WITH (DATA_COMPRESSION = ROW);

	/*
	Running with the below two indexes (with options) runtime is about 00:05:41 for 980k records (condensed to 140k) over 5 runs
	Running without the below two indexes runtime is about 00:20:00 for 980k records (condensed to 140k) over 5 runs
	*/
	CREATE CLUSTERED INDEX idx_fromdate_thrudate_memberid_sourcesystemnumber_chartchasenpi_submissionindicator
	ON #working_claims (From_Date, Thru_Date, Member_ID ASC, Source_System_Number, Chart_Chase_NPI DESC, Submission_Indicator, STATUS_CODE)
	WITH (FILLFACTOR = 80, PAD_INDEX = ON)
	ON "default";

	CREATE NONCLUSTERED INDEX idx_fromdate_thrudate_memberid_sourcesystemnumber_chartchasenpi_dxcode_patientcontrolno
	ON #working_claims (From_Date, Thru_Date, Member_ID ASC, Source_System_Number, Chart_Chase_NPI, Dx_Code, Patient_Control_No, Submission_Indicator)
	INCLUDE (STATUS_CODE, Status_desc, Hic_No, Plan_No, Provider_Type)
	WITH (FILLFACTOR = 80, PAD_INDEX = ON)
	ON "default";



	/*
	Get items that have multiple plans and hicnos
	We want these to show as errors in the input table
	and not be brought to the output table

	Also flag items with "duplicate diag" codes
	*/

	WITH multi_plan_hicno AS (
		SELECT
			si.Member_ID,
			si.Source_System_Number,
			si.Thru_Date,
			si.From_Date,
			multi_hicno = COUNT(DISTINCT si.Hic_No),
			multi_plans = COUNT(DISTINCT si.Plan_No)
		FROM #working_claims si
		GROUP BY 
			si.Member_ID,
			si.Source_System_Number,
			si.Thru_Date,
			si.From_Date
		HAVING (COUNT(DISTINCT si.Hic_No) > 1 OR COUNT(DISTINCT si.Plan_No) > 1))
	UPDATE wc
	SET STATUS_CODE = '222',
		Status_desc = 'Data_Error_Sub_Diag_Dup',
		Submission_Indicator = 1
	FROM #working_claims wc
		JOIN multi_plan_hicno mph
			ON wc.Member_ID = mph.Member_ID
			AND wc.Source_System_Number = mph.Source_System_Number
			AND wc.Thru_Date = mph.Thru_Date
			AND wc.From_Date = mph.From_Date;

	WITH dup_diags AS ( 
		SELECT
			si.ID,
			si.Hic_No,
			si.Member_ID,
			si.Provider_Type,
			si.X_MBI,
			si.Chart_Chase_NPI,
			si.Plan_No,
			si.Dx_Code,
			si.Data_Source,
			si.Source_System_Number,
			si.From_Date, si.Thru_Date,
			si.Patient_Control_No,
			codes = ROW_NUMBER() OVER  (PARTITION BY si.Member_ID, si.Thru_Date, Hic_No, Dx_Code ORDER BY si.Source_System_Number)
		FROM #working_claims si)
	UPDATE wc
	SET STATUS_CODE = '222',
		Status_desc = 'Data_Error_Sub_Diag_Dup',
		Submission_Indicator = 1
	FROM #working_claims wc
	JOIN dup_diags dds
		ON wc.ID = dds.ID
	WHERE dds.codes > 1;


	IF OBJECT_ID('tempdb.dbo.#providers') IS NOT NULL
		DROP TABLE #providers;
	
	WITH provider_filter AS (
		SELECT
			epd.ProviderID,
			epd.FIDN,
			epd.NPID
		FROM EDPS_Data.dbo.EDS_ProviderDim epd
		WHERE LEN(epd.FIDN) > 0
		GROUP BY
			epd.ProviderID,
			epd.FIDN,
			epd.NPID
	),monthly_member AS (
		SELECT
			pd.NPID,
			mmd.MemberID,
			pd.FIDN,
			pd.ProviderID,
			BeginCoverageDateKey = TRY_CAST(TRY_CAST(mmd.BeginCoverageDateKey AS VARCHAR) AS DATE),
			EndCoverageDateKey = TRY_CAST(TRY_CAST(mmd.EndCoverageDateKey AS VARCHAR) AS DATE)
		FROM EDPS_Data.dbo.MonthlyMembershipDim mmd
		JOIN provider_filter pd
			ON mmd.PCPID = pd.ProviderID
		WHERE 1 = 1		
			AND pd.NPID NOT IN ('UNKNOWN', '00000000', '999999999')
			AND EXISTS (SELECT 1 FROM #working_claims si WHERE mmd.MemberID = si.Member_ID)
		GROUP BY
			pd.NPID,
			mmd.MemberID,
			mmd.BeginCoverageDateKey,
			mmd.EndCoverageDateKey,
			pd.FIDN,
			pd.ProviderID)
	SELECT
		*
	INTO #providers
	FROM monthly_member;

	CREATE NONCLUSTERED INDEX idx_providers
	ON #providers (NPID, MemberID ASC, BeginCoverageDateKey, EndCoverageDateKey )
	INCLUDE (FIDN, ProviderID);


	/*
	Do checks to filter out input rows with bad data
	*/
	WITH supp_NPI AS (
		SELECT
			si.Source_System_Number,
			si.Member_ID,
			si.From_Date,
			si.Thru_Date,
			si.Chart_Chase_NPI
		FROM #working_claims si
		GROUP BY 
			si.Chart_Chase_NPI,
			si.Source_System_Number,
			si.Member_ID,
			si.From_Date,
			si.Thru_Date
	),BAD_Data AS (
		SELECT
			SN.Chart_Chase_NPI,
			SN.Source_System_Number,
			SN.MEMBER_ID,
			SN.From_Date,
			SN.Thru_Date,
			isChart_Chase_NPI_or_NPID_BAD = CASE WHEN COALESCE(LEN(SN.Chart_Chase_NPI), LEN(mmd.NPID)) != 10  THEN 1 ELSE NULL END, 
			isBillPROV_LAST_NAME_BAD = CASE WHEN LEN(ci.ProviderLastName) = 0 AND LEN(ci.ProviderOrganizationName) > 0 THEN 1 ELSE NULL END,
			isBillPROV_ORG_NAME_BAD = CASE WHEN LEN(ci.ProviderOrganizationName) = 0 AND LEN(ci.ProviderLastName) > 0 THEN 1 ELSE NULL END,
			isBillPROV_ADDRESS_BAD = CASE WHEN LEN(CONCAT(ci.ProviderFirstLineBusinessMailingAddress,ci.ProviderSecondLineBusinessMailingAddress)) = 0 THEN 1 ELSE NULL END,
			isBillPROV_CITY_BAD = CASE WHEN LEN(ci.ProviderBusinessMailingAddressCityName) = 0 THEN 1 ELSE NULL END,
			isBillPROV_ORG_STATE_BAD = CASE WHEN LEN(ci.ProviderBusinessMailingAddressStateName) = 0 THEN 1 ELSE NULL END,
			isBillPROV_ZIPCODE_BAD = CASE WHEN LEN(ci.ProviderBusinessMailingAddressPostalCode) = 0 THEN 1 ELSE NULL END, --FIX THIS
			isBILLINGPROV_TAX_ID_BAD = CASE WHEN LEN(REPLACE(mmd.FIDN,'%T%','')) != 9 THEN 1 ELSE NULL END --remove "T"  
		FROM supp_NPI SN
		LEFT JOIN EDPS_Data.IDQ.CMSGeneralInformation ci
			ON SN.Chart_Chase_NPI = ci.NPI
		LEFT JOIN #providers mmd
			ON SN.Chart_Chase_NPI = mmd.NPID)
	UPDATE FTC
		SET 
			STATUS_CODE = '222',
			Submission_Indicator = 1,
			Status_desc = COALESCE(	REPLACE(BD.isChart_Chase_NPI_or_NPID_BAD,'1','Data_Error_NPI_Missing'),
									REPLACE(COALESCE(BD.isBillPROV_LAST_NAME_BAD,BD.isBillPROV_ORG_NAME_BAD),'1','Data_Error_PROV_Name_Missing'),
									REPLACE(COALESCE(BD.isBillPROV_ADDRESS_BAD,BD.isBillPROV_CITY_BAD,BD.isBillPROV_ORG_STATE_BAD, isBillPROV_ZIPCODE_BAD),'1','Data_Error_PROV_ADDRESS_Missing'),
									REPLACE(BD.isBILLINGPROV_TAX_ID_BAD,'1','Data_Error_PROV_TaxId_Missing'))
	FROM #working_claims FTC
		JOIN BAD_Data BD
			ON  FTC.Source_System_Number = BD.Source_System_Number
			AND FTC.Member_ID = BD.Member_ID
			AND FTC.From_Date = BD.From_Date
			AND FTC.Thru_Date = BD.Thru_Date
	WHERE 1 = 1
		AND COALESCE(	BD.isChart_Chase_NPI_or_NPID_BAD,
						BD.isBillPROV_LAST_NAME_BAD,
						BD.isBillPROV_ORG_NAME_BAD,
						BD.isBillPROV_ADDRESS_BAD,
						BD.isBillPROV_CITY_BAD,
						BD.isBillPROV_ORG_STATE_BAD, 
						BD.isBillPROV_ZIPCODE_BAD,
						BD.isBILLINGPROV_TAX_ID_BAD) = 1;


	/*Create temp copy of output table*/
	SELECT
		*
	INTO #stage_Supplemental_OUTPUT
	FROM wipro.dbo.Supplemental_OUTPUT so
	WHERE 1 = 2;
	
	TRUNCATE TABLE #stage_Supplemental_OUTPUT; --reset auto increment key

	ALTER TABLE #stage_Supplemental_OUTPUT ADD ID_SEED INT;
	ALTER TABLE #stage_Supplemental_OUTPUT REBUILD PARTITION = ALL WITH (DATA_COMPRESSION = ROW);

	/*
	NOTE: 
		The below three chained CTEs work under the following premise.
		Each diag code needs to be flattened to 12 columns (from maximum of 37? diags per claim).
		Each "Unique_Field" field is "split" into groups of 12 which should handle a maximum of 144 diags (matrix 12 x 12)
			anything over 144 codes will not be shown.
		Within the grouping of 12 "Unique_Field", the diag codes are broken down into 12 "DX" fields and labeled DX1-DX12 in CTE 2
		In CTE 3 the DX fields are pivoted into the maximum 12 field format

		Claims are also prioritized by "Chart_Chase_NPI" (prefering not null) the "DX_Dup_Counter" field.  Items higher than count 1 are dropped in CTE 2 

	*/
	WITH pvt AS ( --chain cte 1 of 3
		SELECT
			wc.Hic_No
		   ,wc.Member_ID
		   ,wc.Provider_Type
		   ,wc.X_MBI
		   ,wc.Chart_Chase_NPI
		   ,wc.Plan_No
		   ,wc.Dx_Code
		   ,wc.Data_Source
		   ,wc.Source_System_Number
		   ,wc.From_Date
		   ,wc.Thru_Date
		   ,wc.Patient_Control_No
		   ,Unique_Field = CONCAT(	wc.Member_ID,
									wc.From_Date,
									wc.Thru_Date,
									'-',
									TRY_CAST((ROW_NUMBER() OVER (PARTITION BY wc.Member_ID,
																			  wc.from_date,
																			  wc.Thru_Date
																			  ORDER BY ISNULL(wc.Chart_Chase_NPI, '') DESC) -1) --end rownumber
																			  / 12 AS VARCHAR)) --end try_cast
		FROM #working_claims wc
		WHERE 1 = 1
			AND wc.Status_Code IN ('010')
			AND wc.Submission_Indicator = 0
		GROUP BY 
			wc.Hic_No,
			wc.Member_ID,
			wc.Provider_Type,
			wc.X_MBI,
			wc.Chart_Chase_NPI,
			wc.Plan_No,
			wc.Dx_Code,
			wc.Data_Source,
			wc.Source_System_Number,
			wc.From_Date,
			wc.Thru_Date,
			wc.Patient_Control_No
	),
	dx_split AS ( --chain cte 2 of 3
		SELECT
			Patient_Control_No
			,pt.Member_ID
			,pt.Plan_No
			,pt.X_MBI
			,pt.Chart_Chase_NPI
			,pt.Source_System_Number
			,pt.From_Date
			,pt.Thru_Date
			,pt.Unique_Field
			,Dx_Code
			,pt.Data_Source
			,pt.Hic_No
			,pt.Provider_Type
			,DX_Label = REPLACE('DX' + TRY_CAST((ROW_NUMBER() OVER (PARTITION BY	pt.Unique_Field,
																					pt.Source_System_Number,
																					pt.From_Date,
																					pt.Thru_Date,
																					ISNULL(pt.Chart_Chase_NPI, '')
																					ORDER BY pt.Source_System_Number																		
																					) ) % 12 AS VARCHAR) --end rownumber
																					,'DX0','DX12') --end replace
		FROM pvt pt
	),
	normalized_dx_code AS ( --chain cte 3 of 3
		SELECT
			Patient_Control_No
			,Unique_Field
			,Hic_No
			,Plan_No
			,Member_ID
			,Chart_Chase_NPI
			,Source_System_Number
			,From_Date
			,Thru_Date
			,Provider_Type
			,Data_Source
			,X_MBI
			,p.DX1
			,p.DX2
			,p.DX3
			,p.DX4
			,p.DX5
			,p.DX6
			,p.DX7
			,p.DX8
			,p.DX9
			,p.DX10
			,p.DX11
			,p.DX12
		FROM dx_split pvt
		PIVOT (
				MIN(pvt.Dx_Code)
				FOR pvt.DX_Label IN ([DX1],[DX2],[DX3],[DX4],[DX5],[DX6],[DX7],[DX8],[DX9],[DX10],[DX11],[DX12])) p
	)
	SELECT
		ID = IDENTITY(INT, 1,1),
		ENC_ID = IIF(ndxc.Plan_No = 'H8423','HCF0594','HCF0262'),
		RECEIVER_ID = IIF(ndxc.Plan_No IN ('H6751', ' H8423'), '80889','80882'),
		ENC_TYPE = IIF(ndxc.Provider_Type = '20','P','I'),
		CLAIM_IND = '01',
		HIC_NBR = ndxc.Hic_No,
		CMS_CONTRACT_NO = ndxc.Plan_No,
		RAPS_PROV_TYPE = '20',
		From_Date = TRY_CONVERT(VARCHAR(8),ndxc.From_Date,112),
		Thru_Date = TRY_CONVERT(VARCHAR(8),ndxc.Thru_Date,112),
		RAPS_PCN = ndxc.Patient_Control_No, 
		CLAIM_NO = '',
		CHS_CLM_EDPS = NULL,
		ICN_NO = NULL,
		NPI_EDPS = NULL,
		NPI_SUPP = NULL,
		HS_CLAIM_NBR = ndxc.Source_System_Number,
		FREQ_CD = '1',
		[ACTION] = NULL,
		icd_version = '',
		DIAG01_CODE_QUAL = 'ABK',
		DIAG01_CODE = ndxc.DX1,
		DIAG02_CODE_QUAL = IIF(ndxc.DX2 IS NOT NULL, 'ABF',NULL),
		DIAG02_CODE = ndxc.DX2,
		DIAG03_CODE_QUAL = IIF(ndxc.DX3 IS NOT NULL, 'ABF',NULL),
		DIAG03_CODE = ndxc.DX3,
		DIAG04_CODE_QUAL = IIF(ndxc.DX4 IS NOT NULL, 'ABF',NULL),
		DIAG04_CODE = ndxc.DX4,
		DIAG05_CODE_QUAL = IIF(ndxc.DX5 IS NOT NULL, 'ABF',NULL),
		DIAG05_CODE = ndxc.DX5,
		DIAG06_CODE_QUAL = IIF(ndxc.DX6 IS NOT NULL, 'ABF',NULL),
		DIAG06_CODE = ndxc.DX6,
		DIAG07_CODE_QUAL = IIF(ndxc.DX7 IS NOT NULL, 'ABF',NULL),
		DIAG07_CODE = ndxc.DX7,
		DIAG08_CODE_QUAL = IIF(ndxc.DX8 IS NOT NULL, 'ABF',NULL),
		DIAG08_CODE = ndxc.DX8,
		DIAG09_CODE_QUAL = IIF(ndxc.DX9 IS NOT NULL, 'ABF',NULL),
		DIAG09_CODE = ndxc.DX9,
		DIAG10_CODE_QUAL = IIF(ndxc.DX10 IS NOT NULL, 'ABF',NULL),
		DIAG10_CODE = ndxc.DX10,
		DIAG11_CODE_QUAL = IIF(ndxc.DX11 IS NOT NULL, 'ABF',NULL),
		DIAG11_CODE = ndxc.DX11,
		DIAG12_CODE_QUAL = IIF(ndxc.DX12 IS NOT NULL, 'ABF',NULL),
		DIAG12_CODE = ndxc.DX12,
		BILLPROV_LAST_NAME = LEFT(ci.ProviderLastName,35),
		BILLPROV_ORG_NAME = LEFT(ci.ProviderOrganizationName,50),
		BILLINGPROV_NPI = IIF(LEN(ndxc.Chart_Chase_NPI) = 0,mmd.NPID,ndxc.Chart_Chase_NPI),
		BILLINGPROV_GRP_NPI = IIF(LEN(ndxc.Chart_Chase_NPI) = 0,mmd.NPID,ndxc.Chart_Chase_NPI), 
		BILLINGPROV_ADDRESS = CONCAT(ci.ProviderFirstLineBusinessMailingAddress,' ',ci.ProviderSecondLineBusinessMailingAddress),
		BILLINGPROV_CITY = LEFT(ci.ProviderBusinessPracticeLocationAddressCityName,50),
		BILLINGPROV_STATE = LEFT(ci.ProviderBusinessMailingAddressStateName,50),
		BILLINGPROV_ZIPCODE = LEFT(IIF(LEN(NULLIF(ci.ProviderBusinessMailingAddressPostalCode,'')) = 5, CONCAT(ci.ProviderBusinessMailingAddressPostalCode,'9998'),ci.ProviderBusinessMailingAddressPostalCode), 50),
		BILLINGPROV_TAX_ID = IIF(mmd.FIDN LIKE '%T%',SUBSTRING(mmd.FIDN,1,9), mmd.FIDN),
		MEMBER_LAST_NAME = md.LastName,
		MEMBER_FIRST_NAME = md.FirstName,
		MEMBER_MIDDLE_NAME = md.MiddleName,
		MEMBER_ADDRESS = IIF(md.AddressLine2 = 'UNKNOWN',md.AddressLine1,CONCAT(md.AddressLine1,' ', md.AddressLine2)),
		MEMBER_CITY = md.City,
		MEMBER_STATE = md.State,
		MEMBER_ZIPCODE = md.Zip,
		MEMBER_DOB = md.DOBDateKey,
		MEMBER_GENDER = md.Gender,
		PLAN_CLAIM_NO = ndxc.Source_System_Number,
		PLACE_OF_SERVICE = '11',
		Supp_Type = 'Unlinked',
		[DATA_SOURCE] = ndxc.Data_Source,
		STATUS_CODE = '777',
		Status_desc = 'Unlinked_SUB',
		Process_Date = TRY_CAST(GETDATE() AS DATE),
		CYCLE = NULL, --CONCAT(FORMAT(GETDATE(), 'ddMMyyyy'),'_','Y', RIGHT(YEAR(GETDATE()),2), IIF(@cycle < 10,CONCAT('0',@cycle),@cycle) ),
		[FILE_NAME] = CAST('' AS VARCHAR(255)) --populated below		
	INTO #Normalized_Supplemental_Input
	FROM normalized_dx_code ndxc
	LEFT JOIN #providers mmd
		ON ndxc.Member_ID = mmd.MemberID
		AND ndxc.From_Date BETWEEN mmd.BeginCoverageDateKey AND mmd.EndCoverageDateKey
	LEFT JOIN EDPS_Data.IDQ.CMSGeneralInformation ci
		ON ndxc.Chart_Chase_NPI = ci.NPI
	LEFT JOIN MDQOLib.dbo.MemberDim md
		ON md.MemberID = ndxc.Member_ID
		AND md.MemberKey = (SELECT MAX(md1.MemberKey) FROM MDQOLib.dbo.MemberDim md1 WHERE md.MemberID = md1.MemberID AND md1.Active = 1)
	WHERE 1 = 1
		AND mmd.MemberID IS NOT NULL;

	--update the filename and break up records according to file size limit here
	UPDATE #Normalized_Supplemental_Input
	SET [file_name] = NULL;

	DECLARE @file_date DATETIME = GETDATE(), 
			@server_var VARCHAR(4);

	IF @@servername = 'HSTNEDSDEVDB02' BEGIN  
    	SET @server_var = 'DEV';
    END
	ELSE IF @@servername = 'HSTNEDSDEVDB01' BEGIN  
    	SET @server_var = 'QA';
    END
	ELSE IF @@servername = 'HSTNEDSDB01' BEGIN  
    	SET @server_var = 'PROD';
    END
	ELSE
	BEGIN
		SET @server_var = 'UNKN'
	END;

	WITH file_counter AS (
	SELECT
		nsi.ID,		
		[Filename] = CONCAT('HSCE.',@server_var,'.MAO.88.P.'),
		file_break = CAST(( ROW_NUMBER() OVER (ORDER BY nsi.ID) - 1 )/ @max_file_records AS VARCHAR)
	FROM #Normalized_Supplemental_Input nsi
	WHERE nsi.CMS_CONTRACT_NO != 'H8423'
	UNION
	SELECT
		nsi.ID,		
		[Filename] = CONCAT('HSCE.',@server_var,'.MMPCARE.88.P.'),
		file_break = CAST(( ROW_NUMBER() OVER (ORDER BY nsi.ID) - 1) / @max_file_records AS VARCHAR)
	FROM #Normalized_Supplemental_Input nsi
	WHERE nsi.CMS_CONTRACT_NO = 'H8423'
	)
	UPDATE nsi	
		SET [FILE_NAME]	= CONCAT(fc.Filename, REPLICATE('0',12 - LEN( file_break)),fc.file_break)
	FROM  #Normalized_Supplemental_Input nsi
	JOIN file_counter fc ON nsi.ID = fc.ID;
	--end filename updates

	/*insert items into secondary temp table and update CMS unique ID (Edifecs_Claim_Id)*/

	INSERT INTO #stage_Supplemental_OUTPUT (ENC_ID, RECEIVER_ID, ENC_TYPE, CLAIM_IND, HIC_NBR, CMS_CONTRACT_NO, RAPS_PROV_TYPE, 
											From_Date, Thru_Date, RAPS_PCN, CLAIM_NO, CHS_CLM_EDPS, ICN_NO, NPI_EDPS, NPI_SUPP, 
											HS_CLAIM_NBR, FREQ_CD, ACTION, icd_version, DIAG01_CODE_QUAL, DIAG01_CODE, DIAG02_CODE_QUAL, 
											DIAG02_CODE, DIAG03_CODE_QUAL, DIAG03_CODE, DIAG04_CODE_QUAL, DIAG04_CODE, DIAG05_CODE_QUAL, 
											DIAG05_CODE, DIAG06_CODE_QUAL, DIAG06_CODE, DIAG07_CODE_QUAL, DIAG07_CODE, DIAG08_CODE_QUAL, 
											DIAG08_CODE, DIAG09_CODE_QUAL, DIAG09_CODE, DIAG10_CODE_QUAL, DIAG10_CODE, DIAG11_CODE_QUAL, 
											DIAG11_CODE, DIAG12_CODE_QUAL, DIAG12_CODE, BILLPROV_LAST_NAME, BILLPROV_ORG_NAME, BILLINGPROV_NPI, 
											BILLINGPROV_GRP_NPI, BILLINGPROV_ADDRESS, BILLINGPROV_CITY, BILLINGPROV_STATE, BILLINGPROV_ZIPCODE, 
											BILLINGPROV_TAX_ID, MEMBER_LAST_NAME, MEMBER_FIRST_NAME, MEMBER_MIDDLE_NAME, MEMBER_ADDRESS,
											MEMBER_CITY, MEMBER_STATE, MEMBER_ZIPCODE, MEMBER_DOB, MEMBER_GENDER, PLAN_CLAIM_NO, 
											PLACE_OF_SERVICE, Supp_Type, Data_Source, STATUS_CODE, Status_desc, Process_Date, Cycle, 
											file_name, ID_SEED)
	SELECT	
		nsi.ENC_ID ,nsi.RECEIVER_ID,nsi.ENC_TYPE,nsi.CLAIM_IND,nsi.HIC_NBR,nsi.CMS_CONTRACT_NO,nsi.RAPS_PROV_TYPE,nsi.From_Date
	   ,nsi.Thru_Date,nsi.RAPS_PCN,nsi.CLAIM_NO,nsi.CHS_CLM_EDPS,nsi.ICN_NO,nsi.NPI_EDPS,nsi.NPI_SUPP,nsi.HS_CLAIM_NBR
	   ,nsi.FREQ_CD,nsi.ACTION,nsi.icd_version,nsi.DIAG01_CODE_QUAL,nsi.DIAG01_CODE,nsi.DIAG02_CODE_QUAL,nsi.DIAG02_CODE
	   ,nsi.DIAG03_CODE_QUAL,nsi.DIAG03_CODE
	   ,nsi.DIAG04_CODE_QUAL,nsi.DIAG04_CODE
	   ,nsi.DIAG05_CODE_QUAL,nsi.DIAG05_CODE
	   ,nsi.DIAG06_CODE_QUAL,nsi.DIAG06_CODE
	   ,nsi.DIAG07_CODE_QUAL,nsi.DIAG07_CODE
	   ,nsi.DIAG08_CODE_QUAL,nsi.DIAG08_CODE
	   ,nsi.DIAG09_CODE_QUAL,nsi.DIAG09_CODE
	   ,nsi.DIAG10_CODE_QUAL,nsi.DIAG10_CODE
	   ,nsi.DIAG11_CODE_QUAL,nsi.DIAG11_CODE
	   ,nsi.DIAG12_CODE_QUAL,nsi.DIAG12_CODE
	   ,nsi.BILLPROV_LAST_NAME,nsi.BILLPROV_ORG_NAME
	   ,nsi.BILLINGPROV_NPI,nsi.BILLINGPROV_GRP_NPI
	   ,nsi.BILLINGPROV_ADDRESS,nsi.BILLINGPROV_CITY
	   ,nsi.BILLINGPROV_STATE,nsi.BILLINGPROV_ZIPCODE
	   ,nsi.BILLINGPROV_TAX_ID,nsi.MEMBER_LAST_NAME
	   ,nsi.MEMBER_FIRST_NAME,nsi.MEMBER_MIDDLE_NAME
	   ,nsi.MEMBER_ADDRESS,nsi.MEMBER_CITY
	   ,nsi.MEMBER_STATE,nsi.MEMBER_ZIPCODE
	   ,nsi.MEMBER_DOB,nsi.MEMBER_GENDER
	   ,nsi.PLAN_CLAIM_NO,nsi.PLACE_OF_SERVICE
	   ,nsi.Supp_Type,nsi.DATA_SOURCE
	   ,nsi.STATUS_CODE,nsi.Status_desc
	   ,nsi.Process_Date,nsi.CYCLE
	   ,nsi.file_name, ID_SEED = (NEXT VALUE FOR supp_edifecs_ID OVER (ORDER BY nsi.ID))	   
	FROM #Normalized_Supplemental_Input nsi;

	IF (SELECT MAX(ID_SEED) FROM #stage_Supplemental_OUTPUT sso) > 999999 BEGIN  
        THROW 51000, 'The current data cannot be as the Edifecs Unique ID values will be exceeded for this run.',1;
		RETURN;
    END;

	WITH strip_source (RAPS_PCN, ID, STRIPPED_SOURCE) AS (
		SELECT 
			nsi.RAPS_PCN,
			nsi.ID,
			Stripped_Source = REPLACE(REPLACE(nsi.RAPS_PCN,left(nsi.RAPS_PCN,PATINDEX('%-%',nsi.RAPS_PCN) ),''),right(nsi.RAPS_PCN,PATINDEX('%-%',REVERSE(nsi.RAPS_PCN))),'')
		FROM #stage_Supplemental_OUTPUT nsi)
	,strip_invalid_chars (CLEANED_SOURCE,RAPS_PCN, ID) AS (
		SELECT
			TRY_CAST(STRIPPED_SOURCE AS VARCHAR),
			RAPS_PCN,
			ID		
		FROM strip_source
		UNION ALL
		SELECT
			TRY_CAST(STUFF(CLEANED_SOURCE,PATINDEX('%[^a-z0-9]%',CLEANED_SOURCE),1,'') AS VARCHAR),
			RAPS_PCN,
			ID
		FROM strip_invalid_chars
		WHERE PATINDEX('%[^a-z0-9]%', CLEANED_SOURCE) > 0
	)
	UPDATE sso
		SET sso.Edifecs_Claim_Id = CONCAT(@Submission_Type, @Date_Format, REPLICATE('0', (4 - LEN(CLEANED_SOURCE))) , LEFT(CLEANED_SOURCE,4), REPLICATE('0',(6 - LEN(sso.ID_SEED))),sso.ID_SEED )
	FROM #stage_Supplemental_OUTPUT sso
	JOIN strip_invalid_chars
		ON sso.ID = strip_invalid_chars.ID
	WHERE PATINDEX('%[^a-z0-9]%', CLEANED_SOURCE) = 0;
	/*End unique ID update*/

	SET XACT_ABORT ON;

	--insert items into output table
	BEGIN TRY

		DECLARE @Generation_Timestamp DATETIME = GETDATE();
		BEGIN TRANSACTION;

		--create error for testing catch
		--SELECT 1/0;

		INSERT INTO WIPRO.dbo.Supplemental_OUTPUT (
			ENC_ID, RECEIVER_ID, ENC_TYPE, CLAIM_IND, HIC_NBR, CMS_CONTRACT_NO, RAPS_PROV_TYPE, From_Date, Thru_Date, RAPS_PCN, CLAIM_NO, CHS_CLM_EDPS,
			ICN_NO, NPI_EDPS, NPI_SUPP, HS_CLAIM_NBR, FREQ_CD, ACTION, icd_version, DIAG01_CODE_QUAL, DIAG01_CODE, DIAG02_CODE_QUAL, DIAG02_CODE, DIAG03_CODE_QUAL, DIAG03_CODE, DIAG04_CODE_QUAL,
			DIAG04_CODE, DIAG05_CODE_QUAL, DIAG05_CODE, DIAG06_CODE_QUAL, DIAG06_CODE, DIAG07_CODE_QUAL, DIAG07_CODE, DIAG08_CODE_QUAL, DIAG08_CODE, DIAG09_CODE_QUAL, DIAG09_CODE, DIAG10_CODE_QUAL,
			DIAG10_CODE, DIAG11_CODE_QUAL, DIAG11_CODE, DIAG12_CODE_QUAL, DIAG12_CODE,BILLPROV_LAST_NAME, BILLPROV_ORG_NAME, BILLINGPROV_NPI, BILLINGPROV_GRP_NPI, BILLINGPROV_ADDRESS, BILLINGPROV_CITY,
			BILLINGPROV_STATE, BILLINGPROV_ZIPCODE, BILLINGPROV_TAX_ID, MEMBER_LAST_NAME, MEMBER_FIRST_NAME, MEMBER_MIDDLE_NAME, MEMBER_ADDRESS, MEMBER_CITY, MEMBER_STATE, MEMBER_ZIPCODE,
			MEMBER_DOB, MEMBER_GENDER, PLAN_CLAIM_NO, PLACE_OF_SERVICE, Supp_Type, Data_Source, STATUS_CODE, Status_desc, Process_Date, Cycle, file_name, Generation_Timestamp, Edifecs_Claim_Id)
		SELECT
			sso.ENC_ID ,sso.RECEIVER_ID ,sso.ENC_TYPE ,sso.CLAIM_IND ,sso.HIC_NBR ,sso.CMS_CONTRACT_NO ,sso.RAPS_PROV_TYPE ,sso.From_Date ,sso.Thru_Date ,sso.RAPS_PCN ,sso.CLAIM_NO
		   ,sso.CHS_CLM_EDPS ,sso.ICN_NO ,sso.NPI_EDPS ,sso.NPI_SUPP ,sso.HS_CLAIM_NBR ,sso.FREQ_CD ,sso.ACTION ,sso.icd_version ,sso.DIAG01_CODE_QUAL ,sso.DIAG01_CODE ,sso.DIAG02_CODE_QUAL
		   ,sso.DIAG02_CODE ,sso.DIAG03_CODE_QUAL ,sso.DIAG03_CODE ,sso.DIAG04_CODE_QUAL ,sso.DIAG04_CODE ,sso.DIAG05_CODE_QUAL ,sso.DIAG05_CODE ,sso.DIAG06_CODE_QUAL ,sso.DIAG06_CODE
		   ,sso.DIAG07_CODE_QUAL ,sso.DIAG07_CODE ,sso.DIAG08_CODE_QUAL ,sso.DIAG08_CODE ,sso.DIAG09_CODE_QUAL ,sso.DIAG09_CODE ,sso.DIAG10_CODE_QUAL ,sso.DIAG10_CODE ,sso.DIAG11_CODE_QUAL
		   ,sso.DIAG11_CODE ,sso.DIAG12_CODE_QUAL ,sso.DIAG12_CODE ,sso.BILLPROV_LAST_NAME ,sso.BILLPROV_ORG_NAME ,sso.BILLINGPROV_NPI ,sso.BILLINGPROV_GRP_NPI ,sso.BILLINGPROV_ADDRESS
		   ,sso.BILLINGPROV_CITY ,sso.BILLINGPROV_STATE ,sso.BILLINGPROV_ZIPCODE ,sso.BILLINGPROV_TAX_ID ,sso.MEMBER_LAST_NAME ,sso.MEMBER_FIRST_NAME ,sso.MEMBER_MIDDLE_NAME ,sso.MEMBER_ADDRESS
		   ,sso.MEMBER_CITY ,sso.MEMBER_STATE ,sso.MEMBER_ZIPCODE ,sso.MEMBER_DOB ,sso.MEMBER_GENDER ,sso.PLAN_CLAIM_NO ,sso.PLACE_OF_SERVICE ,sso.Supp_Type ,sso.DATA_SOURCE ,sso.STATUS_CODE
		   ,sso.Status_desc ,sso.Process_Date ,sso.CYCLE ,sso.file_name
		   ,@Generation_Timestamp, sso.Edifecs_Claim_Id
		FROM #stage_Supplemental_OUTPUT sso;

		--update for input table so we flag items that were submitted
		UPDATE si
			SET si.STATUS_CODE = '777',
				si.Last_Modified = GETDATE()
		FROM WIPRO.dbo.Supplemental_INPUT si
			JOIN #working_claims wc ON si.ID = wc.ID
		WHERE wc.STATUS_CODE = '010' ;

		--update for input table to reflect errors found above
		UPDATE si
			SET si.STATUS_CODE = wc.STATUS_CODE,
				si.Status_desc = wc.Status_desc,
				si.Submission_Indicator = wc.Submission_Indicator,
				si.Last_Modified = GETDATE()
		FROM WIPRO.dbo.Supplemental_INPUT si
			JOIN #working_claims wc ON si.ID = wc.ID
		WHERE wc.STATUS_CODE != '010';

		COMMIT TRANSACTION;

	END TRY
	BEGIN CATCH

		DECLARE @error NVARCHAR(MAX) = ERROR_MESSAGE();

		IF (XACT_STATE() = 1) BEGIN  
    		ROLLBACK TRANSACTION;
		END;
    
		SET XACT_ABORT OFF;
		RAISERROR(@error,15,-1);	
	END CATCH;

	SET XACT_ABORT OFF;

	--cleanup
	IF OBJECT_ID('tempdb.dbo.#working_claims') IS NOT NULL
		DROP TABLE #working_claims;
	IF OBJECT_ID('tempdb.dbo.#Normalized_Supplemental_Input') IS NOT NULL
		DROP TABLE #Normalized_Supplemental_Input;
	IF OBJECT_ID('tempdb.dbo.#multi_plan_hicno') IS NOT NULL
		DROP TABLE #multi_plan_hicno;
	IF OBJECT_ID('tempdb.dbo.#Final_Table_Checks') IS NOT NULL
		DROP TABLE #Final_Table_Checks;
	IF OBJECT_ID('tempdb.dbo.#providers') IS NOT NULL
		DROP TABLE #providers;
	IF OBJECT_ID('tempdb.dbo.#stage_Supplemental_OUTPUT') IS NOT NULL
		DROP TABLE #stage_Supplemental_OUTPUT;

	RETURN 0;
END;
