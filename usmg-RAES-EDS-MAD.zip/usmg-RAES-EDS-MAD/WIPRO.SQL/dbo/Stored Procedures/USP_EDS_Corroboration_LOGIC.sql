﻿CREATE PROCEDURE [dbo].[USP_EDS_Corroboration_LOGIC]
	AS

	/*********************************************************************************************************************************************
		
		Description: corroboration logic for claims (Claim Type = P) that are being held in the SOS Compliance filtering

		test script: EXEC [WIPRO].[dbo].[USP_EDS_Corroboration_LOGIC]
		
		Modification History:
		======================================================================================================================================
		Date			Who				Description
		--------------------------------------------------------------------------------------------------------------------------------------
		2023-02-07		SasiT			Initial Creation


		*********************************************************************************************************************************************/

-- get a list of claims to be processed 

SELECT r.memberid, r.claimid AS HeldClaimID, r.HoldDate, r.FilterID
INTO #MemberList
FROM [dbo].[EDS_Claims_Master_Recon] r
WHERE Hold_Flag = 'Y' AND ReleaseDate IS NULL

INSERT INTO #MemberList
SELECT r.memberid, r.claimid AS HeldClaimID, r.HoldDate, r.FilterID
FROM [dbo].[EDS_Claims_Master_Recon] r
WHERE Hold_Flag = 'D' AND memberid <> '00000001'

-- get related I claims and info

SELECT DISTINCT r.memberid, m.HeldClaimID, r.claimid, r.ClaimType , RefreshDate , m.HoldDate, m.FilterID, r.BeginServiceDate AS PBeginServiceDate, r.EndServiceDate AS PEndServiceDate
INTO #MemberClaim
FROM [dbo].[EDS_Claims_Master_Recon] r
	JOIN #MemberList m ON r.memberid = m.memberid  AND r.ClaimType = 'I'
--	AND r.RefreshDate >= m.HoldDate

INSERT INTO #MemberClaim
SELECT DISTINCT r.memberid, m.HeldClaimID, r.claimid, r.ClaimType , RefreshDate , m.HoldDate, m.FilterID, r.BeginServiceDate AS PBeginServiceDate, r.EndServiceDate AS PEndServiceDate
FROM [dbo].[EDS_Claims_Master_Recon_Archive] r
	JOIN #MemberList m ON r.memberid = m.memberid  AND r.ClaimType = 'I'

SELECT DISTINCT r.*, x.BILL_TYPE_CODE INTO #FinalMemberClaim1 
FROM #MemberClaim r
	JOIN EDPS_Data.[dbo].[UB921AdmissionDim] u ON r.ClaimID = u.claimid
	JOIN [dbo].[CORROBORATING_BILL_TYPE_CODE_XREF] x ON  u.billtypecode = CONVERT(VARCHAR,x.BILL_TYPE_CODE)

INSERT INTO #FinalMemberClaim1 
SELECT DISTINCT r.* , e.BILLTYPECODE  
FROM #MemberClaim r
	JOIN EDPS_Data.DBO.encounterclaimdim e ON  r.Claimid = e.Claimnum
	JOIN [dbo].[CORROBORATING_BILL_TYPE_CODE_XREF] x ON  e.billtypecode = CONVERT(VARCHAR,x.BILL_TYPE_CODE)

-- get diagnosis code and source data key


SELECT r.*, REPLACE(cdd.DIAGNOSISCODE,'.','') AS DIAGNOSISCODE, cdd.SourceDataKey
INTO #ClaimsList
FROM #FinalMemberClaim1 r
	JOIN EDPS_Data.dbo.CLAIMDIAGNOSISDIM cdd
		ON r.ClaimID = cdd.CLAIMID
			AND r.memberid <> '00000001'


INSERT INTO #ClaimsList
SELECT r.*, REPLACE(cdd.DIAGNOSISCODE,'.','') AS DIAGNOSISCODE, cdd.SOURCEDATAKEY
FROM #FinalMemberClaim1 r
	JOIN EDPS_Data.dbo.CLAIMDETAILDIAGNOSISDIM cdd
		ON r.ClaimID = cdd.CLAIMID
		AND r.memberid <> '00000001'

-- adding encounter claims

INSERT INTO  #ClaimsList
SELECT DISTINCT r.*, cdd.DIAGNOSISCODE, cdd.SourceDataKey
FROM #FinalMemberClaim1 r
	JOIN (SELECT Claimnum, diagnosiscode, SourceDataKey, LoadDateKey FROM
			(	SELECT Claimnum, LoadDateKey, SourceDataKey, DX1 , DX2 , DX3 , DX4 , DX5 , DX6 , DX7 , DX8 , DX9 , DX10
				FROM EDPS_Data.dbo.encounterclaimdim 
				 ) p
			UNPIVOT
			( diagnosiscode for DXCode IN
				(DX1 , DX2 , DX3 , DX4 , DX5 , DX6 , DX7 , DX8 , DX9 , DX10)
			) AS upvt
					WHERE upvt.diagnosiscode <> '') cdd
		ON r.ClaimID = cdd.ClaimNum
			AND r.memberid <> '00000001'

SELECT DISTINCT * INTO #FinalMemberClaim
FROM #ClaimsList
WHERE memberid <> '00000001'

-- get SUPP data

SELECT c.Source_System_Number, c.Member_ID, c.SOS_Filter
INTO #MemberListSupp
FROM dbo.Supplemental_INPUT c
WHERE c.SOS_HOLD_Flag IN ('Y','D')


SELECT s.Member_ID, s.Source_System_Number, s.SOS_Filter, c.Source_System_Number AS CorrClaimID,  c.From_Date, c.Thru_Date, c.Dx_Code
INTO #MemberClaimSupp
FROM #MemberListSupp s
	JOIN dbo.Supplemental_INPUT c 
		ON s.Member_ID = c.Member_ID
			 AND c.Provider_Type = 'I'

	-- get recon I claims
INSERT INTO #MemberClaimSupp
SELECT DISTINCT s.Member_ID, s.Source_System_Number, s.SOS_Filter, c.claimid AS CorrClaimID, CONVERT(VARCHAR,c.BeginServiceDate) AS From_Date, CONVERT(VARCHAR,c.EndServiceDate) AS Thru_Date, REPLACE(cdd.DIAGNOSISCODE,'.','') AS Dx_Code
FROM #MemberListSupp s
	JOIN [dbo].[EDS_Claims_Master_Recon] c 
		ON s.Member_ID = c.memberid
			 AND c.ClaimType = 'I'
	JOIN EDPS_Data.dbo.CLAIMDETAILDIAGNOSISDIM cdd
		ON c.ClaimID = cdd.CLAIMID

INSERT INTO #MemberClaimSupp
SELECT DISTINCT s.Member_ID, s.Source_System_Number, s.SOS_Filter, c.claimid AS CorrClaimID, CONVERT(VARCHAR,c.BeginServiceDate) AS From_Date, CONVERT(VARCHAR,c.EndServiceDate) AS Thru_Date, REPLACE(cdd.DIAGNOSISCODE,'.','') AS Dx_Code
FROM #MemberListSupp s
	JOIN [dbo].[EDS_Claims_Master_Recon] c 
		ON s.Member_ID = c.memberid
			 AND c.ClaimType = 'I'
	JOIN EDPS_Data.dbo.CLAIMDIAGNOSISDIM cdd
		ON c.ClaimID = cdd.CLAIMID

INSERT INTO #MemberClaimSupp
SELECT DISTINCT s.Member_ID, s.Source_System_Number, s.SOS_Filter, c.claimid AS CorrClaimID, CONVERT(VARCHAR,c.BeginServiceDate) AS From_Date, CONVERT(VARCHAR,c.EndServiceDate) AS Thru_Date, REPLACE(cdd.DIAGNOSISCODE,'.','') AS Dx_Code
FROM #MemberListSupp s
	JOIN [dbo].[EDS_Claims_Master_Recon] c 
		ON s.Member_ID = c.memberid
			 AND c.ClaimType = 'I'
	JOIN (SELECT Claimnum, diagnosiscode, SourceDataKey, LoadDateKey FROM
			(	SELECT Claimnum, LoadDateKey, SourceDataKey, DX1 , DX2 , DX3 , DX4 , DX5 , DX6 , DX7 , DX8 , DX9 , DX10
				FROM EDPS_Data.dbo.encounterclaimdim 
				 ) p
			UNPIVOT
			( diagnosiscode for DXCode IN
				(DX1 , DX2 , DX3 , DX4 , DX5 , DX6 , DX7 , DX8 , DX9 , DX10)
			) AS upvt
					WHERE upvt.diagnosiscode <> '') cdd
		ON c.ClaimID = cdd.ClaimNum


SELECT DISTINCT S.*, x.BILL_TYPE_CODE INTO #FinalMemberClaimSupp
FROM #MemberClaimSupp s
	JOIN EDPS_Data.[dbo].[UB921AdmissionDim] u ON s.CorrClaimID = u.claimid
	JOIN [dbo].[CORROBORATING_BILL_TYPE_CODE_XREF] x ON  u.billtypecode = CONVERT(VARCHAR,x.BILL_TYPE_CODE)
	

-- release claims of filters 1, 14 of 72 hour with HCC

UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id of ' +  f.FilterID + ' of 4 weeks of HCC',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND DATEDIFF(DD, CONVERT(DATETIME, CONVERT(VARCHAR, f.PEndServiceDate)) ,  CONVERT(DATETIME, CONVERT(VARCHAR, r.EndServiceDate))) 
					BETWEEN 0 AND 28
			AND f.FilterID in ('1', '14')
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON f.DIAGNOSISCODE = x.DxCode 
				AND f.SourceDataKey = r.sourcedatakey
				AND x.HCC_LOGIC_VALUE IN ('86','87','228','229')

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of ' + s.SOS_Filter + ' of 4 weeks of HCC',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN #FinalMemberClaimSupp s
			ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
				AND DATEDIFF(DD, s.Thru_Date, c.Thru_Date) BETWEEN 0 AND 28
				AND s.SOS_Filter IN ('1', '14')
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON x.DxCode = s.Dx_Code
			AND x.HCC_LOGIC_VALUE IN ('86','87','228','229')
	

-- release claims of filters 1, 14 of 28 days with cardio

UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id of ' +  f.FilterID + ' of 4 weeks cardio',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND DATEDIFF(DD, CONVERT(DATETIME, CONVERT(VARCHAR, f.PEndServiceDate)) ,  CONVERT(DATETIME, CONVERT(VARCHAR, r.EndServiceDate))) 
					BETWEEN 0 AND 28
			AND f.FilterID in ('1', '14')
		JOIN  MDQOLib.[dbo].[IngenixProviderDim] igx
			ON r.BillingProvNPI = igx.NPI
			AND igx.TaxonomyCode IN ('246X00000X', '246W00000X', '246XC2903X',
										'246XC2901X', '246XS1301X', '208G00000X',
										'207RC0000X','207RA0001X','207RC0000X',
										'207UN0901X','2080P0202X', '2251C2600X',
										'207RI0011X', '207RA0001X')

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of ' + s.SOS_Filter + ' of 4 weeks of Cardio',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN #FinalMemberClaimSupp s
			ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
				AND DATEDIFF(DD, s.Thru_Date, c.Thru_Date) BETWEEN 0 AND 28
				AND s.SOS_Filter IN ('1', '14')
		JOIN  MDQOLib.[dbo].[IngenixProviderDim] igx
			ON c.Chart_Chase_NPI = igx.NPI
			AND igx.TaxonomyCode IN ('246X00000X', '246W00000X', '246XC2903X',
										'246XC2901X', '246XS1301X', '208G00000X',
										'207RC0000X','207RA0001X','207RC0000X',
										'207UN0901X','2080P0202X', '2251C2600X',
										'207RI0011X', '207RA0001X')

-- filter 5 with hcc release 72 hours
UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id of ' +  f.FilterID + ' of 72 hours of HCC',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND DATEDIFF(HH, CONVERT(DATETIME, CONVERT(VARCHAR, f.PBeginServiceDate)) ,  CONVERT(DATETIME, CONVERT(VARCHAR, r.BeginServiceDate))) 
					BETWEEN 0 AND 72 
			AND f.FilterID = 5
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON f.DIAGNOSISCODE = x.DxCode 
				AND f.SourceDataKey = r.sourcedatakey
				AND x.HCC_LOGIC_VALUE IN ('99', '248')

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of ' + s.SOS_Filter + ' of 72 hour of HCC',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN #FinalMemberClaimSupp s
			ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
				AND DATEDIFF(HH, s.From_Date, c.From_Date) BETWEEN 0 AND 72
				AND s.SOS_Filter = '5'
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON x.DxCode = s.Dx_Code
			AND x.HCC_LOGIC_VALUE IN ('99', '248')

-- filter 6 with hcc release 72 hours
UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id of ' +  f.FilterID + ' of 72 hours of HCC',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND DATEDIFF(HH, CONVERT(DATETIME, CONVERT(VARCHAR, f.PBeginServiceDate)) ,  CONVERT(DATETIME, CONVERT(VARCHAR, r.BeginServiceDate))) 
					BETWEEN 0 AND 72 
			AND f.FilterID = 6
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON f.DIAGNOSISCODE = x.DxCode 
				AND f.SourceDataKey = r.sourcedatakey
				AND x.HCC_LOGIC_VALUE IN ('162', '385')

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of ' + s.SOS_Filter + ' of 72 hour of HCC',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN #FinalMemberClaimSupp s
			ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
				AND DATEDIFF(HH, s.From_Date, c.From_Date) BETWEEN 0 AND 72
				AND s.SOS_Filter = '6'
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON x.DxCode = s.Dx_Code
			AND x.HCC_LOGIC_VALUE IN ('162', '385')

-- filter 7 with hcc release 72 hours
UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id of ' +  f.FilterID + ' of 72 hours of HCC',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND DATEDIFF(HH, CONVERT(DATETIME, CONVERT(VARCHAR, f.PBeginServiceDate)) ,  CONVERT(DATETIME, CONVERT(VARCHAR, r.BeginServiceDate))) 
					BETWEEN 0 AND 72 
			AND f.FilterID = 7
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON f.DIAGNOSISCODE = x.DxCode 
				AND f.SourceDataKey = r.sourcedatakey
				AND x.HCC_LOGIC_VALUE IN ('166', '397')

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of ' + s.SOS_Filter + ' of 72 hour of HCC',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN #FinalMemberClaimSupp s
			ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
				AND DATEDIFF(HH, s.From_Date, c.From_Date) BETWEEN 0 AND 72
				AND s.SOS_Filter = '7'
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON x.DxCode = s.Dx_Code
			AND x.HCC_LOGIC_VALUE IN ('166', '397')


-- filter 8 with hcc release 72 hours
UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id of ' +  f.FilterID + ' of 72 hours of HCC',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND DATEDIFF(HH, CONVERT(DATETIME, CONVERT(VARCHAR, f.PBeginServiceDate)) ,  CONVERT(DATETIME, CONVERT(VARCHAR, r.BeginServiceDate))) 
					BETWEEN 0 AND 72 
			AND f.FilterID = 8
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON f.DIAGNOSISCODE = x.DxCode 
				AND f.SourceDataKey = r.sourcedatakey
				AND x.HCC_LOGIC_VALUE IN ('167', '398','399')

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of ' + s.SOS_Filter + ' of 72 hour of HCC',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN #FinalMemberClaimSupp s
			ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
				AND DATEDIFF(HH, s.From_Date, c.From_Date) BETWEEN 0 AND 72
				AND s.SOS_Filter = '8'
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON x.DxCode = s.Dx_Code
			AND x.HCC_LOGIC_VALUE IN ('167', '398','399')


-- filter 9 with hcc release 72 hours
UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id of ' +  f.FilterID + ' of 72 hours of HCC',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND DATEDIFF(HH, CONVERT(DATETIME, CONVERT(VARCHAR, f.PBeginServiceDate)) ,  CONVERT(DATETIME, CONVERT(VARCHAR, r.BeginServiceDate))) 
					BETWEEN 0 AND 72 
			AND f.FilterID = 9
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON f.DIAGNOSISCODE = x.DxCode 
				AND f.SourceDataKey = r.sourcedatakey
				AND x.HCC_LOGIC_VALUE IN ('173','405', '267', '2')

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of ' + s.SOS_Filter + ' of 72 hour of HCC',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN #FinalMemberClaimSupp s
			ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
				AND DATEDIFF(HH, s.From_Date, c.From_Date) BETWEEN 0 AND 72
				AND s.SOS_Filter = '9'
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON x.DxCode = s.Dx_Code
			AND x.HCC_LOGIC_VALUE IN ('173','405', '267', '2')

-- filter 10 with hcc release 72 hours
UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id of ' +  f.FilterID + ' of 72 hours of HCC',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND DATEDIFF(HH, CONVERT(DATETIME, CONVERT(VARCHAR, f.PBeginServiceDate)) ,  CONVERT(DATETIME, CONVERT(VARCHAR, r.BeginServiceDate))) 
					BETWEEN 0 AND 72 
			AND f.FilterID = 10
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON f.DIAGNOSISCODE = x.DxCode 
				AND f.SourceDataKey = r.sourcedatakey
				AND x.HCC_LOGIC_VALUE IN ('100','249')

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of ' + s.SOS_Filter + ' of 72 hour of HCC',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN #FinalMemberClaimSupp s
			ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
				AND DATEDIFF(HH, s.From_Date, c.From_Date) BETWEEN 0 AND 72
				AND s.SOS_Filter = '10'
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON x.DxCode = s.Dx_Code
			AND x.HCC_LOGIC_VALUE IN ('100','249')

-- filter 12 with hcc release 72 hours
UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id of ' +  f.FilterID + ' of 72 hours of HCC',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND DATEDIFF(HH, CONVERT(DATETIME, CONVERT(VARCHAR, f.PBeginServiceDate)) ,  CONVERT(DATETIME, CONVERT(VARCHAR, r.BeginServiceDate))) 
					BETWEEN 0 AND 72 
			AND f.FilterID = 12
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON  f.DIAGNOSISCODE = x.DxCode 
				AND f.SourceDataKey = r.sourcedatakey
				AND x.HCC_LOGIC_VALUE = '2'

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of ' + s.SOS_Filter + ' of 72 hour of HCC',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN #FinalMemberClaimSupp s
			ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
				AND DATEDIFF(HH, s.From_Date, c.From_Date) BETWEEN 0 AND 72
				AND s.SOS_Filter = '12'
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
			ON x.DxCode = s.Dx_Code
				AND x.HCC_LOGIC_VALUE = '2'



-- release filter id 2
	-- update hold table 

UPDATE h
SET h.RELEASED_FOR_PROCESS_DATE = GETDATE(),
	h.HOLD_TABLE_STATUS = 30,
	h.HOLD_DATE = NULL,
	h.status_code_desc = 'release filter id 2 of opposite gender ' 
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN [dbo].[EDS_Claims_Master_Recon] r  
		ON h.MEM_ID = r.memberid 
			AND h.CLM_NO = r.ClaimID
			AND r.FilterID = 2 AND r.Hold_Flag = 'Y' AND r.Gender = 'M'

UPDATE r
SET r.Hold_Flag = 'N',
	--r.Corrob_ClaimID = f.claimid,
	--r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 2 of opposite gender' 
FROM [dbo].[EDS_Claims_Master_Recon] r
	WHERE r.FilterID = 2 AND r.Hold_Flag = 'Y' AND r.Gender = 'M'

UPDATE C
SET	c.SOS_HOLD_FLAG = 'N',
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of 2 of opposite gender',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
JOIN EDPS_Data.dbo.MemberDim M
			ON M.MemberID = c.Member_ID
				AND m.Gender = 'M'	
	WHERE c.SOS_Filter = '2' AND c.SOS_HOLD_Flag = 'Y' 

-- release filter id 3
	-- update hold table 

UPDATE h
SET h.RELEASED_FOR_PROCESS_DATE = GETDATE(),
	h.HOLD_TABLE_STATUS = 30,
	h.HOLD_DATE = NULL,
	h.status_code_desc = 'release filter id 3 of opposite gender ' 
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN [dbo].[EDS_Claims_Master_Recon] r  
		ON h.MEM_ID = r.memberid 
			AND h.CLM_NO = r.ClaimID
			AND r.FilterID = 3 AND r.Hold_Flag = 'Y' AND r.Gender = 'F'

UPDATE r
SET r.Hold_Flag = 'N',
	--r.Corrob_ClaimID = f.claimid,
	--r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 3 of opposite gender'
FROM [dbo].[EDS_Claims_Master_Recon] r
	WHERE r.FilterID = 3 AND r.Hold_Flag = 'Y' AND r.Gender = 'F'

UPDATE C
SET	c.SOS_HOLD_FLAG = 'N',
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id of 3 of opposite gender',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
JOIN EDPS_Data.dbo.MemberDim M
			ON M.MemberID = c.Member_ID
				AND m.Gender = 'F'	
	WHERE c.SOS_Filter = '3' AND c.SOS_HOLD_Flag = 'Y' 

-- release claims of filters 12

UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 12',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND ABS(DATEDIFF(DD, CONVERT(DATETIME, CONVERT(VARCHAR, f.PEndServiceDate)) ,  CONVERT(DATETIME, CONVERT(VARCHAR, r.EndServiceDate)))) < 14
			AND f.FilterID = '12'

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id 12',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN #FinalMemberClaimSupp s
			ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
				AND ABS(DATEDIFF(DD, s.From_Date, c.From_Date)) < 14
				AND s.SOS_Filter = '12'


-- Release of filter 16

		-- check for Z diag for member of same claim or any other claims with same dos

UPDATE r
SET r.Hold_Flag = 'D',
	r.Corrob_ClaimID = r1.claimid,
	--r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 16 with Z diag/retraction' ,
	r.Retraction_Date = CONVERT(VARCHAR, GETDATE(), 101),
	r.Claim_Status = NULL
FROM [dbo].[EDS_Claims_Master_Recon] r
		--JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
		JOIN [dbo].[EDS_Claims_Master_Recon] r1 ON r.memberid = r1.memberid AND r.BeginServiceDate = r1.BeginServiceDate
			AND r.FilterID = '16'
			AND r.Hold_Flag = 'Y'
		JOIN EDPS_Data.dbo.CLAIMDIAGNOSISDIM cd ON cd.CLAIMID = r1.claimid
			and REPLACE(cd.DIAGNOSISCODE,'.','') IN ('Z681', 'Z6820', 'Z6821', 'Z6822', 'Z6823', 'Z6824',
									'Z6825', 'Z6826', 'Z6827', 'Z6828', 'Z6829', 'Z6830',
									'Z6831', 'Z6832', 'Z6833', 'Z6834' )
				AND cd.SourceDataKey = r.sourcedatakey

UPDATE C
SET	c.SOS_HOLD_FLAG = 'D',
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id 16 with Z diag/retraction',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
		JOIN dbo.Supplemental_INPUT c1 ON c.Member_ID = c1.Member_ID AND c.From_Date = c1.From_Date
			AND c.SOS_Filter = 16 AND c.SOS_HOLD_Flag = 'Y'
			AND c1.Dx_Code IN ('Z681', 'Z6820', 'Z6821', 'Z6822', 'Z6823', 'Z6824',
									'Z6825', 'Z6826', 'Z6827', 'Z6828', 'Z6829', 'Z6830',
									'Z6831', 'Z6832', 'Z6833', 'Z6834' )

UPDATE r
SET r.Hold_Flag = 'D',
	r.Corrob_ClaimID = r1.claimid,
	--r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 16 with Z diag/retraction' ,
	r.Retraction_Date = CONVERT(VARCHAR, GETDATE(), 101),
	r.Claim_Status = NULL
FROM [dbo].[EDS_Claims_Master_Recon] r
		--JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
		JOIN [dbo].[EDS_Claims_Master_Recon] r1 ON r.memberid = r1.memberid AND r.BeginServiceDate = r1.BeginServiceDate
			AND r.FilterID = '16'
			AND r.Hold_Flag = 'Y'
		JOIN EDPS_Data.dbo.CLAIMDETAILDIAGNOSISDIM cd ON cd.CLAIMID = r1.claimid
			and REPLACE(cd.DIAGNOSISCODE,'.','') IN ('Z681', 'Z6820', 'Z6821', 'Z6822', 'Z6823', 'Z6824',
									'Z6825', 'Z6826', 'Z6827', 'Z6828', 'Z6829', 'Z6830',
									'Z6831', 'Z6832', 'Z6833', 'Z6834' )
				AND cd.SourceDataKey = r.sourcedatakey

UPDATE r
SET r.Hold_Flag = 'D',
	r.Corrob_ClaimID = r1.claimid,
	--r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 16 with Z diag/retraction' ,
	r.Retraction_Date = CONVERT(VARCHAR, GETDATE(), 101),
	r.Claim_Status = NULL
FROM [dbo].[EDS_Claims_Master_Recon] r
		--JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
		JOIN [dbo].[EDS_Claims_Master_Recon] r1 ON r.memberid = r1.memberid AND r.BeginServiceDate = r1.BeginServiceDate
			AND r.FilterID = '16'
			AND r.Hold_Flag = 'Y'
		JOIN (SELECT Claimnum, diagnosiscode, SourceDataKey, LoadDateKey FROM
			(	SELECT Claimnum, LoadDateKey, SourceDataKey, DX1 , DX2 , DX3 , DX4 , DX5 , DX6 , DX7 , DX8 , DX9 , DX10
				FROM EDPS_Data.dbo.encounterclaimdim 
				 ) p
			UNPIVOT
			( diagnosiscode for DXCode IN
				(DX1 , DX2 , DX3 , DX4 , DX5 , DX6 , DX7 , DX8 , DX9 , DX10)
			) AS upvt
					WHERE upvt.diagnosiscode <> '') cdd
		ON r1.ClaimID = cdd.ClaimNum
			and cdd.DIAGNOSISCODE IN ('Z681', 'Z6820', 'Z6821', 'Z6822', 'Z6823', 'Z6824',
									'Z6825', 'Z6826', 'Z6827', 'Z6828', 'Z6829', 'Z6830',
									'Z6831', 'Z6832', 'Z6833', 'Z6834' )
				AND cdd.SourceDataKey = r.sourcedatakey

UPDATE h
SET	h.Retraction_Date = CONVERT(VARCHAR,GETDATE(),101) , h.HOLD_TABLE_STATUS = 16, h.RETRACTION_FLAG = 1
	,h.STATUS_CODE_DESC = a.ReleaseStatusDescription
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] A 
		ON h.MEM_ID = a.memberid 
			AND h.CLM_NO = a.claimid
			AND a.Hold_Flag = 'D'  AND a.FilterID = '16' 
			AND a.ReleaseStatusDescription = 'release filter id 16 with Z diag/retraction' 
			AND CONVERT(VARCHAR, a.Retraction_Date, 101) =  CONVERT(VARCHAR, GETDATE(), 101)
			AND h.Retraction_Date IS NULL

UPDATE h
SET	h.Retraction_Date = CONVERT(VARCHAR,GETDATE(),101) , h.HOLD_TABLE_STATUS = 16, h.RETRACTION_FLAG = 1
	,h.STATUS_CODE_DESC = c.SOS_Release_Status_Description
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN dbo.Supplemental_INPUT c 
		ON h.MEM_ID = c.Member_ID
			AND h.CLM_NO = c.Source_System_Number
			AND h.RELEASED_FOR_PROCESS_DATE IS NULL
			AND c.SOS_HOLD_FLAG = 'D' AND c.SOS_Filter = 16
			AND c.SOS_Release_Status_Description = 'release filter id 16 with Z diag/retraction'
			AND h.Retraction_Date IS NULL	

		-- release claims that dont have z diag

UPDATE r
SET r.Hold_Flag = 'N',
	--r.Corrob_ClaimID = f.claimid,
	--r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id of 16' ,
	r.Claim_Status = NULL
--	r.Retraction_Date = CONVERT(VARCHAR, GETDATE(), 101)
FROM [dbo].[EDS_Claims_Master_Recon] r
		--JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
WHERE r.FilterID = '16'
			AND r.Hold_Flag = 'Y'

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id 16',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
	WHERE c.SOS_Filter = 16 AND c.SOS_HOLD_Flag = 'Y'

-- release filter 15

UPDATE r
SET r.Hold_Flag = 'N',
	r.Corrob_ClaimID = c.claim_id,
	r.ReleaseDate = GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 15 pharmacy claims'
FROM [dbo].[EDS_Claims_Master_Recon] r -- update N
JOIN WIPRO.dbo.CDO_PHARM_CLAIMS c ON REPLACE(r.memberid,'*','') = REPLACE(c.MEMBERID,'*','')
WHERE r.FilterID = '15' AND Hold_Flag IN ('Y','D') AND CONVERT(VARCHAR, r.BeginServiceDate,101)
BETWEEN  DATEADD(YEAR, -1, c.PRESCRIPTIONFILLEDDATE ) AND DATEADD(YEAR, 1, c.PRESCRIPTIONFILLEDDATE)

UPDATE h
SET h.RELEASED_FOR_PROCESS_DATE = GETDATE(),
	h.HOLD_TABLE_STATUS = 30,
	h.HOLD_DATE = NULL,
	h.status_code_desc = 'Released Corrob Inpt BillType Claim : ' + r.Corrob_ClaimID 
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] r
		 ON r.memberid =  h.MEM_ID AND r.claimid = h.CLM_NO
			AND r.FilterID = '15'
			AND r.Hold_Flag = 'N'
			AND r.ReleaseDate > GETDATE()-1
			AND h.HOLD_DATE IS NOT NULL 

UPDATE r
SET r.Hold_Flag = CASE WHEN r.Hold_Flag = 'Y' THEN 'N' WHEN r.Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate = GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 15 Hospice claims',
	r.Retraction_Resub_Date = CASE WHEN r.Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND f.FilterID = '15' AND r.Hold_Flag IN ('Y', 'D')
		JOIN [dbo].[EDS_Claims_Master_Recon] r1 ON r1.claimID = f.ClaimID
			AND CONVERT(VARCHAR, r.BeginServiceDate,101) BETWEEN DATEADD(YEAR, -1, CONVERT(VARCHAR, r1.BeginServiceDate,101)) AND DATEADD(YEAR, 1, CONVERT(VARCHAR, r1.BeginServiceDate,101))
		LEFT JOIN [EDPS_Data].[dbo].[ClaimLineRevenueCodeDim] rc ON f.ClaimID = rc.ClaimID -- AND r.DOS_Year = r1.DOS_Year
WHERE f.BILL_TYPE_CODE IN ('0810', '0811', '0812', '0813', '0814', '0817', '0818', --'081A', '081B', '081C', '081D', '081E',
						   '0820', '0821', '0822', '0823', '0824', '0827', '0828' ) --, '082A', '082B', '082C', '082D', '082E')
			OR rc.RevenueCode IN ('0651','0652','0655','0656','0657')

UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id 15 Hospice claims',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
	JOIN #FinalMemberClaimSupp s ON c.Source_System_Number = s.Source_System_Number AND c.Member_ID = s.Member_ID
		AND c.SOS_Filter = 15 AND c.SOS_HOLD_Flag IN ( 'Y', 'D')
	JOIN dbo.Supplemental_INPUT c1 ON c1.Source_System_Number = s.CorrClaimID
			AND c.From_Date BETWEEN DATEADD(YEAR, -1, c1.From_Date) AND DATEADD(YEAR, 1, c1.From_Date)
	LEFT JOIN [EDPS_Data].[dbo].[ClaimLineRevenueCodeDim] rc ON s.CorrClaimID = rc.ClaimID
WHERE s.BILL_TYPE_CODE IN ('0810', '0811', '0812', '0813', '0814', '0817', '0818', --'081A', '081B', '081C', '081D', '081E',
						   '0820', '0821', '0822', '0823', '0824', '0827', '0828' ) --, '082A', '082B', '082C', '082D', '082E')
			OR rc.RevenueCode IN ('0651','0652','0655','0656','0657')

		

UPDATE r
SET r.Hold_Flag = CASE WHEN r.Hold_Flag = 'Y' THEN 'N' WHEN r.Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = r1.claimid,
	--r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate = GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 15 with Proc or Dx Code' ,
	r.Retraction_Resub_Date = CASE WHEN r.Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		--JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
		--	AND f.FilterID = '15'
		JOIN [dbo].[EDS_Claims_Master_Recon] r1 ON r1.memberid = r.memberid 
			AND CONVERT(VARCHAR, r.BeginServiceDate,101) BETWEEN DATEADD(YEAR, -1, CONVERT(VARCHAR, r1.BeginServiceDate,101)) AND DATEADD(YEAR, 1, CONVERT(VARCHAR, r1.BeginServiceDate,101))
					AND r.FilterID = 15 AND r.Hold_Flag IN ('Y', 'D')
		JOIN EDPS_Data.dbo.ClaimDetaildim cd ON cd.Claimid = r1.ClaimID 
		JOIN EDPS_Data.dbo.CLAIMDIAGNOSISDIM cdd ON cd.CLAIMID = cdd.claimid
		LEFT JOIN dbo.EDS_SOS_Corroboration_ProcedureCodes c1 ON cd.ProcedureCode = c1.ProcCode
		LEFT JOIN dbo.EDS_SOS_Corroboration_ProcedureCodes c2 ON REPLACE(cdd.DIAGNOSISCODE,'.','') = c2.DxCode
WHERE c1.ProcCode IS NOT NULL OR c2.DxCode  IS NOT NULL


UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter id 15 with Proc or Dx Code',
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM dbo.Supplemental_INPUT c 
	JOIN dbo.Supplemental_INPUT c1 ON c1.Member_ID = c.Member_ID
			AND c.From_Date BETWEEN DATEADD(YEAR, -1, c1.From_Date) AND DATEADD(YEAR, 1, c1.From_Date)
				AND c.SOS_Filter = 15 AND c.SOS_HOLD_Flag IN ( 'Y', 'D')
		JOIN EDPS_Data.dbo.ClaimDetaildim cd ON cd.Claimid = c1.Source_System_Number 
		--JOIN EDPS_Data.dbo.CLAIMDIAGNOSISDIM cdd ON cd.CLAIMID = cdd.claimid
		LEFT JOIN dbo.EDS_SOS_Corroboration_ProcedureCodes pc1 ON cd.ProcedureCode = pc1.ProcCode
		LEFT JOIN dbo.EDS_SOS_Corroboration_ProcedureCodes pc2 ON c1.Dx_Code = pc2.DxCode
WHERE pc1.ProcCode IS NOT NULL OR pc2.DxCode  IS NOT NULL

UPDATE r
SET r.Hold_Flag = CASE WHEN r.Hold_Flag = 'Y' THEN 'N' WHEN r.Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = f.claimid,
	r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate = GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 15 Hospice claims',
	r.Retraction_Resub_Date = CASE WHEN r.Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
			AND f.FilterID = '15' AND r.Hold_Flag IN ('Y', 'D')
		JOIN [dbo].[EDS_Claims_Master_Recon] r1 ON r1.claimID = f.ClaimID 
			AND CONVERT(VARCHAR, r.BeginServiceDate,101) BETWEEN DATEADD(YEAR, -1, CONVERT(VARCHAR, r1.BeginServiceDate,101)) AND DATEADD(YEAR, 1, CONVERT(VARCHAR, r1.BeginServiceDate,101))
		LEFT JOIN EDPS_Data.dbo.encounterclaimdim rc ON f.ClaimID = rc.ClaimNum 
WHERE f.BILL_TYPE_CODE IN ('0810', '0811', '0812', '0813', '0814', '0817', '0818', --'081A', '081B', '081C', '081D', '081E',
						   '0820', '0821', '0822', '0823', '0824', '0827', '0828' ) --, '082A', '082B', '082C', '082D', '082E')
			OR rc.RevenueCode IN ('0651','0652','0655','0656','0657')

UPDATE r
SET r.Hold_Flag = CASE WHEN r.Hold_Flag = 'Y' THEN 'N' WHEN r.Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = r1.claimid,
	--r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate = GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 15 with Proc or Dx Code',
	r.Retraction_Resub_Date = CASE WHEN r.Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		--JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
		--	AND f.FilterID = '15'
		JOIN [dbo].[EDS_Claims_Master_Recon] r1 ON r1.memberid = r.memberid 
			AND CONVERT(VARCHAR, r.BeginServiceDate,101) BETWEEN DATEADD(YEAR, -1, CONVERT(VARCHAR, r1.BeginServiceDate,101)) AND DATEADD(YEAR, 1, CONVERT(VARCHAR, r1.BeginServiceDate,101))
					AND r.FilterID = 15 AND r.Hold_Flag IN ('Y', 'D')
		JOIN (SELECT Claimnum, diagnosiscode, SourceDataKey, LoadDateKey,ProcedureCode FROM
			(	SELECT Claimnum, LoadDateKey, SourceDataKey,ProcedureCode, DX1 , DX2 , DX3 , DX4 , DX5 , DX6 , DX7 , DX8 , DX9 , DX10
				FROM EDPS_Data.dbo.encounterclaimdim 
				 ) p
			UNPIVOT
			( diagnosiscode for DXCode IN
				(DX1 , DX2 , DX3 , DX4 , DX5 , DX6 , DX7 , DX8 , DX9 , DX10)
			) AS upvt
					WHERE upvt.diagnosiscode <> '') cdd ON cdd.ClaimNum = r1.ClaimID
		LEFT JOIN dbo.EDS_SOS_Corroboration_ProcedureCodes c1 ON cdd.ProcedureCode = c1.ProcCode
		LEFT JOIN dbo.EDS_SOS_Corroboration_ProcedureCodes c2 ON REPLACE(cdd.DIAGNOSISCODE,'.','') = c2.DxCode
WHERE c1.ProcCode IS NOT NULL OR c2.DxCode  IS NOT NULL

UPDATE r
SET r.Hold_Flag = CASE WHEN r.Hold_Flag = 'Y' THEN 'N' WHEN r.Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = r1.claimid,
	--r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate = GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 15 with Proc or Dx Code',
	r.Retraction_Resub_Date = CASE WHEN r.Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		--JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
		--	AND f.FilterID = '15'
		JOIN [dbo].[EDS_Claims_Master_Recon] r1 ON r1.memberid = r.memberid 
			AND CONVERT(VARCHAR, r.BeginServiceDate,101) BETWEEN DATEADD(YEAR, -1, CONVERT(VARCHAR, r1.BeginServiceDate,101)) AND DATEADD(YEAR, 1, CONVERT(VARCHAR, r1.BeginServiceDate,101))
					AND r.FilterID = 15 AND r.Hold_Flag IN ('Y', 'D')
		JOIN EDPS_Data.dbo.ClaimDetaildim cd ON cd.Claimid = r1.ClaimID 
		JOIN EDPS_Data.dbo.CLAIMDETAILDIAGNOSISDIM cdd ON cd.CLAIMID = cdd.claimid
		LEFT JOIN dbo.EDS_SOS_Corroboration_ProcedureCodes c1 ON cd.ProcedureCode = c1.ProcCode
		LEFT JOIN dbo.EDS_SOS_Corroboration_ProcedureCodes c2 ON REPLACE(cdd.DIAGNOSISCODE,'.','') = c2.DxCode
WHERE c1.ProcCode IS NOT NULL OR c2.DxCode  IS NOT NULL

UPDATE r
SET r.Hold_Flag = CASE WHEN Hold_Flag = 'Y' THEN 'N' WHEN Hold_Flag = 'D' THEN 'R' END,
	r.Corrob_ClaimID = r1.Source_System_Number,
	--r.Corrob_Bill_Type = f.BILL_TYPE_CODE,
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release filter id 15 with supp Proc or Dx Code',
	r.Retraction_Resub_Date = CASE WHEN Hold_Flag = 'D' THEN GETDATE() END 
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN dbo.Supplemental_INPUT  r1 ON r1.Member_ID = r.memberid 
			AND CONVERT(VARCHAR, r.BeginServiceDate,101) BETWEEN DATEADD(YEAR, -1, CONVERT(VARCHAR, r1.From_Date,101)) AND DATEADD(YEAR, 1, CONVERT(VARCHAR, r1.From_Date,101))
					AND r.FilterID = 15 AND r.Hold_Flag IN ('Y', 'D')
		JOIN EDPS_Data.dbo.ClaimDetaildim cd ON cd.Claimid = r1.Source_System_Number 
		JOIN EDPS_Data.dbo.CLAIMDETAILDIAGNOSISDIM cdd ON cd.CLAIMID = cdd.claimid
		LEFT JOIN dbo.EDS_SOS_Corroboration_ProcedureCodes c1 ON cd.ProcedureCode = c1.ProcCode
		LEFT JOIN dbo.EDS_SOS_Corroboration_ProcedureCodes c2 ON REPLACE(cdd.DIAGNOSISCODE,'.','') = c2.DxCode
WHERE c1.ProcCode IS NOT NULL OR c2.DxCode  IS NOT NULL

	--  filterID 4

					SELECT A.memberid AS MEM_ID, A.claimid AS CLM_NO, A.sourcedatakey AS CLMSOURCE, A.BillingProvNPI AS  PROVIDER_NPI
						--,A.MEDICARE_NO, A.PROV_TYPE
					INTO #TEMP
					FROM WIPRO.[dbo].[EDS_Claims_Master_Recon] A
					WHERE A.FilterID = 4 AND A.Hold_Flag IN ('Y', 'D') AND A.memberid <> '00000001'
					
				 
				-- Gather all the rows to make the appropriate calculations from the Master Claims Archive table

					SELECT 
						DISTINCT 
						A.MEM_ID						
						,D.memberid MEMID_ARCHIVE
						,D.BillingProvNPI PROVID_ARCHIVE
						,D.claimid CLMNO_ARCHIVE
						INTO #TEMP2
					FROM #TEMP A
					JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon_ARCHIVE] D
						ON D.memberid = A.MEM_ID
						AND A.CLM_NO <> D.Claimid -- added as per RT 3455
					--JOIN #FinalMemberClaim f ON a.MEM_ID = f.memberid AND a.CLM_NO = f.HeldClaimID
					JOIN dbo.DX_COMPLIANCE_HOLD h ON a.MEM_ID = h.MEM_ID AND a.CLM_NO <> h.CLM_NO
					WHERE EXISTS (
									SELECT 1
									FROM  dbo.[EDS_RAPS_DX_RESEARCH_XREF] B
									WHERE REPLACE(B.DxCode,'.','') = REPLACE(h.DIAGNOSIS_CODE,'.','')
									AND B.HCC_LOGIC_VALUE = '110'
								)

										
					INSERT INTO #TEMP2					
					SELECT DISTINCT 
						A.MEM_ID						
						,D.memberid MEMID_ARCHIVE
						,D.BillingProvNPI PROVID_ARCHIVE
						,D.claimid CLMNO_ARCHIVE
					FROM #TEMP A
					JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] D
						ON D.memberid = A.MEM_ID
						AND A.CLM_NO <> D.Claimid -- added as per RT 3455
					--JOIN #FinalMemberClaim f ON a.MEM_ID = f.memberid AND a.CLM_NO = f.HeldClaimID
					JOIN dbo.DX_COMPLIANCE_HOLD h ON a.MEM_ID = h.MEM_ID AND a.CLM_NO <> h.CLM_NO
					WHERE EXISTS (
									SELECT 1
									FROM  dbo.[EDS_RAPS_DX_RESEARCH_XREF] B
									WHERE REPLACE(B.DxCode,'.','') = REPLACE(h.DIAGNOSIS_CODE,'.','')
									AND B.HCC_LOGIC_VALUE = '110'
								)
				
				-- Get the count per member of how many providers they have seen and claims they have filed

					SELECT 
						MEM_ID
						,MEMID_ARCHIVE,PROVID_ARCHIVE,CLMNO_ARCHIVE
						,DENSE_RANK() OVER (PARTITION BY MEM_ID ORDER BY PROVID_ARCHIVE) PROVIDER_CNT
						,DENSE_RANK() OVER (PARTITION BY MEM_ID ORDER BY CLMNO_ARCHIVE) CLAIM_CNT
						INTO #TEMP3
					FROM #TEMP2
					WHERE COALESCE(PROVID_ARCHIVE,'') <> ''

					SELECT 
						DISTINCT
						MEM_ID
						,MEMID_ARCHIVE,PROVID_ARCHIVE,CLMNO_ARCHIVE
						INTO #TEMP4
					FROM #TEMP3
					WHERE CLAIM_CNT>=15
				
				-- Get Member that has seen more than 2 providers

					SELECT 
						DISTINCT
						MEM_ID
						,MEMID_ARCHIVE,PROVID_ARCHIVE,CLMNO_ARCHIVE
						INTO #TEMP5
					FROM #TEMP3
					WHERE PROVIDER_CNT>=2
				
				-- Validate the Members that is 35 years or younger that has more than 15 claims and seen more than 2 providers

					SELECT 
						DISTINCT
						MEM_ID, CLM_NO, CLMSOURCE,PROVIDER_NPI
						--,MEDICARE_NO, PROV_TYPE
						INTO #TEMP6
					FROM #TEMP A -- Original table that validated if the member was 35 years or younger
					WHERE EXISTS (	
									SELECT	
										1
									FROM #TEMP4 B
									WHERE B.MEM_ID = A.MEM_ID
								)
					AND EXISTS (	
									SELECT	
										1
									FROM #TEMP5 C
									WHERE C.MEM_ID = A.MEM_ID
								) 
				
UPDATE A
SET a.Hold_Flag = CASE WHEN a.Hold_Flag = 'Y' THEN 'N' WHEN a.Hold_Flag = 'D' THEN 'R' END,
	a.ReleaseDate = GETDATE(),
	a.ReleaseStatusDescription = 'release filter id 4',
	a.Retraction_Resub_Date = CASE WHEN a.Hold_Flag = 'D' THEN GETDATE() END 			
FROM WIPRO.[dbo].[EDS_Claims_Master_Recon] A
		JOIN #TEMP6 B
			ON B.CLM_NO = A.claimid
			AND B.MEM_ID = A.memberid
				-- WHERE A.FilterID = 4

UPDATE h
SET h.RELEASED_FOR_PROCESS_DATE = GETDATE(),
	h.HOLD_TABLE_STATUS = 30,
	h.HOLD_DATE = NULL,
	h.status_code_desc = 'Released Corrob Inpt BillType Claim : ' + m.Claimid 
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN #FinalMemberClaim m 
		ON h.MEM_ID = m.memberid 
			AND h.CLM_NO = m.HeldClaimID			
		JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] r
		 ON r.memberid =  h.MEM_ID AND r.claimid = h.CLM_NO
			AND r.Hold_Flag = 'N'
			AND h.HOLD_DATE IS NOT NULL 

UPDATE h
SET	h.Retraction_Resub_Date = r.ReleaseDate, 
	h.HOLD_TABLE_STATUS = 23, 
	h.HOLD_STATUS_DESC = ISNULL(r.ReleaseStatusDescription,'release of filter ' + r.FilterID ),
	h.RETRACTION_FLAG = NULL,
	h.STATUS_CODE_DESC = ISNULL(r.ReleaseStatusDescription,'release of filter ' + r.FilterID ),
	h.RELEASED_FOR_PROCESS_DATE = r.ReleaseDate
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] r
		 ON r.memberid = h.MEM_ID AND r.claimid = h.CLM_NO
			AND h.Retraction_Resub_Date IS NULL 
			AND r.Hold_Flag = 'R'

-- POS 21 AND 23

UPDATE h
SET h.RELEASED_FOR_PROCESS_DATE = GETDATE(),
	h.HOLD_TABLE_STATUS = 30,
	h.HOLD_DATE = NULL,
	h.status_code_desc = 'Release POS 21/23'
FROM dbo.DX_COMPLIANCE_HOLD h
WHERE HOLD_TABLE_STATUS IN (1,16) AND [HCFA_POS_CD] IN ('21','23') AND LOGIC_FILTER IN ('1', '5', '6','7', '8', '9', '10', '12','14' ) 
		AND h.HOLD_DATE IS NOT NULL 


UPDATE A
SET	A.Hold_Flag = 'N',
	A.ReleaseDate =  GETDATE(),
	A.ReleaseStatusDescription = 'release POS 21/23'	
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] A 
		ON h.MEM_ID = a.memberid 
			AND h.CLM_NO = a.claimid
			AND NULLIF(a.Hold_Flag, 'Y') <> 'N'
			AND h.status_code_desc = 'Release POS 21/23'
			--AND h.RELEASED_FOR_PROCESS_DATE > GETDATE() - 1
			AND a.FilterID IN ('1', '5', '6','7', '8', '9', '10', '12', '14' ) 


UPDATE r
SET	r.Hold_Flag = 'N',
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release POS 21/23'		
FROM WIPRO.[dbo].[EDS_Claims_Master_Recon] r 
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
		JOIN EDPS_data.dbo.ClaimdetailDim cdd ON cdd.Claimid = f.HeldClaimID AND cdd.ServicePlaceCode IN ('21','23')
			AND NULLIF(r.Hold_Flag, 'Y')  <> 'N' 
			AND r.FilterID IN ('1', '5', '6','7', '8', '9', '10', '12', '14' ) 


UPDATE r
SET	r.Hold_Flag = 'N',
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release POS 21/23'		
FROM WIPRO.[dbo].[EDS_Claims_Master_Recon] r 
		JOIN #FinalMemberClaim f ON r.memberid = f.memberid AND r.claimid = f.HeldClaimID
		JOIN EDPS_data.dbo.encounterclaimdim cdd ON cdd.ClaimNum = f.HeldClaimID AND cdd.PlaceOfServiceCode IN ('21','23')
			AND NULLIF(r.Hold_Flag, 'Y')  <> 'N' 
			AND r.FilterID IN ('1', '5', '6','7', '8', '9', '10', '12', '14' ) 


UPDATE r 
SET r.Hold_Flag = 'N',
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'release SUPP data',
	r.Corrob_ClaimID = c.Source_System_Number	
FROM [dbo].[EDS_Claims_Master_Recon] r
		JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
		ON r.BeginServiceDate BETWEEN CONVERT(VARCHAR,x.DOS_START,112) AND CONVERT(VARCHAR,x.FILTER_ENDDATE,112)
			AND x.LOGIC_FILTER = r.FilterID
		JOIN dbo.Supplemental_INPUT c
			ON c.Member_ID = r.memberid
				AND c.Chart_Chase_NPI = CASE WHEN c.Chart_Chase_NPI = r.RenderingProvNPI THEN r.RenderingProvNPI ELSE r.BillingProvNPI END
				AND CONVERT(VARCHAR,c.Thru_Date,112) = r.EndServiceDate
				AND r.Hold_Flag IN ('Y', 'D')
				AND r.FilterID IN (1,5,6,7,8,9,10,12,14,16)
				AND c.Dx_Code = x.DxCode
				--AND r.ClaimType = 'P'


UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release SUPP data from recon',
	c.SOS_Filter = r.FilterID,
	C.SOS_HOLD_Date = CASE WHEN C.SOS_HOLD_Date IS NULL THEN GETDATE() END
FROM [dbo].[EDS_Claims_Master_Recon] r
		--JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
		--ON r.BeginServiceDate BETWEEN CONVERT(VARCHAR,x.DOS_START,112) AND CONVERT(VARCHAR,x.FILTER_ENDDATE,112)
		--	AND x.LOGIC_FILTER = r.FilterID
		JOIN dbo.Supplemental_INPUT c
			ON c.Member_ID = r.memberid
				AND c.Chart_Chase_NPI = CASE WHEN c.Chart_Chase_NPI = r.RenderingProvNPI THEN r.RenderingProvNPI ELSE r.BillingProvNPI END
				AND CONVERT(VARCHAR,c.Thru_Date,112) = r.EndServiceDate
				AND NULLIF(c.SOS_HOLD_FLAG,'Y') IS NULL 
				AND r.FilterID IN (1,5,6,7,8,9,10,12,14,16)
				--AND c.Dx_Code = x.DxCode
				--AND r.ClaimType = 'P'
			--	AND c.Process_Date > @PreviousRefreshDate


UPDATE h
SET h.RELEASED_FOR_PROCESS_DATE = GETDATE(),
	h.HOLD_TABLE_STATUS = 30,
	h.HOLD_DATE = NULL,
	h.status_code_desc = 'release SUPP/Recon data ' + r.Corrob_ClaimID 
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] r
		 ON r.memberid =  h.MEM_ID AND r.claimid = h.CLM_NO
			AND r.Hold_Flag = 'N'
			AND r.ReleaseStatusDescription = 'release SUPP data'	
			AND h.HOLD_DATE IS NOT NULL 

-- release filter 4 of SUPP data

 SELECT DISTINCT c.Member_ID AS MemberID, c.Source_System_Number AS ClaimID 
 INTO #TEMPC
					FROM dbo.Supplemental_INPUT c
						JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
							ON c.From_Date BETWEEN CONVERT(VARCHAR,x.DOS_START,112) AND CONVERT(VARCHAR,x.FILTER_ENDDATE,112)
								AND X.LOGIC_FILTER = 4
								AND c.Dx_Code = x.DxCode 
								AND c.SOS_HOLD_Flag IS NULL	
				
				-- Gather all the rows to make the appropriate calculations from the Master Claims Archive table

					SELECT 
						DISTINCT 
						A.MemberID						
						,D.memberid MEMID_ARCHIVE
						,D.BillingProvNPI PROVID_ARCHIVE
						,D.claimid CLMNO_ARCHIVE
						INTO #TEMPC2
					FROM #TEMPC A
					JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon_ARCHIVE] D
						ON D.memberid = A.MemberID
						AND A.ClaimID <> D.Claimid 
					JOIN dbo.DX_COMPLIANCE_HOLD h ON a.MemberID = h.MEM_ID AND a.ClaimID <> h.CLM_NO
					WHERE EXISTS (
									SELECT 1
									FROM  dbo.[EDS_RAPS_DX_RESEARCH_XREF] B
									WHERE REPLACE(B.DxCode,'.','') = REPLACE(h.DIAGNOSIS_CODE,'.','')
									AND B.HCC_LOGIC_VALUE = '110'
								)
					UNION
					SELECT 
						DISTINCT 
						A.MemberID						
						,D.memberid MEMID_ARCHIVE
						,D.BillingProvNPI PROVID_ARCHIVE
						,D.claimid CLMNO_ARCHIVE
					FROM #TEMPC A
					JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] D
						ON D.memberid = A.MemberID
						AND A.ClaimID <> D.Claimid 
					JOIN dbo.DX_COMPLIANCE_HOLD h ON a.MemberID = h.MEM_ID AND a.ClaimID <> h.CLM_NO
					WHERE EXISTS (
									SELECT 1
									FROM  dbo.[EDS_RAPS_DX_RESEARCH_XREF] B
									WHERE REPLACE(B.DxCode,'.','') = REPLACE(h.DIAGNOSIS_CODE,'.','')
									AND B.HCC_LOGIC_VALUE = '110'
								)
				
				-- Get the count per member of how many providers they have seen and claims they have filed

					SELECT 
						MemberID
						,MEMID_ARCHIVE,PROVID_ARCHIVE,CLMNO_ARCHIVE
						,DENSE_RANK() OVER (PARTITION BY MemberId ORDER BY PROVID_ARCHIVE) PROVIDER_CNT
						,DENSE_RANK() OVER (PARTITION BY MemberId ORDER BY CLMNO_ARCHIVE) CLAIM_CNT
						INTO #TEMPC3
					FROM #TEMPC2
					WHERE COALESCE(PROVID_ARCHIVE,'') <> ''
				

					SELECT 
						DISTINCT
						MemberID
						,MEMID_ARCHIVE,PROVID_ARCHIVE,CLMNO_ARCHIVE
						INTO #TEMPC4
					FROM #TEMPC3
					WHERE CLAIM_CNT>=15
				
				-- Get Member that has seen more than 2 providers

					SELECT 
						DISTINCT
						MemberID
						,MEMID_ARCHIVE,PROVID_ARCHIVE,CLMNO_ARCHIVE
					INTO #TEMPC5
					FROM #TEMPC3
					WHERE PROVIDER_CNT>=2
				
				-- Validate the Members that is 35 years or younger that has more than 15 claims and seen more than 2 providers

					SELECT 
						DISTINCT
						MemberID, ClaimID --, CLMSOURCE,PROVIDER_NPI
						--,MEDICARE_NO, PROV_TYPE
						INTO #TEMPC6
					FROM #TEMPC A -- Original table that validated if the member was 35 years or younger
					WHERE EXISTS (	
									SELECT	
										1
									FROM #TEMPC4 B
									WHERE B.MemberID = A.MemberID
								)
					AND EXISTS (	
									SELECT	
										1
									FROM #TEMPC5 C
									WHERE C.MemberID = A.MemberID
								) 
				
UPDATE C
SET	c.SOS_HOLD_FLAG = CASE WHEN c.SOS_HOLD_FLAG = 'D' THEN 'R' ELSE 'N' END,
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'release filter 4 SUPP from recon',
	c.SOS_Filter = 4			
FROM dbo.Supplemental_INPUT C
	JOIN #TEMPC6 B
		ON B.ClaimID = c.Source_System_Number
				AND B.MemberID = c.Member_ID

UPDATE h
SET h.RELEASED_FOR_PROCESS_DATE = GETDATE(),
	h.HOLD_TABLE_STATUS = 30,
	h.STATUS_CODE_DESC = c.SOS_Release_Status_Description
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN dbo.Supplemental_INPUT c
		ON h.MEM_ID = c.Member_ID
			AND h.CLM_NO = c.Source_System_Number
			AND h.RELEASED_FOR_PROCESS_DATE IS NULL
			AND c.SOS_HOLD_FLAG = 'N'
	
UPDATE r
SET	
	r.ReleaseDate =  GETDATE(),
	r.ReleaseStatusDescription = 'SOS Retraction Identified'		
FROM WIPRO.[dbo].[EDS_Claims_Master_Recon] r 
		WHERE r.Hold_Flag = 'Y'
			AND r.ReleaseDate IS NULL
			AND r.ReleaseStatusDescription IS NULL

UPDATE C
SET	
	c.SOS_Release_Date = GETDATE(),
	c.SOS_Release_Status_Description = 'SOS Retraction Identified'
FROM dbo.Supplemental_INPUT c
			where c.SOS_HOLD_FLAG = 'Y'
			AND c.SOS_Release_Date IS NULL
			AND c.SOS_Release_Status_Description IS NULL

UPDATE h
SET	h.STATUS_CODE_DESC = 'SOS Retraction Identified',
		h.HOLD_STATUS_DESC = 'Claim released not corroborated - retract after CMS acceptance' ,
		h.HOLD_TABLE_STATUS = 1,
		h.RELEASED_FOR_PROCESS_DATE = CONVERT(VARCHAR(10), GETDATE(),101)
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] A 
		ON h.MEM_ID = a.memberid 
			AND h.CLM_NO = a.claimid
			AND a.Hold_Flag = 'Y'  --AND a.ReleaseStatusDescription = 'release after 85 days of hold'
			AND h.STATUS_CODE_DESC IS NULL
			AND h.RELEASED_FOR_PROCESS_DATE IS NULL
			AND a.ReleaseStatusDescription = 'SOS Retraction Identified'

UPDATE h
SET	h.Retraction_Date = CONVERT(VARCHAR,GETDATE(),101), h.HOLD_TABLE_STATUS = 16, h.RETRACTION_FLAG = 1,
	h.STATUS_CODE_DESC = a.ReleaseStatusDescription
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] A 
		ON h.MEM_ID = a.memberid 
			AND h.CLM_NO = a.claimid
			AND a.Hold_Flag = 'Y'  
			AND Claim_Status = 'A-ICN'
			AND h.Retraction_Date IS NULL
			AND a.ReleaseStatusDescription = 'SOS Retraction Identified'

UPDATE a
SET a.Retraction_Date = CONVERT(VARCHAR,GETDATE(),101), a.hold_flag = 'D'
FROM [dbo].[EDS_Claims_Master_Recon] a
WHERE Hold_Flag = 'Y' 
		AND a.Claim_Status = 'A-ICN'
		AND a.Retraction_Date IS NULL
		AND a.ReleaseStatusDescription = 'SOS Retraction Identified'

UPDATE c		
SET c.Retraction_Date = CONVERT(VARCHAR,GETDATE(),101), c.sos_hold_flag = 'D' 
FROM dbo.Supplemental_INPUT c
	JOIN dbo.Supplemental_OUTPUT o
		ON c.HIC_NO = o.HIC_NBR
			AND c.Source_System_Number = o.HS_CLAIM_NBR
			AND c.Dx_Code = o.DIAG01_CODE
WHERE c.SOS_HOLD_FLAG = 'Y'  
		AND (Response_Status_Reserverd_1 = 'A-ICN' OR RSP_MAO002 = 'A-ICN')
		AND c.Retraction_Date IS NULL
		AND  c.SOS_Release_Status_Description = 'SOS Retraction Identified'

UPDATE C
SET	c.SOS_HOLD_FLAG = 'R',
	c.Retraction_Resub_Date = GETDATE()
FROM [dbo].[EDS_Claims_Master_Recon] r
		--JOIN dbo.[EDS_RAPS_DX_RESEARCH_XREF] x
		--ON r.BeginServiceDate BETWEEN CONVERT(VARCHAR,x.DOS_START,112) AND CONVERT(VARCHAR,x.FILTER_ENDDATE,112)
		--	AND x.LOGIC_FILTER = r.FilterID
		JOIN dbo.Supplemental_INPUT c
			ON c.Member_ID = r.memberid
				AND c.Chart_Chase_NPI = CASE WHEN c.Chart_Chase_NPI = r.RenderingProvNPI THEN r.RenderingProvNPI ELSE r.BillingProvNPI END
				AND CONVERT(VARCHAR,c.Thru_Date,112) = r.EndServiceDate
				AND r.Hold_Flag = 'R'
				AND c.SOS_HOLD_FLAG = 'D'
				AND r.FilterID IN (1,5,6,7,8,9,10,12,14,16)
				--AND c.Dx_Code = x.DxCode

UPDATE h
SET	h.Retraction_Resub_Date = c.Retraction_Resub_Date, 
	h.HOLD_TABLE_STATUS = 23, 
	h.HOLD_STATUS_DESC = ISNULL(r.ReleaseStatusDescription,'release of filter ' + r.FilterID ),
	h.RETRACTION_FLAG = NULL,
	h.STATUS_CODE_DESC = ISNULL(r.ReleaseStatusDescription,'release of filter ' + r.FilterID ),
	h.RELEASED_FOR_PROCESS_DATE = c.Retraction_Resub_Date
FROM dbo.DX_COMPLIANCE_HOLD h
		JOIN dbo.Supplemental_INPUT c
		ON h.MEM_ID = c.Member_ID
			AND h.CLM_NO = c.Source_System_Number
			AND h.Retraction_Resub_Date IS NULL
			AND c.SOS_HOLD_FLAG = 'R'
		JOIN WIPRO.[dbo].[EDS_Claims_Master_Recon] r
		ON c.Member_ID = r.memberid
				AND c.Chart_Chase_NPI = CASE WHEN c.Chart_Chase_NPI = r.RenderingProvNPI THEN r.RenderingProvNPI ELSE r.BillingProvNPI END
				AND CONVERT(VARCHAR,c.Thru_Date,112) = r.EndServiceDate