﻿
CREATE PROC LeonAdjustmentInput
AS

/***************************************************************************************************
** CREATE DATE: 04/12/2020
**
** AUTHOR: SUBHASH ACHARYA
**
** DESCRIPTION: Leon File
**              
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------
04/12/2020		SUBHASH ACHARYA   Initial Creation

EXEC LeonAdjustmentInput
																    
\\hsnas3.healthspring.inside\deptshares\DPPRVREL\MDQO\EDPS\FROMWIPRO\EDS\Leon_Adjustments\LEON_INPUT_DEV
\\hsnas3.healthspring.inside\deptshares\DPPRVREL\MDQO\EDPS\FROMWIPRO\EDS\Leon_Adjustments\LEON_INPUT_QA
\\hsnas3.healthspring.inside\deptshares\DPPRVREL\MDQO\EDPS\FROMWIPRO\EDS\Leon_Adjustments\LEON_INPUT_PROD

Email notification
HS_MDQOEDSSupport <MDQOEDSSupport@cigna.com>
For DEV testing 
	
Deanna.Reed@healthspring.com	
Dinh.Phan@Cigna.com	
Subhash.Acharya@healthspring.com	
Ashwini.Maravanthe@healthspring.com	

Email notification Subject	Leon Adjustment File for MMDDYY created successfully		
Email notification body/content	File Name : LEON_AdjustmentFile_MMDDYYYY.Timestamp.csv		
	File Location: nice to have.. If it takes additonal effort this is not required		
	No of records: XX (provide count of the records in the file)	
	
As discussed please accommodate the following changes,
1. Change the column names in Input and archive table for Status and Status Code. Rename it to Status_code and Status_description resprectively
2. Import of Archive data to PROD (we will provide you the data in spreadsheet in Archive table format)
3. Modify logic for Status desc = Adj_ClaimId_duplicate. 
Set Status = 1_Adj_ClaimId_duplicate to previous file
IF the Adj_Claim_id in input file was present LEON_ADJUSTMENTS_INPUT_Archive table with Status_code 3 
		
select count(*) from LEON_ADJUSTMENTS_INPUT_ARCHIVE  --47141
select count(*) from LEON_ADJUSTMENTS_INPUT			 --73675

**********************************************************************************************************************************************/

INSERT into LEON_ADJUSTMENTS_INPUT_ARCHIVE
	(ADJ_CLAIM_ID,ORIGINAL_CLAIM_ID,ORIGINAL_CLM_STATUS,ADJ_CLM_DOSYR,Status_code,Status_description,[Process_Date],Archive_Date)
SELECT 
       ADJ_CLAIM_ID,
       ORIGINAL_CLAIM_ID,
       ORIGINAL_CLM_STATUS,
       ADJ_CLM_DOSYR,
       Status_code,
       Status_description,
       Process_Date,
	   GETDATE() AS Archive_Date
FROM dbo.LEON_ADJUSTMENTS_INPUT

TRUNCATE TABLE LEON_ADJUSTMENTS_INPUT

INSERT INTO dbo.LEON_ADJUSTMENTS_INPUT
(
    ADJ_CLAIM_ID,   
    ORIGINAL_CLAIM_ID, 
    ORIGINAL_CLM_STATUS, --update 
    ADJ_CLM_DOSYR,		 --update 
    Status_code,				 --update 
    Status_description,			 --update 
    Process_Date
)
SELECT 
--TOP 10 
 H.claim_id AS ADJ_CLAIM_ID
,CONCAT(LEFT(H.claim_id,DATALENGTH(H.claim_id)-2),'00') AS ORIGINAL_CLAIM_ID
,NULL AS ORIGINAL_CLM_STATUS
,NULL AS ADJ_CLM_DOSYR
,NULL AS Status_code
,NULL AS Status_description
,GETDATE() AS Process_Date
FROM [EXT_CLAIM_EXCLUSION_HIST] H
Where H.SOURCEDATAKEY = '30' And H.Excl_id = '9019'



--update ADJ_CLM_DOSYR
UPDATE le
SET le.ADJ_CLM_DOSYR = LEFT(Cd.BeginServiceDateKey,4)
--SELECT TOP 10 le.*,LEFT(Cd.BeginServiceDateKey,4) AS ADJ_CLM_DOSYR
--SELECT COUNT(*)   --73673
FROM dbo.LEON_ADJUSTMENTS_INPUT Le
LEFT JOIN [EDPS_Data].[dbo].[CLAIMDIM] cd
	ON le.ADJ_CLAIM_ID = cd.CLAIMID
WHERE le.ADJ_CLM_DOSYR  IS NULL


;WITH CTE AS	
(
SELECT * FROM 
(
SELECT 
le.*, os.CLMSTAT_STATUS, os.LAST_UPD_DATE, ROW_NUMBER() OVER (PARTITION BY os.CLAIM_ID ORDER BY os.LAST_UPD_DATE DESC) AS rownum
FROM dbo.LEON_ADJUSTMENTS_INPUT Le
LEFT JOIN [WIPRO].[dbo].[OUTB_CLAIM_STATUS] Os
	ON le.ORIGINAL_CLAIM_ID = os.CLAIM_ID
--WHERE Os.LAST_UPD_DATE IS NOT null
) z WHERE z.rownum = 1
)
UPDATE CTE SET cte.ORIGINAL_CLM_STATUS = CTE.CLMSTAT_STATUS


/*
ORIGINAL_CLM_STATUS	Varchar (50)	"[WIPRO].[dbo].[OUTB_CLAIM_STATUS].CLMSTAT_STATUS
Where ORIGINAL_CLM_ID = [WIPRO].[dbo].[OUTB_CLAIM_STATUS].CLAIM_ID
(Take the CLMSTAT_STATUS of max last update date)
"
*/

--SELECT * FROM dbo.LEON_ADJUSTMENTS_INPUT 
UPDATE dbo.LEON_ADJUSTMENTS_INPUT 
SET Status_code = '0',Status_description = 'PSY_Claim_Excluded'
WHERE ADJ_CLAIM_ID LIKE 'PSY%'
AND Status_code IS NULL

UPDATE dbo.LEON_ADJUSTMENTS_INPUT 
SET Status_code = '1',Status_description = 'Adj_ClaimId_duplicate'
--SELECT * FROM dbo.LEON_ADJUSTMENTS_INPUT 
WHERE ADJ_CLAIM_ID IN (SELECT ADJ_CLAIM_ID FROM LEON_ADJUSTMENTS_INPUT_ARCHIVE WHERE status_code = '3')
AND Status_code IS NULL

UPDATE dbo.LEON_ADJUSTMENTS_INPUT 
SET Status_code = '2',Status_description = 'Orig_Claimid not Accepted'
--SELECT * FROM dbo.LEON_ADJUSTMENTS_INPUT 
WHERE ISNULL(ORIGINAL_CLM_STATUS,'' ) NOT IN ('A-ICN','MAO-004')
AND Status_code IS NULL

UPDATE dbo.LEON_ADJUSTMENTS_INPUT 
SET Status_code = '3',Status_description = 'Adj_ClaimId_for Leon Review'
--SELECT * FROM dbo.LEON_ADJUSTMENTS_INPUT 
WHERE 1 = 1
AND Status_code IS NULL

/*
UPDATE dbo.LEON_ADJUSTMENTS_INPUT 
SET Status = NULL,StatusCode = NULL

SELECT * FROM LEON_ADJUSTMENTS_INPUT  --2 rows
WHERE Status = '0'


SELECT * FROM LEON_ADJUSTMENTS_INPUT  --5 rows
WHERE Status = '3'

" Extract data from [EXT_CLAIM_EXCLUSION_HIST] 
Where Source = 30 And Excl_id = 9019"


ADJ_CLAIM_ID	Varchar (50)	[WIPRO].[dbo].[EXT_CLAIM_EXCLUSION_HIST].claim_id 
ORIGINAL_CLAIM_ID	Varchar (50)	"Logic to poulate original claimid is to remove last two digit and suffix 00 to the adjusted claim
										EG:
										ADJ_CLAIM_ID = 150060024701
										Original Claimid = 150060024700"
ORIGINAL_CLM_STATUS	Varchar (50)	"[WIPRO].[dbo].[OUTB_CLAIM_STATUS].CLMSTAT_STATUS
									Where ORIGINAL_CLM_ID = [WIPRO].[dbo].[OUTB_CLAIM_STATUS].CLAIM_ID
									(Take the CLMSTAT_STATUS of max last update date)
									"
ADJ_CLM_DOSYR	Varchar (10)	"[EDPS_Data].[dbo].[CLAIMDIM].BeginServiceDateKey
									Where ADJ_CLAIM_ID = [EDPS_Data].[dbo].[CLAIMDIM].CLAIM_ID

							(Need only the DOSYR from beginservicedate key LEFT(BeginServiceDateKey, 4) AS ExtractString"
Status	Varchar (50)	Set Status = 0_PSY_Claim_Excluded If ADJ_Claim_id in input table begins with PSY
								"Set Status = 1_Adj_ClaimId_duplicate to previous file
						IF the Adj_Claim_id in input file was present  LEON_ADJUSTMENTS_INPUT_Archive table "
								Set Status = 2_Orig_Claimid not Accepted if ORIGINAL_CLM_STATUS in input table is notA-ICN or MAO004
								"Set Status = 3_Adj_ClaimId_for Leon Review
						after status 0,1,2 markt he rest as Status 3"
Process Date				Date 	Date the job was run for file creation

Set Status = 0_PSY_Claim_Excluded If ADJ_Claim_id in input table begins with PSY	0_PSY_Claim_Excluded
"Set Status = 1_Adj_ClaimId_duplicate to previous file
IF the Adj_Claim_id in input file was present  LEON_ADJUSTMENTS_INPUT_Archive table "	1_Adj_ClaimId_duplicate to previous file
Set Status = 2_Orig_Claimid not Accepted if ORIGINAL_CLM_STATUS in input table is notA-ICN or MAO004	2_Orig_Claimid not Accepted
"Set Status = 3_Adj_ClaimId_for Leon Review
after status 0,1,2 markt he rest as Status 3"	3_Adj_ClaimId_for Leon Review

SELECT * FROM LEON_ADJUSTMENTS_INPUT_ARCHIVE

SELECT  '180090185601'
,REPLACE('180090185601', SUBSTRING('180090185601', len('180090185601') - 1, 2), '00') AS ORIGINAL_CLAIM_ID
, SUBSTRING(REVERSE('180090185601'),1,2)
, REVERSE(REPLACE(REVERSE('180090185601'),SUBSTRING(REVERSE('180090185601'),1,2),'00'))
,CONCAT(LEFT('180090185601',DATALENGTH('180090185601')-2),'00')
SELECT SUBSTRING(Status, 3,100)
FROM LEON_ADJUSTMENTS_INPUT_ARCHIVE
WHERE ADJ_CLAIM_ID IS NOT NULL

UPDATE LEON_ADJUSTMENTS_INPUT_ARCHIVE
SET Process_Date  = GETDATE()
, Archive_Date = GETDATE()


UPDATE LEON_ADJUSTMENTS_INPUT_ARCHIVE
SET StatusCode = LEFT(Status,1)

UPDATE LEON_ADJUSTMENTS_INPUT_ARCHIVE
SET Status =  SUBSTRING(Status, 3,100)

SELECT * FROM dbo.LEON_ADJUSTMENTS_INPUT
WHERE ADJ_CLAIM_ID = '180090185601'


SELECT * , ROW_NUMBER() OVER (PARTITION BY H.claim_id ORDER BY H.BATCH_RUN_DT DESC ) 
FROM [EXT_CLAIM_EXCLUSION_HIST] H
Where H.SOURCEDATAKEY = '30' And H.Excl_id = '9019'
ORDER BY ROW_NUMBER() OVER (PARTITION BY H.claim_id ORDER BY H.BATCH_RUN_DT DESC )  desc

SELECT * FROM dbo.LEON_ADJUSTMENTS_INPUT
WHERE ADJ_CLAIM_ID IN
(
'190660113701',
'190740075201',
'D19161007801',
'191130002201',
'D19035003301'
)

SELECT *
FROM [EXT_CLAIM_EXCLUSION_HIST] H
Where H.SOURCEDATAKEY = '30' And H.Excl_id = '9019'
AND H.claim_id IN
(
'190660113701',
'190740075201',
'D19161007801',
'191130002201',
'D19035003301'
)

SELECT ADJ_CLAIM_ID , ROW_NUMBER() OVER ( PARTITION BY ADJ_CLAIM_ID ORDER BY Process_Date DESC) AS RwNum
FROM dbo.LEON_ADJUSTMENTS_INPUT
ORDER BY ROW_NUMBER() OVER ( PARTITION BY ADJ_CLAIM_ID ORDER BY Process_Date DESC) desc

SELECT COUNT(*)  --73673
FROM [EXT_CLAIM_EXCLUSION_HIST] H
Where H.SOURCEDATAKEY = '30' And H.Excl_id = '9019'

BEGIN TRAN

INSERT INTO [WIPRO].[dbo].[OUTB_CLAIM_STATUS] (CLAIM_ID, CLMSTAT_STATUS, LAST_UPD_DATE, EffectiveEncounterFlag)
SELECT '180030348500','A-ICN','2020-04-08 16:22:38.607','T' union all
select '180040322300','A-ICN','2020-04-08 16:22:38.607','T'	union all
select '180040434400','A-ICN','2020-04-08 16:22:38.607','T'	union all
select '180040434500','A-ICN','2020-04-08 16:22:38.607','T'	union all
select '180040434600','A-ICN','2020-04-08 16:22:38.607','T'

ROLLBACK TRAN

COMMIT TRAN

INSERT INTO [WIPRO].[dbo].[EXT_CLAIM_EXCLUSION_HIST] (claim_id, SOURCEDATAKEY, EXCL_ID, BATCH_RUN_DT)
select 'PSY111111100','30','9019','2020-04-08 16:22:38.607' UNION 
select 'PSY222222200','30','9019' ,'2020-04-08 16:22:38.607'

SELECT * FROM [WIPRO].[dbo].[EXT_CLAIM_EXCLUSION_HIST] 

status 3.
1.	Can you please INSERT below claims into  [WIPRO].[dbo].[OUTB_CLAIM_STATUS]
180030348500
180040322300
180040434400
180040434500
180040434600
SET CLMSTAT_STATUS = A-ICN
LAST_UPD_DATE = '2020-04-08 16:22:38.607'
EffectiveEncounterFlag = 'TETDM2233'

2.	Also for StatusCode 0, we need to create test data in DEV

Please insert below claims into [WIPRO].[dbo].[EXT_CLAIM_EXCLUSION_HIST] 
PSY111111100
PSY222222200

SET SOURCEDATAKEY = ‘30’
EXCL_ID = ‘9019’

COMMIT tran


INSERT INTO dbo.LEON_ADJUSTMENTS_INPUT
(
    ADJ_CLAIM_ID,   --
    ORIGINAL_CLAIM_ID, --
    ORIGINAL_CLM_STATUS,
    ADJ_CLM_DOSYR,
    Status,
    StatusCode,
    Process_Date
)
SELECT a.ADJ_CLAIM_ID,
       a.ORIGINAL_CLAIM_ID,
       a.ORIGINAL_CLM_STATUS,
       a.ADJ_CLM_DOSYR,
       a.Status,
       a.StatusCode,
       a.Process_Date
FROM 
(
SELECT --TOP 10
H.claim_id AS ADJ_CLAIM_ID
--,REPLACE(H.claim_id, SUBSTRING(H.claim_id, len(H.claim_id) - 1, 2), '00') AS ORIGINAL_CLAIM_ID
,CONCAT(LEFT(H.claim_id,DATALENGTH(H.claim_id)-2),'00') AS ORIGINAL_CLAIM_ID
,S.CLMSTAT_STATUS AS ORIGINAL_CLM_STATUS
,ROW_NUMBER() OVER (PARTITION BY h.CLAIM_ID ORDER BY S.LAST_UPD_DATE DESC) AS Rw
,LEFT(C.BeginServiceDateKey,4) AS ADJ_CLM_DOSYR
,CASE WHEN  H.claim_id LIKE 'PSY%' THEN '0'
	  WHEN  H.claim_id IN (SELECT ADJ_CLAIM_ID FROM LEON_ADJUSTMENTS_INPUT_ARCHIVE) THEN '1'
	  WHEN  H.claim_id NOT IN (SELECT ADJ_CLAIM_ID FROM LEON_ADJUSTMENTS_INPUT_ARCHIVE) 
			AND S.CLMSTAT_STATUS NOT IN ('A-ICN',  'MAO004') THEN '2'
	 ELSE '3' END AS Status
,CASE WHEN  H.claim_id LIKE 'PSY%' THEN 'PSY_Claim_Excluded'
	  WHEN  H.claim_id IN (SELECT ADJ_CLAIM_ID FROM LEON_ADJUSTMENTS_INPUT_ARCHIVE) THEN 'Adj_ClaimId_duplicate to previous file'
	  WHEN  H.claim_id NOT IN (SELECT ADJ_CLAIM_ID FROM LEON_ADJUSTMENTS_INPUT_ARCHIVE) 
			AND S.CLMSTAT_STATUS NOT IN ('A-ICN',  'MAO004') THEN 'Orig_Claimid not Accepted'
	 ELSE 'Adj_ClaimId_for Leon Review' END AS StatusCode
,GETDATE() AS Process_Date
,s.LAST_UPD_DATE AS LAST_UPD_DATE
FROM [EXT_CLAIM_EXCLUSION_HIST] H
JOIN [WIPRO].[dbo].[OUTB_CLAIM_STATUS] S
	ON REPLACE(H.claim_id, SUBSTRING(H.claim_id, len(H.claim_id) - 1, 2), '00') = S.CLAIM_ID
LEFT JOIN [EDPS_Data].[dbo].[CLAIMDIM] C 
	ON H.claim_id = c.CLAIMID

--AND CASE WHEN  H.claim_id LIKE 'PSY%' THEN '0'
--	  WHEN  H.claim_id IN (SELECT ADJ_CLAIM_ID FROM LEON_ADJUSTMENTS_INPUT_ARCHIVE) THEN '1'
--	  WHEN  H.claim_id NOT IN (SELECT ADJ_CLAIM_ID FROM LEON_ADJUSTMENTS_INPUT_ARCHIVE) 
--			AND S.CLMSTAT_STATUS NOT IN ('A-ICN',  'MAO004') THEN '2'
--	 ELSE '3' END = '3'
--AND REPLACE(H.claim_id, SUBSTRING(H.claim_id, len(H.claim_id) - 1, 2), '00') = '170050047200'

--'170200527600'
) a

WHERE a.Rw = 1


SELECT 
       ADJ_CLAIM_ID AS CLAIM_ID,
       ORIGINAL_CLAIM_ID,
	   'Accepted' AS ORIGINAL_CLAIM_STATUS,
	   '' AS LEON_TEAM_RESPONSE
	   FROM DBO.LEON_ADJUSTMENTS_INPUT
WHERE STATUS = '3'

claim_id	Original_Claim_id	ORIGINAL_CLAIM_STATUS	"Leon Team Response
Replace_Void_Ignore"


SELECT TOP 1 ID AS Cnt1
FROM dbo.LEON_ADJUSTMENTS_INPUT
where status_code = '3'

*/


