﻿
CREATE PROCEDURE [dbo].[EXSP_CLAIM_EXCLUSION_MULTI_CLAIM_TYPES]
	(@CLAIMTYPE		CHAR(1),		-- Valid Values P or I
	 @SOURCEDESC	VARCHAR(60)  ) 

AS     
     
/***************************************************************************************************     
** CREATE DATE: 07/17/2018      
** AUTHOR:		Scott Waller
** TETDM-1768

** DESCRIPTION: This sproc will look for Encounter claims that have more than one type of ClaimType.
				If it finds any, it will remove the claims from the Header and Detail tables so that
				they don't get submitted.  It will also insert them into the Exclusion table so they 
				will be excluded in future runs.

Modification History     
====================     
Date			Who				Description     
11/10/2021		Scott Waller	TETDM-2618 Change Encounter Exclusion 9055. Currently if an Encounter 
								Claim has more than 1 header row, and they are of different ClaimTypes 
								(I or P), it will put them in 9055 and remove them from the current
								claim submission.
								The change is to NOT put them into 9055 and to leave them in the submission
								table IF the MemberID for each header row is different.

-----------------------------------------------------------------------------------------------------     

*****************************************************************************************************/	  
   
--Declare Variables        
	DECLARE     @TOTAL_RECORDS	INT,
				@HOLD_DATE		datetime;

	SELECT		@HOLD_DATE = GETDATE();
				     
--Insert Claim File Run controls Start        
		INSERT INTO EXT_SYS_RUNLOG     
				(PROC_NAME     
				,STEP     
				,START_DT     
				,END_DT     
				,RUN_MINUTES     
				,TOTAL_RECORDS     
				,ENTRYDT     
				)     
		VALUES('EXSP_CLAIM_EXCLUSION_MULTI_CLAIM_TYPES'
				,'14'     
				,GETDATE()     
				,NULL     
				,NULL     
				,0     
				,GETDATE()     
				)     
					     

--Check for Temp Table and Create								     
		IF OBJECT_ID('TEMPDB..#EXT_CLAIM_EXCLUSION_HIST') <> 0     
		DROP TABLE #EXT_CLAIM_EXCLUSION_HIST     
								     
		CREATE TABLE #EXT_CLAIM_EXCLUSION_HIST     
		(	CLAIM_ID		VARCHAR(20) NULL,
			SOURCEDATAKEY	INT NULL,
			BATCH_RUN_DT	datetime NULL,
			EXCL_ID			int NULL,
			CLAIM_TYPE		char(5) NULL
		)         

--Exclusion #9055 - Encounter Claims with Multiple Claim Types
		
	IF @CLAIMTYPE = 'P' -- professional
	BEGIN

		IF OBJECT_ID('TEMPDB..#EC_MultiClaimTypes_P') <> 0     
			DROP TABLE #EC_MultiClaimTypes_P

		SELECT	b.claimnum, COUNT(*) as ClaimTypeCount
		INTO	#EC_MultiClaimTypes_P
		FROM	(SELECT	ec.claimnum, ec.ClaimType
				 FROM	WIPRO.dbo.OUTB_PROF_HEADER oph
				 INNER JOIN	EDPS_DATA.dbo.encounterclaimdim ec
					ON	ec.ClaimNum			= oph.CLAIM_ID
					AND	ec.SourceDataKey	= 4
					AND	ec.sourcedesc		= @SOURCEDESC
				 GROUP BY ec.claimnum, ec.ClaimType ) b
		GROUP BY b.ClaimNum
		HAVING COUNT(*) > 1

-- TETDM-2618   For the Multi Claim Type claims, get their distinct MemberIDs
--				and then get a count of the number of MemberIDs per ClaimNum.
--				Any ClaimID that has more than one different MemberID, we will
--				remove from the table that is holding the claims to be put into 
--				Exclusion 9055 and removed from the submission tables.
		IF OBJECT_ID('TEMPDB..#hold_P_claims_memberids') <> 0     
			DROP TABLE #hold_P_claims_memberids

		IF OBJECT_ID('TEMPDB..#hold_P_claims_multi_memberids') <> 0     
			DROP TABLE #hold_P_claims_multi_memberids

		SELECT	DISTINCT a.ClaimNum, a.MemberID
		INTO	#hold_P_claims_memberids
		FROM	EDPS_Data.dbo.encounterclaimdim a
		INNER JOIN #EC_MultiClaimTypes_P b
			on	b.ClaimNum		= a.ClaimNum
		WHERE	a.SourceDesc	= @SOURCEDESC

		SELECT	ClaimNum, COUNT(*) as MemberID_Count
		INTO	#hold_P_claims_multi_memberids
		FROM	#hold_P_claims_memberids
		GROUP BY ClaimNum

		DELETE FROM #EC_MultiClaimTypes_P
		WHERE	ClaimNum in (SELECT ClaimNum	
							 FROM	#hold_P_claims_multi_memberids
							 WHERE	MemberID_Count > 1 )
-- END TETDM-2618

		--Load Claim Data into Temp Exclusion Table   
		INSERT INTO #EXT_CLAIM_EXCLUSION_HIST
			(CLAIM_ID, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE)     
		select	claimnum,
				4,
				@HOLD_DATE AS 'BATCH_RUNDT',
				9055,
				@CLAIMTYPE
		from	#EC_MultiClaimTypes_P

		--Remove Claim Header Data for records not having matching Detail Data
		DELETE	FROM dbo.OUTB_PROF_HEADER
		WHERE	claim_id in (select claim_id from #EXT_CLAIM_EXCLUSION_HIST)

		DELETE	FROM dbo.OUTB_PROF_DETAIL
		WHERE	claim_id in (select claim_id from #EXT_CLAIM_EXCLUSION_HIST)
	END

	IF @CLAIMTYPE = 'I' -- institutional
	BEGIN
		IF OBJECT_ID('TEMPDB..#EC_MultiClaimTypes_I') <> 0     
			DROP TABLE #EC_MultiClaimTypes_I

		SELECT	b.claimnum, COUNT(*) as ClaimTypeCount
		INTO	#EC_MultiClaimTypes_I
		FROM	(SELECT	ec.claimnum, ec.ClaimType
				 FROM	WIPRO.dbo.OUTB_INST_HEADER oph
				 INNER JOIN	EDPS_DATA.dbo.encounterclaimdim ec
					ON	ec.ClaimNum			= oph.CLAIM_ID
					AND	ec.SourceDataKey	= 4
					AND	ec.sourcedesc		= @SOURCEDESC
				 GROUP BY ec.claimnum, ec.ClaimType ) b
		GROUP BY b.ClaimNum
		HAVING COUNT(*) > 1

-- TETDM-2618   For the Multi Claim Type claims, get their distinct MemberIDs
--				and then get a count of the number of MemberIDs per ClaimNum.
--				Any ClaimID that has more than one different MemberID, we will
--				remove from the table that is holding the claims to be put into 
--				Exclusion 9055 and removed from the submission tables.
		IF OBJECT_ID('TEMPDB..#hold_I_claims_memberids') <> 0     
			DROP TABLE #hold_P_claims_memberids

		IF OBJECT_ID('TEMPDB..#hold_I_claims_multi_memberids') <> 0     
			DROP TABLE #hold_P_claims_multi_memberids

		SELECT	DISTINCT a.ClaimNum, a.MemberID
		INTO	#hold_I_claims_memberids
		FROM	EDPS_Data.dbo.encounterclaimdim a
		INNER JOIN #EC_MultiClaimTypes_I b
			on	b.ClaimNum		= a.ClaimNum
		WHERE	a.SourceDesc	= @SOURCEDESC

		SELECT	ClaimNum, COUNT(*) as MemberID_Count
		INTO	#hold_I_claims_multi_memberids
		FROM	#hold_I_claims_memberids
		GROUP BY ClaimNum

		DELETE FROM #EC_MultiClaimTypes_I
		WHERE	ClaimNum in (SELECT ClaimNum	
							 FROM	#hold_I_claims_multi_memberids
							 WHERE	MemberID_Count > 1 )
-- END TETDM-2618

		--Load Claim Data into Temp Exclusion Table   
		INSERT INTO #EXT_CLAIM_EXCLUSION_HIST
			(CLAIM_ID, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE)     
		select	claimnum,
				4,
				@HOLD_DATE AS 'BATCH_RUNDT',
				9055,
				@CLAIMTYPE
		from	#EC_MultiClaimTypes_I

		--Remove Claim Header Data for records not having matching Detail Data
		DELETE	FROM dbo.OUTB_INST_HEADER
		WHERE	claim_id in (select claim_id from #EXT_CLAIM_EXCLUSION_HIST)

		DELETE	FROM dbo.OUTB_INST_DETAIL
		WHERE	claim_id in (select claim_id from #EXT_CLAIM_EXCLUSION_HIST)
	END

-- Scott Waller 7/17/18
-- this prevents INSERTING claim multiple times
-- this can only happen for resub (special jobid's) jobs where
-- they force claims and ignore the Exclusion Table
		DELETE	FROM #EXT_CLAIM_EXCLUSION_HIST
		WHERE	CLAIM_ID IN	(	SELECT	DISTINCT a.CLAIM_ID
								FROM	#EXT_CLAIM_EXCLUSION_HIST	a
								INNER JOIN EXT_CLAIM_EXCLUSION_HIST b
									ON	b.CLAIM_ID		= a.CLAIM_ID		
									AND	b.SOURCEDATAKEY	= a.SOURCEDATAKEY
									AND	b.EXCL_ID		= 9055	)

--Load Exclusions to final table								     
		INSERT INTO EXT_CLAIM_EXCLUSION_HIST
			(CLAIM_ID, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE) 
		SELECT	CLAIM_ID,     
				SOURCEDATAKEY,
				BATCH_RUN_DT,
				EXCL_ID,
				CLAIM_TYPE
		FROM #EXT_CLAIM_EXCLUSION_HIST
						
--Get Total Records Count								     
		SET @TOTAL_RECORDS = @@ROWCOUNT  
 
--Update Final Run Controls End          
		UPDATE EXT_SYS_RUNLOG     
			SET END_DT = GETDATE()	     
				,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())     
				,TOTAL_RECORDS = @TOTAL_RECORDS     
				,ENTRYDT = GETDATE()    
				,PROC_NAME = 'EXSP_CLAIM_EXCLUSION_MULTI_CLAIM_TYPES swaller'
			WHERE PROC_NAME = 'EXSP_CLAIM_EXCLUSION_MULTI_CLAIM_TYPES'
					AND END_DT IS NULL     
							     
		IF OBJECT_ID('TEMPDB..#EXT_CLAIM_EXCLUSION_HIST') <> 0     
		DROP TABLE #EXT_CLAIM_EXCLUSION_HIST     

		IF OBJECT_ID('TEMPDB..#EC_MultiClaimTypes_P') <> 0     
		DROP TABLE #EC_MultiClaimTypes_P

		IF OBJECT_ID('TEMPDB..#EC_MultiClaimTypes_I') <> 0     
		DROP TABLE #EC_MultiClaimTypes_I
		
		IF OBJECT_ID('TEMPDB..#hold_P_claims_memberids') <> 0     
			DROP TABLE #hold_P_claims_memberids

		IF OBJECT_ID('TEMPDB..#hold_P_claims_multi_memberids') <> 0     
			DROP TABLE #hold_P_claims_multi_memberids

		IF OBJECT_ID('TEMPDB..#hold_I_claims_memberids') <> 0     
			DROP TABLE #hold_P_claims_memberids

		IF OBJECT_ID('TEMPDB..#hold_I_claims_multi_memberids') <> 0     
			DROP TABLE #hold_P_claims_multi_memberids

