﻿
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_WIPRO_DATASCRUB]

AS
/******************************************************************************************************************
** CREATE DATE: 09/10/2014
**
** AUTHOR: LOYAL RICKS 
**
** DESCRIPTION: PROCEDURE WILL Remove non required WIPRO data elements from outbound file.
**             Scurb being performed in separate sp due to fk and other DML that is required  
**             for processing outbound file that may be impacted by removing these field in 
**				earlier steps of the process.
Modification History
====================
Date			Who				Description
-------------------------------------------------------------------------------------------------------------------
09/25/13		Loyal Ricks		EDS-396 - Update the following provider data elements to blank for all claim provider types:
								Plan Provider Id, UPIN, State License Number, Location Number
03/27/15		Loyal Ricks		TETDM-14 - Add logic for shifting adjustment segments 
07/15/15		Loyal Ricks		Add Ambulance Exclusion Edit - TETDM-263 - Remove Ambulance Claims from outbound file 
								using Taxonomy Codes.
07/20/15		Loyal Ricks		Modify Ambulance Exclusion Edit - TETDM-263 - Split Taxonomy Code driven exclusions 
								into individual bucket (ExclusionId 8003).
07/27/16		Loyal Ricks		TETDM-756 -Add logic to capture taxonomy code that was tied to claim when edit fired. Save data
								so BA team can investigate and validate logic.
08/29/16		Loyal Ricks		TETDM-1020 Lift Ambulance Exclusion Edit
*******************************************************************************************************************/


--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT
		

--HRP_CLAIM_FILE Run controls
		
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_BUILD_OUTB_INST_WIPRO_DATASCRUB'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					

		-----
		-- Note 
		------ EDS-396 Claim Provider data element removal

					--Billing Provider Info
					
						update OUTB_INST_HEADER
						SET BILL_PROV_GRP_ID = ' ',
							BILL_PROV_ID = ' ',
							BILL_PROV_UPIN = ' ',
							BILL_PROV_LICENSE_NO = ' '
						

					--Rendering Provider Info
				
						update OUTB_INST_HEADER
						SET RENDERING_PROV_ID = ' ',
							RENDERING_PROV_UPIN = ' ',
							RENDERING_PROV_GRP_ID = ' ' 
					


					--Referring Provider Info
					
						update OUTB_INST_HEADER
						SET REF_PROV_ID = ' ',
							REF_PROV_UPIN = ' ',
							REF_PROV_LICENSE_NO = ' '
						
					--Attneding Provider Info
				
						update OUTB_INST_HEADER
						SET ATTN_PROV_ID = ' ',
							ATTN_PROV_UPIN = ' ',
							ATTN_PROV_LICENSE_NO = ' ',
							ATTN_PROV_LOC_NO = ' '
						

					--Operating Provider Info
					 
						update OUTB_INST_HEADER
						SET OPER_PHYS_PROV_ID = ' '
						

					--Other Operating Provider Info
					 
						update OUTB_INST_HEADER
						SET OTH_OPER_PHYS_PROV_ID = ' '
							
						--Shift Segment 132 to 131 when 131 segment is not present

							
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON131 = CLM_ADJ_REASON132,
										CLM_ADJ_AMT131 = CLM_ADJ_AMT132,
										CLM_ADJ_QTY131 = CLM_ADJ_QTY132,
										CLM_ADJ_REASON132 = ' ',
										CLM_ADJ_AMT132 = ' ',
										CLM_ADJ_QTY132 = ' '
									WHERE (LEN(CLM_ADJ_REASON131) = 0
										AND LEN(CLM_ADJ_REASON132) > 0)
							
							--Shift Segment 133 to 132 when 132 segment is not present
							 
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON132 = CLM_ADJ_REASON133,
										CLM_ADJ_AMT132 = CLM_ADJ_AMT133,
										CLM_ADJ_QTY132 = CLM_ADJ_QTY133,
										CLM_ADJ_REASON133 = ' ',
										CLM_ADJ_AMT133 = ' ',
										CLM_ADJ_QTY133 = ' '
									WHERE LEN(CLM_ADJ_REASON132) = 0
										AND LEN(CLM_ADJ_REASON133) > 0


	
								--TETDM-263 Ambulance Exclusion Edit 
								--TETDM-1020 Lift Ambulance Exclusion Edit
							
								---Update Billing Provider Taxonomy Code when Taxonomy 
							
								--UPDATE OUTB_INST_HEADER
								--SET BILL_PROV_TAXONOMY_CD = HealthcareProviderTaxonomyCode
								--FROM OUTB_INST_HEADER P
								--INNER JOIN EDPS_Data.IDQ.CMSTaxonomy T
								--ON P.BILL_PROV_GRP_NPI = T.NPI
								--where len(P.BILL_PROV_TAXONOMY_CD) = 0
								--	AND T.HealthcareProviderTaxonomyCode IN ('343900000X','341600000X','3416A0800X','3416L0300X','3416S0300X')
								
								

					--IF OBJECT_ID('TEMPDB..#TMP_EXCLID_8003') <> 0
					--				DROP TABLE #TMP_EXCLID_8003
		
					--					CREATE TABLE #TMP_EXCLID_8003
		
					--					( CLAIMID VARCHAR(20),
					--						SOURCEDATAKEY INT 
					--					)

					--	--Identify current exclusions
					--	insert into #TMP_EXCLID_8003
					--	select claim_id,sourcedatakey
					--	from OUTB_INST_header
					--	WHERE BILL_PROV_TAXONOMY_CD IN ('343900000X','341600000X','3416A0800X','3416L0300X','3416S0300X')

					--	--log claim into OUTB_CLAIM_EXCLUSION_HIST for capturing history of claims found as exclusion
					--	----TETDM-756 -
					--	INSERT INTO OUTB_CLAIM_EXCLUSION_HIST
					--	select DISTINCT CLAIM_ID,SOURCEDATAKEY,GETDATE(),8003,CLAIM_TYPE, BILL_PROV_TAXONOMY_CD
					--	from OUTB_INST_header
					--	WHERE BILL_PROV_TAXONOMY_CD IN ('343900000X','341600000X','3416A0800X','3416L0300X','3416S0300X')

					--	--Append EXT_CLAIM_EXCLUSION_HIST 

					--	Insert into EXT_CLAIM_EXCLUSION_HIST
					--	SELECT O.CLAIM_ID,
					--			O.SOURCEDATAKEY,
					--			O.BATCH_RUN_DT,
					--			O.EXCL_ID,
					--			O.CLAIM_TYPE
					--	FROM OUTB_CLAIM_EXCLUSION_HIST O
					--	LEFT OUTER JOIN EXT_CLAIM_EXCLUSION_HIST H
					--	ON O.SOURCEDATAKEY = H.SOURCEDATAKEY 
					--	AND O.CLAIM_ID = H.CLAIM_ID 
					--	WHERE H.CLAIM_ID IS NULL

					--	--REMOVE CLAIMS FROM OUTBOUND FILE 
					--	DELETE 
					--	FROM OUTB_INST_HEADER
					--	WHERE CLAIM_ID IN (SELECT CLAIMID FROM #TMP_EXCLID_8003)

					--	DELETE 
					--	FROM OUTB_INST_DETAIL
					--	WHERE CLAIM_ID IN (SELECT CLAIMID FROM #TMP_EXCLID_8003)

						
			--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_HEADER)
			
									
		----HRP_CLAIM_FILE Update Run Controls
				
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_WIPRO_DATASCRUB'
										and END_DT is null
						
