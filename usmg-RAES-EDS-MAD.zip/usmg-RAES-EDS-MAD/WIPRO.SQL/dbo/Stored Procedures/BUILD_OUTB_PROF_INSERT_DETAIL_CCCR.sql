﻿



  
  CREATE PROCEDURE [dbo].[BUILD_OUTB_PROF_INSERT_DETAIL_CCCR]  
  
AS  
/************************************************************************************************************************  
** CREATE DATE: 08/10/2017  
**  
** AUTHOR: Henry Faust  
**  
** DESCRIPTION: Populates the table OUTB_Prof_CCCR. The table is used to eliminate multiple DX codes  
**                
**                
**  
**  
Modification History  
====================  
Date			Who				Description  
--------------------------------------------------------------------------------------------------------------------------  
 08/10/2017		henry Faust   This procedure populates the table OUTB_PROF_CCCR with only the unique Diagnosis codes.  
                              Primary Diag Code row number 1, the rest are offset by 1.       
								  
*****************************************************************************************************	  
------------------------------------------------------------------------------------------------------  
******************************************************************************************************  
------------------------------------------------------------------------------------------------------  
  
2017-08-10		Henry Faust TETDM 1501		WIPRO Implementation																							      
2018-04-01		Henry Faust TETDM 1769		fix codes and pointer issue																							      
*****************************************************************************************************/	
/* Note: This code takes care of setting the DX code pointers at the line level back to the correct adjusted DX codes 
at the header level. I set all the code to populate the table dbo.OUTB_PROF_DETAIL_CCCR so all the codes are in the
correct order. That way when the mapping has to be done, it is a simple pick a row from a table. I decided to put all
logic for ordering and correcting the data here instead of replicating 30 times in the mapping SP.
*/  
			DECLARE
			
			@TOTAL_RECORDS INT

					INSERT INTO EXT_SYS_RUNLOG  
							(PROC_NAME  
							,STEP  
							,START_DT  
							,END_DT  
							,RUN_MINUTES  
							,TOTAL_RECORDS  
							,ENTRYDT  
							)  
					VALUES('BUILD_OUTB_PROF_INSERT_DETAIL_CCCR'   
							,'1.1'  
							,GETDATE()  
							,NULL  
							,NULL  
							,0  
							,GETDATE()  
							)  
  
  
  
  
	IF OBJECT_ID('TEMPDB..#CLMPCDPSD') <> 0
					DROP TABLE #CLMPCDPSD

	create table  #CLMPCDPSD
	(claimid varchar(20),
	 claimlineid VARCHAR(5),
	  dgcd VARCHAR(10),
	  rownum int,
	  parent INT NULL)
   CREATE CLUSTERED INDEX cmsidcpsd_idx ON #CLMPCDPSD (claimid,claimlineid, rownum)
----------------
INSERT INTO #CLMPCDPSD
        ( rownum, claimid, claimlineid, dgcd,parent)

		SELECT TOP 100 percent ROW_NUMBER() OVER (PARTITION BY claim_id, claimlineid ORDER BY claim_id, CLAIMLINEID,ROWNUM ASC) AS seq
		                                                                                               , CLAIM_ID 
		                                                                                               , claimlineid 
																									   , DIAGNOSISCODE 
																									   , NULL AS parent
		FROM  
		(

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE  SEQUENCE = 1
		   AND ROWNUM = 1

		UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE  SEQUENCE = 2
		   AND ROWNUM = 2
    
		  UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE  SEQUENCE = 3
		   AND ROWNUM = 3  
		  UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 4
		   AND ROWNUM = 4   
   
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 5
		   AND ROWNUM = 5   
   
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 6
		   AND ROWNUM = 6 
   
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 7
		   AND ROWNUM = 7   
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 8
		   AND ROWNUM = 8   
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 9
		   AND ROWNUM = 9
   
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 10
		   AND ROWNUM = 10   
------------------------
   
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 11
		   AND ROWNUM = 11     
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 12
		   AND ROWNUM = 12     
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 13
		   AND ROWNUM = 13     
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 14
		   AND ROWNUM = 14     
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 15
		   AND ROWNUM = 15     
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 16
		   AND ROWNUM = 16     
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 17
		   AND ROWNUM = 17     
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 18
		   AND ROWNUM = 18     
		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 19
		   AND ROWNUM = 19     
----------------------------------------------

		   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 20
		   AND ROWNUM = 20  

			   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 21
		   AND ROWNUM = 21  

			   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 22
		   AND ROWNUM = 22  
			   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 23
		   AND ROWNUM = 23  
			   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 24
		   AND ROWNUM = 24  
			   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 25
		   AND ROWNUM = 25  
			   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 26
		   AND ROWNUM = 26  
			   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 27
		   AND ROWNUM = 27  
			   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 28
		   AND ROWNUM = 28  
			   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 29
		   AND ROWNUM = 29  
			   UNION

		SELECT opc.CLAIM_ID,  cdd.CLAIMLINEID,cdd.DIAGNOSISCODE, opc.ROWNUM
		 FROM [EDPS_Data].[dbo].[CLAIMdetailDIAGNOSISDIM] cdd 
			LEFT JOIN dbo.OUTB_PROF_cccr opc ON cdd.CLAIMID = opc.CLAIM_ID
		 WHERE SEQUENCE = 30
		   AND ROWNUM = 30  

		   )x

 -- ORDER BY claim_id, claimlineid, rownum ,diagnosiscode

--  SELECT *   FROM #CLMPCDPSD tcd

TRUNCATE TABLE dbo.OUTB_PROF_DETAIL_CCCR  

INSERT INTO dbo.OUTB_PROF_DETAIL_CCCR 
            ( Rownum, claim_id, CLAIMLINEID, dgcd, parent  )  
 SELECT tcd.rownum, tcd.claimid, tcd.claimlineid, tcd.dgcd,  opc.ROWNUM -1 AS parent
  FROM #CLMPCDPSD tcd
 LEFT outer JOIN dbo.OUTB_PROF_CCCR opc ON tcd.claimid = opc.CLAIM_ID AND tcd.dgcd = opc.DGCD AND opc.ROWNUM > 1

-- SELECT * FROM dbo.OUTB_PROF_DETAIL_CCCR

------------------------
-----------------------
SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_DETAIL_CCCR)
------------
------------ 
						UPDATE EXT_SYS_RUNLOG  
						SET END_DT = GETDATE()	  
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()  
						WHERE PROC_NAME = 'BUILD_OUTB_PROF_INSERT_DETAIL_CCCR'   
										and END_DT is null  
  
  
  







