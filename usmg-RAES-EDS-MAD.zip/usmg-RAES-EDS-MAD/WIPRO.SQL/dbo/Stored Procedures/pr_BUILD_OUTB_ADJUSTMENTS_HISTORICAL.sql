﻿CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_ADJUSTMENTS_HISTORICAL] 

AS
/***************************************************************************************************
** CREATE DATE: 2/2018
**
** AURTHOR: Aaron Ridley -  
**
** DESCRIPTION:  Procedure has been created to utilize the Adjustment DIAG/PROC Code change table as the driver
**              to stack and qualify adjustments in the inventory. This process is responsible for 
**              updating the Test Bed adjustment table with all current, submittable adjustments as well as 
**              updating the Void export table for retractions. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------

02/25/2021      Aaron Ridley    TETDM-2359 Added logic to allow for frequency codes 7,8 to accom adjustment submissions 
04/26/2021      Aaron Ridley    TETDM-2472 Added logic to remove the Exclusion table deletion for EXCL_ID '9019' 
06/16/2021      Aaron Ridley    TETDM-2506 Added the following logic: 
								 a. Added logic to properly set ClaimType to 'E' for DME Taxonomy Codes
								 b. Updating Leon Adjustment table (changing schema from dbo to staging) 
09/06/2022		Aaron Ridley	RETM-131 - Include exclusion 8012 for FDR claims 
02/03/2023		Aaron Ridley	RETM-180 - Added Exclusion 9070 
04/10/2023		Aaron Ridley	RETM-241 - DME qualification. Removed check for Taxonomy Switch
05/04/2023		Aaron Ridley	RETM-239 - Filter FDR claims on encounters vendors where claims are submitted to CMS
06/19/2024		Scott Waller	RETM-675 - INST DME claims are being submitted.  DME is only for PROF claims.
											Add logic to update only PROF claims with the 'E' ClaimType value.

*****************************************************************************************************/	
	/* Identify LOB for WIPRO Test Bed */
	SELECT DISTINCT LOBCode, ProductType, OperationalMarket,
	CASE WHEN ProductType = 'MEDICARE' THEN 'MAO'
		 WHEN ProductType = 'Care-Caid' AND LOBCODE = 'UMISC0028041899' THEN 'MMAI'
		 WHEN ProductType = 'Care-Caid' AND LOBCODE = 'C54581391' THEN 'MMAI'
		 WHEN ProductType = 'MEDICAID' AND LobCode in ('C42644396', 'C45137428', 'C54240970') THEN 'CAID'
		 WHEN ProductType = 'MEDICAID' AND LobCode ='UMISC0028042858' THEN 'CAID'
		 ELSE 'OTHER'
	END AS TESTBEDCODE
	into #TESTBEDLOB 
	FROM MDQOLIB.dbo.LineofBusinessDim  
	WHERE Active = 1  AND ProductType NOT IN ('COMMERCIAL','PDP','RX','EPO')

	/* Identify Adjustments excluded in the Outbound Claims generation process */
		select distinct a.claimid as claim_id, replace(convert(date,a.[Adjuddate],110),'-','') AS [Adjuddate], a.[Frequencycode], memberid, beginservicedatekey, providernpi, requestedamt, 
		b.sourcedatakey, 'EXCLUSION' as source, d.TESTBEDCODE, a.PREVIOUSCLAIMID as origclaimno, 
		CASE when Formtypecode = 'U' then 'I'
			when  Formtypecode != 'U' then 'P'
		 end as claimtype, '' as SourceDesc
		into #EXCLUSIONS
		from EDIFECS.dbo.ADJUSTMENT_SUBMISSION_CHANGEINPUT a
		join EDPS_Data.dbo.ClaimAgg b on a.claimid = b.claimid 
		JOIN #TESTBEDLOB d ON b.LOBCODE = d.LOBCode
		where b.beginservicedatekey > 20190100
		UNION
		select distinct a.claim_id, replace(convert(date,[Adjuddate],110),'-','') AS [Adjuddate], [Frequencycode], memberid, beginservicedatekey, providernpi, requestedamt, 
		b.sourcedatakey, 'EXCLUSION' as source, d.TESTBEDCODE, previousclaimid as origclaimno,
		CASE when Formtypecode = 'U' then 'I'
			when  Formtypecode != 'U' then 'P'
		 end as claimtype, '' as SourceDesc
		from [WIPRO].[dbo].[EXT_CLAIM_EXCLUSION_HIST] a
		join EDPS_Data.dbo.ClaimAgg b on a.claim_id = b.claimid 
		join EDPS_Data.[dbo].[QNXT_Claim] c on b.claimid = c.claimid 
		JOIN #TESTBEDLOB d ON b.LOBCODE = d.LOBCode
		where beginservicedatekey > 20190100 and [EXCL_ID] = '9019' and c.frequencycode = '8' --	and c.plancrn <>''
		UNION 
		select distinct a.claim_id, '' AS [Adjuddate], b.[ClaimFrequencyCode] as [Frequencycode], b.memberid, beginservicedatekey,b.[VendorID] as providernpi, requestedamt, 
		b.sourcedatakey, 'EXCLUSION' as source, d.TESTBEDCODE, b.ReversedClaimNum as origclaimno, b.ClaimType, SourceDesc
		from [WIPRO].[dbo].[EXT_CLAIM_EXCLUSION_HIST] a
		join EDPS_Data.dbo.EncounterClaimDim b on a.claim_id = b.claimnum  and b.ClaimLineNum = '1'
												and b.SourceDesc in ('Wellmed','Advocate','SuperiorVision', 'EyeMed')
		join EDPS_Data.dbo.MonthlymembershipDim c on b.memberid = c.memberid and b.beginservicedatekey between c.begincoveragedatekey and c.EndCoverageDateKey
		JOIN #TESTBEDLOB d ON c.LOBCODE = d.LOBCode
		where beginservicedatekey > 20190100 and [EXCL_ID] = '9019' and b.ReversedClaimNum <>'' 

		delete a
		from #EXCLUSIONS a
		INNER JOIN WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST b on a.claim_id = b.claim_id 
		WHERE EXCL_ID = '8012' AND a.SOURCEDATAKEY ='50'

		delete a
		from #EXCLUSIONS a
		INNER JOIN WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST b on a.claim_id = b.claim_id 
		WHERE EXCL_ID = '8012' AND a.SOURCEDATAKEY ='4'

		delete a
		from #EXCLUSIONS a
		INNER JOIN WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST b on a.origclaimno = b.claim_id 
		WHERE EXCL_ID in ('7000','7001') AND a.SOURCEDATAKEY ='50'

		delete a
		from #EXCLUSIONS a
		INNER JOIN WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST b on a.claim_id = b.claim_id 
		WHERE EXCL_ID = '9070' AND a.SOURCEDATAKEY ='50'

		UPDATE a
		SET origclaimno = b.PREVIOUSCLAIMID
		from #EXCLUSIONS a
		INNER JOIN EDPS_Data.dbo.ClaimDim b on a.claim_id = b.claimid
		where origclaimno = '' or origclaimno = 'N/A'


	CREATE CLUSTERED INDEX IDX_C_Exclusions_claimNo ON #EXCLUSIONS
			(
			claim_id ASC,
			memberid ASC
			)

	-------------------------------------------------------------------------------------------------------

	/* Rank Claims based on the Original ClaimNumber an the Adjudication date (Latest to Earliest) */
	select distinct *, 
	[Latest] = ROW_NUMBER() OVER (PARTITION BY origclaimno ORDER BY [Adjuddate] desc)
	into #EXCLUSIONRANK
	FROM #EXCLUSIONS

	/* Identify claims to be submitted as an original claim */
	-- Need to ensure that we're looking at the most current record in the OUTBOUND ClaimStatus table 
	select distinct a.* 
	into #EXCLUSIONREJECTED
	from #EXCLUSIONRANK a
	where a.origclaimno in (select claim_id from WIPRO.[dbo].[OUTB_CLAIM_STATUS] WHERE clmstat_status not in ('A','A-ICN', 'A-277','A-999','MAO-004','UNWRK')) 
	UNION 
	select distinct a.* 
	from #EXCLUSIONRANK a 
	where a.origclaimno not in (select claim_id from WIPRO.[dbo].[OUTB_CLAIM_STATUS]) 
	UNION
	select distinct a.*
	from #EXCLUSIONRANK a 
	join EDPS_Data.dbo.ClaimDim b on a.claim_id = b.claimid
	join EDPS_Data.dbo.ClaimDim c on a.origclaimno = c.claimid 
	where b.PREVIOUSCLAIMID = 'UNKNOWN' and  b.BeginServiceDateKey <> c.BeginServiceDateKey


	/* Remove any claims that would be identified as ADJUSTASORIG when original claim was submitted multiple time and accepted*/

	delete a 
	from #EXCLUSIONREJECTED a
	inner join WIPRO.[dbo].[OUTB_CLAIM_STATUS] b on a.origclaimno = b.claim_id
	WHERE clmstat_status in ('A','A-ICN', 'A-277','A-999','MAO-004','UNWRK')


	/* Adjust Ranking Based for Adjustments/Reversals */

	/* Adjustments as Originals - Identify Min Adjustment Date for submission */
	select origclaimno, max([Adjuddate]) as maxadj 
	into #tmporigrejected
	from #EXCLUSIONREJECTED a
	group by origclaimno 


	/* Identify maximum Adjustment for multiple adjustments to a claim on the same day */
	select  a.claim_id as claimid, adjuddate, latest, a.origclaimno , a.frequencycode,
	NEWLATEST = ROW_NUMBER() OVER (PARTITION BY RTRIM(LTRIM(a.origclaimno)) ORDER BY RTRIM(LTRIM(a.claim_id)) desc)
	into #tmporigrejected2
	from  #EXCLUSIONRANK a 
	join #tmporigrejected b on maxadj = a.adjuddate and a.origclaimno = b.origclaimno
	WHERE a.frequencycode = '7'
	--WHERE a.claim_id NOT LIKE '%R%'  


	/* Creating additional partition to handle Adjustments/Reversal that occur on the same day. Giving Adjustments priority */
	update a 
	set NEWLATEST = '2'
	from #tmporigrejected2 a
	WHERE (a.frequencycode = '8' or a.claimid like '%R%') AND a.NEWLATEST = '1'
	--WHERE a.claimid like '%R%' AND a.NEWLATEST = '1'

	SELECT origclaimno, MIN(NEWLATEST) AS minlatest
	INTO #tmporigrejected3
	FROM #tmporigrejected2
	GROUP BY origclaimno 


	update a
	set  NEWLATEST = '2' 
	from #tmporigrejected2 a 
	join #tmporigrejected2 b on left(a.origclaimno, 12) = left(b.origclaimno,12)  and a.claimid <> b.claimid
	where a.NEWLATEST = '1' and a.Adjuddate < b.Adjuddate


	/* Identify most current adjustment */
	select DISTINCT CLAIMID , origclaimno
	into #adjustmentasorig
	from #tmporigrejected2 where newlatest = '1' and frequencycode = '7'--claimid like '%A%'


	/* Build Adjustment table that will be used as driver for claims submissions and historical account of Adjusted Claims */
	select distinct b.claimtype, a.claimid, b.adjuddate, origclaimno ='',
	b.memberid, b.beginservicedatekey, b.providernpi, b.requestedamt, b.sourcedatakey, source, frequencycode as qnxtfrequencycode , newfrequencycode = '1',
	reasoncode = '1', ADJTYPE = 'ADJASORIG', replace(convert(date,getdate(),110),'-','') as LoadDateKey, b.TESTBEDCODE, SourceDesc
	into #Adjustmenttabletmp
	 from #adjustmentasorig a  
	 join #EXCLUSIONS b on a.claimid = b.claim_id 

	-----------------------------------------------------------------------------------------------------------------------------------
	/* Reversals */
	----------------------------------------------------------------------------------------------------------------------------------
	/* Select associated adjusted claims. Will be phase 2 of our adjustment submission process */

	select distinct a.* 
	into #EXCLUSIONACCEPTED
	from #EXCLUSIONRANK a
	where a.origclaimno in (select claim_id from WIPRO.[dbo].[OUTB_CLAIM_STATUS] WHERE clmstat_status in ('A-ICN','MAO-004')) 

	select origclaimno, MAX([Adjuddate]) as maxadj 
	into #tmporigaccepted
	from #EXCLUSIONACCEPTED a
	group by origclaimno 

	SELECT distinct a.CLAIM_ID, a.adjuddate, latest,
	NEWLATEST = ROW_NUMBER() OVER (PARTITION BY a.origclaimno ORDER BY a.claim_id desc),
	a.origclaimno,  a.TESTBEDCODE, a.claimtype, a.Frequencycode, a.Frequencycode as newfrequencycode, a.SOURCEDATAKEY, maxadj
	into #tmporigaccepted2
	from #EXCLUSIONRANK a
	inner join #tmporigaccepted b on a.origclaimno = b.origclaimno and maxadj = adjuddate
	inner join #EXCLUSIONS c on a.claim_id = c.claim_id

	
	/* This section identifies the maximim adjustment when multiple adjustments have the same adjudication date */

	SELECT distinct  a.origclaimno
	into #tmpmultadj
	FROM #tmporigaccepted2 a
	JOIN #tmporigaccepted2 b on a.origclaimno = b.origclaimno 
	WHERE  a.NEWLATEST ='1'  and a.SOURCEDATAKEY = '50' and a.newfrequencycode = '7'
    group by a.origclaimno
	having count(*) > 1 

	select distinct --b.claim_id, b.origclaimno, newfrequencycode, Latest, NEWLATEST,
	max(b.claim_id) as claim_id
	into #tmpmultadjfinal
	from #tmpmultadj a
	join #tmporigaccepted2 b on a.origclaimno = b.origclaimno  
	where b.claim_id not like '%R%'
	group by a.origclaimno

	UPDATE a
	set NEWLATEST = '2' 
	from #tmporigaccepted2 a 
	inner join #tmpmultadj b on a.origclaimno = b.origclaimno 
	where  a.claim_id not in (select claim_id from #tmpmultadjfinal)

	UPDATE a
	set NEWLATEST = '1' 
	from #tmporigaccepted2 a 
	inner join #tmpmultadj b on a.origclaimno = b.origclaimno 
	where  a.claim_id in (select claim_id from #tmpmultadjfinal)

	----------------------------------------------------------------------------------------------------

	/* This section excludes Reversals from the FrequencyCode '7' population for adjustment submissions */ 
	update a 
	set NEWLATEST = '2'
	from #tmporigaccepted2 a
	WHERE (a.frequencycode = '8' OR a.claim_id like '%R%') AND a.NEWLATEST = '1'
	--WHERE a.claim_id like '%R%' AND a.NEWLATEST = '1'

	SELECT origclaimno, maxadj, MIN(NEWLATEST) AS minlatest
	INTO #tmporigaccepted3
	FROM #tmporigaccepted2
	GROUP BY origclaimno , maxadj

	SELECT DISTINCT origclaimno , maxadj
	INTO #tmporigmin
	FROM #tmporigaccepted3 WHERE minlatest <> '1' AND 
	origclaimno NOT IN (SELECT origclaimno FROM #tmporigaccepted2 WHERE NEWLATEST ='1' AND frequencycode = '7')-- or CLAIM_ID LIKE '%A%'))

	DELETE
	FROM #tmporigmin
	WHERE origclaimno NOT IN 
	(SELECT origclaimno FROM #tmporigaccepted2
	 WHERE NEWLATEST ='1' AND newfrequencycode = '7' )--CLAIM_ID LIKE '%A%')

	 UPDATE a 
	SET newlatest = '1'
	FROM #tmporigaccepted2 a
	JOIN #tmporigaccepted3 b ON a.origclaimno = b.origclaimno AND a.Adjuddate = b.maxadj
	--INNER JOIN #tmporigrejected c ON a.origclaimno = b.origclaimno AND a.Adjuddate = c.maxadj
	WHERE b.minlatest <> '1' AND (a.newfrequencycode = '7' or claim_id NOT LIKE '%R%')

	
	select distinct origclaimno
	into #adjustments
	from #tmporigaccepted2 a
	--inner join #tmpmultadjfinal b on a.claim_id = b.claim_id
	where newlatest = '1'

	CREATE CLUSTERED INDEX IDX_C_tmporigaccept2_claimNo ON #tmporigaccepted2
			(
			origclaimno ASC
			)

	select distinct *
	into #voids
	from #tmporigaccepted2 where origclaimno not in (select origclaimno from #adjustments)

	CREATE CLUSTERED INDEX IDX_C_voids_claimNo ON #voids
			(
			origclaimno ASC
			)

	SELECT b.* 
	INTO #voidsall
	FROM #voids a 
	inner JOIN #EXCLUSIONS b ON a.origclaimno = b.origclaimno
	WHERE newfrequencycode = '8' -- b.claim_id LIKE '%R%' 

	select DISTINCT origclaimno, min([Adjuddate]) as minadj 
	into #voidsadj
	from #voidsall  
	group by origclaimno

	select distinct a.*
	INTO #voidsfinal
	from #voidsall a
	inner join #voidsadj b on a.origclaimno = b.origclaimno and b.minadj = a.Adjuddate
	INNER JOIN #tmporigaccepted2 c ON b.origclaimno = c.origclaimno
	 WHERE newfrequencycode = '8' --a.claim_id like '%R%'  



/* Build Adjustment table that will be used as driver for claims submissions and historical account of Adjusted Claims */
select distinct a.claimtype, a.claim_id, c.adjuddate, a.origclaimno,
c.memberid, c.beginservicedatekey, c.providernpi, c.requestedamt, c.sourcedatakey, a.source, a.frequencycode as qnxtfrequencycode , a.frequencycode as newfrequencycode,
reasoncode = '1', ADJTYPE = 'REVERSALS', replace(convert(date,getdate(),110),'-','') as LoadDateKey, a.TESTBEDCODE
into #Adjustmenttabletmprev
 from #voidsfinal a  
inner join #EXCLUSIONS c on a.claim_id = c.claim_id


 
-------------------------------------------------
/* Adjustments */
------------------------------------------------

--drop table #ADJUSTMENT_SUBMISSION

IF OBJECT_ID('tempdb..#ADJUSTMENT_SUBMISSION') IS NOT NULL
TRUNCATE TABLE #ADJUSTMENT_SUBMISSION
else
create table #ADJUSTMENT_SUBMISSION
(Claimtype char,
Claimid varchar (50),
Adjuddate smalldatetime,
origclaimno varchar (50),
cms_icn varchar (50),
memberid varchar (20),
beginservicedatekey int,
providernpi varchar(20),
requestedamt money,
sourcedatakey varchar (2),
source varchar (20), 
qnxtfrequencycode char, 
newfrequencycode char, 
reason char, 
adjtype varchar (20), 
loaddatekey int,
submissionflag CHAR,
testbedcode VARCHAR (20),
sourcedesc varchar (60))

/* Adjustment as Original insert */
insert into #ADJUSTMENT_SUBMISSION
select DISTINCT claimtype, claimid, adjuddate, origclaimno, '', memberid, beginservicedatekey, providernpi, requestedamt, sourcedatakey, source, qnxtfrequencycode , newfrequencycode,
reasoncode, ADJTYPE, loaddatekey, submissionflag = 'N', TESTBEDCODE, SourceDesc
from #Adjustmenttabletmp

/* Reversal Insert */
insert into #ADJUSTMENT_SUBMISSION
select claimtype, claim_id, adjuddate, origclaimno, '', memberid, beginservicedatekey, providernpi, requestedamt, sourcedatakey, 
source, qnxtfrequencycode , newfrequencycode,
reasoncode, ADJTYPE, LoadDateKey, submissionflag = 'N', TESTBEDCODE, ''
from #Adjustmenttabletmprev

/* Adjustment Insert */ 

insert into #ADJUSTMENT_SUBMISSION
select distinct a.claimtype, a.claim_id, a.adjuddate, a.origclaimno, '', memberid, beginservicedatekey, providernpi, 
requestedamt, a.sourcedatakey, source, a.frequencycode , a.newfrequencycode,
'1', 'ADJUSTMENT',  replace(convert(date,getdate(),110),'-','') AS loaddatekey, submissionflag ='N', a.TESTBEDCODE, SourceDesc
from #tmporigaccepted2 a
inner join #EXCLUSIONS c on a.claim_id = c.claim_id
where a.newlatest = '1'AND a.newfrequencycode = '7' AND a.claim_id NOT IN (SELECT DISTINCT claimid FROM #adjustmentasorig)
--order by 1


/* DUPE Insert */
insert into #ADJUSTMENT_SUBMISSION
select distinct claimtype, claim_id, adjuddate, origclaimno, '', memberid, beginservicedatekey, providernpi, 
requestedamt, sourcedatakey, source, frequencycode , frequencycode as newfrequencycode,
'2', 'DUPE', replace(convert(date,getdate(),110),'-','') AS loaddatekey, submissionflag = 'N', TESTBEDCODE, ''
from #EXCLUSIONS where claim_id not in (select claimid from #ADJUSTMENT_SUBMISSION)

---------------------------------------------------------------------------------------------------------------
/* LEON ADJUSTMENT UPDATES */
---------------------------------------------------------------------------------------------------------------

/* ADJUSTMENT POPULATION */
insert into #ADJUSTMENT_SUBMISSION
SELECT DISTINCT CASE WHEN FORMTYPECODE ='U' THEN 'I'
                     ELSE 'P' 
			     END AS CLAIMTYPE,
 ADJUSTMENT_CLAIM_ID, '' AS ADJDATE, ORIGCLAIMID, '', MEMBERID, 
BEGINSERVICEDATEKEY, VENDORNPI AS PROVIDERNPI, CLAIMBILLEDAMT AS REQUESTEDAMT, SOURCEDATAKEY,
'LEON XLS' AS SOURCE,
'7' AS FREQUENCYCODE,'7' AS NEWFREQUENCYCODE,'1' AS REASONCODE,'ADJUSTMENT' AS ADJTYPE,
REPLACE(convert(date,getdate(),110),'-','') AS LOADDATEKEY,'N' AS SUBMISSIONFLAG, TESTBEDCODE, ''
--,LOBCODE
FROM WIPRO.dbo.LEON_Adjustments a
JOIN EDPS_Data.DBO.CLAIMDIM b ON a.adjustment_claim_id = b.claimid 
JOIN #TESTBEDLOB c ON b.LOBCODE = c.LOBCode
WHERE FLAG = 'REPLACE'

---------------------------------
/* REPLACEMENT UPDATES */
---------------------------------

insert into #ADJUSTMENT_SUBMISSION
SELECT DISTINCT CASE WHEN FORMTYPECODE ='U' THEN 'I'
                     ELSE 'P' 
			     END AS CLAIMTYPE,
 ADJUSTMENT_CLAIM_ID, '' AS ADJDATE, ORIGCLAIMID, '', MEMBERID, 
BEGINSERVICEDATEKEY, VENDORNPI AS PROVIDERNPI, CLAIMBILLEDAMT AS REQUESTEDAMT, SOURCEDATAKEY,
'LEON XLS' AS SOURCE,
'8' AS FREQUENCYCODE,'8' AS NEWFREQUENCYCODE,'1' AS REASONCODE,'REVERSALS' AS ADJTYPE,
REPLACE(convert(date,getdate(),110),'-','') AS LOADDATEKEY,'N' AS SUBMISSIONFLAG,'xxxx' AS TESTBEDCODE, ''
--LOBCODE
FROM WIPRO.dbo.LEON_Adjustments a
JOIN EDPS_Data.DBO.CLAIMDIM b ON a.adjustment_claim_id = b.claimid 
JOIN #TESTBEDLOB c ON b.LOBCODE = c.LOBCode
WHERE FLAG = 'VOID'

------------------------
/* DUPE UPDATES */
------------------------

insert into #ADJUSTMENT_SUBMISSION
SELECT DISTINCT CASE WHEN FORMTYPECODE ='U' THEN 'I'
                     ELSE 'P' 
			     END AS CLAIMTYPE,
 ADJUSTMENT_CLAIM_ID, '' AS ADJDATE, ORIGCLAIMID, '', MEMBERID, 
BEGINSERVICEDATEKEY, VENDORNPI AS PROVIDERNPI, CLAIMBILLEDAMT AS REQUESTEDAMT, SOURCEDATAKEY,
'LEON XLS' AS SOURCE,
'1' AS FREQUENCYCODE,'1' AS NEWFREQUENCYCODE,'2' AS REASONCODE,'DUPE' AS ADJTYPE,
REPLACE(convert(date,getdate(),110),'-','') AS LOADDATEKEY,'N' AS SUBMISSIONFLAG,TESTBEDCODE, ''
--,LOBCODE
FROM WIPRO.dbo.LEON_Adjustments a
JOIN EDPS_Data.DBO.CLAIMDIM b ON a.adjustment_claim_id = b.claimid 
JOIN #TESTBEDLOB c ON b.LOBCODE = c.LOBCode
WHERE FLAG = 'IGNORE'


/* ---------------------------------------------------------------------------
UPDATE CLAIM_TYPE FOR DME CLAIMS 
------------------------------------------------------------------------------ */
-- RETM-675		add logic to do this update on PROFESSIONAL claims only.  SWaller

UPDATE a 
SET CLAIMTYPE = 'E' 
FROM #ADJUSTMENT_SUBMISSION a 
join EDPS_DATA.[IDQ].[CMSTaxonomy] b on a.PROVIDERNPI  = b.NPI --and [HealthcareProviderPrimaryTaxonomySwitch] ='Y'  Commented out for RETM-241
AND healthcareprovidertaxonomycode IN ('332B00000X','332BC3200X','332BD1200X','332BN1400X','332BX2000X')
WHERE	a.CLAIMTYPE IN ('H', 'P')	-- 'H' is for Professional Claims, just in case any of the H's didn't get transposed to P's

/* ---------------------------------------------------------------------------
UPDATES TO EXCLUDE SUPPLEMENTAL CLAIMS AND PREVIOUSLY SUBMITTED REVERSALS
------------------------------------------------------------------------------ */

UPDATE a 
 SET reason = '2',
     a.adjtype ='HOLD'
FROM #ADJUSTMENT_SUBMISSION a
INNER JOIN WIPRO.DBO.SUPPLEMENTAL_CLAIMS B ON a.claimid = b.PLANCLAIMNBR

 update a 
 set reason ='2',
     a.adjtype ='HOLD'
 from #ADJUSTMENT_SUBMISSION a 
 inner join WIPRO.[dbo].[OUTB_CLAIM_STATUS] b on a.claimid = b.claim_id

 --Adjustment as Originals (Remove claims associated with 9019 edit) 
update a
set reason = '2',
    a.adjtype = 'HOLD'
 FROM #ADJUSTMENT_SUBMISSION a
 INNER JOIN #EXCLUSIONS b on a.claimid = b.claim_id
 join [WIPRO].[dbo].[EXT_CLAIM_EXCLUSION_HIST] c on b.origclaimno = c.claim_id
 and EXCL_ID = '9019'
 WHERE adjtype = 'ADJASORIG'


 --join #EXCLUSIONS b on a.origclaimno = b.claim_id


--------------------------------------------------------------------------------------------------------
/* Exclude Encounter Claims where Original and Reverse Claim numbers are identical */

update a 
set reason = '2',
     a.adjtype = 'HOLDRES'
 from #ADJUSTMENT_SUBMISSION a 
 inner join #EXCLUSIONS b on a.claimid = b.origclaimno


 update a 
set  reason ='2',
	 adjtype = 'ADMINREVERSALS'
 from #ADJUSTMENT_SUBMISSION a WHERE a.claimid like '%R%' and sourcedatakey ='50'

 update a 
 set reason = '2',
 adjtype = 'MEMNOMATCH'
 from #ADJUSTMENT_SUBMISSION a
 inner join EDPS_Data.dbo.Claimdim b on a.origclaimno = b.CLAIMID and a.memberid <> b.MEMBERID


 /* Append Adjustment submission table with the CMS_ICN */ 
 update a 
 set cms_icn = [EncounterICN]
 from #ADJUSTMENT_SUBMISSION a 
 inner join WIPRO.dbo.CMS_MAO_004_Detail b on a.origclaimno = b.claimid
 where adjtype ='REVERSAL'
 
 update a 
 set a.cms_icn = b.cmsicn
 from #ADJUSTMENT_SUBMISSION a 
 inner join WIPRO.[dbo].[MAO_002_Detail] b on a.origclaimno = b.PlanClaimNumber
 where adjtype = 'REVERSAL' and a.cms_icn =''

 -------------------------------------------------------------



-----------------------------------------
/* UDPATE HISTORICAL ADJUSTMENT TABLE */
-----------------------------------------

INSERT INTO WIPRO.DBO.HISTORICAL_CLAIMS_ADJUSTMENTS 
SELECT *
FROM #ADJUSTMENT_SUBMISSION


/* INSERT CLAIMS AVAILABLE FOR SUBMISSION INTO WIPRO ADJUSTMENT TESTBED */

--IF OBJECT_ID('WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS') IS NOT NULL
--TRUNCATE TABLE WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS

INSERT INTO WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS
SELECT 
	[TESTID] = 
	CASE 
		WHEN TESTBEDCODE = 'MAO' and CLAIMTYPE = 'I' and ADJTYPE = 'ADJUSTMENT' THEN '3000'
		WHEN TESTBEDCODE = 'MAO' and CLAIMTYPE = 'P' and ADJTYPE = 'ADJUSTMENT' THEN '3001'
		WHEN TESTBEDCODE = 'MAO' and CLAIMTYPE = 'E' and ADJTYPE = 'ADJUSTMENT' THEN '3006'
		WHEN TESTBEDCODE ='MMAI' and CLAIMTYPE ='I'  and ADJTYPE = 'ADJUSTMENT'THEN '3000'
		WHEN TESTBEDCODE ='MMAI' and CLAIMTYPE ='P'  and ADJTYPE = 'ADJUSTMENT'THEN '3001'
		WHEN TESTBEDCODE ='MMAI' and CLAIMTYPE ='E'  and ADJTYPE = 'ADJUSTMENT'THEN '3006'
		WHEN TESTBEDCODE ='CAID' AND CLAIMTYPE ='I'  and ADJTYPE = 'ADJUSTMENT' THEN '3000'
		WHEN TESTBEDCODE ='CAID' AND CLAIMTYPE ='P'  and ADJTYPE = 'ADJUSTMENT' THEN '3001'
		WHEN TESTBEDCODE ='CAID' AND CLAIMTYPE ='E'  and ADJTYPE = 'ADJUSTMENT' THEN '3006'
		WHEN TESTBEDCODE = 'MAO' and CLAIMTYPE = 'I' and ADJTYPE = 'ADJASORIG' THEN '3060'
		WHEN TESTBEDCODE = 'MAO' and CLAIMTYPE = 'P' and ADJTYPE = 'ADJASORIG' THEN '3061'
		WHEN TESTBEDCODE = 'MAO' and CLAIMTYPE = 'E' and ADJTYPE = 'ADJASORIG' THEN '3066'
		WHEN TESTBEDCODE ='MMAI' and CLAIMTYPE ='I'  and ADJTYPE = 'ADJASORIG'THEN '3060'
		WHEN TESTBEDCODE ='MMAI' and CLAIMTYPE ='P'  and ADJTYPE = 'ADJASORIG'THEN '3061'
		WHEN TESTBEDCODE ='CAID' AND CLAIMTYPE ='I'  and ADJTYPE = 'ADJASORIG' THEN '3060'
		WHEN TESTBEDCODE ='CAID' AND CLAIMTYPE ='P'  and ADJTYPE = 'ADJASORIG' THEN '3061'
	    ELSE '9999'
	END 
,
	[TEST_DESC] = 'ADJUSTMENTHISTORYJOB',
	[CLAIMID] = Claimid,
	[FormTypeCode] ='',
	[typecode] = TESTBEDCODE,
	[DeniedFlag] ='',
	[SOURCEDATAKEY] = SOURCEDATAKEY,
	[CLAIM_TYPE] = CLAIMTYPE,
	[CLM_IND] ='',
	[CLMSTAT_STATUS] ='',
	[LAST_UPD_DATE] = replace(convert(date,getdate(),110),'-',''),
	[DOS_MONTH] = LEFT(beginservicedatekey,6),
	[ORIG_BIDW_EXTRACT_DT] ='',
	[LAST_BIDW_EXTRACT_DT] ='',
	[CMS_ICN],
	[FILEID] ='',
	[LOBCODE] ='',
	[PRODUCTTYPE] ='',
	[SERVICEPLACECODE] ='',
	[HPLAN]='',
	[PAPER_IND] ='',
	[SOURCEDESC] = sourcedesc,
	[HRP_CLAIM_ID] ='',
	[OUTBOUNDVHCLAIMID] ='',
	[INBOUNDFILENAME] ='',
	[NEWFREQUENCYCODE] = NEWFREQUENCYCODE,
	[ORIGCLAIMNO] = ORIGCLAIMNO
FROM #ADJUSTMENT_SUBMISSION 
WHERE REASON = '1' AND SUBMISSIONFLAG = 'N' AND adjtype IN ('ADJUSTMENT', 'ADJASORIG')

UPDATE a
SET SUBMISSIONFLAG = 'Y'
FROM WIPRO.DBO.HISTORICAL_CLAIMS_ADJUSTMENTS a
INNER JOIN WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS b ON a.CLAIMID = b.CLAIMID 



-- CLEAR ADJUSTMENT EXCLUSION FOR SUBMITTED ADJUSTMENTS ---- TETDM-2742 - Comment our Logic that deletes the Adjustment Data from the Exclusion tables 
--**********************************************
--** CODE COMMENTED OUT TETM-2742              *
--**********************************************
--DELETE a
--FROM WIPRO.DBO.EXT_CLAIM_EXCLUSION a
--INNER JOIN WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS b ON a.CLAIM_ID = b.CLAIMID 
--WHERE EXCL_ID = '9019'

--DELETE a
--FROM WIPRO.DBO.EXT_CLAIM_EXCLUSION_HIST a
--INNER JOIN WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS b ON a.CLAIM_ID = b.CLAIMID 
--WHERE EXCL_ID = '9019'

---- REMOVE ANY SOS COMPLIANCE FILTER CLAIMS (DO NOT SUBMIT) ----
--DELETE a
--FROM WIPRO.dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS a
--INNER JOIN WIPRO.DBO.EXT_CLAIM_EXCLUSION_HIST b ON a.CLAIMID = b.CLAIM_ID 
--WHERE EXCL_ID in ('7000','7001')


/* Insert Voids into Void table */
INSERT INTO  WIPRO.Export.Claim_Void_Output
SELECT CLAIMID, a.sourcedatakey, b.WIPRO_CLAIM_ID , '9999999999',--a.cms_icn, 
a.Claimtype, 
--FORMAT(CONVERT(datetime, a.beginservicedatekey),'DD-M-YY') 
SUBSTRING(CAST(beginservicedatekey as varchar(10)),1,4)  + '-' + SUBSTRING(CAST(beginservicedatekey as varchar(10)),5,2)
 + '-' + SUBSTRING(CAST(beginservicedatekey as varchar(10)),7,2)
, NULL, a.memberid, 
'HSCE.' + CASE WHEN @@SERVERNAME = 'HSTNEDSDB01' THEN 'PROD' ELSE 'DEV' END + '.'  + a.SOURCEDATAKEY + '.' +
 a.Claimtype + '.Void.' + REPLACE(replace(replace(convert(varchar,getdate(),120),'-',''),':',''),' ',''),
GETDATE(), 'VE',0,1, NULL
FROM  #ADJUSTMENT_SUBMISSION a
inner join WIPRO.dbo.OUTB_CLAIM_STATUS b on a.origclaimno = b.CLAIM_ID 
WHERE REASON = '1' AND SUBMISSIONFLAG = 'N' AND adjtype = 'REVERSALS' -- Remove SourceDataKey Filter 
and a.Claimid NOT IN (SELECT CLAIMID FROM WIPRO.Export.Claim_Void_Output)


/***************************************************************************************************************************************/
/* STOP HERE */
/***************************************************************************************************************************************/


