﻿


CREATE PROCEDURE [dbo].[EXSP_CLAIM_EXCLUSION_MISSING_DETAIL]     
	(@CLAIMTYPE		CHAR(1) ) -- Valid Values P or I

AS     
     
/***************************************************************************************************     
** CREATE DATE: 06/13/2018      
** AUTHOR: Mike Vega     
** DESCRIPTION: Procedure will identify all ClaimIDs that contian Claim Header but no corresponding
				Claim Detail Lines. These ClaimIDs will be removed from the Claim Header so that no
				claim info is sent in the Outbound File. These ClaimIDs will be added the Exclusion
				Table under Exclusion Code: 9054
				Also deletes the ClaimID from the Claim Header table

Modification History     
====================     
Date			Who				Description     
-----------------------------------------------------------------------------------------------------     
05/21/2018		Mike Vega		TETDM-1613 Remove ClaimIDs from Outbound File where the ClaimID has a
								Claim Header Line but no corresponding Claim Detail Lines.

*****************************************************************************************************/	  
   
--Declare Variables        
	DECLARE     @TOTAL_RECORDS	INT,
				@HOLD_DATE		datetime;

	SELECT		@HOLD_DATE = GETDATE();
				     
--Insert Claim File Run controls Start        
		INSERT INTO EXT_SYS_RUNLOG     
				(PROC_NAME     
				,STEP     
				,START_DT     
				,END_DT     
				,RUN_MINUTES     
				,TOTAL_RECORDS     
				,ENTRYDT     
				)     
		VALUES('EXSP_CLAIM_EXCLUSION_MISSING_DETAIL'
				,'13'     
				,GETDATE()     
				,NULL     
				,NULL     
				,0     
				,GETDATE()     
				)     
					     

--Check for Temp Table and Create								     
		IF OBJECT_ID('TEMPDB..#EXT_CLAIM_EXCLUSION_HIST') <> 0     
		DROP TABLE #EXT_CLAIM_EXCLUSION_HIST     
								     
		CREATE TABLE #EXT_CLAIM_EXCLUSION_HIST     
		(	CLAIM_ID		VARCHAR(20) NULL,
			SOURCEDATAKEY	INT NULL,
			BATCH_RUN_DT	datetime NULL,
			EXCL_ID			int NULL,
			CLAIM_TYPE		char(5) NULL
		)         
								     
--Exclusion #9054 - Claims with Missing Detail Lines 
		
	IF @CLAIMTYPE = 'P' -- professional
	BEGIN
		--Load Claim Data into Temp Exclusion Table   
		INSERT INTO #EXT_CLAIM_EXCLUSION_HIST
			(CLAIM_ID, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE)     
		select DISTINCT oph.CLAIM_ID,
						oph.SOURCEDATAKEY,
						@HOLD_DATE AS 'BATCH_RUNDT',
						9054,
						oph.CLAIM_TYPE
		from dbo.OUTB_PROF_HEADER oph
			left join dbo.OUTB_PROF_DETAIL opd on opd.claim_id = oph.claim_id
			left join edps_data.dbo.claimdim cd on cd.claimid = oph.claim_id
		where opd.claim_id is null

		--Remove Claim Header Data for records not having matching Detail Data
		DELETE	FROM dbo.OUTB_PROF_HEADER
		WHERE	claim_id in (select claim_id from #EXT_CLAIM_EXCLUSION_HIST)
	END

	IF @CLAIMTYPE = 'I' -- institutional
	BEGIN
		--Load Claim Data into Temp Exclusion Table   
		INSERT INTO #EXT_CLAIM_EXCLUSION_HIST
			(CLAIM_ID, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE)     
		select DISTINCT oph.CLAIM_ID,
						oph.SOURCEDATAKEY,
						@HOLD_DATE AS 'BATCH_RUNDT',
						9054,
						oph.CLAIM_TYPE
		from dbo.OUTB_INST_HEADER oph
			left join dbo.OUTB_INST_DETAIL opd on opd.claim_id = oph.claim_id
			left join edps_data.dbo.claimdim cd on cd.claimid = oph.claim_id
		where opd.claim_id is null

		--Remove Claim Header Data for records not having matching Detail Data
		DELETE	FROM dbo.OUTB_INST_HEADER
		WHERE	claim_id in (select claim_id from #EXT_CLAIM_EXCLUSION_HIST)
	END

-- Scott Waller 7/6/18
-- this prevents INSERTING claim multiple times
-- this can only happen for resub (special jobid's) jobs where
-- they force claims and ignore the Exclusion Table
		DELETE	FROM #EXT_CLAIM_EXCLUSION_HIST
		WHERE	CLAIM_ID IN	(	SELECT	DISTINCT a.CLAIM_ID
								FROM	#EXT_CLAIM_EXCLUSION_HIST	a
								INNER JOIN EXT_CLAIM_EXCLUSION_HIST b
									ON	b.CLAIM_ID		= a.CLAIM_ID		
									AND	b.SOURCEDATAKEY	= a.SOURCEDATAKEY
									AND	b.EXCL_ID		= 9054	)

--Load Exclusions to final table								     
		INSERT INTO EXT_CLAIM_EXCLUSION_HIST
			(CLAIM_ID, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, CLAIM_TYPE) 
		SELECT	CLAIM_ID,     
				SOURCEDATAKEY,
				BATCH_RUN_DT,
				EXCL_ID,
				CLAIM_TYPE
		FROM #EXT_CLAIM_EXCLUSION_HIST
						
--Get Total Records Count								     
		SET @TOTAL_RECORDS = @@ROWCOUNT  
 
--Update Final Run Controls End          
		UPDATE EXT_SYS_RUNLOG     
			SET END_DT = GETDATE()	     
				,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())     
				,TOTAL_RECORDS = @TOTAL_RECORDS     
				,ENTRYDT = GETDATE()     
			WHERE PROC_NAME = 'EXSP_CLAIM_EXCLUSION_MISSING_DETAIL'
					AND END_DT IS NULL     
							     
		IF OBJECT_ID('TEMPDB..#EXT_CLAIM_EXCLUSION_HIST') <> 0     
		DROP TABLE #EXT_CLAIM_EXCLUSION_HIST     


