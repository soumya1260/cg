﻿CREATE PROCEDURE [dbo].[pr_MAO004_LEON]

AS
/***************************************************************************************************
** CREATE DATE: 03/20/2016
**
** AUTHOR: LOYAL RICKS -  Loyal.Ricks@healthspring.com
**
** DESCRIPTION:		Append all Leon (sdk=30) MAO004 results into MAO_004_LEON table in order to 
**					populate hstnedsrpt01.Raps_Leon database with EDS MAO004 data. The process will
**					complete a total refresh of the MAO_004_DETAIL_LEON table from the EDS MAO004
**					Daily and historical tables after each EDS MAO004 update. This will ensure that 
**					all available MAO004 records are appended during each run. 
**
**
Modification History
====================
Date			Who				Description
*****************************************************/
						DECLARE
			
							@TOTAL_RECORDS INT
			

						-- Run controls
			
											INSERT INTO EXT_SYS_RUNLOG
													(PROC_NAME
													,STEP
													,START_DT
													,END_DT
													,RUN_MINUTES
													,TOTAL_RECORDS
													,ENTRYDT
													)
											VALUES('pr_MAO004_LEON'
													,'1'
													,GETDATE()
													,NULL
													,NULL
													,0
													,GETDATE()
													)
					
						TRUNCATE TABLE MAO_004_DETAIL_LEON

						IF OBJECT_ID('TEMPDB..#MAO_004_LEON_DAILY') <> 0
											DROP TABLE #MAO_004_LEON_DAILY
					
											CREATE TABLE #MAO_004_LEON_DAILY
											(  sourcedatakey int,
												claimid varchar(20),
												MeidcareAdvContractID varchar(5)
						
											)

					---Compile all Leon claims from EDS Daily MAO004 data
					
						insert into #MAO_004_LEON_DAILY
						select C.SOURCEDATAKEY
								,M.CLAIMID
								,M.MEDICAREADVCONTRACTID
						from MAO_004_DETAIL_DAILY M 
						INNER JOIN EDPS_DATA.DBO.CLAIMDIM C
						ON M.CLAIMID = C.CLAIMID
						AND C.SOURCEDATAKEY = 30

						INSERT INTO MAO_004_DETAIL_LEON
						SELECT M.* 
						FROM MAO_004_DETAIL_DAILY M 
						INNER JOIN #MAO_004_LEON_DAILY T
						ON M.CLAIMID = t.CLAIMID

						---Compile all Leon claims from EDS History MAO004 data

						---Rebuild #MAO_004_LEON 
						IF OBJECT_ID('TEMPDB..#MAO_004_LEON') <> 0
											DROP TABLE #MAO_004_LEON
					
											CREATE TABLE #MAO_004_LEON
											(  sourcedatakey int,
												claimid varchar(20),
												MeidcareAdvContractID varchar(5)
						
											)

						insert into #MAO_004_LEON
						select C.SOURCEDATAKEY
								,M.CLAIMID
								,M.MEDICAREADVCONTRACTID
						from MAO_004_DETAIL M 
						INNER JOIN EDPS_DATA.DBO.CLAIMDIM C
						ON M.CLAIMID = C.CLAIMID
						AND C.SOURCEDATAKEY = 30



						INSERT INTO MAO_004_DETAIL_LEON
						SELECT M.* 
						FROM MAO_004_DETAIL_DAILY M 
						INNER JOIN #MAO_004_LEON T
						ON M.CLAIMID = t.CLAIMID


						---insert Verisk Leon claims from WIPRO MAO002

						insert into MAO_004_DETAIL_LEON
						select MD.*
						from MAO_004_DETAIL md
						inner join EDPS.DBO.EXT_HRP_CLAIM_STATUS CS
						ON MD.EncounterICN = CS.CMS_ICN 
						AND MD.BeneficiaryHICN = CS.HICN_NUM
						where len(claimid) = 0
						and len(wipro_claimid) = 0
						and MedicareAdvContractID = 'H5410'
						AND CS.SOURCEDATAKEY = 30

						--Update total records

						set @TOTAL_RECORDS = (select count(*) from MAO_004_DETAIL_LEON);


					UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_MAO004_LEON' 
										and END_DT is null


