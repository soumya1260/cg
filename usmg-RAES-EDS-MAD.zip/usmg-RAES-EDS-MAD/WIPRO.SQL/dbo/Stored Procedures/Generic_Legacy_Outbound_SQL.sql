﻿/*
This procedure will remove claims from the testbed table that matches the @Table_To_Clean input.
Author: ASU
Create Date: 09/05/2023
-------------------------------------------------
Notes:
Referenced By: SSIS Project: Packages-Submission
									|
									--> Main_Execute_Package.dtsx (SSISDB)
09/05/2023:
--Initial creation
01/12/2024
--Update to fix incorrect "IF" path to execute cleanup

*/
CREATE PROCEDURE [dbo].[Generic_Legacy_Outbound_SQL]	
	@Job varchar(50),
	@Job_Type varchar(255)
AS
	
	DECLARE @archiveDate DATETIME = GETDATE(),
			@START_DT DATETIME = GETDATE();
	

	IF @job = 'Clean' BEGIN;
		/*
		Clean Encounter Test Bed
		*/
		IF @Job_Type = 'Encounter' BEGIN;
		
			INSERT INTO dbo.OUTB_WIPRO_TEST_BED_Archive 
				(TestID, TEST_DESC, CLAIMID, FormTypeCode, typecode, DeniedFlag, SOURCEDATAKEY, 
				CLAIM_TYPE, CLM_IND, CLMSTAT_STATUS, LAST_UPD_DATE, DOS_MONTH, ORIG_BIDW_EXTRACT_DT, 
				LAST_BIDW_EXTRACT_DT, CMS_ICN, FILEID, LOBCODE, PRODUCTTYPE, SERVICEPLACECODE, 
				HPLAN, PAPER_IND, SOURCEDESC, HRP_CLAIM_ID, OUTBOUNDVHCLAIMID, INBOUNDFILENAME, ARCHIVE_DT)
				SELECT
					 sub.TestID
					,sub.TEST_DESC
					,sub.CLAIMID
					,sub.FormTypeCode
					,sub.typecode
					,sub.DeniedFlag
					,sub.SOURCEDATAKEY
					,sub.CLAIM_TYPE
					,sub.CLM_IND
					,sub.CLMSTAT_STATUS
					,sub.LAST_UPD_DATE
					,sub.DOS_MONTH
					,sub.ORIG_BIDW_EXTRACT_DT
					,sub.LAST_BIDW_EXTRACT_DT
					,sub.CMS_ICN
					,sub.FILEID
					,sub.LOBCODE
					,sub.PRODUCTTYPE
					,sub.SERVICEPLACECODE
					,sub.HPLAN
					,sub.PAPER_IND
					,sub.SOURCEDESC
					,sub.HRP_CLAIM_ID
					,sub.OUTBOUNDVHCLAIMID
					,sub.INBOUNDFILENAME
					,ARCHIVE_DT = @archiveDate
				FROM (
						DELETE FROM dbo.OUTB_WIPRO_TEST_BED
							OUTPUT 
							  DELETED.TestID,
							  DELETED.TEST_DESC
							, DELETED.CLAIMID
							, DELETED.FormTypeCode
							, DELETED.typecode
							, DELETED.DeniedFlag
							, DELETED.SOURCEDATAKEY
							, DELETED.CLAIM_TYPE
							, DELETED.CLM_IND
							, DELETED.CLMSTAT_STATUS
							, DELETED.LAST_UPD_DATE
							, DELETED.DOS_MONTH
							, DELETED.ORIG_BIDW_EXTRACT_DT
							, DELETED.LAST_BIDW_EXTRACT_DT
							, DELETED.CMS_ICN
							, DELETED.FILEID
							, DELETED.LOBCODE
							, DELETED.PRODUCTTYPE
							, DELETED.SERVICEPLACECODE
							, DELETED.HPLAN
							, DELETED.PAPER_IND
							, DELETED.SOURCEDESC
							, DELETED.HRP_CLAIM_ID
							, DELETED.OUTBOUNDVHCLAIMID
							, DELETED.INBOUNDFILENAME
						WHERE TestID IN (5001, 5002)) sub;

			INSERT INTO dbo.EXT_SYS_RUNLOG (PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
			SELECT 
				CONCAT('Generic_Legacy_Outbound_SQL: ',@Job_Type),
				'0000',
				@START_DT,
				GETDATE(),
				DATEDIFF(MINUTE,@START_DT,GETDATE()),
				@@rowcount,
				GETDATE();
		END;

		/*
		Clean Regular Test Bed
		*/
		ELSE IF @Job_Type = 'Regular' BEGIN;
	
			DECLARE	@LOW_ID				INT,
					@HIGH_ID			INT;			

			SELECT	@LOW_ID		= LOW_ID,
					@HIGH_ID	= HIGH_ID
			FROM	dbo.EXT_SYS_JOB_RANGE
			WHERE	NAME		= '2000s';


			INSERT INTO dbo.OUTB_WIPRO_TEST_BED_Archive		
				(TestID, TEST_DESC, CLAIMID, FormTypeCode, typecode, DeniedFlag, SOURCEDATAKEY, 
				CLAIM_TYPE, CLM_IND, CLMSTAT_STATUS, LAST_UPD_DATE, DOS_MONTH, ORIG_BIDW_EXTRACT_DT, 
				LAST_BIDW_EXTRACT_DT, CMS_ICN, FILEID, LOBCODE, PRODUCTTYPE, SERVICEPLACECODE, 
				HPLAN, PAPER_IND, SOURCEDESC, HRP_CLAIM_ID, OUTBOUNDVHCLAIMID, INBOUNDFILENAME, ARCHIVE_DT)
				SELECT
						sub.TestID
					,sub.TEST_DESC
					,sub.CLAIMID
					,sub.FormTypeCode
					,sub.typecode
					,sub.DeniedFlag
					,sub.SOURCEDATAKEY
					,sub.CLAIM_TYPE
					,sub.CLM_IND
					,sub.CLMSTAT_STATUS
					,sub.LAST_UPD_DATE
					,sub.DOS_MONTH
					,sub.ORIG_BIDW_EXTRACT_DT
					,sub.LAST_BIDW_EXTRACT_DT
					,sub.CMS_ICN
					,sub.FILEID
					,sub.LOBCODE
					,sub.PRODUCTTYPE
					,sub.SERVICEPLACECODE
					,sub.HPLAN
					,sub.PAPER_IND
					,sub.SOURCEDESC
					,sub.HRP_CLAIM_ID
					,sub.OUTBOUNDVHCLAIMID
					,sub.INBOUNDFILENAME
					,ARCHIVE_DT = @archiveDate
				FROM (
						DELETE FROM dbo.OUTB_WIPRO_TEST_BED
							OUTPUT 
								DELETED.TestID,
								DELETED.TEST_DESC
							, DELETED.CLAIMID
							, DELETED.FormTypeCode
							, DELETED.typecode
							, DELETED.DeniedFlag
							, DELETED.SOURCEDATAKEY
							, DELETED.CLAIM_TYPE
							, DELETED.CLM_IND
							, DELETED.CLMSTAT_STATUS
							, DELETED.LAST_UPD_DATE
							, DELETED.DOS_MONTH
							, DELETED.ORIG_BIDW_EXTRACT_DT
							, DELETED.LAST_BIDW_EXTRACT_DT
							, DELETED.CMS_ICN
							, DELETED.FILEID
							, DELETED.LOBCODE
							, DELETED.PRODUCTTYPE
							, DELETED.SERVICEPLACECODE
							, DELETED.HPLAN
							, DELETED.PAPER_IND
							, DELETED.SOURCEDESC
							, DELETED.HRP_CLAIM_ID
							, DELETED.OUTBOUNDVHCLAIMID
							, DELETED.INBOUNDFILENAME
						WHERE TestID BETWEEN @LOW_ID AND @HIGH_ID) sub;

		
			INSERT INTO dbo.EXT_SYS_RUNLOG (PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
			SELECT 
				CONCAT('Generic_Legacy_Outbound_SQL: ',@Job_Type),
				'0000',
				@START_DT,
				GETDATE(),
				DATEDIFF(MINUTE,@START_DT,GETDATE()),
				@@rowcount,
				GETDATE();
		END;
		/*
		Clean adjustment Test Bed
		*/
		ELSE IF @Job_Type = 'Adjustment' BEGIN;

			INSERT INTO OUTB_WIPRO_TEST_BED_ADJUSTMENTS_BKUP 
			(TESTID, TEST_DESC, CLAIMID, FormTypeCode, typecode, DeniedFlag, SOURCEDATAKEY, CLAIM_TYPE, CLM_IND, 
			CLMSTAT_STATUS, LAST_UPD_DATE, DOS_MONTH, ORIG_BIDW_EXTRACT_DT, LAST_BIDW_EXTRACT_DT, CMS_ICN, FILEID, 
			LOBCODE, PRODUCTTYPE, SERVICEPLACECODE, HPLAN, PAPER_IND, SOURCEDESC, HRP_CLAIM_ID, OUTBOUNDVHCLAIMID, 
			INBOUNDFILENAME, NEWFREQUENCYCODE, ORIGCLAIMNO)
			SELECT
			*
			FROM (	DELETE owtba
					OUTPUT
						DELETED.TESTID
					   ,DELETED.TEST_DESC
					   ,DELETED.CLAIMID
					   ,DELETED.FormTypeCode
					   ,DELETED.typecode
					   ,DELETED.DeniedFlag
					   ,DELETED.SOURCEDATAKEY
					   ,DELETED.CLAIM_TYPE
					   ,DELETED.CLM_IND
					   ,DELETED.CLMSTAT_STATUS
					   ,DELETED.LAST_UPD_DATE
					   ,DELETED.DOS_MONTH
					   ,DELETED.ORIG_BIDW_EXTRACT_DT
					   ,DELETED.LAST_BIDW_EXTRACT_DT
					   ,DELETED.CMS_ICN
					   ,DELETED.FILEID
					   ,DELETED.LOBCODE
					   ,DELETED.PRODUCTTYPE
					   ,DELETED.SERVICEPLACECODE
					   ,DELETED.HPLAN
					   ,DELETED.PAPER_IND
					   ,DELETED.SOURCEDESC
					   ,DELETED.HRP_CLAIM_ID
					   ,DELETED.OUTBOUNDVHCLAIMID
					   ,DELETED.INBOUNDFILENAME
					   ,DELETED.NEWFREQUENCYCODE
					   ,DELETED.ORIGCLAIMNO
					FROM dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS owtba) SUB;

			INSERT INTO dbo.EXT_SYS_RUNLOG (PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
			SELECT 
				CONCAT('Generic_Legacy_Outbound_SQL: ',@Job_Type),
				'0000',
				@START_DT,
				GETDATE(),
				DATEDIFF(MINUTE,@START_DT,GETDATE()),
				@@ROWCOUNT,
				GETDATE();

		END;
	END;
	/*
	Update Service_Line_Dup_Processing
	*/
	ELSE IF @job = 'Update Service_Line_Dup_Processing' BEGIN;

		UPDATE sldp
		SET Has_Been_Resubmitted = 1
		FROM dbo.Service_Line_Dup_Processing sldp
		WHERE 1 = 1
			AND sldp.Is_Resubmission_Eligible = 1
			AND sldp.Has_Been_Resubmitted = 0
			AND sldp.Error_Code = '98325'
			AND EXISTS (
						SELECT
						*
						FROM dbo.OUTB_WIPRO_TEST_BED_Archive owtba
						WHERE 1 = 1
							AND owtba.TEST_DESC = '98325_Resub'
							AND owtba.CLAIMID = sldp.Claim_ID
							AND owtba.SOURCEDATAKEY = sldp.Sourcedatakey);

		INSERT INTO dbo.EXT_SYS_RUNLOG (PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)
		SELECT 
			CONCAT('Generic_Legacy_Outbound_SQL: ',@Job_Type),
			'0000',
			@START_DT,
			GETDATE(),
			DATEDIFF(MINUTE,@START_DT,GETDATE()),
			@@rowcount,
			GETDATE();
	END;

	/*
	Log in generic file log table 	
	*/
	DECLARE @Job_ID INT;

	INSERT INTO dbo.Generic_File_Config_Log (Run_Job_Config_Name)
	SELECT @Job
	EXCEPT
	SELECT	
		gfcl.Run_Job_Config_Name
	FROM dbo.Generic_File_Config_Log gfcl;

	SELECT TOP 1
		@Job_ID = gfcl.Job_ID	
	FROM dbo.Generic_File_Config_Log gfcl
	WHERE gfcl.Run_Job_Config_Name = @Job;

	INSERT INTO dbo.Generic_File_Config_Log_Detail (FK_JOB_ID, Run_String, Run_Date)
		SELECT
			@Job_ID,
			@Job_Type,
			GETDATE();
	--End Logging


RETURN 0;
