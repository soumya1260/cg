﻿
		 
 
 
 
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_ENCOUNTER_HISTORICAL_CLAIM_COND_OCCCD] 
(@SOURCE_DESC VARCHAR(60))--,@SOURCE_ENVIRONMENT VARCHAR(10)) 
AS 
/*************************************************************************************************** 
** CREATE DATE: 08/2016 
** 
** AUTHOR: LOYAL RICKS - Loyal Ricks - Loyal.Ricks@healthspring.com 
** 
** DESCRIPTION: Encounter Historic Claim Inst Occurence Code 
** 
** 
Modification History 
==================== 
Date			Who				Description 
----------------------------------------------------------------------------------------------------- 
05/20/2019		Scott Waller	TETDM-2058  Performance of this sproc has gone downhill terribly.  
								To try and improve performance, we need to remove the RTRIM on the joins
								to HistoricalClaims.  It causes it to table scan and not use the indexes.
								 
*****************************************************************************************************/			 
	--DECLARE VARIABLES 
 
			DECLARE 
			 
			@TOTAL_RECORDS INT 
			 
 
--HRP_CLAIM_FILE Run controls 
INSERT INTO EXT_SYS_RUNLOG 
		(PROC_NAME 
		,STEP 
		,START_DT 
		,END_DT 
		,RUN_MINUTES 
		,TOTAL_RECORDS 
		,ENTRYDT 
		) 
		VALUES('pr_BUILD_OUTB_INST_ENCOUNTER_HISTORICAL_CLAIM_OCCCD' 
				,'5' 
				,GETDATE() 
				,NULL 
				,NULL 
				,0 
				,GETDATE() 
				) 
			 
 
			 
				 
						IF OBJECT_ID('TEMPDB..##HistoricalClaim_INST') <> 0 
											DROP TABLE ##HistoricalClaim_INST 
 
 
						CREATE TABLE [dbo].##HistoricalClaim_INST( 
							--[HistoricalClaimID] [int] NOT NULL, 
							[ClaimID] [varchar](50) NOT NULL, 
							[ClaimNo] [varchar](50) NULL, 
							[CLM01] [varchar](50) NULL,	 
							[ConditionCode1] [varchar](30) NULL, 
							[ConditionCode2] [varchar](30) NULL, 
							[ConditionCode3] [varchar](30) NULL, 
							[ConditionCode4] [varchar](30) NULL, 
							[ConditionCode5] [varchar](30) NULL, 
							[ConditionCode6] [varchar](30) NULL, 
							[ConditionCode7] [varchar](30) NULL, 
							[ConditionCode8] [varchar](30) NULL, 
							[ConditionCode9] [varchar](30) NULL, 
							[ConditionCode10] [varchar](30) NULL, 
							[ConditionCode11] [varchar](30) NULL, 
							[ConditionCode12] [varchar](30) NULL, 
							[OccurrenceCode1] [varchar](50) NULL, 
							[OccurrenceDate1] [varchar](35) NULL, 
							[OccurrenceCode2] [varchar](50) NULL, 
							[OccurrenceDate2] [varchar](35) NULL, 
							[OccurrenceCode3] [varchar](50) NULL, 
							[OccurrenceDate3] [varchar](35) NULL, 
							[OccurrenceCode4] [varchar](50) NULL, 
							[OccurrenceDate4] [varchar](35) NULL, 
							[OccurrenceCode5] [varchar](50) NULL, 
							[OccurrenceDate5] [varchar](35) NULL, 
							[OccurrenceCode6] [varchar](50) NULL, 
							[OccurrenceDate6] [varchar](35) NULL, 
							[OccurrenceCode7] [varchar](50) NULL, 
							[OccurrenceDate7] [varchar](35) NULL, 
							[OccurrenceCode8] [varchar](50) NULL, 
							[OccurrenceDate8] [varchar](35) NULL, 
							[OccurrenceCode9] [varchar](50) NULL, 
							[OccurrenceDate9] [varchar](35) NULL, 
							[OccurrenceCode10] [varchar](50) NULL, 
							[OccurrenceDate10] [varchar](35) NULL, 
							[OccurrenceCode11] [varchar](50) NULL, 
							[OccurrenceDate11] [varchar](35) NULL, 
							[OccurrenceCode12] [varchar](50) NULL, 
							[OccurrenceDate12] [varchar](35) NULL, 
							[OccurrenceCode13] [varchar](50) NULL, 
							[OccurrenceDate13] [varchar](35) NULL, 
							[OccurrenceCode14] [varchar](50) NULL, 
							[OccurrenceDate14] [varchar](35) NULL, 
							[OccurrenceCode15] [varchar](50) NULL, 
							[OccurrenceDate15] [varchar](35) NULL, 
							[OccurrenceCode16] [varchar](50) NULL, 
							[OccurrenceDate16] [varchar](35) NULL, 
							[OccurrenceCode17] [varchar](50) NULL, 
							[OccurrenceDate17] [varchar](35) NULL, 
							[OccurrenceCode18] [varchar](50) NULL, 
							[OccurrenceDate18] [varchar](35) NULL, 
							[OccurrenceCode19] [varchar](50) NULL, 
							[OccurrenceDate19] [varchar](35) NULL, 
							[OccurrenceCode20] [varchar](50) NULL, 
							[OccurrenceDate20] [varchar](35) NULL, 
							[OccurrenceCode21] [varchar](50) NULL, 
							[OccurrenceDate21] [varchar](35) NULL, 
							[OccurrenceCode22] [varchar](50) NULL, 
							[OccurrenceDate22] [varchar](35) NULL, 
							[OccurrenceCode23] [varchar](50) NULL, 
							[OccurrenceDate23] [varchar](35) NULL, 
							[OccurrenceCode24] [varchar](50) NULL, 
							[OccurrenceDate24] [varchar](35) NULL, 
							[OccurrenceSpanCode1] [varchar](50) NULL, 
							[OccurrenceSpanFrom1] [varchar](35) NULL, 
							[OccurrenceSpanTo1] [varchar](35) NULL, 
							[OccurrenceSpanCode2] [varchar](50) NULL, 
							[OccurrenceSpanFrom2] [varchar](35) NULL, 
							[OccurrenceSpanTo2] [varchar](35) NULL, 
							[OccurrenceSpanCode3] [varchar](50) NULL, 
							[OccurrenceSpanFrom3] [varchar](35) NULL, 
							[OccurrenceSpanTo3] [varchar](35) NULL, 
							[OccurrenceSpanCode4] [varchar](50) NULL, 
							[OccurrenceSpanFrom4] [varchar](35) NULL, 
							[OccurrenceSpanTo4] [varchar](35) NULL, 
							[OccurrenceSpanCode5] [varchar](50) NULL, 
							[OccurrenceSpanFrom5] [varchar](35) NULL, 
							[OccurrenceSpanTo5] [varchar](35) NULL, 
							[OccurrenceSpanCode6] [varchar](50) NULL, 
							[OccurrenceSpanFrom6] [varchar](35) NULL, 
							[OccurrenceSpanTo6] [varchar](35) NULL, 
							[OccurrenceSpanCode7] [varchar](50) NULL, 
							[OccurrenceSpanFrom7] [varchar](35) NULL, 
							[OccurrenceSpanTo7] [varchar](35) NULL, 
							[OccurrenceSpanCode8] [varchar](50) NULL, 
							[OccurrenceSpanFrom8] [varchar](35) NULL, 
							[OccurrenceSpanTo8] [varchar](35) NULL, 
							[OccurrenceSpanCode9] [varchar](50) NULL, 
							[OccurrenceSpanFrom9] [varchar](35) NULL, 
							[OccurrenceSpanTo9] [varchar](35) NULL, 
							[OccurrenceSpanCode10] [varchar](50) NULL, 
							[OccurrenceSpanFrom10] [varchar](35) NULL, 
							[OccurrenceSpanTo10] [varchar](35) NULL, 
							[OccurrenceSpanCode11] [varchar](50) NULL, 
							[OccurrenceSpanFrom11] [varchar](35) NULL, 
							[OccurrenceSpanTo11] [varchar](35) NULL, 
							[OccurrenceSpanCode12] [varchar](50) NULL, 
							[OccurrenceSpanFrom12] [varchar](35) NULL, 
							[OccurrenceSpanTo12] [varchar](35) NULL, 
							[OccurrenceSpanCode13] [varchar](50) NULL, 
							[OccurrenceSpanFrom13] [varchar](35) NULL, 
							[OccurrenceSpanTo13] [varchar](35) NULL, 
							[OccurrenceSpanCode14] [varchar](50) NULL, 
							[OccurrenceSpanFrom14] [varchar](35) NULL, 
							[OccurrenceSpanTo14] [varchar](35) NULL, 
							[OccurrenceSpanCode15] [varchar](50) NULL, 
							[OccurrenceSpanFrom15] [varchar](35) NULL, 
							[OccurrenceSpanTo15] [varchar](35) NULL, 
							[OccurrenceSpanCode16] [varchar](50) NULL, 
							[OccurrenceSpanFrom16] [varchar](35) NULL, 
							[OccurrenceSpanTo16] [varchar](35) NULL, 
							[OccurrenceSpanCode17] [varchar](50) NULL, 
							[OccurrenceSpanFrom17] [varchar](35) NULL, 
							[OccurrenceSpanTo17] [varchar](35) NULL, 
							[OccurrenceSpanCode18] [varchar](50) NULL, 
							[OccurrenceSpanFrom18] [varchar](35) NULL, 
							[OccurrenceSpanTo18] [varchar](35) NULL, 
							[OccurrenceSpanCode19] [varchar](50) NULL, 
							[OccurrenceSpanFrom19] [varchar](35) NULL, 
							[OccurrenceSpanTo19] [varchar](35) NULL, 
							[OccurrenceSpanCode20] [varchar](50) NULL, 
							[OccurrenceSpanFrom20] [varchar](35) NULL, 
							[OccurrenceSpanTo20] [varchar](35) NULL, 
							[OccurrenceSpanCode21] [varchar](50) NULL, 
							[OccurrenceSpanFrom21] [varchar](35) NULL, 
							[OccurrenceSpanTo21] [varchar](35) NULL, 
							[OccurrenceSpanCode22] [varchar](50) NULL, 
							[OccurrenceSpanFrom22] [varchar](35) NULL, 
							[OccurrenceSpanTo22] [varchar](35) NULL, 
							[OccurrenceSpanCode23] [varchar](50) NULL, 
							[OccurrenceSpanFrom23] [varchar](35) NULL, 
							[OccurrenceSpanTo23] [varchar](35) NULL, 
							[OccurrenceSpanCode24] [varchar](50) NULL, 
							[OccurrenceSpanFrom24] [varchar](35) NULL, 
							[OccurrenceSpanTo24] [varchar](35) NULL, 
							[CLAIM_ID] [VARCHAR] (50) NULL, 
							[SOURCE_DESC] [VARCHAR] (60) NULL 
							) 
	 
						INSERT INTO ##HistoricalClaim_INST 
						select DISTINCT 
								--HISTORICALCLAIMID, 
								CLAIMID 
								,CLAIMNO 
								,CLM01 
								,[ConditionCode1] 
								  ,[ConditionCode2] 
								  ,[ConditionCode3] 
								  ,[ConditionCode4] 
								  ,[ConditionCode5] 
								  ,[ConditionCode6] 
								  ,[ConditionCode7] 
								  ,[ConditionCode8] 
								  ,[ConditionCode9] 
								  ,[ConditionCode10] 
								  ,[ConditionCode11] 
								  ,[ConditionCode12] 
									,[OccurrenceCode1] 
								  ,[OccurrenceDate1] 
								  ,[OccurrenceCode2] 
								  ,[OccurrenceDate2] 
								  ,[OccurrenceCode3] 
								  ,[OccurrenceDate3] 
								  ,[OccurrenceCode4] 
								  ,[OccurrenceDate4] 
								  ,[OccurrenceCode5] 
								  ,[OccurrenceDate5] 
								  ,[OccurrenceCode6] 
								  ,[OccurrenceDate6] 
								  ,[OccurrenceCode7] 
								  ,[OccurrenceDate7] 
								  ,[OccurrenceCode8] 
								  ,[OccurrenceDate8] 
								  ,[OccurrenceCode9] 
								  ,[OccurrenceDate9] 
								  ,[OccurrenceCode10] 
								  ,[OccurrenceDate10] 
								  ,[OccurrenceCode11] 
								  ,[OccurrenceDate11] 
								  ,[OccurrenceCode12] 
								  ,[OccurrenceDate12] 
								  ,[OccurrenceCode13] 
								  ,[OccurrenceDate13] 
								  ,[OccurrenceCode14] 
								  ,[OccurrenceDate14] 
								  ,[OccurrenceCode15] 
								  ,[OccurrenceDate15] 
								  ,[OccurrenceCode16] 
								  ,[OccurrenceDate16] 
								  ,[OccurrenceCode17] 
								  ,[OccurrenceDate17] 
								  ,[OccurrenceCode18] 
								  ,[OccurrenceDate18] 
								  ,[OccurrenceCode19] 
								  ,[OccurrenceDate19] 
								  ,[OccurrenceCode20] 
								  ,[OccurrenceDate20] 
								  ,[OccurrenceCode21] 
								  ,[OccurrenceDate21] 
								  ,[OccurrenceCode22] 
								  ,[OccurrenceDate22] 
								  ,[OccurrenceCode23] 
								  ,[OccurrenceDate23] 
								  ,[OccurrenceCode24] 
								  ,[OccurrenceDate24] 
								  ,[OccurrenceSpanCode1] 
								  ,[OccurrenceSpanFrom1] 
								  ,[OccurrenceSpanTo1] 
								  ,[OccurrenceSpanCode2] 
								  ,[OccurrenceSpanFrom2] 
								  ,[OccurrenceSpanTo2] 
								  ,[OccurrenceSpanCode3] 
								  ,[OccurrenceSpanFrom3] 
								  ,[OccurrenceSpanTo3] 
								  ,[OccurrenceSpanCode4] 
								  ,[OccurrenceSpanFrom4] 
								  ,[OccurrenceSpanTo4] 
								  ,[OccurrenceSpanCode5] 
								  ,[OccurrenceSpanFrom5] 
								  ,[OccurrenceSpanTo5] 
								  ,[OccurrenceSpanCode6] 
								  ,[OccurrenceSpanFrom6] 
								  ,[OccurrenceSpanTo6] 
								  ,[OccurrenceSpanCode7] 
								  ,[OccurrenceSpanFrom7] 
								  ,[OccurrenceSpanTo7] 
								  ,[OccurrenceSpanCode8] 
								  ,[OccurrenceSpanFrom8] 
								  ,[OccurrenceSpanTo8] 
								  ,[OccurrenceSpanCode9] 
								  ,[OccurrenceSpanFrom9] 
								  ,[OccurrenceSpanTo9] 
								  ,[OccurrenceSpanCode10] 
								  ,[OccurrenceSpanFrom10] 
								  ,[OccurrenceSpanTo10] 
								  ,[OccurrenceSpanCode11] 
								  ,[OccurrenceSpanFrom11] 
								  ,[OccurrenceSpanTo11] 
								  ,[OccurrenceSpanCode12] 
								  ,[OccurrenceSpanFrom12] 
								  ,[OccurrenceSpanTo12] 
								  ,[OccurrenceSpanCode13] 
								  ,[OccurrenceSpanFrom13] 
								  ,[OccurrenceSpanTo13] 
								  ,[OccurrenceSpanCode14] 
								  ,[OccurrenceSpanFrom14] 
								  ,[OccurrenceSpanTo14] 
								  ,[OccurrenceSpanCode15] 
								  ,[OccurrenceSpanFrom15] 
								  ,[OccurrenceSpanTo15] 
								  ,[OccurrenceSpanCode16] 
								  ,[OccurrenceSpanFrom16] 
								  ,[OccurrenceSpanTo16] 
								  ,[OccurrenceSpanCode17] 
								  ,[OccurrenceSpanFrom17] 
								  ,[OccurrenceSpanTo17] 
								  ,[OccurrenceSpanCode18] 
								  ,[OccurrenceSpanFrom18] 
								  ,[OccurrenceSpanTo18] 
								  ,[OccurrenceSpanCode19] 
								  ,[OccurrenceSpanFrom19] 
								  ,[OccurrenceSpanTo19] 
								  ,[OccurrenceSpanCode20] 
								  ,[OccurrenceSpanFrom20] 
								  ,[OccurrenceSpanTo20] 
								  ,[OccurrenceSpanCode21] 
								  ,[OccurrenceSpanFrom21] 
								  ,[OccurrenceSpanTo21] 
								  ,[OccurrenceSpanCode22] 
								  ,[OccurrenceSpanFrom22] 
								  ,[OccurrenceSpanTo22] 
								  ,[OccurrenceSpanCode23] 
								  ,[OccurrenceSpanFrom23] 
								  ,[OccurrenceSpanTo23] 
								  ,[OccurrenceSpanCode24] 
								  ,[OccurrenceSpanFrom24] 
								  ,[OccurrenceSpanTo24] 
								,claim_id 
								,SOURCEDESC 
						from edps_data.dbo.HistoricalClaim HC 
						inner join OUTB_INST_HEADER PH 
-- TETDM-2058			ON RTRIM(HC.clm01 ) = RTRIM(PH.Claim_ID) 
						ON HC.clm01 = PH.Claim_ID
						inner join EDPS_Data.dbo.encounterclaimdim EC 
						ON PH.CLAIM_ID = RTRIM(EC.CLAIMNUM) 
						AND RTRIM(PH.SYSTEM_SOURCE) = RTRIM(EC.SOURCEDESC) 
					 
 
						-----Update Occurance Codes 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_11 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_11 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_11 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
-- TETDM-2058				ON RTRIM(HP.clm01 ) = RTRIM(H.Claim_ID) 
							ON HP.clm01 = H.Claim_ID
						 
						--OCC_SPAN_CD_12 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_12 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_12 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_12 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						--OCC_SPAN_CD_13 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_13 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_13 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_13 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						--OCC_SPAN_CD_14 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_14 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_14 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_14 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						--OCC_SPAN_CD_15 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_15 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_15 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_15 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
 
						--OCC_SPAN_CD_16 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_16 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_16 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_16 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
 
						--OCC_SPAN_CD_17 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_12 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_17 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_17 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058 
 
 
						--OCC_SPAN_CD_18 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_18 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_18 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_18 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058 
 
 
						--OCC_SPAN_CD_19 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_19 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_19 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_19 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058 
 
						--OCC_SPAN_CD_110 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_110 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_110 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_110 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058 
 
							--OCC_SPAN_CD_111 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_111 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_111 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_111 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058 
 
						--OCC_SPAN_CD_112 
						Update OUTB_INST_HEADER 
						set OCC_SPAN_CD_112 = HP.OccurrenceCode1 
							,OCC_SPAN_BEGIN_DT_112 = HP.OccurrenceDate1 
							--,OCC_SPAN_END_DT_112 =  
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058 
 
 
							--CONDITIONCODES 
 
							--CONDITION1 
						Update OUTB_INST_HEADER 
						set CONDITION1 = ConditionCode1 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						--CONDITION2 
						Update OUTB_INST_HEADER 
						set CONDITION2 = ConditionCode2 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						--CONDITION3 
						Update OUTB_INST_HEADER 
						set CONDITION3 = ConditionCode3 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
 
 
						--CONDITION4 
						Update OUTB_INST_HEADER 
						set CONDITION4 = ConditionCode4 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
 
							--CONDITION5 
						Update OUTB_INST_HEADER 
						set CONDITION5 = ConditionCode5 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						--CONDITION6 
						Update OUTB_INST_HEADER 
						set CONDITION6 = ConditionCode6 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						--CONDITION7 
						Update OUTB_INST_HEADER 
						set CONDITION7 = ConditionCode7 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
								--CONDITION8 
						Update OUTB_INST_HEADER 
						set CONDITION8 = ConditionCode8 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						--CONDITION9 
						Update OUTB_INST_HEADER 
						set CONDITION9 = ConditionCode9 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						--CONDITION10 
						Update OUTB_INST_HEADER 
						set CONDITION10 = ConditionCode10 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						--CONDITION11 
						Update OUTB_INST_HEADER 
						set CONDITION11 = ConditionCode11 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
						 
						--CONDITION112 
						Update OUTB_INST_HEADER 
						set CONDITION12 = ConditionCode12 
							FROM OUTB_INST_HEADER H   
							INNER JOIN ##HistoricalClaim_INST HP 
							ON HP.clm01  = H.Claim_ID	--TETDM-2058
 
 
 
 
	--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_INST_HEADER_RESEND 
	 
	 
							  
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM ##HistoricalClaim_INST) 
			 
	----HRP_CLAIM_FILE Update Run Controls 
				BEGIN TRANSACTION 
						UPDATE EXT_SYS_RUNLOG 
						SET END_DT = GETDATE() 
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()) 
							,TOTAL_RECORDS = @TOTAL_RECORDS 
							,ENTRYDT = GETDATE() 
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_ENCOUNTER_HISTORICAL_CLAIM_OCCCD' 
							AND END_DT IS NULL 
							IF @@ERROR <> 0 
										BEGIN  
												ROLLBACK  
										END 
						COMMIT 
 

