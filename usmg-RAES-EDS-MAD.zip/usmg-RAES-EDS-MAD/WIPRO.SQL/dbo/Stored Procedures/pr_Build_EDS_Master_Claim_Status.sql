﻿
CREATE procedure [dbo].[pr_Build_EDS_Master_Claim_Status]

AS
/***************************************************************************************************
** CREATE DATE: 05/2016
**
** AUTHOR: LOYAL RICKS - Loyal Ricks 
**
** DESCRIPTION: Procedure refreshes EDS_MASTER_CLAIM_STATUS table.
**

**
**
**
**
**
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------

*****************************************************************************************************/	

--TRUNCATE TABLE EDS_MASTER_CLAIM_STATUS 
--GO
DECLARE 
				@TOTAL_RECORDS INT,	
				@LAST_UPD_DATE DATETIME,
				@ENTRYDT DATETIME,
				@TOTAL_EDS_PEND INT,
				@TOTAL_EDS_NOSTATUS INT,
				@TOTAL_EDS_EXCLUSIONS INT,
				@TOTAL_277_A INT,
				@TOTAL_277_R INT,
				@TOTAL_999_A INT,
				@TOTAL_999_R INT,
				@TOTAL_MAO002_A INT,
				@TOTAL_MAO002_R INT,
				@TOTAL_MAO004 INT,
				@TOTAL_CLAIMS INT

				SET @LAST_UPD_DATE = GETDATE();
				SET @ENTRYDT = @LAST_UPD_DATE;

						INSERT INTO EXT_SYS_RUNLOG
						(PROC_NAME
						,STEP
						,START_DT
						,END_DT
						,RUN_MINUTES
						,TOTAL_RECORDS
						,ENTRYDT
						)
						VALUES('EDS Master Claim Status Build'
								,'Job Execution'
								,GETDATE()
								,NULL
								,NULL
								,0
								,GETDATE()
								)



									INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('EDS Master Claim Status Build - New Claim Inventory'
											,'1000'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE()
											)

												IF OBJECT_ID('TEMPDB..#tmplob') <> 0
														DROP TABLE #tmplob

													CREATE TABLE #tmplob
													(
														LOBCode			VARCHAR(15),
														HCFACODE		VARCHAR(5)
													)

													INSERT INTO 
															#tmplob
														( 
															LOBCode,
															HCFACODE
														)
														SELECT
															LOBCode,
															HCFACode
														FROM
															MDQOLib.dbo.LineofBusinessDim
														WHERE	
															ProductType IN ('Care-Caid','Medicare')
														AND Active = 1
														ORDER BY LOBCode
		
												--Identify new claims not currently in EDS_MASTER_CLAIM_STATUS
												IF OBJECT_ID('TEMPDB..#mclaimid') <> 0
													DROP TABLE #mclaimid

														CREATE TABLE #mclaimid
															(
															claimid varchar(20),
															claim_type char(1),
															lobcode varchar(15), 
															hplan varchar(5),
															sourcedatakey int,
															beginservicedatekey int,
															endservicedatekey int
															)
													insert into #mclaimid 
													select 
														c.claimid,
														case c.formtypecode when 'H' then 'P' when 'U' then 'I' else formtypecode end,
														c.lobcode,
														t.HCFACODE,
														c.sourcedatakey,
														c.BeginServiceDateKey,
														c.endservicedatekey

														from edps_data.dbo.claimdim c
														left outer join EDS_MASTER_CLAIM_STATUS EC
														ON C.SOURCEDATAKEY = EC.SOURCEDATAKEY 
														AND C.CLAIMID = EC.CLAIMID 
														INNER JOIN #tmplob t
														on c.lobcode = t.lobcode
													WHERE C.BeginServiceDateKey >= '20150101'
														AND C.SOURCEDATAKEY <> 40
													AND EC.CLAIMID IS NULL
													ORDER BY c.sourcedatakey,c.claimid

													---Reset EDS_MASTER_CLAIM_STATUS.EDS_STATUS TO NULL 
													---Status reset to allow for recent submission and exclusion updates

													UPDATE EDS_MASTER_CLAIM_STATUS
													SET EDS_STATUS = ' '
														,EDS_STATUS_DT = ' '

													---append new records to master claim status 
			

													insert into EDS_MASTER_CLAIM_STATUS
													SELECT 
															CLAIMID,
															SOURCEDATAKEY,
															@LAST_UPD_DATE,
															' ',--' ',--[EDS_STATUS] ' ',--[VARCHAR] (255),
															' ',--' ',--[EDS_STATUS_DT] DATETIME,
															' ',--' ',--[WIPRO_STATUS] ' ',--[VARCHAR] (10),
															' ',--' ',--[WIPRO_STATUS_DT] DATETIME,
															' ',--' ',--[WIPRO_999_STATUS] ' ',--[VARCHAR] (1),
															' ',--' ',--[WIPRO_999_STATUS_DT] DATETIME,
															' ',--' ',--[WIPRO_277_STATUS] ' ',--[VARCHAR] (1),
															' ',--' ',--[WIPRO_277_STATUS_DT] DATETIME,
															' ',--' ',--[WIPRO_MAO002_STATUS] ' ',--[VARCHAR] (1),
															' ',--' ',--[WIPRO_MAO002_STATUS_DT] DATETIME,
															' ',--' ',--[WIPRO_MAO004_STATUS] ' ',--[VARCHAR] (1),
															' ',--' ',--[WIPRO_MAO004_STATUS_DT] DATETIME,
															' ',--' ',--[MEMBERID] ' ',--[VARCHAR] (80),
															' ',--' ',--[HCIN] ' ',--[VARCHAR] (20),
															beginservicedatekey,--' ',--[BEGINSERVICEDATEKEY DATETIME
															claim_type,--' ',--[CLAIM_TYPE] ' ',--[varchar](1) NULL,
															HPLAN,--' ',--[HPLAN] ' ',--[varchar](5) NULL,
															lobcode,--' ',--[LOBCODE] ' ',--[varchar](15) NULL,
															' ',--' ',--[MedicareAdvContractID] ' ',--' ',--[char](5) NULL,
															' ',--[BeneficiaryHICN] ' ',--[varchar](12) NULL,
															' ',--[EncounterICN] ' ',--[varchar](44) NULL,
															' ',--[INST_PRINCIPAL_DIAG_CD] ' ',--[char](10) NULL,
															' ',--[INST_PRINCIPAL_POA_CD] ' ',--[char](15) NULL,
															' ',--[INST_ADM_DIAG_CD] ' ',--[char](10) NULL,
															' ',--[INST_VISIT_DIAG_CD1] ' ',--[char](10) NULL,
															' ',--[INST_VISIT_DIAG_CD2] ' ',--[char](10) NULL,
															' ',--[INST_VISIT_DIAG_CD3] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND1] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD1] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND2] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD2] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND3] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD3] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND4] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD4] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND5] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD5] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND6] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD6] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND7] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD7] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND8] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD8] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND9] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD9] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND10] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD10] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND11] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD11] ' ',--[char](10) NULL,
															' ',--[INST_EXT_INJ_POA_IND12] ' ',--[char](15) NULL,
															' ',--[INST_EXT_INJ_DIAG_CD12] ' ',--[char](10) NULL,
															' ',--[INST_DIAG_DRG_CD] ' ',--[char](10) NULL,
															' ',--[DIAG_CD1] ' ',--[char](10) NULL,
															' ',--[POA_IND1] ' ',--[char](15) NULL,
															' ',--[DIAG_CD2] ' ',--[char](10) NULL,
															' ',--[POA_IND2] ' ',--[char](15) NULL,
															' ',--[DIAG_CD3] ' ',--[char](10) NULL,
															' ',--[POA_IND3] ' ',--[char](15) NULL,
															' ',--[DIAG_CD4] ' ',--[char](10) NULL,
															' ',--[POA_IND4] ' ',--[char](15) NULL,
															' ',--[DIAG_CD5] ' ',--[char](10) NULL,
															' ',--[POA_IND5] ' ',--[char](15) NULL,
															' ',--[DIAG_CD6] ' ',--[char](10) NULL,
															' ',--[POA_IND6] ' ',--[char](15) NULL,
															' ',--[DIAG_CD7] ' ',--[char](10) NULL,
															' ',--[POA_IND7] ' ',--[char](15) NULL,
															' ',--[DIAG_CD8] ' ',--[char](10) NULL,
															' ',--[POA_IND8] ' ',--[char](15) NULL,
															' ',--[DIAG_CD9] ' ',--[char](10) NULL,
															' ',--[POA_IND9] ' ',--[char](15) NULL,
															' ',--[DIAG_CD10] ' ',--[char](10) NULL,
															' ',--[POA_IND10] ' ',--[char](15) NULL,
															' ',--[DIAG_CD11] ' ',--[char](10) NULL,
															' ',--[POA_IND11] ' ',--[char](15) NULL,
															' ',--[DIAG_CD12] ' ',--[char](10) NULL,
															' ',--[POA_IND12] ' ',--[char](15) NULL,
															' ',--[DIAG_CD13] ' ',--[char](10) NULL,
															' ',--[POA_IND13] ' ',--[char](15) NULL,
															' ',--[DIAG_CD14] ' ',--[char](10) NULL,
															' ',--[POA_IND14] ' ',--[char](15) NULL,
															' ',--[DIAG_CD15] ' ',--[char](10) NULL,
															' ',--[POA_IND15] ' ',--[char](15) NULL,
															' ',--[DIAG_CD16] ' ',--[char](10) NULL,
															' ',--[POA_IND16] ' ',--[char](15) NULL,
															' ',--[DIAG_CD17] ' ',--[char](10) NULL,
															' ',--[POA_IND17] ' ',--[char](15) NULL,
															' ',--[DIAG_CD18] ' ',--[char](10) NULL,
															' ',--[POA_IND18] ' ',--[char](15) NULL,
															' ',--[DIAG_CD19] ' ',--[char](10) NULL,
															' ',--[POA_IND19] ' ',--[char](15) NULL,
															' ',--[DIAG_CD20] ' ',--[char](10) NULL,
															' ',--[POA_IND20] ' ',--[char](15) NULL,
															' ',--[DIAG_CD21] ' ',--[char](10) NULL,
															' ',--[POA_IND21] ' ',--[char](15) NULL,
															' ',--[DIAG_CD22] ' ',--[char](10) NULL,
															' ',--[POA_IND22] ' ',--[char](15) NULL,
															' ',--[DIAG_CD23] ' ',--[char](10) NULL,
															' ',--[POA_IND23] ' ',--[char](15) NULL,
															' ',--[DIAG_CD24] ' ',--[char](10) NULL,
															' ',--[POA_IND24] ' ',--[char](15) NULL,
															' ',--[DIAG_CD25] ' ',--[char](10) NULL,
															' ',--[POA_IND25] ' ',--[char](15) NULL,
															' ',--[DIAG_CD26] ' ',--[char](10) NULL,
															' ',--[POA_IND26] ' ',--[char](15) NULL,
															' ',--[DIAG_CD27] ' ',--[char](10) NULL,
															' ',--[POA_IND27] ' ',--[char](15) NULL,
															' ',--[DIAG_CD28] ' ',--[char](10) NULL,
															' ',--[POA_IND28] ' ',--[char](15) NULL,
															' ',--[DIAG_CD29] ' ',--[char](10) NULL,
															' ',--[POA_IND29] ' ',--[char](15) NULL,
															' ',--[DIAG_CD30] ' ',--[char](10) NULL,
															' ',--[POA_IND30] ' ',--[char](15) NULL,
															endservicedatekey
													FROM #mclaimid

								SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #mclaimid)

								UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EDS Master Claim Status Build - New Claim Inventory'
													AND END_DT IS NULL

--##GET CURRENT STATUS FOR CLAIM IN ORDER TO UPDATE INVENTORY
				--STEP 1 GET MAX FILEID WHICH IDENTIFIES LATEST FILE CONTAINING OUTBOUND CLAIMS 

						
								INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('EDS Master Claim Status Build - WIPRO Status'
											,'2000'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE()
											)




														IF OBJECT_ID('TEMPDB..#WIPRO_CURR_STATUS') <> 0
															DROP TABLE #WIPRO_CURR_STATUS
								
														CREATE TABLE #WIPRO_CURR_STATUS(
															[CLAIM_ID] [varchar](20) NULL,
															[CLAIM_TYPE] [CHAR] (1) NULL,
															[WIPRO_CLAIM_ID] [VARCHAR] (20),
															[FILEID] [char](50) NULL,
															[SOURCEDATAKEY] [int] NULL,
															[CLMSTAT_STATUS] [VARCHAR] (50),
															[LAST_UPD_DATE] DATETIME,
															[MEMBER_ID] [VARCHAR] (80),
															[HICN_NUM] [VARCHAR] (20)
															)
				
							
														INSERT INTO #WIPRO_CURR_STATUS
														SELECT CLAIM_ID
																,CLAIM_TYPE
																,WIPRO_CLAIM_ID
																,max(FILEID)
																,SOURCEDATAKEY
																,ISNULL(CLMSTAT_STATUS,'P')
																,LAST_UPD_DATE
																,MEMBER_ID
																,HICN_NUM
														FROM OUTB_CLAIM_STATUS
														--WHERE ISNULL(CLMSTAT_STATUS,'P') IN ('A','R')
														group by SOURCEDATAKEY
																,ClAIM_ID
																,CLAIM_TYPE
																,WIPRO_CLAIM_ID
																,SOURCEDATAKEY
																,CLMSTAT_STATUS
																,LAST_UPD_DATE
																,MEMBER_ID
																,HICN_NUM

														UPDATE EDS_MASTER_CLAIM_STATUS
														SET CLAIM_TYPE = CS.CLAIM_TYPE,
															MEMBERID = CS.MEMBER_ID ,
															HICN = CS.HICN_NUM
														FROM EDS_MASTER_CLAIM_STATUS EM
														INNER JOIN #WIPRO_CURR_STATUS CS
														ON EM.SOURCEDATAKEY = CS.SOURCEDATAKEY
														AND EM.CLAIMID = CS.CLAIM_ID 
														WHERE CS.CLAIM_TYPE = 'E' 
														AND CS.CLAIM_TYPE <> 'E'

														Update EDS_MASTER_CLAIM_STATUS
														SET WIPRO_STATUS = CS.CLMSTAT_STATUS
															,WIPRO_STATUS_DT = CS.LAST_UPD_DATE
															,MEMBERID = CS.MEMBER_ID 
															,HICN = CS.HICN_NUM
														FROM EDS_MASTER_CLAIM_STATUS EM
														INNER JOIN #WIPRO_CURR_STATUS CS
														ON EM.SOURCEDATAKEY = CS.SOURCEDATAKEY
														AND EM.CLAIMID = CS.CLAIM_ID 
														WHERE CLMSTAT_STATUS in ('A','R')

														Update EDS_MASTER_CLAIM_STATUS
														SET EDS_STATUS = CS.CLMSTAT_STATUS
															,EDS_STATUS_DT = CS.LAST_UPD_DATE
															,MEMBERID = CS.MEMBER_ID 
															,HICN = CS.HICN_NUM
														FROM EDS_MASTER_CLAIM_STATUS EM
														INNER JOIN #WIPRO_CURR_STATUS CS
														ON EM.SOURCEDATAKEY = CS.SOURCEDATAKEY
														AND EM.CLAIMID = CS.CLAIM_ID 
														WHERE CLMSTAT_STATUS = 'P'

							SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #WIPRO_CURR_STATUS)

							UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EDS Master Claim Status Build - WIPRO Status'
													AND END_DT IS NULL


									---999 Accepted Claim 
																
					
							INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('EDS Master Claim Status Build - 999 Status'
											,'3000'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE()
											)


												IF OBJECT_ID('TEMPDB..#WIPRO_999') <> 0
													DROP TABLE #WIPRO_999
								
												CREATE TABLE #WIPRO_999(
													[INBOUNDFILENAME] [VARCHAR] (256),
													[FILECREATEDATE] [VARCHAR] (14),
													[CLAIM_ID] [varchar](20) NULL,
													[WIPRO_CLAIM_ID] [VARCHAR] (20),
													[CLMSTAT_STATUS] [CHAR] (1)
													)

												INSERT INTO #WIPRO_999
												select WF.InboundFileName
													,WF.CMSTransactionDate
													,W9.CLAIMID
													,W9.WIPRO_CLAIMID
													,W9.RECORDTYPE
	
												from WIPRO_999_ACCEPTED_DETAIL W9
												INNER JOIN WIPRO_999_FileStatus WF
												ON W9.InboundFileName = WF.InboundFileName
												INNER JOIN #WIPRO_CURR_STATUS WCS
												ON W9.CLAIMID = WCS.CLAIM_ID
												AND W9.WIPRO_CLAIMID = WCS.WIPRO_CLAIM_ID


							
												INSERT INTO #WIPRO_999
												select WF.InboundFileName
													,WF.CMSTransactionDate
													,W9.CLAIM_ID
													,W9.WIPRO_CLAIMID
													,W9.RECORDTYPE
	
												from WIPRO_999_REJECT_DETAIL W9
												INNER JOIN WIPRO_999_FileStatus WF
												ON W9.InboundFileName = WF.InboundFileName
												INNER JOIN #WIPRO_CURR_STATUS WCS
												ON W9.CLAIM_ID = WCS.CLAIM_ID
												AND W9.WIPRO_CLAIMID = WCS.WIPRO_CLAIM_ID

												--INSERT INTO #WIPRO_999
												--select WF.InboundFileName
												--	,WF.CMSTransactionDate
												--	,W9.CLAIMID
												--	,W9.WIPRO_CLAIMID
												--	,W9.RECORDTYPE
	
												--from WIPRO_999__REJECT_DETAIL W9
												--INNER JOIN WIPRO_999_FileStatus WF
												--ON W9.InboundFileName = WF.InboundFileName
												---TEST THIS BLOCK WITH PRODUCTION DATA
												--INNER JOIN #WIPRO_CURR_STATUS WCS
												--ON WR.PlanClaimNumber = WCS.CLAIM_ID
												--AND WR.WIPROID = WCS.WIPRO_CLAIM_ID

												UPDATE EDS_MASTER_CLAIM_STATUS
												SET WIPRO_999_STATUS = RTRIM(W2.CLMSTAT_STATUS)
													,WIPRO_999_STATUS_DT = W2.FILECREATEDATE
												FROM EDS_MASTER_CLAIM_STATUS C
												INNER JOIN #WIPRO_999 W2 
												ON C.CLAIMID = W2.CLAIM_ID 

							SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #WIPRO_999)

							UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EDS Master Claim Status Build - 999 Status'
													AND END_DT IS NULL
							---277 Accepted Claim 
							INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('EDS Master Claim Status Build - 277 Status'
											,'4000'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE()
											)
											IF OBJECT_ID('TEMPDB..#WIPRO_277') <> 0
												DROP TABLE #WIPRO_277
								
											CREATE TABLE #WIPRO_277(
												[INBOUNDFILENAME] [VARCHAR] (256),
												[FILECREATEDATE] [VARCHAR] (14),
												[CLAIM_ID] [varchar](20) NULL,
												[WIPRO_CLAIM_ID] [VARCHAR] (20),
												[CLMSTAT_STATUS] [CHAR] (1)
												)

											--INSERT INTO #WIPRO_277
											--select WH.InboundFileName
											--	,WH.FileCreateDate
											--	,WA.PlanClaimNumber
											--	,WA.WIPROID
											--	,WA.RECORDTYPE
	
											--from WIPRO_277_Accepted WA
											--INNER JOIN WIPRO_277_Header WH
											--ON WA.InboundFileName = WH.InboundFileName
										/*		---TEST THIS BLOCK WITH PRODUCTION DATA
											--INNER JOIN #WIPRO_CURR_STATUS WCS
											--ON WA.PlanClaimNumber = WCS.CLAIM_ID
											--AND WA.WIPROID = WCS.WIPRO_CLAIM_ID
											*/

											--INSERT INTO #WIPRO_277
											--select WH.InboundFileName
											--	,WH.FileCreateDate
											--	,WR.PlanClaimNumber
											--	,WR.WIPROID
											--	,WR.RECORDTYPE
											--from WIPRO_277_Rejected WR
											--INNER JOIN WIPRO_277_Header WH
											--ON WR.InboundFileName = WH.InboundFileName
											-----TEST THIS BLOCK WITH PRODUCTION DATA
											----INNER JOIN #WIPRO_CURR_STATUS WCS
											----ON WR.PlanClaimNumber = WCS.CLAIM_ID
											----AND WR.WIPROID = WCS.WIPRO_CLAIM_ID

											--UPDATE EDS_MASTER_CLAIM_STATUS
											--SET WIPRO_277_STATUS = RTRIM(W2.CLMSTAT_STATUS)
											--	,WIPRO_277_STATUS_DT = W2.FILECREATEDATE
											--FROM EDS_MASTER_CLAIM_STATUS C
											--INNER JOIN #WIPRO_277 W2 
											--ON C.CLAIMID = W2.CLAIM_ID 
							
							
							SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #WIPRO_277)

							UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EDS Master Claim Status Build - 277 Status'
													AND END_DT IS NULL
												--MAO002 Updates
												---MAO002 Accepted Claim 
												INSERT INTO EXT_SYS_RUNLOG
														(PROC_NAME
														,STEP
														,START_DT
														,END_DT
														,RUN_MINUTES
														,TOTAL_RECORDS
														,ENTRYDT
														)
														VALUES('EDS Master Claim Status Build - MAO002 Status'
																,'5000'
																,GETDATE()
																,NULL
																,NULL
																,0
																,GETDATE()
																)
												IF OBJECT_ID('TEMPDB..#WIPRO_MAO002') <> 0
													DROP TABLE #WIPRO_MAO002
								
												CREATE TABLE #WIPRO_MAO002(
													[INBOUNDFILENAME] [VARCHAR] (256),
													[FILECREATEDATE] [VARCHAR] (14),
													[CLAIM_ID] [varchar](20) NULL,
													[WIPRO_CLAIM_ID] [VARCHAR] (20),
													[CLMSTAT_STATUS] [CHAR] (1)
													)

												INSERT INTO #WIPRO_MAO002
												select WH.InboundFileName
													,WH.CMSTransactionDate
													,WA.PlanClaimNumber
													,WA.WIPRO_UNQ_ID
													,WA.RECORDTYPE
	
												from MAO_002_DETAIL WA
												INNER JOIN MAO_002_FILESTATUS WH
												ON WA.InboundFileName = WH.InboundFileName
													---TEST THIS BLOCK WITH PRODUCTION DATA
												--INNER JOIN #WIPRO_CURR_STATUS WCS
												--ON WA.PlanClaimNumber = WCS.CLAIM_ID
												--AND WA.WIPROID = WCS.WIPRO_CLAIM_ID

												UPDATE EDS_MASTER_CLAIM_STATUS
												SET WIPRO_MAO002_STATUS = RTRIM(W2.CLMSTAT_STATUS)
													,WIPRO_MAO002_STATUS_DT = W2.FILECREATEDATE
												FROM EDS_MASTER_CLAIM_STATUS C
												INNER JOIN #WIPRO_MAO002 W2 
												ON C.CLAIMID = W2.CLAIM_ID 

							SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #WIPRO_MAO002)

							UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EDS Master Claim Status Build - MAO002 Status'
													AND END_DT IS NULL
							
							--MAO004 Updates
							INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('EDS Master Claim Status Build - MAO004 Status'
											,'6000'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE()
											)
												IF OBJECT_ID('TEMPDB..#WIPRO_MAO004') <> 0
													DROP TABLE #WIPRO_MAO004
								
												CREATE TABLE #WIPRO_MAO004(
													[INBOUNDFILENAME] [VARCHAR] (256),
													[FILECREATEDATE] [VARCHAR] (14),
													[CLAIM_ID] [varchar](20) NULL,
													[WIPRO_CLAIM_ID] [VARCHAR] (20),
													[CLMSTAT_STATUS] [CHAR] (1),
													[MedicareAdvContractID] [char] (5),
													[BeneficiaryHICN] [CHAR] (12),
													[EncounterICN] [Char] (44),
													[SOURCEDATAKEY] INT ,
													)

												INSERT INTO #WIPRO_MAO004
												select WH.InboundFileName
													,WH.ReportDate
													,WA.ClaimID
													,WA.WIPRO_ClaimID
													,'A'
													,WA.MedicareAdvContractId
													,BeneficiaryHICN
													,EncounterICN
													,WCS.SOURCEDATAKEY
												from MAO_004_DETAIL WA
												INNER JOIN MAO_004_HEADER WH
												ON WA.InboundFileName = WH.InboundFileName
													---TEST THIS BLOCK WITH PRODUCTION DATA
												INNER JOIN #WIPRO_CURR_STATUS WCS
												ON WA.CLAIMID = WCS.CLAIM_ID
												AND WA.WIPRO_CLAIMID = WCS.WIPRO_CLAIM_ID


												UPDATE EDS_MASTER_CLAIM_STATUS
												SET WIPRO_MAO004_STATUS = RTRIM(W2.CLMSTAT_STATUS)
													,WIPRO_MAO004_STATUS_DT = W2.FILECREATEDATE
													,MedicareAdvContractId = W2.MedicareAdvContractId
													,BeneficiaryHICN = W2.BeneficiaryHICN
													,EncounterICN = W2.EncounterICN
												FROM EDS_MASTER_CLAIM_STATUS C
												INNER JOIN #WIPRO_MAO004 W2 
												ON C.SOURCEDATAKEY = W2.SOURCEDATAKEY
												AND C.CLAIMID = W2.CLAIM_ID 


							SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #WIPRO_MAO004)

							UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EDS Master Claim Status Build - MAO004 Status'
													AND END_DT IS NULL
							---exclusion status
										---Clear all EDS_STATUS info
											UPDATE EDS_MASTER_CLAIM_STATUS
														SET EDS_STATUS = ' '
														,EDS_STATUS_DT = ' ' 
																						
								--EXECUTE pr_Build_EDS_Master_Claim_Status_Exclusions @ENTRYDT

							--INSERT INTO EXT_SYS_RUNLOG
							--		(PROC_NAME
							--		,STEP
							--		,START_DT
							--		,END_DT
							--		,RUN_MINUTES
							--		,TOTAL_RECORDS
							--		,ENTRYDT
							--		)
							--		VALUES('EDS Master Claim Status Build - Exclusion Status'
							--				,'6000'
							--				,GETDATE()
							--				,NULL
							--				,NULL
							--				,0
							--				,GETDATE()
							--				)
							--					IF OBJECT_ID('TEMPDB..#DP_EXCL') <> 0
							--						DROP TABLE #DP_EXCL

							--					CREATE TABLE #DP_EXCL
							--					(
							--					EXCL_ID INT
							--					)

							--					INSERT INTO #DP_EXCL		
							--					select CONVERT(INT, substring(cntrl_txt,6,4))
							--					from EXT_SYS_CLM_JOBCNTRL
							--					where sourcedatakey = 999999999

							--					---Add Verisk Submissions to #DP_EXCL
												
							--					insert into #DP_EXCL
							--					VALUES(999999999)

							--					IF OBJECT_ID('TEMPDB..#EXCL_ID') <> 0
							--						DROP TABLE #EXCL_ID

							--					CREATE TABLE #EXCL_ID
							--					(
							--					EXCL_ID INT
							--					)

							--					INSERT INTO #EXCL_ID
							--					SELECT EXCL_ID 
							--					FROM ClaimExclusionCode
							--					WHERE EXCL_ID <> 999999999

							--					DELETE FROM #EXCL_ID
							--					WHERE EXCL_ID IN (SELECT EXCL_ID FROM #DP_EXCL)

						
							--					IF OBJECT_ID('TEMPDB..#tmp_excl') <> 0
							--						DROP TABLE #tmp_excl

							--					CREATE TABLE #tmp_excl
							--					(
							--							sourcedatakey int,
							--							claim_id varchar(20),
							--							excl_id INT,
							--							SEQ INT
							--					)

							--					insert into #tmp_excl
							--					select sourcedatakey,
							--							claim_id,
							--							H.excl_id,
							--							row_number() over (partition by sourcedatakey,claim_id order by sourcedatakey,claim_id) as seq
							--					from ext_claim_exclusion_hist H
							--					INNER JOIN #EXCL_ID E
							--					ON H.EXCL_ID = E.EXCL_ID 
							--					group by sourcedatakey,
							--							claim_id,
							--							h.excl_id
												

							--					-----Add revised logic that formats all exclusions into the status field
							--					UPDATE EDS_MASTER_CLAIM_STATUS
							--					SET EDS_STATUS = CONVERT(CHAR, EXCL_ID)
							--						,EDS_STATUS_DT = GETDATE()
							--					FROM EDS_MASTER_CLAIM_STATUS C
							--					INNER JOIN #tmp_excl W2 
							--					ON C.SOURCEDATAKEY = W2.SOURCEDATAKEY
							--					AND  C.CLAIMID = W2.CLAIM_ID 


									
							--SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #EXCL_ID)

							--			UPDATE EXT_SYS_RUNLOG
							--			SET END_DT = GETDATE()	
							--				,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							--				,TOTAL_RECORDS = @TOTAL_RECORDS
							--				,ENTRYDT = @ENTRYDT
							--			WHERE PROC_NAME = 'EDS Master Claim Status Build - Exclusion Status'
							--						AND END_DT IS NULL


							---get outbound claim header diagnosis codes on submission
							INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('EDS Master Claim Status Build - Retrieve Submission Info'
											,'6000'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE()
											)

											---Get EDS Submission Information
											IF OBJECT_ID('TEMPDB..#WIPRO_SUBMISSION') <> 0
												DROP TABLE #WIPRO_SUBMISSION
											CREATE TABLE #WIPRO_SUBMISSION
											(
												[CLAIMID] [varchar](20) NULL,
												[SOURCEDATAKEY] [int] NULL,
												[MEMBERID] [varchar](80) NULL,
												[HICN] [varchar](20) NULL,
												[CLAIM_TYPE] [varchar](1) NULL,
												[HPLAN] [varchar](5) NULL,
												[INST_PRINCIPAL_DIAG_CD] [char](10) NULL,
												[INST_PRINCIPAL_POA_CD] [char](15) NULL,
												[INST_ADM_DIAG_CD] [char](10) NULL,
												[INST_VISIT_DIAG_CD1] [char](10) NULL,
												[INST_VISIT_DIAG_CD2] [char](10) NULL,
												[INST_VISIT_DIAG_CD3] [char](10) NULL,
												[INST_EXT_INJ_POA_IND1] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD1] [char](10) NULL,
												[INST_EXT_INJ_POA_IND2] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD2] [char](10) NULL,
												[INST_EXT_INJ_POA_IND3] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD3] [char](10) NULL,
												[INST_EXT_INJ_POA_IND4] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD4] [char](10) NULL,
												[INST_EXT_INJ_POA_IND5] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD5] [char](10) NULL,
												[INST_EXT_INJ_POA_IND6] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD6] [char](10) NULL,
												[INST_EXT_INJ_POA_IND7] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD7] [char](10) NULL,
												[INST_EXT_INJ_POA_IND8] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD8] [char](10) NULL,
												[INST_EXT_INJ_POA_IND9] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD9] [char](10) NULL,
												[INST_EXT_INJ_POA_IND10] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD10] [char](10) NULL,
												[INST_EXT_INJ_POA_IND11] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD11] [char](10) NULL,
												[INST_EXT_INJ_POA_IND12] [char](15) NULL,
												[INST_EXT_INJ_DIAG_CD12] [char](10) NULL,
												[INST_DIAG_DRG_CD] [char](10) NULL,
												[DIAG_CD1] [char](10) NULL,
												[POA_IND1] [char](15) NULL,
												[DIAG_CD2] [char](10) NULL,
												[POA_IND2] [char](15) NULL,
												[DIAG_CD3] [char](10) NULL,
												[POA_IND3] [char](15) NULL,
												[DIAG_CD4] [char](10) NULL,
												[POA_IND4] [char](15) NULL,
												[DIAG_CD5] [char](10) NULL,
												[POA_IND5] [char](15) NULL,
												[DIAG_CD6] [char](10) NULL,
												[POA_IND6] [char](15) NULL,
												[DIAG_CD7] [char](10) NULL,
												[POA_IND7] [char](15) NULL,
												[DIAG_CD8] [char](10) NULL,
												[POA_IND8] [char](15) NULL,
												[DIAG_CD9] [char](10) NULL,
												[POA_IND9] [char](15) NULL,
												[DIAG_CD10] [char](10) NULL,
												[POA_IND10] [char](15) NULL,
												[DIAG_CD11] [char](10) NULL,
												[POA_IND11] [char](15) NULL,
												[DIAG_CD12] [char](10) NULL,
												[POA_IND12] [char](15) NULL,
												[DIAG_CD13] [char](10) NULL,
												[POA_IND13] [char](15) NULL,
												[DIAG_CD14] [char](10) NULL,
												[POA_IND14] [char](15) NULL,
												[DIAG_CD15] [char](10) NULL,
												[POA_IND15] [char](15) NULL,
												[DIAG_CD16] [char](10) NULL,
												[POA_IND16] [char](15) NULL,
												[DIAG_CD17] [char](10) NULL,
												[POA_IND17] [char](15) NULL,
												[DIAG_CD18] [char](10) NULL,
												[POA_IND18] [char](15) NULL,
												[DIAG_CD19] [char](10) NULL,
												[POA_IND19] [char](15) NULL,
												[DIAG_CD20] [char](10) NULL,
												[POA_IND20] [char](15) NULL,
												[DIAG_CD21] [char](10) NULL,
												[POA_IND21] [char](15) NULL,
												[DIAG_CD22] [char](10) NULL,
												[POA_IND22] [char](15) NULL,
												[DIAG_CD23] [char](10) NULL,
												[POA_IND23] [char](15) NULL,
												[DIAG_CD24] [char](10) NULL,
												[POA_IND24] [char](15) NULL,
												[DIAG_CD25] [char](10) NULL,
												[POA_IND25] [char](15) NULL,
												[DIAG_CD26] [char](10) NULL,
												[POA_IND26] [char](15) NULL,
												[DIAG_CD27] [char](10) NULL,
												[POA_IND27] [char](15) NULL,
												[DIAG_CD28] [char](10) NULL,
												[POA_IND28] [char](15) NULL,
												[DIAG_CD29] [char](10) NULL,
												[POA_IND29] [char](15) NULL,
												[DIAG_CD30] [char](10) NULL,
												[POA_IND30] [char](15) NULL
)
												--Append Professional Claim Submission History
												INSERT INTO #WIPRO_SUBMISSION
													SELECT OP.[CLAIM_ID]
											  ,OP.[SOURCEDATAKEY]
											  ,OP.[MEMBER_ID]
											  ,OP.[HICN_NUM]
	 
											  ,OP.[CLAIM_TYPE]
											   ,OP.[CMS_CONTRACT_NUM]
											  ,OP.[INST_PRINCIPAL_DIAG_CD]
											  ,' '--OP.[INST_PRINCIPAL_POA_CD]
											  ,OP.[INST_ADM_DIAG_CD]
											  ,' '--OP.[INST_VISIT_DIAG_CD1]
											  ,' '--OP.[INST_VISIT_DIAG_CD2]
											  ,' '--OP.[INST_VISIT_DIAG_CD3]
											  ,' '--OP.[INST_EXT_INJ_POA_IND1]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD1]
											  ,' '--OP.[INST_EXT_INJ_POA_IND2]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD2]
											  ,' '--OP.[INST_EXT_INJ_POA_IND3]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD3]
											  ,' '--OP.[INST_EXT_INJ_POA_IND4]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD4]
											  ,' '--OP.[INST_EXT_INJ_POA_IND5]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD5]
											  ,' '--OP.[INST_EXT_INJ_POA_IND6]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD6]
											  ,' '--OP.[INST_EXT_INJ_POA_IND7]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD7]
											  ,' '--OP.[INST_EXT_INJ_POA_IND8]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD8]
											  ,' '--OP.[INST_EXT_INJ_POA_IND9]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD9]
											  ,' '--OP.[INST_EXT_INJ_POA_IND10]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD10]
											  ,' '--OP.[INST_EXT_INJ_POA_IND11]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD11]
											  ,' '--OP.[INST_EXT_INJ_POA_IND12]
											  ,' '--OP.[INST_EXT_INJ_DIAG_CD12]
											  ,' '--OP.[INST_DIAG_DRG_CD]
											  ,OP.[DIAG_CD1]
											  ,' '--OP.[POA_IND1]
											  ,OP.[DIAG_CD2]
											  ,' '--OP.[POA_IND2]
											  ,OP.[DIAG_CD3]
											  ,' '--OP.[POA_IND3]
											  ,OP.[DIAG_CD4]
											  ,' '--OP.[POA_IND4]
											  ,OP.[DIAG_CD5]
											  ,' '--OP.[POA_IND5]
											  ,OP.[DIAG_CD6]
											  ,' '--OP.[POA_IND6]
											  ,OP.[DIAG_CD7]
											  ,' '--OP.[POA_IND7]
											  ,OP.[DIAG_CD8]
											  ,' '--OP.[POA_IND8]
											  ,OP.[DIAG_CD9]
											  ,' '--OP.[POA_IND9]
											  ,OP.[DIAG_CD10]
											  ,' '--OP.[POA_IND10]
											  ,OP.[DIAG_CD11]
											  ,' '--OP.[POA_IND11]
											  ,OP.[DIAG_CD12]
											  ,' '--OP.[POA_IND12]
											  ,OP.[DIAG_CD13]
											  ,' '--OP.[POA_IND13]
											  ,OP.[DIAG_CD14]
											  ,' '--OP.[POA_IND14]
											  ,OP.[DIAG_CD15]
											  ,' '--OP.[POA_IND15]
											  ,OP.[DIAG_CD16]
											  ,' '--OP.[POA_IND16]
											  ,OP.[DIAG_CD17]
											  ,' '--OP.[POA_IND17]
											  ,OP.[DIAG_CD18]
											  ,' '--OP.[POA_IND18]
											  ,OP.[DIAG_CD19]
											  ,' '--OP.[POA_IND19]
											  ,OP.[DIAG_CD20]
											  ,' '--OP.[POA_IND20]
											  ,OP.[DIAG_CD21]
											  ,' '--OP.[POA_IND21]
											  ,OP.[DIAG_CD22]
											  ,' '--OP.[POA_IND22]
											  ,OP.[DIAG_CD23]
											  ,' '--OP.[POA_IND23]
											  ,OP.[DIAG_CD24]
											  ,' '--OP.[POA_IND24]
											  ,OP.[DIAG_CD25]
											  ,' '--OP.[POA_IND25]
											  ,OP.[DIAG_CD26]
											  ,' '--OP.[POA_IND26]
											  ,OP.[DIAG_CD27]
											  ,' '--OP.[POA_IND27]
											  ,OP.[DIAG_CD28]
											  ,' '--OP.[POA_IND28]
											  ,OP.[DIAG_CD29]
											  ,' '--OP.[POA_IND29]
											  ,OP.[DIAG_CD30]
											  ,' '--OP.[POA_IND30]
										  FROM [dbo].[OUTB_PROF_HEADER_HIST] OP
											INNER JOIN #WIPRO_CURR_STATUS CS
																	ON OP.SOURCEDATAKEY = CS.SOURCEDATAKEY 
																	AND OP.CLAIM_ID = CS.CLAIM_ID 
																	AND OP.ExtractFileID = CS.FILEID 
																	--select top 10 * from #WIPRO_CURR_STATUS
										--Append Institutional Claim Submission History
																INSERT INTO #WIPRO_SUBMISSION
																	SELECT  OP.[CLAIM_ID]
											  ,OP.[SOURCEDATAKEY]
											  ,OP.[MEMBER_ID]
											  ,OP.[HICN_NUM]
	 
											  ,OP.[CLAIM_TYPE]
											   ,OP.[CMS_CONTRACT_NUM]
											  ,[INST_PRINCIPAL_DIAG_CD]
											  ,[INST_PRINCIPAL_POA_CD]
											  ,[INST_ADM_DIAG_CD]
											  ,[INST_VISIT_DIAG_CD1]
											  ,[INST_VISIT_DIAG_CD2]
											  ,[INST_VISIT_DIAG_CD3]
											  ,[INST_EXT_INJ_POA_IND1]
											  ,[INST_EXT_INJ_DIAG_CD1]
											  ,[INST_EXT_INJ_POA_IND2]
											  ,[INST_EXT_INJ_DIAG_CD2]
											  ,[INST_EXT_INJ_POA_IND3]
											  ,[INST_EXT_INJ_DIAG_CD3]
											  ,[INST_EXT_INJ_POA_IND4]
											  ,[INST_EXT_INJ_DIAG_CD4]
											  ,[INST_EXT_INJ_POA_IND5]
											  ,[INST_EXT_INJ_DIAG_CD5]
											  ,[INST_EXT_INJ_POA_IND6]
											  ,[INST_EXT_INJ_DIAG_CD6]
											  ,[INST_EXT_INJ_POA_IND7]
											  ,[INST_EXT_INJ_DIAG_CD7]
											  ,[INST_EXT_INJ_POA_IND8]
											  ,[INST_EXT_INJ_DIAG_CD8]
											  ,[INST_EXT_INJ_POA_IND9]
											  ,[INST_EXT_INJ_DIAG_CD9]
											  ,[INST_EXT_INJ_POA_IND10]
											  ,[INST_EXT_INJ_DIAG_CD10]
											  ,[INST_EXT_INJ_POA_IND11]
											  ,[INST_EXT_INJ_DIAG_CD11]
											  ,[INST_EXT_INJ_POA_IND12]
											  ,[INST_EXT_INJ_DIAG_CD12]
											  ,[INST_DIAG_DRG_CD]
											  ,[DIAG_CD1]
											  ,[POA_IND1]
											  ,[DIAG_CD2]
											  ,[POA_IND2]
											  ,[DIAG_CD3]
											  ,[POA_IND3]
											  ,[DIAG_CD4]
											  ,[POA_IND4]
											  ,[DIAG_CD5]
											  ,[POA_IND5]
											  ,[DIAG_CD6]
											  ,[POA_IND6]
											  ,[DIAG_CD7]
											  ,[POA_IND7]
											  ,[DIAG_CD8]
											  ,[POA_IND8]
											  ,[DIAG_CD9]
											  ,[POA_IND9]
											  ,[DIAG_CD10]
											  ,[POA_IND10]
											  ,[DIAG_CD11]
											  ,[POA_IND11]
											  ,[DIAG_CD12]
											  ,[POA_IND12]
											  ,[DIAG_CD13]
											  ,[POA_IND13]
											  ,[DIAG_CD14]
											  ,[POA_IND14]
											  ,[DIAG_CD15]
											  ,[POA_IND15]
											  ,[DIAG_CD16]
											  ,[POA_IND16]
											  ,[DIAG_CD17]
											  ,[POA_IND17]
											  ,[DIAG_CD18]
											  ,[POA_IND18]
											  ,[DIAG_CD19]
											  ,[POA_IND19]
											  ,[DIAG_CD20]
											  ,[POA_IND20]
											  ,[DIAG_CD21]
											  ,[POA_IND21]
											  ,[DIAG_CD22]
											  ,[POA_IND22]
											  ,[DIAG_CD23]
											  ,[POA_IND23]
											  ,[DIAG_CD24]
											  ,[POA_IND24]
											  ,[DIAG_CD25]
											  ,[POA_IND25]
											  ,[DIAG_CD26]
											  ,[POA_IND26]
											  ,[DIAG_CD27]
											  ,[POA_IND27]
											  ,[DIAG_CD28]
											  ,[POA_IND28]
											  ,[DIAG_CD29]
											  ,[POA_IND29]
											  ,[DIAG_CD30]
											  ,[POA_IND30]
										  FROM [dbo].[OUTB_inst_HEADER_HIST] OP
											INNER JOIN #WIPRO_CURR_STATUS CS
																	ON OP.SOURCEDATAKEY = CS.SOURCEDATAKEY 
																	AND OP.CLAIM_ID = CS.CLAIM_ID 
																	AND OP.ExtractFileID = CS.FILEID 




										UPDATE EDS_MASTER_CLAIM_STATUS 
										SET MEMBERID = CS.MEMBERID
											,HICN = CS.HICN
											,CLAIM_TYPE = CS.CLAIM_TYPE
												,INST_PRINCIPAL_DIAG_CD= CS.INST_PRINCIPAL_DIAG_CD
												,INST_PRINCIPAL_POA_CD = CS.INST_PRINCIPAL_POA_CD
												,INST_ADM_DIAG_CD = CS.INST_ADM_DIAG_CD
												,INST_VISIT_DIAG_CD1 = CS.INST_VISIT_DIAG_CD1
												,INST_VISIT_DIAG_CD2 = CS.INST_VISIT_DIAG_CD2
												,INST_VISIT_DIAG_CD3 = CS.INST_VISIT_DIAG_CD3
												,INST_EXT_INJ_POA_IND1 = CS.INST_EXT_INJ_POA_IND1
												,INST_EXT_INJ_DIAG_CD1 = CS.INST_EXT_INJ_DIAG_CD1
												,INST_EXT_INJ_POA_IND2 = CS.INST_EXT_INJ_POA_IND2
												,INST_EXT_INJ_DIAG_CD2 = CS.INST_EXT_INJ_DIAG_CD2
												,INST_EXT_INJ_POA_IND3 = CS.INST_EXT_INJ_POA_IND3
												,INST_EXT_INJ_DIAG_CD3 = CS.INST_EXT_INJ_DIAG_CD3
												,INST_EXT_INJ_POA_IND4 = CS.INST_EXT_INJ_POA_IND4
												,INST_EXT_INJ_DIAG_CD4 = CS.INST_EXT_INJ_DIAG_CD4
												,INST_EXT_INJ_POA_IND5 = CS.INST_EXT_INJ_POA_IND5
												,INST_EXT_INJ_DIAG_CD5 = CS.INST_EXT_INJ_DIAG_CD5
												,INST_EXT_INJ_POA_IND6 = CS.INST_EXT_INJ_POA_IND6
												,INST_EXT_INJ_DIAG_CD6 = CS.INST_EXT_INJ_DIAG_CD6
												,INST_EXT_INJ_POA_IND7 = CS.INST_EXT_INJ_POA_IND7
												,INST_EXT_INJ_DIAG_CD7 = CS.INST_EXT_INJ_DIAG_CD7
												,INST_EXT_INJ_POA_IND8 = CS.INST_EXT_INJ_POA_IND8
												,INST_EXT_INJ_DIAG_CD8 = CS.INST_EXT_INJ_DIAG_CD8
												,INST_EXT_INJ_POA_IND9 = CS.INST_EXT_INJ_POA_IND9
												,INST_EXT_INJ_DIAG_CD9 = CS.INST_EXT_INJ_DIAG_CD9
												,INST_EXT_INJ_POA_IND10 = CS.INST_EXT_INJ_POA_IND10
												,INST_EXT_INJ_DIAG_CD10 = CS.INST_EXT_INJ_DIAG_CD10
												,INST_EXT_INJ_POA_IND11 = CS.INST_EXT_INJ_POA_IND11
												,INST_EXT_INJ_DIAG_CD11 = CS.INST_EXT_INJ_DIAG_CD11
												,INST_EXT_INJ_POA_IND12 = CS.INST_EXT_INJ_POA_IND12
												,INST_EXT_INJ_DIAG_CD12 = CS.INST_EXT_INJ_DIAG_CD12
												,INST_DIAG_DRG_CD = CS.INST_DIAG_DRG_CD
												,DIAG_CD1 = CS.DIAG_CD1
												,POA_IND1 = CS.POA_IND1
												,DIAG_CD2 = CS.DIAG_CD2
												,POA_IND2 = CS.POA_IND2
												,DIAG_CD3 = CS.DIAG_CD3
												,POA_IND3 = CS.POA_IND3
												,DIAG_CD4 = CS.DIAG_CD4
												,POA_IND4 = CS.POA_IND4
												,DIAG_CD5 = CS.DIAG_CD5
												,POA_IND5 = CS.POA_IND5
												,DIAG_CD6 = CS.DIAG_CD6
												,POA_IND6 = CS.POA_IND6
												,DIAG_CD7 = CS.DIAG_CD7
												,POA_IND7 = CS.POA_IND7
												,DIAG_CD8 = CS.DIAG_CD8
												,POA_IND8 = CS.POA_IND8
												,DIAG_CD9 = CS.DIAG_CD9
												,POA_IND9 = CS.POA_IND9
												,DIAG_CD10 = CS.DIAG_CD10
												,POA_IND10 = CS.POA_IND10
												,DIAG_CD11 = CS.DIAG_CD11
												,POA_IND11 = CS.POA_IND11
												,DIAG_CD12 = CS.DIAG_CD12
												,POA_IND12 = CS.POA_IND12
												,DIAG_CD13 = CS.DIAG_CD13
												,POA_IND13 = CS.POA_IND13
												,DIAG_CD14 = CS.DIAG_CD14
												,POA_IND14 = CS.POA_IND14
												,DIAG_CD15 = CS.DIAG_CD15
												,POA_IND15 = CS.POA_IND15
												,DIAG_CD16 = CS.DIAG_CD16
												,POA_IND16 = CS.POA_IND16
												,DIAG_CD17 = CS.DIAG_CD17
												,POA_IND17 = CS.POA_IND17
												,DIAG_CD18 = CS.DIAG_CD18
												,POA_IND18 = CS.POA_IND18
												,DIAG_CD19 = CS.DIAG_CD19
												,POA_IND19 = CS.POA_IND19
												,DIAG_CD20 = CS.DIAG_CD20
												,POA_IND20 = CS.POA_IND20
												,DIAG_CD21 = CS.DIAG_CD21
												,POA_IND21 = CS.POA_IND21
												,DIAG_CD22 = CS.DIAG_CD22
												,POA_IND22 = CS.POA_IND22
												,DIAG_CD23 = CS.DIAG_CD23
												,POA_IND23 = CS.POA_IND23
												,DIAG_CD24 = CS.DIAG_CD24
												,POA_IND24 = CS.POA_IND24
												,DIAG_CD25 = CS.DIAG_CD25
												,POA_IND25 = CS.POA_IND25
												,DIAG_CD26 = CS.DIAG_CD26
												,POA_IND26 = CS.POA_IND26
												,DIAG_CD27 = CS.DIAG_CD27
												,POA_IND27 = CS.POA_IND27
												,DIAG_CD28 = CS.DIAG_CD28
												,POA_IND28 = CS.POA_IND28
												,DIAG_CD29 = CS.DIAG_CD29
												,POA_IND29 = CS.POA_IND29
												,DIAG_CD30 = CS.DIAG_CD30
												,POA_IND30 = CS.POA_IND30
										FROM EDS_MASTER_CLAIM_STATUS EM
										INNER JOIN #WIPRO_SUBMISSION CS
										ON EM.SOURCEDATAKEY = CS.SOURCEDATAKEY 
										AND EM.CLAIMID = CS.CLAIMID

								SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #WIPRO_SUBMISSION)

										UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EDS Master Claim Status Build - Retrieve Submission Info'
													AND END_DT IS NULL





							---Archive Newly Generate Table 

							INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('EDS Master Claim Status Build - Archiving'
											,'20000'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE()
											)

												INSERT INTO EDS_MASTER_CLAIM_STATUS_Archive
												select *,Getdate()
												from EDS_MASTER_CLAIM_STATUS

							
							SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EDS_MASTER_CLAIM_STATUS)

							UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EDS Master Claim Status Build - Archiving'
													AND END_DT IS NULL

												-------------------Audits------------------------------
												set @TOTAL_EDS_PEND = (select count(*) from #WIPRO_CURR_STATUS where clmstat_status = 'P');
												set @TOTAL_EDS_NOSTATUS = (select count(*) from #WIPRO_CURR_STATUS where clmstat_status = ' ');
												set @TOTAL_EDS_EXCLUSIONS = (SELECT COUNT(*) FROM EDS_MASTER_CLAIM_STATUS
																					WHERE EDS_STATUS NOT IN ('P','A','R',' '));
												set @TOTAL_277_A = (select count(*) from #WIPRO_277 where clmstat_status = 'A');
												set @TOTAL_277_R = (select count(*) from #WIPRO_277 where clmstat_status = 'R');
												set @TOTAL_999_A = (select count(*) from #WIPRO_999 where clmstat_status = 'A');
												set @TOTAL_999_R = (select count(*) from #WIPRO_999 where clmstat_status = 'R');
												set @TOTAL_MAO002_A = (select count(*) from #WIPRO_MAO002 where clmstat_status = 'A');
												set @TOTAL_MAO002_R = (select count(*) from #WIPRO_MAO002 where clmstat_status = 'R');
												set @TOTAL_MAO004 = (select count(*) from #WIPRO_MAO004);
												set @TOTAL_CLAIMS = (select count(*) from EDS_MASTER_CLAIM_STATUS);
				
												---Append Audit 
												insert into EDS_MASTER_CLAIM_STATUS_Audit
												values(getdate(), @TOTAL_CLAIMS,@TOTAL_EDS_PEND,@TOTAL_EDS_NOSTATUS,@TOTAL_EDS_EXCLUSIONS,
															@TOTAL_999_A,@TOTAL_999_R,@TOTAL_277_A,@TOTAL_277_R,@TOTAL_MAO002_A,@TOTAL_MAO002_R,
															@TOTAL_MAO004)
										

									UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = 0--@TOTAL_RECORDS
											,ENTRYDT = GETDATE()--@ENTRYDT
										WHERE PROC_NAME = 'EDS Master Claim Status Build'
													AND END_DT IS NULL



