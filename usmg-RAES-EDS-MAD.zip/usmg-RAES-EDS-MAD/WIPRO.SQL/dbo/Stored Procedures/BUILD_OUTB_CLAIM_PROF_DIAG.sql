﻿
--
						

CREATE PROCEDURE [dbo].[BUILD_OUTB_CLAIM_PROF_DIAG]
AS
/***************************************************************************************************
** CREATE DATE: 06/2012
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM HEADER 
**              AND LINE LEVE DIAGNOSIS CODE INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
2012-10-19		Dwight Staggs	Remove database name from table references
2013-03-22		Loyal Ricks		Revised Diag. 1-9 update to include appropriate logic for sequence
								number in join. Facets uses 1 char '1', all others using '01' for 
								claim header updates (OUTB_PROF_HEADER)
2013-04-26		Loyal Ricks		Revised Diag. 1-9 update to include appropriate logic for sequence
								number in join. Facets uses 1 char '1', all others using '01' for 
								claim detail updates (OUTB_PROF_DETAIL)
2013-05-16		Loyal Ricks		Added Facets OUTB_PROF_DETAIL Update Logic (line level diagnosis
								& pointer info)
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation																							    
*****************************************************************************************************/		
--UPDATE DIAGNOSIS POINTERS
		--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM OUTB_PROF_HEADER_RESEND
			DECLARE
			
			@TOTAL_HEADER_RECORDS INT,
			@TOTAL_DETAIL_RECORDS INT,
			@TOTAL_RECORDS INT
--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_CLAIM_PROF_DIAG'
				,'4'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
--UPDATE DIAGNOSIS CODES
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD1 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND1 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE in ('01','1')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commiT
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD2 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND2 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE in ( '02','2')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD3 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND3 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE in ('3', '03')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD4 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND4 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE in ('4', '04')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD5 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND5 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE in ('5', '05')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD6 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND6 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE in ('6', '06')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD7 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND7 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE in ('7', '07')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD8 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND8 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE in ('8', '08')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD9 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND9 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE in ('9', '09')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD10 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND10 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '10'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD11 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND11 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '11'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD12 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND12 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '12'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD13 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND13 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '13'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD14 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND14 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '14'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD15 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND15 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '15'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD16 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND16 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '16'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD17 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND17 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '17'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD18 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND18 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '18'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD19 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND19 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '19'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET DIAG_CD20 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND20 = case CDG.POAind when 'Y' then 'Y' else 'N' end
			FROM OUTB_PROF_HEADER E
				,EDPS_Data.dbo.claimdiagnosisdim CDG
			WHERE E.CLAIM_ID = CDG.CLAIMID 
				AND CDG.SEQUENCE = '20'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		
		----HRP LINE LEVEL DIAGNOSIS CODE UPDATES
		----OUTB_PROF_DETAIL UPDATES
		--update diagnosis codes
		--PRIM_DIAG_CD
	begin transaction 
			update OUTB_PROF_DETAIL
			set PRIM_DIAG_CD = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ('01','1')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
--UPDATE DIAG_CD2
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD2 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ( '02','2')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit		
--UPDATE DIAG_CD3
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD3 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ( '03','3')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD4
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD4 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ( '04','4')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD5
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD5 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ( '05','5')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD6
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD6 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ( '06','6')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD7
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD7 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ( '07','7')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD8
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD8 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ( '08','8')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD9
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD9 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ( '09','9')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD10
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD10 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ( '0010','10')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD11
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD11 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '11'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD12
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD12 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '12'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD13
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD13 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '13'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD14
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD14 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '14'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD15
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD15 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '15'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD16
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD16 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '16'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD17
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD17 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '17'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD18
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD18 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '18'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD19
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD19 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '19'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD20
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD20 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '20'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD21
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD21 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '21'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD22
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD22 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '22'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD23
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD23 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '23'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD24
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD24 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '24'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD25
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD25 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '25'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit			
			--UPDATE DIAG_CD26
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD26 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '26'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD27
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD27 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '27'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD28
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD28 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '28'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD29
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD29 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '29'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD30
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD30 = CDD.DiagnosisCode
			FROM OUTB_PROF_DETAIL ECD
				,EDPS_Data.dbo.claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE = '30'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		/************************************************************************************************************************************
		** HRP LINE LEVEL DIAGNOSIS CODE UPDATES - FACETS ONLY - claimdetaildim.claimlineno (int) is formatted differently then 
		**										claimdiagnosisdetaildim.claimlineno ('0' pad)
		** OUTB_PROF_DETAIL UPDATES
		** update diagnosis codes
		**************************************************************************************************************************************/
			IF OBJECT_ID('TEMPDB..#tmp_claimdetaildiagnosisdim') <> 0
		DROP TABLE #tmp_claimdetaildiagnosisdim
		
		select CLAIMID,CD.SOURCEDATAKEY,CLAIMDETAILDIAGNOSISKEY,replace(CLAIMLINEID,'0','') as 'claimlineid',REPLACE(DIAGNOSISCODE,'.','') AS 'DIAGNOSISCODE',SEQUENCE
		into #tmp_claimdetaildiagnosisdim
	from EDPS_Data.dbo.claimdetaildiagnosisdim CD
	JOIN OUTB_PROF_HEADER C
	ON C.CLAIM_ID = CD.CLAIMID
	--where CLAIMID in (select claimid from OUTB_PROF_HEADER)
	order by CLAIMID,CLAIMLINEID	
	
		--PRIM_DIAG_CD
		
		
	begin transaction 
			update OUTB_PROF_DETAIL
			set PRIM_DIAG_CD = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  CDD.CLAIMLINEID
				AND CDD.SEQUENCE in ('01','1')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
--UPDATE DIAG_CD2
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD2 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND rtrim(ECD.CLAIM_LINE_NO) = rtrim(CDD.CLAIMLINEID)-- replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE in ( '02','2')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit		
--UPDATE DIAG_CD3
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD3 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE in ( '03','3')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD4
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD4 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE in ( '04','4')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD5
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD5 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE in ( '05','5')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD6
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD6 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE in ( '06','6')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD7
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD7 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE in ( '07','7')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD8
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD8 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND rtrim(ECD.CLAIM_LINE_NO) = rtrim(CDD.CLAIMLINEID)-- replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE in ( '08','8')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD9
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD9 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE in ( '09','9')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD10
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD10 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE in ( '0010','10')
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD11
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD11 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '11'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD12
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD12 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '12'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD13
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD13 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '13'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD14
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD14 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '14'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD15
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD15 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '15'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD16
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD16 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '16'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD17
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD17 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '17'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD18
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD18 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '18'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD19
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD19 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '19'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD20
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD20 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '20'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD21
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD21 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '21'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD22
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD22 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '22'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
		--UPDATE DIAG_CD23
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD23 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '23'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD24
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD24 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '24'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD25
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD25 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '25'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit			
			--UPDATE DIAG_CD26
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD26 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '26'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD27
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD27 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '27'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD28
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD28 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '28'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD29
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD29 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '29'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit	
			--UPDATE DIAG_CD30
		begin transaction 
			update OUTB_PROF_DETAIL
			set DIAG_CD30 = replace(CDD.DiagnosisCode,'.','')
			FROM OUTB_PROF_DETAIL ECD
				,#tmp_claimdetaildiagnosisdim CDD
			WHERE ECD.CLAIM_ID = CDD.CLAIMID and ECD.SOURCEDATAKEY IN ('30')
				AND ECD.CLAIM_LINE_NO =  replace(CDD.CLAIMLINEID,'0','')
				AND CDD.SEQUENCE = '30'
			if @@ERROR <> 0
			begin
				rollback 
			end
		commit
		
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_PROF_HEADER_RESEND
			
			SET @TOTAL_HEADER_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_HEADER)
			SET @TOTAL_DETAIL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_DETAIL)			 
			SET @TOTAL_RECORDS =(@TOTAL_HEADER_RECORDS + @TOTAL_DETAIL_RECORDS)
									
----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_CLAIM_PROF_DIAG'
							AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
