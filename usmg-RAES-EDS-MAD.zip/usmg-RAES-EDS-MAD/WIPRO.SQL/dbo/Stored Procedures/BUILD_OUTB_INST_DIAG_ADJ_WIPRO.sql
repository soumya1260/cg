﻿

--
						

CREATE PROCEDURE [dbo].[BUILD_OUTB_INST_DIAG_ADJ_WIPRO]
(@SOURCEDATAKEY INT)
AS
/***************************************************************************************************
** CREATE DATE: 06/2012
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM HEADER 
**              AND LINE LEVE DIAGNOSIS CODE INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
2012-10-19		Dwight Staggs	Remove database name from table references
2013-03-22		Loyal Ricks		Revised Diag. 1-9 update to include appropriate logic for sequence
								number in join. Facets uses 1 char '1', all others using '01' for 
								claim header updates (OUTB_PROF_HEADER)
2013-04-26		Loyal Ricks		Revised Diag. 1-9 update to include appropriate logic for sequence
								number in join. Facets uses 1 char '1', all others using '01' for 
								claim detail updates (OUTB_PROF_DETAIL)
2013-05-16		Loyal Ricks		Added Facets OUTB_PROF_DETAIL Update Logic (line level diagnosis
								& pointer info)
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation		
2014-07-31		Loyal Ricks		Added Qualifier Codes (Principal, Institutional Visit, Daig Code) and 
								logic for updating appropriate codes for this sp.	
2014-11-19		Loyal Ricks		WIPRO Pointer revision, revise pointer logic to be sequential in order 
								and not be the actual pointer to the diagnosis submission.	
2015-02-09		Loyal Ricks		EDS-706 Facets professional Claim integration - evaluate @sourcedatakey in 
								order to determine appropriate DX selection criteria for each sdk. QNXT and
								MHC use same code blocks, Facets uses indepeent code block. 		
2015-02-25		Loyal Ricks		EDS-711 Replace all diagnosis code values of 'UNKNOWN' with a blank value.	
				Loyal Ricks		Performance and fine tuning - removal of explicit transactions	
2015-10-31		Loyal Ricks		TETDM-438 Professional Claim ICD10 Revisions- Revise #claimdetaildiagnosisdim.daignosiscode to varchar10 
2015-10-28		Loyal Ricks		TETDM-438 ICD-10 Qualifier Revisions		
2016-03-01		Loyal Ricks		Realign DIAG_CD shifting DIAG_CD 2-30 up to populate DIAG_CD1 -30. Institutional primary diagnosis code
								is assigned for Institutional claims so outbound file DIAG_CD1 should be populated by DIAG_CD2 (SEQUENCE = 2) 
								from BIDW source claimdiagnosisdim	
2016-03-14		Loyal Ricks		TETDM-673 Realignment of DAIG_CD1-DIAG_CD30 when ADMIN_DAIG_CD = DIAG_CD1	
2016-03-17		Loyal Ricks		TETDM-685 Reorder DIAG_CD1 - DIAG_CD30 When the claimed in ClaimDiagnosisdim contains secondary diagnosis 
								codes with sequences that are not in sequential order. 	 	
2016-03-22		Loyal Ricks		TETDM-696 Create Edit - Duplicate Principal Diagnsosi Code																		    
*****************************************************************************************************/		
--UPDATE DIAGNOSIS POINTERS
		--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM OUTB_PROF_HEADER_RES
			DECLARE
			
			@TOTAL_HEADER_RECORDS INT,
			@TOTAL_DETAIL_RECORDS INT,
			@TOTAL_RECORDS INT
--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_INST_DIAG_ADJ_WIPRO'
				,'4'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
	IF OBJECT_ID('TEMPDB..#diag_adj') <> 0
					DROP TABLE #diag_adj
					
					CREATE TABLE #diag_adj
					(  claimid varchar(20),
						sourcedatakey int
					)
					
			---Identify claims requiring diag_cd adjustment

			insert into #diag_adj
			select claim_id,sourcedatakey  
			from outb_inst_header
			WHERE len(INST_ADM_DIAG_CD) > 0 
						and INST_ADM_DIAG_CD = diag_cd1

			--reset existing diag_cd and poa_ind

			update OUTB_INST_HEADER
			SET DIAG_CD1 = ' ',POA_IND1 = ' ', DIAG_CD_QUAL1 = ' ',
				DIAG_CD2 = ' ',POA_IND2 = ' ', DIAG_CD_QUAL2 = ' ',
				DIAG_CD3 = ' ',POA_IND3 = ' ', DIAG_CD_QUAL3 = ' ',
				DIAG_CD4 = ' ',POA_IND4 = ' ', DIAG_CD_QUAL4 = ' ',
				DIAG_CD5 = ' ',POA_IND5 = ' ', DIAG_CD_QUAL5 = ' ',
				DIAG_CD6 = ' ',POA_IND6 = ' ', DIAG_CD_QUAL6 = ' ',
				DIAG_CD7 = ' ',POA_IND7 = ' ', DIAG_CD_QUAL7 = ' ',
				DIAG_CD8 = ' ',POA_IND8 = ' ', DIAG_CD_QUAL8 = ' ',
				DIAG_CD9 = ' ',POA_IND9 = ' ', DIAG_CD_QUAL9 = ' ',
				DIAG_CD10 = ' ',POA_IND10 = ' ', DIAG_CD_QUAL10 = ' ',
				DIAG_CD11 = ' ',POA_IND11 = ' ', DIAG_CD_QUAL11 = ' ',
				DIAG_CD12 = ' ',POA_IND12 = ' ', DIAG_CD_QUAL12 = ' ',
				DIAG_CD13 = ' ',POA_IND13 = ' ', DIAG_CD_QUAL13 = ' ',
				DIAG_CD14 = ' ',POA_IND14 = ' ', DIAG_CD_QUAL14 = ' ',
				DIAG_CD15 = ' ',POA_IND15 = ' ', DIAG_CD_QUAL15 = ' ',
				DIAG_CD16 = ' ',POA_IND16 = ' ', DIAG_CD_QUAL16 = ' ',
				DIAG_CD17 = ' ',POA_IND17 = ' ', DIAG_CD_QUAL17 = ' ',
				DIAG_CD18 = ' ',POA_IND18 = ' ', DIAG_CD_QUAL18 = ' ',
				DIAG_CD19 = ' ',POA_IND19 = ' ', DIAG_CD_QUAL19 = ' ',
				DIAG_CD20 = ' ',POA_IND20 = ' ', DIAG_CD_QUAL20 = ' ',
				DIAG_CD21 = ' ',POA_IND21 = ' ', DIAG_CD_QUAL21 = ' ',
				DIAG_CD22 = ' ',POA_IND22 = ' ', DIAG_CD_QUAL22 = ' ',
				DIAG_CD23 = ' ',POA_IND23 = ' ', DIAG_CD_QUAL23 = ' ',
				DIAG_CD24 = ' ',POA_IND24 = ' ', DIAG_CD_QUAL24 = ' ',
				DIAG_CD25 = ' ',POA_IND25 = ' ', DIAG_CD_QUAL25 = ' ',
				DIAG_CD26 = ' ',POA_IND26 = ' ', DIAG_CD_QUAL26 = ' ',
				DIAG_CD27 = ' ',POA_IND27 = ' ', DIAG_CD_QUAL27 = ' ',
				DIAG_CD28 = ' ',POA_IND28 = ' ', DIAG_CD_QUAL28 = ' ',
				DIAG_CD29 = ' ',POA_IND29 = ' ', DIAG_CD_QUAL29 = ' ',
				DIAG_CD30 = ' ',POA_IND30 = ' ', DIAG_CD_QUAL30 = ' '
				FROM OUTB_INST_HEADER H
				INNER JOIN #diag_adj D
				ON H.SOURCEDATAKEY = D.SOURCEDATAKEY 
				AND H.CLAIM_ID = D.CLAIMID
--UPDATE DIAGNOSIS CODES
	 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD1 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND1 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL1 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE in ( '03','3')
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD2 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND2 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL2 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE in ('4', '04')
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD3 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND3 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL3 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE in ('5', '05')
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD4 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND4 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL4 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE in ('6', '06')
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD5 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND5 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL5 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE in ('7', '07')
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD6 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND6 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL6 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE in ('8', '08')
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD7 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND7 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL7 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE in ('9', '09')
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD8 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND8 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL8 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '10'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD9 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND9 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL9 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '11'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD10 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND10 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL10 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '12'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD11 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND11 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL11 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '13'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD12 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND12 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL12 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '14'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD13 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND13 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL13 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '15'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD14 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND14 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL14 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '16'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD15 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND15 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL15 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '17'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD16 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND16 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL16 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '18'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD17 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND17 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL17 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '19'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD18 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND18 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL18 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '20'
			
			
				 
			
		
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD19 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND19 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL19 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '21'
			
			
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD20 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND20 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL20 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '22'	 
			
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD21 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND21 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL21 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '23'	 

			UPDATE OUTB_INST_HEADER
			SET DIAG_CD22 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND22 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL22 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '24'	 
		
			
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD23 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND23 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL23 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '25'	 

			UPDATE OUTB_INST_HEADER
			SET DIAG_CD24 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND24 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL24 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '26'	 

			UPDATE OUTB_INST_HEADER
			SET DIAG_CD25 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND25 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL25 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '27'	 

			UPDATE OUTB_INST_HEADER
			SET DIAG_CD26 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND26 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL26 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '28'	 

			UPDATE OUTB_INST_HEADER
			SET DIAG_CD27 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND27 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL27 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '29'	 

			UPDATE OUTB_INST_HEADER
			SET DIAG_CD28 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND28 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL28 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '30'	 
		
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD29 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND29 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL29 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '31'	 
			
			UPDATE OUTB_INST_HEADER
			SET DIAG_CD30 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND30 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
				DIAG_CD_QUAL30 = 'BF'
			FROM OUTB_INST_HEADER E
			INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CDG
			ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
			AND  E.CLAIM_ID = CDG.CLAIMID 
			INNER JOIN #diag_adj D
			ON E.SOURCEDATAKEY = D.SOURCEDATAKEY 
			AND E.CLAIM_ID = D.CLAIMID 
			WHERE CDG.SEQUENCE = '32'	 
		
			--TETDM-685

			IF OBJECT_ID('TEMPDB..#claimdiagnosisdim') <> 0
					DROP TABLE #claimdiagnosisdim
					
					CREATE TABLE #claimdiagnosisdim
					(  claimid varchar(20)
						,sourcedatakey int
						,DIAGNOSISCODE varchar(10)
						,POAIND VARCHAR(1)
						,SEQUENCE int
					)
					

					insert into #claimdiagnosisdim
					select CLAIMID,
							P.sourcedatakey,
							DIAGNOSISCODE,
							POAIND,
							--SEQUENCE,
							 ROW_NUMBER() OVER ( PARTITION BY ClaimID ORDER BY CLAIMID,DIAGNOSISCODE)
					from OUTB_INST_HEADER P
					INNER JOIN EDPS_Data.dbo.claimdiagnosisdim CD
					ON P.CLAIM_ID = CD.CLAIMID 
					AND P.SOURCEDATAKEY = CD.SOURCEDATAKEY
					WHERE LEN(P.DIAG_CD1) = 0 
						AND cd.DELETED = 0
						AND CD.DIAGNOSISTYPECODE = 'S'       
					order by CD.claimid,DIAGNOSISCODE

					--reset existing diag_cd and poa_ind
						update OUTB_INST_HEADER
						SET DIAG_CD1 = ' ',POA_IND1 = ' ', DIAG_CD_QUAL1 = ' ',
							DIAG_CD2 = ' ',POA_IND2 = ' ', DIAG_CD_QUAL2 = ' ',
							DIAG_CD3 = ' ',POA_IND3 = ' ', DIAG_CD_QUAL3 = ' ',
							DIAG_CD4 = ' ',POA_IND4 = ' ', DIAG_CD_QUAL4 = ' ',
							DIAG_CD5 = ' ',POA_IND5 = ' ', DIAG_CD_QUAL5 = ' ',
							DIAG_CD6 = ' ',POA_IND6 = ' ', DIAG_CD_QUAL6 = ' ',
							DIAG_CD7 = ' ',POA_IND7 = ' ', DIAG_CD_QUAL7 = ' ',
							DIAG_CD8 = ' ',POA_IND8 = ' ', DIAG_CD_QUAL8 = ' ',
							DIAG_CD9 = ' ',POA_IND9 = ' ', DIAG_CD_QUAL9 = ' ',
							DIAG_CD10 = ' ',POA_IND10 = ' ', DIAG_CD_QUAL10 = ' ',
							DIAG_CD11 = ' ',POA_IND11 = ' ', DIAG_CD_QUAL11 = ' ',
							DIAG_CD12 = ' ',POA_IND12 = ' ', DIAG_CD_QUAL12 = ' ',
							DIAG_CD13 = ' ',POA_IND13 = ' ', DIAG_CD_QUAL13 = ' ',
							DIAG_CD14 = ' ',POA_IND14 = ' ', DIAG_CD_QUAL14 = ' ',
							DIAG_CD15 = ' ',POA_IND15 = ' ', DIAG_CD_QUAL15 = ' ',
							DIAG_CD16 = ' ',POA_IND16 = ' ', DIAG_CD_QUAL16 = ' ',
							DIAG_CD17 = ' ',POA_IND17 = ' ', DIAG_CD_QUAL17 = ' ',
							DIAG_CD18 = ' ',POA_IND18 = ' ', DIAG_CD_QUAL18 = ' ',
							DIAG_CD19 = ' ',POA_IND19 = ' ', DIAG_CD_QUAL19 = ' ',
							DIAG_CD20 = ' ',POA_IND20 = ' ', DIAG_CD_QUAL20 = ' ',
							DIAG_CD21 = ' ',POA_IND21 = ' ', DIAG_CD_QUAL21 = ' ',
							DIAG_CD22 = ' ',POA_IND22 = ' ', DIAG_CD_QUAL22 = ' ',
							DIAG_CD23 = ' ',POA_IND23 = ' ', DIAG_CD_QUAL23 = ' ',
							DIAG_CD24 = ' ',POA_IND24 = ' ', DIAG_CD_QUAL24 = ' ',
							DIAG_CD25 = ' ',POA_IND25 = ' ', DIAG_CD_QUAL25 = ' ',
							DIAG_CD26 = ' ',POA_IND26 = ' ', DIAG_CD_QUAL26 = ' ',
							DIAG_CD27 = ' ',POA_IND27 = ' ', DIAG_CD_QUAL27 = ' ',
							DIAG_CD28 = ' ',POA_IND28 = ' ', DIAG_CD_QUAL28 = ' ',
							DIAG_CD29 = ' ',POA_IND29 = ' ', DIAG_CD_QUAL29 = ' ',
							DIAG_CD30 = ' ',POA_IND30 = ' ', DIAG_CD_QUAL30 = ' '
							FROM OUTB_INST_HEADER H
							INNER JOIN #claimdiagnosisdim D
							ON H.SOURCEDATAKEY = D.SOURCEDATAKEY 
							AND H.CLAIM_ID = D.CLAIMID

							UPDATE OUTB_INST_HEADER
							SET DIAG_CD1 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND1 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL1 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 1
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD2 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND2 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL2 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 2
			
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD3 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND3 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL3 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 3
			
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD4 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND4 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL4 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 4
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD5 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND5 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL5 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 5
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD6 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND6 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL6 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 6
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD7 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND7 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL7 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 7
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD8 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND8 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL8 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 8
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD9 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND9 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL9 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 9
		
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD10 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND10 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL10 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 10
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD11 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND11 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL11 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 11
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD12 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND12 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL12 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 12
		
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD13 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND13 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL13 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 13
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD14 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND14 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL14 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 14
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD15 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND15 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL15 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 15
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD16 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND16 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL16 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 16
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD17 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND17 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL17 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 17
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD18 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND18 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL18 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 18
			
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD19 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND19 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL19 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 19
			
			
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD20 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND20 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL20 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 20	 
			
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD21 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND21 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL21 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 21	 

							UPDATE OUTB_INST_HEADER
							SET DIAG_CD22 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND22 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL22 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 22	 
		
			
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD23 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND23 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL23 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 23	 

							UPDATE OUTB_INST_HEADER
							SET DIAG_CD24 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND24 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL24 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 24	 

							UPDATE OUTB_INST_HEADER
							SET DIAG_CD25 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND25 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL25 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 25	 

							UPDATE OUTB_INST_HEADER
							SET DIAG_CD26 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND26 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL26 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 26	 

							UPDATE OUTB_INST_HEADER
							SET DIAG_CD27 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND27 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL27 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 27	 

							UPDATE OUTB_INST_HEADER
							SET DIAG_CD28 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND28 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL28 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 28	 
		
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD29 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND29 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL29 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 29	 
			
							UPDATE OUTB_INST_HEADER
							SET DIAG_CD30 = replace(CDG.DIAGNOSISCODE,'.',''),POA_IND30 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
								DIAG_CD_QUAL30 = 'BF'
							FROM OUTB_INST_HEADER E
							INNER JOIN #claimdiagnosisdim CDG
							ON E.SOURCEDATAKEY = CDG.SOURCEDATAKEY 
							AND E.CLAIM_ID = CDG.CLAIMID 
							WHERE CDG.SEQUENCE = 30	
					

					
			
				--TETDM-438 ICD-10 Qualifier Revisions
	
				--TETDM-438 ICD-10 Qualifier Revisions
				--ICD-10 Principal Diag Qual
				Update OUTB_INST_HEADER 
				SET PRINCIPAL_DIAG_QUAL = 'A'+''+RTRIM(PRINCIPAL_DIAG_QUAL)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND H.PRINCIPAL_DIAG_QUAL = 'BK'


				--ICD-10 DIAG_CD_QUAL1
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL1 = 'A'+''+RTRIM(DIAG_CD_QUAL1)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL1 =  'BF'

				--ICD-10 DIAG_CD_QUAL2
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL2 = 'A'+''+RTRIM(DIAG_CD_QUAL2)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL2 =  'BF'


				--ICD-10 DIAG_CD_QUAL3
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL3 = 'A'+''+RTRIM(DIAG_CD_QUAL3)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL3=  'BF'

				--ICD-10 DIAG_CD_QUAL4
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL4 = 'A'+''+RTRIM(DIAG_CD_QUAL4)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL4 =  'BF'

				--ICD-10 DIAG_CD_QUAL5
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL5 = 'A'+''+RTRIM(DIAG_CD_QUAL5)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL5 =  'BF'

				--ICD-10 DIAG_CD_QUAL6
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL6 = 'A'+''+RTRIM(DIAG_CD_QUAL6)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL6 =  'BF'

				--ICD-10 DIAG_CD_QUAL7
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL7 = 'A'+''+RTRIM(DIAG_CD_QUAL7)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL7 =  'BF'

				--ICD-10 DIAG_CD_QUAL8
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL8 = 'A'+''+RTRIM(DIAG_CD_QUAL8)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL8 =  'BF'

				--ICD-10 DIAG_CD_QUAL9
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL9 = 'A'+''+RTRIM(DIAG_CD_QUAL9)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL9 =  'BF'

				--ICD-10 DIAG_CD_QUAL1
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL10 = 'A'+''+RTRIM(DIAG_CD_QUAL10)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL10 =  'BF'

				--ICD-10 DIAG_CD_QUAL11
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL11 = 'A'+''+RTRIM(DIAG_CD_QUAL11)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL11 =  'BF'

				--ICD-10 DIAG_CD_QUAL12
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL12 = 'A'+''+RTRIM(DIAG_CD_QUAL12)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL12 =  'BF'

				--ICD-10 DIAG_CD_QUAL13
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL13 = 'A'+''+RTRIM(DIAG_CD_QUAL13)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL13 =  'BF'

				--ICD-10 DIAG_CD_QUAL14
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL14 = 'A'+''+RTRIM(DIAG_CD_QUAL14)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL14 =  'BF'

				--ICD-10 DIAG_CD_QUAL15
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL15 = 'A'+''+RTRIM(DIAG_CD_QUAL15)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL15 =  'BF'

				--ICD-10 DIAG_CD_QUAL16
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL16 = 'A'+''+RTRIM(DIAG_CD_QUAL16)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL16 =  'BF'

				--ICD-10 DIAG_CD_QUAL17
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL17 = 'A'+''+RTRIM(DIAG_CD_QUAL17)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL17 =  'BF'

				--ICD-10 DIAG_CD_QUAL18
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL18 = 'A'+''+RTRIM(DIAG_CD_QUAL18)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL18 =  'BF'

				--ICD-10 DIAG_CD_QUAL19
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL19 = 'A'+''+RTRIM(DIAG_CD_QUAL19)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL19 =  'BF'

				--ICD-10 DIAG_CD_QUAL20
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL20 = 'A'+''+RTRIM(DIAG_CD_QUAL20)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL20 =  'BF'

				--ICD-10 DIAG_CD_QUAL21
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL21 = 'A'+''+RTRIM(DIAG_CD_QUAL21)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL21 =  'BF'

				--ICD-10 DIAG_CD_QUAL22
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL22 = 'A'+''+RTRIM(DIAG_CD_QUAL22)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL22 =  'BF'

				--ICD-10 DIAG_CD_QUAL23
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL23 = 'A'+''+RTRIM(DIAG_CD_QUAL23)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL23 =  'BF'

				--ICD-10 DIAG_CD_QUAL24
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL24 = 'A'+''+RTRIM(DIAG_CD_QUAL24)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL24 =  'BF'

				--ICD-10 DIAG_CD_QUAL25
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL25 = 'A'+''+RTRIM(DIAG_CD_QUAL25)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL25 =  'BF'

				--ICD-10 DIAG_CD_QUAL26
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL26 = 'A'+''+RTRIM(DIAG_CD_QUAL26)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL26 =  'BF'

				--ICD-10 DIAG_CD_QUAL27
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL27 = 'A'+''+RTRIM(DIAG_CD_QUAL27)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL27 =  'BF'

				--ICD-10 DIAG_CD_QUAL28
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL28 = 'A'+''+RTRIM(DIAG_CD_QUAL28)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL28 =  'BF'

				--ICD-10 DIAG_CD_QUAL29
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL29 = 'A'+''+RTRIM(DIAG_CD_QUAL29)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL29 =  'BF'

				--ICD-10 DIAG_CD_QUAL30
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL30 = 'A'+''+RTRIM(DIAG_CD_QUAL30)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL30 =  'BF'
			 
			
				--TETDM-696 Edit - Duplicate Principal Diagnsosi Code

				Update OUTB_INST_HEADER
				set DIAG_CD1 = ' ',
					DIAG_CD_QUAL1 = ' ',
					POA_IND1 = ' '
				where INST_PRINCIPAL_DIAG_CD = INST_ADM_DIAG_CD 
						AND INST_ADM_DIAG_CD = DIAG_CD1 
						AND DIAG_CD2 = ' '
		
		
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_INST_HEADER_RES
			
			SET  @TOTAL_RECORDS = (SELECT COUNT(*) FROM #diag_adj)	
			SET  @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM #claimdiagnosisdim)	 
												
----HRP_CLAIM_FILE Update Run Controls
				
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_INST_DIAG_ADJ_WIPRO'
							AND END_DT IS NULL
							
										
												 
										
						

