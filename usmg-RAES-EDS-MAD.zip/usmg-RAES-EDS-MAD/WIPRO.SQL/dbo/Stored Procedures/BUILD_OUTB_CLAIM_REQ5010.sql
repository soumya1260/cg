﻿CREATE PROCEDURE [dbo].[BUILD_OUTB_CLAIM_REQ5010]
AS
/************************************************************************************************************************
** CREATE DATE: 03/05/2013
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY OBTAIN PROVIDER SPECIFIC  
**              INFORMATION NEEDED FOR THE HRP CLAIM FILE. 
**              TABLES SUPPORTING THIS SCRIPT IS OWNED AND MAINTAINED BY THE ODS TEAM. 
**
**
Modification History
====================
Date			Who				Description
--------------------------------------------------------------------------------------------------------------------------
05/10/2013		LOYAL RICKS		RTRIM EDI_REQ_5010 data elements due to default data length set by ODS of 50 characters
								Add conditional logic for applying updates due to HRP rejections, check length 
								before applying update. If len of applicable data element > 0 then apply 
								EDI_REQ_5010 updates, eles leave default assignment.
06/08/2013		Loyal Ricks		Remove archive of hits used to support testing
09/24/2013		Loyal Ricks		Add parameter @SourceEnvironment, default for BIDW source ('UAT')
05/16/2014		Loyal Ricks		Change default hard coded parameter value for @sourceenvironment from UAT to PROD
**************************************************************************************************************************/
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM OUTB_PROF_HEADER_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT
			,@SourceEnvironment varchar(10)
			
			set @SourceEnvironment = 'PROD';


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_CLAIM_REQ5010'
				,'8'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
				
Create Table #temp_EDI_REQ_5010
 		(
		CLAIM_ID VARCHAR(20),
		PROVIDERSIGNATURE VARCHAR(1),
		PROVIDERACCEPTSASSGN VARCHAR(1),
		BENASSGNCERTIND	VARCHAR(1),
		RELEASEOFINFOFLAG VARCHAR(1),
		sourcedatakey varchar(50)
		
		)
		
		INSERT INTO #temp_EDI_REQ_5010
		SELECT C.CLAIM_ID
			,isnull(rtrim(ER.PROVIDERSIGNATURE),' ')
			,isnull(rtrim(ER.PROVIDERACCEPTSASSGN),' ')
			,isnull(rtrim(ER.BenAssgnCertInd),' ')
			,isnull(rtrim(ER.RELEASEOFINFOFLAG),' ')
			,isnull(rtrim(ER.SourceDataKey),' ')			
		FROM OUTB_PROF_HEADER C
		join EDPS_Data.dbo.EDI_Reqd_5010 ER
		on  C.CLAIM_ID = ER.ClaimNo
		where SourceEnvironment = @SourceEnvironment
			 --DO NOT USE LINEID, LINEID IS NULL
			 --AND ER.LINEID = '1'
		
		------conditional catch all updates, update from catch all only when there is a value populated
		
		UPDATE OUTB_PROF_HEADER
		SET PROV_ASSGN_IND = ER.PROVIDERACCEPTSASSGN
		FROM OUTB_PROF_HEADER C
			,#temp_EDI_REQ_5010  ER
		WHERE C.CLAIM_ID = ER.CLAIM_ID
			and LEN(ER.PROVIDERACCEPTSASSGN) > 0
			
		UPDATE OUTB_PROF_HEADER
		SET REL_OF_INFO_FLAG = ER.RELEASEOFINFOFLAG
		FROM OUTB_PROF_HEADER C
			,#temp_EDI_REQ_5010  ER
		WHERE C.CLAIM_ID = ER.CLAIM_ID
			and LEN(ER.RELEASEOFINFOFLAG) > 0
			
		UPDATE OUTB_PROF_HEADER
		SET INSR_BEN_ASSGN_IND = ER.BENASSGNCERTIND
		FROM OUTB_PROF_HEADER C
			,#temp_EDI_REQ_5010  ER
		WHERE C.CLAIM_ID = ER.CLAIM_ID
			AND LEN(ER.BENASSGNCERTIND) > 0
		
		UPDATE OUTB_PROF_HEADER
		SET PROV_SIGNATURE_FLAG = ER.PROVIDERSIGNATURE
		FROM OUTB_PROF_HEADER C
			,#temp_EDI_REQ_5010  ER
		WHERE C.CLAIM_ID = ER.CLAIM_ID
			AND LEN(ER.PROVIDERSIGNATURE) > 0
		
		--INSERT INTO EXT_HRP_EDI_REQ_5010
		--SELECT *
		--FROM #temp_EDI_REQ_5010
		--WHERE CLAIM_ID NOT IN (SELECT CLAIM_ID FROM EXT_HRP_EDI_REQ_5010)
		
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_PROF_HEADER_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #temp_EDI_REQ_5010)
									
		----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_CLAIM_REQ5010'
							AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
						
