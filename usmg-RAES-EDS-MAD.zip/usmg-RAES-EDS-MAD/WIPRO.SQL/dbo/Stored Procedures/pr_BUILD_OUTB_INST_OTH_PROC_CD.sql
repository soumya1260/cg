﻿

CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_OTH_PROC_CD]
--(@BEGIN_DOS CHAR(8), @END_DOS CHAR(8)  )
AS
/***************************************************************************************************
** CREATE DATE: 12/2016
**
** AUTHOR: LOYAL RICKS 
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM Other Procedure
**				CODE INFORMATION USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.2. 
**				THE SOURCE TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES.  
**              
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
04/11/2017   John Bartholomay   TETDM-644 - Modifications to allow for 2nd pass to accomidated
                                            addiontal procedure pointers for '01' sequence	
09/13/2017   John Bartholomay   TETDM-1622  Remove decimal from procedure codes						 
*****************************************************************************************************/			
DECLARE

@TOTAL_RECORDS INT

	--EXT_SYS_RUNLOG
	INSERT INTO EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT
			)
			VALUES('pr_BUILD_OUTB_INST_OTH_PROC_CD'
					,'9'
					,GETDATE()
					,null
					,' '
					,0
					,GETDATE()
					)
		
				IF OBJECT_ID('TEMPDB..#PROC') <> 0
					DROP TABLE #PROC

					
				
								CREATE TABLE #PROC
								(CLAIMID VARCHAR(20),
								ICD9CODE VARCHAR(10),
								PROCEDUREDATE INT,
								PROC_TYPE VARCHAR(5),
								PROCEDURE_TYPE VARCHAR(02),
								SEQUENCE CHAR(2)
								)

								----------------------------------
								-- 'O'THER PROCEDURE CODES SEQ 1
								----------------------------------
								INSERT INTO #PROC
								select claimid,REPLACE(ip.ICD9Code,'.',''),IP.proceduredate, CASE diagnosiscodeversion when '9' then 'BQ' when '0' then 'BBQ' else diagnosiscodeversion END,IP.ProcedureTypeCode,sequence
								from edps_data.dbo.ClaimICD9ProcedureDim ip
								inner join OUTB_INST_HEADER H
								ON IP.SOURCEDATAKEY = H.SOURCEDATAKEY 
								AND IP.CLAIMID = H.CLAIM_ID
								AND ip.Sequence = '01'
								AND ip.ProcedureTypeCode = 'O'
								ORDER BY IP.CLAIMID,IP.SEQUENCE

								---------------------------------------
								-- PRIMARY WITH SEQ 01
								---------------------------------------
								INSERT INTO #PROC
								select ip.claimid,REPLACE(ip.ICD9Code,'.',''),IP.proceduredate,  CASE diagnosiscodeversion when '9' then 'BR' when '0' then 'BBR' else diagnosiscodeversion end,ip.ProcedureTypeCode,IP.sequence
								from edps_data.dbo.ClaimICD9ProcedureDim ip
								inner join OUTB_INST_HEADER H
								ON IP.SOURCEDATAKEY = H.SOURCEDATAKEY 
								 AND IP.CLAIMID = H.CLAIM_ID
								 AND ip.Sequence = '01'
								 AND ip.ProcedureTypeCode = 'P'
								JOIN #PROC PP
								  ON PP.CLAIMID = ip.ClaimID
								  AND ip.CLAIMID + ip.Sequence + REPLACE(ip.ICD9Code,'.','') + ip.ProcedureTypeCode NOT IN (SELECT CLAIMID + SEQUENCE + ICD9CODE + PROCEDURE_TYPE FROM #PROC)
								ORDER BY IP.CLAIMID,IP.SEQUENCE

								--------------------------------------
								-- ALL OTHER PROCEDURE CODES
								---------------------------------------
                                INSERT INTO #PROC
								select ip.claimid,REPLACE(ip.ICD9Code,'.',''),IP.proceduredate,  CASE diagnosiscodeversion when '9' then 'BQ' when '0' then 'BBQ' else diagnosiscodeversion end,ip.ProcedureTypeCode,IP.sequence
								from edps_data.dbo.ClaimICD9ProcedureDim ip
								inner join OUTB_INST_HEADER H
								ON IP.SOURCEDATAKEY = H.SOURCEDATAKEY 
								 AND IP.CLAIMID = H.CLAIM_ID
								 AND IP.Sequence > '01'
								JOIN #PROC PP
								  ON PP.CLAIMID = ip.ClaimID
								  AND ip.CLAIMID + ip.Sequence + REPLACE(ip.ICD9Code,'.','')  NOT IN (SELECT CLAIMID + SEQUENCE + ICD9CODE  FROM #PROC)
								ORDER BY IP.CLAIMID,IP.SEQUENCE


															
								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_11 = P.PROC_TYPE,
									OTH_PROC_CD_11 = P.ICD9CODE,
									OTH_PROC_CD_DT_11 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '01'
								 AND P.PROCEDURE_TYPE = 'P'


								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_12 = P.PROC_TYPE,
									OTH_PROC_CD_12 = P.ICD9CODE,
									OTH_PROC_CD_DT_12 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '01'
								 AND P.PROCEDURE_TYPE = 'O'        

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_13 = P.PROC_TYPE,
									OTH_PROC_CD_13 = P.ICD9CODE,
									OTH_PROC_CD_DT_13 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '02'


								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_14 = P.PROC_TYPE,
									OTH_PROC_CD_14 = P.ICD9CODE,
									OTH_PROC_CD_DT_14 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '03'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_15 = P.PROC_TYPE,
									OTH_PROC_CD_15 = P.ICD9CODE,
									OTH_PROC_CD_DT_15 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '04'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_16 = P.PROC_TYPE,
									OTH_PROC_CD_16 = P.ICD9CODE,
									OTH_PROC_CD_DT_16 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '05'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_17 = P.PROC_TYPE,
									OTH_PROC_CD_17 = P.ICD9CODE,
									OTH_PROC_CD_DT_17 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '06'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_18 = P.PROC_TYPE,
									OTH_PROC_CD_18 = P.ICD9CODE,
									OTH_PROC_CD_DT_18 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '07'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_19 = P.PROC_TYPE,
									OTH_PROC_CD_19 = P.ICD9CODE,
									OTH_PROC_CD_DT_19 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '08'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_110 = P.PROC_TYPE,
									OTH_PROC_CD_110 = P.ICD9CODE,
									OTH_PROC_CD_DT_110 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '09'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_111 = P.PROC_TYPE,
									OTH_PROC_CD_111 = P.ICD9CODE,
									OTH_PROC_CD_DT_111 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '10'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_112 = P.PROC_TYPE,
									OTH_PROC_CD_112 = P.ICD9CODE,
									OTH_PROC_CD_DT_112 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '11'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_21 = P.PROC_TYPE,
									OTH_PROC_CD_21 = P.ICD9CODE,
									OTH_PROC_CD_DT_21 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '12'

								-------------------------

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_22 = P.PROC_TYPE,
									OTH_PROC_CD_22 = P.ICD9CODE,
									OTH_PROC_CD_DT_22 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '13'


								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_23 = P.PROC_TYPE,
									OTH_PROC_CD_23 = P.ICD9CODE,
									OTH_PROC_CD_DT_23 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '14'


								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_24 = P.PROC_TYPE,
									OTH_PROC_CD_24 = P.ICD9CODE,
									OTH_PROC_CD_DT_24 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '15'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_25 = P.PROC_TYPE,
									OTH_PROC_CD_25 = P.ICD9CODE,
									OTH_PROC_CD_DT_25 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '16'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_26 = P.PROC_TYPE,
									OTH_PROC_CD_26 = P.ICD9CODE,
									OTH_PROC_CD_DT_26 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '17'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_27 = P.PROC_TYPE,
									OTH_PROC_CD_27 = P.ICD9CODE,
									OTH_PROC_CD_DT_27 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '18'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_28 = P.PROC_TYPE,
									OTH_PROC_CD_28 = P.ICD9CODE,
									OTH_PROC_CD_DT_28 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '19'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_29 = P.PROC_TYPE,
									OTH_PROC_CD_29 = P.ICD9CODE,
									OTH_PROC_CD_DT_29 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '20'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_210 = P.PROC_TYPE,
									OTH_PROC_CD_210 = P.ICD9CODE,
									OTH_PROC_CD_DT_210 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '21'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_211 = P.PROC_TYPE,
									OTH_PROC_CD_211 = P.ICD9CODE,
									OTH_PROC_CD_DT_211 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '22'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_212 = P.PROC_TYPE,
									OTH_PROC_CD_212 = P.ICD9CODE,
									OTH_PROC_CD_DT_212 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '23'

						
				
				------------------------------------------------------------------------------
				-- Second Pass of claims not containing a Sequence number of '01 for 
				-- and a ProcType  = 'O' (other), those were handled in the first pass
				------------------------------------------------------------------------------
			     IF OBJECT_ID('TEMPDB..#PROC_2') <> 0
					 DROP TABLE #PROC_2
				
								CREATE TABLE #PROC_2
								(CLAIMID VARCHAR(20),
								ICD9CODE VARCHAR(10),
								PROCEDUREDATE INT,
								PROC_TYPE VARCHAR(5),
								PROCEDURE_TYPE VARCHAR(01),
								SEQUENCE CHAR(2)
								)
       							
								-----------------------------------------
								-- PRIMARY PROCS WITH ONLY 1 '01' SEQ NO
								-----------------------------------------
								INSERT INTO #PROC_2
								select claimid,REPLACE(ip.ICD9Code,'.',''),IP.proceduredate,  CASE diagnosiscodeversion when '9' then 'BR' when '0' then 'BBR' else diagnosiscodeversion end,IP.ProcedureTypeCode,sequence
								from edps_data.dbo.ClaimICD9ProcedureDim ip
								inner join OUTB_INST_HEADER H
								ON IP.SOURCEDATAKEY = H.SOURCEDATAKEY 
								AND IP.CLAIMID = H.CLAIM_ID
								AND IP.Sequence = '01'
								AND IP.ProcedureTypeCode = 'P'
								AND ip.CLAIMID + ip.Sequence + REPLACE(ip.ICD9Code,'.','') + ip.ProcedureTypeCode NOT IN (SELECT CLAIMID + SEQUENCE + ICD9CODE + PROCEDURE_TYPE FROM #PROC)
								ORDER BY IP.CLAIMID,IP.SEQUENCE

								-----------------------------------
								-- ALL OTHER PROCS
								-----------------------------------
								INSERT INTO #PROC_2
								select claimid,REPLACE(ip.ICD9Code,'.',''),IP.proceduredate,  CASE diagnosiscodeversion when '9' then 'BQ' when '0' then 'BBQ' else diagnosiscodeversion end,IP.ProcedureTypeCode,sequence
								from edps_data.dbo.ClaimICD9ProcedureDim ip
								inner join OUTB_INST_HEADER H
								ON IP.SOURCEDATAKEY = H.SOURCEDATAKEY 
								AND IP.CLAIMID = H.CLAIM_ID
								AND IP.CLAIMID NOT IN (SELECT CLAIMID FROM #PROC)
								AND IP.Sequence > '01'
								AND IP.ProcedureTypeCode = 'O'
								ORDER BY IP.CLAIMID,IP.SEQUENCE

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_11 = P.PROC_TYPE,
									OTH_PROC_CD_11 = P.ICD9CODE,
									OTH_PROC_CD_DT_11 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '01'
       

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_12 = P.PROC_TYPE,
									OTH_PROC_CD_12 = P.ICD9CODE,
									OTH_PROC_CD_DT_12 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '02'


								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_13 = P.PROC_TYPE,
									OTH_PROC_CD_13 = P.ICD9CODE,
									OTH_PROC_CD_DT_13 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '03'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_14 = P.PROC_TYPE,
									OTH_PROC_CD_14 = P.ICD9CODE,
									OTH_PROC_CD_DT_14 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '04'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_15 = P.PROC_TYPE,
									OTH_PROC_CD_15 = P.ICD9CODE,
									OTH_PROC_CD_DT_15 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '05'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_16 = P.PROC_TYPE,
									OTH_PROC_CD_16 = P.ICD9CODE,
									OTH_PROC_CD_DT_16 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '06'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_17 = P.PROC_TYPE,
									OTH_PROC_CD_17 = P.ICD9CODE,
									OTH_PROC_CD_DT_17 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '07'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_18 = P.PROC_TYPE,
									OTH_PROC_CD_18 = P.ICD9CODE,
									OTH_PROC_CD_DT_18 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '08'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_19 = P.PROC_TYPE,
									OTH_PROC_CD_19 = P.ICD9CODE,
									OTH_PROC_CD_DT_19 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '09'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_110 = P.PROC_TYPE,
									OTH_PROC_CD_110 = P.ICD9CODE,
									OTH_PROC_CD_DT_110 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '10'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_111 = P.PROC_TYPE,
									OTH_PROC_CD_111 = P.ICD9CODE,
									OTH_PROC_CD_DT_111 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '11'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_112 = P.PROC_TYPE,
									OTH_PROC_CD_112 = P.ICD9CODE,
									OTH_PROC_CD_DT_112 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '12'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_21 = P.PROC_TYPE,
									OTH_PROC_CD_21 = P.ICD9CODE,
									OTH_PROC_CD_DT_21 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '13'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_22 = P.PROC_TYPE,
									OTH_PROC_CD_22 = P.ICD9CODE,
									OTH_PROC_CD_DT_22 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '14'


								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_23 = P.PROC_TYPE,
									OTH_PROC_CD_23 = P.ICD9CODE,
									OTH_PROC_CD_DT_23 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '15'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_24 = P.PROC_TYPE,
									OTH_PROC_CD_24 = P.ICD9CODE,
									OTH_PROC_CD_DT_24 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '16'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_25 = P.PROC_TYPE,
									OTH_PROC_CD_25 = P.ICD9CODE,
									OTH_PROC_CD_DT_25 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '17'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_26 = P.PROC_TYPE,
									OTH_PROC_CD_26 = P.ICD9CODE,
									OTH_PROC_CD_DT_26 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '18'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_27 = P.PROC_TYPE,
									OTH_PROC_CD_27 = P.ICD9CODE,
									OTH_PROC_CD_DT_27 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '19'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_28 = P.PROC_TYPE,
									OTH_PROC_CD_28 = P.ICD9CODE,
									OTH_PROC_CD_DT_28 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '20'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_29 = P.PROC_TYPE,
									OTH_PROC_CD_29 = P.ICD9CODE,
									OTH_PROC_CD_DT_29 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '21'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_210 = P.PROC_TYPE,
									OTH_PROC_CD_210 = P.ICD9CODE,
									OTH_PROC_CD_DT_210 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '22'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_211 = P.PROC_TYPE,
									OTH_PROC_CD_211 = P.ICD9CODE,
									OTH_PROC_CD_DT_211 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '23'

								UPDATE OUTB_INST_HEADER 
								SET OTH_PROC_CD_TYPE_212 = P.PROC_TYPE,
									OTH_PROC_CD_212 = P.ICD9CODE,
									OTH_PROC_CD_DT_212 = CONVERT(CHAR, PROCEDUREDATE)
								FROM OUTB_INST_HEADER H
								INNER JOIN #PROC_2 P
								ON H.CLAIM_ID = P.CLAIMID
								WHERE P.SEQUENCE = '24'

				------------------------------------------------------------------------------
				-- 2nd pass end
				------------------------------------------------------------------------------
				
				
				--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #PROC)
		----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_OTH_PROC_CD'
								AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT