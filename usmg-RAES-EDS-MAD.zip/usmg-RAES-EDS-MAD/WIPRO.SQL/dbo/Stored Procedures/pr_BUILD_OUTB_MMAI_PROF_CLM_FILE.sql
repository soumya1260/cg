﻿



CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_MMAI_PROF_CLM_FILE] 
(	@LOB CHAR(10)  --Valid Values (MMAI,MOA)
	,@ExecutionMode		CHAR(1) = 'M'
	,@exclusionmode		char(1) = 'R'
	--,@sourcedatakey		int
	,@JOBID				INT =1
	,@LOBCODE			VARCHAR(15)
	--
	--	NOTE:	Pass in 'A' for new "automated" execution
	--			Default is [M]anual mode...
	-- @exclusionmode - Pass 'M' for migration exclusions, 'R' default = regular exclusion
)

AS
/***************************************************************************************************
** CREATE DATE: 08/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL EXECUTE REQUIRD STEPS FOR COMPILING HRP MHC CLAIM SUBMISSIONS.
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
10/28/12		LOYAL RICKS		REMOVED EXSP_HRP_CLAIM_RESEND procedure call, replaed with 
								EXSP_HRP_CLAIM_EXCLUSION procedure call
03/06/2013		LOYAL RICKS		ADD CATCHALL REQUIRED TABLE TO PROCESS - EXECUTE EXSP_HRP_CLAIM_REQ5010
								REMOVE EXSP_HRP_CLAIM_PROVIDER 
								ADD EXSP_HRP_CLAIM_EDSPROVIDER
07/24/2013		Dwight Staggs	Removed creating of EXT_HRP_CLAIM_EXCLUSION table.  That table is now
								created in the first step of the SSIS Extract Package when the table
								dbo.EDS_AllExtractClaims is built							
09/18/2013		Dwight Staggs	Added @ExecutionMode input parameter for backward compatibility.  The
								default of 'M' executes the same as previously.  When set to 'A', we 
								by-pass creating the EXT_HRP_CLAIM_EXCLUSION table (see 7/24 comments).
								This parameter is also used in the Claim Header SP executed herein.
10/10/2013		Loyal Ricks		Add procedure EXSP_HRP_CLAIM_PROF5010	
11/15/2013		Loyal Ricks		Add input parameter @exclusionmode for main procedure and calling procedure
								EXSP_HRP_CLAIM_EXCLUSION. Parm used by exclusion process to determine 
								whether to execute in migration mode "M" or regular mode "R" default.
11/15/2013		Loyal Ricks		Replace @sourcedatakey parameter with @DATASOURCEKEY for procedure
								EXSP_HRP_CLAIM_EXCLUSION	
05/02/2014		Loyal Ricks		Upgrade mapping from Verisk 3.2 to Verisk 4.0 - EXSP_HRP_CLAIM_MAP_V4	
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation		
09/10/14		Loyal Ricks		EDS-397 - Add sp - pr_BUILD_OUTB_INST_WIPRO_DATASCRUB			
2015-05-29		Loyal Ricks		TETDM-107 Add input parameters @JOBID, @LOBCODE		
								Add input parameters for sp - pr_BUILD_OUTB_MMAI_PROF_CLAIM_HEADER @JOBID,@LOBCODE 	
								Add input parameter for sp - BUILD_OUTB_PROF_MAP @LOB				
06-10-15		Loyal Ricks		Add sp - 	EXECUTE dbo.pr_BUILD_PROF_DME		
07/10/15		Loyal Ricks		Add @LOBCODE to comply with SSIS package requirements supporting all 
								EDS lob. @LOBCODE required for MMAI submissions.	
2015-07-23		Loyal Ricks		TETDM-276 Add JOBID to filedesc			
2015-11-02		Loyal Ricks		Add Pointer realignment procedure for Prof MMAI - EXECUTE dbo.BUILD_OUTB_PROF_DIAG_WIPRO @SOURCEDATAKEY	
2016-04-11		Loyal Ricks		TETDM-667 Add procedure - 	BUILD_OUTB_PROF_AMBULANCEINFO		
2016-04-14		Loyal Ricks		TETDM-732 Replace procedure EXECUTE dbo.BUILD_OUTB_PROF_ADJUSTMENTS with EXECUTE dbo.BUILD_OUTB_PROF_ADJUSTMENTS_WIPRO
								in order to apply code to support MMAI submissions 	
2016-08-17		Loyal Ricks		Add input parameter @JOBID to 	EXECUTE dbo.pr_BUILD_PROF_DME	
2016-09-10		Loyal Ricks		TETDM-988 Professional Denied Claim adjustment added - 	DBO.BUILD_OUTB_PROF_DENIED_ADJUSTMENTS_WIPRO																	    
2018-01-17      JohnBartholomay TETDM-1715 Remove Zero Dollar amount CAS Segments
2018-03-12		Scott Waller	TETDM-1758 creating Generic Claim Resubmission and noticed some mistakes for JobID > 1 processing
*****************************************************************************************************/


	SET NOCOUNT ON;
	
	DECLARE @CatchErrorMessage VARCHAR(2200);
	DECLARE	@TOTAL_RECORDS INT
			,@SOURCEDATAKEY INT
			
	SET @SOURCEDATAKEY = 50; --QNXT


BEGIN TRY
	--HRP_CLAIM_FILE Run controls
	BEGIN TRANSACTION 

	INSERT INTO EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT
			)
	VALUES('pr_EXSP_QNXT_CLAIM'
			,'1'
			,GETDATE()
			,NULL
			,NULL
			,0
			,GETDATE()
			)
	COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY

		--	
		-- Note 
		--6/25 - disable automation steps for initial testing
		--		

		IF @ExecutionMode <> 'A'
		BEGIN
-- TETDM-1758 Scott Waller
			IF @JOBID < 10
				BEGIN
					EXECUTE EXSP_WIPRO_CLAIM_EXCLUSION @sourcedatakey,@exclusionmode
				END
		END

		--IF @ExecutionMode <> 'A'
		--BEGIN
		--	EXECUTE dbo.pr_EXSP_CLAIM_PROF_QNXT_CLMHEADER @ExecutionMode = 'M'
		--END
		--ELSE
		--BEGIN
		--	EXECUTE dbo.pr_EXSP_CLAIM_PROF_QNXT_CLMHEADER @ExecutionMode = 'A'
		--END
		
		EXECUTE dbo.pr_BUILD_OUTB_MMAI_PROF_CLAIM_HEADER @ExecutionMode,@JOBID,@LOBCODE ,@LOB

		EXECUTE dbo.BUILD_OUTB_PROF_CLM_DETAIL

		EXECUTE dbo.BUILD_OUTB_PROF_DIAG_WIPRO @SOURCEDATAKEY

		EXECUTE dbo.BUILD_OUTB_PROF_DIAG_POINTERS

		EXECUTE dbo.BUILD_OUTB_PROF_EDSPROVIDER

		--EXECUTE dbo.BUILD_OUTB_PROF_ADJUSTMENTS
		EXECUTE dbo.BUILD_OUTB_PROF_ADJUSTMENTS_WIPRO
		EXECUTE DBO.BUILD_OUTB_PROF_DENIED_ADJUSTMENTS_WIPRO
		EXECUTE dbo.BUILD_OUTB_PROF_REQ5010
		
		EXECUTE dbo.BUILD_OUTB_PROF_5010
		EXECUTE dbo.BUILD_OUTB_PROF_AMBULANCEINFO
		EXECUTE dbo.pr_BUILD_PROF_DME @JOBID	

		EXECUTE dbo.pr_BUILD_OUTB_PROF_WIPRO_DATASCRUB
		EXECUTE dbo.pr_BUILD_OUTB_PROF_REMOVE_ZERO_CAS_AMTS --TETDM-1715

		EXECUTE dbo.BUILD_OUTB_PROF_MAP @LOB,@LOBCODE,@JOBID

		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY

	SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EXT_HRP_CLAIM)
	SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM EXT_HRP_CLAIM_DETAIL)
									
	----HRP_CLAIM_FILE Update Run Controls
	BEGIN TRANSACTION

	UPDATE EXT_SYS_RUNLOG
	SET END_DT = GETDATE()	
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
		,TOTAL_RECORDS = @TOTAL_RECORDS
		,ENTRYDT = GETDATE()
	WHERE PROC_NAME = 'pr_EXSP_QNXT_CLAIM'
					and END_DT is null
		IF @@ERROR <> 0
					BEGIN 
							ROLLBACK 
					END
	COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH




/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()

BEGIN TRANSACTION

	EXEC [dbo].[pr_EXSP_QNXT_CLAIM]
		@ExecutionMode	= 'M'
		
ROLLBACK TRANSACTION

SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/









