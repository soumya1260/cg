﻿
--(@FILENAME varCHAR(256),
		
CREATE PROCEDURE [dbo].[SUPP_CR_SupportLoad]
(@FILENAME varCHAR(256) = 'Test in SP'
)
AS
/***************************************************************************************************
** CREATE DATE: 07/2021
**
** AUTHOR: Henry faust
**
** DESCRIPTION: 
**              
**              
**               
**
**
**/
			DECLARE
			
			@TOTAL_RECORDS INT

DECLARE @CursorTestID INT = 1;
DECLARE @RunningTotal BIGINT = 0;
DECLARE @RowCnt BIGINT = 0;
declare @Seg varchar(max),
        @ele varchar(250) = '';
declare
		@Recnum varchar(5) = '',
		@enum int = 0,
		@elmsep varchar(1) = '	'
declare @x int = 0, @y int = 0

declare
 	@mem_id varchar(16) ,
	@medicare_no varchar(20) ,
	@plan varchar(5) ,
	@prov_type varchar(2) ,
	@dos_dt varchar(8) ,
	@dos_thru_dt varchar(8) ,
	@diagnosis_code varchar(10) ,
	@clm_no varchar(20) ,
	@clm_source varchar(30) ,
	@icd_version varchar(50) ,
	@error_flag varchar(50) ,
	@error_description varchar(50) ,
	@provider_ID varchar(10) ,
	@file_name varchar(100)  = @FILENAME,
	@load_date date 


--###############################################################################################

	IF OBJECT_ID('TEMPDB..#SUPP_CR_SUPPORTING') <> 0
		DROP TABLE #SUPP_CR_SUPPORTING
	
	CREATE TABLE #SUPP_CR_SUPPORTING
	(
		[mem_id] [varchar](16) NULL,
	[medicare_no] [varchar](20) NULL,
	[plan] [varchar](5) NULL,
	[prov_type] [varchar](2) NULL,
	[dos_dt] [varchar](8) NULL,
	[dos_thru_dt] [varchar](8) NULL,
	[diagnosis_code] [varchar](10) NULL,
	[clm_no] [varchar](20) NULL,
	[clm_source] [varchar](30) NULL,
	[icd_version] [varchar](50) NULL,
	[error_flag] [varchar](50) NULL,
	[error_description] [varchar](50) NULL,
	[provider_ID] [varchar](10) NULL,
	[file_name] [varchar](100) NULL,
	[load_date] [date] NULL

	)
CREATE NONCLUSTERED INDEX [IDX_SUPP_CR_SUPPORTING] ON #SUPP_CR_SUPPORTING
(
	
	[clm_no] ASC,
	[error_flag] ASC,
	[error_description] ASC
)




--############################################################################################

-- get a count of total rows to process 
select @RowCnt = COUNT(0) FROM [WIPRO].[staging].[Raw_supp_cr];
-- set @Seg = (select left(segment,10) from staging.RawSegments where segnum = 1)
 
WHILE @CursorTestID <= @RowCnt
BEGIN
   set @Seg = (select comfile from [WIPRO].[staging].[Raw_supp_cr] where segnum = @CursorTestID)
--select  @Seg, @CursorTestID
------------------------------------------------------------------------
------------------------------------------------------------------------
	   begin

  set @Seg = @Seg + '	' -- add element seperator to the end of string for old format

 		  set @x = 0
		  set @y = 0
	      set @enum = 0
				 set @x = charindex(@elmsep,@seg, @x)
				 set @mem_id = substring(@Seg,1, @x)	   
				-- select @enum ,@x, @y,  @ele
				  
		  while @enum < 12
		    begin 
				 set @x = charindex(@elmsep,@seg, @x)
				 set @y = charindex(@elmsep,@seg,@x+1)
				 set @ele = substring(@Seg,@x+1, @y-@x-1)
					if @enum = 0 set @medicare_no = @ele;
					if @enum = 1 set  @plan= @ele;
					if @enum = 2 set @prov_type = @ele;
					if @enum = 3 set  @dos_dt = @ele;
					if @enum = 4 set  @dos_thru_dt= @ele;
					if @enum = 5 set  @diagnosis_code = @ele;
					if @enum = 6 set  @clm_no= @ele;
					if @enum = 7 set  @clm_source= @ele;
					if @enum = 8 set  @icd_version= @ele;
					if @enum = 9 set  @error_flag = case when @ele = 'Y' then '1'
					                                 when @ele = 'N' then '0'
					                                 when @ele = '0' then '0'
					                                 when @ele = '1' then '1'
              					                       else '0' end;
					if @enum = 10 set @error_description = @ele;
					if @enum = 11 set @provider_ID = @ele;
			        
				-- select @enum ,@x, @y,  @ele
				 set @enum = @enum +1
				 set @x = @y
             end -- While

set @load_date =   getdate()
insert into #SUPP_CR_SUPPORTING
select @mem_id , @medicare_no, @plan,  @prov_type,@dos_dt,@dos_thru_dt 
      ,@diagnosis_code,@clm_no,  @clm_source, @icd_version,@error_flag
	  ,@error_description, @provider_ID ,@file_name, @load_date
           
        end
----------------------------------------------------------------------------------------------------------------------------


   SET @CursorTestID = @CursorTestID + 1 
   --if  @CursorTestID >1 
   --     break;
END
insert into [WIPRO].[staging].[SUPP_CR_SUPPORTING]
   select * from #SUPP_CR_SUPPORTING
 

