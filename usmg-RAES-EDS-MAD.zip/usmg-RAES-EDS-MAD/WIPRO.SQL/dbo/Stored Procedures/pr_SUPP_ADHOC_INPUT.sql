﻿CREATE PROCEDURE dbo.pr_SUPP_ADHOC_INPUT
/******************************************
Creation Date 7/24/2019
Author: ASU
Loads "SUPP_ADHOC_INPUT" items into Supplemental_Input

Notes:
10/28/2019 TETDM-2131
	Added: 	 ChartChase_NPI = COALESCE(NULLIF(sai.provider_npi,''), scs.provider_ID),
	Removed: 	ChartChase_NPI = scs.provider_ID,
05/08/2023 RETM-235
	Updated to include TaxID and PCPID
	
*/
AS

SET NOCOUNT ON;
SET ANSI_NULLS ON;

--Supp_Adhoc_Input pull
IF OBJECT_ID('tempdb.dbo.#Raw_Pull') IS NOT NULL
	DROP TABLE #Raw_Pull;

CREATE TABLE #Raw_Pull
(
	Plan_no VARCHAR(5),
	HicNo VARCHAR(20),
	X_HICN VARCHAR(12),
	X_MBI VARCHAR(11),
	MemberID VARCHAR(16),
	From_Date date,
	Thru_Date DATE,
	Provider_Type VARCHAR(2),
	DxCode VARCHAR(10),
	icdversion INT,
	SourceSystem VARCHAR(20),
	SourceSystemNumber VARCHAR(20),
	SourceType VARCHAR(200),
	Patient_Control_No VARCHAR(70),
	DOS_YR VARCHAR(4),
	Linked_Claim_number VARCHAR(20),
	WIPRO_CLAIM_NO VARCHAR(20),
	CHS_CLM_EDPS VARCHAR(20),
	CMS_ICN VARCHAR(20),
	Supp_Type VARCHAR(20),
	[Data_Source] VARCHAR(25),
	DocumentProvID VARCHAR(20),
	ChartProv VARCHAR(20),
	ChartChase_NPI VARCHAR(20),
	EXCL_ID VARCHAR(2),
	Status_Code VARCHAR(3) DEFAULT '000',
	Status_desc VARCHAR(20) DEFAULT 'New_Claims',
	Process_Date DATE,
	Last_Modified_Date DATE,
	PCP_ID VARCHAR(50),
	NPI_Source VARCHAR(50),
	Input_File_Name VARCHAR(150),
	Tax_ID VARCHAR(50)
);

CREATE CLUSTERED INDEX idx_RP
ON #Raw_Pull
(MemberID, PCP_ID)
WITH (PAD_INDEX = ON, FILLFACTOR = 98);



DECLARE @Process_Date DATE = GETDATE(),
		@Load_Key DATE = (SELECT MAX(sai1.Load_dt) FROM WIPRO.dbo.SUPP_ADHOC_INPUT sai1); --need to add a load key to this table

WITH monthly_member AS ( --get subset of member data for below and cast dates from INTs for DATE to DATE compare
	SELECT DISTINCT
		mmd.MemberID,
		mmd.MedicareID,
		mmd.HCFACode,
		BeginCoverageDateKey_Convert = TRY_CAST(TRY_CAST(mmd.BeginCoverageDateKey AS VARCHAR(8)) AS DATE),
		EndCoverageDateKey_Convert = TRY_CAST(TRY_CAST(mmd.EndCoverageDateKey AS VARCHAR(8)) AS DATE),
		mmd.PCPID
	FROM EDPS_Data.dbo.MonthlyMembershipDim mmd
	WHERE 1 = 1
		AND (mmd.HCFACode NOT LIKE 'S%' AND mmd.HCFACode != '-----' AND mmd.HCFACode IS NOT NULL)
		AND EXISTS (SELECT * FROM WIPRO.dbo.SUPP_ADHOC_INPUT srcd WHERE srcd.mem_id = mmd.MemberID AND srcd.Load_dt = @Load_Key)
),
source_type AS ( --get distinct source types
	SELECT DISTINCT
		srsdt.SourceDesc
	   ,srsdt.Type
	FROM WIPRO.dbo.SUPP_RAPS_Source_Desc_Type srsdt
	WHERE EXISTS (SELECT * FROM WIPRO.dbo.SUPP_ADHOC_INPUT srcd WHERE srcd.clmsource = srsdt.SourceDesc AND srcd.Load_dt = @Load_Key)
)
INSERT INTO #Raw_Pull (	Plan_no, HicNo, MemberID, From_Date, Thru_Date,
						Provider_Type, DxCode, icdversion, SourceSystem, SourceSystemNumber, 
						SourceType, Patient_Control_No, DOS_YR, Data_Source, ChartChase_NPI, 
						Process_Date, Last_Modified_Date, Input_File_Name, NPI_Source,
						PCP_ID)
SELECT
	Plan_No = sai.hplan,
	HicNo = sai.medicare_no,
	MemberID = sai.mem_id,
	From_Date = TRY_CAST(sai.dos_dt AS DATE),
	Thru_Date = TRY_CAST(sai.dos_thru_dt AS DATE),
	Provider_Type = sai.prov_type,
	DxCode = sai.diagnosis_code,
	icdversion = sai.icdversion,
	SourceSystem = sai.clmsource,
	SourceSystemNumber = sai.clm_no,
	SourceType = srsdt.[Type],
	Patient_Control_No = CONCAT(sai.mem_id, '-', sai.clmsource, '-',sai.clm_no),
	DOS_YR = LEFT(sai.dos_thru_dt,4),
	[DATA_SOURCE] = 'SUPP_ADHOC_INPUT',
	ChartChase_NPI = COALESCE(NULLIF(sai.provider_npi,''), scs.provider_ID), 
	Process_Date = @Process_Date,
	Last_Modified_Date = @Process_Date,	
	Input_File_Name = sai.filename,
	NPI_Source = CASE 
                 	WHEN NULLIF(sai.provider_npi,'') IS NOT NULL THEN 'Vendor_File'
                 	WHEN scs.provider_ID IS NOT NULL THEN 'COGnizant_SUPPORTING_FILE'
                 	ELSE NULL
                 END,
	PCP_ID = NULLIF(mm.PCPID,'')
FROM WIPRO.dbo.SUPP_ADHOC_INPUT sai
LEFT JOIN source_type srsdt
	ON sai.clmsource = srsdt.SOURCEDESC
LEFT JOIN WIPRO.dbo.SUPP_CR_SUPPORTING scs
	ON sai.mem_id = scs.mem_id
		AND sai.medicare_no = scs.medicare_no
		AND sai.dos_thru_dt = scs.dos_thru_dt
		AND sai.clm_no = scs.clm_no
LEFT JOIN monthly_member mm
	ON sai.mem_id = mm.MemberID
		AND TRY_CAST(sai.dos_dt AS DATE) >= mm.BeginCoverageDateKey_Convert
		AND TRY_CAST(sai.dos_thru_dt AS DATE) <= mm.EndCoverageDateKey_Convert
WHERE sai.Load_dt = @Load_Key;


/**************************************
get npi data for use later
use NPI check function to validate NPI
***************************************/
IF OBJECT_ID('tempdb.dbo.#NPI_Source') IS NOT NULL
	DROP TABLE #NPI_Source;

SELECT
	Provider_ID = cp.ProviderID,
	NPI = cp.ProviderNPI,
	NPI_Source = 'PCPID'
INTO #NPI_Source
FROM EDPS_Data.dbo.Common_Provider cp
CROSS APPLY (SELECT * FROM WIPRO.dbo.fn_NPI_Calculate_Check_Digit_Luhn(cp.ProviderNPI)) fnccdl
WHERE 1 = 1
	AND fnccdl.CheckDigit = TRY_CAST(RIGHT(cp.ProviderNPI, 1) AS INT)
	AND fnccdl.CheckDigit IS NOT NULL
	AND EXISTS (	SELECT * 
					FROM #Raw_Pull rp 
					WHERE 1 = 1
						AND rp.PCP_ID = cp.ProviderID
						AND rp.PCP_ID IS NOT NULL
						AND rp.ChartChase_NPI IS NULL)
UNION
SELECT
	Provider_ID = pd.ProviderID,
	pd.NPID,
	NPI_Source = 'PCPID'
FROM EDPS_Data.dbo.ProviderDim pd
CROSS APPLY (SELECT * FROM WIPRO.dbo.fn_NPI_Calculate_Check_Digit_Luhn(pd.NPID)) fnccdl
WHERE 1 = 1
	AND fnccdl.CheckDigit = TRY_CAST(RIGHT(pd.NPID, 1) AS INT)
	AND fnccdl.CheckDigit IS NOT NULL
	AND pd.ProviderStatus = 'active'
	AND EXISTS (	SELECT * 
					FROM #Raw_Pull rp 
					WHERE 1 = 1
						AND rp.PCP_ID = pd.ProviderID
						AND rp.PCP_ID IS NOT NULL
						AND rp.ChartChase_NPI IS NULL)
/************************************************
Go back and update ChartChase_NPI and NPI_Source
based on PCP_ID populated above
*************************************************/
CREATE CLUSTERED INDEX idx_npi_source ON #NPI_Source (Provider_ID, NPI);

UPDATE RP
SET RP.ChartChase_NPI = COALESCE(ns.NPI, ns1.NPI, ns2.NPI),
	RP.NPI_Source = COALESCE(ns.NPI_Source, ns1.NPI_Source, ns2.NPI_Source)
FROM #Raw_Pull RP
LEFT JOIN #NPI_Source ns
	ON RP.DocumentProvID = ns.Provider_ID
LEFT JOIN #NPI_Source ns1
	ON RP.ChartProv = ns1.Provider_ID
LEFT JOIN #NPI_Source ns2
	ON RP.PCP_ID = ns2.Provider_ID
WHERE RP.ChartChase_NPI IS NULL;


/********************
end npi data gather
*********************/

/*******************
Update Tax ID
********************/

WITH Taxes AS ( --check IngenixProviderDim first
	SELECT DISTINCT
		ipd.NPI,
		ipd.TaxID
	FROM MDQOLib.dbo.IngenixProviderDim ipd
	WHERE 1 = 1
		AND EXISTS (SELECT * FROM #Raw_Pull rp WHERE rp.ChartChase_NPI = ipd.NPI)
		AND NULLIF(ipd.TaxID, 'UNKNOWN') IS NOT NULL
)
UPDATE RP
SET Tax_ID = T.TaxID
FROM #Raw_Pull RP
JOIN Taxes T 
	ON RP.ChartChase_NPI = T.NPI;

WITH Taxes AS (
	SELECT
		pd.NPID,
		Tax_ID = SUBSTRING(LTRIM(RTRIM(pd.FIDN)),1,9)
	FROM EDPS_Data.dbo.ProviderDim pd
	WHERE 1 = 1
		AND EXISTS (SELECT * FROM #Raw_Pull rp WHERE rp.ChartChase_NPI = pd.NPID)
		AND (NULLIF(pd.FIDN,'') IS NOT NULL OR  pd.FIDN NOT IN ('0000','9999','UNKNOWN'))
		AND pd.ProviderStatus = 'Active'
	UNION
	SELECT
		epd.ProviderNPI,
		SUBSTRING(LTRIM(RTRIM(epd.FederalTaxID)),1,9)
	FROM EDPS_Data.dbo.EncounterProviderDim epd
	WHERE 1 = 1
		AND EXISTS (SELECT * FROM #Raw_Pull rp WHERE rp.ChartChase_NPI = epd.ProviderNPI)
		AND (NULLIF(epd.FederalTaxID,'') IS NOT NULL OR epd.FederalTaxID NOT IN ('0000','9999','UNKNOWN'))
)
UPDATE RP
SET Tax_ID = T.Tax_ID
FROM #Raw_Pull RP
JOIN Taxes T
	ON RP.ChartChase_NPI = T.NPID
WHERE RP.Tax_ID IS NULL; --update where not found (or null) in prior tax ID update


INSERT INTO WIPRO.dbo.Supplemental_INPUT 
	(	Plan_No, Hic_No, Member_ID, From_Date, Thru_Date, Provider_Type,
		Dx_Code, icd_version, Source_System, Source_System_Number, Source_Type, Patient_Control_No,
		DOS_YR, Linked_Claim_number, WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type, Data_Source,
		Document_Prov_ID, Chart_Prov, Chart_Chase_NPI, Status_Code, Status_desc, Process_Date, Last_Modified,
		Input_File_Name, Tax_ID, PCP_ID, NPI_Source)
	SELECT 
		rp.Plan_no
	   ,rp.HicNo
	   ,rp.MemberID
	   ,rp.From_Date
	   ,rp.Thru_Date
	   ,rp.Provider_Type
	   ,rp.DxCode
	   ,rp.icdversion
	   ,rp.SourceSystem
	   ,rp.SourceSystemNumber
	   ,rp.SourceType
	   ,rp.Patient_Control_No
	   ,rp.DOS_YR
	   ,rp.Linked_Claim_number
	   ,rp.WIPRO_CLAIM_NO
	   ,rp.CHS_CLM_EDPS
	   ,rp.CMS_ICN
	   ,rp.Supp_Type
	   ,rp.Data_Source
	   ,rp.DocumentProvID
	   ,rp.ChartProv
	   ,rp.ChartChase_NPI
	   ,rp.Status_Code
	   ,rp.Status_desc
	   ,rp.Process_Date
	   ,rp.Last_Modified_Date
	   ,rp.Input_File_Name
	   ,rp.Tax_ID
	   ,rp.PCP_ID
	   ,rp.NPI_Source
	FROM #Raw_Pull rp
	EXCEPT --just here in case procedure is run multiple times with same dataset
	SELECT
		Plan_No
	   ,Hic_No
	   ,Member_ID
	   ,From_Date
	   ,Thru_Date
	   ,Provider_Type
	   ,Dx_Code
	   ,icd_version
	   ,Source_System
	   ,Source_System_Number
	   ,Source_Type
	   ,Patient_Control_No
	   ,DOS_YR
	   ,Linked_Claim_number
	   ,WIPRO_CLAIM_NO
	   ,CHS_CLM_EDPS
	   ,CMS_ICN
	   ,Supp_Type
	   ,Data_Source
	   ,Document_Prov_ID
	   ,Chart_Prov
	   ,Chart_Chase_NPI
	   ,Status_Code
	   ,Status_desc
	   ,Process_Date
	   ,Last_Modified
	   ,Input_File_Name
	   ,Tax_ID
	   ,si.PCP_ID
	   ,si.NPI_Source
	FROM WIPRO.dbo.Supplemental_INPUT si;

IF OBJECT_ID('tempdb.dbo.#Raw_Pull') IS NOT NULL
	DROP TABLE #Raw_Pull;

SET NOCOUNT OFF;


/***************************************************************************************
----------------------------------------------------------------------------------------
****************************************************************************************/
