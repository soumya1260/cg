﻿
CREATE PROCEDURE [dbo].[Retraction_Diag_Overlay_Build]
AS
/***************************************************************************************************
** CREATE DATE: 01/25/2003
**
** AUTHOR: Aaron Ridley
**
** DESCRIPTION: This procedure has been created to readh the Adhoc Input Tracking table, housing requested retractions.
**              Diagnosis Codes that are not present in this table are written to newly created DiagnosisCode Overlay tables.
**              The Diagnosis Code overlay tables will subsequently be utilized in place of the source EDPS_Data Diag tables for 
**              Retraction data submission.
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------*/
	--DECLARE VARIABLES

			DECLARE
			
			@TOTAL_RECORDS INT
		


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('Retraction_Diag_Overlay_Build'
				,'1'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)

/*----------------------------------------------------------------------------------------------
              Temporary Table Preparation 
*/----------------------------------------------------------------------------------------------
IF OBJECT_ID('tempdb.dbo.#cleaned_diag') IS NOT NULL
	DROP TABLE #cleaned_diag;

IF OBJECT_ID('tempdb.dbo.#cleaned_diag_final') IS NOT NULL
	DROP TABLE #cleaned_diag_final;

IF OBJECT_ID('tempdb.dbo.#clm_diag_detail_dim_final') IS NOT NULL
	DROP TABLE #clm_diag_detail_dim_final;

/*-------------------------------------------------------------------------------------------------------------
Get general match of claims to scan strip period from diag code (for join later) get count of diags removed
add blank column for sequence shift start
*/----------------------------------------------------------------------------------------------------------------
SELECT
	c.CLAIMID
   ,c.DIAGNOSISCODE
   ,CLEANED_DIAGNOSISCODE = REPLACE(c.DIAGNOSISCODE,'.','')
   ,c.DIAGNOSISTYPECODE
   ,c.DIAGNOSISDESC
   ,c.SEQUENCE
   ,c.POAIND
   ,c.SourceDataKey
   ,c.DiagnosisCodeVersion
   ,c.LoadDateKey
   ,c.Active 
   ,c.Deleted 
   ,c.EnterpriseID 
   ,c.DiagnosisTypeCodeDesc 
   ,CLM_TYPE = (SELECT CLM_TYPE FROM Adhoc_Input_Tracking ait1 WHERE ait1.claim_id = c.claimid GROUP BY CLM_TYPE)
INTO #cleaned_diag
FROM EDPS_Data.dbo.CLAIMDIAGNOSISDIM c
WHERE 1 = 1
	AND c.DIAGNOSISTYPECODE IN ('P','S','V','T','A') --Only take type of P or S, others do not matter
	AND EXISTS (SELECT
					*
				FROM dbo.Adhoc_Input_Tracking ait
				WHERE  ait.CLAIM_ID = c.CLAIMID);


CREATE NONCLUSTERED INDEX idx_dxtype
ON #cleaned_diag (CLAIMID)
INCLUDE (CLEANED_DIAGNOSISCODE);


/*-----------------------------------------------------------------------------------
shift sequence based on new order minus diags from adhoc tracking table
*/-----------------------------------------------------------------------------------

SELECT 
    cd.CLAIMID
   ,cd.DIAGNOSISCODE
   ,cd.CLEANED_DIAGNOSISCODE
   ,DIAGNOSISTYPECODE = CASE 
                        	WHEN (ROW_NUMBER() OVER (PARTITION BY CLAIMID ORDER BY CAST(cd.SEQUENCE AS INT)) - 1) = 0
								THEN 'P'
                        	ELSE cd.DIAGNOSISTYPECODE
                        END
   ,cd.DIAGNOSISDESC
   ,CURRENT_Sequence = cd.SEQUENCE
   ,New_Sequence = 
		REPLACE(FORMAT(ROW_NUMBER() OVER (PARTITION BY CLAIMID ORDER BY CAST(cd.SEQUENCE AS INT)) - 1,'0#'),'00','01')
   ,cd.POAIND
   ,cd.SourceDataKey
   ,cd.DiagnosisCodeVersion
   ,cd.LoadDateKey
   ,cd.Active 
   ,cd.Deleted 
   ,cd.EnterpriseID 
   ,cd.DiagnosisTypeCodeDesc 
INTO #cleaned_diag_final
FROM #cleaned_diag cd
WHERE 1 = 1
	AND NOT EXISTS (	SELECT 
							* 
						FROM  dbo.Adhoc_Input_Tracking ait
						WHERE 1 = 1
							AND ait.CLAIM_ID = cd.CLAIMID
							AND ait.DIAGNOSIS_CODE = cd.CLEANED_DIAGNOSISCODE)
ORDER BY cd.claimid, CAST(cd.SEQUENCE AS INT);

/*--------------------------------------------------------------------------------
* Insert newly sequenced diagnosis codes into the Diag Overlay table 
*/--------------------------------------------------------------------------------------
INSERT INTO WIPRO.dbo.CLAIMDIAGNOSISDIM_OVERLAY
SELECT CLAIMID, CLEANED_DIAGNOSISCODE, DIAGNOSISTYPECODE, DIAGNOSISDESC, [New_Sequence], POAIND, SOURCEDATAKEY, DIAGNOSISCODEVERSION 
   ,LoadDateKey
   ,Active 
   ,Deleted 
   ,EnterpriseID 
   ,DiagnosisTypeCodeDesc  
 FROM #cleaned_diag_final; 

 /*---------------------------------------------------------------------------------
 *   Post Diagnpsis table Syslog Updates 
 */---------------------------------------------------------------------------------

 SET @TOTAL_RECORDS = (SELECT COUNT(DISTINCT(CLAIMID)) FROM #cleaned_diag_final);

 --HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('Retraction_Diag_Overlay_Build_DiagDim'
				,'1'
				,GETDATE()
				,NULL
				,NULL
				,@TOTAL_RECORDS
				,GETDATE()
				)

SET @TOTAL_RECORDS = 0;

/*setup for detail moc*/
IF OBJECT_ID('tempdb.dbo.#rough_clm_diag_detail_dim') IS NOT NULL
	DROP TABLE #rough_clm_diag_detail_dim;


SELECT
*
,CLEANED_DIAGNOSISCODE = REPLACE(c.DIAGNOSISCODE,'.','')
INTO #rough_clm_diag_detail_dim
FROM EDPS_Data.dbo.CLAIMDETAILDIAGNOSISDIM c
WHERE EXISTS (SELECT
				*
			  FROM #cleaned_diag cd
			  WHERE 1 = 1
				AND c.CLAIMID = cd.claimid
				AND CLM_TYPE = 'P');


SELECT
	c.CLAIMID
   ,c.SOURCEDATAKEY
   ,c.CLAIMDETAILDIAGNOSISKEY
   ,c.CLAIMLINEID  
   ,c.DIAGNOSISCODE
   ,c.CLEANED_DIAGNOSISCODE
   ,c.SEQUENCE
   ,New_SEQUENCE = ROW_NUMBER() OVER (PARTITION BY CLAIMID, CLAIMLINEID ORDER BY CAST(c.SEQUENCE AS INT))  
   ,c.ACTIVE
   ,c.DELETED
   ,c.LOADDATEKEY
   ,c.ENTERPRISEID
   ,c.DiagnosisCodeVersion   
into #clm_diag_detail_dim_final 
FROM #rough_clm_diag_detail_dim c
	WHERE 1 = 1
		AND NOT EXISTS (	SELECT 
							* 
							FROM  dbo.Adhoc_Input_Tracking ait
							WHERE 1 = 1
								AND ait.CLAIM_ID = c.CLAIMID
								AND ait.DIAGNOSIS_CODE = c.CLEANED_DIAGNOSISCODE)
ORDER BY CLAIMID, CAST(CLAIMLINEID AS INT), SEQUENCE;

/****
	INITIAL RESEQUENCED POPULATION OF DETAIL DIAGNOSIS CODE TABLE
*/ 

INSERT INTO WIPRO.dbo.CLAIMDETAILDIAGNOSISDIM_OVERLAY
SELECT CLAIMID, SOURCEDATAKEY, CLAIMDETAILDIAGNOSISKEY, CLAIMLINEID, CLEANED_DIAGNOSISCODE, [New_Sequence], ACTIVE, DELETED, LOADDATEKEY, ENTERPRISEID, DIAGNOSISCODEVERSION 
 FROM #clm_diag_detail_dim_final; 

/****
	DETAIL DIAGNOSIS TABLE BACKFILL USED WHEN THE PRIMARY DIAG IS REMOVED 
*/ 
INSERT INTO WIPRO.dbo.CLAIMDETAILDIAGNOSISDIM_OVERLAY
SELECT 
DISTINCT A.CLAIMID, A.SourceDataKey, 0 AS CLAIMDETAILDIAGNOSISKEY, '0001' AS CLAIMLINEID, A.DIAGNOSISCODE, 1 AS SEQUENCE , '1' AS ACTIVE, '0' AS DELETED, A.LoadDateKey, A.EnterpriseID, A.DiagnosisCodeVersion
FROM WIPRO.dbo.CLAIMDIAGNOSISDIM_OVERLAY A 
LEFT JOIN WIPRO.dbo.CLAIMDETAILDIAGNOSISDIM_OVERLAY B ON A.CLAIMID = B.CLAIMID 
WHERE A.DIAGNOSISTYPECODE = 'P' AND B.CLAIMID IS NULL;

 /*---------------------------------------------------------------------------------
 *   Post Detail Diagnosis table Syslog Updates 
 */---------------------------------------------------------------------------------

 SET @TOTAL_RECORDS = (SELECT COUNT(DISTINCT(CLAIMID)) FROM #clm_diag_detail_dim_final);

 --HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('Retraction_Diag_Overlay_Build_DetailDiagDim'
				,'1'
				,GETDATE()
				,NULL
				,NULL
				,@TOTAL_RECORDS
				,GETDATE()
				)

UPDATE EXT_SYS_RUNLOG
SET END_DT = GETDATE()	
	,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
	,ENTRYDT = GETDATE()
WHERE PROC_NAME = 'Retraction_Diag_Overlay_Build'
		AND END_DT IS NULL;

UPDATE EXT_SYS_RUNLOG
SET END_DT = GETDATE()	
	,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
	,ENTRYDT = GETDATE()
WHERE PROC_NAME = 'Retraction_Diag_Overlay_Build_DiagDim'
		AND END_DT IS NULL;

UPDATE EXT_SYS_RUNLOG
SET END_DT = GETDATE()	
	,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
	,ENTRYDT = GETDATE()
WHERE PROC_NAME = 'Retraction_Diag_Overlay_Build_DetailDiagDim'
		AND END_DT IS NULL;

/*------------------------------------------------------------------
*                END
*/------------------------------------------------------------------