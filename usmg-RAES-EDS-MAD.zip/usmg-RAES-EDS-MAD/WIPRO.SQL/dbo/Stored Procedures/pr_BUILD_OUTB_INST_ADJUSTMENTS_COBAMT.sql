﻿create  PROCEDURE [dbo].[pr_BUILD_OUTB_INST_ADJUSTMENTS_COBAMT]
AS
/****************************************************************************************************************************************************
** CREATE DATE: 06/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM LINE 
**              ADJUSTMENT SEGMENTS (CAST SEGMENTS) INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------

11/09/12		LOYAL RICKS     MOVE DEDUCTIBLE ADJUSTMENT FROM GRP131 TO GRP 122
11/19/12		LOYAL RICKS		REVISED ADJUSTMENTS ALIGNING SEGEMENTS WITH APPROPRIATE GROUP CODE
11/27/12		LOYAL RICKS		REVISED USE OF TEMPDB, RENAME #INST_#INST_TMP TO #INST_#INST_TMPDEV TO ALLOW FOR MULTIPLE
								PROCESSING IN EDPS & EDPS_PROD
04/10/13		LOYAL RICKS		REMOVE ADJUSTMENT - CLM_ADJ_GRP12 = 'OA',CLM_ADJ_REASON121 = '94'
								ADD ADJUSTMENT - CLM_ADJ_GRP12 = 'CO',CLM_ADJ_REASON121 = '94' 
								OA (OVER PAYMENT) ADJUSTMENTS 
04/11/13		LOYAL RICKS		REVISE CLM_ADJ_GRP111 = 'CO',CLM_ADJ_REASON111 = '45' ADJUSTMENT SEG
								TO INCLUDE ADJUSTMENT FOR SPECIFIC NON CAP LINE
								Adjust GRP111 loop for conditional submission of Reason111 '45' and
								Reason112 '94'
05/14/13		Loyal Ricks		Add CLM_ADJ_GRP111 = 'CO',CLM_ADJ_REASON111 = '45' logic for Facets
06/03/13		Loyal Ricks		Add logic to ensure Member_Amt_paid is never populated on claim header
6/24/14			Loyal Ricks		Added evaluation for capitated line. Missing logic causing 103 edits when there is cap line. W/o logic outbound
								claim line is being submitted with both a CO-45 and CR-223. Lines should only contain CR-223 when capped. Additional 
								logic will ensure CO-45 (Contract Obligation) is not present for capitated line
07/03/14		Loyal Ricks		03/13/14 Sequestration - Add logic to CAS segment (Verisk Adj - CO) 
10/06/14		Loyal Ricks		Shift Adjustment Group 111-113 to allow adjustments to fall in order instead by Reason code due to WIPRO requirement
									•	EDS-437	•	EDS-442 •	EDS-443
06/22/15		Loyal Ricks		Adjustment amount formatting left trim - adjust amounts - CLM_ADJ_AMT111,CLM_ADJ_AMT112,CLM_ADJ_AMT113
*****************************************************************************************************************************************************/	
	--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM OUTB_INST_DETAIL_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT
		


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_INST_ADJUSTMENTS'
				,'7'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)


					IF OBJECT_ID('TEMPDB..#INST_TMPDEV_CLMCAP') <> 0
							DROP TABLE #INST_TMPDEV_CLMCAP
		
							Create Table #INST_TMPDEV_CLMCAP
 							(CLAIMID VARCHAR(20),
							 CLAIMLINEID VARCHAR(5),
							 CAP_AMT MONEY,
							 QUANTITY INT
							 )

				--UPDATE CLM_ADJ_GRP5 INFORMATION - PROVIDER CAPITATION
				--CALCULATE CAPITATED AMOUNT
				--USE ALSO TO DETERMINE WHETHER CLM_ADJ_GRP1 'CO' SHOULD BE POPULATED
				INSERT INTO #INST_TMPDEV_CLMCAP
				SELECT CLAIMID,CLAIMLINEID,SUM(CD.RequestedAmt - CD.PAYMENTAMOUNT - CD.COBAMT - CD.DEDUCTIBLEAMT - CD.COPAYAMT - CD.COINSURANCEAMT) as 'CAP_AMT',Quantity
				--INTO  #INST_TMPDEV_CLMCAP
				FROM EDPS_Data.dbo.claimdetaildim CD
				INNER JOIN OUTB_INST_HEADER IH
				ON CD.SOURCEDATAKEY = IH.SOURCEDATAKEY 
				AND CD.CLAIMID = IH.CLAIM_ID 
				WHERE CAPITATEDLINEFLAG = 'Y'
					--AND ClaimID IN (SELECT CLAIM_ID FROM OUTB_INST_HEADER)
				GROUP BY ClaimID,ClaimLineID,Quantity

	--UPDATE CLM_ADJ_GRP1 INFORMATION - CONTRACT ADJUSTMENT
	--REVISED LOGIC 7/5/12 BASED ON HRP CALL. CO AMOUNT SHOULD EQUAL CONTRACTED WRITE OFF AMOUNT
	--POTENTIAL FIX LOGIC REMOVED DUE TO EMAIL FROM K.DEHNKE VALIDATING THE USE OF MAXFEEAMT
	--POTENTIAL FIX LOGIC WAS --LTRIM(RequestedAmt - MAXFEEAMT - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt)
	--ADJUSTED BACK TO ORIGINAL LOGIC FROM 6/15
	--7/19/13 ADD CHECK TO ONLY APPLY UPDATE WHEN CLAIM IS NOT CAPITATED
	--6/24/14 Added evaluation for capitated line. Missing logic causing 103 edits when there is cap line. W/o logic outbound
	--	claim line is being submitted with both a CO-45 and CR-223. Lines should only contain CR-223 when capped. Additional 
	--logic will ensure CO-45 (Contract Obligation) is not present for capitated line
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 = 'CO'
					,CLM_ADJ_REASON111 = '45'
					,CLM_ADJ_AMT111 = LTRIM(RequestedAmt - PaymentAmount -  CoInsuranceAmt - DeductibleAmt - CoPayAmt)
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY111 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				JOIN EDPS_Data.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND  CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE ((RequestedAmt - PaymentAmount - CoInsuranceAmt - DeductibleAmt - CoPayAmt) > 0  and COBAmt = 0 )
						--and CONTRACT_type <> '05'
						and cd.CAPITATEDLINEFLAG <> 'Y'
						--AND rtrim(CLAIM_ID)+''+rtrim(CLAIM_LINE_NO) NOT IN (SELECT rtrim(ClaimID)+''+rtrim(CLAIMLINEID) FROM #INST_TMPDEV_CLMCAP)
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				----FACETS CO-45 ADJUSTMENT
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 = 'CO'
					,CLM_ADJ_REASON111 = '45'
					,CLM_ADJ_AMT111 = LTRIM(RequestedAmt - PaymentAmount - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt)
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY111 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN EDPS_Data.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE ((RequestedAmt - PaymentAmount - COBAmt - CoInsuranceAmt - DeductibleAmt - CoPayAmt) > 0 and COBAmt = 0 )
				AND		EC.SOURCEDATAKEY IN ('30')
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				-----OTHER ADJUSTMENTS - WHEN TOTAL PAID AMOUNTS EXCEED TOTAL CHARGES
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 = 'CO'
					,CLM_ADJ_REASON112 = '94'
					,CLM_ADJ_AMT112 = LTRIM(RequestedAmt - (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)) 
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY112 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN EDPS_Data.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE RequestedAmt < (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				
				 update OUTB_INST_DETAIL
				set CLM_ADJ_AMT112 = LTRIM(convert(money,CLM_ADJ_AMT112) * -1)
				 from OUTB_INST_DETAIL
				where CLM_ADJ_AMT112 <> ' '
				/*		REMOVED 4/10/13 OA ARE NOT OVER PAYMENT, THEY ARE CONTRACTED AMOUNTS	
							BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = 'OA'
					,CLM_ADJ_REASON121 = '94'
					,CLM_ADJ_AMT121 = LTRIM(RequestedAmt - (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt))
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY121 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				JOIN EDPS_Data.dbo.claimdetaildim CD
				ON CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE RequestedAmt < (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)
				IF @@ERROR <> 0
					BEGIN 
							ROLLBACK 
					END
				COMMIT
				*/
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET /*CLM_ADJ_GRP111 = ' '
					,*/CLM_ADJ_REASON111 = ' '
				WHERE LEN(CLM_ADJ_AMT111) = 0
						--AND LEN(CLM_ADJ_REASON112) = 0
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK
				--	END
				--COMMIT
				----REMOVE CLM_ADJ_GRP111 WHEN 
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 = ' '
					,CLM_ADJ_REASON111 = ' '
					,CLM_ADJ_REASON112 = ' '
				WHERE LEN(CLM_ADJ_AMT111) = 0
						AND LEN(CLM_ADJ_AMT112) = 0
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK
				--	END
				--COMMIT
				
				----RESET CLM_ADJ_GRP12 WHEN NOT USED
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = ' '
					,CLM_ADJ_REASON121 = ' '
				WHERE LEN(CLM_ADJ_AMT121) = 0
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK
				--	END
				--COMMIT
				--	-- Note:
				---- 03/13/14		Loyal Ricks		Sequestration
				----
				--	---OTHER ADJUSTMENTS - WHEN TOTAL PAID AMOUNTS EXCEED TOTAL CHARGES
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP111 = 'CO'
					,CLM_ADJ_REASON113 = '253'
					,CLM_ADJ_AMT113 = LTRIM(cd.WITHHOLDAMT)
					--LTRIM(RequestedAmt - ((PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)+ WITHHOLDAMT))
					--LTRIM(REQUESTEDAMT - MAXFEEAMT)-- REMOVED 6/15/12 CALCULATION (REQUESTEDAMT -  MAXFEEAMT), FORMULA NOT ACCURATE.
					,CLM_ADJ_QTY113 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN EDPS_Data.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND CLAIM_ID = CD.ClaimID
				AND LTRIM(CLAIM_LINE_NO) = LTRIM(CD.ClaimLineID)
				WHERE convert(money, cd.WITHHOLDAMT) > 0
				--RequestedAmt < (PaymentAmount + COBAmt + CoInsuranceAmt + DeductibleAmt + CoPayAmt)
				--	and cd.WITHHOLDAMT > 0
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				
				--BEGIN TRANSACTION 
				 update OUTB_INST_DETAIL
				set CLM_ADJ_AMT113 = LTRIM(convert(money,CLM_ADJ_AMT113) * -1)
				 from OUTB_INST_DETAIL
				where  CONVERT(MONEY, CLM_ADJ_AMT113) < 0
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
									
				--begin transaction
					update OUTB_INST_DETAIL
					set CLM_ADJ_AMT113 = ' '
					where CLM_ADJ_REASON113 <> '253'
				--	IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				--	--UPDATE CLM_ADJ_GRP2 INFORMATION - COPAY ADJUSTMENT
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP13 = 'PR'
					,CLM_ADJ_REASON131 = '3'
					,CLM_ADJ_AMT131 = LTRIM(COPAYAMT)
					,CLM_ADJ_QTY131 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN EDPS_Data.dbo.claimdetaildim CD
				 ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				 AND EC.CLAIM_ID = CD.CLAIMID
				AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
					WHERE CD.COPAYAMT <> 0.00	
				--				IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				----UNIT TEST FIX DUE TO ABOVE UPDATE, UPDATING RECORDS WITH ZERO COPAYAMT
				--BEGIN TRANSACTION 
					UPDATE OUTB_INST_DETAIL
					SET CLM_ADJ_GRP13 = ' '
							,CLM_ADJ_REASON131 = ' '
							,CLM_ADJ_AMT131 = ' '
					WHERE CLM_ADJ_AMT131 = '0.00'
				--	IF @@ERROR <> 0
				--		BEGIN 
				--			ROLLBACK
				--		END
				--COMMIT
				--	--UPDATE CLM_ADJ_GRP3 INFORMATION - DEDUCTIBLE ADJUSTMENT
				--	--11/09/12 - MOVE DEDUCTIBLE ADJUSTMENT FROM GRP131 TO GRP 122
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP13 = 'PR'
					,CLM_ADJ_REASON132 = '1'
					,CLM_ADJ_AMT132 = LTRIM(CD.DEDUCTIBLEAMT)
					,CLM_ADJ_QTY132 = QUANTITY
				FROM OUTB_INST_DETAIL EC
				INNER JOIN EDPS_Data.dbo.claimdetaildim CD
				ON EC.SOURCEDATAKEY = CD.SOURCEDATAKEY 
				AND  EC.CLAIM_ID = CD.CLAIMID
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
				WHERE CD.DEDUCTIBLEAMT <> 0.00
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				--		--UPDATE CLM_ADJ_GRP4 INFORMATION - COINSURANCE ADJUSTMENT
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP13 = 'PR'
					,CLM_ADJ_REASON133 = '2'
					,CLM_ADJ_AMT133 = LTRIM(CD.COINSURANCEAMT)
					,CLM_ADJ_QTY133 = QUANTITY
				FROM OUTB_INST_DETAIL EC
					,EDPS_Data.dbo.claimdetaildim CD
				WHERE EC.CLAIM_ID = CD.CLAIMID
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
					AND CD.COINSURANCEAMT <> 0.00
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT
				----UPDATE CLM_ADJ_GRP5 INFORMATION - PROVIDER CAPITATION
				--BEGIN TRANSACTION 
				--7/17/15 BALANCING TEST
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP15 = 'CR'
					,CLM_ADJ_REASON151 = '223'
					,CLM_ADJ_AMT151 = LTRIM(CAP_AMT)
					,CLM_ADJ_QTY151 = QUANTITY
					,OTH_PAYER1_PAID_AMT = ltrim((OTH_PAYER1_PAID_AMT - cap_amt))
				FROM OUTB_INST_DETAIL EC
					,#INST_TMPDEV_CLMCAP CD
				WHERE EC.CLAIM_ID = CD.CLAIMID
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
					--AND EC.CONTRACT_CODE = '05'
					AND TOTAL_CHRG_AMT <> OTH_PAYER1_PAID_AMT
				--IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT	
				----RESET OTH_PAYER1_PAID_AMT & OTH_PAYER1_PAID_QTY WHEN OTH_PAYER1_PAID_AMT = 0
				----remove code, 7/18 ONSITE HRP SESSION FINDINGS THERE MUST ALWAYS BE AN AMOUNT
				----IN OTH_PAYER11_PAID_AMT DEFAULT = 0.00
				--BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET OTH_PAYER1_PAID_AMT = '0.00'
					--,OTH_PAYER1_PAID_QTY = ' '
				WHERE (OTH_PAYER1_PAID_AMT = '0.00' OR LEN(OTH_PAYER1_PAID_AMT) = 0 )
					--AND CONTRACT_CODE = '05'
				--		IF @@ERROR <> 0
				--	BEGIN 
				--			ROLLBACK 
				--	END
				--COMMIT	
				
				--MAKE SURE MEMBER_AMT_PAID ON CLAIM HEADER IS NEVER SUBMITTED FOR PROFESSIONAL CLAIMS
				--SUBMITTING A VALUE WILL RESULT IN 103 REJECTIONS
				
				
		
						UPDATE OUTB_INST_HEADER
						SET MEMBER_AMT_PAID = ' '
						WHERE LEN(MEMBER_AMT_PAID) > 0
					
					--Shift Segment 132 to 131 when 131 segment is not present

							
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON131 = CLM_ADJ_REASON132,
										CLM_ADJ_AMT131 = ltrim(CLM_ADJ_AMT132),
										CLM_ADJ_QTY131 = CLM_ADJ_QTY132,
										CLM_ADJ_REASON132 = ' ',
										CLM_ADJ_AMT132 = ' ',
										CLM_ADJ_QTY132 = ' '
									WHERE (LEN(CLM_ADJ_REASON131) = 0
										AND LEN(CLM_ADJ_REASON132) > 0)
							
							--Shift Segment 133 to 132 when 132 segment is not present
							 
									UPDATE OUTB_INST_DETAIL
									SET CLM_ADJ_REASON132 = CLM_ADJ_REASON133,
										CLM_ADJ_AMT132 = ltrim(CLM_ADJ_AMT133),
										CLM_ADJ_QTY132 = CLM_ADJ_QTY133,
										CLM_ADJ_REASON133 = ' ',
										CLM_ADJ_AMT133 = ' ',
										CLM_ADJ_QTY133 = ' '
									WHERE LEN(CLM_ADJ_REASON132) = 0
										AND LEN(CLM_ADJ_REASON133) > 0
							

						----Shift Segment 112 to 111 when 111 segment is not present

						
						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON111 = CLM_ADJ_REASON112,
							CLM_ADJ_AMT111 = ltrim(CLM_ADJ_AMT112),
							CLM_ADJ_QTY111 = CLM_ADJ_QTY112
						WHERE LEN(CLM_ADJ_REASON111) = 0

						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON112 =' ',
							CLM_ADJ_AMT112 = ' ',
							 CLM_ADJ_QTY111 = ' '
						WHERE CLM_ADJ_REASON111 = CLM_ADJ_REASON112
							 AND CLM_ADJ_AMT111 = CLM_ADJ_AMT112
					

						----Shift Segment 113 to 111 when 111 segment is not present
						 
						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON111 = CLM_ADJ_REASON113,
							CLM_ADJ_AMT111 = ltrim(CLM_ADJ_AMT113),
							CLM_ADJ_QTY111 = CLM_ADJ_QTY113
						WHERE LEN(CLM_ADJ_REASON111) = 0

						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON113 =' ',
							CLM_ADJ_AMT113 = ' ',
							 CLM_ADJ_QTY113 = ' '
						WHERE CLM_ADJ_REASON111 = CLM_ADJ_REASON113
							 AND CLM_ADJ_AMT111 = CLM_ADJ_AMT113
						

						----Shift Segment 113 to 111 when 111 segment is not present
						
						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON112 = CLM_ADJ_REASON113,
							CLM_ADJ_AMT112 = ltrim(CLM_ADJ_AMT113),
							CLM_ADJ_QTY112 = CLM_ADJ_QTY113
						WHERE LEN(CLM_ADJ_REASON111) > 0
							and LEN(CLM_ADJ_REASON112) = 0

						update OUTB_INST_DETAIL
						SET CLM_ADJ_REASON113 =' ',
							CLM_ADJ_AMT113 = ' ',
							 CLM_ADJ_QTY113 = ' '
						WHERE CLM_ADJ_REASON112 = CLM_ADJ_REASON113
							 AND CLM_ADJ_AMT112 = CLM_ADJ_AMT113
				

						
				
				---07/09/12 UPDATE CLAIM ADJUSTMENT GROUP FOR 'PR' ADJUSTMENT
				---ADJUSTMENT GROUPS GRP12 - GRP14 ARE 'PR' AND SHOULD ONLY HAVE 1 GROUP CODE SUBMITTED PER SEGMENT
				--SET CLM_ADJ_GRP13 WHEN GRP12 IS NOT POPULATED
			/*	BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP13 = 'PR'
				FROM OUTB_INST_DETAIL EC
					,EDPS_Data.dbo.claimdetaildim CD
				WHERE EC.CLAIM_ID = CD.CLAIMID
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
					AND CD.DEDUCTIBLEAMT <> 0.00
					AND CLM_ADJ_GRP12 <> 'PR'
					IF @@ERROR <> 0
					BEGIN 
							ROLLBACK 
					END
				COMMIT	
				--SET CLM_ADJ_GRP14 WHEN GRP12 & GRP13 IS NOT POPULATED
				BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP14 = 'PR'
				FROM OUTB_INST_DETAIL EC
					,EDPS_Data.dbo.claimdetaildim CD
				WHERE EC.CLAIM_ID = CD.CLAIMID
					AND EC.CLAIM_LINE_NO = CD.CLAIMLINEID
					AND CD.COINSURANCEAMT <> 0.00
					AND CLM_ADJ_GRP12 <> 'PR'
					AND CLM_ADJ_GRP13 <> 'PR'
					IF @@ERROR <> 0
					BEGIN 
							ROLLBACK 
					END
				COMMIT	*/
				--MHC PENALTY PAYMENT UPDATES
				/*
				BEGIN TRANSACTION 
				UPDATE OUTB_INST_DETAIL
				SET CLM_ADJ_GRP12 = 'OA'
						,CLM_ADJ_REASON122 = '225'
					,CLM_ADJ_AMT122 = OTH_PAYER1_PAID_AMT
					,OTH_PAYER1_PROC_CD = ' '
					,SERV_ID_QUAL = ' '
					,PROC_CD = ' '
				FROM OUTB_INST_DETAIL
				WHERE PROC_CD = '0L6'
				COMMIT*/
				--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_INST_DETAIL_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_DETAIL)
									
		----HRP_CLAIM_FILE Update Run Controls
				--BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_INST_ADJUSTMENTS'
								AND END_DT IS NULL							
						--	IF @@ERROR <> 0
						--				BEGIN 
						--						ROLLBACK 
						--				END
						--COMMIT
						
