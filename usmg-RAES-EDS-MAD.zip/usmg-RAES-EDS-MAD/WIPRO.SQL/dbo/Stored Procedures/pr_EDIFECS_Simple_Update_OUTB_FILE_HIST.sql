﻿
CREATE  PROCEDURE dbo.pr_EDIFECS_Simple_Update_OUTB_FILE_HIST
AS
BEGIN
/**********************************************************************************************
PROCEDURE:	dbo.pr_EDIFECS_Simple_Update_OUTB_FILE_HIST
PURPOSE:	Update WIPRO.dbo.OUTB_FILE_HIST table from EDIFEC's equivalent tables of 
			OUTB_CLAIM_STATUS because they dont send use CLMSTAT, ACK, REJ, 277, etc files.

			This version updates from the data in the
			EDIFECS_UPDATES_TO_OUTB_FILE_HIST  table which is populated by a job on our server
			that pulls data from the EDIFECS Datamart servers.

			This is different from the dbo.pr_EDIFECS_Update_OUTB_FILE_HIST.  That sproc 
			collects the data from our EDIFECS tables on our servers, which are populated
			from Noe's separate jobs.  And then it updates the OUTB_FILE_HIST table.
			
NOTES:		

CREATED:	10/05/2020	Scott Waller	TETDM-2336
REVISIONS:
Date		Author			Description
------------------------------------------------------------------------------------------------

*************************************************************************************************/

	DECLARE		@record_counts			INT

	INSERT INTO WIPRO.dbo.EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT
			)
			VALUES('pr_EDIFECS_Simple_Update_OUTB_FILE_HIST'
					,'1'
					,GETDATE()
					,NULL
					,NULL
					,0
					,GETDATE()
					)

-----------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------
-- time to update	WIPRO.dbo.OUTB_FILE_HIST and
--					WIPRO.dbo.EDIFECS_UPDATES_TO_OUTB_FILE_HIST
-----------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------

	UPDATE WIPRO.dbo.OUTB_FILE_HIST
	SET		STAT_FILE_DT		= replace(convert(varchar(8), a.STAT_FILE_DATE, 112)+convert(varchar(8), a.STAT_FILE_DATE, 114), ':',''),
			STAT_REC_AMT		= ISNULL(a.CLAIMS_RECEIVED,0),
			STAT_ACCPT_AMT		= ISNULL(a.CLAIMS_ACCEPTED,0),
			STAT_REJ_AMT		= ISNULL(a.CLAIMS_REJECTED,0),
			LAST_UPD_DT			= ISNULL(a.STAT_FILE_DATE,0)
	FROM	WIPRO.dbo.EDIFECS_UPDATES_TO_OUTB_FILE_HIST a
	INNER JOIN WIPRO.dbo.OUTB_FILE_HIST b
		on	b.FILEID			= a.FILEID
		and b.SOURCEDATAKEY		= a.SOURCEDATAKEY

	SELECT @record_counts = @@rowcount

	UPDATE WIPRO.dbo.EXT_SYS_RUNLOG
	SET END_DT = GETDATE()
		,RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE())
		,TOTAL_RECORDS = @record_counts
		,ENTRYDT = GETDATE()
	WHERE PROC_NAME = 'pr_EDIFECS_Simple_Update_OUTB_FILE_HIST'
	AND END_DT IS NULL;

END
