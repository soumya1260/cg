﻿
CREATE PROCEDURE [dbo].[BUILD_ENCOUNTER_CLAIM_EXCLUSIONS] 
AS 
/*************************************************************************************************** 
** CREATE DATE: 09/16 
** 
** AUTHOR: LOYAL RICKS - LOYAL RICKS 
** 
** DESCRIPTION: Procedure will be used to identify encounterclaimdim exclusions 
** C:\Users\M74693\source\repos\RAES-EDS-MAD\WIPRO.SQL\dbo\Functions
** 
** 
** 
Modification History 
==================== 
Date			Who				Description 
 
-------------------------------------------------------------------------------------------------------------------------------------------------------------- 
09/20/16		Loyal Ricks		Add duplicate claim exclusion 
01/19/17		Loyal Ricks		TETDM-1253 Lift exclusion 444444442
04/23/18		Scott Waller	TETDM-1791 March 2018 Refresh, there are encounter claims that have a claimtype column value
								that is greater than 5 characters.  Our Exclusion tables have a max 5 character size.  This is due 
								to some bad data upstream.  So insteam of doing multiple table changes and MUCH testing, we are going 
								add a SUBSTRING on the claimtype column because these claims are bad and will not get submitted.
12/17/2018      Henry Faust     TETDM-1882 remove 444444444 exclusion. 
01/30/2019      Henry Faust     TETDM-1947 add 9057 - Frequency Code <> 1
08/19/2019		Scott Waller	TETDM-2098 Create a new exclusion to hold Arizona Hplan Claims in an exclusion (H0354).  Use 9047 per Tracy Black
09/03/2020      Aaron Ridley    TETDM-2346 Remove the 9057 exclusion and add 9019 exclusion for Adjustments

02/01/2021		Scott Waller	TETDM-2448 Create a new exclusion for Encounter Claims that do not have a line number 1.
02/05/21021     Henry Faust     TETDM-2453  Claim Adj , exclude claims that have aready been sent, have a record in the 
                                OUTB_CLAIM_STATUS table for Excl 9019

10/19/2021		Scott Waller	TETDM-2594	For the current Exclusion 9047, change it to 9062.
								Then copy the logic for Exclusion 9047 from the regular claims Exclusion sproc (EXSP_CLAIM_EXCLUSION_HIST)
								and put it in this Encounter Exclusion sproc.

09/03/2022		Scott Waller	RETM-135 Create a new exclusion, 9066, and create new logic to put any Encounter Claims 
								that have claim lines that have duplicates, into this new exclusion.

*******************************************************************************************************************************************************************/ 
--DECLARE VARIABLES 
 
	DECLARE 
			 
			@TOTAL_RECORDS INT 
           ,@CURRENTDATE	DATE
		select @CURRENTDATE = getdate()
			 
--HRP_CLAIM_FILE Run controls 
			 
					INSERT INTO EXT_SYS_RUNLOG 
							(PROC_NAME 
							,STEP 
							,START_DT 
							,END_DT 
							,RUN_MINUTES 
							,TOTAL_RECORDS 
							,ENTRYDT 
							) 
					VALUES('BUILD_ENCOUNTER_CLAIM_EXCLUSIONS' 
							,'1' 
							,GETDATE() 
							,NULL 
							,NULL 
							,0 
							,GETDATE() 
							) 
 
							---Delete previous EXT_CLAIM_EXCLUSION_HISTORY sourcedatakey 4 exclusions 
							---Additional logic required in order to leave DP sourcedatakey 4 exclusions  
							---in place. These exclusions are built during the regular EDS exclusion logic. 
							---deletion of excl_id = 444444444 will remove all previousl recors appended by  
							---this process as a temp solution. 

							delete  
							from EXT_CLAIM_EXCLUSION_HIST 
							WHERE SOURCEDATAKEY = 4 
								AND EXCL_ID = 444444444 
							--Truncate encounter exclusion hist table 
							truncate table EXT_ENCOUNTER_EXCLUSION_HIST 
 
 
									IF OBJECT_ID('TEMPDB..#tmp_enc_dup') <> 0 
														DROP TABLE #tmp_enc_dup 
					 
														CREATE TABLE #tmp_enc_dup 
														( claimnum varchar(50)  
															,sourcedesc varchar(60) 
															,claimlinenum varchar(4) 
															,filename varchar(256) 
															,claimtype varchar(50) 
															,seq int 
														) 
									insert into #tmp_enc_dup 
									select claimnum, 
											sourcedesc, 
											claimlinenum, 
											filename 
											,claimtype 
											, ROW_NUMBER() OVER ( PARTITION BY sourcedesc, Claimnum, claimlinenum ORDER BY sourcedesc, Claimnum, claimlinenum,filename desc)  
 
									from edps_Data.dbo.encounterclaimdim  
									where claimlinenum = '1' 
									--and claimnum =  'HSPTN20/12410884T' 
									order by claimnum,filename desc 
 
 
 
									---append EDS Exclusion history table in order to report exclusions 
									--INSERT INTO ClaimExclusionCode 
									--VALUES(444444444,'Encounter Duplicates',4,'All') 
--TETDM-1882  START Turn off exclusion id 44444444 for prof and institutional
								--	insert into EXT_CLAIM_EXCLUSION_HIST 
								--	select distinct claimnum,4,getdate(),444444444,substring(claimtype,1,5)---sourcedesc --*--max(filename)--*  
								--	from #tmp_enc_dup 
								--	where seq > 1 
 								-----append EDS Encounter exclusion table in order to report exclusion details 
 
									--INSERT INTO EXT_ENCOUNTER_EXCLUSION_HIST 
									--select distinct T.claimnum,T.sourcedESC,substring(t.claimtype,1,5),T.filename 
									--from #tmp_enc_dup t 
									--inner join EXT_CLAIM_EXCLUSION_HIST E 
									----ON T.SOURCEDESC = E.sourcedesc 
									--on T.CLAIMNUM = E.claim_id 
									--where sourcedatakey = 4  
									--	and EXCL_ID = 444444444 
 
 -- TETDM-1882 END

									--INVALID PAIDDATE
									--INSERT INTO EXT_CLAIM_EXCLUSION_HIST
									--SELECT DISTINCT CLAIMNUM,SOURCEDATAKEY,GETDATE(),444444442,CLAIMTYPE
									--FROM EDPS_DATA.DBO.ENCOUNTERCLAIMDIM 
									--WHERE PAIDDATEKEY IS NULL
--TETDM-1947 Begin
-- TETDM-2346 (Modification to exclude Adjustments with 9019)
				--	INSERT INTO wipro.dbo.EXT_ENCOUNTER_EXCLUSION_HIST 
				  --  INSERT INTO wipro.dbo.EXT_CLAIM_EXCLUSION_HIST
						--SELECT DISTINCT ecd.ClaimNum, 4 ,  GETDATE(), '9019', ClaimType
						--FROM edps_data.dbo.encounterclaimdim ecd
						--WHERE ecd.ClaimFrequencyCode in ('7','8')
						-- AND ecd.ClaimLineNum = 1
						-- AND ClaimType IN ('P','I')
--TETDM-1947 End
--TETDM-2493   Adjustment claim exclusions begin
INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST
    (claim_id, SOURCEDATAKEY, BATCH_RUN_DT,EXCL_ID, claim_type)
  select claimnum, sdk, cdate,excl, ClaimType 
    from (
      select distinct ecd.ClaimNum as claimnum, '4' as sdk, @CURRENTDATE as cdate, '9019' as excl, ClaimType, ocs.CLAIM_ID 
       FROM edps_data.dbo.encounterclaimdim ecd
          left join outb_claim_status ocs on ocs.CLAIM_ID = ecd.ClaimNum 
         --and ecd.ClaimLineNum = 1 
         --and ocs.CLAIM_TYPE = ecd.ClaimType 
         WHERE ecd.ClaimFrequencyCode in ('7','8')
           AND ecd.ClaimLineNum = '1'
           AND ClaimType IN ('P','I')
         ) x
   where x.CLAIM_ID is null
--TETDM-2493   Adjustment claim exclusions evd

-- TETDM-2098	Exclusion Claims in the H0354 HPLAN - use exclusion 9047 
-- per TETDM-2594, change this exclusion id 9047 to a new id, 9062
        ;WITH EncounterClaimBasket AS 
        (	SELECT	*
			FROM ( SELECT
						e.ClaimNum , 
						e.ClaimType ,
                        e.sourcedatakey , 
						e.Sourcedesc,
						e.memberid,
						e.beginservicedatekey,
						e.endservicedatekey,
						mmd.lobcode,
						mmd.HCFACODE,
                        latest = ROW_NUMBER() OVER (PARTITION BY e.CLAIMNUM, e.ClaimLineNum, e.MemberID, e.SOURCEDESC ORDER BY  e.LoadDateKey DESC, e.BeginServiceDateKey, e.FILENAME DESC)
                   FROM	EDPS_Data.dbo.encounterclaimdim e
				   	INNER JOIN EDS_Audit.dbo.EDS_Encounter_SourceDesc s
						ON	e.SourceDesc			= s.SourceDesc
						AND e.BeginServiceDateKey		BETWEEN startdate AND enddate
					INNER JOIN EDPS_Data.dbo.MonthlyMembershipDim mmd
						ON	mmd.MemberID			= e.MemberID
						AND e.BeginServiceDateKey	BETWEEN mmd.ModifiedReportDateKey - 14
													AND     mmd.ReportDateKey
                   WHERE	1 = 1
                   AND	e.ClaimFrequencyCode	= '1' 
				   AND	e.BeginServiceDateKey	>= '20170101'
                   AND  e.sourcedatakey			= 4 ) sub
              WHERE sub.latest = 1 )

		   INSERT INTO wipro.dbo.EXT_CLAIM_EXCLUSION_HIST
		   (claim_id, SOURCEDATAKEY, BATCH_RUN_DT,EXCL_ID, claim_type)
				SELECT DISTINCT ecd.ClaimNum, 
								ecd.sourcedatakey ,  
								GETDATE(), 
								--'9047', 
								'9062',	-- TETDM-2594
								ecd.ClaimType
				FROM    EncounterClaimBasket ecd
				WHERE	ecd.HCFACode = 'H0354'
-- end TETDM-2098

--Begin TETDM-2112  
			INSERT INTO wipro.dbo.EXT_CLAIM_EXCLUSION_HIST
				(claim_id, SOURCEDATAKEY, BATCH_RUN_DT,EXCL_ID, claim_type)
				SELECT DISTINCT ecd.ClaimNum, 4 ,  @CURRENTDATE, '8012', ClaimType

			FROM edps_data.dbo.encounterclaimdim ecd 
			 JOIN edps_data.dbo.MonthlyMembershipDim mmd ON mmd.MemberID = ecd.MemberID 
														 AND LEFT(mmd.ReportDateKey,6) = LEFT(ecd.BeginServiceDateKey,6)
			WHERE ecd.ClaimLineNum = '1'
			   AND ecd.ClaimType <> 'D'
			   AND mmd.ProductType = 'MEDICAID'
			   AND mmd.LobCode IN ( 'C45137428','UMISC0028042858','C54240970', 'C42644396')
			   AND mmd.EmployerCode IN ('TX002' ,'IL002', 'TX003', 'TX001')
				 AND LEFT(mmd.ReportDateKey,6) > 201701
			  AND claimnum NOT IN 

				(SELECT claimnum 
					FROM edps_data.dbo.encounterclaimdim ecd 
					JOIN edps_data.dbo.MonthlyMembershipDim mmd ON mmd.MemberID = ecd.MemberID 
					--AND LEFT(mmd.ReportDateKey,6) <> LEFT(ecd.BeginServiceDateKey,6)
					AND ecd.beginservicedatekey BETWEEN begincoveragedatekey AND endcoveragedatekey
					WHERE ecd.ClaimLineNum = '1' 
					AND LEFT(mmd.ReportDateKey,6) = LEFT(ecd.BeginServiceDateKey,6)
					AND LEFT(mmd.ReportDateKey,6) > 201701
					AND mmd.ProductType IN ( 'MEDICARE', 'CARE-CAID') 
	             )
--End TETDM-2112

-- TETDM-2448 new exclusion 9060
			SELECT	DISTINCT claimnum, ClaimType
			INTO	#hold_encounter_claims
			FROM	EDPS_Data.dbo.encounterclaimdim
			WHERE	SourceDesc		in ('WELLMED', 'ADVOCATE', 'SUPERIORVISION')

			CREATE NONCLUSTERED INDEX tIndex ON #hold_encounter_claims (claimnum ASC)

			SELECT	DISTINCT a.claimnum, a.ClaimLineNum, a.ClaimType
			INTO	#hold_encounter_claims_l1
			FROM	EDPS_Data.dbo.encounterclaimdim a
			WHERE	a.ClaimLineNum	= '1'
			AND		a.SourceDesc	in ('WELLMED', 'ADVOCATE', 'SUPERIORVISION')

			CREATE NONCLUSTERED INDEX tIndex ON #hold_encounter_claims_l1 (claimnum ASC)

			INSERT INTO wipro.dbo.EXT_CLAIM_EXCLUSION_HIST
			SELECT DISTINCT a.ClaimNum, 4 ,  @CURRENTDATE, '9060', a.ClaimType
			FROM	#hold_encounter_claims a
			WHERE	a.ClaimNum not in (	SELECT	b.ClaimNum
										FROM	#hold_encounter_claims_l1 b )
-- end TETDM-2448

-- TETDM-2594	Add the 9047 Exclusion logic from the EXSP_CLAIM_EXCLUSION_HIST sproc, to this sproc, for Encounter Claims
			IF OBJECT_ID('TEMPDB..#tmplob_excl') <> 0    
					DROP TABLE #tmplob_excl    
    
			CREATE TABLE #tmplob_excl    
				(LOBCode			VARCHAR(15))    
    
			INSERT INTO	#tmplob_excl  
				(LOBCode)    
				SELECT	LOBCode    
				FROM	MDQOLib.dbo.LineofBusinessDim    
				WHERE	ProductType IN ('Commercial','RX','PDP')    
				AND		Active = 1    
				ORDER BY LOBCode    
    
			INSERT INTO #tmplob_excl    
				(LOBCode)    
				SELECT	LOBCode    
				FROM    MDQOLib.dbo.LineofBusinessDim    
				WHERE	substring(HCFACODE,1,1) = 'S'    
				AND		Active = 1    
				and		LOBCode not in (SELECT LOBCode from #tmplob_excl)
				ORDER BY LOBCode    

			INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
			SELECT  DISTINCT e.CLAIMNUM, e.SOURCEDATAKEY, @CURRENTDATE, 9047,
					e.claimtype 
			FROM EDPS_DATA.DBO.encounterclaimdim e
		   	INNER JOIN EDS_Audit.dbo.EDS_Encounter_SourceDesc s
				ON	e.SourceDesc			= s.SourceDesc
				AND e.BeginServiceDateKey		BETWEEN startdate AND enddate
			INNER JOIN EDPS_Data.dbo.MonthlyMembershipDim mmd
				ON	mmd.MemberID			= e.MemberID
				AND e.BeginServiceDateKey	BETWEEN mmd.ModifiedReportDateKey - 14
											AND     mmd.ReportDateKey
			INNER JOIN #tmplob_excl T    
			ON mmd.LOBCODE = T.LOBCODE     
			WHERE	e.ClaimLineNum = '1'
-- end TETDM-2594

---------------------------------------------------------------------------------------------------------------------------------------
-- RETM-135 Identify encounter claims with duplicate claim line rows
--		1. Collect Encounter claim headers into a temp table
--		2. create another temp table that holds the claim headers that ARENT already in an Exclusion
--
--		*** NOTE:   Tracy Black advised that we want these claims in an EXCLUSION even if they are already in another exclusion
--					so I will put the same claims into the #hold_encounters_not_excluded table, but I'll comment out 
--					the logic and leave it here, incase we come back to it and need to put it in.
--
--		3. create a temp table for all claim headers in the Step 2 temp table, whose claimlinenum has 2 or more occurrances
--		4. For the distinct ClaimNum's in the temp table from Step 3, insert these claims into the Exclusion table for 9066 exclusion
---------------------------------------------------------------------------------------------------------------------------------------
		IF OBJECT_ID('tempDB..#hold_encounter_headers') IS NOT NULL
		BEGIN
			DROP TABLE #hold_encounter_headers
		END

       ;WITH EncounterClaimBasket AS 
       (	SELECT	*
			FROM ( SELECT
						e.ClaimNum , 
                        e.sourcedatakey , 
						e.Sourcedesc,
						e.memberid,
						e.claimlinenum,
						e.beginservicedatekey,
						e.claimtype,
                        latest = ROW_NUMBER() OVER (PARTITION BY e.CLAIMNUM, e.ClaimLineNum, e.MemberID, e.SOURCEDESC ORDER BY  e.LoadDateKey DESC, e.BeginServiceDateKey, e.FILENAME DESC)
                   FROM	EDPS_Data.dbo.EncounterClaimDim e
				   	INNER JOIN EDS_Audit.dbo.EDS_Encounter_SourceDesc s
						ON	e.SourceDesc			= s.SourceDesc
						AND e.BeginServiceDateKey		BETWEEN startdate AND enddate
                   WHERE	1 = 1
				   AND	e.BeginServiceDateKey	>= 20150101 
				   AND	e.claimlinenum			= 1		-- TETDM-2530
                   AND  e.sourcedatakey			= 4 ) sub
              WHERE sub.latest = 1
       )

		SELECT	SUBSTRING(CONVERT(CHAR, a.BeginServiceDateKey),1,4) as BeginServiceDateKeyYear,
				a.sourcedatakey, a.claimnum, a.SourceDesc,
				a.beginservicedatekey, a.ClaimType
		INTO	#hold_encounter_headers
		FROM	EncounterClaimBasket a

		IF OBJECT_ID('tempDB..#hold_encounters_not_excluded') IS NOT NULL
		BEGIN
			DROP TABLE #hold_encounters_not_excluded
		END

		-- do not join to the EXT_CLAIM_EXCLUSION_HIST table for now, per Tracy Black
		-- what this means is that some claims that are already in the EXT_CLAIM_EXCLUSION_HIST table
		-- under  a different exclsuion id, will be put in again under the new 9066 exclusion.
		-- This is needed and requested by the BA team (Tracy Black)
		SELECT	a.*
		INTO	#hold_encounters_not_excluded
		FROM	#hold_encounter_headers	a
--		LEFT OUTER JOIN WIPRO.dbo.ext_claim_exclusion_hist b
--			ON	b.sourcedatakey		= a.sourcedatakey
--			AND	b.claim_id			= a.ClaimNum
--		WHERE	b.claim_id IS NULL
-- with the LEFT OUTER JOIN and the WHERE claus removed, ALL the claims in #hold_encounters_headers will
-- be put into #hold_encounters_not_excluded.
		CREATE NONCLUSTERED INDEX tIndex ON #hold_encounters_not_excluded (claimnum)

		IF OBJECT_ID('tempDB..#hold_encounters_w_dup_lines') IS NOT NULL
		BEGIN
			DROP TABLE #hold_encounters_w_dup_lines
		END

		SELECT	a.SourceDataKey, a.SourceDesc, a.ClaimNum, a.ClaimLineNum, a.claimtype, count(*) as LineNumCount
		INTO	#hold_encounters_w_dup_lines
		FROM	EDPS_Data.dbo.encounterclaimdim a
		INNER JOIN #hold_encounters_not_excluded b
			on	b.SourceDataKey		= a.SourceDataKey
			and	b.ClaimNum			= a.ClaimNum
		GROUP BY a.SourceDataKey, a.SourceDesc, a.ClaimNum, a.ClaimLineNum, a.ClaimType
		HAVING	count(*) > 1

		CREATE NONCLUSTERED INDEX tIndex ON #hold_encounters_w_dup_lines (claimnum)

		INSERT INTO		wipro.dbo.EXT_CLAIM_EXCLUSION_HIST
		SELECT DISTINCT a.ClaimNum, 4 ,  @CURRENTDATE, '9067', a.ClaimType
		FROM	#hold_encounters_w_dup_lines a
---------------------------------------------------------------------------
-- end RETM-135
---------------------------------------------------------------------------

			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EXT_ENCOUNTER_EXCLUSION_HIST) 
		----HRP_CLAIM_FILE Update Run Controls 
				 
						UPDATE EXT_SYS_RUNLOG 
						SET END_DT = GETDATE()	 
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()) 
							,TOTAL_RECORDS = @TOTAL_RECORDS 
							,ENTRYDT = GETDATE() 
						WHERE PROC_NAME = 'BUILD_ENCOUNTER_CLAIM_EXCLUSIONS' 
										AND END_DT IS NULL 
