﻿

CREATE PROCEDURE [dbo].[BUILD_OUTB_PROF_EDSPROVIDER]
AS
/***************************************************************************************************
** CREATE DATE: 01/19/2013
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY OBTAIN PROVIDER SPECIFIC  
**              INFORMATION NEEDED FOR THE HRP CLAIM FILE. 
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-------------------------------------------------------------------------------------------------------------
03/07/2013		loyal ricks		Renumbered step from 6B to 6. Procedure replaces old EXSP_HRP_CLAIM_PROVIDER
04/02/2013		Loyal Ricks		Revisions supporting EDPS_Data.dbo.EDS_ProviderDim vendor updates
04/05/2013		Loyal Ricks		Add BILL_PROV_GRP and BILL_PROV EDS_Provider Update Logic 
04/07/2013		Loyal Ricks		Remove 'UNKNOWN' values from BILL_PROV AddressLine2
04/16/2013		Loyal Ricks		Add case statement to remove 'UNKNOWN' value from Title
04/18/2013		Loyal Ricks		Add REF_PROV_NPI,REF_PROV_PCP_NPI,ATTN_PROV_NPI
								Revised Logic to omit duplicate records from #TMP_EDSPROV
								Revised logic to transform 'UNKNOWN' REF_PROV_ID TO ''
05/09/2013		Loyal Ricks		Add Rendering Provider logic with condition to remove bill_prov info
								when both bill prov and bill provider group are known and passed
								Removal of PayTo information due to HS claim submissions. Payto no longer 
								needed.
05/10/2013		Loyal Ricks		Add Rendering Provider Group Id & Org Name conditionally when rendering provider
								is suspected to be a entity and not an individual
05/23/2013		Loyal Ricks		Added additional logic for conditional Billing Prov Group Updates required to
								resolve rej_rea_id = 1 & FIELD_ERR = 'LastOrOrg'
06/25/13		Loyal Ricks		REF_PROV Updates using NPID from claim to find REF_PROV name and NPID from 
								EDS_Provider
08/06/13		Loyal Ricks		EDPS_Data.dbo.EDS_ProviderDim.RecordSource revisions - Billing Group - Only use record source = 'V'
								records for Billing Provider Group address information. Global provider revisions
								have set all address info for recordsource = 'P' records to null.
08/16/13		Loyal Ricks     Revisions to support EDS_PROVIDERADDRESSDIM - Update Billing Provider Address info
								using EDS_ProviderAddressdim
10/24/13		Loyal Ricks		Revise logic for Billing Provider Group build when EDPS_Data.dbo.EDS_ProviderDim.Recordsource = 'P'
								for a billing provider group. Revisions include the following code changes
								Comment out --(AND LEN(ISNULL(EP.FirstName,' ')) = 0 )
 								Add check for null value (and ISNULL(ProviderStatus,' ') <> 'INACTIVE')
 10/25/13		Loyal Ricks		Add logic to support Facets Group Build - Bill Group Org Name & TIN updates 
								when EDPS_Data.dbo.EDS_ProviderDim.recordsource = 'P'
 01/08/2014		Loyal Ricks		Revised --UPDATE RENDERING_PROV_ORG_NAME, added substring(EDPS_Data.dbo.EDS_ProviderDim.FullName,1,60 
								due to truncation issues when executing procedure.
02/11/14		Loyal Ricks		Additional invalid EDI character parsing -	
04-14-14		Loyal Ricks		Remove setting of Taxonomy Code to blank. Taxonomy codes will begin to get submitted	
04/29/14		Loyal Ricks		Add substring length 60 for EDPS_Data.dbo.EDS_ProviderDim.FullName update 
06/04/2013		Loyal Ricks		Production Support due to job failure during execution for binary data length
								Revised - 	--Additional Billing Group Org Name & TIN Updates when EDPS_Data.dbo.EDS_ProviderDim.RecordSource = 'P'
								SET BILL_PROV_ORG_NAME = RTRIM(SUBSTRING(EP.FULLNAME,1,60))						
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation			
2014-08-28		Loyal Ricks		JIRA EDS-388 Provider DME Logic - Taxonomy Code Update - Use the IDQ.CMSTaxonomy
								table to update Billing Group Provider and Billing Provider taxonomy code
								using the Billing Provider NPI. 
								Remove "REF_PCP Provider" Updates. REF_PCP only required when multple 
								referrals (REF_Number) is required on a claim. Additional logic required
								for multiple referrals.		
								Apply Conditional Update for Referring Provider only when a referral number
								is present on the claim header (OUTB_PROF_HEADER.referral_no)		
								Claim DME Flag (OUTB_PROF_HEADER.CLAIM_TYPE) Update. Update value = 'E'
								(DME) when BILL_PROV_TAXONOMY_CD IN  ('332B00000X','332BC3200X','332BD1200X','332BN1400X','332BX2000X')		
2015-04-14		Loyal Ricks		--04/14/15 - Add evaluation of zipcode in order to proper assign zip4 only when 5 digit zip exists		
2016-02-09		Loyal Ricks		TETDM-632 Billing Provider Group Address Info Update - Update when Group Address is blank	
2016-10-05		Loyal Ricks		RTD-1115 Revision to DME Taxonomy logic	
2018-03-16      John Bartholomay TETDM-1678 UPDATE BILLING PROVIDER INFORMATION IF IT EXITS IN THE HISTORICAL CLAIM 								    
2018-05-08      John Bartholomay TETDM-1678 Null out Billing Provider Suffix
2018-06-08      John Bartholomay TETDM-1678 Set all Billing Provider Suffix's to null
2018-07-02      John Bartholomay TETDM-1808 Rendering Providre Information
2018-08-07      John Bartholomay TETDM-1755 Hard Code Provider NPI number for 1 provider
2109-04-08      Subhash Acharya  TETDM-1979 
2019-07-31      Henry Faust      TETDM-2072 fill in Attending provider information when empty.
2019-07-31      Henry Faust      TETDM-2075 fill in Billing Provider Address info when empty or has PO Box.
2019-10-31		Noe Leiva		 TETDM-2132 Commented out PO BOX logic.
******************************************************************************************************************************************/			
	--DECLARE VARIABLES

			DECLARE
			
			@TOTAL_RECORDS INT


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_PROF_EDSPROVIDER'
				,'6'
				,GETDATE()
				,null
				,' '
				,0
				,GETDATE()
				)
	--GET BILLING AND SERVICING PROVIDER INFORMATION FROM EDPS_Data.dbo.claimdetaildim
	--03/21/13 ADD EDPS_Data.dbo.claimdetaildim.VENDORNPI - USE VENDORNPI FROM EDPS_Data.dbo.claimdetaildim TO IDENTIFY BILL_PROV_GRP INFO
	---EDPS_Data.dbo.claimdetaildim.VENDORID OFTEN NOT FOUND IN EDPS_Data.dbo.EDS_ProviderDim.PROVIDERID
	IF OBJECT_ID('TEMPDB..#TMPDEV_CLMPROV') <> 0
		DROP TABLE #TMPDEV_CLMPROV
		
	SELECT DISTINCT  c.CLAIMID
					,cd.VENDORID
					,isnull(c.vendornpi,' ') as vendornpi
					,cd.PROVIDERID
					,CASE cd.PROVIDERNPI WHEN 'UNKNOWN' THEN ' ' WHEN '0000000000' THEN ' ' ELSE cd.PROVIDERNPI END AS 'PROVIDERNPI'
					,c.SourceDataKey
	INTO  #TMPDEV_CLMPROV
	FROM EDPS_Data.dbo.claimdim c
		,EDPS_Data.dbo.claimdetaildim cd 
	WHERE c.claimid = cd.claimid 
			and cd.VENDORID <> 'UNKNOWN'
			and c.CLAIMID IN (SELECT CLAIM_ID FROM OUTB_PROF_HEADER)
	
		
	--UPDATE OUTB_PROF_HEADER WITH PROVIDER IDENTIFIERS FROM EDPS_Data.dbo.claimdetaildim
	
	BEGIN TRANSACTION 
	UPDATE OUTB_PROF_HEADER
	SET BILL_PROV_NPI = substring(rtrim(T.PROVIDERNPI),1,10)
		,BILL_PROV_ID = substring(rtrim(T.PROVIDERID),1,40)
		,BILL_PROV_GRP_ID = substring(rtrim(T.VENDORID),1,40)
		,BILL_PROV_GRP_NPI = substring(rtrim(ISNULL(T.VENDORNPI,' ')),1,40)
	FROM OUTB_PROF_HEADER C
		,#TMPDEV_CLMPROV T
	WHERE C.CLAIM_ID = T.CLAIMID
	IF @@ERROR <> 0
		if @@ERROR <> 0
			begin
				rollback 
			end
		commit
			
	--Build #tmp_edsprov --Get Claim and provider identifiers along with additional provider info from EDPS_Data.dbo.EDS_ProviderDim
	
		IF OBJECT_ID('TEMPDB..#temp_clmprov') <> 0
		DROP TABLE #temp_clmprov
		
		Create Table #temp_clmprov
 		(
 		[CLAIMID]	[VARCHAR](20),
 		[BILL_PROV_GRP_ID] [VARCHAR] (40),
 		[BILL_PROV_GRP_NPI] [VARCHAR] (40),
 		[BILL_PROV_ID]	[VARCHAR](40),
 		[BILL_PROV_NPI] [VARCHAR] (40),
 		[REF_PROV_ID]	[VARCHAR](50),
 		[REF_PCP_PROV_ID]	[VARCHAR](50),
 		[ATTN_PROV_ID]  [VARCHAR](50),
 		[SOURCEDATAKEY]	INT,
 		[STATUS_CD]  [VARCHAR] (500)
 		)
 		
 		--GET ALL CLAIM PROVIDER IDENTIFIERS 
 		insert into #temp_clmprov
 		select	claim_id
 				,BILL_PROV_GRP_ID	--Billing Provider Group ID
 				,BILL_PROV_GRP_NPI	--Billing Provider Group NPI
 				,BILL_PROV_ID		--Billing Provider Plan Provider ID
 				,BILL_PROV_NPI		--Billing Provider NPI
 				,case REF_PROV_ID  when 'UNKNOWN' THEN ' ' ELSE REF_PROV_ID END
 				,case REF_PCP_PROV_ID when 'UNKNOWN' THEN ' ' ELSE REF_PCP_PROV_ID END
 				,CASE ATTN_PROV_ID when 'UNKNOWN' THEN ' ' ELSE ATTN_PROV_ID END
 				,SOURCEDATAKEY
 				,NULL
 		from OUTB_PROF_HEADER	
 		
 	IF OBJECT_ID('TEMPDB..#TMP_EDSPROV_BILLGRP') <> 0
		DROP TABLE #TMP_EDSPROV_BILLGRP
		
 		
 	CREATE TABLE #TMP_EDSPROV_BILLGRP
 	(
 	[RecordSource] [CHAR] (1),
 	[ProviderID] [VARCHAR](20) ,
	[ProviderTypeCode] [varchar](15) ,
	[ProviderStatus] [varchar](10) ,
	[GlobalCurrentPatientLoad] [varchar](5) ,
	[AdditionalBusinessName] [varchar](35) ,
	[PrimaryBusinessName] [varchar](90) ,
	[FullName] [varchar](95) ,
	[ReverseFullName] [varchar](95) ,
	[LastName] [varchar](60) ,
	[FirstName] [varchar](40) ,
	[MiddleName] [varchar](30) ,
	[Title] [varchar](15) ,
	[GlobalPanelSize] [varchar](5) ,
	[NewPatientFlag] [char](1) ,
	[DeaNumber] [varchar](10) ,
	[Gender] [char](1) ,
	[DOBDateKey] [int] ,
	[UPIN] [varchar](20) ,
	[FIDN] [varchar](25) ,
	[NPID] [varchar](10) ,
	[MedicaidID] [varchar](20) ,
	[MedicareID] [varchar](20) ,
	[HandicapAccess] [varchar](1) ,
	[CredentialingStatus] [varchar](15) ,
	[ProvCategory] [varchar](15) ,
	[LicenseTypeCode] [char](1) ,
	[LeasedStatusCode] [char](1) ,
	[PreferredStatusCode] [char](1) ,
	[ChildFlg] [char](1) ,
	[YouthFlg] [char](1) ,
	[AdultFlg] [char](1) ,
	[StandardHoursInd] [char](1) ,
	[AfterHoursInd] [char](1) ,
	[WeekendHoursInd] [char](1) ,
	--[SourceDataKey] [int] ,
	[ProviderType_ProviderTypeDesc] [varchar](60) ,
	--Global Provider vendor revisions
	[VendorID] [varchar](20) ,
	[VendorTypeCode] [varchar](15),
	[Vendor_NPI] [varchar] (10),
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	[Vendor_Phone] [varchar](20) ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	[Vendor_AddressLine1] [varchar](60) ,
	[Vendor_AddressLine2] [varchar](60) ,
	[Vendor_City] [varchar](30) ,
	[Vendor_State] [char](2) ,
	[Vendor_ZipCode9] [varchar] (11),--(9) ,
	--[ProviderAddress_MultiAddressInd] [int] ,
	--[ProviderAddress_Latitude] [decimal](9, 6) ,
	--[ProviderAddress_Longitude] [decimal](9, 6) ,
	--[ProviderAddress_AddressTypeDesc] [varchar](20) ,
	[Ingenix_TaxonomyCode] [varchar](10) ,
	[Ingenix_SpecialtyName] [varchar](60) ,
	[Ingenix_SpecialtyGroupName] [varchar](60) ,
 	[SourceDataKey] [INT]
 	)
 		
	--Build Provider Record for Billing Group 
	BEGIN TRANSACTION
	INSERT INTO #TMP_EDSPROV_BILLGRP
	SELECT distinct 
	RecordSource ,
	T.BILL_PROV_GRP_ID,
	ProviderTypeCode  ,
	ProviderStatus  ,
	GlobalCurrentPatientLoad  ,
	AdditionalBusinessName  ,
	PrimaryBusinessName  ,
	dbo.fn_edi_parse(FullName)  ,
	dbo.fn_edi_parse(ReverseFullName)  ,
	dbo.fn_edi_parse(LastName)  ,
	dbo.fn_edi_parse(FirstName)  ,
	dbo.fn_edi_parse(MiddleName)  ,
	case Title when 'UNKNOWN' then ' ' else Title end,
	GlobalPanelSize  ,
	NewPatientFlag  ,
	DeaNumber  ,
	Gender  ,
	DOBDateKey  ,
	UPIN  ,
	--FIDN  ,	
	VENDOR_FEDERALID , --use vendor info for billing group
	isnull(NPID,' ')  ,
	MedicaidID  ,
	MedicareID  ,
	HandicapAccess  ,
	CredentialingStatus  ,
	ProvCategory  ,
	LicenseTypeCode  ,
	LeasedStatusCode  ,
	PreferredStatusCode  ,
	ChildFlg  ,
	YouthFlg  ,
	AdultFlg  ,
	StandardHoursInd  ,
	AfterHoursInd  ,
	WeekendHoursInd  ,
	--SourceDataKey  ,
	ProviderType_ProviderTypeDesc  ,
	t.BILL_PROV_GRP_ID  , --Vendor_VendorID ,
	Vendor_VendorTypeCode ,
	case t.BILL_PROV_GRP_NPI when 'N/A' then ' ' else ISNULL(t.BILL_PROV_GRP_NPI,' ') end , --Vendor_NPIID ,
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	Vendor_Phone ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	dbo.fn_edi_parse(Vendor_AddressLine1)  ,
	dbo.fn_edi_parse(Vendor_AddressLine2)  ,
	Vendor_City  ,
	Vendor_State  ,
	Vendor_Zip,--Code9 ,
	--ProviderAddress_MultiAddressInd  ,
	--ProviderAddress_Latitude  ,
	--ProviderAddress_Longitude  ,
	--ProviderAddress_AddressTypeDesc  ,
	Ingenix_TaxonomyCode  ,
	Ingenix_SpecialtyName  ,
	Ingenix_SpecialtyGroupName  ,
 	T.SourceDataKey
 	FROM #temp_clmprov T 
	JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 	ON rtrim(T.BILL_PROV_GRP_ID) = rtrim(EP.ProviderID)  
 	AND T.SOURCEDATAKEY = EP.SOURCEDATAKEY 
 	where RecordSource = 'V'
 	IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
 	
 	
 	--Vendors configured with RecordSource = 'P'
 	
 	--Build Provider Record for Billing Group 
	BEGIN TRANSACTION 
	INSERT INTO #TMP_EDSPROV_BILLGRP
	SELECT distinct 
	RecordSource ,
	T.BILL_PROV_GRP_ID,
	ProviderTypeCode  ,
	ProviderStatus  ,
	GlobalCurrentPatientLoad  ,
	AdditionalBusinessName  ,
	PrimaryBusinessName  ,
	dbo.fn_edi_parse(FullName)  ,
	dbo.fn_edi_parse(ReverseFullName)  ,
	' ',--LastName  ,
	' ',--FirstName  ,
	' ',--MiddleName  ,
	' ',--Title  ,
	GlobalPanelSize  ,
	NewPatientFlag  ,
	DeaNumber  ,
	Gender  ,
	DOBDateKey  ,
	UPIN  ,
	--FIDN  ,	
	FIDN, --- USE FOR INDIVIDUAL GROUP (P RECORDSOURCE)VENDOR_FEDERALID , --use vendor info for billing group
	NPID  ,
	MedicaidID  ,
	MedicareID  ,
	HandicapAccess  ,
	CredentialingStatus  ,
	ProvCategory  ,
	LicenseTypeCode  ,
	LeasedStatusCode  ,
	PreferredStatusCode  ,
	ChildFlg  ,
	YouthFlg  ,
	AdultFlg  ,
	StandardHoursInd  ,
	AfterHoursInd  ,
	WeekendHoursInd  ,
	--SourceDataKey  ,
	ProviderType_ProviderTypeDesc  ,
	t.BILL_PROV_GRP_ID  , --Vendor_VendorID ,
	Vendor_VendorTypeCode ,
	case t.BILL_PROV_GRP_NPI when 'N/A' then ' ' else t.BILL_PROV_GRP_NPI end , --Vendor_NPIID ,
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	' ',--ProviderPhone_PhoneNumber ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	' ',--ProviderAddress_AddressLine1  ,
	' ',--ProviderAddress_AddressLine2  ,
	' ',--ProviderAddress_City  ,
	' ',--ProviderAddress_State  ,
	' ',--ProviderAddress_ZipCode9 ,
	--' ',--ProviderAddress_MultiAddressInd  ,
	--0,--ProviderAddress_Latitude  ,
	--0,--ProviderAddress_Longitude  ,
	--' ',--ProviderAddress_AddressTypeDesc  ,
	Ingenix_TaxonomyCode  ,
	Ingenix_SpecialtyName  ,
	Ingenix_SpecialtyGroupName  ,
 	T.SourceDataKey
 	FROM #temp_clmprov T 
	LEFT OUTER JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 	ON rtrim(T.BILL_PROV_GRP_ID) = rtrim(EP.ProviderID)  
 	AND T.SOURCEDATAKEY = EP.SOURCEDATAKEY
 	where  EP.RecordSource = 'P'
 	--AND LEN(ISNULL(EP.FirstName,' ')) = 0 
 	and ISNULL(ProviderStatus,' ') <> 'INACTIVE'
 	and ProviderID not in (select ProviderID from #TMP_EDSPROV_BILLGRP)
 	IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
 	
 	--update NPI FROM EDPS_Data.dbo.EDS_ProviderDim For those providers where the vendornpi on the claim was unknown
 	-- Update VendorNPI from EDS_Provider.Vendor_NationalProviderID
	BEGIN TRANSACTION 
 	update  #TMP_EDSPROV_BILLGRP
 	set vendor_npi = ISNULL(EP.Vendor_NationalProviderID,' ')
 	from #TMP_EDSPROV_BILLGRP BG
 		,EDPS_Data.dbo.EDS_ProviderDim EP
 	WHERE BG.VendorID = EP.Vendor_VendorID
 		AND BG.SourceDataKey = EP.SourceDataKey
 		AND BG.VendorID = EP.ProviderID 
 		AND LEN(ISNULL(BG.vendor_npi,' '))  < 10  
		and EP.RecordSource = 'V'
 		IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
 		
 	--update billing group zip4, use default of '9998' when zip4 is blank
	--
	--Note
	--04/14/15 - Add evaluation of zipcode in order to proper assign zip4 only when 5 digit zip exists
	--
 	BEGIN TRANSACTION 
 	update #TMP_EDSPROV_BILLGRP
 	set Vendor_ZipCode9 = substring(vendor_zipcode9,1,5) + '' + '9998'
 	where (len(substring(vendor_zipcode9,1,5)) = 5 and  LEN(vendor_zipcode9) <> 9)
 	IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
 	-- --update NPI FROM EDPS_Data.dbo.EDS_ProviderDim For those providers where the vendornpi on the claim was unknown
 	---- Update VendorNPI from EDS_Provider.isnull(NPID,' ')	
 	
 	-- 	update  #TMP_EDSPROV_BILLGRP
 	--set vendor_npi = ISNULL(EP.Vendor_NationalProviderID,' ')
 	--from #TMP_EDSPROV_BILLGRP BG
 	--	,EDPS_Data.dbo.EDS_ProviderDim EP
 	--WHERE BG.ProviderID = EP.ProviderID
 	--	AND BG.SourceDataKey = EP.SourceDataKey
 	--	AND EP.ProviderID = EP.Vendor_VendorID
 	--	AND LEN(ISNULL(BG.vendor_npi,' '))  <> 10  
 	--	and EP.RecordSource = 'P'	
 	
 	
 	IF OBJECT_ID('TEMPDB..#TMP_EDSPROV') <> 0
	DROP TABLE #TMP_EDSPROV
		
 	CREATE TABLE #TMP_EDSPROV
 	(
 	[RecordSource] [CHAR] (1),
 	[ProviderID] [VARCHAR](20) ,
	[ProviderTypeCode] [varchar](15) ,
	[ProviderStatus] [varchar](10) ,
	[GlobalCurrentPatientLoad] [varchar](5) ,
	[AdditionalBusinessName] [varchar](35) ,
	[PrimaryBusinessName] [varchar](90) ,
	[FullName] [varchar](95) ,
	[ReverseFullName] [varchar](95) ,
	[LastName] [varchar](60) ,
	[FirstName] [varchar](40) ,
	[MiddleName] [varchar](30) ,
	[Title] [varchar](15) ,
	[GlobalPanelSize] [varchar](5) ,
	[NewPatientFlag] [char](1) ,
	[DeaNumber] [varchar](10) ,
	[Gender] [char](1) ,
	[DOBDateKey] [int] ,
	[UPIN] [varchar](20) ,
	[FIDN] [varchar](25) ,
	[NPID] [varchar](10) ,
	[MedicaidID] [varchar](20) ,
	[MedicareID] [varchar](20) ,
	[HandicapAccess] [varchar](1) ,
	[CredentialingStatus] [varchar](15) ,
	[ProvCategory] [varchar](15) ,
	[LicenseTypeCode] [char](1) ,
	[LeasedStatusCode] [char](1) ,
	[PreferredStatusCode] [char](1) ,
	[ChildFlg] [char](1) ,
	[YouthFlg] [char](1) ,
	[AdultFlg] [char](1) ,
	[StandardHoursInd] [char](1) ,
	[AfterHoursInd] [char](1) ,
	[WeekendHoursInd] [char](1) ,
	--[SourceDataKey] [int] ,
	[ProviderType_ProviderTypeDesc] [varchar](60) ,
	--Global Provider vendor revisions
	[VendorID] [varchar](20) ,
	[VendorTypeCode] [varchar](15),
	[Vendor_NPI] [varchar] (10),	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	[Vendor_Phone] [varchar](20) ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	[Vendor_AddressLine1] [varchar](60) ,
	[Vendor_AddressLine2] [varchar](60) ,
	[Vendor_City] [varchar](30) ,
	[Vendor_State] [char](2) ,
	[Vendor_ZipCode9] [varchar] (11),--(9) ,
	--[ProviderAddress_MultiAddressInd] [int] ,
	--[ProviderAddress_Latitude] [decimal](9, 6) ,
	--[ProviderAddress_Longitude] [decimal](9, 6) ,
	--[ProviderAddress_AddressTypeDesc] [varchar](20) ,
	[Ingenix_TaxonomyCode] [varchar](10) ,
	[Ingenix_SpecialtyName] [varchar](60) ,
	[Ingenix_SpecialtyGroupName] [varchar](60) ,
 	SourceDataKey INT
 	)
	--BUILD BILL_PROV_ID
	BEGIN TRANSACTION 
	INSERT INTO #TMP_EDSPROV
	SELECT DISTINCT 
	RecordSource,
	T.BILL_PROV_ID  ,
	ProviderTypeCode  ,
	ProviderStatus  ,
	GlobalCurrentPatientLoad  ,
	AdditionalBusinessName  ,
	PrimaryBusinessName  ,
	dbo.fn_edi_parse(FullName)  ,
	dbo.fn_edi_parse(ReverseFullName)  ,
	dbo.fn_edi_parse(LastName ) ,
	dbo.fn_edi_parse(FirstName)  ,
	dbo.fn_edi_parse(MiddleName ) ,
	case Title when 'UNKNOWN' then ' ' else Title end,
	GlobalPanelSize  ,
	NewPatientFlag  ,
	DeaNumber  ,
	Gender  ,
	DOBDateKey  ,
	UPIN  ,
	FIDN  ,
	--isnull(NPID,' ')  ,
	case T.BILL_PROV_NPI when 'N/A' then ' ' else T.BILL_PROV_NPI end,
	MedicaidID  ,
	MedicareID  ,
	HandicapAccess  ,
	CredentialingStatus  ,
	ProvCategory  ,
	LicenseTypeCode  ,
	LeasedStatusCode  ,
	PreferredStatusCode  ,
	ChildFlg  ,
	YouthFlg  ,
	AdultFlg  ,
	StandardHoursInd  ,
	AfterHoursInd  ,
	WeekendHoursInd  ,
	--SourceDataKey  ,
	ProviderType_ProviderTypeDesc  ,
	t.BILL_PROV_GRP_ID  , --Vendor_VendorID ,
	Vendor_VendorTypeCode ,
	case t.BILL_PROV_GRP_NPI when 'N/A' then ' ' else ISNULL(t.BILL_PROV_GRP_NPI,' ') end , --Vendor_NPIID ,
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	Vendor_Phone ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	' ',--ProviderAddress_AddressLine1  ,
	' ',--ProviderAddress_AddressLine2  ,
	' ',--ProviderAddress_City  ,
	' ',--ProviderAddress_State  ,
	' ',--ProviderAddress_ZipCode9 ,
	--ProviderAddress_MultiAddressInd  ,
	--ProviderAddress_Latitude  ,
	--ProviderAddress_Longitude  ,
	--ProviderAddress_AddressTypeDesc  ,
	Ingenix_TaxonomyCode  ,
	Ingenix_SpecialtyName  ,
	Ingenix_SpecialtyGroupName  ,
 	T.SourceDataKey
 	
 	FROM #temp_clmprov T
 	JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 	ON EP.ProviderID = T.BILL_PROV_ID
 	AND EP.SOURCEDATAKEY = T.SOURCEDATAKEY
 	WHERE EP.RecordSource = 'P'
 		AND  EP.ProviderID NOT IN (SELECT ProviderID FROM #TMP_EDSPROV)
 	IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
 	
	--BUILD REF_PROV_ID
	BEGIN TRANSACTION
	INSERT INTO #TMP_EDSPROV
	SELECT distinct
	 RecordSource,
	ProviderID  ,
	ProviderTypeCode  ,
	ProviderStatus  ,
	GlobalCurrentPatientLoad  ,
	AdditionalBusinessName  ,
	PrimaryBusinessName  ,
	dbo.fn_edi_parse(FullName)  ,
	dbo.fn_edi_parse(ReverseFullName)  ,
	dbo.fn_edi_parse(LastName ) ,
	dbo.fn_edi_parse(FirstName)  ,
	dbo.fn_edi_parse(MiddleName ) ,
	case Title when 'UNKNOWN' then ' ' else Title end,
	GlobalPanelSize  ,
	NewPatientFlag  ,
	DeaNumber  ,
	Gender  ,
	DOBDateKey  ,
	UPIN  ,
	FIDN  ,
	isnull(NPID,' ')  ,
	MedicaidID  ,
	MedicareID  ,
	HandicapAccess  ,
	CredentialingStatus  ,
	ProvCategory  ,
	LicenseTypeCode  ,
	LeasedStatusCode  ,
	PreferredStatusCode  ,
	ChildFlg  ,
	YouthFlg  ,
	AdultFlg  ,
	StandardHoursInd  ,
	AfterHoursInd  ,
	WeekendHoursInd  ,
	--SourceDataKey  ,
	ProviderType_ProviderTypeDesc  ,
	Vendor_VendorID ,
	Vendor_VendorTypeCode ,
	Vendor_NationalProviderID,
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	Vendor_Phone ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	Vendor_AddressLine1  ,
	Vendor_AddressLine2  ,
	Vendor_City  ,
	Vendor_State  ,
	Vendor_Zip,--Code9 ,
	--ProviderAddress_MultiAddressInd  ,
	--ProviderAddress_Latitude  ,
	--ProviderAddress_Longitude  ,
	--ProviderAddress_AddressTypeDesc  ,
	Ingenix_TaxonomyCode  ,
	Ingenix_SpecialtyName  ,
	Ingenix_SpecialtyGroupName  ,
 	T.SourceDataKey 
 	
 	FROM #temp_clmprov T
 	JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 	ON EP.ProviderID = T.REF_PROV_ID
 	AND EP.SOURCEDATAKEY = T.SOURCEDATAKEY		
 	WHERE EP.RecordSource = 'P'
 		AND  EP.ProviderID NOT IN (SELECT ProviderID FROM #TMP_EDSPROV)
 	IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT	
 	
				
	--REF_PCP_PROV_ID
	
	BEGIN TRANSACTION 
	INSERT INTO #TMP_EDSPROV
	SELECT distinct
	RecordSource,
	ProviderID  ,
	ProviderTypeCode  ,
	ProviderStatus  ,
	GlobalCurrentPatientLoad  ,
	AdditionalBusinessName  ,
	PrimaryBusinessName  ,
	dbo.fn_edi_parse(FullName)  ,
	dbo.fn_edi_parse(ReverseFullName)  ,
	dbo.fn_edi_parse(LastName ) ,
	dbo.fn_edi_parse(FirstName)  ,
	dbo.fn_edi_parse(MiddleName ) ,
	case Title when 'UNKNOWN' then ' ' else Title end,
	GlobalPanelSize  ,
	NewPatientFlag  ,
	DeaNumber  ,
	Gender  ,
	DOBDateKey  ,
	UPIN  ,
	FIDN  ,
	isnull(NPID,' ')  ,
	MedicaidID  ,
	MedicareID  ,
	HandicapAccess  ,
	CredentialingStatus  ,
	ProvCategory  ,
	LicenseTypeCode  ,
	LeasedStatusCode  ,
	PreferredStatusCode  ,
	ChildFlg  ,
	YouthFlg  ,
	AdultFlg  ,
	StandardHoursInd  ,
	AfterHoursInd  ,
	WeekendHoursInd  ,
	--SourceDataKey  ,
	ProviderType_ProviderTypeDesc  ,
	Vendor_VendorID ,
	Vendor_VendorTypeCode ,
	Vendor_NationalProviderID,
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	Vendor_Phone ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	Vendor_AddressLine1  ,
	Vendor_AddressLine2  ,
	Vendor_City  ,
	Vendor_State  ,
	Vendor_Zip,--Code9 ,
	--ProviderAddress_MultiAddressInd  ,
	--ProviderAddress_Latitude  ,
	--ProviderAddress_Longitude  ,
	--ProviderAddress_AddressTypeDesc  ,
	Ingenix_TaxonomyCode  ,
	Ingenix_SpecialtyName  ,
	Ingenix_SpecialtyGroupName  ,
 	T.SourceDataKey 
 	
 	FROM #temp_clmprov T
 	JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 	ON EP.ProviderID = T.REF_PCP_PROV_ID
 	AND EP.SOURCEDATAKEY = T.SOURCEDATAKEY
	WHERE EP.RecordSource = 'P'
 		AND  EP.ProviderID NOT IN (SELECT ProviderID FROM #TMP_EDSPROV)
	IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT				
			
	--ATTN_PROV_ID
	
	BEGIN TRANSACTION 	
	INSERT INTO #TMP_EDSPROV
	SELECT distinct
	RecordSource,
	ProviderID  ,
	ProviderTypeCode  ,
	ProviderStatus  ,
	GlobalCurrentPatientLoad  ,
	AdditionalBusinessName  ,
	PrimaryBusinessName  ,
	dbo.fn_edi_parse(FullName)  ,
	dbo.fn_edi_parse(ReverseFullName)  ,
	dbo.fn_edi_parse(LastName ) ,
	dbo.fn_edi_parse(FirstName)  ,
	dbo.fn_edi_parse(MiddleName ) ,
	case Title when 'UNKNOWN' then ' ' else Title end,
	GlobalPanelSize  ,
	NewPatientFlag  ,
	DeaNumber  ,
	Gender  ,
	DOBDateKey  ,
	UPIN  ,
	FIDN  ,
	isnull(NPID,' ')  ,
	MedicaidID  ,
	MedicareID  ,
	HandicapAccess  ,
	CredentialingStatus  ,
	ProvCategory  ,
	LicenseTypeCode  ,
	LeasedStatusCode  ,
	PreferredStatusCode  ,
	ChildFlg  ,
	YouthFlg  ,
	AdultFlg  ,
	StandardHoursInd  ,
	AfterHoursInd  ,
	WeekendHoursInd  ,
	--SourceDataKey  ,
	ProviderType_ProviderTypeDesc  ,
	Vendor_VendorID ,
	Vendor_VendorTypeCode ,
	Vendor_NationalProviderID,
	--[ProviderGroup_BeginCoverageDateKey] [int] ,
	--[ProviderGroup_EndCoverageDateKey] [int] ,
	--[ProviderGroup_TerminationReasonCode] [varchar](4) ,
	--[ProviderPhone_PhoneTypeCode] [varchar](2) ,
	Vendor_Phone ,
	--[ProviderPhone_FaxNumber] [varchar](20) ,
	--[ProviderPhone_MultiPhoneInd] [int] ,
	--[ProviderAddress_AddressTypeCode] [varchar](2) ,
	Vendor_AddressLine1  ,
	Vendor_AddressLine2  ,
	Vendor_City  ,
	Vendor_State  ,
	Vendor_Zip,--Code9 ,
	--ProviderAddress_MultiAddressInd  ,
	--ProviderAddress_Latitude  ,
	--ProviderAddress_Longitude  ,
	--ProviderAddress_AddressTypeDesc  ,
	Ingenix_TaxonomyCode  ,
	Ingenix_SpecialtyName  ,
	Ingenix_SpecialtyGroupName  ,
 	T.SourceDataKey 
 	
 	FROM #temp_clmprov T
 	JOIN EDPS_Data.dbo.EDS_ProviderDim EP
 	ON EP.ProviderID = T.ATTN_PROV_ID
 	AND EP.SOURCEDATAKEY = T.SOURCEDATAKEY
 	WHERE EP.RecordSource = 'P'
 		AND  EP.ProviderID NOT IN (SELECT ProviderID FROM #TMP_EDSPROV)
 	IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT	
 	 	--update billing group zip4, use default of '9998' when zip4 is blank
		--Note
		--04/14/15 - Add evaluation of zipcode in order to proper assign zip4 only when 5 digit zip exists
		--
 	BEGIN TRANSACTION 
 	update #TMP_EDSPROV
 	set Vendor_ZipCode9 = SUBSTRING(vendor_zipcode9,1,5) + '' + '9998'
 	where (len(substring(vendor_zipcode9,1,5)) = 5 and  LEN(vendor_zipcode9) <> 9)
 	IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
 	--update NPI FROM EDPS_Data.dbo.EDS_ProviderDim For those providers where the providernpi on the claim was unknown
 	---- Update isnull(NPID,' ') from EDS_Provider.isnull(NPID,' '), EDS_Provider.RecordSource = P (Providerdim Source)
 	BEGIN TRANSACTION
 	update #TMP_EDSPROV
 	set NPID = isnull(ep.NPID,' ')
 	from #TMP_EDSPROV BP
 		,EDPS_Data.dbo.EDS_ProviderDim EP
 	WHERE BP.ProviderID = EP.ProviderID
 		AND LEN(BP.NPID)  = 0
 		AND EP.RecordSource = 'P'
 		IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
 	--update NPI FROM EDPS_Data.dbo.EDS_ProviderDim For those providers where the providernpi on the claim was unknown
 	---- Update isnull(NPID,' ') from EDS_Provider.Vendor_NationalProviderid, EDS_Provider.RecordSource = P (Providerdim Source)
 	--EDPS_Data.dbo.EDS_ProviderDim Solo Groups (Xray, clinics, Hospitals)
 	BEGIN TRANSACTION
 	update #TMP_EDSPROV
 	set NPID = ep.Vendor_NationalProviderID
 	from #TMP_EDSPROV BP
 		,EDPS_Data.dbo.EDS_ProviderDim EP
 	WHERE BP.ProviderID = EP.ProviderID
 		and BP.ProviderID = EP.Vendor_VendorID
 		AND LEN(BP.NPID)  = 0
 		AND EP.RecordSource = 'P'
 		IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
 		
 		
	--UPDATE BILL_PROV & PAY_TO ADDRESS INFO
	--USING PROVIDERDIM AND EDPS_Data.dbo.claimdetaildim.PROVIDERID (OUTB_PROF_HEADER.BILL_PROV_ID)
	
		--BILLING GROUP & BILLING PROVIDER EDS_PROVIDERADDRESSDIM UPDATES-08/16/13
 	
 	
 		BEGIN TRANSACTION
		UPDATE  #TMP_EDSPROV_BILLGRP
      SET Vendor_AddressLine1 = dbo.fn_edi_parse(EP.AddressLine1)
			,Vendor_AddressLine2 = dbo.fn_edi_parse(EP.AddressLine2)
			,Vendor_City = EP.City
			,Vendor_State = EP.State
			,Vendor_ZipCode9  = EP.ZipCode9
	 FROM EDPS_Data.dbo.EDS_ProviderAddressDim EP
	 JOIN #TMP_EDSPROV_BILLGRP T
	 ON EP.ProviderID = T.ProviderID
	 WHERE EP.AddressTypeCode = 'PB'
		AND T.RecordSource = 'P'
		IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
						
		BEGIN TRANSACTION
	  UPDATE  #TMP_EDSPROV 
      SET Vendor_AddressLine1 = dbo.fn_edi_parse(EP.AddressLine1)
			,Vendor_AddressLine2 = dbo.fn_edi_parse(EP.AddressLine2)
			,Vendor_City = EP.City
			,Vendor_State = EP.State
			,Vendor_ZipCode9  = EP.ZipCode9
	 FROM EDPS_Data.dbo.EDS_ProviderAddressDim EP
	 JOIN #TMP_EDSPROV T
	 ON EP.ProviderID = T.ProviderID
	 WHERE EP.AddressTypeCode = 'PB'
		AND T.RecordSource = 'P'	
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
 				
	--OUTB_PROF_HEADER UPDATES
				
	--UPDATE BILLING PROVIDER GROUP & CPO_NPI
	--USE THE VENDORID FROM EDPS_Data.dbo.claimdetaildim AS THE BILL_PROV_GRP_ID TO APPLY UPDATES
			BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET --BILL_PROV_ORG_NAME = T.FULLNAME --send BILL_PROV FIRST AND LAST INSTEAD OF FULL NAME 
				BILL_PROV_GRP_NPI = isnull(T.Vendor_NPI,' ')
				,CPO_NPI = isnull(T.NPID,' ')
			FROM OUTB_PROF_HEADER EHP
			JOIN  #TMP_EDSPROV_BILLGRP T
			ON EHP.BILL_PROV_GRP_ID = T.ProviderID
					AND EHP.SOURCEDATAKEY = T.SourceDataKey
					AND LEN(BILL_PROV_GRP_NPI) <> 10
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT		
				
			--UPDATE Billing Group Address
			BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET  BILL_PROV_ADDR1 =  substring(isnull(dbo.fn_edi_parse(T.Vendor_AddressLine1),' '),1,55)
				,BILL_PROV_ADDR2 =  substring(isnull(dbo.fn_edi_parse(T.Vendor_AddressLine2),' '),1,55)
				,BILL_PROV_CITY =  substring(isnull(T.Vendor_City,' '),1,30)
				,BILL_PROV_STATE =  substring(isnull(T.Vendor_State,' '),1,2)
				,BILL_PROV_ZIP =  substring(isnull(substring(T.Vendor_ZipCode9,1,5),' '),1,5)
				,BILL_PROV_ZIP4 =  substring(isnull(substring(T.Vendor_ZipCode9,6,4),' '),1,4)
			FROM OUTB_PROF_HEADER EHP
			JOIN  #TMP_EDSPROV_BILLGRP T
			ON EHP.BILL_PROV_GRP_ID = T.ProviderID
			AND EHP.SOURCEDATAKEY = T.SourceDataKey		
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT	
				
			
			----UPDATE Billing Group Address using vendor record 
			--UPDATE OUTB_PROF_HEADER
			--SET  BILL_PROV_ADDR1 =  substring(isnull(T.Vendor_AddressLine1,' '),1,55)
			--	,BILL_PROV_ADDR2 =  substring(isnull(T.Vendor_AddressLine2,' '),1,55)
			--	,BILL_PROV_CITY =  substring(isnull(T.Vendor_City,' '),1,30)
			--	,BILL_PROV_STATE =  substring(isnull(T.Vendor_State,' '),1,2)
			--	,BILL_PROV_ZIP =  substring(isnull(substring(T.Vendor_ZipCode9,1,5),' '),1,5)
			--	,BILL_PROV_ZIP4 =  substring(isnull(substring(T.Vendor_ZipCode9,6,4),' '),1,4)
			--FROM OUTB_PROF_HEADER EHP
			--JOIN  #TMP_EDSPROV_BILLGRP T
			--ON EHP.BILL_PROV_GRP_ID = T.ProviderID
			--AND EHP.SOURCEDATAKEY = T.SourceDataKey	
			--WHERE T.RecordSource = 'V'	
			
			
			--UPDATE Billing Group Address from Billing Group P record when vendor record not updated
			--UPDATE OUTB_PROF_HEADER
			--SET  BILL_PROV_ADDR1 =  substring(isnull(T.Vendor_AddressLine1,' '),1,55)
			--	,BILL_PROV_ADDR2 =  substring(isnull(T.Vendor_AddressLine2,' '),1,55)
			--	,BILL_PROV_CITY =  substring(isnull(T.Vendor_City,' '),1,30)
			--	,BILL_PROV_STATE =  substring(isnull(T.Vendor_State,' '),1,2)
			--	,BILL_PROV_ZIP =  substring(isnull(substring(T.Vendor_ZipCode9,1,5),' '),1,5)
			--	,BILL_PROV_ZIP4 =  substring(isnull(substring(T.Vendor_ZipCode9,6,4),' '),1,4)
			--FROM OUTB_PROF_HEADER EHP
			--JOIN  #TMP_EDSPROV_BILLGRP T
			--ON EHP.BILL_PROV_GRP_ID = T.ProviderID
			--AND EHP.SOURCEDATAKEY = T.SourceDataKey	
			--WHERE T.RecordSource = 'P'	
			--	AND LEN(isnull(T.Vendor_AddressLine1,' ')) = 0	
					
			--5/9 - remove payto due to discussion during onsite visit
			--payto not needed due to the way claims are submitted		
			--UPDATE PAYTO INFO WHEN BILLING GROUP IS PAYTO	
			--	UPDATE OUTB_PROF_HEADER
			--SET  PAYTO_ADDR1 =  substring(isnull(T.Vendor_AddressLine1,' '),1,55)
			--	,PAYTO_ADDR2 =  substring(isnull(T.Vendor_AddressLine2,' '),1,55)
			--	,PAYTO_CITY =  substring(isnull(T.Vendor_City,' '),1,30)
			--	,PAYTO_STATE =  substring(isnull(T.Vendor_State,' '),1,2)
			--	,PAYTO_ZIP =  substring(isnull(substring(T.Vendor_ZipCode9,1,5),' '),1,5)
			--	,PAYTO_ZIP4 =  substring(isnull(substring(T.Vendor_ZipCode9,6,4),' '),1,4)
			--FROM OUTB_PROF_HEADER EHP
			--JOIN  #TMP_EDSPROV_BILLGRP T
			--ON EHP.BILL_PROV_GRP_ID = T.ProviderID--T.ProviderGroup_ProviderGroupID
			----AND EHP.CLAIM_ID = T.CLAIM_ID
			--AND EHP.SOURCEDATAKEY = T.SourceDataKey
			----where EHP.BILL_PROV_GRP_ID IS NOT NULL
			
			
			----3/12/13 UPDATE PAYTO USING BILL_PROV_GRP_NPI
			--removed 04/03/13 all BILL_PROV_GRP_ID will reside in EDPS_Data.dbo.EDS_ProviderDim no need to do NPI hit
			--		UPDATE OUTB_PROF_HEADER
			--SET  PAYTO_ADDR1 =  substring(isnull(T.Vendor_AddressLine1,' '),1,55)
			--	,PAYTO_ADDR2 =  substring(isnull(T.Vendor_AddressLine2,' '),1,55)
			--	,PAYTO_CITY =  substring(isnull(T.Vendor_City,' '),1,30)
			--	,PAYTO_STATE =  substring(isnull(T.Vendor_State,' '),1,2)
			--	,PAYTO_ZIP =  substring(isnull(substring(T.Vendor_ZipCode9,1,5),' '),1,5)
			--	,PAYTO_ZIP4 =  substring(isnull(substring(T.Vendor_ZipCode9,6,4),' '),1,4)
			--FROM OUTB_PROF_HEADER EHP
			--JOIN  #TMP_EDSPROV_BILLGRP T
			--ON EHP.BILL_PROV_GRP_NPI = T.Vendor_NPI--T.ProviderGroup_ProviderGroupNPI
			----AND EHP.CLAIM_ID = T.CLAIM_ID
			--AND EHP.SOURCEDATAKEY = T.SourceDataKey
		
		
		BEGIN TRANSACTION
			update OUTB_PROF_HEADER
			set  BILL_PROV_LNAME = substring(isnull(dbo.fn_edi_parse(TP.LastName),' '),1,60)
				,BILL_PROV_FNAME = substring(isnull(dbo.fn_edi_parse(TP.FirstName),' '),1,35)
				,BILL_PROV_MID_INIT = substring(isnull(dbo.fn_edi_parse(TP.MiddleName),' '),1,25)
				,BILL_PROV_SFX = substring(isnull(TP.Title,' '),1,10)
				,BILL_PROV_ADDR1 = substring(isnull(dbo.fn_edi_parse(TP.Vendor_AddressLine1),' '),1,55)
				,BILL_PROV_ADDR2 =  CASE substring(isnull(dbo.fn_edi_parse(TP.Vendor_AddressLine2),' '),1,55)
										WHEN 'UNKNOWN' THEN ' ' ELSE substring(isnull(dbo.fn_edi_parse(TP.Vendor_AddressLine2),' '),1,55)
										END
				,BILL_PROV_CITY = substring(isnull(TP.Vendor_City,' '),1,30)
				,BILL_PROV_STATE = substring(isnull(TP.Vendor_State,' '),1,2)
				,BILL_PROV_ZIP =  substring(isnull(substring(TP.Vendor_ZipCode9,1,5),' ') ,1,5)
				,BILL_PROV_ZIP4 = substring(isnull(substring(TP.Vendor_ZipCode9,6,4) ,' ') ,1,4)
				,BILL_PROV_TAXONOMY_CD = substring(isnull(TP.Ingenix_TaxonomyCode,' '),1,10)
				,BILL_PROV_TAX_ID = substring(isnull(TP.FIDN,' '),1,11)
				--,BILL_PROV_SSN = TP.
				,BILL_PROV_UPIN = substring(isnull(TP.UPIN,' '),1,50)
				--,BILL_PROV_LICENSE_NO = TP.
			FROM dbo.OUTB_PROF_HEADER EC
				JOIN #TMP_EDSPROV TP
			ON EC.BILL_PROV_ID = TP.ProviderID
			--AND EC.CLAIM_ID = TP.CLAIM_ID 
			AND EC.SOURCEDATAKEY = TP.SourceDataKey
			WHERE LEN(EC.BILL_PROV_GRP_ID) = 0
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
	 ---UPDATE BILL_PROV_NPI FOR THOSE WITH INVALID ('0000000000' OR 'UNKNOWN') EDPS_Data.dbo.claimdetaildim.PROVIDERNPI
	 		BEGIN TRANSACTION
			update OUTB_PROF_HEADER
			set	BILL_PROV_NPI = isnull(TP.NPID,' ')
			FROM dbo.OUTB_PROF_HEADER EC
				JOIN #TMP_EDSPROV TP
			ON EC.BILL_PROV_ID = TP.ProviderID
			--AND EC.CLAIM_ID = TP.CLAIM_ID 
			AND EC.SOURCEDATAKEY = TP.SourceDataKey	
			WHERE LEN(BILL_PROV_NPI) = 0
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT		
			--UPDATE PAYTO INFO WHEN BILLING GROUP IS PAYTO	
			--IS THIS NEEDED? IS BILL_PROV_GRP_ID ALWAYS POPULATED ON THE CLAIM
			--ADDITIONAL RESEARCH REQUIRED
			/*	UPDATE OUTB_PROF_HEADER
			SET  PAYTO_ADDR1 = T.Vendor_AddressLine1
				,PAYTO_ADDR2 = T.Vendor_AddressLine1
				,PAYTO_CITY = T.Vendor_City
				,PAYTO_STATE = T.Vendor_State
				,PAYTO_ZIP = substring(T.Vendor_Zip,1,5)
				,PAYTO_ZIP4 = substring(T.Vendor_Zip,6,4)
			FROM OUTB_PROF_HEADER EHP
			JOIN  #TMP_EDSPROV_BILLGRP T
			ON EHP.BILL_PROV_ID = T.ProviderID--T.ProviderGroup_ProviderGroupID
			AND EHP.CLAIM_ID = T.CLAIM_ID
			AND EHP.SOURCEDATAKEY = T.SourceDataKey
			where EHP.BILL_PROV_GRP_ID IS NULL
				AND EHP.BILL_PROV_ID IS NOT NULL*/
	
			--REF_PROV UPDATES
			BEGIN TRANSACTION
			update OUTB_PROF_HEADER
			set  REF_PROV_LNAME = isnull(dbo.fn_edi_parse(TP.LastName),' ')
				,REF_PROV_FNAME = isnull(dbo.fn_edi_parse(TP.FirstName),' ')
				,REF_PROV_MID_INIT = isnull(dbo.fn_edi_parse(TP.MiddleName),' ')
				,REF_PROV_SFX = isnull(TP.Title,' ')
				,REF_PROV_TAXONOMY_CD = isnull(TP.Ingenix_TaxonomyCode,' ')
				,REF_PROV_UPIN = isnull(TP.UPIN,' ')
				,REF_PROV_NPI = isnull(TP.NPID,' ')
			FROM dbo.OUTB_PROF_HEADER EC
				JOIN #TMP_EDSPROV TP
			ON EC.REF_PROV_ID = TP.ProviderID
			--AND EC.CLAIM_ID = TP.CLAIM_ID 
			AND EC.SOURCEDATAKEY = TP.SourceDataKey			
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT	


						----
						--Note
						--- Remove logic for EDS-388 logic revisions to support DME claims
			--REF_PCP UPDATES
			--BEGIN TRANSACTION
			--update OUTB_PROF_HEADER
			--set  REF_PCP_LNAME = isnull(dbo.fn_edi_parse(TP.LastName),' ')
			--	,REF_PCP_FNAME = isnull(dbo.fn_edi_parse(TP.FirstName),' ')
			--	,REF_PCP_MID_INIT = isnull(dbo.fn_edi_parse(TP.MiddleName),' ')
			--	,REF_PCP_SFX = isnull(TP.Title,' ')
			--	,REF_PCP_TAXONOMY_CD = isnull(TP.Ingenix_TaxonomyCode,' ')
			--	,REF_PCP_PROV_UPIN = isnull(TP.UPIN,' ')
			--	,REF_PCP_PROV_NPI = isnull(TP.NPID,' ')
			--FROM dbo.OUTB_PROF_HEADER EC
			--	JOIN #TMP_EDSPROV TP
			--ON EC.REF_PCP_PROV_ID = TP.ProviderID
			----AND EC.CLAIM_ID = TP.CLAIM_ID 
			--AND EC.SOURCEDATAKEY = TP.SourceDataKey				
			--	IF @@ERROR <> 0
			--							BEGIN 
			--									ROLLBACK 
			--							END
			--			COMMIT
				
				
			--ATTN_PROV UPDATES
--TETDM-2072 set up, NULL the fields and if the don't get updated, then update them

			BEGIN TRANSACTION
			update OUTB_PROF_HEADER
			set  ATTN_PROV_LNAME = isnull(dbo.fn_edi_parse(TP.LastName),' ')
				,ATTN_PROV_FNAME = isnull(dbo.fn_edi_parse(TP.FirstName),' ')
				,ATTN_PROV_MIDINIT = isnull(dbo.fn_edi_parse(TP.MiddleName),' ')
				,ATTN_PROV_SFX = isnull(TP.Title,' ')
				,ATTN_PROV_TAXONOMY_CD = isnull(TP.Ingenix_TaxonomyCode,' ')
				--,BILL_PROV_SSN = TP.
				,ATTN_PROV_UPIN = isnull(TP.UPIN,' ')
				,ATTN_PROV_NPI = isnull(TP.NPID,' ')
			FROM dbo.OUTB_PROF_HEADER EC
				JOIN #TMP_EDSPROV TP
			ON EC.ATTN_PROV_ID = TP.ProviderID
			--AND EC.CLAIM_ID = TP.CLAIM_ID 
			AND EC.SOURCEDATAKEY = TP.SourceDataKey	
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT



			--provider taxonomy code exclusion
			--temporary logic to omit submisson of taxonomy code
			--comment out reset of taxonomy code
			--Update OUTB_PROF_HEADER 
			--SET REF_PROV_TAXONOMY_CD = ' '
			--	,REF_PCP_TAXONOMY_CD = ' '
			--	,ATTN_PROV_TAXONOMY_CD = ' '
			--	,BILL_PROV_TAXONOMY_CD = ' '
			

			-- 10/23/2019 TETDM 2132 Commented out the code below
			---conditional name submissions from various sources
			---update Billing Group Org. Name  
			--BEGIN TRANSACTION
			--update OUTB_PROF_HEADER
			--SET BILL_PROV_ORG_NAME = SUBSTRING(RTRIM(bill_prov_lname) +' '+ RTRIM(bill_prov_fname) + ' '+ RTRIM(BILL_PROV_MID_INIT) + ' ' + RTRIM(bill_prov_sfx),1,60)
			--	,bill_prov_lname = ' '
			--	,BILL_PROV_FNAME = ' '
			--	,BILL_PROV_MID_INIT = ' '
			--	,BILL_PROV_SFX = ' '
			--where  BILL_PROV_GRP_NPI = BILL_PROV_NPI
			--IF @@ERROR <> 0
			--							BEGIN 
			--									ROLLBACK 
			--							END
			--			COMMIT
			
			
			
			--update Bill Provider Name
			--
			--04/29/14 - Add substring length 60 for EDPS_Data.dbo.EDS_ProviderDim.FullName update 
			update OUTB_PROF_HEADER
			SET BILL_PROV_ORG_NAME = isnull(substring(P.FULLNAME,1,60),' ')
			FROM OUTB_PROF_HEADER C
				,EDPS_Data.dbo.EDS_ProviderDim P
			WHERE C.BILL_PROV_GRP_ID = P.ProviderID
				AND C.SOURCEDATAKEY = P.SourceDataKey
				AND BILL_PROV_GRP_NPI <> BILL_PROV_NPI
			--NO NEED TO UPDATE BILL_PROV_GRP_NPI - BEING UPDATED FROM CLAIMDDIM
			
			BEGIN TRANSACTION 
			update OUTB_PROF_HEADER
			SET /*BILL_PROV_GRP_NPI = ISNULL(P.Vendor_NationalProviderID,' ')
				,*/BILL_PROV_ORG_NAME = substring(P.Vendor_VendorName,1,60)
			FROM OUTB_PROF_HEADER C
				,EDPS_Data.dbo.EDS_ProviderDim P
			WHERE c.BILL_PROV_GRP_ID = p.ProviderID
			and c.SOURCEDATAKEY = p.SourceDataKey
			AND LEN(C.BILL_PROV_GRP_ID) > 0
				AND (LEN(C.BILL_PROV_GRP_NPI) = 0 OR LEN(C.BILL_PROV_ORG_NAME) = 0)
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
						
			BEGIN TRANSACTION	
			update OUTB_PROF_HEADER
			set BILL_PROV_ORG_NAME = ' '
			where BILL_PROV_ORG_NAME is null
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT	

				
			--update rendering provider info when billing group info is known AND rendering provider is an individual
			BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET RENDERING_PROV_LAST_NAME = RTRIM(BILL_PROV_LNAME)
				,RENDERING_PROV_FIRST_NAME = RTRIM(BILL_PROV_FNAME)
				,RENDERING_PROV_MID_INIT = RTRIM(BILL_PROV_MID_INIT)
				,RENDERING_PROV_SFX = RTRIM(BILL_PROV_SFX)
				,RENDERING_PROV_NPI = BILL_PROV_NPI
				,RENDERING_PROV_ID = BILL_PROV_ID
				,BILL_PROV_LNAME = ' '
				,BILL_PROV_FNAME = ' '
				,BILL_PROV_MID_INIT = ' '
				,BILL_PROV_SFX = ' '
				,BILL_PROV_NPI = ' '
				,BILL_PROV_ID = ' '
			WHERE LEN(BILL_PROV_GRP_ID) > 0 
					AND LEN(BILL_PROV_ID) > 0
					and LEN(bill_prov_fname) > 0
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
			--update rendering provider info when billing group info is known AND rendering provider is an individual
			BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET RENDERING_PROV_ORG_NAME = isnull(BILL_PROV_LNAME,' ')
				,RENDERING_PROV_NPI = BILL_PROV_NPI
				,RENDERING_PROV_GRP_ID = BILL_PROV_ID
				,BILL_PROV_LNAME = ' '
				,BILL_PROV_FNAME = ' '
				,BILL_PROV_MID_INIT = ' '
				,BILL_PROV_SFX = ' '
				,BILL_PROV_NPI = ' '
				,BILL_PROV_ID = ' '
			WHERE LEN(BILL_PROV_GRP_ID) > 0 
					AND LEN(BILL_PROV_ID) > 0
					AND BILL_PROV_GRP_NPI <> BILL_PROV_NPI
					and LEN(bill_prov_fname) = 0	
			--SUBMIT BILL_PROV_GRP INFORMATION WHEN BILL_PROV_GRP_NPI = BILL_PROV_NPI
			UPDATE OUTB_PROF_HEADER
			SET BILL_PROV_ID = ' '
				,BILL_PROV_NPI = ' '
			WHERE  BILL_PROV_GRP_NPI = BILL_PROV_NPI
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
			
--UPDATE RENDERING_PROV_ORG_NAME
			BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET RENDERING_PROV_ORG_NAME =substring(isnull(EP.VENDOR_VENDORNAME,' '),1,60)
			FROM OUTB_PROF_HEADER C
			JOIN EDPS_Data.dbo.EDS_ProviderDim EP
			ON RTRIM(C.RENDERING_PROV_GRP_ID) = RTRIM(EP.ProviderID)
			WHERE EP.RECORDSOURCE = 'V'
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT


--UPDATE RENDERING_PROV_ORG_NAME
			BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET RENDERING_PROV_ID = RENDERING_PROV_GRP_ID
				,RENDERING_PROV_LAST_NAME = RTRIM(EP.LASTNAME)
				,RENDERING_PROV_FIRST_NAME = RTRIM(EP.FIRSTNAME)
				,RENDERING_PROV_MID_INIT = RTRIM(EP.MIDDLENAME)
				,RENDERING_PROV_GRP_ID = ' '
			--RENDERING_PROV_ORG_NAME =substring(isnull(EP.VENDOR_VENDORNAME,' '),1,60)
			FROM OUTB_PROF_HEADER C
			JOIN EDPS_Data.dbo.EDS_ProviderDim EP
			ON RTRIM(C.RENDERING_PROV_GRP_ID) = RTRIM(EP.ProviderID)
			WHERE EP.RECORDSOURCE = 'P'
				AND LEN(RENDERING_PROV_ORG_NAME) = 0
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
			--Update missing REF_PROV INFO FROM EDS_PROVIDER 
			--REJ_REA_ID 1,FILE_SUBTYPE_qUAL = 'DN',FIELD_ERR - 'LASTORGORG'
			BEGIN TRANSACTION		
			UPDATE OUTB_PROF_HEADER
			SET REF_PROV_LNAME = ISNULL(E.lastname,' ')
				,REF_PROV_FNAME = isnull(E.FirstName,' ')
				,REF_PROV_MID_INIT = ISNULL(E.MiddleName,' ')
				,REF_PROV_NPI = isnull(E.NPID,' ')
				,REF_PROV_UPIN = isnull(E.UPIN,' ')
			FROM OUTB_PROF_HEADER C
				,EDPS_Data.dbo.EDS_ProviderDim E
			WHERE C.REF_PROV_ID = E.ProviderID  
				AND E.RecordSource = 'P' 
				AND (LEN(C.REF_PROV_LNAME) = 0 AND LEN(C.REF_PROV_ID) > 0)
				IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
						
			BEGIN TRANSACTION
				
			UPDATE OUTB_PROF_HEADER
			SET REF_PROV_LNAME = ISNULL(E.Vendor_VendorName,' ')
				,REF_PROV_FNAME = isnull(E.Vendor_FirstName,' ')
				,REF_PROV_NPI = isnull(E.Vendor_NationalProviderID,' ')
				,REF_PROV_UPIN = isnull(E.UPIN,' ')
			FROM OUTB_PROF_HEADER C
				,EDPS_Data.dbo.EDS_ProviderDim E
			WHERE C.REF_PROV_ID = E.ProviderID   
				AND( LEN(C.REF_PROV_LNAME) = 0 AND LEN(C.REF_PROV_ID) > 0)  
				and e.NPID is null                                    
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT			
			---REF_PROV UPDATES WHEN REF_PROV_ID IS KNOWN AND NO HIT FOUND ON EDS_PROVIDER
			---NO HIT NORMALLY DUE TO USE OF REF_PROV NPID ON CLAIM INSTEAD OF REF_PROV_ID
			---IMPLEMENTED TO SUPPORT FACETS REF_PROV REJECT ISSUES 06/25/13	
			--08-28-2014 Revise logic to conditional update Referring Provider only when a Referral exists (len(OUTB_PROF_HEADER.REFERRAL_NO) > 0 )					
			BEGIN TRANSACTION				
			update OUTB_PROF_HEADER
			SET REF_PROV_LNAME = ISNULL(P.LastName,' ')
				,REF_PROV_FNAME = ISNULL(P.FirstName,' ')
				,REF_PROV_NPI = P.NPID
			FROM OUTB_PROF_HEADER C
				,EDPS_Data.dbo.EDS_ProviderDim P
			WHERE C.REF_PROV_ID = P.NPID
				AND C.SOURCEDATAKEY = P.SourceDataKey
				AND LEN(REF_PROV_ID) > 0
				AND LEN(REF_PROV_NPI) = 0
				AND LEN(REF_PROV_LNAME) = 0	
				AND len(referral_no) > 0
				IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT	
		
	--Update Billing Provider TIN on outbound claim 
			BEGIN TRANSACTION	
			UPDATE OUTB_PROF_HEADER
			SET BILL_PROV_TAX_ID = BG.FIDN
			FROM #TMP_EDSPROV_BILLGRP BG
			JOIN OUTB_PROF_HEADER 	C
			ON BG.ProviderID = C.BILL_PROV_GRP_ID 
			WHERE LEN(C.BILL_PROV_TAX_ID) = 0
				AND LEN(BILL_PROV_GRP_ID) > 0 
				AND BG.RecordSource = 'V'
				IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
	--APPLY DEFAULT BILL_PROV_ZIP4 
	--Note
	--04/14/15 - Add evaluation of zipcode in order to proper assign zip4 only when 5 digit zip exists
	--
			BEGIN TRANSACTION
			UPDATE OUTB_PROF_HEADER
			SET BILL_PROV_ZIP4 = '9998'
			WHERE len(BILL_PROV_ZIP) = 5 
				AND LEN(BILL_PROV_ZIP4) = 0
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
	--BILL_PROV_TAX_ID NULL VALUE CHECK
			BEGIN TRANSACTION 
			UPDATE OUTB_PROF_HEADER
			SET BILL_PROV_TAX_ID = ' '
			WHERE BILL_PROV_TAX_ID IS NULL
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
			
	--Additional Billing Group Org Name & TIN Updates when EDPS_Data.dbo.EDS_ProviderDim.RecordSource = 'P'
			BEGIN TRANSACTION 
			update OUTB_PROF_HEADER
			SET BILL_PROV_ORG_NAME = RTRIM(SUBSTRING(EP.FULLNAME,1,60))
			FROM OUTB_PROF_HEADER E
			JOIN EDPS_Data.dbo.EDS_ProviderDim EP
			ON E.BILL_PROV_GRP_ID = EP.ProviderID
			AND E.SOURCEDATAKEY = EP.SOURCEDATAKEY
			WHERE EP.RecordSource = 'P'
			AND LEN(BILL_PROV_GRP_ID) > 0
			AND LEN(BILL_PROV_ORG_NAME) = 0
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
			
			BEGIN TRANSACTION
			update OUTB_PROF_HEADER
			SET BILL_PROV_TAX_ID = EP.FIDN
			FROM OUTB_PROF_HEADER E
			JOIN EDPS_Data.dbo.EDS_ProviderDim EP
			ON E.BILL_PROV_GRP_ID = EP.ProviderID
			AND E.SOURCEDATAKEY = EP.SOURCEDATAKEY
			WHERE EP.RecordSource = 'P'
			AND LEN(BILL_PROV_GRP_ID) > 0
			AND LEN(BILL_PROV_TAX_ID) = 0 
			IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT

	---EDS-388 Update Provider Taxonomy from IDQ.CMSTaxonomy 
	---
			--Note
			--- EDS-388 DME provider taxonomy updates 
			----RTD-1115 Revision
			---Update Billing Provider Taxonomy Code 
			BEGIN TRANSACTION 
			UPDATE OUTB_PROF_HEADER
			SET BILL_PROV_TAXONOMY_CD = HealthcareProviderTaxonomyCode
			FROM OUTB_PROF_HEADER P
			INNER JOIN EDPS_Data.IDQ.CMSTaxonomy T
			ON P.BILL_PROV_GRP_NPI = T.NPI
			where len(P.BILL_PROV_TAXONOMY_CD) = 0
				and t.HealthcareProviderPrimaryTaxonomySwitch = 'Y'
			IF @@ERROR <> 0
			BEGIN 
			ROLLBACK
			END
			COMMIT	

			
			begin transaction 
			update OUTB_PROF_HEADER
			SET CLAIM_TYPE = 'E'
			WHERE BILL_PROV_TAXONOMY_CD IN ('332B00000X','332BC3200X','332BD1200X','332BN1400X','332BX2000X')	
			IF @@ERROR <> 0
			BEGIN 
			ROLLBACK
			END
			COMMIT		

			--2/9/16 Billing Provider Group Address Info Update - Update when Group Address is blank
			
			 UPDATE  OUTB_PROF_HEADER 
				  SET BILL_PROV_ADDR1 = EP.AddressLine1
						,BILL_PROV_ADDR2 = EP.AddressLine2
						,BILL_PROV_CITY = EP.City
						,BILL_PROV_STATE = EP.State
						,BILL_PROV_ZIP  = SUBSTRING(EP.ZipCode9,1,5)
						,BILL_PROV_ZIP4 = SUBSTRING(EP.ZipCode9,6,4)
				 FROM edps_data.dbo.EDS_ProviderAddressDim EP
				 JOIN  OUTB_PROF_HEADER T
				 ON EP.ProviderID = T.BILL_PROV_GRP_ID
				 WHERE EP.AddressTypeCode = 'PB'
				 and len(bill_prov_addr1) = 0	
			
	  --TETDM-1678 UPDATE BILLING PROVIDER INFORMATION IF IT EXITS IN THE HISTORICAL CLAIM TABLE
	  IF OBJECT_ID('TEMPDB..#TMPBILLING_CLMPROV') <> 0
		 DROP TABLE #TMPBILLING_CLMPROV
		
	  SELECT A.CLAIM_ID,
	         B.BillProvID,
             B.BillProvNPI,
			 CASE
			   WHEN LTRIM(RTRIM(A.BILL_PROV_TAX_ID)) ='' THEN B.BillProvTaxID 
			   ELSE A.BILL_PROV_TAX_ID
			  END AS BillProvTaxId,
		     B.BillProvFirst,
		     B.BillProvLast,
			 B.BillProvSuffix,
			 B.BillProvMiddle,
		     B.BillProvAddress,
		     B.BillProvAddress2,
		     B.BillProvCity,
		     B.BillProvState,
		     B.BillProvZip,
			 B.BillProvUPINLicense,
			 B.BillProvTaxonomy,
			 CASE 
			   WHEN LTRIM(RTRIM(A.BILL_PROV_GRP_NPI)) ='' THEN B.BillProvNPI 
			   WHEN LTRIM(RTRIM(UPPER(A.BILL_PROV_GRP_NPI))) ='UNKNOWN' THEN B.BillProvNPI 
			   ELSE A.BILL_PROV_GRP_NPI
			  END AS BILLPROV_GRP_NPI
			
	  INTO  #TMPBILLING_CLMPROV
      FROM EDPS_Data.DBO.HistoricalClaim B 
      JOIN OUTB_PROF_HEADER A
       ON B.InternalAppClaimID = A.Claim_ID
	   AND LEN(B.BILLPROVNPI) > 0
	   --AND LEN(B.BillProvTaxonomy) > 0

	  --------------------------------------------------
	  -- UPDATE BILLING PROVIDER INFO FROM HISTORY TABLE
	  ---------------------------------------------------
	  update OUTB_PROF_HEADER
	  SET  BILL_PROV_LNAME = substring(isnull(T.BillProvLast,' '),1,60)
		   ,BILL_PROV_FNAME = substring(isnull(T.BillProvFirst,' '),1,35)
		   ,BILL_PROV_MID_INIT = substring(isnull(T.BillProvMiddle,' '),1,25)
		   ,BILL_PROV_SFX =  substring(isnull(T.BillProvSuffix,' '),1,10)
		   ,BILL_PROV_ADDR1 = substring(isnull(T.BillProvAddress,' '),1,55)
		   ,BILL_PROV_ADDR2 =  CASE substring(isnull(T.BillProvAddress2,' '),1,55)
								WHEN 'UNKNOWN' THEN ' ' ELSE substring(isnull(T.BillProvAddress2,' '),1,55)
								END
		   ,BILL_PROV_CITY = substring(isnull(T.BillProvCity,' '),1,30)
		   ,BILL_PROV_STATE = substring(isnull(T.BillProvState,' '),1,2)
		   ,BILL_PROV_ZIP =  substring(isnull(substring(T.BillProvZip,1,5),' ') ,1,5)
		   ,BILL_PROV_ZIP4 = substring(isnull(substring(T.BillProvZip,6,4) ,' ') ,1,4)
		   ,BILL_PROV_TAXONOMY_CD = substring(isnull(T.BillProvTaxonomy,' '),1,10)
		   ,BILL_PROV_TAX_ID = substring(isnull(T.BillProvTaxID,' '),1,11)
		   ,BILL_PROV_UPIN = substring(isnull(T.BillProvUPINLicense,' '),1,50)
		   ,BILL_PROV_NPI = LTRIM(rtrim(T.BillProvNPI))
		   ,BILL_PROV_GRP_NPI= LTRIM(RTRIM(T.BILLPROV_GRP_NPI))
		FROM dbo.OUTB_PROF_HEADER  H
		JOIN #TMPBILLING_CLMPROV T
		 ON T.CLAIM_ID  = H.CLAIM_ID
	    where LEN(T.BILLPROVNPI) > 0

		--tetdm 1687 additional change

		UPDATE dbo.OUTB_PROF_HEADER
		SET BILL_PROV_SFX = ' '

		--TETDM-1808
		------------------------------------------------
		-- RENDERING PROVIDER UPDATES FROM HIST TABLE
		------------------------------------------------
		IF OBJECT_ID('TEMPDB..#TMPRENDERING_CLMPROV') <> 0
		 DROP TABLE #TMPRENDERING_CLMPROV
		
	    SELECT A.CLAIM_ID,
	           B.RendProvNPI,
			   B.RendProvLast,
			   B.RendProvFirst,
			   B.RendProvEntity,
			   B.RendProvMiddle
	   INTO  #TMPRENDERING_CLMPROV
       FROM EDPS_Data.DBO.HistoricalClaim B 
       JOIN OUTB_PROF_HEADER A
         ON B.InternalAppClaimID = A.Claim_ID
	    AND LEN(B.RendProvNPI) > 0

		UPDATE H
		SET  RENDERING_PROV_NPI = T.RendProvNPI,
		     H.RENDERING_PROV_LAST_NAME = T.RendProvLast,
			 H.RENDERING_PROV_FIRST_NAME = T.RendProvFirst,
			 H.RENDERING_PROV_MID_INIT = T.RendProvMiddle
		FROM dbo.OUTB_PROF_HEADER  H
		JOIN #TMPRENDERING_CLMPROV T
		  ON T.CLAIM_ID  = H.CLAIM_ID
	    where LEN(T.RendProvNPI) > 0

     --------------------------
	 --1755
	 --------------------------
	 UPDATE dbo.OUTB_PROF_HEADER
	 SET BILL_PROV_NPI = '1376579839',
	     BILL_PROV_GRP_NPI = '1376579839'
	 WHERE UPPER(BILL_PROV_GRP_NPI) = 'UNKNOWN'
	   AND UPPER(BILL_PROV_ORG_NAME) = 'TAMI DE ARAUJO MD PA'
	   AND BILL_PROV_TAX_ID ='208745280'
     -------------------------------------
	 -- 1755
	 -------------------------------------

-- TETDM-2075 begin tried everything else, now fill in Bill to address info --------------------------------------------------------------------
 UPDATE dbo.OUTB_PROF_HEADER
   SET BILL_PROV_ADDR1 = ''
   FROM dbo.OUTB_PROF_HEADER oph
   WHERE oph.BILL_PROV_ADDR1 LIKE '%PO %'

-- SELECT * FROM dbo.OUTB_PROF_HEADER WHERE CLAIM_ID = '18362E030256'

     UPDATE dbo.OUTB_PROF_HEADER
	   SET BILL_PROV_ADDR1 =  x.pbadressline1 
	     , BILL_PROV_ADDR2 =   x.pbAddressLine2 
		 ,BILL_PROV_CITY =   x.pbcity 
		 ,BILL_PROV_STATE =   x.pbstate 
		 ,BILL_PROV_ZIP =  LEFT(x.pbzip,5) 
		 ,bill_prov_zip4 = RIGHT(x.pbzip,4)
		
--		SELECT DISTINCT oph.CLAIM_ID, oph.BILL_PROV_GRP_ID, pd.ProviderID, pd.AddressLine1, pd.AddressLine2
FROM dbo.OUTB_PROF_HEADER oph
   LEFT JOIN 
		(SELECT DISTINCT t.CLAIM_ID,t.BILL_PROV_ID, t.BILL_PROV_GRP_ID, t.BILL_PROV_NPI, t.BILL_PROV_FNAME, t.BILL_PROV_LNAME
					   ,pb.ProviderID AS pbprovider, pb.AddressTypeCode AS pbaddresstypecode, pb.AddressLine1 AS pbadressline1, pb.AddressLine2 AS pbaddressline2, pb.City AS pbcity, pb.State AS pbstate, pb.ZipCode9 AS pbzip
	
		FROM dbo.OUTB_PROF_HEADER T --#temp_clmprov T 
		  LEFT	JOIN EDPS_Data.dbo.EDS_ProviderAddressDim pb
 				ON rtrim(T.BILL_PROV_GRP_ID) = rtrim(pb.ProviderID)  
 				AND T.SOURCEDATAKEY = pb.SOURCEDATAKEY 
				AND pb.AddressTypeCode =  'PB'
				--AND pb.AddressLine1 NOT LIKE '%PO %' -- TETDM 2132

        --WHERE t.claim_id LIKE '%E%' -- TETDM 2132
				)x ON x.CLAIM_ID = oph.CLAIM_ID 
WHERE oph.BILL_PROV_ADDR1 IS NULL OR oph.BILL_PROV_ADDR1 = '' OR oph.BILL_PROV_ADDR1 LIKE '%PO %'
--ORDER BY oph.CLAIM_ID
-------------------------------------------------update PM if needed
     UPDATE dbo.OUTB_PROF_HEADER
	   SET BILL_PROV_ADDR1 =  x.pmadressline1 
	     , BILL_PROV_ADDR2 =   x.pmAddressLine2 
		 ,BILL_PROV_CITY =   x.pmcity 
		 ,BILL_PROV_STATE =   x.pmstate 
		 ,BILL_PROV_ZIP =  LEFT(x.pmzip,5) 
		 ,bill_prov_zip4 = RIGHT(x.pmzip,4)
		
--		SELECT DISTINCT oph.CLAIM_ID, oph.BILL_PROV_GRP_ID, pd.ProviderID, pd.AddressLine1, pd.AddressLine2
FROM dbo.OUTB_PROF_HEADER oph
   LEFT JOIN 
		(SELECT DISTINCT t.CLAIM_ID,t.BILL_PROV_ID, t.BILL_PROV_GRP_ID, t.BILL_PROV_NPI, t.BILL_PROV_FNAME, t.BILL_PROV_LNAME
--					   ,pb.ProviderID AS pbprovider, pb.AddressTypeCode AS pbaddresstypecode, pb.AddressLine1 AS pbadressline1, pb.AddressLine2 AS pbaddressline2, pb.City AS pbcity, pb.State AS pbstate, pb.ZipCode9 AS pbzip
					   ,pm.ProviderID AS pmprovider, pm.AddressTypeCode AS pmaddresstypecode, pm.AddressLine1 AS pmadressline1, pm.AddressLine2 AS pmaddressline2, pm.City AS pmcity, pm.State AS pmstate, pm.ZipCode9 AS pmzip
		--               ,pa.ProviderID AS paprovider, pa.AddressTypeCode AS paaddresstypecode, pa.AddressLine1 AS paadressline1
		FROM dbo.OUTB_PROF_HEADER T --#temp_clmprov T 
		  --LEFT	JOIN EDPS_Data.dbo.EDS_ProviderAddressDim pb
 			--	ON rtrim(T.BILL_PROV_GRP_ID) = rtrim(pb.ProviderID)  
 			--	AND T.SOURCEDATAKEY = pb.SOURCEDATAKEY 
				--AND pb.AddressTypeCode =  'PB'
				--AND pb.AddressLine1 NOT LIKE '%PO %'
		  LEFT	JOIN EDPS_Data.dbo.EDS_ProviderAddressDim pm
 				ON rtrim(T.BILL_PROV_GRP_ID) = rtrim(pm.ProviderID)  
 				AND T.SOURCEDATAKEY = pm.SOURCEDATAKEY 
				AND pm.AddressTypeCode = 'PM' 
				--AND pm.AddressLine1 NOT LIKE '%PO %' -- TETDM 2132
        --WHERE t.claim_id LIKE '%E%' -- TETDM 2132
				)x ON x.CLAIM_ID = oph.CLAIM_ID 
WHERE oph.BILL_PROV_ADDR1 IS NULL OR oph.BILL_PROV_ADDR1 = '' OR oph.BILL_PROV_ADDR1 LIKE '%PO %'


----------- and finally address type PA
     UPDATE dbo.OUTB_PROF_HEADER
	   SET BILL_PROV_ADDR1 =  y.AddressLine1
	     , BILL_PROV_ADDR2 =   y.AddressLine2 
		 ,BILL_PROV_CITY =  y.City 
		 ,BILL_PROV_STATE = y.State 
		 ,BILL_PROV_ZIP =  LEFT(y.ZipCode9,5) 
       FROM dbo.OUTB_PROF_HEADER oph
	 JOIN 

		(SELECT pad.* FROM edps_data.dbo.EDS_ProviderAddressDim pad
		 JOIN 
			(SELECT ProviderID, MAX(MultiAddressInd) AS maxadd
					FROM edps_data.dbo.EDS_ProviderAddressDim 
					WHERE AddressTypeCode = 'PA'
					 --AND AddressLine1 NOT LIKE '%PO%' -- TETDM 2132
					 AND SourceDataKey IN (30,50)
					GROUP BY ProviderID) x ON x.ProviderID = pad.ProviderID AND pad.MultiAddressInd =  x.maxadd  
					--AND pad.AddressLine1 NOT LIKE '%PO%' -- TETDM 2132
		)y ON y.ProviderID = oph.BILL_PROV_GRP_ID
      WHERE oph.BILL_PROV_ADDR1 IS NULL OR oph.BILL_PROV_ADDR1 = ''

	  -- clean up when there isn't an address in the Provider Address Dim table
	  UPDATE dbo.OUTB_PROF_HEADER
	  SET BILL_PROV_ADDR1 = ''
	  FROM dbo.OUTB_PROF_HEADER oph
	  where oph.BILL_PROV_ADDR1 IS NULL
	  UPDATE dbo.OUTB_PROF_HEADER
	  SET BILL_PROV_ADDR2 = ''
	  FROM dbo.OUTB_PROF_HEADER oph
	  where oph.BILL_PROV_ADDR2 IS NULL
	  UPDATE dbo.OUTB_PROF_HEADER
	  SET BILL_PROV_CITY = ''
	  FROM dbo.OUTB_PROF_HEADER oph
	  where oph.BILL_PROV_CITY IS NULL
	  UPDATE dbo.OUTB_PROF_HEADER
	  SET BILL_PROV_STATE = ''
	  FROM dbo.OUTB_PROF_HEADER oph
	  where oph.BILL_PROV_state IS NULL
	  UPDATE dbo.OUTB_PROF_HEADER
	  SET BILL_PROV_ZIP = ''
	  FROM dbo.OUTB_PROF_HEADER oph
	  where oph.BILL_PROV_ZIP IS NULL
	  UPDATE dbo.OUTB_PROF_HEADER
	  SET BILL_PROV_ZIP4 = ''
	  FROM dbo.OUTB_PROF_HEADER oph
	  where oph.BILL_PROV_ZIP4 IS NULL

	  
-------------- end TETDM-2075---------------------------------------------------------------------------------

	  -- TETDM-2290 SourceDataKey = 30 (LEON) NEWQUEST Billing Provider overlay

	 UPDATE OUTB_PROF_HEADER
			SET  
			     BILL_PROV_FNAME = rtrim(ltrim(substring(RENDERING_PROV_ORG_NAME, CHARINDEX(' ', RENDERING_PROV_ORG_NAME) -25, 25)))
				,BILL_PROV_LNAME = rtrim(ltrim(substring(RENDERING_PROV_ORG_NAME, CHARINDEX(' ', RENDERING_PROV_ORG_NAME) + 1, 25)))
				,BILL_PROV_ORG_NAME = ''
			    ,RENDERING_PROV_ORG_NAME = ''
				,BILL_PROV_NPI = RENDERING_PROV_NPI 
				,RENDERING_PROV_NPI ='' 
			WHERE BILL_PROV_ORG_NAME like '%NEWQUEST%' 
			        AND SYSTEM_SOURCE = '30'
					AND BILL_PROV_NPI = ''
					AND BILL_PROV_GRP_NPI =''
					




	 /*************1979 from here************/
		

		UPDATE OUTB_PROF_HEADER
		SET
			 [REF_PROV_LNAME]			= ' '		
			,[REF_PROV_FNAME]  			= ' '
			,[REF_PROV_MID_INIT]  		= ' '
			,[REF_PROV_SFX]  			= ' '
			,[REF_PROV_NPI] 			= ' '
			,[REF_PROV_TAXONOMY_CD]  	= ' '
			,[REF_PROV_LICENSE_NO] 		= ' '
			,[REF_PROV_UPIN] 			= ' '
			--,[REF_PROV_ID] 			= ' '
			,[REF_PCP_LNAME]  			= ' '
			,[REF_PCP_FNAME]  			= ' '
			,[REF_PCP_MID_INIT]  		= ' '
			,[REF_PCP_SFX]  			= ' '
			,[REF_PCP_PROV_NPI]  		= ' '
			,[REF_PCP_TAXONOMY_CD]  	= ' '
			,[REF_PCP_LICENSE_NO] 		= ' '
			,[REF_PCP_PROV_UPIN] 		= ' '
			,[REF_PCP_PROV_ID] 			= ' '
		WHERE ISNULL(REF_PROV_NPI,' ')	= ' '



		UPDATE OUTB_PROF_HEADER
		SET
			 [RENDERING_PROV_LAST_NAME]		= ' '
			,[RENDERING_PROV_FIRST_NAME] 	= ' '
			,[RENDERING_PROV_MID_INIT]   	= ' '
			,[RENDERING_PROV_SFX]			= ' '
			--,[RENDERING_PROV_NPI]			= ' '
			,[RENDERING_PROV_ID] 			= ' '
			,[RENDERING_PROV_TAXONOMY] 		= ' '
			,[RENDERING_PROV_ORG_NAME] 		= ' '
			,[RENDERING_PROV_GRP_ID] 		= ' '
		WHERE ISNULL(RENDERING_PROV_NPI,' ')	= ' '


	 /*************1979 to here************/

	--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_PROF_HEADER_RESEND
							 
		SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_HEADER)
	----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_PROF_EDSPROVIDER'
							AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
               
                                              
                                            






