﻿
CREATE PROCEDURE [dbo].[EXSP_CLAIM_EXCLUSION_HIST]    
--(@sourcedatekey int)    
AS    
    
/***************************************************************************************************    
** CREATE DATE: 10/26/2012    
**    
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM    
**    
** DESCRIPTION: Procedure will identify all HS Claims eligible for HRP Claim Encounter File Exclusion.    
**               HRP Claim File Exclusion Logic:    
**				 #1 - HRP CMS ICN Claims - Exclude all claims from current outbound claim file(s) that     
**				 have a current HRP claim status of Accepted AND a CMS ICN number.     
**				 #2 - HRP Accpeted Claims - Exclude all claims from current claim file(s) that have a     
**				 current HRP claim status of Accepted.     
**				 #3 - HRP Rejected Claim - Exclude all claims from current claim file(s) that have a     
**				 current status of Rejected AND the last EDPS update is within last 31 days.     
**				 #4 - HRP Recently submitted Claim - Exclude all claims from current claim file(s) that do not     
**				 have a current status AND the last EDPS update is within last 14 days.     
**    
Modification History    
====================    
Date			Who				Description    
    
--------------------------------------------------------------------------------------------------------------------------------------------------------------    
01/03/13		LOYAL RICKS		ADD HPLAN EXCLUSION LOGIC    
01/05/2013		LOYAL RICKS		ADD PARAMERTER VALUES @EXCL_DAYS,@REJ_EXCL_DAYS	    
01/17/13		LOYAL RICKS		REMOVE USE OF ##EDPSPROD_CLMSTAT, REPLACE WITH VW_HRP_CLAIM_STATUS    
02/18/13		LOYAL RICKS		USE #TMP INSTEAD OF ##TMP    
03/06/2012		LOYAL RICKS		HPLAN EXCLUDE REVISION WHERE ACTIVE_FLAG = 'Y', ONLY ACTIVE ROWS    
03/06/2012		LOYAL RICKS		ADD NEW CLAIM EXCLUSION LOGIC - EXCLUDE FROM OUTBOUND SUBMISSION     
								ALL CLAIMS THAT HAVE A EDPS_Data.dbo.claimdetaildim LILNE WITH AT LEAST 1 BEGINSERVICEDATEKEY    
								ON OR AFTER THE FIRST DAY OF THE PREVIOUS MONTH FOR THE DAY OF EXECUTION.    
								EXAMPLE: Process is executed on 3/6/13, all claims with at least 1 service line    
								beginservicedatekey is >= 2/1/13 (Greater than or equal to)     
03/22/2012		LOYAL RICKS		EZCap Intrest claims exlcusion added to invalid procedure code list    
								EZCap invalid diagnosis code added	    
03/26/2013						Remove 2013 DOS Exclusions		    
04/07/13						Add Provider exclusion logic    
04/23/2013						Add exclusion for claims that are not in EDPS_Data.DBO.ClaimDiagnosisDim, these claims    
								are missing pointer information. Additional logic may be needed to derrive    
								pointers.    
05/13/2012		Loyal Ricks		Alter EXT_HRP_CLAIM_EXCLUSION - Add EXCL_ID on insert for every exclusion category    
								Revise process to support required maintenance to support dbo.EXT_CLAIM_EXCLUSION_HIST     
								table which will be used via RRS reporting.	    
05/14/2013		Loyal Ricks		Invalid PlaceofServiceCode (EDPS_Data.dbo.claimdetaildim)	    
06/25/2013		Loyal Ricks		Revise Exclusion Code 9001, 360 & Exams to include wild card seach     
07/13/2013		Loyal Ricks		Add Exclusion 9009 - POS (21,51,61) and Invalid Admissiondatekey     
08/27/2013		Loyal Ricks		Revise Exclusion - 9001 Exams•	Add claim_type = ‘P’ to logic to the below criteria,    
								procedurecode contains the string ‘MA36’,"HMR","360"    
08/27/2013		Loyal Ricks		Revise Exclusion Code – 9002 Interest Payments - Add Wild card logic -     
								procedure code contains the string “$INT”,”INT”,”OL”    
08/27/2013		Loyal Ricks		Revise Exclusion Code – 9003 - Add wild card logic -     
								Where EDPS_Data.DBO.ClaimDiagnosisDim.diagnosiscode contains the string “ZZZ”		    
09/06/13		Loyal Ricks		Remove 9006 "Provider Exclusion" logic. Logic replaced with EXSP_HRP_CLAIM_EXCLUSION_9006    
11/08/13		Loyal Ricks		Remove 9002 "Penalty Payment" Exclusions only for professional claims. Outbound professional claims	    
								code supports the submission of penaly payments using the Verisk deleted line logic.    
11/26/13		Loyal Ricks		Temporarily remove 9005 exclusion. Removal of exclusion to test impact removal will have on these claims    
11/26/13		Loyal Ricks		Revise exclusion 9001 Exams logic, Check "claim type" for QNXT & MHC claims to ensure only professional claims    
								are excluded. Revenue codes and procedure codes share the EDPS_Data.dbo.claimdetaildim.procedurecode field. As a result some    
								institutional claims with a rev code = 360 are being held by this exclusion.    
01/30/14		Loyal Ricks		Remove call to EXSP_HRP_CLAIM_eXCLUSION_9006 - "Lift 9006 exclusion" due to provider cleanup currently underway    
								to support compass conversion.	    
02/11/14		Loyal Ricks		Add 9010 - Invalid Bill type Exclusion		    
03/03/14		Loyal Ricks		Add 9011 - 2014 DOS     
03/05/14		Loyal Ricks		Remove 9011 - comment out until proper approval has been obtained.    
03/11/14		Loyal Ricks		Add 9012 - Institutional DOS >= 20130101 Exclusion. Exclusion supports 2012 Institutional Claim discontinue pursuit    
								project. Exclsuions is temporary while Institutional 2012 claims are submitted.    
03/31/14		Loyal Ricks		Add Discontinue Pursuit Configuration Code - Logic will allow for the configuration of discontinue pursuit claims    
								using parameters that are stored in the EXT_SYS_CLM_JOBCNTRL tables. Values must be configured and validated prior    
								to the execution of this stored procedure. 	    
05/01/14		Loyal Ricks		Revise Exclusion 9008 to only include professional claims 		    
-------------------------------------------------------------------------------------------------------------------------------------------------------------------    
08/27/14		Loyal Ricks		WIPRO Implementation Build    
    
08/27/14		Loyal Ricks		Add 9018 - Claims missing line level pointer information - claimdetaildiagnosisdim    
09/23/14		Loyal Ricks		Add 9019 - Adjusted claim - replacement/voids     
								Add 9020 - None MAO Medicare or MMAI claims    
								Add 9021 - Denied    
								Add 9021 - Inactive     
09/29/14		Loyal Ricks		Add 999999999 - Claims processed by Verisk Health    
12/04/14		Loyal Ricks		Performance & fine tuning    
								removal of explicit transactions    
								removal of use of temp tables for large volume of data,use user tables with truncate    
02/09/15		Loyal Ricks		EDS-712 - Add 9024 - MMAI Texas - HPLAN H8423 - Temporary Exclusion used while HPLAN is configured and prepared for testing    
								Add exclusion 9023     
02/27/15		Loyal Ricks		Add Facets Adjusted claim (replace/void) exclusion per Facets adjustment meeting on 2/27. When Facets claimid > 10 identify claim    
								as adjusted.    
05/05/15		Loyal Ricks		Add Exclid - 9025 TETDM-98 Bill Type Code exclusion 24x     
05/05/15		Loyal Ricks		Add Exclid - 9026 dashes in diagnosiscode CLAIMDETAILDIAGNOSISDIM    
06/01/15		Loyal Ricks		Add Exclid - 9028 TETDM-116-Institutional Bill Type 75X AND REVCD exists    
07/14/15		Loyal Ricks		Add Exclid - 8000 TETDM-264 Production Exclusion Captiated Claims    
07/15/15		Loyal Ricks		Add Exclid - 8002 TETDM-263	--Production Exclusion Ambulance    
07/20/15		Loyal Ricks		Add append of production exclusions - EXT_PROD_CLAIM_EXCLUSION_HIST	    
08/03/15		Loyal Ricks		Add Exclid - 8004 - TEDM-304 - Exclude claims that have at least one claim line with a COB_AMT > 0 		    
08/05/15		Loyal Ricks		Add Excl_id - 9030 - TETDM-305 Previously submitted Facets Professional Claims that are Institutional based on BIDW addition of Facets claim type	    
08/24/15		Loyal Ricks		Add Excl_id - 9031 - TETDM-316	- Mixed Insitutional Capped and Fee for Service Claims	    
09/01/15		Loyal Ricks		Remove Excl_id - 8000 only for QNXT based on test results - TETDM-336- Remove Exclusion for QNXT only based on QA pass	    
09/04/15		Loyal Ricks		Add Excl_id - 9033 - TETDM-343 - PROD Logic Change - Balancing Fix - Paid amt greater than requested	    
09/09/15		Loyal Ricks		Add Excl_id - 9034 - TETDM-345 - Create exclusion for $0 billed $0 paid AND CAPITATEDLINEFLAG = 'Y'	    
09/30/15		Loyal Ricks		Revise Excl_id - 9033 Add additional logic to exclude when withholdamt = 0 Only    
09/30/15		Loyal ricks		Add Excl_id - 9035 - TETDM-374 - Balancing Fix - Paid amt greater than requested and sequestered amount is greater than zero				    
10/08/15		Loyal Ricks		Revise Excl_id - 9018 Add logic to only exclude Professional Claims. Exclusion was excluding all claims in error    
10/17/15		Loyal Ricks		Add Excl_id 8010 - TETDM-439 ICD-10 Exclusion-  ICD10 Claims Exclusion - Exclude all claims that have at least one claim line with a valid ICD-10 code    
10/17/15		Loyal Ricks		Add Excl_id 80101 - TETDM-439 ICD-10 Exclusion - All Claims Exclusion - Due to EDS ICD10 update issues all claims that are not currently being excluded     
								will be placed in this exclusion bucket. This will prevent all claims from being submitted to WIPRO while EDS technical team    
								works on ICD10 update issues.    
10/22/15		Loyal Ricks		TETDM-439 - Remove Excl_id 80101 - BIDW ICD10 refresh completed.	    
10/23/15		Loyal Ricks		Revised logic TETDM-439 ICD-10 Exclusion - Excl_id - 8010 to include values of 0 and 10 for sources. DiagnosisCodeVersion in ('0', '10')    
10/27/15		Loyal Ricks		TETDM-439 - Revised temporary ICD-10 ExclId-80101 to apply exclusion to all Facets claims due to upstream ICD10 issues.     
11/20/15		Loyal Ricks		TETDM-544 - Lifted Excl_id 9033		    
12/01/15		Loyal Ricks		TETDM-554 - Remove Exclusion for Facets Professional Claims    
12/02/15		Loyal Ricks		Add Excl_id 9036 - TETDM-549 - Contract Amount greater than Billed Amount    
12/02/15		Loyal Ricks		TETDM-559 Modify Excl_id 80101    
01/13/16		Loyal Ricks		Add Excl_id 9038 - TETDM-605 - Missing Claimdetaildim',0,'All'    
01/22/16		Loyal Ricks		Revise Excl_id 8010 - Exclude sourcedatakey = 50 and claim_type = 'P'    
01/22/16		Loyal Ricks		TETDM-199, TETDM-200, TETDM-201 - Remove Previously Rejected - Add append of production exclusions - EXT_PROD_CLAIM_EXCLUSION_HIST    
01/25/16		Loyal Ricks		Add ExclId - 9039 ----TETDM-622     
01/25/16		Loyal Ricks		Revise Excl_id - 9020 remove MMAI CAID from exclusion.    
01/29/16		Loyal Ricks		Remove exclusion id 9024 MMAI TX exclusion    
03/18/16		Loyal Ricks		TETDM-676 Life Exclusion 9034 only for QNXT    
03/18/16		Loyal Ricks		TETDM-684 Lift for QNXT    
03/22/16		Loyal Ricks		Add exclusion id - 9040 - TETDM-694 Invalid External Cause of InjuryCode     
03/24/16		Loyal Ricks		Add Exclusion id - 9041 - TETDM-695 Admit Diag Mismatch     
03/25/16		Loyal Ricks		Add Exclusion id - 9042 - TETDM-709 BIDW Refresh Claims missing ub921admissiondim    
04/04/16		Loyal Ricks		TETDM-717 Lift Exclusion id - 9035    
04/04/16		Loyal Ricks		TETDM-718 Lift Exclusion id - 9036    
04/05/16		Loyal Ricks		Add Exclusion Id - 9043 - TETDM-710 Claims with Multiple Claimdetaildiagnosisdim records with a unique Sequence number    
04/05/16		Loyal Ricks		Reapply exclusion id 9036 - TETDM-718 Lift Exclusion id - 9036. Exclusion being reapplied in dev due to EDS need to apply an     
								exclusion code migration "hot fix" that will allow exlcusion id 9043 to be released to production to support production submission     
								issues causing bad files. This exclusion will get lifted once the production hot fix has been applied.     
04/13/16		Loyal Ricks		TETDM-744 Revise Excl_id 8002 -  Revise code to only exclude I claims    
04/18/16		Loyal Ricks		Add Exclusion Id - 9044 - TETDM-752 Facets Claims with Multiple Claimdiagnosisdim records with multiple records with the same sequence number.    
04/18/16		Loyal Ricks		Add Exclusion Id - 9045 - TETDM-753 Facets Claims - Claimdiagnosisdim - Multiple Primary DiagnosisCodes records    
05/02/16		Loyal Ricks		TETDM-743 - Remove Facets Professional Claims from this exclusion (8010,80101)    
05/04/16		Loyal Ricks		Excl_id 9009 - Add distinct claimid to logic to prevent duplicate records    
05/10/16		Loyal Ricks		TETDM-718 Lift Exclusion id - 9036     
05/10/16		Loyal Ricks		TETDM-744 Lift Exclusion id - 8002    
05/13/16		Loyal Ricks		EMC-982 Lift Exclusions - 9040 and 9041    
05/26/16		Loyal Ricks		Exclusion Production Hot Fix Adjustments - Reapply the following exclusion (9036,9040,9041) in order to complete the required production exclusion     
								hotfix.    
05/27/16		Loyal Ricks		TETDM-834 Lift Exclusion Id - 9009	    
05/31/16		Loyal Ricks		Revise Exclusion 9001 	    
06/01/16		Loyal Ricks		Revise Exclusion 9001 Remove sdk 3,30 and revise logic for 2,50		    
06/14/16		Loyal Ricks		Add - TETDM-824 Facets Institutional When The Payer Claim Control Number is Present		    
06/15/16		Loyal Ricks		TETDM-850 - Modify Excl_id 9020 to only include MMAI exclusion, removing other associated logic to a new exclusion code    
06/15/16		Loyal Ricks		TETDM-850 - Create new exclusion from existing 9020 exclusion logic for non MMAI claims    
06/16/16		Loyal Ricks		TETDM-840 - Lift Excl_id (8010,80101) Facets I Claims    
07/15/16		Loyal Ricks		Add logic for encounterclaimdim DP exclusion    
07/27/16		Loyal Ricks 	TETDM-808 Lift exclusion 9040    
07/27/16		Loyal Ricks 	TETDM-809 Lift exclusion 9041    
07/27/16		Loyal Ricks		TETDM-840 Turn back on to support production hot fix    
08/02/16		Loyal Ricks		TETDM-853 Lift for Facets Professional Claims, Facets I claims are the only source remaining in this exclusion.    
08/24/16		Loyal Ricks		TETDM-840 Lift exclusion (Facets/All) 8010 and 80101    
08/24/16		Loyal Ricks		TETDM-853 Lift exclusion (Facets I/All) 9034    
09/06/16		Loyal Ricks		TETDM-913 - Lift exclusion 8000    
09/06/16		Loyal Ricks		TETDM-972 lift DME exclusion 9999    
09/16/16		Loyal Ricks		TETDM-1064 - Excl_id 9048 - Denied Claim invalid procedure code     
09/16/16		Loyal Ricks		TETDM-1070 - Excl_id 9049 -  Claim invalid procedure code      
10/10/16		Loyal Ricks		TETDM-1166 - Lift QNXT MAO Professional Denied Claims    
10/12/16		Loyal Ricks		TETDM-1166 - Lift QNXT MAO Institutional Denied Claims    
10/14/16		Loyal Ricks		TETDM-1187 Delete all other exclusions for DP claims    
11/17/16		Loyal Ricks		TETDM-1166 - Revise exclusion logic to include all MMAI claims. Issues found that only Prof. MMAI claims where being excluded.    
12/14/16		Loyal Ricks		TETDM-862 - Remove Exclusion Id 9031    
12/14/16		Loyal Ricks		TETDM-1282 - Remove Exclusion Id 8004    
12/14/16		Loyal Ricks		TETDM-1377 -Delete all other exclusions for Adjusted Claims except 9019    
01/13/17		Loyal Ricks		TETDM-1279 Remove exclusion 9023    
01/19/17		Loyal Ricks		TETDM-718 Lift exclusion 9036 for QNXT Professional Claims    
03/09/17        John Bartholomay TETDM-1403 Lift exclusion 9036 for Facets Institutional  
04/05/17        John Bartholomay TETDM-1446 9050 Exclusion for SDK=50 for Total Claim Amt > 9999999.99  
05/09/17        John Bartholomay TETDM-1493 Lift 9036 for QNXT I Claims 
05/15/17        John Bartholomay TETDM-1502 Lift 9050 for QNXT  
05/22/17        John Bartholomay ?????-???? Add back in 9020 exclusion as per Scott W. for testing 
05/25/17		Patricia Greenlea	tetdm-1286 lift 9020 Exclusion 
09/16/17		Subhash Acharya	 TETDM-1436 lift 9021 Exclusion
10/26/17        John Bartholomay TETDM-2436 lift only I not P for 9021 Exclusion
12/06/17		Mike Vega		 TETDM-1644 Modified the 9020 Exclusion so that it keeps the not equal to "Medicare/Medicaid" (UNKNOWN) exclusion but added where DENIEDFLAG <> 1
12/19/17		Mike Vega		 TETDM-1644 Add'l requirement ID'd during Deploy, Add UPDATE script from John's DEP-537 per Tracy. Added to end of this process to do final update of HIST table
-------------------------------------------------------------------------------------------------------------------------------------------------
01/15/18        John Bartholomay TETDM-1637 remove 9021 for sdk=30 and denied claims
01/22/18        Henry Faust      TETDM-1650/1722 add 5 specific claims to the Exclusion History table EXCL_ID = 9052
02/02/18        Henry Faust      TETDM_1521 remove SDK 2,3,40 and EXCL_ID 999999999 
04/23/18		Scott Waller	TETDM-1791 Create exclusion to capture claims with Rev code D
04/25/18		Scott Waller	TETDM-1745 Turn off exclusion 9030 for SDK30 and submit claims as Institutional claims
04/25/18		Scott Waller	TETDM-1793 Turn off exclusion 9044
05/02/18		Scott Waller	TETDM-1787 New exclusion 8012 to exclude claims for 
								LOB's 'C54240970', 'C42644396', 'C45137428', 'UMISC0028042858'
05/02/18		Scott Waller	TETDM-1782	New exclusion 9053 Termed Members with no Hplan
11/26/10        Henry Faust     TETDM-1887 -Exclusion for member reimbursement claims SDK30
03/26/19        Henry Faust     TETDM-1977 REMOVE EXCLUSION 9025
03/26/19        Henry Faust     TETDM-1980 REMOVE EXCLUSION 9000
03/26/19        Henry Faust     TETDM-1980 REMOVE EXCLUSION 9021
04/25/19        Henry Faust     TETDM-1988 Remove Exclusion 9007
05/02/19        Henry Faust     TETDM-1988/1990/1991/2001/2002/2003/2004 turn of 9007/9008/9049/9052/9010/9018/9039
05/13/19		Scott Waller	TETDM-2047	Clean up redundant claim data.  These EXCL_ID's are inserting claimid's into the table more than once.  
								9001, 9008, 9019, 9039, 9047.   This is unneccessary.  (9008 and 9039 were just turned off but I will change the logic
								in case they are turned back on in the future).
								Also, replace GETDATE() on each INSERT statement, with a variable that gets the GETDATE() value one time at the
								beginning of the sproc.  THis way all rows in this table generated at  the same time will have the same 
								exclusion date.
06/11/10        Henry Faust     TETDM-2060/2061/2062 remove exclusion 9001, 9043 and 9048
07/24/2019      Henry Faust     TETDM-2091 turn back on 9038 , just un-comment the code
07/24/2019      Henry Faust     TETDM-2089 add to 9053 all claims in CALIMDIM with LOB = UNKNOWN
08/19/2019		Scott Waller	TETDM-2103 The EXSP_CLAIM_EXCLUSION_HIST sproc in the WIPRO database, hangs up from time to time, in PROD ONLY.  
								It can run in prod between 1-2 hours but can also take 4-6 hours.  I have identified two areas of logic for two different 
								exclusions (9056 and 9020) and need to be rewritten.  Full details in the JIRA ticket.
09/27/2019     Henry Faust		TETDM-2118- updae 9019 to inculde claims with Frequency Coe 7,8 and have not been sent to Wipro
                                Null in OUTB_Claim_Status table and claim_stat field
11/05/2019     Henry Faust		TETDM-2119 remove the Denied Flag <>1 from 9020 exlcusions
11/11/2019     Aaron Ridley     TETDM-2168 - Set sourcedatakey to 50 for freq 8/7. Prevent duplicate 9019 errors
01/07/2020     Henry Faust      TETDM-2212 update 8020 to include SDK 30,50 I and P claims
01/10/2020     Henry Faust      TETDM-2211 update 9053 to include SDK 4 where claim not in coverage dates
02/20/2020		Scott Waller	TETDM-2236 add a single claimid to this sproc
07/14/2020     Henry Faust      TETDM-2298   Add 180120033000 to Exclusion 8012
07/30/2020     Aaron Ridley     TETDM-2298 Removed 180120033000 (Invalid logic) Resetting change
08/12/2020		Scott Waller	TETDM-2299 Update to Exclusion 9053.  Add claims to 9053 if they have a MemberID that 
								does not exist in the MDQOLib.dbo.MemberDim table.
08/25/2020     Aaron Ridley     TETDM-2345 Add LEON exclusions for frequency codes 7,8
11/16/2020	   ASU				TETDM-2389 add 'A-Ace','UnWrk' as exclusion ID 5
01/13/2021		Scott Waller	TETDM-2417 Update exclusion id 9038 to include claims that have a formtypecode of U in the claimdim table 
								and claimlinerevenuecode is blank or NULL.
02/05/21021     Henry Faust     TETDM-2453  Claim Adj , exclude claims that have aready been sent, have a record in the 
                                OUTB_CLAIM_STATUS table for Excl 9019
04/29/2021		Aaron Ridley	TETDM-2472 - Uncommented out code to exclude unaccepted frequency code 7/8 for QNXT
06/28/2021  	Subhash Acharya	 TETDM-2529 lift 9046 Exclusion (claimexclusionCode)
09/27/2021		Scott Waller	TETDM-2587 create Exclusion 8022 for all older (pre BIDW Cutoff date) claims that have been recently modified.  We bring
								them over in the Refresh, but they are not meant to be submitted.  This is an easy way for the BA team to account for them.
11/12/2021		Scott Waller	TETDM-2620 Ash has requested a new exclusion, 9063 'Vendor_INHome_Claim'

02/22/2022		Scott Waller	REBT-39  Exclusion 9053 is hardcoded for specific vendors.  We are adding EYEMED vendor to our submissions.  Need to 
								add EYEMED to the 9053 encounter logic.

04/18/2022		Scott Waller	RETM-53 Preclusion Provider Exclusion.  Exclusion ID 9064.

10/19/2022		Scott Waller	RETM-154 new exclusion, 9070, for all claims that have no Primary DX code

12/13/2022		Scott Waller	RETM-160 the logic for Excl 9070 ONLY inserts claims if they are NOT in another 
								exclusion.  Tracy Black has noted that we have Adjustment claims that end up in 
								excl 9019 ALSO need to be in 9070.  This ticket is for making that slight change to correct this.

01/30/2023		Scott Waller	RETM-179 New Exclusion:  9071  'Leon claims with date of service 1/1/23 and greater'

02/24/2023		Scott Waller	RETM-206 addition logic to add to the EXCL 9070 logic

07/12/2023		Aaron Ridley	RETM-326 Comment out Alegis exclusion to allow for the release of these claims

09/08/2023		Scott Waller	RETM-435 Addtional logic for the 9070 claim exclusion.  
								Moving claims that dont have a Primary Diagnosis in sequence 01, but has 
								a primary diagnosis in any other sequence, into 9070.

09/03/2024		Scott Waller	RETM-741	Minor fix to the 9064 Exclusion.  The date comparison of 
								ClaimDim.BeginServiceDateKey to ProviderPreclusionList.ReinDate, and the problem lies with 
								some 3400 claims that have a NULL value for REINDATE.  The comparison is FALSE but should
								be true.   Adding a ISNULL(REINDATE, '21991231') to resolve.

*******************************************************************************************************************************************************************/	    
--DECLARE VARIABLES    
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND    
			DECLARE    
		    
			@TOTAL_RECORDS INT    
			,@EXCL_DAYS		INT    
			,@REJ_EXCL_DAYS	INT    
			,@CURRENTDATE	DATE

--TETDM-2047
		select @CURRENTDATE = getdate()
			    
			--HRP_CLAIM_FILE Run controls    
					INSERT INTO EXT_SYS_RUNLOG    
							(PROC_NAME    
							,STEP    
							,START_DT    
							,END_DT    
							,RUN_MINUTES    
							,TOTAL_RECORDS    
							,ENTRYDT    
							)    
					VALUES('EXSP_CLAIM_EXCLUSION_HIST'    
							,'1'    
							,GETDATE()    
							,NULL    
							,NULL    
							,0    
							,GETDATE()    
							)    
					    
		--ASSIGN VARIABLES     
								--TRUNCATE EXT_HRP_CLAIM_EXCLUSION TABLE       
								TRUNCATE TABLE  dbo.EXT_CLAIM_EXCLUSION_HIST    
   
								--EXCLUSION #5 - HPLAN DO NOT SEND    
								--    
								-- 01/09/14 - MDQO Code Requirement revisions, revised #TMP_HPLAN_EXLCUDE    
								--    
								IF OBJECT_ID('TEMPDB..#TMP_HPLAN_EXCLUDE') <> 0    
									DROP TABLE #TMP_HPLAN_EXCLUDE    
		    
										CREATE TABLE #TMP_HPLAN_EXCLUDE    
		    
										( LOBCODE VARCHAR(15),    
											DOS DATE     
										)    

								INSERT INTO #TMP_HPLAN_EXCLUDE    
								SELECT LOBCODE,    
										H.EXCLUSION_DT    
								FROM EXT_HPLAN_EXCLUDE H    
								JOIN MDQOLib.DBO.LineofBusinessDim L    
								ON H.HPLAN = L.HCFACode    
								WHERE H.ACTIVE_FLAG = 'Y'    

								--USE EDPS_Data.dbo.CLAIMDIM.LOBCODE TO IDENTIFY LINEOFBUSINESSDIM.HFCACODE IN WHICH CLAIMS SHOULD NOT GET SUBMITTED    
----TETDM-1980 remove 9000								    
--								INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
--								SELECT  CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9000,' '     
--								FROM EDPS_Data.dbo.CLAIMDIM C    
--								JOIN #TMP_HPLAN_EXCLUDE T    
--								ON C.LOBCODE = T.LOBCODE    
--								WHERE CONVERT(CHAR(10), C.BeginServiceDateKey) >= T.DOS     
--									OR CONVERT(CHAR(10), C.EndServiceDateKey) >= T.DOS    
--end tetdm-1980								    
    
								--Invalid procedure code exclusions    
								--EZCap & Facets EXAMS - MMR/360    
								    
								--EZCap & Facets EXAMS - MMR/360    
								    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select distinct ClaimID,SOURCEDATAKEY,@CURRENTDATE,9001,' '     
								--		from EDPS_Data.dbo.claimdetaildim     
								--		where  sourcedatakey in ('3','30')    
								--			and ProcedureCode in ('360','360 FORM','HMR','HMR12')    
    
    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select distinct ClaimID,SOURCEDATAKEY,@CURRENTDATE,9001,' '     
								--		from EDPS_Data.dbo.claimdetaildim     
								--		where  sourcedatakey in ('3','30')    
								--			AND charindex('MA36',PROCEDURECODE) > 0    
    
    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select distinct ClaimID,SOURCEDATAKEY,@CURRENTDATE,9001,' '     
								--		from EDPS_Data.dbo.claimdetaildim     
								--		where  sourcedatakey in ('3','30')    
								--			AND CHARINDEX('HMR',PROCEDURECODE) > 0    
    
    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select distinct ClaimID,SOURCEDATAKEY,@CURRENTDATE,9001,' '     
								--		from EDPS_Data.dbo.claimdetaildim     
								--		where  sourcedatakey in ('3','30')    
								--			AND  CHARINDEX('360',PROCEDURECODE) > 0     
										    
								--Invalid procedure code exclusions    
								--MHC & QNXT EXAMS - MMR/360    
--tetdm-2062	Turn off 9001 Begin							    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select  DISTINCT c.ClaimID,c.SOURCEDATAKEY,@CURRENTDATE,9001,' '	-- TETDM-2047
								--		from EDPS_Data.dbo.CLAIMDIM c    
								--		join EDPS_Data.dbo.claimdetaildim cd    
								--		on c.CLAIMID = cd.CLAIMID    
								--		and c.SOURCEDATAKEY = cd.SOURCEDATAKEY    
								--		where  c.SOURCEDATAKEY in ('2','50')    
								--			and c.FORMTYPECODE = 'H'    
								--			and  ProcedureCode in ('360','360 FORM','HMR','HMR12')    
    
								--	INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select  DISTINCT c.ClaimID,c.SOURCEDATAKEY,@CURRENTDATE,9001,' '     -- TETDM-2047
								--		from EDPS_Data.dbo.CLAIMDIM c    
								--		join EDPS_Data.dbo.claimdetaildim cd    
								--		on c.CLAIMID = cd.CLAIMID    
								--		and c.SOURCEDATAKEY = cd.SOURCEDATAKEY    
								--		where  c.SOURCEDATAKEY in ('2','50')    
								--			and c.FORMTYPECODE = 'H'    
								--			AND charindex('MA36',PROCEDURECODE) > 0    
--TETDM-2060 end
/*     TETDM-2047	This block of code is redundant and puts duplicate claims into the Exclusion table.
					'HMR' is already checked for in the first 9001 code

									INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								select  DISTINCT c.ClaimID,c.SOURCEDATAKEY,@CURRENTDATE,9001,' '     -- TETDM-2047
										from EDPS_Data.dbo.CLAIMDIM c    
										join EDPS_Data.dbo.claimdetaildim cd    
										on c.CLAIMID = cd.CLAIMID    
										and c.SOURCEDATAKEY = cd.SOURCEDATAKEY    
										where  c.SOURCEDATAKEY in ('2','50')    
											and c.FORMTYPECODE = 'H'    
											AND CHARINDEX('HMR',PROCEDURECODE) > 0    
*/    
								--				INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select  c.ClaimID,c.SOURCEDATAKEY,@CURRENTDATE,9001,' '     
								--		from EDPS_Data.dbo.CLAIMDIM c    
								--		join EDPS_Data.dbo.claimdetaildim cd    
								--		on c.CLAIMID = cd.CLAIMID    
								--		and c.SOURCEDATAKEY = cd.SOURCEDATAKEY    
								--		where  c.SOURCEDATAKEY in ('2','50')    
								--			and c.FORMTYPECODE = 'H'    
								--			AND CHARINDEX('360',PROCEDURECODE) > 0     
											    
								--PENALTY PAYMENTS - Institutional Claims Only    
										--	IF OBJECT_ID('TEMPDB..#tmp_9002') <> 0    
										--DROP TABLE #tmp_9002    
										    
										--create table #tmp_9002    
										--(claimid varchar(20)    
										--,formtypecode varchar(1)    
										--,serviceplacecode varchar(4)    
										--,sourcedatakey int    
										--)    
										    
										insert into dbo.EXT_CLAIM_EXCLUSION_HIST									    
										select c.CLAIMID    
											,c.sourcedatakey    
											,@CURRENTDATE    
											,9002    
											,CASE FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE FORMTYPECODE END    
										from EDPS_Data.dbo.CLAIMDIM c    
										join EDPS_Data.dbo.claimdetaildim cd    
										on c.CLAIMID = cd.CLAIMID    
										and c.SOURCEDATAKEY = cd.SOURCEDATAKEY    
										where cd.PROCEDURECODE in ('0L6','$INT')    

										--update #tmp_9002    
										--set serviceplacecode = cd.serviceplacecode     
										--from #tmp_9002 t    
										--join EDPS_Data.dbo.claimdetaildim cd    
										--on t.claimid = cd.CLAIMID    
										--and t.sourcedatakey = cd.SOURCEDATAKEY    
										--where t.formtypecode not in ('P','I')    
										--	AND CD.PROCEDURECODE IN ('0L6','$INT')    
										    
										--UPDATE #tmp_9002    
										--SET formtypecode = PC.CLAIM_TYPE    
										--FROM #tmp_9002 T    
										--JOIN EXT_POS_CD PC    
										--ON RTRIM(T.SERVICEPLACECODE) = RTRIM(PC.POS_CD)    
										--WHERE T.formtypecode not in ('P','I')    
										    
										    
										--APPEND Institutional penalty claims     
									    
											--insert into dbo.EXT_CLAIM_EXCLUSION_HIST    
											--select  ClaimID,SOURCEDATAKEY,@CURRENTDATE,9002,' '     
											--from #tmp_9002    
											--where formtypecode <> 'P'    
											---Compile ExclusionId - 9006 Bad Provider Records    
											    
													    
								--Invalid diagnsos code for     
											INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
											select distinct CLAIMID,SourceDataKey,@CURRENTDATE,9003,' '     
											from EDPS_Data.DBO.ClaimDiagnosisDim    
											where  DIAGNOSISDESC = 'INVALID DIAGNOSIS CODE'    
												or CHARINDEX('ZZZ',DIAGNOSISCODE) > 0    

    
								--Update Claim types from claimdim    
										--update dbo.EXT_CLAIM_EXCLUSION_HIST    
										--set claim_type = case c.formtypecode when 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE C.FORMTYPECODE END    
										--FROM dbo.EXT_CLAIM_EXCLUSION_HIST H    
										--INNER JOIN EDPS_DATA.DBO.CLAIMDIM C    
										--ON H.SOURCEDATAKEY = C.SOURCEDATAKEY    
										--AND H.CLAIM_ID = C.CLAIMID     
												    
								--STANDARD NEW CLAIM EXCLUSION    
								--EXCLUDE ALL CLAIMS WHERE THE BEGINSERVICEDATE > PREVIOUS MONTH FROM EXECUTION DATE    
									--begin transaction    
									--	INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
									--	SELECT DISTINCT CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9005,' '     
									--	FROM EDPS_Data.dbo.claimdetaildim     
									--	WHERE( BEGINSERVICEDATEKEY >= CONVERT(CHAR, DATEADD(M,-1,DATEADD(D,-DATEPART(D,GETDATE()-1),GETDATE())),112)     
									--		or ENDSERVICEDATEKEY >= CONVERT(CHAR, DATEADD(M,-1,DATEADD(D,-DATEPART(D,GETDATE()-1),GETDATE())),112)    
									--		)     
									--	IF @@ERROR <> 0    
									--		BEGIN    
									--			ROLLBACK    
									--		END    
									--	COMMIT	    
											    
										    
								    
								---claims with potential pointer issues    
--tetdm-1988 trun off 9007								    
									--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
									--select claimid 	,SOURCEDATAKEY,@CURRENTDATE,9007,' '     
									--from EDPS_Data.dbo.CLAIMDIM     
									--where  CLAIMID not in (select CLAIMID from EDPS_Data.DBO.ClaimDiagnosisDim )    
									    
								    
									---claims with invalid EDPS_Data.dbo.claimdetaildim.ServicePlaceCode    
									---    
									-- 5/1/14 - revised logic to include only professional claims    

--TETDM-1990 turn off 9008								    
										--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
										--select  DISTINCT C.claimid,C.SOURCEDATAKEY,@CURRENTDATE,9008, CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE C.FORMTYPECODE END    
										--from EDPS_Data.dbo.CLAIMDIM C    
										--INNER JOIN EDPS_Data.dbo.claimdetaildim CD    
										--ON C.CLAIMID = CD.CLAIMID    
										--AND C.SOURCEDATAKEY = CD.SOURCEDATAKEY     
										--where  substring(SERVICEPLACECODE,1,1) = '-'     
										--AND C.FORMTYPECODE = 'H'    
									                               
								    
									    
								--POS (21,51,61) and invalid admissiondatekey    
								--excl_id - 9009    
								---TETDM-834 Lift Exclusion 9009    
								    
								--IF OBJECT_ID('TEMPDB..#tmp_clm9009') <> 0    
								--		DROP TABLE #tmp_clm9009    
									--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
									--select  DISTINCT c.CLAIMID    
									--	--,c.ADMISSIONDATEKEY    
									--	--,cd.SERVICEPLACECODE    
									--	--,cd.BEGINSERVICEDATEKEY    
									--	--,cd.ENDSERVICEDATEKEY    
									--	--,cd.CLAIMLINEID    
									--	--,space(5) as 'clmstat_status'    
									--	--,SPACE(25) as 'fileid'    
									--	, c.SOURCEDATAKEY    
									--	,@CURRENTDATE    
									--	,9009    
									--		,case c.formtypecode when 'H' then 'P'    
									--				when 'U' then 'I'    
									--				else c.formtypecode end as 'claim_type'    
									--from EDPS_Data.dbo.CLAIMDIM c    
									--join EDPS_Data.dbo.claimdetaildim cd    
									--on c.CLAIMID = cd.CLAIMID    
									--and c.SOURCEDATAKEY = cd.SOURCEDATAKEY    
									--where  cd.SERVICEPLACECODE in ('21','51','61')    
									--	and len(c.ADMISSIONDATEKEY) < 8     
									    
								----get existing 9009 for @sourcedatakey    
								--IF OBJECT_ID('TEMPDB..#tmp_clm9009_hist') <> 0    
								--		DROP TABLE #tmp_clm9009_hist    
										    
								--	select  claim_id    
								--	into #tmp_clm9009_hist    
								--	from dbo.EXT_CLAIM_EXCLUSION_HIST    
								--	where  EXCL_ID = '9000'    
								--	order by claim_id    
    
								--	delete     
								--	from #tmp_clm9009    
								--	where CLAIMID in (select claim_id from #tmp_clm9009_hist)    
    
									    
											--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
											--SELECT  CLAIMID,SOURCEDATAKEY,@CURRENTDATE,'9009',claim_type    
											--FROM #tmp_clm9009    
											--ORDER BY SOURCEDATAKEY,CLAIMID    
										    
										---Compile ExclusionId - 9006 Bad Provider Records    
										--01/30/14 lift 9006 exclusions. this category is being lifted    
										--due to progress made with provider cleanup    
									--begin    
									--	Execute EXSP_HRP_CLAIM_EXCLUSION_9006    
									--end	    
						    
						    
--TETDM-2002 turn off 9010									    
											--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
											--SELECT  CLAIMID,SOURCEDATAKEY,@CURRENTDATE,'9010',' '    
											--FROM EDPS_Data.DBO.UB921ADMISSIONDIM    
											--where billtypecode between 'A' and 'Z'    
											--	or LEN(billtypecode) <= 2    
											--order by SourceDataKey,claimid    
											    
									    
									--- 2014 DOS Claims Exclusion     
									-- Exlcusion 9011    
									    
									--begin transaction     
									--		INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
									--		SELECT DISTINCT CLAIMID,SOURCEDATAKEY,@CURRENTDATE,'9011',case formtypecode when 'H' then 'P'    
									--																	when 'U' then 'I' else formtypecode end    
									--		from EDPS_Data.dbo.CLAIMDIM    
									--		where BeginServiceDateKey >= '20140101'    
									--			or EndServiceDateKey >= '20140101'    
									--		IF @@ERROR <> 0    
									--		BEGIN    
									--			ROLLBACK    
									--		END    
									--COMMIT    
									    
									--BEGIN TRANSACTION     
									--		INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
									--		SELECT DISTINCT CLAIMID,SOURCEDATAKEY,@CURRENTDATE,'9012',case formtypecode when 'H' then 'P'    
									--																when 'U' then 'I' else formtypecode end    
									--		from EDPS_Data.dbo.CLAIMDIM    
									--		where formtypecode = 'U'    
									--			and (BeginServiceDateKey >= '20130101'    
									--			or EndServiceDateKey >= '20130101')    
									--		IF @@ERROR <> 0    
									--		BEGIN    
									--			ROLLBACK    
									--		END    
									--COMMIT    
									    
									    
									    
											/**********************************************************    
											**    
											**    
											**	Discontinue Pursuit Exclusions    
											**    
											***********************************************************/    
											--get all active Discontinue Pursuit parameter values    
--INSERT INTO EXT_SYS_RUNLOG    (PROC_NAME, STEP, START_DT, END_DT, RUN_MINUTES, TOTAL_RECORDS, ENTRYDT)    
--VALUES('EXSP_CLAIM_EXCLUSION_HIST insert 4', '1', GETDATE(), NULL, NULL, 0, GETDATE()) 		

    
											IF OBJECT_ID('TEMPDB..#DP_YR') <> 0    
															DROP TABLE #DP_YR    
															    
											CREATE TABLE #DP_YR    
											(    
											DP_YR CHAR(4),    
											EXCL_ID INT    
											)    
															    
											    
											INSERT INTO #DP_YR    
											select  substring(RTRIM(cntrl_txt),1,4),    
													CONVERT(INT,substring(rtrim(cntrl_txt),6,4))    
											from EXT_SYS_CLM_JOBCNTRL    
											where SOURCEDATAKEY = 999999999    
											and CNTRL_STATUS = 'A'    
											    
				    
										--IF OBJECT_ID('TEMPDB..#DP_EXCLUSION') <> 0    
										--					DROP TABLE #DP_EXCLUSION    
															    
										--CREATE TABLE #DP_EXCLUSION    
										--(    
										--	CLAIM_ID VARCHAR(20),    
										--	SOURCEDATAKEY INT,    
										--	BATCH_RUN_DT DATETIME,    
										--	EXCL_ID INT,    
										--	CLAIM_TYPE CHAR(5)    
										--)    
										--Append all claims where BeginServiceDatekey meets DP parameters    
										    
											insert into dbo.EXT_CLAIM_EXCLUSION_HIST    
											select  ClaimID,SOURCEDATAKEY,@CURRENTDATE,EXCL_ID,' '     
											from EDPS_Data.dbo.CLAIMDIM C    
											INNER JOIN #DP_YR D    
											ON SUBSTRING(CONVERT(CHAR, BeginServiceDateKey),1,4) = D.DP_YR    
											    
											    
											--insert into dbo.EXT_CLAIM_EXCLUSION_HIST    
											--select  ClaimID,SOURCEDATAKEY,@CURRENTDATE,EXCL_ID,' '     
											--from EDPS_Data.dbo.CLAIMDIM C    
											--INNER JOIN #DP_YR D    
											--ON SUBSTRING(CONVERT(CHAR, EndServiceDateKey),1,4) = D.DP_YR    
											    
										--Append all encounter (encounterclaimdim) where BeginServiceDatekey meets DP parameters    
										    
											insert into dbo.EXT_CLAIM_EXCLUSION_HIST    
											select  Claimnum,SOURCEDATAKEY,@CURRENTDATE,EXCL_ID,' '     
											from EDPS_Data.dbo.encounterclaimdim C    
											INNER JOIN #DP_YR D    
											ON SUBSTRING(CONVERT(CHAR, BeginServiceDateKey),1,4) = D.DP_YR    
											    
--UPDATE EXT_SYS_RUNLOG	    
--	SET END_DT = GETDATE()	    
--	,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
--	,TOTAL_RECORDS = @@ROWCOUNT
--	,ENTRYDT = GETDATE()    
--WHERE PROC_NAME = 'EXSP_CLAIM_EXCLUSION_HIST insert 4'    
--AND END_DT IS NULL										    

										--Missing Line Level pointers    

--TETDM-2003 turn off 9018									    
											--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
											--select  CLAIMID,SourceDataKey,@CURRENTDATE,9018,' '     
											--from EDPS_Data.DBO.claimdim    
											--where formtypecode = 'H'    
											--	AND claimid not in (select claimid from EDPS_Data.DBO.claimdetaildiagnosisdim)    
											    
--TETDM-2453  Claim Adjustment logic  Begin									    
									--9019 Adjusted replace/void    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--SELECT  DISTINCT CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9019,' '     -- TETDM-2047
								--FROM EDPS_Data.dbo.CLAIMDIM c    
								--WHERE charindex('R',c.claimid) > 0    
								--	or charindex('A',c.claimid) > 0    
								INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST  
								 select CLAIMID,SOURCEDATAKEY, cdate , excl,  claimtp 
									 from
									(
									SELECT  DISTINCT CLAIMID,c.SOURCEDATAKEY,@CURRENTDATE as cdate ,'9019' as excl ,' ' as claimtp ,ocs.claim_id as clmid    -- TETDM-2047
									FROM EDPS_Data.dbo.CLAIMDIM c
										left join outb_claim_status ocs on ocs.CLAIM_ID = c.claimid    
									WHERE charindex('R',c.claimid) > 0    
										or charindex('A',c.claimid) > 0 
										)x
									where clmid is null
 								    
								 -- Facets adjustments replace/void    
								 -- Last two digits of 12 char claimid is incremented    
								-- INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--SELECT  DISTINCT CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9019,' '     -- TETDM-2047
								--FROM EDPS_Data.dbo.CLAIMDIM c    
								--WHERE SOURCEDATAKEY = 30    
								--	AND substring(claimid,11,2) <> '00'    
								 INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								 select CLAIMID,SOURCEDATAKEY, cdate , excl,  claimtp  
						from(
							SELECT  DISTINCT CLAIMID, c.SOURCEDATAKEY,@CURRENTDATE as cdate,9019 as excl,' ' as claimtp , ocs.CLAIM_ID as clmid    -- TETDM-2047
							FROM EDPS_Data.dbo.CLAIMDIM c   
								left join outb_claim_status ocs on ocs.CLAIM_ID = c.claimid  
							WHERE c.SOURCEDATAKEY = 30    
								AND substring(claimid,11,2) <> '00'   
									 
							)x
							where x.clmid is NULL


								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST                         -- TETDM-2345
								--SELECT  DISTINCT c.CLAIMID,c.SOURCEDATAKEY,@CURRENTDATE,9019,' '
								--FROM EDPS_Data.dbo.CLAIMDIM c 
								--JOIN EDPS_Data.dbo.UB921ADMISSIONDIM u on c.claimid = u.claimid
								--and c.SourceDataKey ='30'
								--WHERE substring(u.billtypecode,3,1) in ('7','8')


								INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST                         -- TETDM-2345

								 select CLAIMID,SOURCEDATAKEY, cdate , excl,  claimtp  
						from(

								SELECT  DISTINCT c.CLAIMID,c.SOURCEDATAKEY,@CURRENTDATE as cdate,9019 as excl,' ' as claimtp , ocs.CLAIM_ID as clmid
								FROM EDPS_Data.dbo.CLAIMDIM c 
								left join outb_claim_status ocs on ocs.CLAIM_ID = c.claimid  
								JOIN EDPS_Data.dbo.UB921ADMISSIONDIM u on c.claimid = u.claimid
								and c.SourceDataKey =30
								WHERE substring(u.billtypecode,3,1) in ('7','8')
                            )x
							where x.clmid is NULL

--TETDM-2118 update 9019 i created a temp table so I could put an index on it and it would run faster
-- TETDM - 2168 - Added sourcedatakey population log and prevents duplicate 9019
-- TETDM-2472 - Uncommented out code to exclude unaccepted frequency code 7/8 for QNXT

					  INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST
								SELECT DISTINCT qc.claimid, '50' ,@CURRENTDATE, 9019,' '
								FROM edps_data.dbo.QNXT_Claim qc 
								 LEFT JOIN dbo.outb_claim_status ocs ON ocs.CLAIM_ID = qc.claimid 
								 AND ocs.CLMSTAT_STATUS not IN (			
                                        	'A-ICN',
											'A-999',
											'A-277',
											'A'
							                 )
								WHERE qc.Frequencycode  IN ('7', '8') 
								and claimid not in (SELECT Claim_id from  dbo.EXT_CLAIM_EXCLUSION_HIST where EXCL_ID = '9019')
								--ORDER BY qc.Frequencycode, qc.claimid
--TETDM-2453  Claim Adjustment logic  End									    



								--TETDM-2389 add 'A-Ace','UnWrk' as exclusion ID 5
								INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST
									(claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type)
								SELECT DISTINCT
										a.CLAIM_ID
										,a.SOURCEDATAKEY
										,@CURRENTDATE
										,5
										,a.CLAIM_TYPE
									FROM WIPRO.dbo.OUTB_CLAIM_STATUS a
									WHERE 1 = 1									
										AND a.CLMSTAT_STATUS IN ('A-Ace','UnWrk');

								--9020 Non MAO Medicare,MMAI    
								--Unknown MMAIClaimDetailDim Product    
							    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--SELECT DISTINCT CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9020,' '     
								--FROM MMAIClaimDetailDim     
								--where UPPER(claimproducttype) = 'UNKNOWN'    
								    
								----MMAI Medicaid Only     
								--IF OBJECT_ID('TEMPDB..#MMAI_MEDICAID') <> 0    
								--			DROP TABLE #MMAI_MEDICAID    
    
								--		CREATE TABLE #MMAI_MEDICAID    
								--		(    
								--			ClaimId			VARCHAR(50)    
								--		)    
								--	INSERT INTO    
								--		#MMAI_MEDICAID    
								--			(     
								--				ClaimID    
								--			)    
    
								--				SELECT CLAIMID     
								--				FROM MMAIClaimDetailDim    
								--				where (claimproducttype) = 'MEDICAID'    
								--				GROUP BY CLAIMID     
								--				HAVING COUNT(CLAIMID) = 1    
								--				ORDER BY CLAIMID    
    
										     
								--		INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--		SELECT DISTINCT mm.CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9020,' '     
								--		FROM MMAIClaimDetailDim mm    
								--		inner join #MMAI_MEDICAID t    
								--		on mm.ClaimID = t.claimid    
										    
								--temporary MMAICLAIMDETADILDIM  dual EXCLUSION     
								------------- TETDM-1644 begin
								-- jab begin - 05/22/17 uncomment the 9020 exclusion  
								 --pg remove 9020 exclusion 

								INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								SELECT DISTINCT mm.CLAIMID,mm.SOURCEDATAKEY,@CURRENTDATE,9020,' '    
								from EXT_MMAI_CLAIM_PRODUCT MM 
								left join edps_data.dbo.ClaimDim cd on cd.claimid = mm.claimid
								where UPPER(eds_mmai_product) not in ('MEDICARE','MEDICAID') 
--								and deniedflag <> 1 --TETDM 1644 addition --removed by TETDM-2119
								--jab end								    
								------------- TETDM-1644 end

								--Claims processed by Verisk Health    
								--remove until EDS Master Claim Status is fully developed    
								     
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--SELECT  CLAIMID,SOURCEDATAKEY,@CURRENTDATE,999999999,claim_type    
								--FROM EDS_master_CLAIM_STATUS    
								--WHERE  SUBSTRING(CLMSTAT_STATUS,1,1) = 'V'    
							    
--TETDM-1521							    
								--INSERT INTO dbo.hf_EXT_CLAIM_EXCLUSION_hist   
								--SELECT  DISTINCT CLAIM_ID,SOURCEDATAKEY,@CURRENTDATE,999999999,claim_type    
								--FROM EDPS.DBO.EXT_HRP_CLAIM_STATUS    
								

								--1637 jab remove 9021 01/15/18
								--1436 changes    
							--9021 Denied     
								---TETDM-11166 Revise Exclusion in order to life QNXT MAO Prof Denied only    
								---Step 1 - Leave all Facets claims	    
								--TETDM-1436 ONLY LIFT 9021 FOR PROFESSIONAL
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--SELECT  CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9021,' '     
								--FROM EDPS_Data.dbo.CLAIMDIM c    
								--WHERE sourcedatakey = 30  
								-- AND c.FORMTYPECODE <> 'U'   --1436
								--	and deniedflag = 1    
								    
								---Step 2 - Leave all QNXT I (MAO & MMAI) claims	    
								--TETDM-1166    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--SELECT  CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9021,CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END    
								--FROM EDPS_Data.dbo.CLAIMDIM c    
								--WHERE sourcedatakey = 50     
								--	and formtypecode = 'U'    
								--	and deniedflag = 1    
    
								---Step 3 - Leave all QNXT MMAI claims	    
								--11/17/16 Revision    
----TETDM-1982 remove 9021
--								INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
--								SELECT  CLAIMID,c.SOURCEDATAKEY,@CURRENTDATE,9021,CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END    
--								FROM EDPS_Data.dbo.CLAIMDIM c    
--								inner join mdqolib.dbo.LineofBusinessDim l    
--								on c.lobcode = l.lobcode     
--								WHERE c.sourcedatakey = 50     
--									--and formtypecode = 'U'    
--									and producttype = 'Care-Caid'    
--									and deniedflag = 1    
									    
--								--9021 Inactive claims     
								     
--								INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
--								SELECT  CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9021,CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END    
--								FROM EDPS_Data.dbo.CLAIMDIM c    
--								WHERE ACTIVE = -1    
-- end tetdm-1982    
    
							-- Exclusion 9023 - Header total charges <> total line total charges    
							    
								--INSERT INTO EXT_CLAIM_EXCLUSION_HIST    
								--SELECT DISTINCT  CC.CLAIM_ID,CC.SOURCEDATAKEY,@CURRENTDATE,9023,' '     
								--FROM EXT_CLAIM_CHKSUM CC    
								--LEFT OUTER JOIN EXT_CLAIM_EXCLUSION_HIST H    
								--ON CC.SOURCEDATAKEY = H.SOURCEDATAKEY    
								--AND CC.CLAIM_ID = H.CLAIM_ID    
								--WHERE H.CLAIM_ID IS NULL    
								    
															    
								--9999 DME temporary exclusion    
								--TETDM-972 lift exclusion    
								--INSERT INTO EXT_CLAIM_EXCLUSION_HIST    
								--SELECT distinct D.CLAIMID,D.SOURCEDATAKEY,@CURRENTDATE,9999,' '    
								--from EXT_CLAIM_DME D    
								--LEFT OUTER JOIN EXT_CLAIM_EXCLUSION_HIST H    
								--ON D.SOURCEDATAKEY = H.SOURCEDATAKEY    
								--AND D.CLAIMID = H.CLAIM_ID    
								--WHERE H.CLAIM_ID IS NULL	    
							--	EDS-712 - 9024 MMAI Texas Temporary Exclusion     
							--    
							--	Exclude all MMAI Tx claims from being submitted to WIPRO    
    
								--IF OBJECT_ID('TEMPDB..#TMP_TX_MMAI') <> 0    
								--	DROP TABLE #TMP_TX_MMAI    
		    
								--		CREATE TABLE #TMP_TX_MMAI    
		    
								--		( LOBCODE VARCHAR(15)    
								--		)    
    
								--INSERT INTO #TMP_TX_MMAI    
								--SELECT DISTINCT LOBCODE    
								--FROM MDQOLib.DBO.LineofBusinessDim    
								--WHERE HCFACode = 'H8423'    
    
    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--SELECT CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9024,case c.formtypecode when 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE C.FORMTYPECODE END    
								--FROM EDPS_Data.dbo.CLAIMDIM c    
								--INNER JOIN #TMP_TX_MMAI TM    
								--ON C.LOBCODE = TM.LOBCODE    
    
								--EXCLID 9026 DASHES IN DIAGNOSIS CODE RESULTING IN WIPRO POINTER BAD FILES    

								INSERT INTO EXT_CLAIM_EXCLUSION_HIST    
									select distinct ClaimID,SOURCEDATAKEY,@CURRENTDATE,9026,' '     
									from EDPS_DATA.DBO.CLAIMDETAILDIAGNOSISDIM    
									WHERE charindex('-',diagnosiscode) > 0     

							    
--TETDM-1977 remove 9025					----exclid 9025 TETDM-98    
								    
								--INSERT INTO EXT_CLAIM_EXCLUSION_HIST    
								--select distinct ClaimID,SOURCEDATAKEY,@CURRENTDATE,9025,' '     
								--FROM EDPS_DATA.DBO.UB921ADMISSIONDIM    
								--WHERE SUBSTRING(BILLTYPECODE,1,2) = '24'    
--end TETDM-1977
    
								--TETDM-116-Institutional Bill Type 75X AND REVCD exists    

								insert into EXT_CLAIM_EXCLUSION_HIST    
								select distinct cd.ClaimID,cd.SOURCEDATAKEY,@CURRENTDATE,9028,' '    
								FROM EDPS_DATA.DBO.claimdetaildim cd    
								inner join EDPS_DATA.DBO.UB921ADMISSIONDIM ub    
								on cd.sourcedatakey = ub.sourcedatakey     
								and cd.claimid = ub.claimid     
								inner join EDPS_DATA.DBO.procedurecodedim pd    
								on cd.procedurecode = pd.procedurecode     
								WHERE SUBSTRING(BILLTYPECODE,1,2) = '75'    
									and pd.proceduretypecode = 'R'    

/* TETDM-1745 Scott Waller - turn this off    
									IF OBJECT_ID('TEMPDB..#TMP_FACETS_CLMTYPE') <> 0    
									DROP TABLE #TMP_FACETS_CLMTYPE    
		    
										CREATE TABLE #TMP_FACETS_CLMTYPE    
		    
										( CLAIM_ID VARCHAR(20),    
											SOURCEDATAKEY INT,    
											CLAIM_TYPE VARCHAR(1),    
											NEW_CLAIM_TYPE VARCHAR(1)     
										)    
    
									Insert into #TMP_FACETS_CLMTYPE    
									select DISTINCT claim_id,SOURCEDATAKEY,CLAIM_TYPE,CLAIM_TYPE AS 'NEW_CLAIM_TYPE'     
									from OUTB_CLAIM_STATUS     
									WHERE SOURCEDATAKEY = 30     
									AND CLAIM_TYPE = 'P'    
    
    
									UPDATE #TMP_FACETS_CLMTYPE    
									SET NEW_CLAIM_TYPE = CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END    
									FROM #TMP_FACETS_CLMTYPE T    
									INNER JOIN EDPS_DATA.DBO.CLAIMDIM C    
									ON T.SOURCEDATAKEY = C.SOURCEDATAKEY     
									AND T.CLAIM_ID = C.CLAIMID     
									WHERE C.SOURCEDATAKEY = 30    
    

									INSERT INTO EXT_CLAIM_EXCLUSION_HIST    
									SELECT CLAIM_ID,SOURCEDATAKEY,@CURRENTDATE,9030,NEW_CLAIM_TYPE    
									FROM #TMP_FACETS_CLMTYPE    
									WHERE CLAIM_TYPE <> NEW_CLAIM_TYPE    
end TETDM-1745	*/
                                 
                                --jab begin TETDM-1493 Remove(Lift) 9036 for QNXT I CLAIMS 
								--jab begin - uncomment below 04/05/2017 for I claims for QNXT  
								--insert into EXT_CLAIM_EXCLUSION_HIST   
								--select DISTINCT cd.CLAIMID,cd.SOURCEDATAKEY,@CURRENTDATE ,9036,CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END   
								--from EDPS_DATA.DBO.claimdetaildim cd   
								--inner join EDPS_DATA.DBO.claimdim c   
								--ON CD.SOURCEDATAKEY = C.SOURCEDATAKEY    
								--AND CD.CLAIMID = C.CLAIMID   
								--where c.sourcedatakey = 50   
								-- and c.formtypecode = 'U'   
								-- AND cd.ELIGIBLEFEEAMT > cd.REQUESTEDAMT   
								 --jab end  
                                 --jab TETDM-1493 END 

								update dbo.EXT_CLAIM_EXCLUSION_HIST    
								set claim_type = case c.formtypecode when 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE C.FORMTYPECODE END    
								FROM dbo.EXT_CLAIM_EXCLUSION_HIST H    
								INNER JOIN EDPS_DATA.DBO.CLAIMDIM C    
								ON H.SOURCEDATAKEY = C.SOURCEDATAKEY    
								AND H.CLAIM_ID = C.CLAIMID     
    
								--Exclusion id - 9038 - TETDM-605 - Missing Claimdetaildim',0,'All'    
								Insert into EXT_CLAIM_EXCLUSION_HIST    
								select c.claimid,c.sourcedatakey,@CURRENTDATE,9038,CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END    
								from EDPS_DATA.DBO.CLAIMDIM C    
								LEFT OUTER JOIN EDPS_DATA.DBO.CLAIMDETAILDIM CD    
								ON C.SOURCEDATAKEY = CD.SOURCEDATAKEY     
								AND C.CLAIMID = CD.CLAIMID     
								WHERE CD.CLAIMID IS NULL    

-- TETDM-2417	Scott Waller 01/14/2021
								Insert into EXT_CLAIM_EXCLUSION_HIST    
								select c.claimid,c.sourcedatakey,@CURRENTDATE,9038,CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END    
								from EDPS_DATA.DBO.CLAIMDIM C    
								LEFT OUTER JOIN EDPS_Data.dbo.ClaimLineRevenueCodeDim CLRCD
									ON CLRCD.SOURCEDATAKEY		= C.SOURCEDATAKEY     
									AND CLRCD.CLAIMID			= C.CLAIMID     
								LEFT OUTER JOIN EXT_CLAIM_EXCLUSION_HIST E
									on	E.SOURCEDATAKEY			= c.SOURCEDATAKEY
									and	E.claim_id				= C.CLAIMID
								WHERE	C.FORMTYPECODE	= 'U'
								AND		CLRCD.ClaimID	IS NULL
								and		E.claim_id		IS NULL
-- end TETDM-2417
    
--TETDM-2004								    
								------TETDM-622 Excl_ID - 9039     
								--Insert into EXT_CLAIM_EXCLUSION_HIST    
								--select  DISTINCT c.claimid,c.sourcedatakey,@CURRENTDATE,9039,CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END    
								--from EDPS_DATA.DBO.CLAIMDIM c    
								--inner join EDPS_DATA.DBO.CLAIMDETAILDIAGNOSISDIM CDD    
								--on c.sourcedatakey = cdd.sourcedatakey    
								--and c.claimid = cdd.claimid    
								--where c.sourcedatakey = 50     
								--	and c.formtypecode = 'H'    
								--	and cdd.claimid +'-'+ diagnosiscode not in (select claimid +'-'+ diagnosiscode from EDPS_DATA.DBO.CLAIMDIAGNOSISDIM)    
								    
								---EMC-982 Life Exclusions - 9040 and 9041    
								---TETDM-808 Lift exclusion 9040    
								---TETDM-694 Invalid External Cause of InjuryCode - 9040    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--SELECT  u.CLAIMID,u.SOURCEDATAKEY,@CURRENTDATE,'9040',CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END    
								--FROM EDPS_Data.DBO.UB921ADMISSIONDIM u    
								--inner join EDPS_DATA.DBO.CLAIMDIM c    
								--on u.sourcedatakey = c.sourcedatakey     
								--and u.claimid = c.claimid    
								--where injurycode <> 'N/A'    
								--order by SourceDataKey,claimid    
    
								----TETDM-695 Admit Type mismatch     
								----TETDM-809 Lift exclusion 9041    
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select u.claimid,u.sourcedatakey,@CURRENTDATE,9041,CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END    
								--from edps_data.dbo.UB921ADMISSIONDIM u    
								--inner join edps_Data.dbo.CLAIMDIAGNOSISDIM cd    
								--on u.sourcedatakey = cd.sourcedatakey    
								--and u.claimid = cd.claimid     
								--inner join EDPS_DATA.DBO.CLAIMDIM c    
								--on u.sourcedatakey = c.sourcedatakey     
								--and u.claimid = c.claimid    
								--where u.diagnosiscode <> 'N/A'     
								--	and u.admissiondiagnosistypecode = 'A'    
								--	and cd.sequence = 02    
								--	and u.diagnosiscode <> cd.diagnosiscode     
								--	and u.sourcedatakey = 50     
								   
								--9042 - TETDM-709 BIDW Refresh Claims missing ub921admissiondim    
								INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								select c.claimid    
										,c.sourcedatakey    
										,@CURRENTDATE    
										,9042    
										,CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END    
								from edps_data.dbo.claimdim c    
								left outer join edps_data.dbo.UB921ADMISSIONDIM u    
								on c.sourcedatakey = u.sourcedatakey     
								and c.claimid = u.claimid     
								where u.claimid is null     
								and c.FORMTYPECODE = 'U'    
                              
							 --1502  begin Lift Exclusion for QNXT jab -05152017  
							 --   --1446 Total claim amount > 999999.99  
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select DISTINCT cd.CLAIMID,cd.SOURCEDATAKEY,@CURRENTDATE ,9050,CASE WHEN C.FORMTYPECODE = 'U' THEN 'I' WHEN C.FORMTYPECODE = 'H' THEN 'P' ELSE C.FORMTYPECODE END   
								--from EDPS_DATA.DBO.claimdetaildim cd   
								--inner join EDPS_DATA.DBO.claimdim c   
								--ON CD.SOURCEDATAKEY = C.SOURCEDATAKEY    
								--AND CD.CLAIMID = C.CLAIMID   
								--where c.sourcedatakey = 50   
								-- and c.formtypecode in ('U','H')   
								-- AND c.CLAIMBILLEDAMT >  9999999.99  
							   --1502 end	   

/*						  
								--TETDM-9043 Claims with Multiple Claimdetaildiagnosisdim records with a unique Sequence number    
								IF OBJECT_ID('TEMPDB..#diag_excl') <> 0    
								DROP TABLE #diag_excl    
					    
								CREATE TABLE #diag_excl    
								(  claimid varchar(20)    
									,sourcedatakey int    
									,claimlineid varchar(5)    
									,sequence int    
									,SEQ_no int    
								)    
					    
    
								insert into #diag_excl    
								select CLAIMID,    
										sourcedatakey,    
										claimlineid,    
										sequence,    
										--SEQUENCE,    
										 ROW_NUMBER() OVER ( PARTITION BY ClaimID,claimlineid,sequence ORDER BY ClaimID,claimlineid,sequence)    
								from EDPS_Data.dbo.CLAIMDETAILDIAGNOSISDIM    
								where sourcedatakey in (50,30)    
					    
-- Scott Waller 04/06/19	TETDM-1995
							CREATE NONCLUSTERED INDEX IDX_diag_excl_01
								ON #diag_excl (SOURCEDATAKEY, CLAIMID) 
-- end
*/
-- ??? so why collect #diag_excl if not using it???

-- TETDM-2061 remove 9043 begin   
									--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
									--select  distinct C.claimid,C.SOURCEDATAKEY,@CURRENTDATE,9043, CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE C.FORMTYPECODE END    
									--from EDPS_Data.dbo.CLAIMDIM C    
									--inner join #diag_excl T    
									--ON C.SOURCEDATAKEY = T.SOURCEDATAKEY     
									--AND C.CLAIMID = T.CLAIMID    
									--where t.seq_no > 1    
-- TETDM-2061 remove 9043 end

    
/* TETDM-1793 Scott Waller									    
							-- Exclusion Id - 9044 - TETDM-752 Facets Claims with Multiple Claimdiagnosisdim records with multiple records with the same sequence number.    
								IF OBJECT_ID('TEMPDB..#TETDM752') <> 0    
								DROP TABLE #TETDM752    
					    
								CREATE TABLE #TETDM752    
								(  claimid varchar(20)    
									,sourcedatakey int    
									,sequence int    
									,SEQ_no int    
								)    
					    
    
								insert into #TETDM752    
								select CLAIMID,    
										sourcedatakey,    
										sequence,    
										--SEQUENCE,    
										 ROW_NUMBER() OVER ( PARTITION BY ClaimID,sequence ORDER BY ClaimID,sequence)    
								from EDPS_Data.dbo.CLAIMDIAGNOSISDIM    
								where sourcedatakey = 30     
    
						    
					    
    
									INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
									select  distinct C.claimid,C.SOURCEDATAKEY,@CURRENTDATE,9044, CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE C.FORMTYPECODE END    
									from EDPS_Data.dbo.CLAIMDIM C    
									inner join #TETDM752 T    
									ON C.SOURCEDATAKEY = T.SOURCEDATAKEY     
									AND C.CLAIMID = T.CLAIMID    
									where t.seq_no > 1    
end TETDM-1793 */

								-- Exclusion Id - 9045 - TETDM-753 Facets Claims - Claimdiagnosisdim - Multiple Primary DiagnosisCodes records    
								IF OBJECT_ID('TEMPDB..#TETDM753') <> 0    
									DROP TABLE #TETDM753    

								IF OBJECT_ID('dbo.excl_TETDM753', 'U') IS NOT NULL 
								BEGIN
									DROP TABLE dbo.excl_TETDM753
								END

/*								CREATE TABLE #TETDM753    
								(  claimid varchar(20)    
									,sourcedatakey int    
									,DIAGNOSISTYPECODE char(5)    
									,SEQ_no int    
								)    
*/					    
								CREATE TABLE dbo.excl_TETDM753    
								(  claimid varchar(20)    
									,sourcedatakey int    
									,DIAGNOSISTYPECODE char(5)    
									,SEQ_no int    
								)    
    
								insert into dbo.excl_TETDM753    
								select CLAIMID,    
										sourcedatakey,    
										diagnosistypecode,    
										--SEQUENCE,    
										 ROW_NUMBER() OVER ( PARTITION BY ClaimID,diagnosistypecode ORDER BY ClaimID,diagnosistypecode)    
								from EDPS_Data.dbo.CLAIMDIAGNOSISDIM    
								where sourcedatakey = 30	    
									and diagnosistypecode = 'P'    
																    
-- Scott Waller 04/06/19	TETDM-1995
							CREATE NONCLUSTERED INDEX IDX_tetdm753_01
								ON dbo.excl_tetdm753 (SOURCEDATAKEY, CLAIMID) 
-- end				    
    
									INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
									select  distinct C.claimid,C.SOURCEDATAKEY,@CURRENTDATE,9045, CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE C.FORMTYPECODE END    
									from EDPS_Data.dbo.CLAIMDIM C    
									inner join dbo.excl_TETDM753 T    
									ON C.SOURCEDATAKEY = T.SOURCEDATAKEY     
									AND C.CLAIMID = T.CLAIMID    
									where t.seq_no > 1    
   
   /*TETDM-2529
    
									INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
									select  distinct C.claimid,C.SOURCEDATAKEY,@CURRENTDATE,9046, CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE C.FORMTYPECODE END    
									from EDPS_Data.dbo.CLAIMDIM C    
									where sourcedatakey = 30    
										and PREVIOUSCLAIMID <> 'N/A'    

*/


								---TETDM-850 EXCL_ID 9047	    
								IF OBJECT_ID('TEMPDB..#tmplob_excl') <> 0    
										DROP TABLE #tmplob_excl    
    
									CREATE TABLE #tmplob_excl    
									(    
										LOBCode			VARCHAR(15)    
									)    
    
    
								INSERT INTO     
										#tmplob_excl    
									(     
										LOBCode    
									)    
									SELECT    
										LOBCode    
									FROM    
										MDQOLib.dbo.LineofBusinessDim    
									WHERE	    
										ProductType IN ('Commercial','RX','PDP')    
									AND Active = 1    
									ORDER BY LOBCode    
    
								INSERT INTO     
										#tmplob_excl    
									(     
										LOBCode    
									)    
									SELECT    
										LOBCode    
									FROM    
										MDQOLib.dbo.LineofBusinessDim    
									WHERE	    
										substring(HCFACODE,1,1) = 'S'    
									AND Active = 1    
									ORDER BY LOBCode    
    
    
								----TETDM-850 EXCL_ID 9047    -- TETDM-2047
								INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								SELECT  DISTINCT CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9047,CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE c.formtypecode END     
								FROM EDPS_DATA.DBO.CLAIMDIM C    
								INNER JOIN #tmplob_excl T    
								ON C.LOBCODE = T.LOBCODE     
							    
								INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								SELECT  CLAIMID,SOURCEDATAKEY,@CURRENTDATE,9047,CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE c.formtypecode END     
								FROM EDPS_DATA.DBO.CLAIMDIM C    
								WHERE SOURCEDATAKEY = 40    

--TETDM-2061 begin    remove 9048
								----TETDM-1064 - Excl_id 9048 - Denied Claim invalid procedure code     
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select distinct c.claimid,c.sourcedatakey,@CURRENTDATE,9048,CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE c.formtypecode END     
								--from edps_data.dbo.claimdim c    
								--inner join edps_data.dbo.claimdetaildim  cd    
								--on c.sourcedatakey = cd.sourcedatakey     
								--and c.claimid = cd.claimid     
								--where c.deniedflag = 1     
								-- and len(procedurecode) > 5    
 --TETDM-2061 end
 --TETDM-1991   
								-- 	--TETDM-1070 - Excl_id 9049 -  Claim invalid procedure code     
								--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST    
								--select distinct c.claimid,c.sourcedatakey,@CURRENTDATE,9049,CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE c.formtypecode END     
								--from edps_data.dbo.claimdim c    
								--inner join edps_data.dbo.claimdetaildim  cd    
								--on c.sourcedatakey = cd.sourcedatakey     
								--and c.claimid = cd.claimid     
								--where c.deniedflag = 0     
								-- and len(procedurecode) > 5    

								 ---TETDM-1197 Delete all other exclusions for DP claims    
								 IF OBJECT_ID('TEMPDB..#EXT_CLAIM_EXCLUSION_HIST_DP') <> 0    
										drop table 	#EXT_CLAIM_EXCLUSION_HIST_DP    
									CREATE TABLE #EXT_CLAIM_EXCLUSION_HIST_DP(    
										[claim_id] [varchar](20) NULL,    
										[SOURCEDATAKEY] [int] NULL,    
										[BATCH_RUN_DT] [datetime] NOT NULL,    
										[EXCL_ID] [int] NULL,    
										[claim_type] [char](5) NULL    
									)    
    
									    
											INSERT INTO #EXT_CLAIM_EXCLUSION_HIST_DP    
											select  ClaimID,SOURCEDATAKEY,@CURRENTDATE ,EXCL_ID,CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE c.formtypecode END     
											from EDPS_Data.dbo.CLAIMDIM C    
											INNER JOIN #DP_YR D    
											ON SUBSTRING(CONVERT(CHAR, BeginServiceDateKey),1,4) = D.DP_YR    
											WHERE SOURCEDATAKEY IN (30,50)    

-- Scott Waller 04/06/19	TETDM-1995
							CREATE NONCLUSTERED INDEX IDX_EXT_CLAIM_EXCLUSION_HIST_DP_01
								ON #EXT_CLAIM_EXCLUSION_HIST_DP (SOURCEDATAKEY, CLAIM_ID) 
-- end									    
											delete     
											from EXT_CLAIM_EXCLUSION_HIST    
											WHERE CLAIM_ID IN (SELECT CLAIM_ID FROM #EXT_CLAIM_EXCLUSION_HIST_DP)    
    
											INSERT INTO EXT_CLAIM_EXCLUSION_HIST    
											SELECT *     
											FROM #EXT_CLAIM_EXCLUSION_HIST_DP    

/*	Scott Waller Jan 2021
	This logic was causing this to run for 16+ hours.
	I removed the concatenation logic of claimid + sdk, and separated them.
*/
									 IF OBJECT_ID('TEMPDB..#clm_adj') <> 0    
										drop table 	#clm_adj    

									IF OBJECT_ID('dbo.excl_clm_adj', 'U') IS NOT NULL 
									BEGIN
										DROP TABLE dbo.excl_clm_adj
									END


--										CREATE TABLE #clm_adj(    
										CREATE TABLE dbo.excl_clm_adj (    
											claim_id			varchar(20) NULL,
											sourcedatakey		int			NULL  )    
    
--									insert into #clm_adj    
									insert into dbo.excl_clm_adj
--									select claim_id+'-'+convert(char,sourcedatakey)     
									select claim_id, sourcedatakey
									from EXT_CLAIM_EXCLUSION_HIST    
									where excl_id = 9019    

-- SEW adding an index
--									CREATE NONCLUSTERED INDEX IDX_clm_adj ON #clm_adj
									CREATE NONCLUSTERED INDEX IDX_clm_adj ON excl_clm_adj
									(claim_id asc, sourcedatakey asc)  ON [PRIMARY]
    
									delete eceh     
									from EXT_CLAIM_EXCLUSION_HIST eceh
--									inner join #clm_adj a
									inner join excl_clm_adj a
										on	a.claim_id		= eceh.claim_id
										and	a.sourcedatakey	= eceh.SOURCEDATAKEY
									--where claim_id+'-'+convert(char,sourcedatakey) in (select claim_id from #clm_adj)    
									where	eceh.excl_id <> 9019    

  --- TETDM-1650  insert into Claim Exclusion History table
--TETDM-2001 
			--INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST  
			-- select distinct c.claimid,c.sourcedatakey,@CURRENTDATE,9052,CASE C.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' ELSE c.formtypecode END 
			-- from edps_data.dbo.claimdim c 
			-- inner join edps_data.dbo.claimdetaildim cd 
			-- on c.sourcedatakey = cd.sourcedatakey 
			-- and c.claimid = cd.claimid 
			-- where C.CLAIMID IN
			-- (
			-- '16216E020714',  --TETDM-1650 EXCL_ID 9052
			-- '16167E041063',  --TETDM-1650 EXCL_ID 9052
			-- '17237E004705',  --TETDM-1650 EXCL_ID 9052
			-- '17298E040974',  --TETDM-1650 EXCL_ID 9052
			-- '17301E010631'   --TETDM-1650 EXCL_ID 9052
			-- )  
  
/* TETDM-1791	We have claims that came over from last refresh that contain 
	a rev code of D in the claimlinerevenuecode dim table. 
	This is causing our outbound institutional job to fail.
	Scott Waller      */
   
			INSERT INTO EXT_CLAIM_EXCLUSION_HIST
			(claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type)
			SELECT	claimid, sourcedatakey, @CURRENTDATE, 8011, 'I'
			FROM	edps_data.dbo.claimdim
			WHERE	claimid in (
			'15063E038855R1',
			'15063E038855R2',
			'15063E038855A1',
			'15063E038855A2',
			'16222E062169',
			'16104E052780A4',
			'15063E038855',
			'15057E003166',
			'15040E011335',
			'18060E038832',
			'16104E052780R4',
			'16104E052780A3' )

/* TETDM-1787	New exclusion 8012 for claims with LOB's 
TETDM-2298  	'C54240970', 'C42644396', 'C45137428', 'UMISC0028042858'
				*** 8.8 million claims took 4 mins 49 sec
	Scott Waller      */
			INSERT INTO EXT_CLAIM_EXCLUSION_HIST
			(claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type)
			SELECT	claimid, sourcedatakey, @CURRENTDATE, 8012, 
					CASE FORMTYPECODE 
						WHEN 'H'	THEN 'P' 
						WHEN 'U'	THEN 'I' 
						ELSE formtypecode 
					END
			FROM	edps_data.dbo.claimdim
			WHERE	LOBCODE	IN ('C54240970', 'C42644396', 'C45137428', 'UMISC0028042858')
-- end TETDM-1787 and TETDM-2298 

/* TETDM-1782	New exclusion 9053 Termed Members with no Hplan
				*** 910,681 claims too 3 mins 50 seconds
	Scott Waller      */

			INSERT INTO EXT_CLAIM_EXCLUSION_HIST
			SELECT	c.claimid, c.sourcedatakey, @CURRENTDATE, 9053, 
								CASE c.FORMTYPECODE 
									WHEN 'H'	THEN 'P' 
									WHEN 'U'	THEN 'I' 
									ELSE formtypecode 
								END
			FROM
					EDPS_Data.dbo.claimdim	c
			LEFT OUTER JOIN	
					edps_data.dbo.monthlymembershipdim b  
				on	b.memberid				= c.memberid 
				and	b.SourceDataKey			= c.SOURCEDATAKEY
				AND	c.beginservicedatekey	between b.begincoveragedatekey and b.endcoveragedatekey   
			WHERE	c.sourcedatakey			= 50
			and		c.DENIEDFLAG			= '1'
			AND		b.HCFACode	IS NULL 
			UNION
			SELECT	c.claimid, c.sourcedatakey, @CURRENTDATE, 9053, 
								CASE c.FORMTYPECODE 
									WHEN 'H'	THEN 'P' 
									WHEN 'U'	THEN 'I' 
									ELSE formtypecode 
								END
			FROM
					EDPS_Data.dbo.claimdim	c
			INNER JOIN	
					edps_data.dbo.monthlymembershipdim b  
				on	b.memberid				= c.memberid 
				and	b.SourceDataKey			= c.SOURCEDATAKEY
				AND	c.beginservicedatekey	between b.begincoveragedatekey and b.endcoveragedatekey   
			WHERE	c.sourcedatakey			= 50
			and		c.DENIEDFLAG			= '1'
			AND		b.LobCode NOT IN ('C54240970', 'C42644396', 'C45137428', 'UMISC0028042858')
			AND		( b.HCFACode	= 'UNKNOWN' 
			OR		b.HCFACode	LIKE '%-%' )
         UNION --tetdm-2089 start
		   			SELECT	c.claimid, c.sourcedatakey, @CURRENTDATE, 9053, 
								CASE c.FORMTYPECODE 
									WHEN 'H'	THEN 'P' 
									WHEN 'U'	THEN 'I' 
									ELSE formtypecode 
								END
			FROM
					EDPS_Data.dbo.claimdim	c
            WHERE c.LOBCODE LIKE '%UNKNOWN%'
			--tetdm-2089 end
       UNION --TETDM-2211 add more claims to EXCL 9053
			SELECT  x.claimnum, x.sourcedatakey, @currentdate, 9053, x.claimtype
			FROM
			(
				SELECT DISTINCT  ecd.ClaimNum, ecd.SourceDataKey, ecd.ClaimType, ecd.MemberID, ecd.BeginServiceDateKey , mmd.BeginCoverageDateKey,
				                 mmd.EndCoverageDateKey, ecd.SourceDesc,
					            CASE WHEN ecd.BeginServiceDateKey  BETWEEN mmd.BeginCoverageDateKey AND mmd.EndCoverageDateKey THEN 'NO' else'YES' END AS Excl
				FROM edps_data.dbo.encounterclaimdim ecd
				  LEFT JOIN edps_data.dbo.MonthlyMembershipDim mmd ON mmd.MemberID = ecd.MemberID 
															 AND ecd.ClaimLineNum = 1
															 AND ecd.BeginServiceDateKey  BETWEEN mmd.BeginCoverageDateKey AND mmd.EndCoverageDateKey
				WHERE ecd.ClaimLineNum = 1
					 AND ecd.SourceDesc  IN ('ADVOCATE', 'PROSPECT', 'SUPERIORVISION', 'SWEDISH', 'UNIV_CHI', 'WELLMED', 'EYEMED')			) x
-- REBT-39	added EYEMED to logic
			WHERE x.excl = 'YES'
			--ORDER BY x.ClaimNum	     --end TETDM-2211
-- end TETDM-1782

-- TETDM-2299 Scott Waller August 12 2020
-- more Excl 9053 logic
		INSERT INTO EXT_CLAIM_EXCLUSION_HIST
		SELECT	cd.claimid, cd.sourcedatakey, @CURRENTDATE, 9053, 
				CASE cd.FORMTYPECODE 
					WHEN 'H'	THEN 'P' 
					WHEN 'U'	THEN 'I' 
					ELSE formtypecode 
				END
		FROM	EDPS_Data.dbo.CLAIMDIM cd
		LEFT OUTER JOIN EXT_CLAIM_EXCLUSION_HIST E
			ON	cd.SOURCEDATAKEY		= E.SOURCEDATAKEY 
			AND cd.CLAIMID			= E.CLAIM_ID 
		LEFT OUTER JOIN MDQOLib.dbo.MemberDim			mb
			ON	cd.SOURCEDATAKEY	= mb.SourceDataKey
			AND cd.MEMBERID			= mb.MemberID
		WHERE	cd.SOURCEDATAKEY IN (30,50)
		AND		E.claim_id		IS NULL
		AND		mb.MemberID		IS NULL
-- end TETDM-2299

			--FINAL EXCL_HIST TABLE CLEAN-UP (REF: DEP-537) 
			-----------------------------------------------
			-- remove 9020 Claims from Exclusions
			-----------------------------------------------

/* TETDM-2098 rewriting this one a little.  Adding SOURCEDATAKEY to the temp table, joins,
		add and appropriate WHERE clause, remove WHERE CLAIM_ID IN (SELECT....) and add a JOIN to 
		both sourcedatakey and claimid columns

			IF OBJECT_ID('TEMPDB..#temp_9020_claims') <> 0
							DROP TABLE #temp_9020_claims
							CREATE TABLE #temp_9020_claims
						(
							CLAIMID VARCHAR(20)
						)

			INSERT INTO #temp_9020_claims (CLAIMID)
			SELECT DISTINCT P.CLAIMID
			FROM dbo.EXT_CLAIM_EXCLUSION_HIST E,
				 dbo.OUTB_CLAIM_STATUS O, 
				 dbo.EXT_MMAI_CLAIM_PRODUCT P
			WHERE P.CLAIMID = E.claim_id
			  AND O.CLAIM_ID = E.claim_id
			  AND E.EXCL_ID = '9020'

			--Remove claims from exclusion history
			DELETE dbo.EXT_CLAIM_EXCLUSION_HIST
			WHERE claim_id IN (SELECT CLAIMID FROM #temp_9020_claims)
end TETDM-2098 */

			IF OBJECT_ID('TEMPDB..#temp_9020_claims') <> 0
				DROP TABLE #temp_9020_claims
							
			IF OBJECT_ID('dbo.excl_temp_9020_claims', 'U') IS NOT NULL 
			BEGIN
				DROP TABLE dbo.excl_temp_9020_claims
			END

--			CREATE TABLE #temp_9020_claims
			CREATE TABLE excl_temp_9020_claims
				(
					SOURCEDATAKEY	INT,
					CLAIMID			VARCHAR(20)
				)

--			INSERT INTO #temp_9020_claims 
			INSERT INTO excl_temp_9020_claims
				(SOURCEDATAKEY, CLAIMID)
			SELECT	P.SOURCEDATAKEY, P.CLAIMID
			FROM dbo.EXT_CLAIM_EXCLUSION_HIST E
			INNER JOIN	dbo.OUTB_CLAIM_STATUS O
				ON	O.SOURCEDATAKEY		= E.SOURCEDATAKEY
				AND	O.CLAIM_ID			= E.claim_id
			INNER JOIN dbo.EXT_MMAI_CLAIM_PRODUCT P
				ON	P.SOURCEDATAKEY		= E.SOURCEDATAKEY
				AND	P.CLAIMID			= E.claim_id
			WHERE E.EXCL_ID = '9020'

			--Remove claims from exclusion history
			DELETE	a
			FROM	dbo.EXT_CLAIM_EXCLUSION_HIST a
			INNER JOIN excl_temp_9020_claims b
				ON	b.SOURCEDATAKEY		= a.SOURCEDATAKEY
				AND	b.CLAIMID			= a.claim_id

			IF OBJECT_ID('dbo.excl_temp_9020_claims', 'U') IS NOT NULL 
			BEGIN
				DROP TABLE dbo.excl_temp_9020_claims
			END

			------------------------------------------
			------------------------------------------
/* TETDM-1827	Build New Exclusion for Member reimbursement claims for 4
specific providers  and SDK 50
   'QMP000003530784','QMP000003530785','QMP000004300591','QMP000003578016'
      */
            --------------------------------------------------------------
/* TETDM-2098	Rewriting this logic as it hangs in PROD
				See the ticket for the details on what needs to be changed.
				For the second SELECT In the UNION, it tablescans on ClaimDetailDim table which has over 120 million rows 
				while joined to a table with 78 million rows.
*/
/*	INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST
		SELECT distinct
			   cd.CLAIMID
			  ,cdd.SOURCEDATAKEY
       		  , @CURRENTDATE
			  ,'9056'
			  , CASE WHEN cd.FORMTYPECODE = 'H' THEN 'P' ELSE 'I' END
		 FROM [EDPS_Data].[dbo].[CLAIMDETAILDIM] cdd
			JOIN [EDPS_Data].[dbo].[CLAIMDIM] cd ON cdd.CLAIMID = cd.CLAIMID
											  AND cdd.SOURCEDATAKEY = cd.SOURCEDATAKEY
		 WHERE providerid IN ('QMP000003530784','QMP000003530785','QMP000004300591','QMP000003578016')
		   AND cdd.CLAIMLINEID = 1
		   AND cd.SOURCEDATAKEY = 50

 
			 UNION

			 SELECT  --COUNT(DISTINCT a.claim_id)
			   DISTINCT
				  A.CLAIM_ID, A.SOURCEDATAKEY, @CURRENTDATE,   '9056' , a.CLAIM_TYPE
			 FROM WIPRO.dbo.OUTB_CLAIM_STATUS AS A 
			 INNER JOIN  EDPS_Data.dbo.CLAIMDETAILDIM AS B 
				ON B.SOURCEDATAKEY = A.SOURCEDATAKEY AND B.CLAIMID = A.CLAIM_ID
			 WHERE (A.STAT_REJ_REA_ID = '90170') AND (A.SOURCEDATAKEY = '50') 
			   AND (B.VENDORID IN ('QMP000003530784', 'QMP000003530785', 'QMP000004300591', 'QMP000003578016'))
*/

	IF OBJECT_ID('TEMPDB..#CDD_Providers') <> 0
		DROP TABLE #CDD_Providers;

	CREATE TABLE #CDD_Providers
		(	SOURCEDATAKEY	INT,
			CLAIMID			VARCHAR(20) )

	IF OBJECT_ID('dbo.excl_CDD_Providers', 'U') IS NOT NULL 
		DROP TABLE dbo.excl_CDD_Providers;

	CREATE TABLE dbo.excl_CDD_Providers
		(	SOURCEDATAKEY	INT,
			CLAIMID			VARCHAR(20) )

--	INSERT INTO	#CDD_Providers			-- start by identifying the smaller subset of claims that only have these providers
	INSERT INTO dbo.excl_CDD_Providers
	SELECT	SOURCEDATAKEY,	CLAIMID
	FROM	EDPS_Data.dbo.CLAIMDETAILDIM
	WHERE	SOURCEDATAKEY	= 50
	AND		CLAIMLINEID		= '0001'
	AND		providerid		IN ('QMP000003530784','QMP000003530785','QMP000004300591','QMP000003578016')

	CREATE NONCLUSTERED INDEX IDX_CDD_Providers ON	dbo.excl_CDD_Providers	--#CDD_Providers
		(sourcedatakey asc, claimid asc)  ON [PRIMARY]

	IF OBJECT_ID('TEMPDB..#CDD_Vendors') <> 0
		DROP TABLE #CDD_Vendors
	
	CREATE TABLE #CDD_Vendors
		( 		SOURCEDATAKEY	INT,
				CLAIMID			VARCHAR(20) )

	IF OBJECT_ID('dbo.excl_CDD_Vendors', 'U') IS NOT NULL 
		DROP TABLE dbo.excl_CDD_Vendors;

	CREATE TABLE dbo.excl_CDD_Vendors
		(	SOURCEDATAKEY	INT,
			CLAIMID			VARCHAR(20)		)


--	INSERT INTO	#CDD_Vendors			-- start by identifying the smaller subset of claims that only have these vendors
	INSERT INTO dbo.excl_CDD_Vendors
	SELECT	SOURCEDATAKEY,	CLAIMID
	FROM	EDPS_Data.dbo.CLAIMDETAILDIM
	WHERE	SOURCEDATAKEY	= 50
	AND		CLAIMLINEID		= '0001'
	AND		VENDORID		IN ('QMP000003530784', 'QMP000003530785', 'QMP000004300591', 'QMP000003578016')

	CREATE NONCLUSTERED INDEX IDX_CDD_Vendors ON	dbo.excl_CDD_Vendors	--#CDD_Vendors
		(sourcedatakey asc, claimid asc)  ON [PRIMARY]

	INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST
		SELECT distinct
			   cd.CLAIMID
			  ,cdd.SOURCEDATAKEY
       		  , @CURRENTDATE
			  ,'9056'
			  , CASE WHEN cd.FORMTYPECODE = 'H' THEN 'P' ELSE 'I' END
		 FROM	dbo.excl_CDD_Providers cdd		--#CDD_Providers cdd
		 JOIN [EDPS_Data].[dbo].[CLAIMDIM] cd 
			ON	cd.SOURCEDATAKEY	= cdd.SOURCEDATAKEY
			AND	cd.CLAIMID			= cdd.CLAIMID 
	UNION
--	INSERT INTO dbo.EXT_CLAIM_EXCLUSION_HIST
			 SELECT  DISTINCT
				  A.CLAIM_ID, A.SOURCEDATAKEY, @CURRENTDATE,   '9056' , a.CLAIM_TYPE
			 FROM WIPRO.dbo.OUTB_CLAIM_STATUS AS A 
			 INNER JOIN	dbo.excl_CDD_Vendors B		--#CDD_Vendors AS B 
				ON	B.SOURCEDATAKEY		= A.SOURCEDATAKEY 
				AND B.CLAIMID			= A.CLAIM_ID
			 WHERE	A.STAT_REJ_REA_ID = '90170'
			 AND	A.SOURCEDATAKEY = 50
	
	IF OBJECT_ID('TEMPDB..#CDD_Providers') <> 0
		DROP TABLE #CDD_Providers;

	IF OBJECT_ID('TEMPDB..#CDD_Vendors') <> 0
		DROP TABLE #CDD_Vendors;

	IF OBJECT_ID('dbo.excl_CDD_Vendors', 'U') IS NOT NULL 
		DROP TABLE dbo.excl_CDD_Vendors;

	IF OBJECT_ID('dbo.excl_CDD_Providers', 'U') IS NOT NULL 
		DROP TABLE dbo.excl_CDD_Providers;

--end TETDM-1827
-- end TETDM-2098 rewrite

	-- Exclusion 8021 
	-- Encounter Exclusions - HistoricalClaims RendProvTaxonomy gt 10 chars
	insert into EXT_CLAIM_EXCLUSION_HIST
	select distinct claimnum, 4, @CURRENTDATE, 8021, ClaimType
	from   EDPS_Data.dbo.encounterclaimdim
	where  ClaimNum in ('225805-2061-LD', '150416307573')  -- rendprovtaxonomy in HistoricalClaim table > 10 chars
	and           claimtype in ('I', 'P')
	and           ClaimLineNum = '1'

	-- Exclusion 8020
	-- Encounter Exclusions - ProcCode gt 5 chars
	INSERT INTO EXT_CLAIM_EXCLUSION_HIST
	SELECT DISTINCT claimnum, 4, @CURRENTDATE, 8020, ClaimType
	FROM edps_data.dbo.encounterclaimdim
	WHERE ClaimLineNum = '1'
	AND claimtype IN ('I', 'P')
	AND claimnum IN 
	('20150729821642400020',
	'20150813821642400033',
	'20150729821642400025',
	'C305150209PT005',
	'20150720821642400029',
	'20150723821633800001',
	'20150722821642400010',
	'20150722821642400026',
	'C401150209PT034',
	'20150729821642400045',
	'20150716821642400010',
	'BV201610390928-193',
	'150902512186',
	'150902512186',
	'C408150209PT029',
	'20150514821634600001',
	'20150722821642400041',
	'150528022954',
	'150528022954',
	'BV201510487669-193',
	'20150730821642400003',
	'150525971222',
	'150525971222',
	'20150729821642400028',
	'20150722821642400042',
	'20150810821642400021',
	'20150715821642400013',
	'20150716821642400009',
	'20150810821642400005',
	'20150715821642400008',
	'150831474587',
	'20150814821642400010',
	'150529041591',
	'150529041591',
	'20150814821642400039',
	'20150813821642400022',
	'20150813821633800005',
	'20150716821642400011',
	'20150720821642400022',
	'20150715821642400006',
	'20150720821642400002',
	'150527006599',
	'150527006599',
	'20150810821642400006',
	'20150722821642400008',
	'20150720821642400004',
	'20150729821642400024',
	'20150717821633800006',
	'20150720821642400003',
	'150526988389',
	'150526988389',
	'C619150034YG011',
	'20150729800043700001')

-- Scott Waller Sept 30, 2021  (as part of TETDM-2587)
--	added the temp table logic due to terrible performance
--	I know it looks hideous, but having all 3 conditions in the WHERE clause was 
--	causing this to run for 24+ hours
--	The LEN function, any function for that matter, in WHERE clauses causes SQL Server to ignore indexes

/*	this was the original logic
	INSERT INTO EXT_CLAIM_EXCLUSION_HIST
	SELECT DISTINCT cd.claimid, cd.sourcedatakey , @CURRENTDATE, 8020, 
	   CASE cd.FORMTYPECODE 
		WHEN 'H'	THEN 'P' 
		WHEN 'U'	THEN 'I' 
		ELSE formtypecode 
	  END
  FROM edps_data.dbo.CLAIMDIM cd
JOIN edps_data.dbo.CLAIMdetailDIM cdd ON cd.CLAIMID =cdd.CLAIMID
WHERE LEN(cdd.PROCEDURECODE) > 5 
 AND cdd.CLAIMLINEID = 1
 AND cdd.SOURCEDATAKEY IN (30,50)
*/
					INSERT INTO EXT_SYS_RUNLOG    
							(PROC_NAME    
							,STEP    
							,START_DT    
							,END_DT    
							,RUN_MINUTES    
							,TOTAL_RECORDS    
							,ENTRYDT    
							)    
					VALUES('EXSP_CLAIM_EXCLUSION_HIST - insert 8022 (bottleneck)'    
							,'1'    
							,GETDATE()    
							,NULL    
							,NULL    
							,0
							,GETDATE()    
							) 

-- RETM-160	we keep filling the tempdb, so I am switching from temp to perm tables

--	IF OBJECT_ID('TEMPDB..#hold_claimdetaildim_8020') <> 0
--		DROP TABLE #hold_claimdetaildim_8020

	IF OBJECT_ID('dbo.hold_claimdetaildim_8020', 'U') IS NOT NULL 
		DROP TABLE dbo.hold_claimdetaildim_8020; 

	SELECT	distinct cdd.SOURCEDATAKEY, cdd.CLAIMID, cdd.CLAIMLINEID, cdd.PROCEDURECODE, 0 as LEN_PROCEDURECODE
--	INTO	#hold_claimdetaildim_8020
	INTO	hold_claimdetaildim_8020
	FROM	edps_data.dbo.CLAIMdetailDIM cdd 
	WHERE	cdd.SOURCEDATAKEY		IN (30,50)	

	DECLARE @Deleted_Rows INT;
	SET @Deleted_Rows = 1;

	WHILE (@Deleted_Rows > 0)
	   BEGIN
		-- Delete some small number of rows at a time
		  DELETE TOP (500000)	hold_claimdetaildim_8020 	--#hold_claimdetaildim_8020 
		  WHERE	CLAIMLINEID <> '0001'

		  SET @Deleted_Rows = @@ROWCOUNT;
	   END

	--UPDATE	#hold_claimdetaildim_8020
	UPDATE	hold_claimdetaildim_8020
	SET		LEN_PROCEDURECODE = LEN(PROCEDURECODE)

	--DELETE	FROM #hold_claimdetaildim_8020
	DELETE	FROM hold_claimdetaildim_8020
	WHERE	LEN_PROCEDURECODE <= 5

	--CREATE NONCLUSTERED INDEX IDX_On_Temp_Table ON #hold_claimdetaildim_8020
	CREATE NONCLUSTERED INDEX IDX_On_Temp_Table ON hold_claimdetaildim_8020
		(sourcedatakey asc, claimid asc)  ON [PRIMARY]

	INSERT INTO EXT_CLAIM_EXCLUSION_HIST
	SELECT DISTINCT cd.claimid, cd.sourcedatakey , @CURRENTDATE, 8020, 
	   CASE cd.FORMTYPECODE 
		WHEN 'H'	THEN 'P' 
		WHEN 'U'	THEN 'I' 
		ELSE formtypecode 
	  END
	FROM edps_data.dbo.CLAIMDIM cd
	--JOIN #hold_claimdetaildim_8020 cdd 
	JOIN hold_claimdetaildim_8020 cdd 
		ON	cd.CLAIMID			= cdd.CLAIMID
		AND cd.SOURCEDATAKEY	= cdd.SOURCEDATAKEY

	UPDATE EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @@ROWCOUNT
		,ENTRYDT = GETDATE()    
	WHERE PROC_NAME = 'EXSP_CLAIM_EXCLUSION_HIST - insert 8022 (bottleneck)'    
			AND END_DT IS NULL

	IF OBJECT_ID('dbo.hold_claimdetaildim_8020', 'U') IS NOT NULL 
		DROP TABLE dbo.hold_claimdetaildim_8020; 
 --end update to 8020 to include SDK 30 and 50 I nd P claims right now only 38 claims
 -- end of rewrite for 8020 Exclusion as part of the TETDM-2587 ticket.

	-- TETDM 1887 -Exclusion for member reimbursement claims SDK30
	-- 

	INSERT INTO EXT_CLAIM_EXCLUSION_HIST
	SELECT DISTINCT cd.claimid, 30, @CURRENTDATE, 9056, 'P'
	FROM edps_DATA.dbo.claimdim cd
	  LEFT JOIN  edps_data.dbo.CLAIMDETAILDIM cdd ON cd.claimid = cdd.CLAIMID
	WHERE cdd.PROVIDERID = 'DMR000000001'
	 AND cd.SOURCEDATAKEY = 30
	  AND cd.FORMTYPECODE = 'H'
	-------------------end tetdm-1887

-- TETDM-2236	add these single claims as they have corrupted data in BIDW and until they fix, this claim causes our QNXT MAO jobs to fail

	insert into EXT_CLAIM_EXCLUSION_HIST
		(claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type)
	values
		('18117000017', 50, getdate(), 9054, 'P')

	insert into EXT_CLAIM_EXCLUSION_HIST
		(claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type)
	values
		('19343E001152', 50, getdate(), 9054, 'I')

	insert into EXT_CLAIM_EXCLUSION_HIST
		(claim_id, SOURCEDATAKEY, BATCH_RUN_DT, EXCL_ID, claim_type)
	values
		('19308E009304', 50, getdate(), 9054, 'I')

-- end TETDM-2236

-- TETDM-2587	Exclusion 8022
	INSERT INTO EXT_CLAIM_EXCLUSION_HIST
	SELECT DISTINCT e.claimnum, 4, @CURRENTDATE, 8022, e.ClaimType
	FROM   EDPS_Data.dbo.encounterclaimdim e
	INNER JOIN EDS_Audit.dbo.EDS_Encounter_SourceDesc s
		ON	e.SourceDesc			= s.SourceDesc
		AND e.BeginServiceDateKey		BETWEEN startdate AND enddate
	WHERE	e.ClaimLineNum		= '1'
	AND		e.ClaimFrequencyCode	= '1'
	AND		e.SourceDataKey		= 4
	AND		e.BeginServiceDateKey < (	SELECT	claimstartdate
										FROM	EDPS_Data.dbo.EDS_ENCOUNTERS_CLAIMSTARTDATE )

	INSERT INTO EXT_CLAIM_EXCLUSION_HIST
	SELECT DISTINCT c.CLAIMID, c.SOURCEDATAKEY, @CURRENTDATE, 8022, 
		CASE c.FORMTYPECODE 
			WHEN 'H'	THEN 'P' 
			WHEN 'U'	THEN 'I' 
			ELSE formtypecode 
		END AS ClaimType
	FROM	EDPS_Data.dbo.claimdim c
	WHERE	c.BeginServiceDateKey < (	SELECT	claimstartdate
										FROM	EDPS_Data.dbo.eds_bidw_claimstartdate )

-- end TETDM-2587


/* RETM-326 
-- TETDM-2620  new Vendor_INHome_Claim Exclusion
	IF OBJECT_ID('dbo.excl_ProviderDim_forexclsuion', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_ProviderDim_forexclsuion
	END

	SELECT	DISTINCT	a.ProviderID, a.FIDN, a.NPID, a.ProvCategory, a.SourceDataKey, a.ProviderTypeCode, a.ProviderStatus  
--	INTO	#ProviderDim_forexclsuion
	INTO	dbo.excl_ProviderDim_forexclsuion
	FROM	EDPS_Data.dbo.ProviderDim a
	INNER JOIN WIPRO.dbo.Home_VendorID_XREF b
		ON	b.ProviderID		= a.ProviderID
		AND	b.NPID				= a.NPID

	INSERT INTO EXT_CLAIM_EXCLUSION_HIST
	SELECT DISTINCT c.CLAIMID, c.SOURCEDATAKEY, @CURRENTDATE, 9063, 
		CASE c.FORMTYPECODE 
			WHEN 'H'	THEN 'P' 
			WHEN 'U'	THEN 'I' 
			ELSE formtypecode 
		END AS ClaimType
	FROM	EDPS_Data.[dbo].[CLAIMDETAILDIM] a
	INNER JOIN EDPS_Data.[dbo].[CLAIMDIM] c 
		on a.claimid = c.claimid
	JOIN	 dbo.excl_ProviderDim_forexclsuion P
		ON (A.[VENDORID] =P.[ProviderID]
			and c.[VENDORNPI]=P.[NPID])
	JOIN EDPS_Data.[dbo].[CLAIMDIAGNOSISDIM] d
		On a.claimid = d.claimid
	WHERE	REPLACE (D.DiagnosisCode, '.','') IN (SELECT DxCode	FROM dbo.Home_DXCodes_XREF)

	IF OBJECT_ID('dbo.excl_ProviderDim_forexclsuion', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_ProviderDim_forexclsuion
	END
-- end TETDM-2620
*/

-------------------------------------------
-- RETM-53 Preclusion Provider Exclusion
-------------------------------------------
	IF OBJECT_ID('TEMPDB..#hold_providerpreclusionlist') <> 0
		DROP TABLE #hold_providerpreclusionlist

	IF OBJECT_ID('dbo.excl_hold_providerpreclusionlist', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_providerpreclusionlist
	END

	-- I am doing this because the PROVIDERPRECLUSIONLIST does not have any indexes;  it'll table scan and run forever
	SELECT	NPI, ACTIVE, CLMREJECTDATE, ISNULL(REINDATE, '21991231') AS REINDATE
	INTO	dbo.excl_hold_providerpreclusionlist
	FROM	edps_data.dbo.PROVIDERPRECLUSIONLIST
	WHERE	ACTIVE = 1		-- RETM-741

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_providerpreclusionlist (NPI ASC)

	IF OBJECT_ID('TEMPDB..#hold_claimstoexclude') <> 0
		DROP TABLE #hold_claimstoexclude

	IF OBJECT_ID('dbo.excl_hold_claimstoexclude', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_claimstoexclude
	END

	SELECT	DISTINCT a.sourcedatakey, a.claimid, a.FORMTYPECODE
	INTO	dbo.excl_hold_claimstoexclude
	FROM	edps_data.dbo.CLAIMDIM a
	INNER JOIN dbo.excl_hold_providerpreclusionlist b
		ON	b.NPI		= a.VENDORNPI
	WHERE	( (a.BeginServiceDateKey >= b.CLMREJECTDATE) AND
			  (a.BeginServiceDateKey < b.REINDATE) )

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_claimstoexclude (SOURCEDATAKEY ASC, claimid ASC)

	INSERT INTO dbo.excl_hold_claimstoexclude
	SELECT	DISTINCT a.sourcedatakey, a.claimid, d.FORMTYPECODE
	FROM	edps_data.dbo.CLAIMDETAILDIM a
	LEFT OUTER JOIN dbo.excl_hold_claimstoexclude c
		ON	c.SOURCEDATAKEY		= a.SOURCEDATAKEY
		AND	c.CLAIMID			= a.CLAIMID
	INNER JOIN dbo.excl_hold_providerpreclusionlist b
		ON	b.NPI		= a.PROVIDERNPI
	INNER JOIN	EDPS_Data.dbo.claimdim d
		on	d.SOURCEDATAKEY		= a.SOURCEDATAKEY
		and	d.CLAIMID			= a.CLAIMID
	WHERE	c.CLAIMID IS NULL	-- this is how we'll skip claims that we identified in the ClaimDim query and not have duplicates in the 9064 Exclusion
	AND		( (a.BeginServiceDateKey >= b.CLMREJECTDATE) AND
			  (a.BeginServiceDateKey < b.REINDATE) )

-- encounter claims
	INSERT INTO dbo.excl_hold_claimstoexclude
	SELECT DISTINCT e.SourceDataKey, e.claimnum, e.ClaimType
	FROM   EDPS_Data.dbo.encounterclaimdim e
	INNER JOIN EDS_Audit.dbo.EDS_Encounter_SourceDesc s
		ON	e.SourceDesc			= s.SourceDesc
		AND e.BeginServiceDateKey	BETWEEN startdate AND enddate
	INNER JOIN dbo.excl_hold_providerpreclusionlist b
		ON	b.NPI					= e.ProviderID
	WHERE	e.ClaimLineNum			= '1'
	AND		e.ClaimFrequencyCode	= '1'
	AND		e.SourceDataKey			= 4
	AND		( (e.BeginServiceDateKey >= b.CLMREJECTDATE) AND
			  (e.BeginServiceDateKey < b.REINDATE) )	-- RETM-741

	INSERT INTO EXT_CLAIM_EXCLUSION_HIST
	SELECT DISTINCT e.claimid, e.SOURCEDATAKEY, @CURRENTDATE, 9064 as EXCL_ID, 
					CASE e.FORMTYPECODE 
						WHEN 'H'	THEN 'P' 
						WHEN 'U'	THEN 'I' 
						ELSE formtypecode 
					END AS ClaimType
	FROM   dbo.excl_hold_claimstoexclude e

--	DROP TABLE #hold_providerpreclusionlist
--	DROP TABLE #hold_claimstoexclude
	
	IF OBJECT_ID('dbo.excl_hold_providerpreclusionlist', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_providerpreclusionlist
	END

	IF OBJECT_ID('dbo.excl_hold_claimstoexclude', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_claimstoexclude
	END
-- end RETM-53

-----------------------------------------------------------------------------
-- RETM-154
-----------------------------------------------------------------------------
-- identify all claims with NO PRIMARY DX CODES
-- these need to be put in some exclusion, I use 9070 
	DECLARE	@hold_date	varchar(8) = CONVERT(VARCHAR, getdate(), 112)

	INSERT INTO EXT_SYS_RUNLOG    
							(PROC_NAME    
							,STEP    
							,START_DT    
							,END_DT    
							,RUN_MINUTES    
							,TOTAL_RECORDS    
							,ENTRYDT    
							)    
	VALUES('EXSP_CLAIM_EXCLUSION_HIST - Exclude Claims with no Prim DX'    
							,'1'    
							,GETDATE()    
							,NULL    
							,NULL    
							,0
							,GETDATE()    
							) 

	IF OBJECT_ID('tempDB..#hold_claims') IS NOT NULL
	BEGIN
		DROP TABLE #hold_claims
	END

-- we are out of tempdb disk space for 4+ weeks now, so I am creating a work around, using physical tables instead of temp tables
	IF OBJECT_ID('dbo.excl_hold_claims', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_claims
	END

-- first, collect all claims that aren't in an exclusion already, and available for submission.
	SELECT	a.SOURCEDATAKEY, a.CLAIMID, 0 as PRIMDIAGCODES, 0 as OTHERDIAGCODES
-- 	INTO	#hold_claims
	INTO	dbo.excl_hold_claims
	FROM	EDPS_Data.dbo.CLAIMDIM a
	LEFT OUTER JOIN WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST b
		ON	b.SourceDataKey		= a.SOURCEDATAKEY
		AND	b.claim_id			= a.claimid
	WHERE	a.SOURCEDATAKEY in (30, 50)
-- RETM-160
	AND		(	(b.claim_id	IS NULL) OR
			(b.claim_id IS NOT NULL) AND (b.EXCL_ID = 9019) )
-- end RETM-160
--	AND		b.claim_id	IS NULL
	GROUP BY a.SOURCEDATAKEY, a.CLAIMID

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_claims (sourcedatakey ASC, claimid ASC)

	IF OBJECT_ID('tempDB..#hold_primdiagcodes') IS NOT NULL
	BEGIN
		DROP TABLE #hold_primdiagcodes
	END

	IF OBJECT_ID('dbo.excl_hold_primdiagcodes', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_primdiagcodes
	END
	
	SELECT	a.SOURCEDATAKEY, a.CLAIMID, ISNULL(count(*), 0) as PRIMDIAGCODES
	INTO	dbo.excl_hold_primdiagcodes
	FROM	dbo.excl_hold_claims a
	INNER JOIN EDPS_Data.dbo.CLAIMDIAGNOSISDIM b
		on	b.SourceDataKey		= a.SOURCEDATAKEY
		and	b.CLAIMID			= a.CLAIMID
	WHERE	b.DIAGNOSISTYPECODE	= 'P'
	group by a.SOURCEDATAKEY, a.CLAIMID

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_primdiagcodes (sourcedatakey ASC, claimid ASC)

	IF OBJECT_ID('tempDB..#hold_otherdiagcodes') IS NOT NULL
	BEGIN
		DROP TABLE #hold_otherdiagcodes
	END

	IF OBJECT_ID('dbo.excl_hold_otherdiagcodes', 'U') IS NOT NULL 
	BEGIN	
		DROP TABLE dbo.excl_hold_otherdiagcodes
	END

	SELECT	a.SOURCEDATAKEY, a.CLAIMID, ISNULL(count(*), 0) as OTHERDIAGCODES
	INTO	dbo.excl_hold_otherdiagcodes
	FROM	dbo.excl_hold_claims a
	INNER JOIN EDPS_Data.dbo.CLAIMDIAGNOSISDIM b
		on	b.SourceDataKey		= a.SOURCEDATAKEY
		and	b.CLAIMID			= a.CLAIMID
	WHERE	b.DIAGNOSISTYPECODE	<> 'P'
	GROUP BY a.SOURCEDATAKEY, a.CLAIMID

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_otherdiagcodes (sourcedatakey ASC, claimid ASC)

-- update with Primary Diag Code counts
	UPDATE	dbo.excl_hold_claims
	SET		dbo.excl_hold_claims.PRIMDIAGCODES = b.PRIMDIAGCODES
	FROM	dbo.excl_hold_claims a
	INNER JOIN dbo.excl_hold_primdiagcodes b
		on	b.SOURCEDATAKEY		= a.SOURCEDATAKEY
		and	b.CLAIMID			= a.CLAIMID

-- update with Other Diag Code counts
	UPDATE	dbo.excl_hold_claims
	SET		dbo.excl_hold_claims.OTHERDIAGCODES = b.OTHERDIAGCODES
	FROM	dbo.excl_hold_claims a
	INNER JOIN dbo.excl_hold_otherdiagcodes b
		on	b.SOURCEDATAKEY		= a.SOURCEDATAKEY
		and	b.CLAIMID			= a.CLAIMID

-- finally, the INSERT statements
	INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST
	SELECT	DISTINCT a.CLAIMID, a.SOURCEDATAKEY, @hold_date, 9070,
			CASE b.FORMTYPECODE
					WHEN 'H' THEN 'P'
					WHEN 'U' THEN 'I'
					ELSE b.FORMTYPECODE
			END
	FROM	dbo.excl_hold_claims a
	INNER JOIN EDPS_Data.dbo.CLAIMDIM b
		on	b.SOURCEDATAKEY		= a.SOURCEDATAKEY
		and b.CLAIMID			= a.CLAIMID
	WHERE	a.PRIMDIAGCODES		= 0
	AND		a.OTHERDIAGCODES	<> 0
	ORDER BY a.SOURCEDATAKEY, a.CLAIMID

	INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST
	SELECT	DISTINCT a.CLAIMID, a.SOURCEDATAKEY, @hold_date, 9070,
			CASE b.FORMTYPECODE
					WHEN 'H' THEN 'P'
					WHEN 'U' THEN 'I'
					ELSE b.FORMTYPECODE
			END
	FROM	dbo.excl_hold_claims a
	INNER JOIN EDPS_Data.dbo.CLAIMDIM b
		on	b.SOURCEDATAKEY		= a.SOURCEDATAKEY
		and b.CLAIMID			= a.CLAIMID
	WHERE	PRIMDIAGCODES = 0
	AND		OTHERDIAGCODES = 0 
	ORDER BY a.SOURCEDATAKEY, a.CLAIMID

-----------------
-- RETM-206 begin
-----------------
	IF OBJECT_ID('dbo.excl_hold_claim_lines', 'U') IS NOT NULL 
	BEGIN	
		DROP TABLE dbo.excl_hold_claim_lines
	END

	SELECT	a.SOURCEDATAKEY, a.CLAIMID, a.CLAIMLINEID, 0 as LINEDXCODES
	INTO	dbo.excl_hold_claim_lines	--  #hold_claim_lines
	FROM	EDPS_Data.dbo.CLAIMDETAILDIM a
	INNER JOIN dbo.excl_hold_claims b
		ON	b.sourcedatakey			= a.SOURCEDATAKEY
		AND	b.claimid				= a.CLAIMID
	GROUP BY a.SOURCEDATAKEY, a.CLAIMID, a.CLAIMLINEID

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_claim_lines (sourcedatakey ASC, claimid ASC, claimlineid ASC)

	IF OBJECT_ID('dbo.excl_hold_claim_lines_dxs', 'U') IS NOT NULL 
	BEGIN	
		DROP TABLE dbo.excl_hold_claim_lines_dxs
	END
	
	SELECT	a.SOURCEDATAKEY, a.CLAIMID, a.CLAIMLINEID, COUNT(a.DIAGNOSISCODE) AS LINEDXCODES
	INTO	dbo.excl_hold_claim_lines_dxs	-- 	#hold_claim_lines_dxs
	FROM	EDPS_Data.dbo.CLAIMDETAILDIAGNOSISDIM a
	INNER JOIN dbo.excl_hold_claims b
		ON	b.sourcedatakey			= a.SOURCEDATAKEY
		AND	b.claimid				= a.CLAIMID
	GROUP BY a.SOURCEDATAKEY, a.CLAIMID, a.CLAIMLINEID

	CREATE NONCLUSTERED INDEX tIndex ON dbo.excl_hold_claim_lines_dxs (sourcedatakey ASC, claimid ASC, claimlineid ASC)

	UPDATE	dbo.excl_hold_claim_lines
	SET		LINEDXCODES		= b.LINEDXCODES
	FROM dbo.excl_hold_claim_lines a 
	JOIN dbo.excl_hold_claim_lines_dxs b
		ON	b.SOURCEDATAKEY		= a.SOURCEDATAKEY
		AND b.CLAIMID			= a.CLAIMID
		AND	b.CLAIMLINEID		= a.CLAIMLINEID

	INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST
	SELECT	DISTINCT a.CLAIMID, a.SOURCEDATAKEY,  @hold_date, 9070,
			CASE b.FORMTYPECODE
					WHEN 'H' THEN 'P'
					WHEN 'U' THEN 'I'
					ELSE b.FORMTYPECODE
			END
	FROM	dbo.excl_hold_claim_lines a
	INNER JOIN EDPS_Data.dbo.CLAIMDIM b
		on	b.SOURCEDATAKEY		= a.SOURCEDATAKEY
		and b.CLAIMID			= a.CLAIMID
	WHERE	a.LINEDXCODES		= 0
	AND		b.FORMTYPECODE		= 'H'	-- currently Tracy requested JUST Professional claims be put into the exclusion
										-- technically, we should eliminate the non-PROF claims upstream, but i suspect
										-- they are going to eventually want the non-PROF claims in this exclusion
-- RETM-206 end

	IF OBJECT_ID('tempDB..#hold_claims') IS NOT NULL
	BEGIN
		DROP TABLE #hold_claims
	END

	IF OBJECT_ID('tempDB..#hold_primdiagcodes') IS NOT NULL
	BEGIN
		DROP TABLE #hold_primdiagcodes
	END

	IF OBJECT_ID('tempDB..#hold_otherdiagcodes') IS NOT NULL
	BEGIN
		DROP TABLE #hold_otherdiagcodes
	END

-- we are out of tempdb disk space for 4+ weeks now, so I am creating a work around, using physical tables instead of temp tables
	IF OBJECT_ID('dbo.excl_hold_claims', 'U') IS NOT NULL 
	BEGIN	
		DROP TABLE dbo.excl_hold_claims
	END

	IF OBJECT_ID('dbo.excl_hold_primdiagcodes', 'U') IS NOT NULL 
	BEGIN	
		DROP TABLE dbo.excl_hold_primdiagcodes
	END

	IF OBJECT_ID('dbo.excl_hold_otherdiagcodes', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_otherdiagcodes
	END

	IF OBJECT_ID('dbo.excl_hold_claim_lines', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_claim_lines
	END

	IF OBJECT_ID('dbo.excl_hold_claim_lines_dxs', 'U') IS NOT NULL 
	BEGIN
		DROP TABLE dbo.excl_hold_claim_lines_dxs
	END

	
	UPDATE EXT_SYS_RUNLOG    
	SET END_DT = GETDATE()	    
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
		,TOTAL_RECORDS = @@ROWCOUNT
		,ENTRYDT = GETDATE()    
	WHERE PROC_NAME = 'EXSP_CLAIM_EXCLUSION_HIST - Exclude Claims with no Prim DX'    
	AND END_DT IS NULL
-- end RETM-154
-- end RETM-160

-----------------------------------------------------------------------------
-- RETM-435
-----------------------------------------------------------------------------
-- identify all claims with no Primary DX codes in Sequence 01, 
-- but have primary dx codes in any other Sequence

	SELECT	DISTINCT a.CLAIMID, a.DIAGNOSISCODE, a.DIAGNOSISTYPECODE, a.SEQUENCE, a.DIAGNOSISDESC, a.SourceDataKey, 
			a.LoadDateKey, a.Active, a.Deleted
	INTO	#hold_retm_435_claims
	FROM	EDPS_Data.dbo.CLAIMDIAGNOSISDIM a
	LEFT OUTER JOIN WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST b
		ON	b.claim_id			= a.CLAIMID
		AND	b.SOURCEDATAKEY		= a.SourceDataKey
	WHERE	b.claim_id IS NULL
	AND		a.SourceDataKey = 50
	AND		(a.sequence <> '01' and a.DIAGNOSISTYPECODE = 'P')  

	INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST
	SELECT	DISTINCT a.CLAIMID, a.SOURCEDATAKEY,  @hold_date, 9070,
			CASE b.FORMTYPECODE
					WHEN 'H' THEN 'P'
					WHEN 'U' THEN 'I'
					ELSE b.FORMTYPECODE
			END
	FROM	#hold_retm_435_claims a
	INNER JOIN EDPS_Data.dbo.ClaimDim b
		ON	b.claimid			= a.CLAIMID
		AND	b.SOURCEDATAKEY		= a.SourceDataKey

-- end RETM-435

-- TETDM-1521 remove SDK 2,3,40 from exclusion tables  --NEEDS TO BE LAST THING RUN
			DELETE FROM ext_claim_exclusion_hist
                   WHERE SourceDataKey IN (2,3)
--                   WHERE SourceDataKey IN (2,3,40)	RETM-53 
--				        OR EXCL_ID = 999999999
-- end TETDM-1521


--	RETM-179 New Exclusion 9071
--	Exclude >= 2023 Leon claims  (SDK 30)
	INSERT INTO WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST
	SELECT	DISTINCT b.CLAIMID, b.SOURCEDATAKEY, @hold_date, 9071,
			CASE b.FORMTYPECODE
					WHEN 'H' THEN 'P'
					WHEN 'U' THEN 'I'
					ELSE b.FORMTYPECODE
			END
	FROM	EDPS_Data.dbo.CLAIMDIM b
	WHERE	b.SOURCEDATAKEY			= 30
	AND		b.BeginServiceDateKey	>= '20230101'
-- end RETM-179

-- Scott Waller 04/06/2019	TETDM-1995
--			DROP TABLE	#diag_excl

			IF OBJECT_ID('tempDB..#TETDM753') IS NOT NULL
			BEGIN
				DROP TABLE #TETDM753
			END

			DROP TABLE	#EXT_CLAIM_EXCLUSION_HIST_DP

			IF OBJECT_ID('dbo.excl_TETDM753', 'U') IS NOT NULL 
			BEGIN
				DROP TABLE dbo.excl_TETDM753
			END
-- end			    
				--ASSIGN TOTAL RECORDS		    
				SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM dbo.EXT_CLAIM_EXCLUSION_HIST)	    
				---HRP_CLAIM_FILE Update Run Controls    
						    
						UPDATE EXT_SYS_RUNLOG    
						SET END_DT = GETDATE()	    
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())    
							,TOTAL_RECORDS = @TOTAL_RECORDS    
							,ENTRYDT = GETDATE()    
						WHERE PROC_NAME = 'EXSP_CLAIM_EXCLUSION_HIST'    
								AND END_DT IS NULL

GO
