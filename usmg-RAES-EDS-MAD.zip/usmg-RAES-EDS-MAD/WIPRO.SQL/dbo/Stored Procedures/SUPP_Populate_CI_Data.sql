﻿CREATE PROCEDURE [dbo].[SUPP_Populate_CI_Data]
	/*
	Creation DAte: 11/22/2022
	Author: Anthony Ulmer
	--------------------------------------------

	Notes:
	This procedure takes the stage data from the staging.SUPP_RAPS_CI_DATA, removes duplicates, and then places it in 
	the table dbo.SUPP_RAPS_CI_DATA for further processing.
	Counts of certain data elements are also logged in the table dbo.CI_SysLog.

	Tickets:
	---------------------------------------------
	11/22/2022	TETDM-116	ASU			Initial Creation
	
	
	*/
AS
	SET NOCOUNT ON;
	SET ANSI_NULLS ON;

	DECLARE @CI_Initial_Data_Count INT,
			@Data_Errors INT,
			@Duplicates INT,
			@Not_Reviewed_Count INT;

	--get some counts for ci_log table later
	WITH dup_count AS (
		SELECT
			srcd.CMCR_ID
		   ,srcd.Member_ID
		   ,srcd.Review_Status
		   ,srcd.Market_Abbr
		   ,srcd.Review_Type
		   ,srcd.Event_Type_Desc
		   ,srcd.Submit_Source
		   ,srcd.Created_Date
		   ,srcd.Last_Modified_Date
		   ,srcd.Chart_Prov
		   ,srcd.Start_Date
		   ,srcd.End_Date
		   ,srcd.DOS_Results_ID
		   ,srcd.Document_Prov_ID
		   ,srcd.CMS_Extract_Date
		   ,srcd.DX_Code_Result_ID
		   ,srcd.ICD_Code
		   ,srcd.DX_Code_ID
		   ,srcd.Chart_Prov_Spec
		   ,srcd.Doc_Prov_Spec
		   ,srcd.Appr_Rvw_Stat
		   ,srcd.Appr_Spec
		   ,srcd.Dos_err
		   ,srcd.Dx_Err
		   ,srcd.Dos_del
		   ,srcd.Dx_del
		   ,srcd.CMS_Extract_Elig
		   ,srcd.Do_Not_Extract
		   ,srcd.DX_Code_Version
		   ,srcd.RA_Prov_Type
		   ,CLM_NO = CONVERT(VARCHAR,srcd.CMCR_ID) + '_' + CONVERT(VARCHAR(10),RIGHT('0' + CONVERT(VARCHAR(10),DENSE_RANK() OVER (PARTITION BY srcd.CMCR_ID ORDER by srcd.Document_Prov_ID)),2))
		   --,srcd.Load_Date   
		FROM WIPRO.staging.SUPP_RAPS_CI_DATA srcd
		WHERE 1= 1
			AND srcd.Dos_err != 1
			AND srcd.Dx_Err != 1
			AND srcd.Dos_del != 1
			AND srcd.Dx_del != 1
			AND srcd.Review_Status = 'Reviewed'
		INTERSECT
		SELECT
			srcd.CMCR_ID
		   ,srcd.Member_ID
		   ,srcd.Review_Status
		   ,srcd.Market_Abbr
		   ,srcd.Review_Type
		   ,srcd.Event_Type_Desc
		   ,srcd.Submit_Source
		   ,srcd.Created_Date
		   ,srcd.Last_Modified_Date
		   ,srcd.Chart_Prov
		   ,srcd.Start_Date
		   ,srcd.End_Date
		   ,srcd.DOS_Results_ID
		   ,srcd.Document_Prov_ID
		   ,srcd.CMS_Extract_Date
		   ,srcd.DX_Code_Result_ID
		   ,srcd.ICD_Code
		   ,srcd.DX_Code_ID
		   ,srcd.Chart_Prov_Spec
		   ,srcd.Doc_Prov_Spec
		   ,srcd.Appr_Rvw_Stat
		   ,srcd.Appr_Spec
		   ,srcd.Dos_err
		   ,srcd.Dx_Err
		   ,srcd.Dos_del
		   ,srcd.Dx_del
		   ,srcd.CMS_Extract_Elig
		   ,srcd.Do_Not_Extract
		   ,srcd.DX_Code_Version
		   ,srcd.RA_Prov_Type
		   ,srcd.CLM_NO	   
		FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd)	
	SELECT
		@CI_Initial_Data_Count = (SELECT COUNT(*) FROM staging.SUPP_RAPS_CI_DATA srcd ),
		@Data_Errors = (SELECT COUNT(*) FROM staging.SUPP_RAPS_CI_DATA srcd WHERE srcd.Dx_Err = 1),			
		@Duplicates = (SELECT COUNT(*) FROM dup_count),
		@Not_Reviewed_Count = (SELECT COUNT(*) FROM staging.SUPP_RAPS_CI_DATA srcd WHERE srcd.Review_Status != 'Reviewed');		


	IF OBJECT_ID('tempdb.dbo.#SUPP_RAPS_CI_DATA') IS NOT NULL
		DROP TABLE #SUPP_RAPS_CI_DATA;

	--create temp insert table replica of SUPP_RAPS_CI_DATA without Load_Key
	--this has to be done because the field Load_Key cannot be used in the except statement below
	SELECT
		CMCR_ID
	   ,Member_ID
	   ,Review_Status
	   ,Market_Abbr
	   ,Review_Type
	   ,Event_Type_Desc
	   ,Submit_Source
	   ,Created_Date
	   ,Last_Modified_Date
	   ,Chart_Prov
	   ,Start_Date
	   ,End_Date
	   ,DOS_Results_ID
	   ,Document_Prov_ID
	   ,CMS_Extract_Date
	   ,DX_Code_Result_ID
	   ,ICD_Code
	   ,DX_Code_ID
	   ,Chart_Prov_Spec
	   ,Doc_Prov_Spec
	   ,Appr_Rvw_Stat
	   ,Appr_Spec
	   ,Dos_err
	   ,Dx_Err
	   ,Dos_del
	   ,Dx_del
	   ,CMS_Extract_Elig
	   ,Do_Not_Extract
	   ,DX_Code_Version
	   ,RA_Prov_Type
	   ,Load_Date   
	   ,CLM_NO
	INTO #SUPP_RAPS_CI_DATA
	FROM SUPP_RAPS_CI_DATA
	WHERE 1 = 2;


	--Insert NEW records only into temp table
	INSERT INTO #SUPP_RAPS_CI_DATA
	(
		CMCR_ID   ,Member_ID   ,Review_Status   ,Market_Abbr   ,Review_Type
	   ,Event_Type_Desc   ,Submit_Source   ,Created_Date   ,Last_Modified_Date
	   ,Chart_Prov   ,Start_Date   ,End_Date   ,DOS_Results_ID   ,Document_Prov_ID
	   ,CMS_Extract_Date   ,DX_Code_Result_ID   ,ICD_Code   ,DX_Code_ID   ,Chart_Prov_Spec
	   ,Doc_Prov_Spec   ,Appr_Rvw_Stat   ,Appr_Spec   ,Dos_err   ,Dx_Err   ,Dos_del
	   ,Dx_del   ,CMS_Extract_Elig   ,Do_Not_Extract   ,DX_Code_Version   ,RA_Prov_Type   ,CLM_NO
	)
	SELECT
		srcd.CMCR_ID
	   ,srcd.Member_ID
	   ,srcd.Review_Status
	   ,srcd.Market_Abbr
	   ,srcd.Review_Type
	   ,srcd.Event_Type_Desc
	   ,srcd.Submit_Source
	   ,srcd.Created_Date
	   ,srcd.Last_Modified_Date
	   ,srcd.Chart_Prov
	   ,srcd.Start_Date
	   ,srcd.End_Date
	   ,srcd.DOS_Results_ID
	   ,srcd.Document_Prov_ID
	   ,srcd.CMS_Extract_Date
	   ,srcd.DX_Code_Result_ID
	   ,srcd.ICD_Code
	   ,srcd.DX_Code_ID
	   ,srcd.Chart_Prov_Spec
	   ,srcd.Doc_Prov_Spec
	   ,srcd.Appr_Rvw_Stat
	   ,srcd.Appr_Spec
	   ,srcd.Dos_err
	   ,srcd.Dx_Err
	   ,srcd.Dos_del
	   ,srcd.Dx_del
	   ,srcd.CMS_Extract_Elig
	   ,srcd.Do_Not_Extract
	   ,srcd.DX_Code_Version
	   ,srcd.RA_Prov_Type
	   ,CLM_NO = CONVERT(VARCHAR,srcd.CMCR_ID) + '_' + CONVERT(VARCHAR(10),RIGHT('0' + CONVERT(VARCHAR(10),DENSE_RANK() OVER (PARTITION BY srcd.CMCR_ID ORDER by srcd.Document_Prov_ID)),2))
	FROM WIPRO.staging.SUPP_RAPS_CI_DATA srcd
	WHERE 1= 1
		AND srcd.Dos_err != 1
		AND srcd.Dx_Err != 1
		AND srcd.Dos_del != 1
		AND srcd.Dx_del != 1
		AND srcd.Review_Status = 'Reviewed'
	EXCEPT
	SELECT
		srcd.CMCR_ID
	   ,srcd.Member_ID
	   ,srcd.Review_Status
	   ,srcd.Market_Abbr
	   ,srcd.Review_Type
	   ,srcd.Event_Type_Desc
	   ,srcd.Submit_Source
	   ,srcd.Created_Date
	   ,srcd.Last_Modified_Date
	   ,srcd.Chart_Prov
	   ,srcd.Start_Date
	   ,srcd.End_Date
	   ,srcd.DOS_Results_ID
	   ,srcd.Document_Prov_ID
	   ,srcd.CMS_Extract_Date
	   ,srcd.DX_Code_Result_ID
	   ,srcd.ICD_Code
	   ,srcd.DX_Code_ID
	   ,srcd.Chart_Prov_Spec
	   ,srcd.Doc_Prov_Spec
	   ,srcd.Appr_Rvw_Stat
	   ,srcd.Appr_Spec
	   ,srcd.Dos_err
	   ,srcd.Dx_Err
	   ,srcd.Dos_del
	   ,srcd.Dx_del
	   ,srcd.CMS_Extract_Elig
	   ,srcd.Do_Not_Extract
	   ,srcd.DX_Code_Version
	   ,srcd.RA_Prov_Type
	   ,srcd.CLM_NO   
	FROM WIPRO.dbo.SUPP_RAPS_CI_DATA srcd;

	--insert data into dbo schema table
	INSERT INTO SUPP_RAPS_CI_DATA (
		CMCR_ID   ,Member_ID   ,Review_Status   ,Market_Abbr   ,Review_Type   ,Event_Type_Desc   ,Submit_Source
	   ,Created_Date   ,Last_Modified_Date   ,Chart_Prov   ,Start_Date   ,End_Date   ,DOS_Results_ID   ,Document_Prov_ID
	   ,CMS_Extract_Date   ,DX_Code_Result_ID   ,ICD_Code   ,DX_Code_ID   ,Chart_Prov_Spec   ,Doc_Prov_Spec   ,Appr_Rvw_Stat
	   ,Appr_Spec   ,Dos_err   ,Dx_Err   ,Dos_del   ,Dx_del   ,CMS_Extract_Elig   ,Do_Not_Extract   ,DX_Code_Version
	   ,RA_Prov_Type   ,Load_Date, Load_Key ,CLM_NO
	)
	SELECT
		CMCR_ID
	   ,Member_ID
	   ,Review_Status
	   ,Market_Abbr
	   ,Review_Type
	   ,Event_Type_Desc
	   ,Submit_Source
	   ,Created_Date
	   ,Last_Modified_Date
	   ,Chart_Prov
	   ,Start_Date
	   ,End_Date
	   ,DOS_Results_ID
	   ,Document_Prov_ID
	   ,CMS_Extract_Date
	   ,DX_Code_Result_ID
	   ,ICD_Code
	   ,DX_Code_ID
	   ,Chart_Prov_Spec
	   ,Doc_Prov_Spec
	   ,Appr_Rvw_Stat
	   ,Appr_Spec
	   ,Dos_err
	   ,Dx_Err
	   ,Dos_del
	   ,Dx_del
	   ,CMS_Extract_Elig
	   ,Do_Not_Extract
	   ,DX_Code_Version
	   ,RA_Prov_Type
	   ,GETDATE()
	   ,(SELECT ISNULL(MAX(Load_Key),0) + 1 FROM WIPRO.dbo.SUPP_RAPS_CI_DATA) --add load_key (from prior supp process)
	   ,CLM_NO   
	FROM #SUPP_RAPS_CI_DATA;


	INSERT INTO dbo.CI_SysLog (CI_Initial_Data_Count, Data_Errors, Duplicates, Final_CI_Claims, Load_Date, Not_Reviewed_Count)
	SELECT
		@CI_Initial_Data_Count,
		@Data_Errors,
		@Duplicates,
		@@rowcount, --from insert above
		GETDATE(),
		@Not_Reviewed_Count;

	IF OBJECT_ID('tempdb.dbo.#SUPP_RAPS_CI_DATA') IS NOT NULL
		DROP TABLE #SUPP_RAPS_CI_DATA;

	SET NOCOUNT OFF;

RETURN 0
