﻿CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_MMAI_INST_CLM_FILE_IMP]
(@SOURCEDATAKEY INT, @LOB CHAR(10), @JOBID INT)--, @REJ_REA_ID CHAR(8) = ' ')--,@BEGIN_BILLTYPECODE CHAR(5) , @END_BILLTYPECODE CHAR(5))
AS
/***************************************************************************************************
** CREATE DATE: 08/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL EXECUTE REQUIRD STEPS FOR COMPILING HRP MHC CLAIM SUBMISSIONS.
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.2. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
09/25/13		Loyal Ricks		Replaced call to EXSP_HRP_CLAIM_EDSPROVIDER_INST with call to 
								EXSP_HRP_CLAIM_INST_EDSPROVIDER
11/08/13		Loyal Ricks		Add bed type range input parameters
06/19/14		Loyal Ricks		Upgrade Verisk Map from V3.2 to V4.0 - EXSP_HRP_CLAIM_INST_MAP_V40
------------------------------------------------------------------------------------------------------
08/2014			Loyal Ricks		WIPRO Implementation
09/10/14		Loyal Ricks		EDS-396 - Add sp - pr_BUILD_OUTB_INST_WIPRO_DATASCRUB
09/23/14		Loyal Ricks		Add @LOB to be used during BUILD_OUTB_INST_MAP
*****************************************************************************************************/	
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT
		

--HRP_CLAIM_FILE Run controls
			BEGIN TRANSACTION 
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_BUILD_OUTB_INST_CLM_FILE'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					if @@ERROR <> 0
							begin
								rollback 
							end
				commit
					----JOBID = 9000 is the EDS Exclusion submission job. Exclusion history build should not be excuted for JOBID 9000
					IF @JOBID <> 9000
					BEGIN
						EXECUTE EXSP_WIPRO_CLAIM_EXCLUSION @SOURCEDATAKEY
					END
					EXECUTE pr_BUILD_OUTB_INST_CLM_HEADER_MMAI_IMP @SOURCEDATAKEY--,@JOBID--,@REJ_REA_ID
					--EXECUTE EXSP_HRP_CLAIM_INST_CLMHEADER @SOURCEDATAKEY,@BEGIN_BILLTYPECODE  , @END_BILLTYPECODE 
					EXECUTE pr_BUILD_OUTB_INST_CLM_DETAIL
					--EXECUTE EXSP_HRP_CLAIM_PROF_DIAG
					--EXECUTE EXSP_HRP_CLAIM_PROF_DIAG_POINTERS
					EXECUTE pr_BUILD_OUTB_INST_EDSPROVIDER
					EXECUTE pr_BUILD_OUTB_INST_ADJUSTMENTS
					--EXECUTE EXSP_HRP_CLAIM_INST_REQ5010
					EXECUTE pr_BUILD_OUTB_INST_OCCURANCECODE
					EXECUTE pr_BUILD_OUTB_INST_CONDITIONCODE
					EXECUTE pr_BUILD_OUTB_INST_WIPRO_DATASCRUB
					--MAP CLAIM DATA FOR FILE PREPARATION
					EXECUTE pr_BUILD_OUTB_INST_MAP @LOB
					
			
	
			
			--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_HEADER)
			SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM OUTB_INST_DETAIL)
									
		----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_CLM_FILE'
										and END_DT is null
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
