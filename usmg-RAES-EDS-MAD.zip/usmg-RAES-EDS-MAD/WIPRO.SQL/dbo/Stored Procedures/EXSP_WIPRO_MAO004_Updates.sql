﻿


CREATE PROCEDURE [dbo].[EXSP_WIPRO_MAO004_Updates]

AS

/***************************************************************************************************
** CREATE DATE: 02/2016
**
** AUTHOR: LOYAL RICKS - Loyal Ricks
**
** DESCRIPTION: Procedure will update the OUTB_CLAIM_STATUS table from the  inbound WIPRO MAO004.
**				these updates will be used to facilitate updates for EDS claim submissions as 
**				claims are processed from WIPRO to CMS
**				
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------

*****************************************************************************************************/	
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE	@TOTAL_RECORDS INT
		
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('EXSP_WIPRO_MAO004_Updates'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
								if OBJECT_ID ('tempdb..#TMP_WIPRO_MAO004') <> 0	
								DROP TABLE #TMP_WIPRO_MAO004

								CREATE TABLE #TMP_WIPRO_MAO004
								(CLAIM_ID VARCHAR(20),
								WIPRO_CLAIM_ID VARCHAR(20),
								CLMSTAT_STATUS VARCHAR(50)
								)

								
								--Process MAO004 records
								INSERT INTO #TMP_WIPRO_MAO004
								SELECT DISTINCT CLAIMID,
												WIPRO_CLAIMID,
												'MAO-004'
								FROM MAO_004_DETAIL_Daily

								---Update OUTB_CLAIM_STATUS.CLMSTAT_STATUS FROM INBOUND MAO004
								UPDATE OUTB_CLAIM_STATUS 
								SET CLMSTAT_STATUS = W.CLMSTAT_STATUS
								FROM OUTB_CLAIM_STATUS C
								INNER JOIN  #TMP_WIPRO_MAO004 W
								ON C.CLAIM_ID = W.CLAIM_ID 
								AND C.WIPRO_CLAIM_ID = W.WIPRO_CLAIM_ID

						--ASSIGN @TOTAL_RECORDS - GET RECORD COUNTS For table being archived
								SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #TMP_WIPRO_MAO004)
								
																			
							---- Update Run Controls 
									
								UPDATE EXT_SYS_RUNLOG
								SET END_DT = GETDATE()	
									,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
									,TOTAL_RECORDS = @TOTAL_RECORDS
									,ENTRYDT = GETDATE()
								WHERE PROC_NAME = 'EXSP_WIPRO_MAO004_Updates'
												and END_DT is null

