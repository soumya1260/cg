﻿CREATE PROCEDURE dbo.pr_Supp_Add_Resub
/******************************************
Create Date: 10/08/2019
Author: Anthony Ulmer

NOTES:
10/08/2019: Initial Creation


*******************************************/
AS

SET NOCOUNT ON;

WITH source_data
AS
(SELECT
		Plan_No =			   NULLIF(NULLIF(sra.Plan_No, 'null'), '')
	   ,Hic_No =			   NULLIF(NULLIF(sra.Hic_No, 'null'), '')
	   ,X_HICN =			   NULLIF(NULLIF(sra.X_HICN, 'null'), '')
	   ,X_MBI =				   NULLIF(NULLIF(sra.X_MBI, 'null'), '')
	   ,Member_ID =			   NULLIF(NULLIF(sra.Member_ID, 'null'), '')
	   ,From_Date =			   NULLIF(NULLIF(sra.From_Date, 'null'), '')
	   ,Thru_Date =			   NULLIF(NULLIF(sra.Thru_Date, 'null'), '')
	   ,Provider_Type =		   NULLIF(NULLIF(sra.Provider_Type, 'null'), '')
	   ,Dx_Code =			   NULLIF(NULLIF(sra.Dx_Code, 'null'), '')
	   ,icd_version =		   NULLIF(NULLIF(sra.icd_version, 'null'), '')
	   ,Source_System =		   NULLIF(NULLIF(sra.Source_System, 'null'), '')
	   ,Source_System_Number = NULLIF(NULLIF(sra.Source_System_Number, 'null'), '')
	   ,Source_Type =		   NULLIF(NULLIF(sra.Source_Type, 'null'), '')
	   ,Patient_Control_No =   NULLIF(NULLIF(sra.Patient_Control_No, 'null'), '')
	   ,DOS_YR =			   NULLIF(NULLIF(sra.DOS_YR, 'null'), '')
	   ,Linked_Claim_number =  NULLIF(NULLIF(sra.Linked_Claim_number, 'null'), '')
	   ,WIPRO_CLAIM_NO =	   NULLIF(NULLIF(sra.WIPRO_CLAIM_NO, 'null'), '')
	   ,CHS_CLM_EDPS =		   NULLIF(NULLIF(sra.CHS_CLM_EDPS, 'null'), '')
	   ,CMS_ICN =			   NULLIF(NULLIF(sra.CMS_ICN, 'null'), '')
	   ,Supp_Type =			   NULLIF(NULLIF(sra.Supp_Type, 'null'), '')
	   ,[DATA_SOURCE] =		   NULLIF(NULLIF(sra.DATA_SOURCE, 'null'), '')
	   ,Document_Prov_ID =	   NULLIF(NULLIF(sra.Document_Prov_ID, 'null'), '')
	   ,Chart_Prov =		   NULLIF(NULLIF(sra.Chart_Prov, 'null'), '')
	   ,Chart_Chase_NPI =	   NULLIF(NULLIF(sra.Chart_Chase_NPI, 'null'), '')
	   ,EXCL_ID =			   NULLIF(NULLIF(sra.EXCL_ID, 'null'), '')
	   ,STATUS_CODE =		   NULLIF(NULLIF(sra.STATUS_CODE, 'null'), '')
	   ,Status_desc =		   NULLIF(NULLIF(sra.Status_desc, 'null'), '')
	   ,OB_CLM_STATUS =		   NULLIF(NULLIF(sra.OB_CLM_STATUS, 'null'), '')
	   ,REJ_RSN_ID =		   NULLIF(NULLIF(sra.REJ_RSN_ID, 'null'), '')
	   ,REJ_RSN_DESC =		   NULLIF(NULLIF(sra.REJ_RSN_DESC, 'null'), '')
	   ,Process_Date =		   NULLIF(NULLIF(sra.Process_Date, 'null'), '')
	   ,Last_Modified =		   NULLIF(NULLIF(sra.Last_Modified, 'null'), '')
	   ,sra.Submission_Indicator
	   ,FILE_TYPE =			   NULLIF(NULLIF(sra.FILE_TYPE, 'null'), '')
	FROM WIPRO.staging.SUPP_Resub_Add sra
	GROUP BY sra.Plan_No
			,sra.Hic_No
			,sra.X_HICN
			,sra.X_MBI
			,sra.Member_ID
			,sra.From_Date
			,sra.Thru_Date
			,sra.Provider_Type
			,sra.Dx_Code
			,sra.icd_version
			,sra.Source_System
			,sra.Source_System_Number
			,sra.Source_Type
			,sra.Patient_Control_No
			,sra.DOS_YR
			,sra.Linked_Claim_number
			,sra.WIPRO_CLAIM_NO
			,sra.CHS_CLM_EDPS
			,sra.CMS_ICN
			,sra.Supp_Type
			,sra.DATA_SOURCE
			,sra.Document_Prov_ID
			,sra.Chart_Prov
			,sra.Chart_Chase_NPI
			,sra.EXCL_ID
			,sra.STATUS_CODE
			,sra.Status_desc
			,sra.OB_CLM_STATUS
			,sra.REJ_RSN_ID
			,sra.REJ_RSN_DESC
			,sra.Process_Date
			,sra.Last_Modified
			,sra.Submission_Indicator
			,sra.FILE_TYPE)
MERGE WIPRO.dbo.Supplemental_INPUT AS si 
USING source_data AS source
ON si.Member_ID = source.Member_ID
	AND si.From_Date = source.From_Date
	AND si.Thru_Date = source.Thru_Date
	AND si.Provider_Type = source.Provider_Type
	AND si.Dx_Code = source.Dx_Code
	AND si.Source_System = source.Source_System
	AND si.Source_System_Number = source.Source_System_Number
	AND si.Patient_Control_No = source.Patient_Control_No
	AND si.Data_Source = source.Data_Source
	AND si.STATUS_CODE = source.STATUS_CODE
	AND si.Status_desc = source.Status_desc
	AND si.Process_Date = si.Process_Date
WHEN MATCHED
	AND source.FILE_TYPE LIKE ('%resub%')
	THEN UPDATE
		SET si.EXCL_ID = source.EXCL_ID
		   ,si.STATUS_CODE = source.REJ_RSN_ID
		   ,si.Status_desc = source.REJ_RSN_DESC
		   ,si.Submission_Indicator = source.Submission_Indicator
		   ,si.Last_Modified = GETDATE()
WHEN NOT MATCHED
	AND source.FILE_TYPE LIKE ('%add%')
	THEN INSERT (Plan_No, Hic_No, X_HICN, X_MBI, Member_ID, From_Date
		, Thru_Date, Provider_Type, Dx_Code, icd_version, Source_System
		, Source_System_Number, Source_Type, Patient_Control_No
		, DOS_YR, Linked_Claim_number, WIPRO_CLAIM_NO, CHS_CLM_EDPS
		, CMS_ICN, Supp_Type, Data_Source, Document_Prov_ID
		, Chart_Prov, Chart_Chase_NPI, EXCL_ID, STATUS_CODE
		, Status_desc, OB_CLM_STATUS
		, REJ_RSN_ID, REJ_RSN_DESC
		, Process_Date, Last_Modified
		, Submission_Indicator)
			VALUES (source.Plan_No, source.Hic_No, source.X_HICN, source.X_MBI, 
					source.Member_ID, source.From_Date, source.Thru_Date, source.Provider_Type, 
					source.Dx_Code, source.icd_version, source.Source_System, source.Source_System_Number, 
					source.Source_Type, source.Patient_Control_No, source.DOS_YR, source.Linked_Claim_number, 
					source.WIPRO_CLAIM_NO, source.CHS_CLM_EDPS, source.CMS_ICN, source.Supp_Type, source.Data_Source, 
					source.Document_Prov_ID, source.Chart_Prov, source.Chart_Chase_NPI, source.EXCL_ID, 
					source.STATUS_CODE, source.Status_desc, source.OB_CLM_STATUS, source.REJ_RSN_ID, 
					source.REJ_RSN_DESC, GETDATE(), GETDATE(), source.Submission_Indicator);

SET NOCOUNT OFF;
