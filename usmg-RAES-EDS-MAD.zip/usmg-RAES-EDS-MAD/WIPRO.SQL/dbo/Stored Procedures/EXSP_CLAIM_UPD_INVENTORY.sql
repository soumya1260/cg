﻿CREATE PROCEDURE [dbo].[EXSP_CLAIM_UPD_INVENTORY]
AS
/***************************************************************************************************
** CREATE DATE: 07/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL UPDATE EXT_EDPS_CLAIM_STATUS TABLE WITH CLAIM INVENTORY
**			    DATA FROM RECENT CLAIM STATUS FROM INBOUND HRP CLAIMSTAT FILES.
**				THIS DATA WILL BE USED TO ASSIST MDQO WITH 
**				AUDITING AND TRACKING CLAIM INVENTORY SENT TO HRP FOR EDS CMS SUBMISSIONS.
**				THIS PROCEDURE WILL RUN DIRECTLY AFTER EACH CLAIM INTAKE SSIS PACKAGE RUN. 
**				THE EXT_HRP_CLAIM_RECON TABLE IS A HISTORICAL TABLE. 
**				DATA WILL GET UPDATED FROM THIS PROCESS.
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
04/01/2013		LOYAL RICKS		Add claim exclusion status updates
04/09/2013		LOYAL RICKS		Add claim exclusion status updates for claim provider errors
05/16/2012		Loyal Ricks		Add new HRP Claim Exclusion Codes 
								Add new exclusion, invalid POS - when substring(pos,1,1) = '-'
								Add CMS_ICN temporary updates from adhoc file received from HRP
								Add EDPS_PROD status updates - EDPS_PROD.EXT_HRP_MAP_HIST &
									EDPS_PROD.EXT_HRP_CLAIM_STATUS tables are required. Import and 
									rename tables with suffix = _PROD.
11/08/13		Loyal Ricks		Revise logic to "reset" EXT_EDPS_CLAIM_STATUS.CLMSTAT_STATUS during 
								processing. This will ensure the most recent individual claim status
								is being captured. Revised required to support removal of exclusions.
								First every exclusion (9002) is being removed due to successful support
								code migration.
03/03/14		Loyal Ricks		Add DP-2012 - Identify claims using inventory. This will allow all 
								available claims to continue "Current life cycle of a Claim".
								Altered Column EXT_EDPS_CLAIM_STATUS.CLMSTAT_STATUS FROM 10 TO 20 CHAR.
								Increased width required for "DP-CCYY" tag.
05/13/14		Loyal Ricks		Remove temporary ICN report logic due to MAO002 implementation
05/13/14		Loyal Ricks		Remove temporary ICN report logic due to MAO002 implementation
05/23/14		Loyal Ricks		Add Denied Clmstat_status - Use BIDW source denied flag to determine updates
								Add Non-Denied Adjustment Claim Status for known adjustments according to EDS documented
								adjustment rules. Non-Denied Adjustments may not apply to some sources (3,30,4)
06/05/14		Loyal Ricks		ADD New Claim Status. CLMSTAT_STATUS Value = 'MMAI'
								Add New Claim Status EXT_EDPS_CLAIM_STATUS.CLMSTAT_STATUS = 'BIDW-INACTIVE'
								Add New Claim Status EXT_EDPS_CLAIM_STATUS.CLMSTAT_STATUS = 'BIDW-DELETED'
-----------------------------------------------------------------------------------------------------
08/20/14		Loyal Ricks		WIPRO Implementation

09/23/14		Loyal Ricks		Add temporary use of INB_WIPRO_CLM_REJ_HIST table to get WIPRO rejections
								during 10W40 Initial production phase. Remove reference once clmstat file 
								is implemented.
01/23/15		Loyal Ricks		Added EXT_EDPS_CLAIM_STATUS.CLAIM_TYPE = E (DME CLAIM) Updates from EXT_CLAIM_DME
								Added EXT_EDPS_CLAIM_STATUS.CLMSTAT_STATUS = '9023' Claim Check Sum Exclusons
07/22/15		Loyal Ricks		Add EXT_EDPS_CLAIM_STATUS.CLMSTAT_STATUS - 'WIPRO MAO002 ERROR' - Claims with 
								a OUTB_CLAIM_STATUS.CLMSTAT_STATUS Value = 'A-ICN' that have a blank CMS_ICN
								NUMBER
09/18/15		Loyal Ricks		Remove logic for - 'WIPRO CLMSTAT ERROR'
09/18/15		Loyal Ricks		Remove logic for - 'WIPRO MAO002 ERROR'
10/23/15		Loyal Ricks		Update EXT_EDPS_CLAIM_STATUS.HPLAN TO '00000' WHEN NULL OR LEN(HPLAN) = 0 
								OR SUBSTRING(HPLAN,1,1) = '-'
01/22/16		Loyal Ricks		TETDM-645 - Prevent DP claims exclusions from being updated to inventory. this will be
								done to ensure all DP claims keep current status and not DP status.
*****************************************************************************************************/			
			
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RECON WHERE ENTRYDT = @ENTRYDT
							DECLARE
										
								@TOTAL_RECORDS INT,
								@ENTRYDT DATETIME
								
							--ASSIGN @ENTRYDT TO EXECUTION DATETIME

								SET @ENTRYDT = (GETDATE())
								
								
							--EXSP_HRP_CLAIM_RECON RUN CONTROLS
							INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('EXSP_CLAIM_UPD_INVENTORY'
											,'Claim Inventory'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE()
											)

					--Reset all Previous Excluded claims to ensure only claims currently excluded will be updated
									
									update EXT_EDPS_CLAIM_STATUS
									SET CLMSTAT_STATUS = ' ' 
									WHERE CLMSTAT_STATUS NOT IN ('A','A-ICN','P','R','R-ICN','999-A','999-R','277-A','277-R')	


					---Update claims identified as DME claims
							
									UPDATE EXT_EDPS_CLAIM_STATUS
									SET CLAIM_TYPE = CD.CLAIM_TYPE
									FROM EXT_EDPS_CLAIM_STATUS ES
									INNER JOIN EXT_CLAIM_DME CD
									ON ES.SOURCEDATAKEY = CD.SOURCEDATAKEY
									AND ES.CLAIMID = CD.CLAIMID 
									WHERE ES.CLAIM_TYPE <> 'E'

					--Update Claim Check Sum 
					--Claims where claim header total charges do not match claim line total charges

									UPDATE EXT_EDPS_CLAIM_STATUS
									SET CLMSTAT_STATUS = '9023'
									FROM EXT_EDPS_CLAIM_STATUS ES
									INNER JOIN EXT_CLAIM_CHKSUM CD
									ON ES.SOURCEDATAKEY = CD.SOURCEDATAKEY
									AND ES.CLAIMID = CD.CLAIM_ID 
						
	--##GET CURRENT STATUS FOR CLAIM IN ORDER TO UPDATE INVENTORY
				--STEP 1 GET MAX FILEID WHICH IDENTIFIES LATEST FILE CONTAINING OUTBOUND CLAIMS 
							IF OBJECT_ID('TEMPDB..#WIPRODEV_STATUS') <> 0
								DROP TABLE #WIPRODEV_STATUS
								
							CREATE TABLE #WIPRODEV_STATUS(
								[CLAIM_ID] [varchar](20) NULL,
								[FILEID] [char](50) NULL,
								[SOURCEDATAKEY] [int] NULL
								)
				
							
							INSERT INTO #WIPRODEV_STATUS
							SELECT CLAIM_ID
									,max(FILEID)
									,SOURCEDATAKEY
							FROM VW_OUTB_CLAIM_STATUS
							--Get all current status regardless of fileid
							--WHERE FILEID >= @FILEID
							group by CLAIM_ID,SOURCEDATAKEY
							
							--GROUP BY CLAIM_ID,SOURCEDATAKEY,FILEID
							--ORDER BY CLAIM_ID,SOURCEDATAKEY,FILEID
				--STEP 2
							IF OBJECT_ID('TEMPDB..#TMPDEV_CLMSTAT') <> 0
								DROP TABLE #TMPDEV_CLMSTAT
								
							CREATE TABLE #TMPDEV_CLMSTAT(
								[CLAIM_ID] [varchar](20) NULL,
								--[HRP_CLAIM_ID] [varchar](20) NULL,
								[CLM_IND] [varchar](20) NULL,
								[CLAIM_TYPE] [varchar](1) NULL,
								[FILEID] [char](50) NULL,
								[CMS_ICN] [varchar](20) NULL,
								[CLMSTAT_STATUS] [varchar](50) NULL,
								[SOURCEDATAKEY] [int] NULL,
								[STAT_REJ_REA_ID] [varchar](8) NULL,
								[LAST_UPD_DATE] [datetime] NULL
								)
								
							 
							INSERT INTO #TMPDEV_CLMSTAT			 		
							SELECT CS.CLAIM_ID
									--,CS.HRP_CLAIM_ID
									,CS.CLM_IND
									,CLAIM_TYPE
									,CS.FILEID
									,CS.CMS_ICN
									,ISNULL(CLMSTAT_STATUS,'P') AS 'CLMSTAT_STATUS'
									,CS.SOURCEDATAKEY
									,STAT_REJ_REA_ID
									,LAST_UPD_DATE
							FROM OUTB_CLAIM_STATUS CS
									,#WIPRODEV_STATUS HS
							WHERE CS.CLAIM_ID = HS.CLAIM_ID
								AND CS.FILEID = HS.FILEID
								and cs.SOURCEDATAKEY = HS.sourcedatakey
							GROUP BY CS.CLAIM_ID
									--,CS.HRP_CLAIM_ID	
									,CLM_IND
									,CLAIM_TYPE
									,CS.FILEID
									,CS.CMS_ICN
									,CLMSTAT_STATUS
									,CS.SOURCEDATAKEY
									,STAT_REJ_REA_ID
									,LAST_UPD_DATE
							
								
							---UPDATE EXT_EDPS_CLAIM_STATUS WITH CURRENT 
							
							UPDATE EXT_EDPS_CLAIM_STATUS
							SET CLAIM_TYPE = TCS.CLAIM_TYPE
								,CLMSTAT_STATUS = TCS.CLMSTAT_STATUS
								,CLM_IND = TCS.CLM_IND
								,CMS_ICN = TCS.CMS_ICN
								,FILEID = TCS.FILEID
								--,HRP_CLAIM_ID = TCS.HRP_CLAIM_ID
								,LAST_UPD_DATE = @ENTRYDT
							FROM EXT_EDPS_CLAIM_STATUS ECS
								,#TMPDEV_CLMSTAT TCS
							WHERE ECS.CLAIMID = TCS.CLAIM_ID
								AND ECS.SOURCEDATAKEY = TCS.SOURCEDATAKEY
							

				
								
				---claim exclusion status updates
				--01/01/22 - Exclude all Discontinue Pursuit Claim exclusions from being updated to inventory
				-----discontinue pursuit claims will report current claim status and not DP status 			
 						
							--Get configured DP exclusion id

							SELECT convert(int, SUBSTRING(CNTRL_TXT,6,4)) AS 'EXCL_ID'
							INTO  #TMP_DP
							FROM EXT_SYS_CLM_JOBCNTRL
							WHERE SOURCEDATAKEY = 999999999
							
							--Verisk Exclusion
							insert into #tmp_dp
							values(999999999)

							UPDATE EXT_EDPS_CLAIM_STATUS
							SET CLMSTAT_STATUS = RTRIM(convert(char, EXCL_ID))
							FROM EXT_EDPS_CLAIM_STATUS ECS
							JOIN EXT_CLAIM_EXCLUSION_HIST XH
							ON ECS.CLAIMID = XH.claim_id
							AND ECS.SOURCEDATAKEY = XH.SOURCEDATAKEY
							where LEN(isnull(ECS.CLMSTAT_STATUS,' ')) = 0
							and xh.excl_id not in (select excl_id from #TMP_DP)
							
							
				--CAPTURE MISSING CLAIMS FROM WIPRO CLMSTAT FILES
					
							
				--				IF OBJECT_ID('TEMPDB..#CLMSTAT') <> 0
				--						DROP TABLE #CLMSTAT
				--				CREATE TABLE #CLMSTAT
				--				(FILEID VARCHAR(50)
				--				)
				--				INSERT INTO #CLMSTAT
				--				select fileid 
				--				from OUTB_FILE_HIST
				--				WHERE STAT_FILE_ID IS NOT NULL


				--				IF OBJECT_ID('TEMPDB..#CLMSTAT_CLAIMID') <> 0
				--						DROP TABLE #CLMSTAT_CLAIMID

				--					CREATE TABLE #CLMSTAT_CLAIMID
				--					(CLAIMID VARCHAR(20),
				--					 SOURCEDATAKEY INT
				--					 )
				--				 INSERT INTO #CLMSTAT_CLAIMID
				--				SELECT CLAIM_ID,SOURCEDATAKEY
				--				FROM OUTB_CLAIM_STATUS CS
				--				INNER JOIN #CLMSTAT C
				--				ON CS.FILEID = C.FILEID 
				--				WHERE CLMSTAT_STATUS IS NULL

				--				UPDATE EXT_EDPS_CLAIM_STATUS
				--				SET CLMSTAT_STATUS = 'WIPRO CLMSTAT ERROR'
				--				FROM EXT_EDPS_CLAIM_STATUS C
				--				INNER JOIN #CLMSTAT_CLAIMID CC
				--				ON C.SOURCEDATAKEY = CC.SOURCEDATAKEY
				--				AND C.CLAIMID = CC.CLAIMID 
			
				----Capture Missing CMS_ICN for claims with A-ICN status

								
				--				IF OBJECT_ID('TEMPDB..#MAO002_CLAIMID') <> 0
				--						DROP TABLE #MAO002_CLAIMID

				--					CREATE TABLE #MAO002_CLAIMID
				--					(CLAIMID VARCHAR(20),
				--					 SOURCEDATAKEY INT
				--					 )
				--				 INSERT INTO #MAO002_CLAIMID
				--				SELECT CLAIM_ID,SOURCEDATAKEY
				--				FROM OUTB_CLAIM_STATUS CS
				--				WHERE CLMSTAT_STATUS = 'A-ICN' 
				--					AND LEN(CMS_ICN) = 0

				--				UPDATE EXT_EDPS_CLAIM_STATUS
				--				SET CLMSTAT_STATUS = 'WIPRO MAO002 ERROR'
				--				FROM EXT_EDPS_CLAIM_STATUS C
				--				INNER JOIN #MAO002_CLAIMID CC
				--				ON C.SOURCEDATAKEY = CC.SOURCEDATAKEY
				--				AND C.CLAIMID = CC.CLAIMID 

				--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RECON

				--TEMPORARY UPDATE DURING INITIAL IMPLEMENTATION (10W40)
				--REMOVE ONCE WIPRO CLMSTAT IS IMPLEMENTED.
							
								

								--UPDATE EXT_EDPS_CLAIM_STATUS
								--SET CLMSTAT_STATUS =  RTRIM(ERRORSOURCE)+ '-' +rtrim(ERRORCODE) 
								--FROM EXT_EDPS_CLAIM_STATUS C
								--INNER JOIN INB_WIPRO_CLM_REJ_HIST H
								--ON C.CLAIMID = H.ClaimRefNbr
								
				---Update all Verisk Health Claim submisson from EDS_MASTER_CLAIM_STATUS TABLE
				--EDS_MASTER_CLAIM_STATUS IS THE FINAL SNAPSHOT FROM hstnedsdb01.EDPS.EXT_HRP_CLAIM_STATUS
				--WHICH INCLUDES ALL CLAIMS SUBMITTED TO VERISK HEALTH.


								
								--UPDATE EXT_EDPS_CLAIM_STATUS
								--SET CLMSTAT_STATUS = 'VERISK' + '-' + RTRIM(EE.CLMSTAT_STATUS)
								--FROM EXT_EDPS_CLAIM_STATUS EE
								--INNER JOIN EDS_MASTER_CLAIM_STATUS EM
								--ON EE.SOURCEDATAKEY = EM.SOURCEDATAKEY
								--AND EE.CLAIMID = EM.CLAIMID 

								--Update Invalid HPLAN to '00000'
								
								update EXT_EDPS_CLAIM_STATUS
								SET HPLAN = '00000'
								WHERE HPLAN IS NULL 
								 OR LEN(HPLAN) = 0
								 OR SUBSTRING(HPLAN,1,1) ='-'
										 
							SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EXT_EDPS_CLAIM_STATUS)
													
						----EXSP_HRP_CLAIM_RECON UPDATE RUN CONTROLS
								BEGIN TRANSACTION
										UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = @ENTRYDT
										WHERE PROC_NAME = 'EXSP_CLAIM_UPD_INVENTORY'
													AND END_DT IS NULL
											IF @@ERROR <> 0
														BEGIN 
																ROLLBACK 
														END
										COMMIT
						
			

	
