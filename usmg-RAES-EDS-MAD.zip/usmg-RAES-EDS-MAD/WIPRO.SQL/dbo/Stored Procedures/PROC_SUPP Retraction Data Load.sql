﻿





CREATE PROCEDURE [dbo].[PROC_SUPP Retraction Data Load]
AS
/***************************************************************************************************
** CREATE DATE: 06/2012
**
** AURTHOR:Henry Faust
**
** DESCRIPTION:  Load Retraction Files 
**               
**                 
**               
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
20202-08-25		Henry Faust Creating Procedure for TETMD-2304
2021-03-11		ASU	TETDM-2611 Update to add data_source population per file

*****************************************************************************************************/			
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('xxPROC_SUPP Retraction Data Load'
				,'1'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
				
----------------------
--move data from staging table to regu;ar table
----------------------

	

			INSERT INTO [dbo].[SUPP_RETRACTION_INPUT] ([MEM_ID]
			, [medicare_no]
			, [HPLAN]
			, [prov_type]
			, [Dos_dt]
			, [dos_thru_dt]
			, [retraction_flag]
			, [diagnosis_code]
			, [CLM_NO]
			, [CLMSOURCE]
			, [icdversion]
			, [filename]
			, [PROVIDERNPI]
			, [Load_date]
			, [Data_Source])
				SELECT
					SUBSTRING([MEM_ID], 1, 50) AS [MEM_ID]
				   ,SUBSTRING([medicare_no], 1, 50) AS [medicare_no]
				   ,SUBSTRING([HPLAN], 1, 5) AS HPLAN
				   ,SUBSTRING([prov_type], 1, 2) AS [prov_type]
				   ,SUBSTRING(REPLACE([Dos_dt], '-', ''), 1, 8) AS [Dos_dt]
				   ,SUBSTRING(REPLACE([dos_thru_dt], '-', ''), 1, 8) AS [dos_thru_dt]

				   ,SUBSTRING([retraction_flag], 1, 1) AS [retraction_flag]
				   ,SUBSTRING([diagnosis_code], 1, 10) AS [diagnosis_code]
				   ,SUBSTRING([CLM_NO], 1, 50) AS [CLM_NO]
				   ,SUBSTRING([CLMSOURCE], 1, 50) AS [CLMSOURCE]
				   ,SUBSTRING([icdversion], 1, 5) AS [icdversion]
				   ,SUBSTRING([filename], 1, 150) AS [filename]
				   ,SUBSTRING([PROVIDERNPI], 1, 10) AS [PROVIDERNPI]
				   ,REPLACE(GETDATE(), '-', '')
				   ,CASE --TETDM-2611
                    	WHEN [filename] LIKE 'CHSRAPR.IRAT[_]IRR%' THEN 'IRR_IRAT'
                    	WHEN [filename] LIKE 'CHSRAPR.OSCR[_]IRR%' THEN 'OSCR_IRR'
						WHEN [filename] LIKE 'CHSRAPR.SOS[_]RETRACT%' THEN 'SOS_RETRACT'
						WHEN [filename] LIKE 'CHSRAPR.SOS[_]COMPLIANCE%' THEN 'SOS_COMPLIANCE'
						WHEN [filename] LIKE 'CHSRAPR.LEON%' THEN 'LEON'
						WHEN [filename] LIKE 'CHSRAPR.WELLMED%' THEN 'WELLMED'
						WHEN [filename] LIKE 'CHSRAPR.ARRO%' OR
							 [filename] LIKE 'CHSRAPR.COG%' OR
							 [filename] LIKE 'CHSRAPR.CAV%' OR
							 [filename] LIKE 'CHSRAPR.XXX%' THEN 'VENDOR_FILE'
						WHEN [filename] LIKE 'CHSRAPR.ERR[_]%' THEN 'Submission_Team'
						WHEN [filename] LIKE 'CHSRAPR.RAPS%'THEN 'DataScience'
                    	ELSE 'Other'
                    END AS [Data_Source]
				FROM staging.SUPP_RETRACTION_INPUT

			 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM staging.SUPP_RETRACTION_INPUT)
									
		----HRP_CLAIM_FILE Update Run Controls
			
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'xxPROC_SUPP Retraction Data Load'
							AND END_DT IS NULL
							
					
						
						








