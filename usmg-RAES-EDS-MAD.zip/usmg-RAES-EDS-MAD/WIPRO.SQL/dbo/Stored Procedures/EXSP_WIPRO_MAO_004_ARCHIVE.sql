﻿
CREATE PROCEDURE [dbo].[EXSP_WIPRO_MAO_004_ARCHIVE]
AS /*	************************************************************************************************
Scott Waller February 2016

I have cloned this from the MAO002 version.  I am leaving all comments here from the MAO002 version
too.

***************************************************************************************************/

/***************************************************************************************************
** CREATE DATE: 03/2014
**
** AUTHOR: LOYAL RICKS - Loyal Ricks
**
** DESCRIPTION: Procedure will archive inbound mao004 data from "mao004 Daily Tables" to 
**				apropriate "mao004 Non Daily" tables. 
**				Archive process designed to execute before daily execution of mao004 job.
**				Archiving daily before process will allow business group access to daily
**				update data for auditing and validation.
**				Daily mao004 tables will be truncated after archiving.
**				
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
03/27/2015		Loyal Ricks			WIPRO mao004 - TETDM-53 - Revised procedure append to EXT_SYS_RUNLOG
									replacing Verisk label with WIPRO label.
04/08/2015		Loyal Ricks			TETDM-73 mao-004 Version 1.1.0 Updates -mao_004_DETAIL/mao_004_DETAIL_DAILY

01/03/2017		Patricia Greenlea	TETDM-1390 Change to intake file formats
*****************************************************************************************************/	
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
    DECLARE @TOTAL_RECORDS INT
		

--HRP_CLAIM_FILE Run controls
			
    INSERT  INTO EXT_SYS_RUNLOG
            ( PROC_NAME ,
              STEP ,
              START_DT ,
              END_DT ,
              RUN_MINUTES ,
              TOTAL_RECORDS ,
              ENTRYDT
							
            )
    VALUES  ( 'EXSP_WIPRO_MA0_004_ARCHIVE' ,
              '1' ,
              GETDATE() ,
              NULL ,
              NULL ,
              0 ,
              GETDATE()
            )
					
						--Archive mao_004_HEADER
    INSERT  INTO [dbo].[mao_004_Header]
	( HeaderID ,
        InboundFileName ,
        RecordType ,
        ReportID ,
        MedicareAdvContractID ,
        ReportDate ,
        ReportDescription ,
        SubmissionFileType)
            SELECT    HeaderID ,
        InboundFileName ,
        RecordType ,
        ReportID ,
        MedicareAdvContractID ,
        ReportDate ,
        ReportDescription ,
        SubmissionFileType
            FROM    mao_004_Header_Daily
			
						---Archive mao_004_DAILY
    INSERT  INTO dbo.mao_004_Detail
            
            SELECT   DetailID ,
        InboundFileName ,
        RecordType ,
        ReportID ,
        MedicareAdvContractID ,
        BeneficiaryHICN ,
        EncounterICN ,
        EncounterTypeSW ,
        OriginalEncounterICN ,
        PlanSubmissionDate ,
        ProcessingDate ,
        FromDateofService ,
        ThroughDateofService ,
        ClaimType ,
        DiagnosisCode ,
        DiagnosisICD ,
        AddorDeleteFlag ,
        DiagnosisCode01 ,
        DiagnosisCode02 ,
        DiagnosisCode03 ,
        DiagnosisCode04 ,
        DiagnosisCode05 ,
        DiagnosisCode06 ,
        DiagnosisCode07 ,
        DiagnosisCode08 ,
        DiagnosisCode09 ,
        DiagnosisCode10 ,
        DiagnosisCode11 ,
        DiagnosisCode12 ,
        DiagnosisCode13 ,
        DiagnosisCode14 ,
        DiagnosisCode15 ,
        DiagnosisCode16 ,
        DiagnosisCode17 ,
        DiagnosisCode18 ,
        DiagnosisCode19 ,
        DiagnosisCode20 ,
        DiagnosisCode21 ,
        DiagnosisCode22 ,
        DiagnosisCode23 ,
        DiagnosisCode24 ,
        DiagnosisCode25 ,
        DiagnosisCode26 ,
        DiagnosisCode27 ,
        DiagnosisCode28 ,
        DiagnosisCode29 ,
        DiagnosisCode30 ,
        DiagnosisCode31 ,
        DiagnosisCode32 ,
        DiagnosisCode33 ,
        DiagnosisCode34 ,
        DiagnosisCode35 ,
        DiagnosisCode36 ,
        ClaimID ,
        WIPRO_ClaimID
            FROM    mao_004_Detail_Daily      
						
						--Archive mao_004 Trailer
    INSERT  INTO [dbo].[mao_004_Trailer]
            SELECT   TrailerID ,
        InboundFileName ,
        RecordType ,
        ReportID ,
        MedicareAdvContractID ,
        TotalRecords
            FROM    mao_004_Trailer_Daily      
							 
						--ASSIGN @TOTAL_RECORDS - GET RECORD COUNTS For table being archived
    SET @TOTAL_RECORDS = ( SELECT   COUNT(*)
                           FROM     mao_004_Header_Daily
                         )
    SET @TOTAL_RECORDS = @TOTAL_RECORDS + ( SELECT  COUNT(*)
                                            FROM    mao_004_Detail_DAILY
                                          )
    SET @TOTAL_RECORDS = @TOTAL_RECORDS + ( SELECT  COUNT(*)
                                            FROM    mao_004_Trailer_DAILY
                                          )
								
						--Truncate Daily tables
    DELETE  FROM mao_004_Header_Daily
    DELETE  FROM mao_004_Detail_DAILY
    DELETE  FROM mao_004_Trailer_DAILY
														
						----HRP_CLAIM_FILE Update Run Controls
    UPDATE  EXT_SYS_RUNLOG
    SET     END_DT = GETDATE() ,
            RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
            TOTAL_RECORDS = @TOTAL_RECORDS ,
            ENTRYDT = GETDATE()
    WHERE   PROC_NAME = 'EXSP_WIPRO_MA0_004_ARCHIVE'
            AND END_DT IS NULL


