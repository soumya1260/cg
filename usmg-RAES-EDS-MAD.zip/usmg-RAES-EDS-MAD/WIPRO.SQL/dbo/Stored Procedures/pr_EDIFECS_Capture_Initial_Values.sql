﻿
CREATE  PROCEDURE dbo.pr_EDIFECS_Capture_Initial_Values

/**********************************************************************************************
PROCEDURE:	dbo.pr_EDIFECS_Capture_Initial_Values
PURPOSE:	Capture the initial file values we receive from EDIFECS
			
NOTES:		

CREATED:	2021-12-22  Scott Waller for EDIFECS
REVISIONS:

Date		Author			Description
------------------------------------------------------------------------------------------------

*************************************************************************************************/

AS

BEGIN

	SET NOCOUNT ON;

	DECLARE		@hold_current_date	datetime = GETDATE()

	INSERT INTO [dbo].[EDIFECS_UPDATES_TO_OUTB_FILE_HIST_INITIAL_VALUES]
			   ([FILEID]
			   ,[SOURCEDATAKEY]
			   ,[STAT_FILE_DATE]
			   ,[CLAIMS_RECEIVED]
			   ,[CLAIMS_REJECTED]
			   ,[CLAIMS_ACCEPTED]
			   ,[CLAIMS_FILL_GAP]
			   ,[FILE_DISPOSITION]
			   ,[ACTIVITY_STATE]
			   ,[FILEFORMATVALSTAT]
			   ,[PROCESS_DATE]
			   ,[INITAL_VALUE_DATE])
	SELECT	   [FILEID]
			   ,[SOURCEDATAKEY]
			   ,[STAT_FILE_DATE]
			   ,[CLAIMS_RECEIVED]
			   ,[CLAIMS_REJECTED]
			   ,[CLAIMS_ACCEPTED]
			   ,[CLAIMS_FILL_GAP]
			   ,[FILE_DISPOSITION]
			   ,[ACTIVITY_STATE]
			   ,[FILEFORMATVALSTAT]
			   ,[PROCESS_DATE]
			   ,@hold_current_date AS INITIAL_VALUE_DATE
	FROM	EDIFECS_UPDATES_TO_OUTB_FILE_HIST
	WHERE	FILEID NOT IN (	SELECT	FILEID 
							FROM	WIPRO.dbo.EDIFECS_UPDATES_TO_OUTB_FILE_HIST_INITIAL_VALUES)	

END