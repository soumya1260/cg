﻿    
  
  
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_MAO_PROF_CLAIM_HEADER_ADJUSTMENTS]  
(  
	@ExecutionMode		CHAR(1) = 'M',  
	@sourcedatakey		INT,  
	@JOBID 		INT = 1 ,
	@LOB VARCHAR(15) = ' '
	--  
	--	NOTE:	Pass in 'A' for new "automated" execution  
	--			Default is [M]anual mode...  
	--  
)  
  
AS  
/***************************************************************************************************  
** CREATE DATE: 01/2012  
**  
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM  
**  
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM INFORMATION   
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE    
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES.   
**  
**  
Modification History  
====================  
Date			Who				Description  
-----------------------------------------------------------------------------------------------------  
2012-10-19		Dwight Staggs	Remove database name from table references  
2012-10-24		Loyal Ricks		Add Exclusion table logic (build and selection into OUTB_PROF_HEADER)  
2012-10-24		Loyal Ricks		replace ##TMP_ with ##TMPDEV_ in order to support use of tempdb  
2012-10-24		Loyal Ricks		between EDPS and EDPS_PROD databases.  
2012-10-24		Loyal Ricks	    remove update, mapping rules change do not include CMS_CONTRACT_NUM  
2013-02-08		Loyal Ricks		INVALID CHARACTER MEMBER RECORD PARSE  
2013-03-06		Loyal Ricks		Remove DOS claim selection criteria  
								Remove input parms  
2013-04-25		Loyal Ricks		Add parsing logic for member address to, set '***' to ' '        
2013-04-30		Loyal Ricks		Remap default code for OTH_INSR_TYPECD1 to CLM_FIL_INDCD1   
								Due to CMS 999 rejection issue.   
2013-05-09		Loyal Ricks		Add Rendering Provider   
								Reject 103 adjustment - Remove cd.MemberPaidAmt from claim header.   
								When populated this data element is causing balance issues between  
								claim header and claim line.  
								scrub cd.pcpid when 'UNKNOWN' SET TO ' '	  
2013-07-24		Dwight Staggs	Use new dbo.EDS_ClaimExtractParams and dbo.EDS_AllExtractClaims tables  
								in SSIS package to pull all available claims for each source  
2013-09-18		Dwight Staggs	Added @ExecutionMode input parameter for backward compatibility.  The  
								default of 'M' executes the same as previously:  
									1.	#tmplob table is created  
									2.	The claims inserted into #ELIG_CLM are pulled directly from  
										EDPS_Data.dbo.ClaimDim, JOINed to #tmplob  
									3.	# of claims extracted is hard-codeded in this SP  
								When set to 'A':  
									1.	The claims inserted into #ELIG_CLM are pulled from dbo.EDS_AllExtractClaims,  
										which is populated in the SSIS package before this SP is executed  
									2.	The number of claims to be extracted is obtained from the   
									    EDS_ClaimExtractParams table for the appropriate SourceDataKey  
2013-10-29		Dwight Staggs	For manual option, use ManualMaxClaimsPerFile in param table and eliminate   
								hardcoded value in this SP 	  
2013-10-31		Loyal Ricks		PAYER_CLAIM_CNTRL_NUM - Revise logic to set this value to blank instead of 1   
								when BIDW defaults are assigned. REquired to support new Verisk edit   
								check on this data element.     
2014-01-22		Loyal Ricks		Add additional data scrub for Member Middle Name & Member Zip4	  
2014-02-04		Loyal Ricks		Remove individual data element Invalid EDI parse and replace with function   
								dbo.fn_edi_parse.  
2014-02-07		Loyal Ricks		Remove MDQOLib references (Memberdim, Lineofbusinessdim)  
2014-02-11		Loyal Ricks		Additional invalid EDI character parsing - member first & last name		  
------------------------------------------------------------------------------------------------------  
2014-09-23		Loyal Ricks		WIPRO Code Migration from EDPS(Verisk) to WIPRO		  
2014-10-08		Loyal Ricks		WIPRO MAO QNXT & MHC WIPRO claim header build	  
2014-10-10		Loyal Ricks		WIPRO MAO BIDW Refersh test casess @JOBID - 500 series		  
2014-10-29		Loyal Ricks		Remove use of @SOURCEDESC as source system value in claim header.  
								 Use @sourcedatakey instead of sourcedesc.  
								Decission made during 10/29 WIPRO Unique Id call. The sourcedatakey   
								will be used in conjunction with other values cancatenated by WIPRO  
								on all clmstat files (WIPRO ICN number).		  
2014-12-01		Loyal Ricks		Add logic for default assignment of PRINCIPAL_DIAG_QUAL = 'BK'	  
2015-02-09		Loyal Ricks		EDS-706 - Facets professional Claim integration - evaluate @sourcedatakey in   
								order to determine appropriate selection criteria for each sdk. QNXT and  
								MHC use same code blocks, Facets uses indepeendent code block. 	  
2015-05-07		Loyal Ricks		Add Paper claim logic for non QNXT claims	  
2015-05-28		Loyal Ricks		Remove parameter limiting sdk (2,50) for test bed submissions to allow for all sources   
								to have the option to use test bed.		  
2015-08-01		Loyal Ricks		Add claimdim.formtypecode evaluation for Facets claim due to BIDW CR change which   
								added the Facets claim type to BIDW.   
								Remove Facets specific claim retrieval logic and combined logic with all other sdk	  
2015-10-28		Loyal Ricks		TETDM-438 ICD-10 Qualifier Revisions  
2015-10-30		Loyal Ricks		TETDM-448 Add @ExtractCount=EDS_ClaimExtractParams.Claim_Type ='P'		  
2016-04-02		Loyal Ricks		TETDM-667 Add Ambulance Pickup and Dropoff fields	  
2016-04-08		Loyal Ricks		TETDM-737 Remove Pay To Vendor Flag		  
2016-08-15		Loyal Ricks		Add Outbound claims per file for DME claims			  
2016-09-22		Loyal Ricks		Remove Jobid 3 Denied claim logic. Denied claims to get submitted with Jobid 1 for prod release	  
2016-09-26		Loyal Ricks		Added back Jobid 3 Denied claim logic. additional volume testing required.		  
2016-10-05		Loyal Ricks		Revise DME logic, remove deniedflag logic to enable submission of denied and non denied	
2020-02-24      Aaron Ridley    TETDM-2359 Added logic to accommodate adjustment submissions 
                                    1) Included jobs 3001 for Inst adjustments 
									2) Included job 3061 for Inst Adjustment as Originals 
									3) Introduced LOBCODE as parameter 		      
**********************************************************************************************************************/			  
  
	SET NOCOUNT ON;  
	  
	DECLARE @CatchErrorMessage VARCHAR(2200);  
	DECLARE	@TOTAL_RECORDS INT,  
			@ExtractCount INT,  
			@SOURCEDESC		CHAR(350), 
			@PRODUCTTYPE VARCHAR(15); 
  
			  
			BEGIN   
			SET @SOURCEDESC = (select rtrim(sourcedesc) from WIPRO.DBO.sourcedatadim where sourcedatakey = @sourcedatakey);  
			end  
  
	IF OBJECT_ID('TEMPDB..#ELIG_CLM') <> 0  
		DROP TABLE #ELIG_CLM  
	  
	CREATE TABLE #ELIG_CLM  
	(  
		ClaimID		VARCHAR(20),
		NewFrequencyCode VARCHAR(2),
		OrigClaimno VARCHAR (15),
		Claim_Type VARCHAR(1)  
	)  
	  
	IF OBJECT_ID('TEMPDB..#TMPDEV_HPLAN') <> 0  
		DROP TABLE #TMPDEV_HPLAN  
  
	CREATE TABLE #TMPDEV_HPLAN  
	(  
		ClaimId			VARCHAR(20),  
		LOBCode			VARCHAR(15),  
		HCFACode		VARCHAR(5)  
	)  
  
	IF OBJECT_ID('TEMPDB..#tmplob') <> 0  
		DROP TABLE #tmplob  
  
	CREATE TABLE #tmplob  
	(  
		LOBCode			VARCHAR(15)  
	)  
BEGIN TRY  
  
--	Init Run controls  
	INSERT INTO EXT_SYS_RUNLOG  
			(PROC_NAME  
			,STEP  
			,START_DT  
			,END_DT  
			,RUN_MINUTES  
			,TOTAL_RECORDS  
			,ENTRYDT  
			)  
			VALUES('pr_BUILD_OUTB_MAO_PROF_CLAIM_HEADER_ADJUSTMENTS' + '' + rtrim(@SOURCEDESC)  
					,'2'  
					,GETDATE()  
					,NULL  
					,NULL  
					,0  
					,GETDATE()  
					)  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH  
				  
BEGIN TRY  
	IF @LOB = 'MAO' 
		BEGIN SET @PRODUCTTYPE = 'MEDICARE'
	END  
	IF @LOB = 'MMAI' 
		BEGIN SET @PRODUCTTYPE = 'CARE-CAID'
	END  
	IF @LOB = 'CAID' 
		BEGIN SET @PRODUCTTYPE = 'MEDICAID'
	END  
  
	SELECT  
			@ExtractCount = ManualMaxClaimsPerFile  
		FROM  
			dbo.EDS_ClaimExtractParams	  
		WHERE  
			SourceDataKey = @sourcedatakey  
			AND CLAIM_TYPE ='P'  
			  
		INSERT INTO   
			#tmplob  
		(   
			LOBCode  
		)  
		SELECT  
			LOBCode  
		FROM  
			MDQOLib.dbo.LineofBusinessDim  
		WHERE	  
			ProductType = @PRODUCTTYPE   
		AND Active = 1  
		ORDER BY LOBCode  
  


    
	----  
	----	EDS Denied Claim Submissions  
	----  
	
  
	IF @JOBID in (3001,3061)  --JOBID Series 3000 for adjustments
	BEGIN  

		  
		INSERT INTO  
			#ELIG_CLM  
		(   
			ClaimID
			,newfrequencycode 
			,origclaimno
			,claim_type
			 
		)  
  
		SELECT  
			--TOP 100000 ClaimID		--	<--  Change value here for Manual mode...  
			TOP(@ExtractCount) ClaimID
			,tb.newfrequencycode
			,tb.origclaimno 
			,tb.claim_type  
		FROM   
			OUTB_WIPRO_TEST_BED_ADJUSTMENTS TB  

		WHERE  
			TB.SOURCEDATAKEY = @SourceDataKey  
			AND TESTID = @JOBID  
			AND @LOB = TB.TYPECODE
			AND TB.CLAIM_TYPE = 'P'  

  
	END  

		IF @JOBID in (3006, 3066)  --JOBID Series 3000 for adjustments
	BEGIN  

		  
		INSERT INTO  
			#ELIG_CLM  
		(   
			ClaimID
			,newfrequencycode 
			,origclaimno
			,claim_type
			 
		)  
  
		SELECT  
			--TOP 100000 ClaimID		--	<--  Change value here for Manual mode...  
			TOP(@ExtractCount) ClaimID
			,tb.newfrequencycode
			,tb.origclaimno   
			,tb.claim_type 
		FROM   
			OUTB_WIPRO_TEST_BED_ADJUSTMENTS TB  

		WHERE  
			TB.SOURCEDATAKEY = @SourceDataKey  
			AND TESTID = @JOBID  
			AND @LOB = TB.TYPECODE
			AND TB.CLAIM_TYPE = 'E'  
  
	END  
 
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH  
  
  
BEGIN TRY  
	--  
	--	Build Claim Headers   
	--  
  
	TRUNCATE TABLE OUTB_PROF_HEADER  
	TRUNCATE TABLE OUTB_PROF_DETAIL  
  
  
	--BEGIN TRANSACTION   
	INSERT INTO   
		OUTB_PROF_HEADER  
	SELECT  DISTINCT  
		'C' 
		,e.claim_type 
		--,case cd.formtypecode when 'H' then 'P'  
		--	when 'U' then 'I'  
		--	else cd.formtypecode  
		--end  
		,rtrim(convert(char, @sourcedatakey))  
		,' '--cd.sourcedatakey--CMS_CONTRACT_NUM  
		,mb.MEDICAREID  
		,cd.claimid  
		,substring(cd.PatientID,1,20)  
		,REPLACE(cd.MemberID,'*','-')  
		,dbo.fn_edi_parse(mb.lastname)  
		,dbo.fn_edi_parse(mb.firstname)  
		,CASE dbo.fn_edi_parse(mb.middlename)   
			WHEN 'UNKNOWN' THEN ' '  
			ELSE dbo.fn_edi_parse(mb.middlename)  
		 END  
		,' '--MEMBER_SFX  
		,dbo.fn_edi_parse(substring(mb.AddressLine1,1,55))  
		,CASE dbo.fn_edi_parse(substring(mb.AddressLine2,1,55))  
			WHEN 'UNKNOWN' THEN ' '  
			when '***' then ' '                                                      
			ELSE dbo.fn_edi_parse(substring(mb.AddressLine2,1,55))  
		 END  
		,mb.City  
		,mb.State  
		,CASE substring(mb.Zip,1,5) WHEN 'UNKNO' THEN '99999' ELSE SUBSTRING(mb.Zip,1,5) END  
		,substring(mb.Zip,6,4)   
		,' '--MEMBER_CTY  
		,' '--MEMBER_CTRY  
		,' '--MEMBER_CTRY_SUBD  
		,REPLACE(cd.GroupID,'*','-')  
		,case cd.formtypecode   
			when 'H' then '14'  
			else ' '  
		end  
		,mb.DOBDateKey  
		,mb.Gender  
		,CASE mb.SSN WHEN 'UNKNOWN' THEN ' ' ELSE mb.SSN END  
		,' '--POS  
		,' '--INST_PRINCIPAL_DIAG_CD  
		,' '--INST_PRINCIPAL_POA_CD  
		,' '--INST_ADM_DIGA_CD  
		,' '--DIAG_CD1  
		,' '--POA_IND1  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '--DIAG_CD20  
		,' '--POA_IND20  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '--DIAG_CD30  
		,' '--POA_IND30  
		,' '--BILL_PROV_NPI  
		,cd.PCPVendor  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '--BILL_PROV_LICENSE_NO  
		,cd.PCPVendor  
		,' '--TETDM-737,case cd.PayToVendorOrFamilyFlag   
		--	when 'V' then '1'  
		--	else ' '  
		--end  
		,' '--PAYTO_ADDR1  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,'P'--PAYER_RESP  
		,ltrim(cd.ClaimBilledAmt)  
		,' '--ltrim(cd.MemberPaidAmt)  
		,' '  
		,newfrequencycode -- A. Ridley -- Pull from Adjustment table CASE cd.PreviousClaimID WHEN 'N/A' THEN '1'  when 'UNKNOWN' THEN '1' ELSE '7' END  
		,'C'--PROV_ASSGN_IND  
		,'Y'--INSR_BEN_ASSGN_IND  
		,' '  
		,' '  
		,' '  
		,case cd.admissiondatekey when '-1' then ' ' when '0' then ' ' else cd.AdmissionDateKey end  
		,' '  
		,' '  
		,' '  
		,case cd.dischargedatekey when '-1' then ' '  when '0' then ' ' else cd.DischargeDateKey end  
		,' '  
		,CASE cd.DispositionCode WHEN 'N/A' THEN ' ' WHEN '--' THEN ' ' ELSE cd.DispositionCode END  
		,CASE replace(cd.AuthorizationID,'*','-') WHEN 'UNKNOWN' THEN ' ' ELSE replace(cd.AuthorizationID,'*','-')  END  
		,' '--CPO_NPI  
		,' '--PRICE_METHOD  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '--REF_PROV_UPIN  
		,CASE cd.ReferringPhysicianID WHEN 'UNKNOWN' THEN ' ' ELSE cd.ReferringPhysicianID END  
		,' '--REF_PCP_LNAME  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '--REF_PCP_PROV_UPIN  
		,case cd.PCPID WHEN 'UNKNOWN' THEN ' ' ELSE cd.PCPID end  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '--ATTN_PROV_LOC_NO  
		,CASE cd.AttendingPhysicianID WHEN 'UNKNOWN' THEN ' ' ELSE cd.AttendingPhysicianID END  
		,' '--ATTN_PROV_LICENSE_NO  
		,' '--EMER_FLAG  
		,' '--PROD_DESC  
		,' '--ANES_FLAG  
		,'P'--PAYER_RESP1 default values for CMS COB  
		,'18'--REL_CD1 default values for CMS COB  
		,' '--OTH_INSR_GRPNO1 CHAR(50),  
		,'HealthSpring'--OTH_INSR_GRPNAME CHAR(60),  
		,' '--OTH_INSR_TYPECD1 CHAR(10),  
		,'16'--CLM_FIL_INDCD1 CHAR(10),  
		,' '--CLM_ADJ_GRP_TYPE1 CHAR(2),  
		,' '--CLM_ADJ_REA_CD1 CHAR(5),  
		,' '--SUM(CD.CLAIMBILLEDAMT - cd.TotalPaid)--CLM_ADJ_AMT1 CHAR(18),  
		,' '--CLM_ADJ_UNIT1 CHAR(18)  
		,ltrim(cd.TotalPaid)  
		,' '--cd.MHCFinancialDateKey--USE CLAIMAGG PAYDATEKEY WHICH IS   
		,' '--ltrim(cd.MemberPaidAmt)  
		,' '  
		,'HealthSpring'--OTHER PAYER 1 NAME  
		,' '---OTHER PAYER1 PLAN ID  
		,'530 GREAT CIRCLE' --OTHER PAYER1 ADDRESS  
		,' '  --OTHER PAYER1 ADDRESS2  
		,'NASHVILLE'--OTHER PAYER1 CITY  
		,'TN' --OTHER PAYER1 STATE  
		,'37228'--OTH PAYER1 ZIP  
		,'9999' -- OTHER PAYER1 ZIP4  
		,' '--cd.MHCFinancialDateKey  
		,cd.sourcedatakey  
		,'Y'--PROV_SIGNATURE_FLAG  
		,'Y'--REL_OF_INFO_FLAG  
		,'Y'--ASSIGN_BEN_IND1  
		,origclaimno -- A. Ridley pull from Adjustment table CASE cd.PreviousClaimID WHEN 'N/A' THEN ' ' when 'UNKNOWN' THEN ' ' ELSE cd.PreviousClaimID END  
		,' '--OPTIONAL REPORTING INDICATOR  
		,' '--rendoring provider   
		,' '  
		,' '  
		,' '  
		,' '  
		,' '  
		,' '--rendering prov taxonomy  
		,' '--rendering provider org name  
		,' '--rendering provider group id  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '--TETDM-667 - Ambulance Pickup Addr1  
			,' '  
			,' '  
			,' '  
			,' '  
			,' '--Ambulance dropoff addr1  
			,' '  
			,' '  
			,' '  
			,' '  
	from   #ELIG_CLM e 
	JOIN EDPS_Data.dbo.claimdim	cd  on e.claimid = cd.claimid 
	JOIN MDQOLib.dbo.MemberDim	mb  
		ON cd.SOURCEDATAKEY = mb.SourceDataKey  
		AND cd.MEMBERID = mb.MemberID  
	WHERE  
		cd.SOURCEDATAKEY = @sourcedatakey  
  
	--COMMIT TRANSACTION  
  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH  
  
BEGIN TRY  
	--UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO  
	INSERT INTO   
		#TMPDEV_HPLAN  
	(  
		ClaimId,   
		LOBCode,   
		HCFACode  
	)  
	 SELECT   
		CD.CLAIMID,  
		CD.LOBCODE,  
		L.HCFACODE  
	 FROM   
		OUTB_PROF_HEADER					C  
	INNER JOIN  
		EDPS_Data.dbo.CLAIMDIM					CD  
		ON C.SOURCEDATAKEY = CD.SOURCEDATAKEY  
		AND C.CLAIM_ID = CD.CLAIMID  
	INNER JOIN  
		MDQOLib.dbo.LineofBusinessDim	L  
		ON CD.SOURCEDATAKEY = L.SourceDataKey  
		AND	CD.LOBCODE = L.LOBCode  
  
  
	--BEGIN TRANSACTION   
		UPDATE   
			OUTB_PROF_HEADER  
		SET   
			 CMS_CONTRACT_NUM = T.HCFACode  
			,OTH_PAYER1_PLANID = T.HCFACode  
		FROM   
			OUTB_PROF_HEADER C  
		INNER JOIN  
			#TMPDEV_HPLAN T	  
			ON C.CLAIM_ID = T.CLAIMID  
		  
	--COMMIT TRANSACTION  
	  
		  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
  
BEGIN TRY	  
	--  
	--	Update PAYER1_PAID_DT from ClaimAgg  
	--  
	--BEGIN TRANSACTION  
		UPDATE   
			OUTB_PROF_HEADER  
		SET   
			PAYER1_PAID_DT = CA.PaidDateKey  
		FROM   
			OUTB_PROF_HEADER			HC  
		INNER JOIN  
			EDPS_Data.dbo.CLAIMAGG			CA  
		ON   
			HC.SOURCEDATAKEY = CA.SOURCEDATAKEY  
			AND HC.CLAIM_ID = CA.CLAIMID  
  
		--COMMIT TRANSACTION  
		  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
BEGIN TRY  
	--  
	--	Update ADM_DT and DISCHRG_DT to '' when 0...  
	--  
   
		UPDATE OUTB_PROF_HEADER  
		SET ADM_DT = ''  
		WHERE ADM_DT = '0'  
  
  
		UPDATE OUTB_PROF_HEADER  
		SET DISCHRG_DT = ''  
		WHERE DISCHRG_DT = '0'  
  
		UPDATE OUTB_PROF_HEADER   
		SET CLAIM_TYPE = 'P'  
		WHERE SOURCEDATAKEY = 30  
  
  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
BEGIN TRY  
	--UPDATE PROFESSIONAL CLAIM PLACE OF SERVICE  
	--BEGIN TRANSACTION  
		UPDATE   
			OUTB_PROF_HEADER  
		SET   
			POS = cd.ServicePlaceCode  
		FROM   
			OUTB_PROF_HEADER			E  
		INNER JOIN  
			EDPS_Data.dbo.CLAIMDETAILDIM		CD  
			ON E.SOURCEDATAKEY = CD.SOURCEDATAKEY  
			AND E.CLAIM_ID = CD.CLAIMID  
		WHERE  
			E.CLAIM_TYPE in ('P','E')  
					  
	--COMMIT TRANSACTION  
  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
  
BEGIN TRY  
	--UPDATE INSTITUTIONAL CLAIM PLACE OF SERVICE  
	--BEGIN TRANSACTION  
		UPDATE   
			OUTB_PROF_HEADER  
		SET   
			POS = UA.billtypecode  
		FROM   
			OUTB_PROF_HEADER			E  
		INNER JOIN  
			EDPS_Data.dbo.UB921ADMISSIONDIM	UA  
			ON E.SOURCEDATAKEY = UA.SourceDataKey  
			AND E.CLAIM_ID = UA.claimid  
		WHERE  
			E.CLAIM_TYPE = 'I'	  
  
	--COMMIT TRANSACTION  
  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
  
BEGIN TRY  
	--UPDATE INST_PRINCIPAL_DIAG_CD  
	--BEGIN TRANSACTION  
		UPDATE   
			OUTB_PROF_HEADER  
		SET   
			INST_PRINCIPAL_DIAG_CD = replace(CDD.DIAGNOSISCODE,'.',''),  
			INST_PRINCIPAL_POA_CD = CASE CDD.POAind WHEN 'Y' THEN 'Y' ELSE 'N' END,  
			PRINCIPAL_DIAG_QUAL = 'BK'  
		FROM   
			OUTB_PROF_HEADER				E  
		INNER JOIN	  
			EDPS_Data.dbo.CLAIMDIAGNOSISDIM		CDD  
			ON E.SOURCEDATAKEY = CDD.SourceDataKey  
			AND E.CLAIM_ID = CDD.CLAIMID  
			AND CDD.DIAGNOSISTYPECODE = 'P'  
	  
	--COMMIT TRANSACTION  
	  
  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
BEGIN TRY  
		--UPDATE SERVICE DATE  
	--BEGIN TRANSACTION   
		UPDATE   
			OUTB_PROF_HEADER  
		SET   
			SERV_DT = BeginServiceDateKey  
		FROM   
			OUTB_PROF_HEADER					E  
		INNER JOIN  
			EDPS_Data.dbo.CLAIMDETAILDIM				CDD  
			ON E.SOURCEDATAKEY = CDD.SOURCEDATAKEY  
			AND E.CLAIM_ID = CDD.CLAIMID  
			AND CDD.CLAIMLINEID = '0001'  
  
	--COMMIT TRANSACTION  
  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH  
  
  
BEGIN TRY  
	--  
	--	Updates from UB921AdmissionDim  
	--  
	  
		--UPDATE ADM_TYPE_CD  
		--BEGIN TRANSACTION  
		UPDATE OUTB_PROF_HEADER  
		SET   
			ADM_TYPE_CD = replace(ub.DIAGNOSISCODE,'.',''),  
			ADM_SOURCE_CD = UB.admissioncode,  
			ADM_TIME = UB.admissionhour,  
			DISCHRG_TIME = case UB.dischargehour when 'N/A' then ' ' else UB.dischargehour end  
		FROM   
			OUTB_PROF_HEADER					E  
		INNER JOIN  
			EDPS_Data.dbo.UB921ADMISSIONDIM			UB  
			ON E.SOURCEDATAKEY = UB.SourceDataKey  
			AND E.CLAIM_ID = UB.claimid	  
			AND UB.admissiondiagnosistypecode = 'A'  
	  
	  
		  
  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH  
  
BEGIN TRY  
	--  
	--	Update "0" dates...  
	--  
	--begin transaction   
		UPDATE OUTB_PROF_HEADER  
		SET ADM_DT = ''  
		WHERE ADM_DT = '0'  
  
  
		UPDATE OUTB_PROF_HEADER  
		SET DISCHRG_DT = ''  
		WHERE DISCHRG_DT = '0'  
	--commit  
		  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
		  
BEGIN TRY		  
  
  
  
			UPDATE   
				OUTB_PROF_HEADER  
			SET   
				NONCOV_CHRG = ' '  
			WHERE   
				CONVERT(INT, NONCOV_CHRG)< 0  
  
		--COMMIT TRANSACTION  
		  
		  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
		  
BEGIN TRY  
	--  
	--	Update claim indicators...  
	--		  
		  
	--BEGIN TRANSACTION   
  
		--CLAIM INDICATOR - CLAIM REVERSAL LOGIC  
		--UPDATE CLAIM INDICATOR TO DELETE FOR R REVERSAL CLAIM   
		--UPDATE   
		--	OUTB_PROF_HEADER   
		--SET  CLM_IND = '8'  
		--	,PAYER_CLAIM_CNTRL_NUM = CA.PreviousClaimID  
		--FROM   
		--	OUTB_PROF_HEADER				C  
		--INNER JOIN  
		--	EDPS_Data.dbo.CLAIMAGG				CA  
		--	ON C.SOURCEDATAKEY = CA.SOURCEDATAKEY  
		--	AND C.CLAIM_ID = CA.CLAIMID  
		--	AND CHARINDEX('R',CA.ClaimID) > 0  
  
		  
		--UPDATE CLAIM INDICATOR TO REPLACE FOR REPLACEMENT CLAIM  
		----'A' (A1-A10)  
		--UPDATE   
		--	OUTB_PROF_HEADER  
		--SET  CLM_IND = '7'  
		--	,PAYER_CLAIM_CNTRL_NUM = CA.PreviousClaimID  
		--FROM  
		--	OUTB_PROF_HEADER				C  
		--INNER JOIN  
		--	EDPS_Data.dbo.CLAIMAGG				CA  
		--	ON C.SOURCEDATAKEY = CA.SOURCEDATAKEY   
		--	AND C.CLAIM_ID = CA.CLAIMID  
		--	AND CHARINDEX('A',CA.ClaimID) > 0  
		--	AND CA.CurrentStatusCode = 'P'  
		--	AND CA.PREVIOUSCLAIMID NOT IN ('N/A','UNKNOWN')  
		  
	  
		--PAPER CLAIM INDICATOR UPDATE for QNXT  
		UPDATE   
			OUTB_PROF_HEADER  
		SET   
			OPTIONAL_REPORTING_IND = 'PAPER'  
		WHERE SOURCEDATAKEY = 50   
				AND CHARINDEX('E',CLAIM_ID) = 0  
  
		--PAPER claim logic for Non QNXT claims  
		  UPDATE  OUTB_PROF_HEADER  
        SET     OPTIONAL_REPORTING_IND = 'PAPER'  
        FROM    EXT_HRP_CLAIM E  
                INNER JOIN EDPS_DATA.DBO.CLAIMSTATUSDIM CS ON E.SOURCEDATAKEY = CS.SOURCEDATAKEY  
                                                AND E.CLAIM_ID = CS.ClaimID  
        WHERE   AdjudicatorInitials = 'OCR'  
		and		E.sourcedatakey <> 50  
		  
		  
  
		  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
BEGIN TRY  
  
		--01/21/14 Additional Parsing  
		   
		UPDATE OUTB_PROF_HEADER  
		SET MEMBER_ZIP4 = '9998'  
		WHERE LEN(MEMBER_ZIP4) < 4  
  
		-- DME ClaimType Logic   
  
		if @jobid = 2   
			begin   
				update OUTB_PROF_HEADER  
				SET CLAIM_TYPE = 'E'  
			END  
	  

		  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
BEGIN TRY  
	--  
	--	Update Run Controls  
	--  
			  
	SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_HEADER)  
							  
	  
		UPDATE   
			EXT_SYS_RUNLOG  
		SET END_DT = GETDATE()	  
			,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
			,TOTAL_RECORDS = @TOTAL_RECORDS  
			,ENTRYDT = GETDATE()  
		WHERE   
			PROC_NAME = 'pr_BUILD_OUTB_MAO_PROF_CLAIM_HEADER_ADJUSTMENTS' + '' + rtrim(@SOURCEDESC)  
			AND END_DT IS NULL  
  
	  
						  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
BEGIN TRY  
	--  
	--	If executing in "A" mode, remove claims processed for next loop in SSIS package  
	--  
	IF @ExecutionMode = 'A'  
	BEGIN  
		DELETE  
			c   
		FROM  
			dbo.EDS_AllExtractClaims	c  
		INNER JOIN  
			#ELIG_CLM					e  
			ON c.ClaimID = e.ClaimID  
	END  
END TRY  
  
BEGIN CATCH  
	SELECT @CatchErrorMessage =   
		'Procedure: ' +   
		OBJECT_NAME(@@PROCID) +  
		' || ErrorNumber: ' +   
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +  
		' || ErrorMessage: ' +  
		ERROR_MESSAGE() +  
		' || ErrorLine: ' +  
		CAST(ERROR_LINE() AS VARCHAR(10));  
	IF @@TRANCOUNT > 0  
		ROLLBACK TRANSACTION;  
	RAISERROR(@CatchErrorMessage, 16, 1);  
END CATCH	  
  
  
	IF OBJECT_ID('TEMPDB..#ELIG_CLM') <> 0  
		DROP TABLE #ELIG_CLM  
  
	IF OBJECT_ID('TEMPDB..#TMPDEV_HPLAN') <> 0  
		DROP TABLE #TMPDEV_HPLAN  
		  
	IF OBJECT_ID('TEMPDB..#tmplob') <> 0  
		DROP TABLE #tmplob  
  
  
  
  
/******************************************************************************  
UNIT TEST:  
  
DECLARE @StartTime DATETIME  
SET @StartTime = GETDATE()  
  
BEGIN TRANSACTION  
  
	EXEC [dbo].[pr_EXSP_CLAIM_PROF_QNXT_CLMHEADER]  
		@ExecutionMode	 = 'M'	  
		  
ROLLBACK TRANSACTION  
  
SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped  
*************************************************************************************/  
  
  
  
  
