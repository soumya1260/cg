﻿CREATE PROCEDURE [dbo].[pr_Supp_Generate_Unlinked_v2]
/******************************************
Date			Author					Notes
09/06/2024		Subhash Acharya			Initital Creation


Select * FROM   [WIPRO].[dbo].[Supplemental_INPUT]

Select * FROM   [WIPRO].[dbo].[Supplemental_OUTPUT]

select *
FROM [WIPRO].[dbo].[Supplemental_INPUT]
WHERE STATUS_CODE IN ( '111' )
      AND Submission_Indicator = '0'


select * from [WIPRO].[dbo].[Service_Line_Dup_Processing] 

update [EDS_Adjustments_Ash].dbo.SVS_LINE_RELOAD
set date_of_service = convert(date,date_of_service)

select convert(date,date_of_service),* from [EDS_Adjustments_Ash].dbo.SVS_LINE_RELOAD
select * from [EDS_Adjustments_Ash].dbo.testbed_reload 

Sample Innvocation: EXEC [dbo].[PR_SUPP_GENERATE_LINKED_v2]
********************************************/

AS 
	SET NOCOUNT ON;

BEGIN 
--set rowcount 0
	;
    WITH cte
    AS (SELECT Hic_No,
               From_Date,
               Thru_Date,
               Source_System_Number,
               Dx_Code,
               STATUS_CODE,
               Status_desc,
               ROW_NUMBER() OVER (PARTITION BY Hic_No,
                                               From_Date,
                                               Thru_Date, /*, source_system_number*/
                                               Dx_Code
                                  ORDER BY Source_System_Number
                                 ) AS RwNum
        FROM [WIPRO].[dbo].[Supplemental_INPUT] A
        WHERE A.STATUS_CODE IN ( '111')
              AND A.Submission_Indicator = '0')
    UPDATE cte
    SET STATUS_CODE = '222',
        Status_desc = 'Data_Error_Sub_Diag_Dup'
    WHERE cte.RwNum > 1;

UPDATE /*top (10000)*/ [WIPRO].[dbo].[Supplemental_INPUT]
SET STATUS_CODE = '888',  --555
    Status_desc = 'UnLinked_SUB'
--SELECT * from [WIPRO].[dbo].[Supplemental_INPUT]
WHERE STATUS_CODE IN ( '111' )
      AND Submission_Indicator = '0'



	IF OBJECT_ID('tempdb.dbo.#Normalized_Supplemental_Input') IS NOT NULL
		DROP TABLE #Normalized_Supplemental_Input;

	IF OBJECT_ID('tempdb.dbo.#working_claims') IS NOT NULL
		DROP TABLE #working_claims;
			
	SELECT
		*
		INTO #working_claims
	FROM WIPRO.dbo.Supplemental_INPUT si
	WHERE 1 = 1
		AND si.STATUS_CODE IN ('888')
		AND si.Submission_Indicator = 0;

	ALTER TABLE #working_claims REBUILD PARTITION = ALL WITH (DATA_COMPRESSION = ROW);

	/*
	Running with the below two indexes (with options) runtime is about 00:05:41 for 980k records (condensed to 140k) over 5 runs
	Running without the below two indexes runtime is about 00:20:00 for 980k records (condensed to 140k) over 5 runs
	*/
	CREATE CLUSTERED INDEX idx_fromdate_thrudate_memberid_sourcesystemnumber_chartchasenpi_submissionindicator
	ON #working_claims (From_Date, Thru_Date, Member_ID ASC, Source_System_Number, Chart_Chase_NPI DESC, Submission_Indicator, STATUS_CODE)
	WITH (FILLFACTOR = 80, PAD_INDEX = ON)
	ON "default";

	CREATE NONCLUSTERED INDEX idx_fromdate_thrudate_memberid_sourcesystemnumber_chartchasenpi_dxcode_patientcontrolno
	ON #working_claims (From_Date, Thru_Date, Member_ID ASC, Source_System_Number, Chart_Chase_NPI, Dx_Code, Patient_Control_No, Submission_Indicator)
	INCLUDE (STATUS_CODE, Status_desc, Hic_No, Plan_No, Provider_Type)
	WITH (FILLFACTOR = 80, PAD_INDEX = ON)
	ON "default";

	/********************run *******************************/

	
		IF OBJECT_ID('tempdb.dbo.#providers') IS NOT NULL
		DROP TABLE #providers;
	
	WITH provider_filter AS (
		SELECT
			epd.ProviderID,
			epd.FIDN,
			epd.NPID
		FROM EDPS_Data.dbo.EDS_ProviderDim epd
		WHERE LEN(epd.FIDN) > 0
		GROUP BY
			epd.ProviderID,
			epd.FIDN,
			epd.NPID
	),monthly_member AS (
		SELECT
			pd.NPID,
			mmd.MemberID,
			pd.FIDN,
			pd.ProviderID,
			BeginCoverageDateKey = TRY_CAST(TRY_CAST(mmd.BeginCoverageDateKey AS VARCHAR) AS DATE),
			EndCoverageDateKey = TRY_CAST(TRY_CAST(mmd.EndCoverageDateKey AS VARCHAR) AS DATE)
		FROM EDPS_Data.dbo.MonthlyMembershipDim mmd
		JOIN provider_filter pd
			ON mmd.PCPID = pd.ProviderID
		WHERE 1 = 1		
			AND pd.NPID NOT IN ('UNKNOWN', '00000000', '999999999')
			AND EXISTS (SELECT 1 FROM #working_claims si WHERE mmd.MemberID = si.Member_ID)
		GROUP BY
			pd.NPID,
			mmd.MemberID,
			mmd.BeginCoverageDateKey,
			mmd.EndCoverageDateKey,
			pd.FIDN,
			pd.ProviderID)
	SELECT
		*
	INTO #providers
	FROM monthly_member;

	CREATE NONCLUSTERED INDEX idx_providers
	ON #providers (NPID, MemberID ASC, BeginCoverageDateKey, EndCoverageDateKey )
	INCLUDE (FIDN, ProviderID);


	/*
	Do checks to filter out input rows with bad data
	*/
	WITH supp_NPI AS (
		SELECT
			si.Source_System_Number,
			si.Member_ID,
			si.From_Date,
			si.Thru_Date,
			si.Chart_Chase_NPI
		FROM #working_claims si
		GROUP BY 
			si.Chart_Chase_NPI,
			si.Source_System_Number,
			si.Member_ID,
			si.From_Date,
			si.Thru_Date
	),BAD_Data AS (
		SELECT
			SN.Chart_Chase_NPI,
			SN.Source_System_Number,
			SN.MEMBER_ID,
			SN.From_Date,
			SN.Thru_Date,
			isChart_Chase_NPI_or_NPID_BAD = CASE WHEN COALESCE(LEN(SN.Chart_Chase_NPI), LEN(mmd.NPID)) != 10  THEN 1 ELSE NULL END, 
			isBillPROV_LAST_NAME_BAD = CASE WHEN LEN(ci.ProviderLastName) = 0 AND LEN(ci.ProviderOrganizationName) > 0 THEN 1 ELSE NULL END,
			isBillPROV_ORG_NAME_BAD = CASE WHEN LEN(ci.ProviderOrganizationName) = 0 AND LEN(ci.ProviderLastName) > 0 THEN 1 ELSE NULL END,
			isBillPROV_ADDRESS_BAD = CASE WHEN LEN(CONCAT(ci.ProviderFirstLineBusinessMailingAddress,ci.ProviderSecondLineBusinessMailingAddress)) = 0 THEN 1 ELSE NULL END,
			isBillPROV_CITY_BAD = CASE WHEN LEN(ci.ProviderBusinessMailingAddressCityName) = 0 THEN 1 ELSE NULL END,
			isBillPROV_ORG_STATE_BAD = CASE WHEN LEN(ci.ProviderBusinessMailingAddressStateName) = 0 THEN 1 ELSE NULL END,
			isBillPROV_ZIPCODE_BAD = CASE WHEN LEN(ci.ProviderBusinessMailingAddressPostalCode) = 0 THEN 1 ELSE NULL END, --FIX THIS
			isBILLINGPROV_TAX_ID_BAD = CASE WHEN LEN(REPLACE(mmd.FIDN,'%T%','')) != 9 THEN 1 ELSE NULL END --remove "T"  
		FROM supp_NPI SN
		LEFT JOIN EDPS_Data.IDQ.CMSGeneralInformation ci
			ON SN.Chart_Chase_NPI = ci.NPI
		LEFT JOIN #providers mmd
			ON SN.Chart_Chase_NPI = mmd.NPID)
	UPDATE FTC
		SET 
			STATUS_CODE = '222',
			Submission_Indicator = 1,
			Status_desc = COALESCE(	REPLACE(BD.isChart_Chase_NPI_or_NPID_BAD,'1','Data_Error_NPI_Missing'),
									REPLACE(COALESCE(BD.isBillPROV_LAST_NAME_BAD,BD.isBillPROV_ORG_NAME_BAD),'1','Data_Error_PROV_Name_Missing'),
									REPLACE(COALESCE(BD.isBillPROV_ADDRESS_BAD,BD.isBillPROV_CITY_BAD,BD.isBillPROV_ORG_STATE_BAD, isBillPROV_ZIPCODE_BAD),'1','Data_Error_PROV_ADDRESS_Missing'),
									REPLACE(BD.isBILLINGPROV_TAX_ID_BAD,'1','Data_Error_PROV_TaxId_Missing'))
	FROM #working_claims FTC
		JOIN BAD_Data BD
			ON  FTC.Source_System_Number = BD.Source_System_Number
			AND FTC.Member_ID = BD.Member_ID
			AND FTC.From_Date = BD.From_Date
			AND FTC.Thru_Date = BD.Thru_Date
	WHERE 1 = 1
		AND COALESCE(	BD.isChart_Chase_NPI_or_NPID_BAD,
						BD.isBillPROV_LAST_NAME_BAD,
						BD.isBillPROV_ORG_NAME_BAD,
						BD.isBillPROV_ADDRESS_BAD,
						BD.isBillPROV_CITY_BAD,
						BD.isBillPROV_ORG_STATE_BAD, 
						BD.isBillPROV_ZIPCODE_BAD,
						BD.isBILLINGPROV_TAX_ID_BAD) = 1;


	/*Create temp copy of output table*/
	--ALTER TABLE #stage_Supplemental_OUTPUT ADD ID_SEED INT;
	--ALTER TABLE #stage_Supplemental_OUTPUT REBUILD PARTITION = ALL WITH (DATA_COMPRESSION = ROW);
	Drop table if exists #Supplemental_OUTPUT 
	SELECT
		--ID = IDENTITY(INT, 1,1),
		ENC_ID = '',
		cast(NULL as INT) as RECEIVER_ID,				--N/A : this is used for Batch
		'PRO' 	ENC_TYPE,	--"IF [Supplemental_INPUT].provider_type = 'P' Then Populate ENC_TYPE = 'PROF' 		
																					--IF [Supplemental_INPUT].provider_type = I,N,O =Then Populate ENC_TYPE = 'INST'"
		CLAIM_IND = '01',
		HIC_NBR = ndxc.Hic_No,
		CMS_CONTRACT_NO = ndxc.Plan_No,
		RAPS_PROV_TYPE = Provider_Type,
		From_Date = J_From_Date_VARCHAR,
		Thru_Date = J_Thru_Date_VARCHAR,
		RAPS_PCN = Concat (member_id,'-',Source_system,'-',Source_system_number),
		CLAIM_NO = '',
		CHS_CLM_EDPS = NULL,
		ICN_NO = NULL,
		NPI_EDPS = NULL,
		NPI_SUPP = NULL,
		HS_CLAIM_NBR = ndxc.Source_System_Number,
		FREQ_CD = '1',
		[ACTION] = 'A',
		icd_version = '10',
		DIAG01_CODE_QUAL = 'ABK',
		DIAG01_CODE		 = ndxc.Dx_Code,
		DIAG02_CODE_QUAL = NULL,
		DIAG02_CODE		 = NULL,
		DIAG03_CODE_QUAL = NULL,
		DIAG03_CODE		 = NULL,
		DIAG04_CODE_QUAL = NULL,
		DIAG04_CODE		 = NULL,
		DIAG05_CODE_QUAL = NULL,
		DIAG05_CODE		 = NULL,
		DIAG06_CODE_QUAL = NULL,
		DIAG06_CODE		 = NULL,
		DIAG07_CODE_QUAL = NULL,
		DIAG07_CODE		 = NULL,
		DIAG08_CODE_QUAL = NULL,
		DIAG08_CODE		 = NULL,
		DIAG09_CODE_QUAL = NULL,
		DIAG09_CODE		 = NULL,
		DIAG10_CODE_QUAL = NULL,
		DIAG10_CODE		 = NULL,
		DIAG11_CODE_QUAL = NULL,
		DIAG11_CODE		 = NULL,
		DIAG12_CODE_QUAL = NULL,
		DIAG12_CODE = NULL,
		BILLPROV_LAST_NAME = LEFT(ci.ProviderLastName,35),
		BILLPROV_ORG_NAME = LEFT(ci.ProviderOrganizationName,50),
		BILLINGPROV_NPI = IIF(LEN(ndxc.Chart_Chase_NPI) = 0,mmd.NPID,ndxc.Chart_Chase_NPI),
		BILLINGPROV_GRP_NPI = IIF(LEN(ndxc.Chart_Chase_NPI) = 0,mmd.NPID,ndxc.Chart_Chase_NPI), 
		BILLINGPROV_ADDRESS = CONCAT(ci.ProviderFirstLineBusinessMailingAddress,' ',ci.ProviderSecondLineBusinessMailingAddress),
		BILLINGPROV_CITY = LEFT(ci.ProviderBusinessMailingAddressCityName,50),
		BILLINGPROV_STATE = LEFT(ci.ProviderBusinessMailingAddressStateName,50),
		BILLINGPROV_ZIPCODE = LEFT(IIF(LEN(NULLIF(ci.ProviderBusinessMailingAddressPostalCode,'')) = 5, CONCAT(ci.ProviderBusinessMailingAddressPostalCode,'9998'),ci.ProviderBusinessMailingAddressPostalCode), 50),
		BILLINGPROV_TAX_ID = IIF(mmd.FIDN LIKE '%T%',SUBSTRING(mmd.FIDN,1,9), mmd.FIDN),
		MEMBER_LAST_NAME = md.LastName,
		MEMBER_FIRST_NAME = md.FirstName,
		MEMBER_MIDDLE_NAME = NULLIF(md.MiddleName,'UNKNOWN'),
		MEMBER_ADDRESS = IIF(md.AddressLine2 = 'UNKNOWN',md.AddressLine1,CONCAT(md.AddressLine1,' ', md.AddressLine2)),
		MEMBER_CITY = md.City,
		MEMBER_STATE = md.State,
		MEMBER_ZIPCODE = md.Zip,
		MEMBER_DOB = md.DOBDateKey,
		MEMBER_GENDER = md.Gender,
		PLAN_CLAIM_NO = ndxc.Source_System_Number,
		PLACE_OF_SERVICE = '11',
		Supp_Type = 'Unlinked',
		[DATA_SOURCE] = Source_System,--ndxc.Data_Source,
		STATUS_CODE = '777',
		Status_desc = Convert(varchar(250),'Unlinked_SUB'),
		Process_Date = TRY_CAST(GETDATE() AS DATE),
		CYCLE = Convert(CHAR(8),getdate()+1,112), --CONCAT(FORMAT(GETDATE(), 'ddMMyyyy'),'_','Y', RIGHT(YEAR(GETDATE()),2), IIF(@cycle < 10,CONCAT('0',@cycle),@cycle) ),
		[FILE_NAME] = CAST('' AS VARCHAR(255)), --populated below	
		cast('' as varchar(20)) Edifecs_Claim_Id,
		getdate() Generation_Timestamp,
		ndxc.ID as RwNum	
	INTO #Supplemental_OUTPUT
	--select top  10 provider_type,mmd.MemberID,BILLINGPROV_CITY = LEFT(ci.ProviderBusinessPracticeLocationAddressCityName,50),*  
	FROM #working_claims ndxc
	LEFT JOIN #providers mmd
		ON ndxc.Member_ID = mmd.MemberID
		AND ndxc.From_Date BETWEEN mmd.BeginCoverageDateKey AND mmd.EndCoverageDateKey
	LEFT JOIN EDPS_Data.IDQ.CMSGeneralInformation ci
		ON ndxc.Chart_Chase_NPI = ci.NPI
	LEFT JOIN MDQOLib.dbo.MemberDim md
		ON md.MemberID = ndxc.Member_ID
		AND md.MemberKey = (SELECT MAX(md1.MemberKey) FROM MDQOLib.dbo.MemberDim md1 WHERE md.MemberID = md1.MemberID AND md1.Active = 1)
	WHERE 1 = 1
		AND mmd.MemberID IS NOT NULL
		and provider_type = 'P' 	
		and STATUS_CODE = '888';

	
;
 with cte as
 (
select 
	ROW_NUMBER() over (order by cycle) as rn,
	*
--from Supplemental_OUTPUT_Subhash
from #Supplemental_OUTPUT
)
,cte1 as
(
select 
--,case when enc_type = 'P' and cms_contract_no <> 'H8423'
 CONCAT('U', left(REPLACE(CONVERT (CHAR(10), getdate(), 101),'/',''),6), right(replicate('0',4)+left(replace([Data_Source],'_','0'),4),4)
  ,ceiling(rn/99999.0) --99999
 ,right(replicate('0',5)+convert(varchar(10),rn),5))  as Edifecs_Claim_Id1
 ,ceiling(rn/99999.0) as batchnumber --99999
,*
from cte
)
update cte1
set Edifecs_Claim_Id = Edifecs_Claim_Id1
, receiver_id = batchnumber
,[file_name] = case when ENC_TYPE = 'PRO' and CMS_CONTRACT_NO <> 'H0354' THEN  CONCAT('HSCE.PROD.MAO.88.P',Cycle,'0000',receiver_id) 
			when ENC_TYPE = 'PRO' and CMS_CONTRACT_NO = 'H0354' THEN  CONCAT('HSCE.PROD.MAO.AZ.88.P',Cycle,'0000',receiver_id) 
end

update #Supplemental_OUTPUT
set 
STATUS_CODE = case when len(BILLINGPROV_ZIPCODE) <> 9 THEN '222' 
					when len(MEMBER_ZIPCODE) not in  (9,5) THEN '222' 
					when len(BILLINGPROV_NPI) <> 10 THEN '222' 
					when len(BILLINGPROV_TAX_ID) <> 9 THEN '222' 
					ELSE STATUS_CODE END
	
,Status_desc =  case when len(BILLINGPROV_ZIPCODE) <> 9 THEN 'BILLINGPROV_ZIPCODE Error' 
					when len(MEMBER_ZIPCODE) not in  (9,5) THEN 'MEMBER_ZIPCODE Error' 
					when len(BILLINGPROV_NPI) <> 10 THEN 'BILLINGPROV_NPI Error' 
					when len(BILLINGPROV_TAX_ID) <> 9 THEN 'BILLINGPROV_TAX_ID Error' 
					else Status_desc END



update a
set 
a.STATUS_CODE = b.STATUS_CODE
,a.Status_desc = b.Status_desc
from WIPRO.dbo.Supplemental_INPUT a
join #Supplemental_OUTPUT b on a.ID = b.RwNum
where b.STATUS_CODE = '222'



--begin tran
--truncate table  [dbo].[Supplemental_OUTPUT]
insert into [dbo].[Supplemental_OUTPUT]
(
ENC_ID	,RECEIVER_ID,	ENC_TYPE	,CLAIM_IND	,HIC_NBR	,CMS_CONTRACT_NO	,RAPS_PROV_TYPE,	From_Date	
,Thru_Date	,RAPS_PCN	,CLAIM_NO	,CHS_CLM_EDPS	,ICN_NO	,NPI_EDPS	,NPI_SUPP	,HS_CLAIM_NBR	
,FREQ_CD	,[ACTION]	,icd_version	,DIAG01_CODE_QUAL	,DIAG01_CODE		,DIAG02_CODE_QUAL	,DIAG02_CODE		,DIAG03_CODE_QUAL	
,DIAG03_CODE	,DIAG04_CODE_QUAL	,DIAG04_CODE	,DIAG05_CODE_QUAL	,DIAG05_CODE	    ,DIAG06_CODE_QUAL	,DIAG06_CODE	,DIAG07_CODE_QUAL	
,DIAG07_CODE	,DIAG08_CODE_QUAL	,DIAG08_CODE	,DIAG09_CODE_QUAL	,DIAG09_CODE	    ,DIAG10_CODE_QUAL	,DIAG10_CODE	,DIAG11_CODE_QUAL	
,DIAG11_CODE	,DIAG12_CODE_QUAL	,DIAG12_CODE		
,BILLPROV_LAST_NAME	,BILLPROV_ORG_NAME	,BILLINGPROV_NPI	,BILLINGPROV_GRP_NPI	,BILLINGPROV_ADDRESS	,BILLINGPROV_CITY	
,BILLINGPROV_STATE	,BILLINGPROV_ZIPCODE	,BILLINGPROV_TAX_ID	,MEMBER_LAST_NAME	,MEMBER_FIRST_NAME	,MEMBER_MIDDLE_NAME	
	,MEMBER_ADDRESS,	MEMBER_CITY	,MEMBER_STATE	,MEMBER_ZIPCODE	,MEMBER_DOB	,MEMBER_GENDER	,PLAN_CLAIM_NO	
,PLACE_OF_SERVICE	,Supp_Type	,[Data_Source]	, STATUS_CODE	,Status_desc	,Process_Date	,[file_name]		,Cycle	,Generation_Timestamp	,Edifecs_Claim_Id
)
select 
ENC_ID	,RECEIVER_ID,	ENC_TYPE	,CLAIM_IND	,HIC_NBR	,CMS_CONTRACT_NO	,RAPS_PROV_TYPE,	From_Date	
,Thru_Date	,RAPS_PCN	,CLAIM_NO	,CHS_CLM_EDPS	,ICN_NO	,NPI_EDPS	,NPI_SUPP	,HS_CLAIM_NBR	
,FREQ_CD	,[ACTION]	,icd_version	,DIAG01_CODE_QUAL	,DIAG01_CODE		,DIAG02_CODE_QUAL	,DIAG02_CODE		,DIAG03_CODE_QUAL	
,DIAG03_CODE	,DIAG04_CODE_QUAL	,DIAG04_CODE	,DIAG05_CODE_QUAL	,DIAG05_CODE	    ,DIAG06_CODE_QUAL	,DIAG06_CODE	,DIAG07_CODE_QUAL	
,DIAG07_CODE	,DIAG08_CODE_QUAL	,DIAG08_CODE	,DIAG09_CODE_QUAL	,DIAG09_CODE	    ,DIAG10_CODE_QUAL	,DIAG10_CODE	,DIAG11_CODE_QUAL	
,DIAG11_CODE	,DIAG12_CODE_QUAL	,DIAG12_CODE	
,BILLPROV_LAST_NAME	,BILLPROV_ORG_NAME	,BILLINGPROV_NPI	,BILLINGPROV_GRP_NPI	,BILLINGPROV_ADDRESS	,BILLINGPROV_CITY	
,BILLINGPROV_STATE	,BILLINGPROV_ZIPCODE	,BILLINGPROV_TAX_ID	,MEMBER_LAST_NAME	,MEMBER_FIRST_NAME	,MEMBER_MIDDLE_NAME	
	,MEMBER_ADDRESS,	MEMBER_CITY	,MEMBER_STATE	,MEMBER_ZIPCODE	,MEMBER_DOB	,MEMBER_GENDER	,PLAN_CLAIM_NO	
,PLACE_OF_SERVICE	,Supp_Type	,[Data_Source]	, STATUS_CODE	,Status_desc	,Process_Date	,[file_name]		,Cycle	,Generation_Timestamp	,RTRIM(LTRIM(Edifecs_Claim_Id)) as Edifecs_Claim_Id
--,CHS_CLM_EDPS 
from #Supplemental_OUTPUT--#Supplemental_OUTPUT
where len(Edifecs_Claim_Id) <= 17
AND STATUS_CODE = '777'
AND Status_desc = 'Unlinked_SUB'
--and STATUS_CODE = '888'

--rollback tran



END

/*

select 
top 10
Claim_Type =  'PROF'
,DME	= 'FALSE'
,Chart_Review_Data	= 'TRUE'
,HICN_MBI =	HIC_NBR
,Contract_ID =	CMS_CONTRACT_NO
,Claim_No =	HS_CLAIM_NBR
,Claim_Freq_Code = 1
,Claim_Indicator	=  'Add'
,Adjusted_Claim_No	= ''
,DXCode_1 = 	DIAG01_CODE
,DXCode_2	= ''
,DXCode_3	= ''
,DXCode_4	= ''
,DXCode_5	= ''
,DXCode_6	= ''
,DXCode_7	= ''
,DXCode_8	= ''
,DXCode_9	= ''
,DXCode_10	= ''
,DXCode_11	= ''
,DXCode_12	= ''
,Patient_control_number	 =RAPS_PCN
,From_DOS	= From_Date
,Through_DOS	= Thru_Date
,BILLPROV_LASTNAME	= BILLPROV_LAST_NAME
,BILLINGPROV_NPI		= BILLINGPROV_NPI
,BILLINGPROV_ADDRESS	= BILLINGPROV_ADDRESS
,BILLINGPROV_CITY	= BILLINGPROV_CITY
,BILLINGPROV_STATE	= BILLINGPROV_STATE
,BILLINGPROV_ZIPCODE	= BILLINGPROV_ZIPCODE
,BILLINGPROV_TAX_ID	= BILLINGPROV_TAX_ID
,MEMBER_LAST_NAME	= MEMBER_LAST_NAME
,MEMBER_FIRST_NAME	= MEMBER_FIRST_NAME
,MEMBER_ADDRESS	= MEMBER_ADDRESS
,MEMBER_CITY		= MEMBER_CITY
,MEMBER_STATE	= MEMBER_STATE
,MEMBER_ZIPCODE	= MEMBER_ZIPCODE
,MEMBER_DOB		= MEMBER_DOB
,MEMBER_GENDER	= MEMBER_GENDER
,CMSICN = ''	 
,ENC_ID	 
,Edifecs_Claim_ID =	Edifecs_Claim_Id
--select top 10 *
from [Supplemental_OUTPUT]
where enc_type = 'PRO'
--and STATUS_CODE = '777'
and STATUS_CODE = '888'

*/
