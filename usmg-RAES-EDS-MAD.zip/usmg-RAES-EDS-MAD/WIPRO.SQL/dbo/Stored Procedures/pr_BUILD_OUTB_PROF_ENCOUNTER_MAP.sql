﻿

CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_PROF_ENCOUNTER_MAP]
(@LOB CHAR(10)  --Valid Values (MMAI,MOA)
 ,@LOBCODE VARCHAR(15) = '0'
,@JOBID INT =1
,@SOURCEDESC VARCHAR(60) )
AS
/********************************************************************************************************************************************************************
** CREATE DATE: 01/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
2012-10-19		Dwight Staggs	Remove database name from table references
2012-11-01		Loyal Ricks		Add CONTRACT_TYPE to claim_line HRP RECORD TYPE L
2012-11-09		LOYAL RICKS		ADD CLM_ADJ_QTY122
2012-11-15		LOYAL RICKS		ADD CLAIM ADJUSTMENT SEGMENTS 1-1-1 - 1.5-6
2012-12-12		LOYAL RICKS		REVISED @FILEID ASSIGNMENT FROM 'CLAIM'+''+RTRIM((replace(replace(replace(convert(char, getdate(), 120),'-',''),':',''),' ','')));
								TO 'HSCE'+''+RTRIM((replace(replace(replace(convert(char, getdate(), 120),'-',''),':',''),' ','')));
2013-03-05		LOYAL RICKS		Change Step from 8 to 9. EXSP_HRP_CLAIM_REQ_CATALL is now #8
2013-05-10		Loyal Ricks		Add Rendering Provider Information 
2013-05-13		Loyal Ricks		Replace default FILEID prefix 'HCSE' with substring(FILEDESC,1,6). This will enable source specific naming 
								of outbound file. Will allow for easier tracking of outbound file throughout entire submission process.
2013-08-05		Loyal Ricks		Add new columns to support Verisk intake file revisions for  OUTB_PROF_HEADER_STATUS - 
								(SecondaryPlanClaimNumber, EffectiveEncounterFlag,Original
2013-08-05		Loyal Ricks		OptionalReportingInd1 - Use for deleted line indicator
2013-10-29		Loyal Ricks		OptionalReportingInd1 - Use for deleted line indicator - deployment into code base
2014-01-13		Loyal Ricks		Add new variable @CLAIMTYPE to use with @FILEDESC in order to further identify (Prof vs. Inst) all outbound files
								New Assignment of @FILEDESC = SOURCEDESC + CLAIMTYPE
2014-04-08		Loyal Ricks		Verisk Version 4.0 Updates
								Verisk Claim Header - Added 157 data elements to account for Version 4.0 additional data elements, 
								 Header revision - '~'+replicate('~',1)+' '+'^' to '~'+replicate('~',158)+' '+'^'
								 Verisk Claim detail - added 23 data elements to account for version 4.0 additional data elements,
								 Detail revisions - +'~'+replicate('~',1)+' '+'^' to +'~'+replicate('~',25)+' '+'^'
								Update file version from 3.0 to 4.0
								Add parameter assignment for ProductIndicator - use @@server to assign appropriate value (Test vs Prod)
2015-07-22		Loyal Ricks		Remove default value assignment of @LOBCODE (0) and set to ' ' - blank 
								is used by MAO 	
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation	
2014-07-16		Loyal Ricks		Add 12 (160-172) data elements to claim header for condition codes 
2014-07-22		Loyal Ricks		Add 1 (172 to 173) for end of record "^" data element	
2014-07-23		Loyal Ricks		WIPRO File naming convention prefix, Production =  'DILT09.NCPDP.UPLOAD'	
								, Test = 'DILT09.NCPDPT.UPLOAD'	
2014-07-24		Loyal Ricks		Remove 1 (173 to 172) for end of record "^" data element	
2014-07-25		Loyal Ricks		Remove 1 (172 to 171) for end of record "^" data element	
2014-08-04		Loyal Ricks		Add PRINCIPAL_DIAG_QUAL & ADMIT_DIAG_QUAL 	
2014-08-05		Loyal Ricks		Revise logic for WIPRO file naming convention
2014-08-05		Loyal Ricks		Add "MMAI" tag to filedesc		
2014-08-05		Loyal Ricks		Remove 20 (136 to 116) for end of record "^" data element	
2014-08-18		Loyal Ricks		Add 12 data elements for I claim external cause of Injury Dx Qualifiers
								 - 	+'~'+RTRIM(ADMITDIAG_QUAL)+'~'+replicate('~',3)+' '			
								 Remove end of record spaces (-12) to account for above increase.	
								 from 	+'~'+replicate('~',116)+' '+'^' to 	+'~'+replicate('~',104)+' '+'^'	
2014-08-18		Loyal Ricks		Remove extra space in front of Primary Diagnosis Qualifier and Daignosis Code Qual. 1	
2014-09-23		Loyal Ricks		Add @LOB, populate OUTB_FILE_HIST.FILEDESC with this value as the suffix (rtrim(FILEDESC+'-'+@LOB)	
2014-11-05		Loyal Ricks		EMC-388 - Add assignment of default value for @CLAIM_TYPE, SET value ='P' due to DME (claim_type ='E')
2014-11-07		Loyal Ricks		EMC-388 - Add variable @TOTAL_DME_CLM in order to properly calculate the total claims in the file footer.
2014-11-18		Loyal Ricks		Add @LOB to fileid				    
2015-01-27		Loyal Ricks		Revised logic incorrectly mapping Vendorid & System Source. Fixed mapping to include 'CIGNA-HSPR' as 
								VendorId & SourceDesc+claim_type+lob as system source
2015-02-10		Loyal Ricks 	EDS-680 Add File Subtype(@FILESUBTYPE) - When @CLAIMTYPE = 'P' THEN SET VALUE = 'Professional' WHEN
								@CLAIMTYPE = 'E' THEN SET VALUE = 'DME'	ELSE ' '
2015-02-17		Loyal Ricks		Map fix - adjust +'~'+RTRIM(RENDERING_PROV_LAST_NAME)+'~'+RTRIM(RENDERING_PROV_LAST_NAME), change to
								+'~'+RTRIM(RENDERING_PROV_LAST_NAME)+'~'+RTRIM(RENDERING_PROV_FIRST_NAME)
2015-04-08		Loyal Ricks		Remove explicit begin transactions 
								Add OUTB_PROF_HEADER and OUTB_PROF_DETAIL archiving - execute pr_ClaimProfessionalExtractHistoryInsert @FILEID
2015-05-29		Loyal Ricks		TETDM-107 Add input parameter @LOBCODE to support MMAI Plans (IL & TX) file naming conventions
								Add variable @SUBMITTERID to support file naming convention
								Revise Fileid for MMAI files
2015-07-13		Loyal Ricks		Add formatting for @SUBMITTERID to include node value of '.' when passed. This node is conditional
								and is only needed when it is a MMAI file. Absence of this logic was creating an extra node for 
								MAO files.
 2015-07-23		Loyal Ricks		TETDM-276 Add JOBID to filedesc
 ------------------------------------------------------------------------------------------------------------------------
 2015-11-04		Loyal Ricks		Revise fileid assignment to match WIPRO file naming convention for encounters	
 2015-11-04		Loyal Ricks		Remove Edit check due to encounter capitation payments - EXECUTE BUILD_OUTB_CLAIM_CKHSUM
 2016-10		Loyal Ricks		TETDM-1003, TETDM-856 
								 Add substring due to filenaming convention limitation of 10char - @FILEDESC  assignment
								Add @LOB for MMAI-Care/Caid
								Add @PRODUCTNODE for MMAI-Care/Caid
2016-11-28		Loyal Ricks		TETDM-1258 Add EXT_Encounter_SourceDesc table for assignment of vendor name node in outbound file
2016-12-12		Loyal Ricks		Revise assignment of pr_BUILD_OUTB_PROF_ENCOUNTER_MAP.recordid from '9999' to 'ZZZZZZZZZ' 
								due to new format of Facets claimid from numeric to alpha numeric. Revision 
								needed to resolve placement of trailer record in outbound file. This will 
								prevent trailer record from being misplaced in outbound file when claimid
								begin with alpha character.		
2016-12-12		Loyal Ricks		Revise Claim Header and Claim Detail appends to removal of  "-" in the OUTB_PROF_CLAIM_MAP.REOCRDID 
								(aka: encounterlcaimdim.claimnum) in order to aline outbound header and detail records
2017-12-21		Mike Vega		TETDM-1649 --> REMOVE "CHKSUM" logic call in order to prevent any out-of-balance claims from being entered into the EXT_CLAIM_CHKSUM Table		
2018-04-01		Henry Faust		TETDM-1677 CMS Reject 999 (91878) and 277 (20407) Service Unit must be greater than 0, ok TO DEFAULT TO 1
2018-08-08		Scott Waller	TETDM-1768 		Create an exclusion for encounters that have more than one claim type
2018-09-25     JohnBartholomay  TETDM-1852  Hospice Indicator added to the map
2019-03-14		Anthony Ulmer	TETDM-1855 Update to "hack" claim sort order since varchar sort causes claims to mix when in close sequence
*************************************************************************************************************************/

--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM OUTB_PROF_HEADER_RESEND
	DECLARE
			@TOTAL_RECORDS INT,
			--FILE FOOTER	
			@TOTAL_CLAIM   INT,
			@TOTAL_PROF_CLM INT,
			@TOTAL_DME_CLM INT,
			@TOTAL_INST_CLM INT,
			@TOTAL_DENTAL_CLM INT ,
			@TOTAL_LINES INT,
			@SUM_TOTAL_CHARGES MONEY,
			@SUM_LINE_CHARGES MONEY,
			@SUM_TOTAL_CHARGES2 MONEY,
			@SUM_LINE_CHARGES2 MONEY,
			@TOTAL_EOF_COUNT INT,
			@CREATEDT CHAR(14),
			@FILEID CHAR(50),
			@FOOTER CHAR(255),
			@HEADER_CNTRL INT,
			@FOOTER_CNTRL INT,
			@RECHEADER_CNTRL INT,
			@RECDTL_CNTRL INT,
			@RECOTH_CNTRL INT,
			@FILE_TYPE CHAR(50),
			@VERSION CHAR(10) ,
			@SOURCEDATAKEY INT,
			@FILEDESC VARCHAR(35),
			@CLAIMTYPE VARCHAR(1),
			@PRODUCTINDICATOR VARCHAR(4),
			@FILESUBTYPE VARCHAR(15),
			@SUBMITTERID VARCHAR(15),
			@PRODUCTNODE VARCHAR(5) ,
			@VENDORNAME VARCHAR(10),
-- TETDM-1768
			@MULTICLAIMTYPE	INT,
			@HSPE_IND  VARCHAR(1) --TETDM-1852

begin

	--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_PROF_ENCOUNTER_MAP'
				,'11'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)

	--PROCEDURE VARIABLES 
		--PROCEDURE VARIABLES
		IF @@SERVERNAME IN ('HSTNEDSDB01')
			BEGIN 
				SET @PRODUCTINDICATOR = 'PROD'
				SET @FILEID = 'HSCE.PROD.'
			END
		IF @@SERVERNAME IN ('HSTNEDSDEVDB02') 
			BEGIN 
				SET @PRODUCTINDICATOR = 'TEST'
				SET @FILEID = 'HSCE.DEV.'
			END
		IF @@SERVERNAME IN ('HSTNEDSDEVDB01') 
			BEGIN 
				SET @PRODUCTINDICATOR = 'TEST'
				SET @FILEID = 'HSCE.QA.'
			END
		--File naming convention Submitterid node assignment
		
				if @LOBCODE = '0'
					BEGIN 
						SET @LOBCODE = ' '
					END
					--MMAI IL
				if @LOBCODE = 'UMISC0028041899'
					BEGIN 
						SET @SUBMITTERID = 'DILT09.'
					END
					--MMAI TX
				if @LOBCODE = 'C54581391'
					BEGIN 
						SET @SUBMITTERID = 'DTXT08.'
					END

				-----06/08/16 MMAI CAID PRODUCTNODE 

				SET @PRODUCTNODE = 'CARE';
				IF @LOB = 'CAID'
					BEGIN 
						SET @PRODUCTNODE = 'CAID';
						SET @LOB = 'MMAI'
					END

				----Vendor Name assignment

				set @VENDORNAME = (select rtrim(WIPRO_FILENAME_NODE) from EXT_Encounter_SourceDesc where sourcedesc = @SOURCEDESC);





		SET @SOURCEDATAKEY = (SELECT DISTINCT SOURCEDATAKEY FROM OUTB_PROF_HEADER);
		SET @CLAIMTYPE = (select distinct claim_type from OUTB_PROF_HEADER);
		--SET @FILEID = (SELECT RTRIM(CNTRL_TXT)+''+@CLAIMTYPE FROM EXT_SYS_CLM_JOBCNTRL WHERE CNTRL_DESC = 'FILEID' AND CNTRL_STATUS = 'A');
		--SET @FILEDESC = (SELECT RTRIM(SOURCEDESC)+'-'+'MMAI' FROM SourceDataDim WHERE SourceDataKey = @SOURCEDATAKEY) + '-'+ @CLAIMTYPE+ '-'+ RTRIM(@LOB);
		SET @FILEID = RTRIM(@FILEID)+''+rtrim(@LOB)+'.'+ISNULL(RTRIM(@SUBMITTERID),'')+''+RTRIM(convert(char(10),@sourcedatakey))+'.'+@CLAIMTYPE+'.CARE.'+RTRIM(@VENDORNAME)+'.'+RTRIM((replace(replace(replace(convert(char, getdate(), 120),'-',''),':',''),' ','')));
		--SET @FILEID = RTRIM(@FILEID)+''+RTRIM((replace(replace(replace(convert(char, getdate(), 120),'-',''),':',''),' ','')));
		SET @CREATEDT = RTRIM((replace(replace(replace(convert(char, getdate(), 120),'-',''),':',''),' ','')));
		SET @SUM_TOTAL_CHARGES2 = (SELECT SUM(convert(MONEY, LTRIM(TOT_CHRG_AMT))) FROM OUTB_PROF_HEADER);	
		SET @SUM_LINE_CHARGES2 = (SELECT SUM(convert(MONEY, LTRIM(TOTAL_CHRG_AMT))) FROM OUTB_PROF_DETAIL);	
		SET @FILESUBTYPE = CASE @CLAIMTYPE WHEN 'P' THEN 'Professional' WHEN 'E' THEN 'DME' ELSE ' ' END;		
		
	    --------------------------
        --TETDM-1852 HOSPICE IND
        --------------------------
       IF OBJECT_ID('TEMPDB..#CLAIM_HCPE_IND') <> 0
	      DROP TABLE #CLAIM_HCPE_IND
			
       CREATE TABLE #CLAIM_HCPE_IND
       (
         CLAIM_ID VARCHAR(20),
         POS   VARCHAR(50),
         HCPE_IND  VARCHAR(1)
       )

       INSERT INTO #CLAIM_HCPE_IND
       SELECT CLAIM_ID,
              POS,
	         ' ' AS HCPE_IND
       FROM OUTB_PROF_HEADER

       UPDATE #CLAIM_HCPE_IND
       SET HCPE_IND  = 'N'
       WHERE POS = '34'
		
		/***************************************************************************************************
		** 
		** HRP CLAIM FILE CHECK SUM - VALIDATE OUTBOUND CLAIM HEADER & LINE TOTAL CHARGES
		**
		*****************************************************************************************************/
		
		----TETDM-1649 --> Remove by Mike Vega 12/21/17
		----------------------------------------------		
		----11/04/15- Remove Check for all encounter submissions due to capitated payments
		--IF @SUM_TOTAL_CHARGES2 <> @SUM_LINE_CHARGES2 
		--begin
		--	EXECUTE BUILD_OUTB_CLAIM_CKHSUM @FILEID
		--end 
--------------------------------------------------------------------------------------------------------
-- TETDM-1768 Create an exclusion for encounters that have more than 1 claim type 
-- 08/08/2018 Scott Waller
--------------------------------------------------------------------------------------------------------
		SELECT	@MULTICLAIMTYPE	= 0;

		SELECT	@MULTICLAIMTYPE = ISNULL(COUNT(*), 0) 
		FROM	(SELECT	b.claimnum, COUNT(*) as ClaimTypeCount
				 FROM	(SELECT	ec.claimnum, ec.ClaimType
						 FROM	WIPRO.dbo.OUTB_PROF_HEADER oph
						 INNER JOIN	EDPS_DATA.dbo.encounterclaimdim ec
							ON	ec.ClaimNum			= oph.CLAIM_ID
							AND	ec.SourceDataKey	= 4
							AND	ec.sourcedesc		= @SOURCEDESC
						 GROUP BY ec.claimnum, ec.ClaimType ) b
				GROUP BY b.ClaimNum
				HAVING COUNT(*) > 1) a

		IF	(@MULTICLAIMTYPE > 0)
		BEGIN
			EXEC dbo.EXSP_CLAIM_EXCLUSION_MULTI_CLAIM_TYPES 'P', @SOURCEDESC
		END
-- END TETDM-1768
				
		TRUNCATE TABLE OUTB_PROF_CLAIM_MAP
		
	/**************************************************************************
		sort order fix, this temp table is used further down
		this is to pre-designate a claim sort number
		otherwise claims in close sequence get mixed since the field is varchar
	***************************************************************************/
    IF OBJECT_ID('tempdb.dbo.#claim_ordinal') IS NOT NULL
	    DROP TABLE #claim_ordinal;

    SELECT DISTINCT
        oph.CLAIM_ID,
        ordinal = IDENTITY(INT,1,1)
    INTO #claim_ordinal
    FROM WIPRO.dbo.OUTB_PROF_HEADER oph;
	/*end sort fix*/
--PROCEDURE VARIABLES 
--FILE FOOTER	

		--BUILD HRP CLAIM RECORD TYPE C - CLAIM HEADER
		--SHOULD SPACING BEFORE REPLICATE INCLUDE +''+ OR +'~'+
	--BEGIN TRANSACTION
		 insert into OUTB_PROF_CLAIM_MAP
		SELECT DISTINCT '2000',LTRIM(RTRIM(CAST(co.ordinal AS VARCHAR)))+'-'+RTRIM(REPLACE(oph.CLAIM_ID,'-',''))+'-'+'0000'+'-'+'2000',RTRIM(RECORD_TYPE)+'~'+RTRIM(CLAIM_TYPE)+'~'+RTRIM(SYSTEM_SOURCE)+'~'+RTRIM(CMS_CONTRACT_NUM)+'~'+RTRIM(HICN_NUM)+'~'+RTRIM(oph.CLAIM_ID)+'~'+RTRIM(PAT_CNTRL_NO)+'~'+RTRIM(MEMBER_ID)
			+'~'+RTRIM(MEMBER_LAST_NAME)+'~'+RTRIM(MEMBER_FIRST_NAME)+'~'+RTRIM(MEMBER_MID_INIT)+'~'+RTRIM(MEMBER_SFX)+'~'+RTRIM(MEMBER_ADDR1)+'~'+RTRIM(MEMBER_ADDR2)+'~'+RTRIM(MEMBER_CITY)
			+'~'+RTRIM(MEMBER_STATE)+'~'+RTRIM(MEMBER_ZIP)+'~'+RTRIM(MEMBER_ZIP4)+'~'+RTRIM(MEMBER_CTY)+'~'+RTRIM(MEMBER_CTRY)+'~'+RTRIM(MEMBER_CTRY_SUBD)
			+'~'+RTRIM(MEMBER_GROUP_NO)+'~'+RTRIM(INSURANCE_TYPE)+'~'+RTRIM(MEMBER_DOB)+'~'+RTRIM(MEMBER_GENDER)+'~'+RTRIM(MEMBER_SSN)+'~'+RTRIM(POS)+'~'+RTRIM(INST_PRINCIPAL_DIAG_CD)
			+'~'+RTRIM(INST_PRINCIPAL_POA_CD)+'~'+RTRIM(INST_ADM_DIAG_CD)+'~'+replicate('~',28)+''+RTRIM(DIAG_CD1)+'~'+RTRIM(POA_IND1)+'~'+RTRIM(DIAG_CD2)+'~'+RTRIM(POA_IND2)
			+'~'+RTRIM(DIAG_CD3)+'~'+RTRIM(POA_IND3)+'~'+RTRIM(DIAG_CD4)+'~'+RTRIM(POA_IND4)+'~'+RTRIM(DIAG_CD5)+'~'+RTRIM(POA_IND5)+'~'+RTRIM(DIAG_CD6)+'~'+RTRIM(POA_IND6)
			+'~'+RTRIM(DIAG_CD7)+'~'+RTRIM(POA_IND7)+'~'+RTRIM(DIAG_CD8)+'~'+RTRIM(POA_IND8)+'~'+RTRIM(DIAG_CD9)+'~'+RTRIM(POA_IND9)+'~'+RTRIM(DIAG_CD10)+'~'+RTRIM(POA_IND10)
			+'~'+RTRIM(DIAG_CD11)+'~'+RTRIM(POA_IND11)+'~'+RTRIM(DIAG_CD12)+'~'+RTRIM(POA_IND12)+'~'+RTRIM(DIAG_CD13)+'~'+RTRIM(POA_IND13)+'~'+RTRIM(DIAG_CD14)+'~'+RTRIM(POA_IND14)
			+'~'+RTRIM(DIAG_CD15)+'~'+RTRIM(POA_IND15)+'~'+RTRIM(DIAG_CD16)+'~'+RTRIM(POA_IND16)+'~'+RTRIM(DIAG_CD17)+'~'+RTRIM(POA_IND17)+'~'+RTRIM(DIAG_CD18)+'~'+RTRIM(POA_IND18)
			+'~'+RTRIM(DIAG_CD19)+'~'+RTRIM(POA_IND19)+'~'+RTRIM(DIAG_CD20)+'~'+RTRIM(POA_IND20)+'~'+RTRIM(DIAG_CD21)+'~'+RTRIM(POA_IND21)+'~'+RTRIM(DIAG_CD22)+'~'+RTRIM(POA_IND22)
			+'~'+RTRIM(DIAG_CD23)+'~'+RTRIM(POA_IND23)+'~'+RTRIM(DIAG_CD24)+'~'+RTRIM(POA_IND24)+'~'+RTRIM(DIAG_CD25)+'~'+RTRIM(POA_IND25)+'~'+RTRIM(DIAG_CD26)+'~'+RTRIM(POA_IND26)
			+'~'+RTRIM(DIAG_CD27)+'~'+RTRIM(POA_IND27)+'~'+RTRIM(DIAG_CD28)+'~'+RTRIM(POA_IND28)+'~'+RTRIM(DIAG_CD29)+'~'+RTRIM(POA_IND29)+'~'+RTRIM(DIAG_CD30)+'~'+RTRIM(POA_IND30)
			+'~'+RTRIM(BILL_PROV_NPI)+'~'+RTRIM(BILL_PROV_GRP_ID)+'~'+RTRIM(BILL_PROV_GRP_NPI)+'~'+RTRIM(BILL_PROV_ORG_NAME)+'~'+RTRIM(BILL_PROV_LNAME)
			+'~'+RTRIM(BILL_PROV_FNAME)+'~'+RTRIM(BILL_PROV_MID_INIT)+'~'+RTRIM(BILL_PROV_SFX)+'~'+RTRIM(BILL_PROV_ADDR1)+'~'+RTRIM(BILL_PROV_ADDR2)
			+'~'+RTRIM(BILL_PROV_CITY)+'~'+RTRIM(BILL_PROV_STATE)+'~'+RTRIM(BILL_PROV_ZIP)+'~'+RTRIM(BILL_PROV_ZIP4)+'~'+RTRIM(BILL_PROV_CTRY)+'~'+RTRIM(BILL_PROV_CTRY_SUBD)
			+'~'+RTRIM(BILL_PROV_TAXONOMY_CD)+'~'+RTRIM(BILL_PROV_TAX_ID)+'~'+RTRIM(BILL_PROV_SSN)+'~'+RTRIM(BILL_PROV_UPIN)+'~'+RTRIM(BILL_PROV_LICENSE_NO)+'~'+RTRIM(BILL_PROV_ID)
			+'~'+replicate('~',9)+''+RTRIM(PAYTO_ADDR_TYPE_FLAG)+'~'+RTRIM(PAYTO_ADDR1)+'~'+RTRIM(PAYTO_ADDR2)+'~'+RTRIM(PAYTO_CITY)+'~'+RTRIM(PAYTO_STATE)+'~'+RTRIM(PAYTO_ZIP)
			+'~'+RTRIM(PAYTO_ZIP4)+'~'+RTRIM(PAYTO_CTRY)+'~'+RTRIM(PAYTO_CTRY_SUBD)+'~'+RTRIM(PAYER_RESP)+'~'+RTRIM(TOT_CHRG_AMT)+'~'+RTRIM(MEMBER_AMT_PAID)+'~'+RTRIM(PATIENT_EST_AMT_DUE)
			+'~'+RTRIM(CLM_IND)+'~'+replicate('~',12)+''+RTRIM(PROV_SIGNATURE_FLAG)+'~'+RTRIM(PROV_ASSGN_IND)+'~'+RTRIM(INSR_BEN_ASSGN_IND)+'~'+RTRIM(REL_OF_INFO_FLAG)+'~'+replicate('~',20)+''+RTRIM(SERV_DT)+'~'+RTRIM(ADM_TYPE_CD)
			+'~'+RTRIM(ADM_SOURCE_CD)+'~'+RTRIM(ADM_DT)+'~'+RTRIM(ADM_TIME)+'~'+RTRIM(STATE_BEGIN_DT)+'~'+RTRIM(STATE_END_DT)+'~'+RTRIM(DISCHRG_DT)+'~'+RTRIM(DISCHRG_TIME)+'~'+RTRIM(PATIENT_STATUS_CD)
			+'~'+replicate('~',47)+''+RTRIM(REFERRAL_NO)+'~'+replicate('~',1)+''+RTRIM(PAYER_CLAIM_CNTRL_NUM)+'~'+replicate('~',7)+''+RTRIM(CPO_NPI)+'~'+replicate('~',128)+''+RTRIM(PRICE_METHOD)+'~'+replicate('~',12)
			+''+RTRIM(REF_PROV_LNAME)+'~'+RTRIM(REF_PROV_FNAME)+'~'+RTRIM(REF_PROV_MID_INIT)+'~'+RTRIM(REF_PROV_SFX)+'~'+RTRIM(REF_PROV_NPI)+'~'+RTRIM(REF_PROV_TAXONOMY_CD)+'~'+RTRIM(REF_PROV_LICENSE_NO)
			+'~'+RTRIM(REF_PROV_UPIN)+'~'+RTRIM(REF_PROV_ID)+'~'+RTRIM(REF_PCP_LNAME)+'~'+RTRIM(REF_PCP_FNAME)+'~'+RTRIM(REF_PCP_MID_INIT)+'~'+RTRIM(REF_PCP_SFX)+'~'+RTRIM(REF_PCP_PROV_NPI)
			+'~'+RTRIM(REF_PCP_TAXONOMY_CD)+'~'+RTRIM(REF_PCP_LICENSE_NO)+'~'+RTRIM(REF_PCP_PROV_UPIN)+'~'+RTRIM(REF_PCP_PROV_ID)+'~'+RTRIM(RENDERING_PROV_ORG_NAME)+'~'+RTRIM(RENDERING_PROV_GRP_ID)
			+'~'+RTRIM(RENDERING_PROV_LAST_NAME)+'~'+RTRIM(RENDERING_PROV_FIRST_NAME)
			+'~'+RTRIM(RENDERING_PROV_MID_INIT)+'~'+RTRIM(RENDERING_PROV_SFX)+'~'+replicate('~',6)+''+RTRIM(RENDERING_PROV_NPI)+'~'+replicate('~',3)+''+RTRIM(RENDERING_PROV_ID)+'~'+replicate('~',25)+''+RTRIM(ATTN_PROV_LNAME)
			+'~'+RTRIM(ATTN_PROV_FNAME)+'~'+RTRIM(ATTN_PROV_MIDINIT)+'~'+RTRIM(ATTN_PROV_SFX)+'~'+RTRIM(ATTN_PROV_NPI)+'~'+RTRIM(ATTN_PROV_TAXONOMY_CD)+'~'+RTRIM(ATTN_PROV_TAXONOMY_CD2)
			+'~'+RTRIM(ATTN_PROV_UPIN)+'~'+RTRIM(ATTN_PROV_LOC_NO)+'~'+RTRIM(ATTN_PROV_ID)+'~'+RTRIM(ATTN_PROV_LICENSE_NO)
			+'~'+replicate('~',27)+''+RTRIM(PAYER_RESP1)+'~'+RTRIM(REL_CD1)+'~'+RTRIM(OTH_INSR_GRPNO1)+'~'+RTRIM(OTH_INSR_GRPNAME)+'~'+RTRIM(OTH_INSR_TYPECD1)+'~'+RTRIM(CLM_FIL_INDCD1)
			+'~'+RTRIM(CLM_ADJ_GRP_TYPE1)+'~'+RTRIM(CLM_ADJ_REA_CD1)+'~'+RTRIM(CLM_ADJ_AMT1)+'~'+RTRIM(CLM_ADJ_UNIT1)+'~'+
			+''+replicate('~',91)+''+RTRIM(AMOUNT_PAID)+'~'+RTRIM(COB_TOTAL)+'~'+replicate('~',1)+''+RTRIM(ASSIGN_BEN_IND1)
			+'~'+replicate('~',33)+''+RTRIM(MEMBER_LAST_NAME)+'~'+RTRIM(MEMBER_FIRST_NAME)+'~'+RTRIM(MEMBER_MID_INIT)+'~'+RTRIM(MEMBER_SFX)+'~'+RTRIM(HICN_NUM)+'~'+RTRIM(MEMBER_ADDR1)+'~'+RTRIM(MEMBER_ADDR2)+'~'+RTRIM(MEMBER_CITY)
			+'~'+RTRIM(MEMBER_STATE)+'~'+RTRIM(MEMBER_ZIP)+'~'+RTRIM(MEMBER_ZIP4)+'~'+replicate('~',3)+''+RTRIM(OTH_PAYER1_NAME)+'~'+RTRIM(OTH_PAYER1_PLANID)+'~'+RTRIM(OTH_PAYER1_ADDRESS1)+'~'+RTRIM(OTH_PAYER1_ADDRESS2)
			+'~'+RTRIM(OTH_PAYER1_CITY)+'~'+RTRIM(OTH_PAYER1_STATE)+'~'+RTRIM(OTH_PAYER1_ZIP)+'~'+RTRIM(OTH_PAYER1_ZIP4)+'~'+replicate('~',2)+''+RTRIM(PAYER1_PAID_DT)+'~'+replicate('~',2215)+''+RTRIM(OPTIONAL_REPORTING_IND)
			+'~'+replicate('~',21)+''+RTRIM(PRINCIPAL_DIAG_QUAL)+'~'+RTRIM(ADMITDIAG_QUAL)+'~'+replicate('~',15)+''+RTRIM(DIAG_CD_QUAL1)+'~'+RTRIM(DIAG_CD_QUAL2)+'~'+RTRIM(DIAG_CD_QUAL3)+'~'+RTRIM(DIAG_CD_QUAL4)+'~'+RTRIM(DIAG_CD_QUAL5)
			+'~'+RTRIM(DIAG_CD_QUAL6)+'~'+RTRIM(DIAG_CD_QUAL7)+'~'+RTRIM(DIAG_CD_QUAL8)+'~'+RTRIM(DIAG_CD_QUAL9)+'~'+RTRIM(DIAG_CD_QUAL10)+'~'+RTRIM(DIAG_CD_QUAL11)+'~'+RTRIM(DIAG_CD_QUAL12)+'~'+RTRIM(DIAG_CD_QUAL13)+'~'+RTRIM(DIAG_CD_QUAL14)
			+'~'+RTRIM(DIAG_CD_QUAL15)+'~'+RTRIM(DIAG_CD_QUAL17)+'~'+RTRIM(DIAG_CD_QUAL18)+'~'+RTRIM(DIAG_CD_QUAL19)+'~'+RTRIM(DIAG_CD_QUAL20)+'~'+RTRIM(DIAG_CD_QUAL21)+'~'+RTRIM(DIAG_CD_QUAL22)+'~'+RTRIM(DIAG_CD_QUAL23)+'~'+RTRIM(DIAG_CD_QUAL24)
			+'~'+RTRIM(DIAG_CD_QUAL25)+'~'+RTRIM(DIAG_CD_QUAL26)+'~'+RTRIM(DIAG_CD_QUAL27)+'~'+RTRIM(DIAG_CD_QUAL28)+'~'+RTRIM(DIAG_CD_QUAL29)+'~'+RTRIM(DIAG_CD_QUAL30)+'~'+replicate('~',104)+' '+'^'
			--+'~'+replicate('~',171)+' '+'^'
		FROM DBO.OUTB_PROF_HEADER oph
			JOIN #claim_ordinal co
				ON oph.CLAIM_ID = co.CLAIM_ID
	--		if @@ERROR <> 0
	--			begin
	--				rollback 
	--			end
	--COMMIT
	--BUILD HRP CLAIM RECORD TYPE L - CLAIM LINE
	--SHOULD SPACING BEFORE REPLICATE INCLUDE +''+ OR +'~'+
	--BEGIN TRANSACTION
		INSERT INTO OUTB_PROF_CLAIM_MAP
		SELECT DISTINCT '3000',LTRIM(RTRIM(CAST(co.ordinal AS VARCHAR)))+'-'+RTRIM(REPLACE(opd.CLAIM_ID,'-',''))+'0'+RTRIM(opd.CLAIM_LINE_NO)+'-'+'3000',RTRIM(RECORD_TYPE)+'~'+RTRIM(opd.CLAIM_ID)+'~'+RTRIM(opd.CLAIM_LINE_NO)+'~'+RTRIM(SERV_START_DT)+'~'+RTRIM(SERV_END_DT)+'~'+RTRIM(REV_CD1)+'~'+RTRIM(REV_CD2)+'~'+RTRIM(REV_CD3)
			+'~'+RTRIM(SERV_ID_QUAL)+'~'+RTRIM(PROC_CD)+'~'+RTRIM(PROC_MOD1)+'~'+RTRIM(PROC_MOD2)+'~'+RTRIM(PROC_MOD3)+'~'+RTRIM(PROC_MOD4)+'~'+RTRIM(PROC_DESC)+'~'+RTRIM(TOTAL_CHRG_AMT)+'~'+RTRIM(NON_COV_AMT)+'~'+RTRIM(ANES_FLAG)
			+'~'+RTRIM(QTY_DAYS)+'~'+
--TETDM-1677 
--			RTRIM(QTY_UNITS)
            CASE  WHEN opd.qty_units = 0 OR opd.qty_units IS NULL THEN '1' ELSE RTRIM(opd.QTY_UNITS) END --TETDM-1773
			+'~'+RTRIM(opd.POS)+'~'+RTRIM(PRIM_DIAG_CD)+'~'+RTRIM(DIAG_CD2)+'~'+RTRIM(DIAG_CD3)+'~'+RTRIM(DIAG_CD4)+'~'+RTRIM(DIAG_CD5)+'~'+RTRIM(DIAG_CD6)+'~'+RTRIM(DIAG_CD7)+'~'+RTRIM(DIAG_CD8)+'~'+RTRIM(DIAG_CD9)
			+'~'+RTRIM(DIAG_CD10)+'~'+RTRIM(DIAG_CD11)+'~'+RTRIM(DIAG_CD12)+'~'+RTRIM(DIAG_CD13)+'~'+RTRIM(DIAG_CD14)+'~'+RTRIM(DIAG_CD15)+'~'+RTRIM(DIAG_CD16)+'~'+RTRIM(DIAG_CD17)+'~'+RTRIM(DIAG_CD18)+'~'+RTRIM(DIAG_CD19)+'~'+RTRIM(DIAG_CD20)
			+'~'+RTRIM(DIAG_CD21)+'~'+RTRIM(DIAG_CD22)+'~'+RTRIM(DIAG_CD23)+'~'+RTRIM(DIAG_CD24)+'~'+RTRIM(DIAG_CD25)+'~'+RTRIM(DIAG_CD26)+'~'+RTRIM(DIAG_CD27)+'~'+RTRIM(DIAG_CD28)+'~'+RTRIM(DIAG_CD29)+'~'+RTRIM(DIAG_CD30)
		--  +'~'+RTRIM(EMER_FLAG)+'~'+RTRIM(COPAY_EX_FLAG)+'~'+replicate('~',90)+''+RTRIM(CONTRACT_TYPE)+'~'+replicate('~',2)+''+
			+'~'+RTRIM(EMER_FLAG)+'~'+RTRIM(COPAY_EX_FLAG)+'~'+replicate('~',70)+''+RTRIM(IND.HCPE_IND)+'~'+REPLICATE('~',19)+''+RTRIM(CONTRACT_TYPE)+'~'+replicate('~',2)+''+
			+''+RTRIM(CONTRACT_CODE)+'~'+replicate('~',5)+''+RTRIM(PRICE_METHOD)+'~'+replicate('~',13)+''+RTRIM(CLAIM_LINE_NO)+'~'+replicate('~',1)+''+RTRIM(CLIA_NO)+'~'+RTRIM(REF_CLIA_FAC_NO_QUAL)+'~'+replicate('~',158)
			+''+RTRIM(OTH_PAYER1_PRIMEID)+'~'+RTRIM(OTH_PAYER1_PAID_AMT)+'~'+RTRIM(OTH_PAYER1_PROC_CD)+'~'+replicate('~',7)+''+RTRIM(OTH_PAYER1_PAID_QTY)+'~'+RTRIM(OTH_PAYER1_ADJ_BUNDLE)+'~'+RTRIM(CLM_ADJ_GRP111)+'~'+RTRIM(CLM_ADJ_REASON111)
			+'~'+RTRIM(CLM_ADJ_AMT111)+'~'+RTRIM(CLM_ADJ_QTY111)+'~'+RTRIM(CLM_ADJ_REASON112)+'~'+RTRIM(CLM_ADJ_AMT112)+'~'+RTRIM(CLM_ADJ_QTY112)+'~'+RTRIM(CLM_ADJ_REASON113)+'~'+RTRIM(CLM_ADJ_AMT113)+'~'+RTRIM(CLM_ADJ_QTY113)
			+'~'+RTRIM(CLM_ADJ_REASON114)+'~'+RTRIM(CLM_ADJ_AMT114)+'~'+RTRIM(CLM_ADJ_QTY114)+'~'+RTRIM(CLM_ADJ_REASON115)+'~'+RTRIM(CLM_ADJ_AMT115)+'~'+RTRIM(CLM_ADJ_QTY115)+'~'+RTRIM(CLM_ADJ_REASON116)+'~'+RTRIM(CLM_ADJ_AMT116)+'~'+RTRIM(CLM_ADJ_QTY116)
			+'~'+RTRIM(CLM_ADJ_GRP12)+'~'+RTRIM(CLM_ADJ_REASON121)+'~'+RTRIM(CLM_ADJ_AMT121)+'~'+RTRIM(CLM_ADJ_QTY121)+'~'+RTRIM(CLM_ADJ_REASON122)+'~'+RTRIM(CLM_ADJ_AMT122)+'~'+RTRIM(CLM_ADJ_QTY122)+'~'+RTRIM(CLM_ADJ_REASON123)+'~'+RTRIM(CLM_ADJ_AMT123)+'~'+RTRIM(CLM_ADJ_QTY123)
			+'~'+RTRIM(CLM_ADJ_REASON124)+'~'+RTRIM(CLM_ADJ_AMT124)+'~'+RTRIM(CLM_ADJ_QTY124)+'~'+RTRIM(CLM_ADJ_REASON125)+'~'+RTRIM(CLM_ADJ_AMT125)+'~'+RTRIM(CLM_ADJ_QTY125)+'~'+RTRIM(CLM_ADJ_REASON126)+'~'+RTRIM(CLM_ADJ_AMT126)+'~'+RTRIM(CLM_ADJ_QTY126)
			+'~'+RTRIM(CLM_ADJ_GRP13)+'~'+RTRIM(CLM_ADJ_REASON131)+'~'+RTRIM(CLM_ADJ_AMT131)+'~'+RTRIM(CLM_ADJ_QTY131)+'~'+RTRIM(CLM_ADJ_REASON132)+'~'+RTRIM(CLM_ADJ_AMT132)+'~'+RTRIM(CLM_ADJ_QTY132)+'~'+RTRIM(CLM_ADJ_REASON133)+'~'+RTRIM(CLM_ADJ_AMT133)+'~'+RTRIM(CLM_ADJ_QTY133)
			+'~'+RTRIM(CLM_ADJ_REASON134)+'~'+RTRIM(CLM_ADJ_AMT134)+'~'+RTRIM(CLM_ADJ_QTY134)+'~'+RTRIM(CLM_ADJ_REASON135)+'~'+RTRIM(CLM_ADJ_AMT135)+'~'+RTRIM(CLM_ADJ_QTY135)+'~'+RTRIM(CLM_ADJ_REASON136)+'~'+RTRIM(CLM_ADJ_AMT136)+'~'+RTRIM(CLM_ADJ_QTY136)
			+'~'+RTRIM(CLM_ADJ_GRP14)+'~'+RTRIM(CLM_ADJ_REASON141)+'~'+RTRIM(CLM_ADJ_AMT141)+'~'+RTRIM(CLM_ADJ_QTY141)+'~'+RTRIM(CLM_ADJ_REASON142)+'~'+RTRIM(CLM_ADJ_AMT142)+'~'+RTRIM(CLM_ADJ_QTY142)+'~'+RTRIM(CLM_ADJ_REASON143)+'~'+RTRIM(CLM_ADJ_AMT143)+'~'+RTRIM(CLM_ADJ_QTY143)
			+'~'+RTRIM(CLM_ADJ_REASON144)+'~'+RTRIM(CLM_ADJ_AMT144)+'~'+RTRIM(CLM_ADJ_QTY144)+'~'+RTRIM(CLM_ADJ_REASON145)+'~'+RTRIM(CLM_ADJ_AMT145)+'~'+RTRIM(CLM_ADJ_QTY145)+'~'+RTRIM(CLM_ADJ_REASON146)+'~'+RTRIM(CLM_ADJ_AMT146)+'~'+RTRIM(CLM_ADJ_QTY146)
			+'~'+RTRIM(CLM_ADJ_GRP15)+'~'+RTRIM(CLM_ADJ_REASON151)+'~'+RTRIM(CLM_ADJ_AMT151)+'~'+RTRIM(CLM_ADJ_QTY151)+'~'+RTRIM(CLM_ADJ_REASON152)+'~'+RTRIM(CLM_ADJ_AMT152)+'~'+RTRIM(CLM_ADJ_QTY152)+'~'+RTRIM(CLM_ADJ_REASON153)+'~'+RTRIM(CLM_ADJ_AMT153)+'~'+RTRIM(CLM_ADJ_QTY153)
			+'~'+RTRIM(CLM_ADJ_REASON154)+'~'+RTRIM(CLM_ADJ_AMT154)+'~'+RTRIM(CLM_ADJ_QTY154)+'~'+RTRIM(CLM_ADJ_REASON155)+'~'+RTRIM(CLM_ADJ_AMT155)+'~'+RTRIM(CLM_ADJ_QTY155)+'~'+RTRIM(CLM_ADJ_REASON156)+'~'+RTRIM(CLM_ADJ_AMT156)+'~'+RTRIM(CLM_ADJ_QTY156)
			+'~'+RTRIM(OTH_PAYER1_ADJ_DT)+'~'+replicate('~',1190)+''+RTRIM(OPTIONAL_RPT_IND1)+'~'+replicate('~',28)+' '+'^'
		FROM DBO.OUTB_PROF_DETAIL opd
		    JOIN #CLAIM_HCPE_IND  IND
	            ON IND.CLAIM_ID = OPD.CLAIM_ID
            JOIN #claim_ordinal co
                ON opd.CLAIM_ID = co.CLAIM_ID
	--		if @@ERROR <> 0
	--			begin
	--				rollback 
	--			end
	--COMMIT
	--BUILD HRP CLAIM RECORD TYPE S - CLAIM SUPPORT DOCUMENTATION
	--ASSIGN TO CLAIM HEADER AND CLAIM LINE
	/*BEGIN TRANSACTION
		INSERT INTO OUTB_PROF_MAP
		SELECT '4000',RTRIM(CLAIM_ID)+''+'9999'+'-'+'4000','S'+'~'+replicate('~',8)
		FROM DBO.OUTB_PROF_HEADER
			if @@ERROR <> 0
				begin
					rollback 
				end
	COMMIT*/
	--BUILD HRP CLAIM RECORD TYPE T - CLAIM TRAILOR
	
	
	
	--RESET PARAMETERS DUE TO CHKSUM VALIDATION
		BEGIN 
		--SET @SUM_TOTAL_CHARGES = 0;
		--SET @SUM_LINE_CHARGES = 0;
		SET @TOTAL_PROF_CLM = (SELECT COUNT(*) FROM OUTB_PROF_HEADER
					where CLAIM_TYPE = 'P');
		SET @TOTAL_DME_CLM = (SELECT COUNT(*) FROM OUTB_PROF_HEADER
					where CLAIM_TYPE = 'E');
		SET @TOTAL_PROF_CLM = @TOTAL_PROF_CLM + @TOTAL_DME_CLM
		SET @TOTAL_INST_CLM = (SELECT COUNT(*) FROM OUTB_PROF_HEADER
					where CLAIM_TYPE = 'I');
		SET @TOTAL_DENTAL_CLM = (SELECT COUNT(*) FROM OUTB_PROF_HEADER
					where CLAIM_TYPE = 'D');
		SET @TOTAL_LINES = (SELECT COUNT(*) FROM OUTB_PROF_DETAIL);
		SET @SUM_TOTAL_CHARGES = (SELECT SUM(convert(MONEY, LTRIM(TOT_CHRG_AMT))) FROM OUTB_PROF_HEADER);	
		SET @SUM_LINE_CHARGES = (SELECT SUM(convert(MONEY, LTRIM(TOTAL_CHRG_AMT))) FROM OUTB_PROF_DETAIL);				
		SET @TOTAL_EOF_COUNT = (SELECT COUNT(*) + 2 FROM OUTB_PROF_CLAIM_MAP);
		SET @FOOTER = ('T'+'~'+RTRIM(@FILEID)+'~'+RTRIM(CONVERT(CHAR,@TOTAL_PROF_CLM))+'~'+RTRIM(CONVERT(CHAR, @TOTAL_INST_CLM))+'~'+RTRIM(CONVERT(CHAR, @TOTAL_DENTAL_CLM))
				+'~'+RTRIM(CONVERT(CHAR, @TOTAL_LINES))+'~'+LTRIM(CONVERT(CHAR, @SUM_TOTAL_CHARGES))+'~'+LTRIM(CONVERT(CHAR, @SUM_LINE_CHARGES))
				+'~'+LTRIM(CONVERT(CHAR, @TOTAL_EOF_COUNT))+''+'^');
		SET @TOTAL_CLAIM = (SELECT COUNT(*) FROM OUTB_PROF_HEADER);		
		SET @FILEDESC   = (SELECT substring(SOURCEDESC,1,10) FROM SourceDataDim WHERE SourceDataKey = @SOURCEDATAKEY)+ '-'+ @CLAIMTYPE+ '-'+ RTRIM(@LOB);

		END
		
		IF @CLAIMTYPE = 'E'
		BEGIN
		SET @FOOTER = ('T'+'~'+RTRIM(@FILEID)+'~'+RTRIM(CONVERT(CHAR,@TOTAL_DME_CLM))+'~'+RTRIM(CONVERT(CHAR, @TOTAL_INST_CLM))+'~'+RTRIM(CONVERT(CHAR, @TOTAL_DENTAL_CLM))
				+'~'+RTRIM(CONVERT(CHAR, @TOTAL_LINES))+'~'+LTRIM(CONVERT(CHAR, @SUM_TOTAL_CHARGES))+'~'+LTRIM(CONVERT(CHAR, @SUM_LINE_CHARGES))
				+'~'+LTRIM(CONVERT(CHAR, @TOTAL_EOF_COUNT))+''+'^');
		END

		SET @TOTAL_CLAIM = (SELECT COUNT(*) FROM OUTB_PROF_HEADER);		
		SET @FILEDESC   = (SELECT substring(SOURCEDESC,1,10) FROM SourceDataDim WHERE SourceDataKey = @SOURCEDATAKEY)+ '-'+ @CLAIMTYPE+ '-'+ RTRIM(@LOB);

		--END
	
--build HRP CLAIM FILE HEADER
	--BEGIN TRANSACTION 
		 insert into OUTB_PROF_CLAIM_MAP
		  values('1000','0','H'+'~'+'1.0.0'
				+'~'+'Claim Encounter'
				+'~'+'1.0.0'
				+'~'+'Proprietary'
				+'~'+'Encounter'
				+'~'+'2.0.0'
				+'~'+@FILESUBTYPE
				+'~'+RTRIM(@FILEID)--'CLAIM'+''+RTRIM(@FILEID)
				+'~'+
				+'~'+@CREATEDT
				+'~'+@PRODUCTINDICATOR
				+'~'+'CIGNA-HSPR'
				+'~'+'CIGNA-HSPR'
				+'~'+@FILEDESC
				+'~'+--Line of Business
				+'~'+--State
				+'~'+--reserved
				+'~'+--reserved
				+'~'+--reserved
				+'~'+--reserved
				+'^')

		--			if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit	
		
		
		
	--BEGIN TRANSACTION
		INSERT INTO OUTB_PROF_CLAIM_MAP
		values('5000','ZZZZZZZZZ','T'+'~'+@FILEID/*'CLAIM'+''+RTRIM(@FILEID)*/+'~'+RTRIM(CONVERT(CHAR,@TOTAL_PROF_CLM))+'~'+RTRIM(CONVERT(CHAR, @TOTAL_INST_CLM))+'~'+RTRIM(CONVERT(CHAR, @TOTAL_DENTAL_CLM))
				+'~'+RTRIM(CONVERT(CHAR, @TOTAL_LINES))+'~'+lTRIM(CONVERT(CHAR, @SUM_TOTAL_CHARGES))+'~'+lTRIM(CONVERT(CHAR, @SUM_LINE_CHARGES))
				+'~'+lTRIM(CONVERT(CHAR, @TOTAL_EOF_COUNT))+''+'^') 
	--	if @@ERROR <> 0
	--			begin
	--				rollback 
	--			end
	--COMMIT

	------------------------------------------------------------------------------------------------------------
	--
	--		----- HRP MAP AUDITING
	--		----- COUNT TOTAL DELIMITERS '~' FOR EACH SEGEMENT OF FILE
	--
	------------------------------------------------------------------------------------------------------------
		BEGIN
				SET @HEADER_CNTRL = (select  distinct dbo.countrecorddelimter(datarow,'~') from OUTB_PROF_CLAIM_MAP Where RECORDTYPEID = '1000');
				SET @FOOTER_CNTRL = (select  distinct dbo.countrecorddelimter(datarow,'~') from OUTB_PROF_CLAIM_MAP Where RECORDTYPEID = '5000');
				SET @RECHEADER_CNTRL = (select  distinct dbo.countrecorddelimter(datarow,'~') from OUTB_PROF_CLAIM_MAP Where RECORDTYPEID = '2000');
				SET @RECDTL_CNTRL = (select  distinct dbo.countrecorddelimter(datarow,'~') from OUTB_PROF_CLAIM_MAP Where RECORDTYPEID = '3000');
				SET @RECOTH_CNTRL = (select  distinct dbo.countrecorddelimter(datarow,'~') from OUTB_PROF_CLAIM_MAP Where RECORDTYPEID = '4000');
				SET @FILE_TYPE = 'Claim Encounter';
				SET @VERSION = '2.0.0';
				
		END



	--CREATE EXT_HRP_MAP_HIST 
	--RETRIEVE FILE HEADER INFORMATION
	--BEGIN TRANSACTION
				INSERT INTO OUTB_FILE_HIST
				SELECT	@FILEID,GETDATE(),NULL,RTRIM(DATAROW),NULL,GETDATE(),@HEADER_CNTRL
						,@FOOTER_CNTRL,@RECHEADER_CNTRL,@RECDTL_CNTRL,@RECOTH_CNTRL,@FILE_TYPE,@VERSION
						,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL
						,NULL,NULL,NULL,NULL,@TOTAL_CLAIM,@SOURCEDATAKEY,NULL,NULL,NULL,rtrim(@FILEDESC)+'-' + 'JobId' + '-' + convert(char,(@JOBID))
				FROM OUTB_PROF_CLAIM_MAP
				WHERE RECORDTYPEID = '1000'
	--			if @@ERROR <> 0
	--			begin
	--				rollback 
	--			end
	--COMMIT
	--UPDATE FILE FOOTER INFORMATION
	--BEGIN TRANSACTION 
				UPDATE OUTB_FILE_HIST
				SET FILEFOOTER = @FOOTER
				WHERE RTRIM(FILEHEADER) IN (SELECT RTRIM(DATAROW)
						FROM OUTB_PROF_CLAIM_MAP
						WHERE RECORDTYPEID =  '1000')
	--			if @@ERROR <> 0
	--			begin
	--				rollback 
	--			end
	--COMMIT
	--APPEND ALL CLAIMS TO OUTB_PROF_HEADER_STATUS TABLE FOR CLAIM LEVEL STATUS TRACKING
	--BEGIN TRANSACTION 
				INSERT INTO OUTB_CLAIM_STATUS
				SELECT CLAIM_ID,CLAIM_TYPE,@FILEID,CLM_IND,SOURCEDATAKEY,MEMBER_ID
						,HICN_NUM,BILL_PROV_GRP_ID,BILL_PROV_ID,REF_PROV_ID,REF_PCP_PROV_ID
						,ATTN_PROV_ID,NULL,NULL,NULL,NULL,NULL
						,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,@CREATEDT,GETDATE(),SUBSTRING(SERV_DT,1,6)
						,NULL,NULL,NULL
				FROM OUTB_PROF_HEADER
				--WHERE @FILEID NOT IN (SELECT DISTINCT FILEID FROM OUTB_PROF_HEADER_STATUS)	
	--			if @@ERROR <> 0
	--			begin
	--				rollback 
	--			end
	--COMMIT
	end

		--Append file history 

				execute pr_ClaimProfessionalExtractHistoryInsert @FILEID
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_PROF_HEADER_RESEND
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_CLAIM_MAP)
		----HRP_CLAIM_FILE Update Run Controls
				--BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_PROF_ENCOUNTER_MAP'
								AND END_DT IS NULL