﻿
CREATE PROCEDURE [dbo].[Retraction_Diag_Overlay_Build_Encounters]
AS
/***************************************************************************************************
** CREATE DATE: 01/25/2003
**
** AUTHOR: Aaron Ridley
**
** DESCRIPTION: This procedure has been created to read the Adhoc Input Tracking table, housing requested retractions.
**              Diagnosis Codes that are not present in this table are written to newly created DiagnosisCode Overlay tables.
**              The Diagnosis Code overlay tables will subsequently be utilized in place of the source EDPS_Data Diag tables for 
**              Retraction data submission.
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------*/
	--DECLARE VARIABLES

			DECLARE
			
			@TOTAL_RECORDS INT
		


--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('Retraction_Diag_Overlay_Build_Encounters'
				,'1'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)

/*----------------------------------------------------------------------------------------------
              Temporary Table Preparation 
*/----------------------------------------------------------------------------------------------

IF OBJECT_ID('tempdb.dbo.#clm_diag_detail_dim_working') IS NOT NULL
	DROP TABLE #clm_diag_detail_dim_working;

IF OBJECT_ID('tempdb.dbo.#clm_diag_detail_dim_final') IS NOT NULL
	DROP TABLE #clm_diag_detail_dim_final;

IF OBJECT_ID('tempdb.dbo.#clm_diag_detail_dim_final') IS NOT NULL
	DROP TABLE #clm_diag_detail_dim_final;


/*----------------------------------------------------------------------------------------------
   Identify Encounter Claims needing for the DiagOverlay creation updating initial working temp table   
*/----------------------------------------------------------------------------------------------


SELECT DISTINCT  
    ClaimNum = ecd.ClaimNum,
	ClaimLineNum = ecd.ClaimLineNum,
    MemberID = ecd.MemberID,
    EndServiceDateKey = TRY_CAST(TRY_CAST(ecd.EndServiceDateKey AS VARCHAR(8)) AS DATE),
    DX_Code_Ecd = NULLIF(REPLACE(X.Dx_Code,'.',''),''),
	DIAG_VERSION = ecd.DiagQual1,
    ProviderID = ecd.ProviderID,
	Derived_SEQUENCE = ROW_NUMBER() OVER (PARTITION BY CLAIMNUM, CLAIMLINENUM ORDER BY CLAIMNUM, CLAIMLINENUM) -- CAST(c.SEQUENCE AS INT))
into #clm_diag_detail_dim_working
FROM EDPS_Data.dbo.EncounterClaimDim ecd
INNER JOIN WIPRO.dbo.Adhoc_Input_Tracking ait ON ecd.ClaimNum = ait.Claim_id 
CROSS APPLY(
VALUES    (ecd.DX1),
        (ecd.DX2),
        (ecd.DX3),
        (ecd.DX4),
        (ecd.DX5),
        (ecd.DX6),
        (ecd.DX7),
        (ecd.DX8),
        (ecd.DX9),
        (ecd.DX10)) X(Dx_Code)
WHERE 1 = 1
AND X.Dx_Code <> ''
  
/*----------------------------------------------------------------------------------------------
   Use Final Temp table to create the temp table containing the final Diagnosis code sequencing 
*/----------------------------------------------------------------------------------------------

	select 
	ClaimNum 
	,ClaimLineNum  
    ,MemberID  
    ,EndServiceDateKey  
    ,DX_Code_Ecd  
	,DIAG_VERSION
    ,ProviderID 
	,Derived_SEQUENCE
	,New_SEQUENCE = ROW_NUMBER() OVER (PARTITION BY ClaimNum, ClaimLineNum ORDER BY CAST(c.Derived_SEQUENCE AS INT))
	into #clm_diag_detail_dim_final
	from #clm_diag_detail_dim_working c
		WHERE 1 = 1
		AND NOT EXISTS (	SELECT 
							* 
							FROM  WIPRO.dbo.Adhoc_Input_Tracking ait
							WHERE 1 = 1
								AND ait.CLAIM_ID = c.ClaimNum
								AND ait.DIAGNOSIS_CODE = c.DX_Code_Ecd)
ORDER BY ClaimNum, CAST(ClaimLineNum AS INT), Derived_SEQUENCE;

/*----------------------------------------------------------------------------------------------
   Insert Final Records into the Encounter Overlay table in same format as initial EncounterClaimDim data
*/----------------------------------------------------------------------------------------------


INSERT INTO WIPRO.dbo.encounterclaimdim_Overlay
SELECT distinct
 [EncounterClaimKey]
      ,a.[ProviderID]
      ,[ReferringProviderID]
      ,a.[MemberID]
      ,[MedicareID]
      ,[PCPID]
      ,[PCPLastName]
      ,[PCPFirstName]
      ,[PCPMiddleName]
      ,a.[ClaimNum]
      ,[ProvTaxonomyCode]
      ,[ProvSpecialtyCode]
      ,[BillTypeCode]
      ,[DateReceivedKey]
      ,[DateEnteredKey]
      ,[AdmissionTypeCode]
      ,[AdmissionSourceCode]
      ,[DischargeStatusCode]
      ,[BeginServiceDateKey]
      ,a.[EndServiceDateKey]
      ,[PaidDateKey]
      ,[ReversedClaimNum]
      ,[Quantity]
      ,[DeniedServiceQuantity]
      ,[PlaceOfServiceCode]
      ,[RequestedAmt]
      ,[EligibleFeeAmt]
      ,[CoPayAmt]
      ,[CoInsuranceAmt]
      ,[DeductibleAmt]
      ,[COBAmt]
      ,[PaidAmt]
      ,[WithholdAmt]
      ,[MaxFeeAmt]
      ,[AdmissionDateKey]
      ,[AdmissionDiagnosisTypeCode]
      ,[ProcedureCode]
      ,[ModifierCode1]
      ,[ModifierCode2]
      ,[ModifierCode3]
      ,[ModifierCode4]
      ,[FederalTaxID]
      ,[VendorID]
      ,[VendorLastName]
      ,[VendorFirstName]
      ,[AdjustmentCode]
      ,[CheckNum]
      ,[RevenueCode]
      ,[DeniedReasonCode]
      ,[ICD9ProcedureCode1]
      ,[ICD9ProcedureDateKey1]
      ,[ICD9ProcedureCode2]
      ,[ICD9ProcedureDateKey2]
      ,[ICD9ProcedureCode3]
      ,[ICD9ProcedureDateKey3]
      ,[AuthorizationID]
      ,a.[ClaimLineNum]
      ,[DX1]
      ,[DiagQual1]
      ,[DX2]
      ,[DiagQual2]
      ,[DX3]
      ,[DiagQual3]
      ,[DX4]
      ,[DiagQual4]
      ,[DX5]
      ,[DiagQual5]
      ,[DX6]
      ,[DiagQual6]
      ,[DX7]
      ,[DiagQual7]
      ,[DX8]
      ,[DiagQual8]
      ,[DX9]
      ,[DiagQual9]
      ,[DX10]
      ,[DiagQual10]
      ,[TaxonomyCode]
      ,[ClaimLineStatus]
      ,[FileName]
      ,[SourceDesc]
      ,[SourceDataKey]
      ,[Active]
      ,[Deleted]
      ,[LoadDateKey]
      ,[EnterpriseID]
      ,[ClaimType]
      ,[InpatientInd]
      ,[ClaimFrequencyCode]
FROM EDPS_DATA.dbo.encounterclaimdim a
inner join #clm_diag_detail_dim_final b on a.ClaimNum = b.ClaimNum and a.ClaimLineNum = b.ClaimLineNum

/*----------------------------------------------------------------------------------------------
   Start Diagnosis code updates to accommodate resequencing 
*/----------------------------------------------------------------------------------------------

UPDATE a
SET DX1 = '',
	DiagQual1 = '',
	DX2 = '',
	DiagQual2 = '',
	DX3 = '',
	DiagQual3 = '',
	DX4 = '',
	DiagQual4 = '',
	DX5 = '',
	DiagQual5 = '',
	DX6 = '',
	DiagQual6 = '',
	DX7 = '',
	DiagQual7 = '',
	DX8 = '',
	DiagQual8 = '',
	DX9 = '',
	DiagQual9 = '',
	DX10 = '',
	DiagQual10 = ''
 from WIPRO.dbo.encounterclaimdim_Overlay a



UPDATE  a 
SET DX1 = DX_Code_Ecd,
    DiagQual1 = DIAG_VERSION 
FROM WIPRO.dbo.encounterclaimdim_Overlay a
INNER JOiN  #clm_diag_detail_dim_final b on a.claimnum = b.claimnum and a.claimlinenum = b.claimlinenum
where b.New_SEQUENCE = '1' 

UPDATE  a 
SET DX2 = DX_Code_Ecd,
    DiagQual2 = DIAG_VERSION
FROM WIPRO.dbo.encounterclaimdim_Overlay a
INNER JOiN  #clm_diag_detail_dim_final b on a.claimnum = b.claimnum and a.claimlinenum = b.claimlinenum
where b.New_SEQUENCE = '2' 

UPDATE  a 
SET DX3 = DX_Code_Ecd,
	DiagQual3 = DIAG_VERSION
FROM WIPRO.dbo.encounterclaimdim_Overlay a
INNER JOiN  #clm_diag_detail_dim_final b on a.claimnum = b.claimnum and a.claimlinenum = b.claimlinenum
where b.New_SEQUENCE = '3' 

UPDATE  a 
SET DX4 = DX_Code_Ecd,
	DiagQual4 = DIAG_VERSION
FROM WIPRO.dbo.encounterclaimdim_Overlay a
INNER JOiN  #clm_diag_detail_dim_final b on a.claimnum = b.claimnum and a.claimlinenum = b.claimlinenum
where b.New_SEQUENCE = '4' 

UPDATE  a 
SET DX5 = DX_Code_Ecd,
	DiagQual5 = DIAG_VERSION
FROM WIPRO.dbo.encounterclaimdim_Overlay a
INNER JOiN  #clm_diag_detail_dim_final b on a.claimnum = b.claimnum and a.claimlinenum = b.claimlinenum
where b.New_SEQUENCE = '5' 


UPDATE  a 
SET DX6 = DX_Code_Ecd,
	DiagQual6 = DIAG_VERSION
FROM WIPRO.dbo.encounterclaimdim_Overlay a
INNER JOiN  #clm_diag_detail_dim_final b on a.claimnum = b.claimnum and a.claimlinenum = b.claimlinenum
where b.New_SEQUENCE = '6' 


UPDATE  a 
SET DX7 = DX_Code_Ecd,
	DiagQual7 = DIAG_VERSION
FROM WIPRO.dbo.encounterclaimdim_Overlay a
INNER JOiN  #clm_diag_detail_dim_final b on a.claimnum = b.claimnum and a.claimlinenum = b.claimlinenum
where b.New_SEQUENCE = '7'


UPDATE  a 
SET DX8 = DX_Code_Ecd,
	DiagQual8 = DIAG_VERSION
FROM WIPRO.dbo.encounterclaimdim_Overlay a
INNER JOiN  #clm_diag_detail_dim_final b on a.claimnum = b.claimnum and a.claimlinenum = b.claimlinenum
where b.New_SEQUENCE = '8'


UPDATE  a 
SET DX9 = DX_Code_Ecd,
	DiagQual9 = DIAG_VERSION
FROM WIPRO.dbo.encounterclaimdim_Overlay a
INNER JOiN  #clm_diag_detail_dim_final b on a.claimnum = b.claimnum and a.claimlinenum = b.claimlinenum
where b.New_SEQUENCE = '9'  


UPDATE  a 
SET DX10 = DX_Code_Ecd,
	DiagQual10 = DIAG_VERSION
FROM WIPRO.dbo.encounterclaimdim_Overlay a
INNER JOiN  #clm_diag_detail_dim_final b on a.claimnum = b.claimnum and a.claimlinenum = b.claimlinenum
where b.New_SEQUENCE = '10'  


 /*---------------------------------------------------------------------------------
 *   Post Detail Diagnosis table Syslog Updates 
 */---------------------------------------------------------------------------------

 SET @TOTAL_RECORDS = (SELECT COUNT(DISTINCT(claimnum)) FROM #clm_diag_detail_dim_final);

 UPDATE EXT_SYS_RUNLOG
SET END_DT = GETDATE()	
	,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
	,ENTRYDT = GETDATE()
WHERE PROC_NAME = 'Retraction_Diag_Overlay_Build_Encounters'
		AND END_DT IS NULL;