﻿






CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_PROF_CLAIM_HEADER_MMAI_IMP]
(
	@ExecutionMode		CHAR(1) = 'M'
	--
	--	NOTE:	Pass in 'A' for new "automated" execution
	--			Default is [M]anual mode...
	--
)

AS
/***************************************************************************************************
** CREATE DATE: 01/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
2012-10-19		Dwight Staggs	Remove database name from table references
2012-10-24		Loyal Ricks		Add Exclusion table logic (build and selection into OUTB_PROF_HEADER)
2012-10-24		Loyal Ricks		replace ##TMP_ with ##TMPDEV_ in order to support use of tempdb
2012-10-24		Loyal Ricks		between EDPS and EDPS_PROD databases.
2012-10-24		Loyal Ricks	    remove update, mapping rules change do not include CMS_CONTRACT_NUM
2013-02-08		Loyal Ricks		INVALID CHARACTER MEMBER RECORD PARSE
2013-03-06		Loyal Ricks		Remove DOS claim selection criteria
								Remove input parms
2013-04-25		Loyal Ricks		Add parsing logic for member address to, set '***' to ' '      
2013-04-30		Loyal Ricks		Remap default code for OTH_INSR_TYPECD1 to CLM_FIL_INDCD1 
								Due to CMS 999 rejection issue. 
2013-05-09		Loyal Ricks		Add Rendering Provider 
								Reject 103 adjustment - Remove cd.MemberPaidAmt from claim header. 
								When populated this data element is causing balance issues between
								claim header and claim line.
								scrub cd.pcpid when 'UNKNOWN' SET TO ' '	
2013-07-24		Dwight Staggs	Use new dbo.EDS_ClaimExtractParams and dbo.EDS_AllExtractClaims tables
								in SSIS package to pull all available claims for each source
2013-09-18		Dwight Staggs	Added @ExecutionMode input parameter for backward compatibility.  The
								default of 'M' executes the same as previously:
									1.	#tmplob table is created
									2.	The claims inserted into #ELIG_CLM are pulled directly from
										dbo.ClaimDim, JOINed to #tmplob
									3.	# of claims extracted is hard-codeded in this SP
								When set to 'A':
									1.	The claims inserted into #ELIG_CLM are pulled from dbo.EDS_AllExtractClaims,
										which is populated in the SSIS package before this SP is executed
									2.	The number of claims to be extracted is obtained from the 
									    EDS_ClaimExtractParams table for the appropriate SourceDataKey
2013-10-29		Dwight Staggs	For manual option, use ManualMaxClaimsPerFile in param table and eliminate 
								hardcoded value in this SP 	
2013-10-31		Loyal Ricks		PAYER_CLAIM_CNTRL_NUM - Revise logic to set this value to blank instead of 1 
								when BIDW defaults are assigned. REquired to support new Verisk edit 
								check on this data element.   
2014-01-22		Loyal Ricks		Add additional data scrub for Member Middle Name & Member Zip4	
2014-02-04		Loyal Ricks		Remove individual data element Invalid EDI parse and replace with function 
								dbo.fn_edi_parse.
2014-02-07		Loyal Ricks		Remove MDQOLib references (Memberdim, Lineofbusinessdim)
2014-02-11		Loyal Ricks		Additional invalid EDI character parsing - member first & last name	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation
2014-07-31		Loyal Ricks		Added Qualifier Codes (Principal, Institutional Visit, Daig Code) and 
								logic for updating appropriate codes for this sp.		
2014-08-22		Loyal Ricks		Revise claim selection process to use MMAIClaimDetailDim as source 
								for all eligible outbound claim selections. 	
								Add hard code value for LOB - Remove logic post production once 
								BIDW.LineofBusinessDim MMAI revisions are implmented.																				    
*****************************************************************************************************/			

	SET NOCOUNT ON;
	
	DECLARE @CatchErrorMessage VARCHAR(2200);
	DECLARE	@TOTAL_RECORDS INT,
			@ExtractCount INT



	IF OBJECT_ID('TEMPDB..#ELIG_CLM') <> 0
		DROP TABLE #ELIG_CLM
	
	CREATE TABLE #ELIG_CLM
	(
		ClaimID		VARCHAR(20)
	)
	
	IF OBJECT_ID('TEMPDB..#TMPDEV_HPLAN') <> 0
		DROP TABLE #TMPDEV_HPLAN

	CREATE TABLE #TMPDEV_HPLAN
	(
		ClaimId			VARCHAR(20),
		LOBCode			VARCHAR(15),
		HCFACode		VARCHAR(5)
	)

	IF OBJECT_ID('TEMPDB..#tmplob') <> 0
		DROP TABLE #tmplob

	CREATE TABLE #tmplob
	(
		LOBCode			VARCHAR(15)
	)

	IF OBJECT_ID('TEMPDB..#MMAI_MEDICARE') <> 0
		DROP TABLE #MMAI_MEDICARE

	CREATE TABLE #MMAI_MEDICARE
	(
		ClaimId			VARCHAR(50)
	)

	IF OBJECT_ID('TEMPDB..#MMAI_MEDICAID') <> 0
		DROP TABLE #MMAI_MEDICAID

	CREATE TABLE #MMAI_MEDICAID
	(
		ClaimId			VARCHAR(50)
	)

BEGIN TRY

--	Init Run controls
	INSERT INTO EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT
			)
			VALUES('pr_BUILD_OUTB_PROF_HEADER'
					,'2'
					,GETDATE()
					,NULL
					,NULL
					,0
					,GETDATE()
					)
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH
				
BEGIN TRY
	--
	--	Backward compatibility mode....
	--
	IF @ExecutionMode <> 'A'
	BEGIN
--
--	Added 10-29-2013 to use ManualMaxClaimsPerFile in param table and eliminate hardcoded value in this SP
--
		SELECT 
			@ExtractCount = ManualMaxClaimsPerFile
		FROM
			dbo.EDS_ClaimExtractParams	
		WHERE
			SourceDataKey = 50
			
		INSERT INTO 
			#tmplob
		( 
			LOBCode
		)
		SELECT
			LOBCode
		FROM
			MDQOLib.dbo.LineofBusinessDim
		WHERE	
			ProductType = 'Other'
		AND HCFACode = 'H6751'
		AND Active = 1
		ORDER BY LOBCode
		
		INSERT INTO
			#MMAI_MEDICARE
		( 
			ClaimID
		)
		SELECT DISTINCT ClaimID
--			TOP 100000 ClaimID		--	<--  Change value here for Manual mode...
		--TOP(@ExtractCount) ClaimID
		FROM 
			dbo.MMAIClaimDetailDim
		WHERE 
			UPPER(claimproducttype) = ('MEDICARE')
			AND charindex('R',claimid) = 0
			AND charindex('A',claimid) = 0
			AND ACTIVE = 1
			and SOURCEDATAKEY = '50'
			--AND FormTypeCode = 'H'
			--AND DeniedFlag = 0
			--AND SUBSTRING(CLAIMID,12,1) NOT IN ('A','R')
			AND LOBCODE IN (SELECT LOBCODE from #tmplob)
			AND CLAIMID NOT IN (SELECT DISTINCT CLAIM_ID FROM EXT_CLAIM_EXCLUSION)

			--Remove all Non Medicare and Dual Claims

			--Remove Unknown Claims 

			Begin Transaction 
				delete 
				from #MMAI_MEDICARE
				WHERE CLAIMID IN (SELECT CLAIMID FROM MMAIClaimDetailDim where UPPER(claimproducttype) = 'UNKNOWN')
			IF @@ERROR <> 0
				BEGIN 
					ROLLBACK 
				END
			COMMIT

			INSERT INTO
			#MMAI_MEDICAID
		( 
			ClaimID
		)
							SELECT CLAIMID 
							FROM MMAIClaimDetailDim
							where (claimproducttype) = 'MEDICAID'
							GROUP BY CLAIMID 
							HAVING COUNT(CLAIMID) = 1
							ORDER BY CLAIMID

			Begin Transaction 
				delete 
				from #MMAI_MEDICARE
				WHERE CLAIMID IN (SELECT CLAIMID FROM #MMAI_MEDICAID)

				IF @@ERROR <> 0
					BEGIN 
						ROLLBACK 
					END
			COMMIT
		INSERT INTO
			#ELIG_CLM
		( 
			ClaimID
		)
		
		SELECT 
			 TOP(@ExtractCount) ClaimID
			FROM #MMAI_MEDICARE
	END
	
	ELSE
	
	BEGIN	
		--
		--	Automated mode...
		--
		SELECT
			@ExtractCount = MaxClaimsPerFile
		FROM
			dbo.EDS_ClaimExtractParams	
		WHERE
			SourceDataKey = 50

		INSERT INTO
			#ELIG_CLM
		( 
			ClaimID
		)
		SELECT
			TOP(@ExtractCount) ClaimID
		FROM
			dbo.EDS_AllExtractClaims
		WHERE	
			SOURCEDATAKEY = 50
	END
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY
	--
	--	Build Claim Headers 
	--

	TRUNCATE TABLE OUTB_PROF_HEADER
	TRUNCATE TABLE OUTB_PROF_DETAIL


	BEGIN TRANSACTION 
	INSERT INTO 
		dbo.OUTB_PROF_HEADER
	SELECT  DISTINCT
		'C'
		,case cd.formtypecode when 'H' then 'P'
			when 'U' then 'I'
			else cd.formtypecode
		end
		,'EDPS-QNXT'
		,' '--cd.sourcedatakey--CMS_CONTRACT_NUM
		,mb.MEDICAREID
		,cd.claimid
		,substring(cd.PatientID,1,20)
		,REPLACE(cd.MemberID,'*','-')
		,dbo.fn_edi_parse(mb.lastname)
		,dbo.fn_edi_parse(mb.firstname)
		,CASE dbo.fn_edi_parse(mb.middlename) 
			WHEN 'UNKNOWN' THEN ' '
			ELSE dbo.fn_edi_parse(mb.middlename)
		 END
		,' '--MEMBER_SFX
		,dbo.fn_edi_parse(substring(mb.AddressLine1,1,55))
		,CASE dbo.fn_edi_parse(substring(mb.AddressLine2,1,55))
			WHEN 'UNKNOWN' THEN ' '
			when '***' then ' '                                                    
			ELSE dbo.fn_edi_parse(substring(mb.AddressLine2,1,55))
		 END
		,mb.City
		,mb.State
		,CASE substring(mb.Zip,1,5) WHEN 'UNKNO' THEN '99999' ELSE SUBSTRING(mb.Zip,1,5) END
		,substring(mb.Zip,6,4) 
		,' '--MEMBER_CTY
		,' '--MEMBER_CTRY
		,' '--MEMBER_CTRY_SUBD
		,REPLACE(cd.GroupID,'*','-')
		,case cd.formtypecode 
			when 'H' then '14'
			else ' '
		end
		,mb.DOBDateKey
		,mb.Gender
		,CASE mb.SSN WHEN 'UNKNOWN' THEN ' ' ELSE mb.SSN END
		,' '--POS
		,' '--INST_PRINCIPAL_DIAG_CD
		,' '--INST_PRINCIPAL_POA_CD
		,' '--INST_ADM_DIGA_CD
		,' '--DIAG_CD1
		,' '--POA_IND1
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--DIAG_CD20
		,' '--POA_IND20
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--DIAG_CD30
		,' '--POA_IND30
		,' '--BILL_PROV_NPI
		,cd.PCPVendor
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--BILL_PROV_LICENSE_NO
		,cd.PCPVendor
		,case cd.PayToVendorOrFamilyFlag 
			when 'V' then '1'
			else ' '
		end
		,' '--PAYTO_ADDR1
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,'P'--PAYER_RESP
		,ltrim(cd.ClaimBilledAmt)
		,' '--ltrim(cd.MemberPaidAmt)
		,' '
		,CASE cd.PreviousClaimID WHEN 'N/A' THEN '1'  when 'UNKNOWN' THEN '1' ELSE '7' END
		,'C'--PROV_ASSGN_IND
		,'Y'--INSR_BEN_ASSGN_IND
		,' '
		,' '
		,' '
		,case cd.admissiondatekey when '-1' then ' ' when '0' then ' ' else cd.AdmissionDateKey end
		,' '
		,' '
		,' '
		,case cd.dischargedatekey when '-1' then ' '  when '0' then ' ' else cd.DischargeDateKey end
		,' '
		,CASE cd.DispositionCode WHEN 'N/A' THEN ' ' WHEN '--' THEN ' ' ELSE cd.DispositionCode END
		,CASE replace(cd.AuthorizationID,'*','-') WHEN 'UNKNOWN' THEN ' ' ELSE replace(cd.AuthorizationID,'*','-')  END
		,' '--CPO_NPI
		,' '--PRICE_METHOD
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--REF_PROV_UPIN
		,CASE cd.ReferringPhysicianID WHEN 'UNKNOWN' THEN ' ' ELSE cd.ReferringPhysicianID END
		,' '--REF_PCP_LNAME
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--REF_PCP_PROV_UPIN
		,case cd.PCPID WHEN 'UNKNOWN' THEN ' ' ELSE cd.PCPID end
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--ATTN_PROV_LOC_NO
		,CASE cd.AttendingPhysicianID WHEN 'UNKNOWN' THEN ' ' ELSE cd.AttendingPhysicianID END
		,' '--ATTN_PROV_LICENSE_NO
		,' '--EMER_FLAG
		,' '--PROD_DESC
		,' '--ANES_FLAG
		,'P'--PAYER_RESP1 default values for CMS COB
		,'18'--REL_CD1 default values for CMS COB
		,' '--OTH_INSR_GRPNO1 CHAR(50),
		,'HealthSpring'--OTH_INSR_GRPNAME CHAR(60),
		,' '--OTH_INSR_TYPECD1 CHAR(10),
		,'16'--CLM_FIL_INDCD1 CHAR(10),
		,' '--CLM_ADJ_GRP_TYPE1 CHAR(2),
		,' '--CLM_ADJ_REA_CD1 CHAR(5),
		,' '--SUM(CD.CLAIMBILLEDAMT - cd.TotalPaid)--CLM_ADJ_AMT1 CHAR(18),
		,' '--CLM_ADJ_UNIT1 CHAR(18)
		,ltrim(cd.TotalPaid)
		,' '--cd.MHCFinancialDateKey--USE CLAIMAGG PAYDATEKEY WHICH IS 
		,' '--ltrim(cd.MemberPaidAmt)
		,' '
		,'HealthSpring'--OTHER PAYER 1 NAME
		,' '---OTHER PAYER1 PLAN ID
		,'530 GREAT CIRCLE' --OTHER PAYER1 ADDRESS
		,' '  --OTHER PAYER1 ADDRESS2
		,'NASHVILLE'--OTHER PAYER1 CITY
		,'TN' --OTHER PAYER1 STATE
		,'37228'--OTH PAYER1 ZIP
		,'9999' -- OTHER PAYER1 ZIP4
		,' '--cd.MHCFinancialDateKey
		,cd.sourcedatakey
		,'Y'--PROV_SIGNATURE_FLAG
		,'Y'--REL_OF_INFO_FLAG
		,'Y'--ASSIGN_BEN_IND1
		,CASE cd.PreviousClaimID WHEN 'N/A' THEN ' ' when 'UNKNOWN' THEN ' ' ELSE cd.PreviousClaimID END
		,' '--OPTIONAL REPORTING INDICATOR
		,' '--rendoring provider 
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--rendering prov taxonomy
		,' '--rendering provider org name
		,' '--rendering provider group id
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
	from 
		EDPS_DATA.dbo.claimdim					cd
	INNER JOIN
		MDQOLib.dbo.MemberDim			mb
		ON cd.SOURCEDATAKEY = mb.SourceDataKey
		AND cd.MEMBERID = mb.MemberID
	INNER JOIN
		#ELIG_CLM						e
		ON cd.CLAIMID = e.ClaimID
	WHERE
		cd.FormTypeCode = 'H'
		AND cd.SOURCEDATAKEY = 50

	COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY
	--UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO
	INSERT INTO 
		#TMPDEV_HPLAN
	(
		ClaimId, 
		LOBCode, 
		HCFACode
	)
	 SELECT 
		CD.CLAIMID,
		CD.LOBCODE,
		L.HCFACODE
	 FROM 
		OUTB_PROF_HEADER					C
	INNER JOIN
		EDPS_DATA.dbo.CLAIMDIM					CD
		ON C.SOURCEDATAKEY = CD.SOURCEDATAKEY
		AND C.CLAIM_ID = CD.CLAIMID
	INNER JOIN
		MDQOLib.dbo.LineofBusinessDim	L
		ON CD.SOURCEDATAKEY = L.SourceDataKey
		AND	CD.LOBCODE = L.LOBCode


	BEGIN TRANSACTION 
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			 CMS_CONTRACT_NUM = T.HCFACode
			,OTH_PAYER1_PLANID = T.HCFACode
		FROM 
			OUTB_PROF_HEADER C
		INNER JOIN
			#TMPDEV_HPLAN T	
			ON C.CLAIM_ID = T.CLAIMID
		
	COMMIT TRANSACTION
	
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	


BEGIN TRY	
	--
	--	Update PAYER1_PAID_DT from ClaimAgg
	--
	BEGIN TRANSACTION
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			PAYER1_PAID_DT = CA.PaidDateKey
		FROM 
			OUTB_PROF_HEADER			HC
		INNER JOIN
			EDPS_DATA.dbo.CLAIMAGG			CA
		ON 
			HC.SOURCEDATAKEY = CA.SOURCEDATAKEY
			AND HC.CLAIM_ID = CA.CLAIMID

		COMMIT TRANSACTION
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY
	--
	--	Update ADM_DT and DISCHRG_DT to '' when 0...
	--
 
		UPDATE OUTB_PROF_HEADER
		SET ADM_DT = ''
		WHERE ADM_DT = '0'


		UPDATE OUTB_PROF_HEADER
		SET DISCHRG_DT = ''
		WHERE DISCHRG_DT = '0'


END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY
	--UPDATE PROFESSIONAL CLAIM PLACE OF SERVICE
	BEGIN TRANSACTION
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			POS = cd.ServicePlaceCode
		FROM 
			OUTB_PROF_HEADER			E
		INNER JOIN
			EDPS_DATA.dbo.CLAIMDETAILDIM		CD
			ON E.SOURCEDATAKEY = CD.SOURCEDATAKEY
			AND E.CLAIM_ID = CD.CLAIMID
		WHERE
			E.CLAIM_TYPE = 'P'
					
	COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	


BEGIN TRY
	--UPDATE INSTITUTIONAL CLAIM PLACE OF SERVICE
	BEGIN TRANSACTION
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			POS = UA.billtypecode
		FROM 
			OUTB_PROF_HEADER			E
		INNER JOIN
			EDPS_DATA.dbo.UB921ADMISSIONDIM	UA
			ON E.SOURCEDATAKEY = UA.SourceDataKey
			AND E.CLAIM_ID = UA.claimid
		WHERE
			E.CLAIM_TYPE = 'I'	

	COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	


BEGIN TRY
	--UPDATE INST_PRINCIPAL_DIAG_CD
	BEGIN TRANSACTION
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			INST_PRINCIPAL_DIAG_CD = replace(CDD.DIAGNOSISCODE,'.',''),
			INST_PRINCIPAL_POA_CD = CASE CDD.POAind WHEN 'Y' THEN 'Y' ELSE 'N' END,
			PRINCIPAL_DIAG_QUAL = 'BK'
		FROM 
			OUTB_PROF_HEADER				E
		INNER JOIN	
			EDPS_DATA.dbo.CLAIMDIAGNOSISDIM		CDD
			ON E.SOURCEDATAKEY = CDD.SourceDataKey
			AND E.CLAIM_ID = CDD.CLAIMID
			AND CDD.DIAGNOSISTYPECODE = 'P'
	
	COMMIT TRANSACTION
	

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY
		--UPDATE SERVICE DATE
	BEGIN TRANSACTION 
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			SERV_DT = BeginServiceDateKey
		FROM 
			OUTB_PROF_HEADER					E
		INNER JOIN
			EDPS_DATA.dbo.CLAIMDETAILDIM				CDD
			ON E.SOURCEDATAKEY = CDD.SOURCEDATAKEY
			AND E.CLAIM_ID = CDD.CLAIMID
			AND CDD.CLAIMLINEID = '0001'

	COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY
	--
	--	Updates from UB921AdmissionDim
	--
	
		--UPDATE ADM_TYPE_CD
		BEGIN TRANSACTION
		UPDATE OUTB_PROF_HEADER
		SET 
			ADM_TYPE_CD = replace(ub.DIAGNOSISCODE,'.',''),
			ADM_SOURCE_CD = UB.admissioncode,
			ADM_TIME = UB.admissionhour,
			DISCHRG_TIME = case UB.dischargehour when 'N/A' then ' ' else UB.dischargehour end
		FROM 
			OUTB_PROF_HEADER					E
		INNER JOIN
			EDPS_DATA.dbo.UB921ADMISSIONDIM			UB
			ON E.SOURCEDATAKEY = UB.SourceDataKey
			AND E.CLAIM_ID = UB.claimid	
			AND UB.admissiondiagnosistypecode = 'A'
	
		COMMIT TRANSACTION
		
		--
		--	These original updates were all combined into the above...
		--
		--
		----UPDATE ADM_SOURCE_CD
		--BEGIN TRANSACTION
		--UPDATE OUTB_PROF_HEADER
		--SET ADM_SOURCE_CD = UB.admissioncode
		--FROM OUTB_PROF_HEADER E
		--	,EDPS_DATA.dbo.ub921admissiondim UB
		--WHERE E.CLAIM_ID = UB.claimid
		--	AND UB.admissiondiagnosistypecode = 'A'
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		----UPDATE ADM_TIME
		--BEGIN TRANSACTION
		--UPDATE OUTB_PROF_HEADER
		--SET ADM_TIME = UB.admissionhour
		--FROM OUTB_PROF_HEADER E
		--	,EDPS_DATA.dbo.ub921admissiondim UB
		--WHERE E.CLAIM_ID = UB.claimid
		--	AND UB.admissiondiagnosistypecode = 'A'
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		
		--UPDATE DISCHRG_TIME
		--BEGIN TRANSACTION
		--UPDATE OUTB_PROF_HEADER
		--SET DISCHRG_TIME = case UB.dischargehour when 'N/A' then ' ' else UB.dischargehour end
		--FROM OUTB_PROF_HEADER E
		--	,EDPS_DATA.dbo.ub921admissiondim UB
		--WHERE E.CLAIM_ID = UB.claimid
		--	AND UB.admissiondiagnosistypecode = 'A'
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--COMMIT
		
		

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY
	--
	--	Update "0" dates...
	--
 
		UPDATE OUTB_PROF_HEADER
		SET ADM_DT = ''
		WHERE ADM_DT = '0'


		UPDATE OUTB_PROF_HEADER
		SET DISCHRG_DT = ''
		WHERE DISCHRG_DT = '0'

		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

		
BEGIN TRY		

		--
		--	UPDATE CMS_CONTRACT_NUMBER and NonCov_Chrg...
		--
		BEGIN TRANSACTION

			--UPDATE 
			--	OUTB_PROF_HEADER
			--SET 
			--	CMS_CONTRACT_NUM = MR.[plan]
			--FROM 
			--	OUTB_PROF_HEADER						EC
			--INNER JOIN
			--	dbo.MMR						MR
			--	ON EC.MEMBER_ID = MR.MEM_ID
			--	AND  MR.[payt_dt] = '201208'  --ADD PARAMETER FOR PRODUCTION
			--	AND MR.adj_code = ''
			--	AND substring(mr.[plan],1,1) <> 'S'
				

			UPDATE 
				OUTB_PROF_HEADER
			SET 
				NONCOV_CHRG = ' '
			WHERE 
				CONVERT(INT, NONCOV_CHRG)< 0

		COMMIT TRANSACTION
		
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

		
BEGIN TRY
	--
	--	Update claim indicators...
	--		
		
	BEGIN TRANSACTION 

		--CLAIM INDICATOR - CLAIM REVERSAL LOGIC
		--UPDATE CLAIM INDICATOR TO DELETE FOR R REVERSAL CLAIM 
		UPDATE 
			OUTB_PROF_HEADER 
		SET  CLM_IND = '8'
			,PAYER_CLAIM_CNTRL_NUM = CA.PreviousClaimID
		FROM 
			OUTB_PROF_HEADER				C
		INNER JOIN
			EDPS_DATA.dbo.CLAIMAGG				CA
			ON C.SOURCEDATAKEY = CA.SOURCEDATAKEY
			AND C.CLAIM_ID = CA.CLAIMID
			AND CHARINDEX('R',CA.ClaimID) > 0

		
		--UPDATE CLAIM INDICATOR TO REPLACE FOR REPLACEMENT CLAIM
		--'A' (A1-A10)
		UPDATE 
			OUTB_PROF_HEADER
		SET  CLM_IND = '7'
			,PAYER_CLAIM_CNTRL_NUM = CA.PreviousClaimID
		FROM
			OUTB_PROF_HEADER				C
		INNER JOIN
			EDPS_DATA.dbo.CLAIMAGG				CA
			ON C.SOURCEDATAKEY = CA.SOURCEDATAKEY 
			AND C.CLAIM_ID = CA.CLAIMID
			AND CHARINDEX('A',CA.ClaimID) > 0
			AND CA.CurrentStatusCode = 'P'
			AND CA.PREVIOUSCLAIMID NOT IN ('N/A','UNKNOWN')
		
	
		--PAPER CLAIM INDICATOR UPDATE
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			OPTIONAL_REPORTING_IND = 'PAPER'
		WHERE 
			CHARINDEX('E',CLAIM_ID) = 0
			
		COMMIT TRANSACTION
		

		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY

		--01/21/14 Additional Parsing
		UPDATE OUTB_PROF_HEADER
		SET MEMBER_ZIP4 = '9998'
		WHERE LEN(MEMBER_ZIP4) < 4
		
		
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY
	--
	--	Update Run Controls
	--
			
	SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_HEADER)
							
	BEGIN TRANSACTION
		UPDATE 
			EXT_SYS_RUNLOG
		SET END_DT = GETDATE()	
			,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
			,TOTAL_RECORDS = @TOTAL_RECORDS
			,ENTRYDT = GETDATE()
		WHERE 
			PROC_NAME = 'pr_BUILD_OUTB_PROF_HEADER'
			AND END_DT IS NULL

	COMMIT TRANSACTION
						
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY
	--
	--	If executing in "A" mode, remove claims processed for next loop in SSIS package
	--
	IF @ExecutionMode = 'A'
	BEGIN
		DELETE
			c 
		FROM
			dbo.EDS_AllExtractClaims	c
		INNER JOIN
			#ELIG_CLM					e
			ON c.ClaimID = e.ClaimID
	END
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	


	IF OBJECT_ID('TEMPDB..#ELIG_CLM') <> 0
		DROP TABLE #ELIG_CLM

	IF OBJECT_ID('TEMPDB..#TMPDEV_HPLAN') <> 0
		DROP TABLE #TMPDEV_HPLAN
		
	IF OBJECT_ID('TEMPDB..#tmplob') <> 0
		DROP TABLE #tmplob




/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()

BEGIN TRANSACTION

	EXEC [dbo].[pr_EXSP_CLAIM_PROF_QNXT_CLMHEADER]
		@ExecutionMode	 = 'M'	
		
ROLLBACK TRANSACTION

SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/




