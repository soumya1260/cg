﻿






CREATE  PROCEDURE [dbo].[pr_Build_EDS_AllExtractClaims]

/**********************************************************************************************
PROCEDURE:	[dbo].[pr_Build_EDS_AllExtractClaims]
PURPOSE:	Builds the table dbo.EDS_AllExtractClaims which contains all available claims
			that can currently be extracted for submission.
			
			That table is used in the SSIS Claims Submission package to create multiple
			flat files for each source until all claims have been processed.
			
NOTES:		
CREATED:	2013-07-19, Dwight Staggs
REVISIONS:
Date		Author			Description
------------------------------------------------------------------------------------------------
03/18/2014	Loyal Ricks		Add sp input parameter @exclusionmode
							Add input parameter @exclusionmode to call for EXSP_HRP_CLAIM_EXCLUSIONS
							Input parameter required to support EDPS_PROD production migration using
							"Empty Bucket" and "Single file" SSIS Packages.
03/24/2014	Loyal Ricks		Add @exclusionmode default assignment
-------------------------------------------------------------------------------------------------
09/17/14	Loyal Ricks		Revise script for MMAI LOB Only
09/29/14	Loyal Ricks		Add input parameters @LOB, @CLAIM_TYPE, @JOBID to support multiple
							lob and claim type processing
*************************************************************************************************/
(
	@SourceDataKey INT = 0
	,@LOB CHAR(10)  --Valid Values (MMAI,MOA)
	,@CLAIM_TYPE CHAR(1) --Valid Values (I,P)
	,@exclusionmode CHAR(1) = 'M' --Migration Exclusions --note: Do not use a default value for parameter, EXSP_HRP_CLAIM_EXCLUSION utilizes a default
										---value specific to processing
	
	
)
AS
DECLARE
		
			@TOTAL_RECORDS INT
BEGIN TRANSACTION 
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_Build_EDS_AllExtractClaims'
							,'0'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					if @@ERROR <> 0
							begin
								rollback 
							end
				commit



BEGIN

	SET NOCOUNT ON;
	
	DECLARE @CatchErrorMessage VARCHAR(2200);
	
	IF OBJECT_ID('TEMPDB..#tmpLOB') <> 0
		DROP TABLE #tmpLOB
	
	CREATE TABLE #tmpLOB
	(
		LOBCode VARCHAR(15)
	)
	
BEGIN TRY
	--
	--	Load Temp LOB table...
	--
	if @LOB = 'MMAI' 
	BEGIN
	INSERT INTO 
		#tmpLOB
	SELECT 
		LOBCode
	FROM 
		MDQOLib.dbo.LineofBusinessDim
	WHERE 
		LOBCODE = 'UMISC0028041899'
		--ProductType = 'Medicare'
	AND Active = 1
	ORDER BY 
		LOBCode	
	END
	
	IF @LOB = 'MAO'
	BEGIN
		INSERT INTO 
		#tmpLOB
	SELECT 
		LOBCode
	FROM 
		MDQOLib.dbo.LineofBusinessDim
	WHERE 
		ProductType = 'Medicare'
	AND Active = 1
	ORDER BY 
		LOBCode	
	END

	--
	--	Refresh the Exclusion table...
	--
	
	--  03/24/2014 - @exclusionmode default assignment
	--	Evaluate current server in order to determine proper default assignment of @exclusionmode
	--	Use value 'R' (Regular exclusion mode) for EDPS_DEV, use 'M' (Migration exclusion mode) for 
	--	EDPS_QA & EDPS_PROD
	
	----
	--	Note 
	-- 01/02/2015 Remove this clause due to change in definition of QA environment. QA will no longer 
	--	be used for Migration jobs. Regular and Migration exclusion jobs will be executed from QA. Additional
	-- revisions required to support Migration only jobs. Removal of below code will support current QA 
	-- requirement of regular exclusionmode jobs. 

		--if @@SERVERNAME = 'HSTNEDSDEVDB02'  -- WAS 'HSMDQODEVDB03'
		--		SELECT @exclusionmode = 'R'
		--ELSE 
		--		SELECT @exclusionmode = 'M'
				
				
	EXECUTE EXSP_WIPRO_CLAIM_EXCLUSION @SourceDataKey,@exclusionmode
	
	--
	--	Truncate target table...
	--
	TRUNCATE TABLE dbo.EDS_AllExtractClaims

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY

	--
	--	MHC
	--
	


	--
	--	QNXT
	--

		INSERT INTO
			dbo.EDS_AllExtractClaims
		(
			SOURCEDATAKEY, 
			ClaimID
		)
		SELECT
			DISTINCT c.SOURCEDATAKEY, c.ClaimID
		FROM
			EDPS_Data.dbo.CLAIMDIM			c
		INNER JOIN
			#tmplob					l
			ON c.LOBCODE = l.LOBCode
		LEFT OUTER JOIN
			dbo.EXT_CLAIM_EXCLUSION		e
			ON c.SOURCEDATAKEY = e.SOURCEDATAKEY
			AND c.CLAIMID = e.claim_id
		WHERE
			c.SOURCEDATAKEY = @SourceDataKey
		AND CASE c.FORMTYPECODE WHEN 'H' THEN 'P' WHEN 'U' THEN 'I' END = @CLAIM_TYPE
		--AND c.DENIEDFLAG = 0
		--AND SUBSTRING(c.CLAIMID, 12, 1) NOT IN ('A', 'R')
		AND e.claim_id IS NULL
	
	
	
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH



END
--ASSIGN TOTAL RECORDS		
				SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM dbo.EDS_AllExtractClaims)	
				---HRP_CLAIM_FILE Update Run Controls
						BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_Build_EDS_AllExtractClaims'
								AND END_DT IS NULL
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT
						
						
						


/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()



	EXEC [dbo].[pr_Build_EDS_AllExtractClaims]
		@SourceDataKey = 30
		


SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/



















