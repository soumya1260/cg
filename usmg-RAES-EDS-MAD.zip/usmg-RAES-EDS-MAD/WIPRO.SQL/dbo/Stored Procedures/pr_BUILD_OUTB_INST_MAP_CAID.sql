﻿  
  
  
  
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_MAP_CAID]  
(@LOB CHAR(10)  --Valid Values (MMAI,MOA)  
,@LOBCODE VARCHAR(15)  
,@JOBID INT)  
AS  
/***************************************************************************************************  
** CREATE DATE: 01/2012  
**  
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM  
**  
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM INFORMATION   
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.2. THE SOURCE    
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES.   
**  
**  
Modification History  
====================  
Date			Who				Description  
-----------------------------------------------------------------------------------------------------  
2012-10-19		Dwight Staggs	Remove database name from table references  
2012-11-01		Loyal Ricks		Add CONTRACT_TYPE to claim_line HRP RECORD TYPE L  
2012-11-09		LOYAL RICKS		ADD CLM_ADJ_QTY122  
2012-11-15		LOYAL RICKS		ADD CLAIM ADJUSTMENT SEGMENTS 1-1-1 - 1.5-6  
2012-12-12		LOYAL RICKS		REVISED @FILEID ASSIGNMENT FROM 'CLAIM'+''+RTRIM((replace(replace(replace(convert(char, getdate(), 120),'-',''),':',''),' ','')));  
								TO 'HSCE'+''+RTRIM((replace(replace(replace(convert(char, getdate(), 120),'-',''),':',''),' ','')));  
2013-03-05		LOYAL RICKS		Change Step from 8 to 9. EXSP_HRP_CLAIM_REQ_CATALL is now #8  
2013-05-10		Loyal Ricks		Add Rendering Provider Information   
2013-05-13		Loyal Ricks		Replace default FILEID prefix 'HCSE' with substring(FILEDESC,1,6). This will enable source specific naming   
								of outbound file. Will allow for easier tracking of outbound file throughout entire submission process.  
2013-10-04		Loyal Ricks		Add Other Payer 1 Revenue Code to claim detail (map row 3291)  
2014-04-17		Loyal Ricks		V4.0 additional 139 data elements revise header from +'~'+replicate('~',10)+' '+'^' to +'~'+replicate('~',149)+' '+'^'  
								v4.0 additonal 19 data elements revise detail from +'~'+replicate('~',17)+' '+'^' to +'~'+replicate('~',36)+' '+'^'  
  
  
*****************************************************************************************************	  
------------------------------------------------------------------------------------------------------  
******************************************************************************************************  
------------------------------------------------------------------------------------------------------  
2014-06-25		Loyal Ricks		WIPRO Implementation  
2014-07-11		Loyal Ricks		Add 13 data elements (148-161) to Header  
								Add 2 data elements (18-20) to detail  
2014-07-16		Loyal Ricks		Add 1 data element to claim detail -  Repriced Product or Service ID  	  
2014-07-16		Loyal Ricks		Add 12 (160-172) data elements to claim header for condition codes   
2014-07-22		Loyal Ricks		Add 1 (172 to 173) for end of record "^" data element	  
2014-07-23		Loyal Ricks		WIPRO File naming convention prefix, Production =  'DILT09.NCPDP.UPLOAD'	  
								, Test = 'DILT09.NCPDPT.UPLOAD'		  
2014-07-30		Loyal Ricks		Add PRINCIPAL_DIAG_QUAL & ADMIT_DIAG_QUAL 	  
2014-08-04		Loyal Ricks		Revise logic for WIPRO file naming convention		  
2014-09-23		Loyal Ricks		Add @LOB, populate OUTB_FILE_HIST.FILEDESC with this value as the suffix (rtrim(FILEDESC+'-'+@LOB)	  
2014-11-18		Loyal Ricks		Add @LOB to fileid	  
2015-01-27		Loyal Ricks		Revised logic incorrectly mapping Vendorid & System Source. Fixed mapping to include 'CIGNA-HSPR' as   
								VendorId & SourceDesc+claim_type+lob as system source		  
2015-02-10		Loyal Ricks		EDS-681 Add File Subtype (@FILESUBTYPE) - When @CLAIMTYPE = 'IP' THEN SET VALUE = 'Institutional' else ' '	  
2015-04-08		Loyal Ricks		Add outbound file archiving SP call pr_ClaimInstitutionalExtractHistoryInsert		  
2015-04-14		Loyal Ricks		Revised @FILETYPE variable changine when clause from CLAIM_TYPE = 'P' TO CLAIM_TYPE = 'I'  
2015-05-29		Loyal Ricks		TETDM-107 Add input parameter @LOBCODE to support MMAI Plans (IL & TX) file naming conventions  
								Add variable @SUBMITTERID to support file naming convention  
								Revise Fileid for MMAI files  
2015-07-13		Loyal Ricks		Add formatting for @SUBMITTERID to include node value of '.' when passed. This node is conditional  
								and is only needed when it is a MMAI file. Absence of this logic was creating an extra node for   
								MAO files. 	  
2015-07-22		Loyal Ricks		Remove default value assignment of @LOBCODE (0) and set to ' ' - blank   
								is used by MAO 	  
2015-07-23		Loyal Ricks		TETDM-276 Add JOBID to filedesc	  
2015-12-04		Loyal Ricks		MMAI-CAID Add PRODUCTNODE set to CIAD when @LOBID = CAID  
2015-12-04		Loyal Ricks		Reassign input variable @LOB from 'CAID' value used by job to 'MMAI' to support file naming convention	  
2017-12-21		Mike Vega		TETDM-1649 --> REMOVE "CHKSUM" logic call in order to prevent any out-of-balance claims from being entered into the EXT_CLAIM_CHKSUM Table											      
*****************************************************************************************************/  
  
	--DECLARE VARIABLES  
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND  
			DECLARE  
			  
			@TOTAL_RECORDS INT,  
			--FILE FOOTER	  
			@TOTAL_CLAIM   INT,  
			@TOTAL_PROF_CLM INT,  
			@TOTAL_INST_CLM INT,  
			@TOTAL_DENTAL_CLM INT ,  
			@TOTAL_LINES INT,  
			@SUM_TOTAL_CHARGES MONEY,  
			@SUM_LINE_CHARGES MONEY,  
			@SUM_TOTAL_CHARGES2 MONEY,  
			@SUM_LINE_CHARGES2 MONEY,  
			@TOTAL_EOF_COUNT INT,  
			@CREATEDT CHAR(14),  
			@FILEID CHAR(50),  
			@FOOTER CHAR(255),  
			@HEADER_CNTRL INT,  
			@FOOTER_CNTRL INT,  
			@RECHEADER_CNTRL INT,  
			@RECDTL_CNTRL INT,  
			@RECOTH_CNTRL INT,  
			@FILE_TYPE CHAR(50),  
			@VERSION CHAR(10) ,  
			@SOURCEDATAKEY INT,  
			@FILEDESC VARCHAR(35),  
			@CLAIMTYPE VARCHAR(1),  
			@PRODUCTINDICATOR VARCHAR(4),  
			@FILESUBTYPE VARCHAR(15),  
			@SUBMITTERID VARCHAR(15),  
			@PRODUCTNODE VARCHAR(5)   
  
begin  
  
	--HRP_CLAIM_FILE Run controls  
INSERT INTO EXT_SYS_RUNLOG  
		(PROC_NAME  
		,STEP  
		,START_DT  
		,END_DT  
		,RUN_MINUTES  
		,TOTAL_RECORDS  
		,ENTRYDT  
		)  
		VALUES('pr_BUILD_OUTB_INST_MAP'  
				,'10'  
				,GETDATE()  
				,NULL  
				,NULL  
				,0  
				,GETDATE()  
				)  
  
	--PROCEDURE VARIABLES  
		IF @@SERVERNAME IN ('HSTNEDSDB01')  
			BEGIN   
				SET @PRODUCTINDICATOR = 'PROD'  
				SET @FILEID = 'HSCE.PROD.'  
			END  
		IF @@SERVERNAME IN ('HSTNEDSDEVDB02')   
			BEGIN   
				SET @PRODUCTINDICATOR = 'TEST'  
				SET @FILEID = 'HSCE.DEV.'  
			END  
		IF @@SERVERNAME IN ('HSTNEDSDEVDB01')   
			BEGIN   
				SET @PRODUCTINDICATOR = 'TEST'  
				SET @FILEID = 'HSCE.QA.'  
			END  
		--File naming convention Submitterid node assignment  
			--remove default @LOBCODE Value used by SSIS package  
		if @LOBCODE = '0'  
			BEGIN   
				SET @LOBCODE = ' '  
			END  
			--MMAI IL  
		if @LOBCODE = 'UMISC0028041899'  
			BEGIN   
				SET @SUBMITTERID = 'DILT09.'  
			END  
			--MMAI TX  
		if @LOBCODE = 'C54581391'  
			BEGIN   
				SET @SUBMITTERID = 'DTXT08.'  
			END  
  
		SET @PRODUCTNODE = 'CARE';  
		IF @LOB = 'CAID'  
			BEGIN   
				SET @PRODUCTNODE = 'CAID';  
				SET @LOB = 'MMAI'  
			END  
		SET @SOURCEDATAKEY = (SELECT DISTINCT SOURCEDATAKEY FROM OUTB_INST_HEADER);  
		SET @CLAIMTYPE = (SELECT DISTINCT CLAIM_TYPE FROM OUTB_INST_HEADER)  
		--SET @FILEID =   
		--SET @FILEID = (SELECT RTRIM(CNTRL_TXT)+''+@CLAIMTYPE FROM EXT_SYS_CLM_JOBCNTRL WHERE CNTRL_DESC = 'FILEID' AND CNTRL_STATUS = 'A');  
		SET @FILEDESC = (SELECT RTRIM(SOURCEDESC) FROM SourceDataDim WHERE SourceDataKey = @SOURCEDATAKEY) + '-'+ @CLAIMTYPE + '-'+ RTRIM(@LOB);  
		SET @FILEID = RTRIM(@FILEID)+''+rtrim(@LOB)+'.'+ISNULL(RTRIM(@SUBMITTERID),'')+''+RTRIM(convert(char(10),@sourcedatakey))+'.'+@CLAIMTYPE+'.'+@PRODUCTNODE+'.'+RTRIM((replace(replace(replace(convert(char, getdate(), 120),'-',''),':',''),' ','')));  
		SET @CREATEDT = RTRIM((replace(replace(replace(convert(char, getdate(), 120),'-',''),':',''),' ','')));  
		SET @SUM_TOTAL_CHARGES2 = (SELECT SUM(convert(MONEY, LTRIM(TOT_CHRG_AMT))) FROM OUTB_INST_HEADER);	  
		SET @SUM_LINE_CHARGES2 = (SELECT SUM(convert(MONEY, LTRIM(TOTAL_CHRG_AMT))) FROM OUTB_INST_DETAIL);				  
		SET @FILESUBTYPE = CASE @CLAIMTYPE WHEN 'I' THEN 'Institutional' ELSE ' ' END;  
		  
		/***************************************************************************************************  
		**   
		** HRP CLAIM FILE CHECK SUM - VALIDATE OUTBOUND CLAIM HEADER & LINE TOTAL CHARGES  
		**  
		*****************************************************************************************************/  
  
		----TETDM-1649 --> Remove by Mike Vega 12/21/17  
		----------------------------------------------  
		--IF @SUM_TOTAL_CHARGES2 <> @SUM_LINE_CHARGES2   
		--begin  
		--	EXECUTE BUILD_OUTB_CLAIM_CKHSUM @FILEID  
		--end   
		  
  
		TRUNCATE TABLE OUTB_INST_CLAIM_MAP  
	  
--PROCEDURE VARIABLES   
--FILE FOOTER	  
  
--BUILD HRP CLAIM RECORD TYPE C - CLAIM HEADER  
		--SHOULD SPACING BEFORE REPLICATE INCLUDE +''+ OR +'~'+  
	--BEGIN TRANSACTION  
		 insert into OUTB_INST_CLAIM_MAP  
		SELECT DISTINCT '2000',RTRIM(CLAIM_ID)+'-'+'0000'+'-'+'2000',RTRIM(RECORD_TYPE)+'~'+RTRIM(CLAIM_TYPE)+'~'+RTRIM(SYSTEM_SOURCE)+'~'+RTRIM(CMS_CONTRACT_NUM)+'~'+RTRIM(HICN_NUM)+'~'+RTRIM(CLAIM_ID)+'~'+RTRIM(PAT_CNTRL_NO)+'~'+RTRIM(MEMBER_ID)  
			+'~'+RTRIM(MEMBER_LAST_NAME)+'~'+RTRIM(MEMBER_FIRST_NAME)+'~'+RTRIM(MEMBER_MID_INIT)+'~'+RTRIM(MEMBER_SFX)+'~'+RTRIM(MEMBER_ADDR1)+'~'+RTRIM(MEMBER_ADDR2)+'~'+RTRIM(MEMBER_CITY)  
			+'~'+RTRIM(MEMBER_STATE)+'~'+RTRIM(MEMBER_ZIP)+'~'+RTRIM(MEMBER_ZIP4)+'~'+RTRIM(MEMBER_CTY)+'~'+RTRIM(MEMBER_CTRY)+'~'+RTRIM(MEMBER_CTRY_SUBD)  
			+'~'+RTRIM(MEMBER_GROUP_NO)+'~'+RTRIM(INSURANCE_TYPE)+'~'+RTRIM(MEMBER_DOB)+'~'+RTRIM(MEMBER_GENDER)+'~'+RTRIM(MEMBER_SSN)+'~'+RTRIM(POS)+'~'+RTRIM(INST_PRINCIPAL_DIAG_CD)  
			+'~'+RTRIM(INST_PRINCIPAL_POA_CD)+'~'+RTRIM(INST_ADM_DIAG_CD)+'~'+replicate('~',28)+''+RTRIM(DIAG_CD1)+'~'+RTRIM(POA_IND1)+'~'+RTRIM(DIAG_CD2)+'~'+RTRIM(POA_IND2)  
			+'~'+RTRIM(DIAG_CD3)+'~'+RTRIM(POA_IND3)+'~'+RTRIM(DIAG_CD4)+'~'+RTRIM(POA_IND4)+'~'+RTRIM(DIAG_CD5)+'~'+RTRIM(POA_IND5)+'~'+RTRIM(DIAG_CD6)+'~'+RTRIM(POA_IND6)  
			+'~'+RTRIM(DIAG_CD7)+'~'+RTRIM(POA_IND7)+'~'+RTRIM(DIAG_CD8)+'~'+RTRIM(POA_IND8)+'~'+RTRIM(DIAG_CD9)+'~'+RTRIM(POA_IND9)+'~'+RTRIM(DIAG_CD10)+'~'+RTRIM(POA_IND10)  
			+'~'+RTRIM(DIAG_CD11)+'~'+RTRIM(POA_IND11)+'~'+RTRIM(DIAG_CD12)+'~'+RTRIM(POA_IND12)+'~'+RTRIM(DIAG_CD13)+'~'+RTRIM(POA_IND13)+'~'+RTRIM(DIAG_CD14)+'~'+RTRIM(POA_IND14)  
			+'~'+RTRIM(DIAG_CD15)+'~'+RTRIM(POA_IND15)+'~'+RTRIM(DIAG_CD16)+'~'+RTRIM(POA_IND16)+'~'+RTRIM(DIAG_CD17)+'~'+RTRIM(POA_IND17)+'~'+RTRIM(DIAG_CD18)+'~'+RTRIM(POA_IND18)  
			+'~'+RTRIM(DIAG_CD19)+'~'+RTRIM(POA_IND19)+'~'+RTRIM(DIAG_CD20)+'~'+RTRIM(POA_IND20)+'~'+RTRIM(DIAG_CD21)+'~'+RTRIM(POA_IND21)+'~'+RTRIM(DIAG_CD22)+'~'+RTRIM(POA_IND22)  
			+'~'+RTRIM(DIAG_CD23)+'~'+RTRIM(POA_IND23)+'~'+RTRIM(DIAG_CD24)+'~'+RTRIM(POA_IND24)+'~'+RTRIM(DIAG_CD25)+'~'+RTRIM(POA_IND25)+'~'+RTRIM(DIAG_CD26)+'~'+RTRIM(POA_IND26)  
			+'~'+RTRIM(DIAG_CD27)+'~'+RTRIM(POA_IND27)+'~'+RTRIM(DIAG_CD28)+'~'+RTRIM(POA_IND28)+'~'+RTRIM(DIAG_CD29)+'~'+RTRIM(POA_IND29)+'~'+RTRIM(DIAG_CD30)+'~'+RTRIM(POA_IND30)  
			+'~'+RTRIM(BILL_PROV_NPI)+'~'+RTRIM(BILL_PROV_GRP_ID)+'~'+RTRIM(BILL_PROV_GRP_NPI)+'~'+RTRIM(BILL_PROV_ORG_NAME)+'~'+RTRIM(BILL_PROV_LNAME)  
			+'~'+RTRIM(BILL_PROV_FNAME)+'~'+RTRIM(BILL_PROV_MID_INIT)+'~'+RTRIM(BILL_PROV_SFX)+'~'+RTRIM(BILL_PROV_ADDR1)+'~'+RTRIM(BILL_PROV_ADDR2)  
			+'~'+RTRIM(BILL_PROV_CITY)+'~'+RTRIM(BILL_PROV_STATE)+'~'+RTRIM(BILL_PROV_ZIP)+'~'+RTRIM(BILL_PROV_ZIP4)+'~'+RTRIM(BILL_PROV_CTRY)+'~'+RTRIM(BILL_PROV_CTRY_SUBD)  
			+'~'+RTRIM(BILL_PROV_TAXONOMY_CD)+'~'+RTRIM(BILL_PROV_TAX_ID)+'~'+RTRIM('')+'~'+RTRIM(BILL_PROV_UPIN)+'~'+RTRIM(BILL_PROV_LICENSE_NO)+'~'+RTRIM(BILL_PROV_ID)  
			+'~'+replicate('~',9)+''+RTRIM(PAYTO_ADDR_TYPE_FLAG)+'~'+RTRIM(PAYTO_ADDR1)+'~'+RTRIM(PAYTO_ADDR2)+'~'+RTRIM(PAYTO_CITY)+'~'+RTRIM(PAYTO_STATE)+'~'+RTRIM(PAYTO_ZIP)  
			+'~'+RTRIM(PAYTO_ZIP4)+'~'+RTRIM(PAYTO_CTRY)+'~'+RTRIM(PAYTO_CTRY_SUBD)+'~'+RTRIM(PAYER_RESP)+'~'+RTRIM(TOT_CHRG_AMT)+'~'+RTRIM(MEMBER_AMT_PAID)+'~'+RTRIM(PATIENT_EST_AMT_DUE)  
			+'~'+RTRIM(CLM_IND)  
				---------institutional claim map revision  
			+'~'+RTRIM(CONDITION1)+'~'+RTRIM(CONDITION2)+'~'+RTRIM(CONDITION3)+'~'+RTRIM(CONDITION4)+'~'+RTRIM(CONDITION5)+'~'+RTRIM(CONDITION6)+'~'+RTRIM(CONDITION7)+'~'+RTRIM(CONDITION8)  
			+'~'+RTRIM(CONDITION9)+'~'+RTRIM(CONDITION10)+'~'+RTRIM(CONDITION11)+'~'+RTRIM(CONDITION12)  
				  
				---------institutional claim map revision  
			+'~'+RTRIM('')+'~'+RTRIM(PROV_ASSGN_IND)+'~'+RTRIM(INSR_BEN_ASSGN_IND)+'~'+RTRIM(REL_OF_INFO_FLAG)+'~'+replicate('~',5)  
			+''+RTRIM(AUTO_ACC_STATE)+'~'+RTRIM(AUTO_ACC_CTRY)+'~'+replicate('~',2)+''+RTRIM(DELAY_REAS)+'~'+replicate('~',11)  
			+''+RTRIM(ADM_TYPE_CD)+'~'+RTRIM(ADM_SOURCE_CD)+'~'+RTRIM(ADM_DT)+'~'+RTRIM(ADM_TIME)+'~'+RTRIM(STATE_BEGIN_DT)+'~'+RTRIM(STATE_END_DT)+'~'+RTRIM('')+'~'+RTRIM(DISCHRG_TIME)+'~'+RTRIM(PATIENT_STATUS_CD)  
  
				---------institutional claim map revision			  
			+'~'+replicate('~',7)+''+RTRIM(REPRICER_REC_DT)+'~'+replicate('~',30)  
			+''+RTRIM(CONTRACT_TYPE)+'~'+replicate('~',8)+''+  
			RTRIM(REFERRAL_NO)+'~'+RTRIM(PRIOR_AUTH_NO)+'~'+RTRIM(CLM_CNTRL_NO)  
				---------institutional claim map revision  
			+'~'+replicate('~',1)+''+RTRIM(REPRICE_CLM_REF_NO)+'~'+RTRIM(ADJ_REPRICED_CLM_REF_NO)+'~'+RTRIM(INVEST_DEV_EXEMP_NO)+'~'+RTRIM(MEDICAL_REC_NO)  
			+'~'+replicate('~',131)+''+RTRIM(PRICE_METHOD)  
				---------institutional claim map revision  
			+'~'+RTRIM(REPRICED_ALLOWED_AMOUNT)+'~'+RTRIM(REPRICED_SAVING_AMOUNT)+'~'+RTRIM(REPRICing_ORGANIZATION_IDENTIFIER)+'~'+RTRIM(REPRICING_PER_DIEM_OR_FLAT_RATE_AMOUNT)+'~'+RTRIM(REPRICED_APPROVED_AMBULATORY_PATIENT_GROUP_CODE)  
			+'~'+RTRIM(REPRICED_APPROVED_AMBULATORY_PATIENT_GROUP_AMOUNT)  
			  
			  
			  
			----------------------------file out of line - missing --- REPRICED_APPROVED_AMBULATORY_PATIENT_GROUP_CODE  
			+'~'+RTRIM(REPRICED_APPROVED_REVENUE_CODE)+'~'+RTRIM(REPRICED_APPROVED_SERVICE_UNITS)+'~'+RTRIM(REPRICED_APPROVED_SERVICE_DAYS)+'~'+RTRIM(REJECT_REASON_CODE)+'~'+RTRIM(POLICY_COMPLIANCE_CODE)+'~'+RTRIM(EXCEPTION_CODE)  
			+'~'+RTRIM(REF_PROV_LNAME)+'~'+RTRIM(REF_PROV_FNAME)+'~'+RTRIM(REF_PROV_MID_INIT)+'~'+RTRIM(REF_PROV_SFX)+'~'+RTRIM(REF_PROV_NPI)+'~'+RTRIM('')+'~'+RTRIM(REF_PROV_LICENSE_NO)  
			+'~'+RTRIM(REF_PROV_UPIN)+'~'+RTRIM(REF_PROV_ID)+'~'+RTRIM('')+'~'+RTRIM('')+'~'+RTRIM('')+'~'+RTRIM('')+'~'+RTRIM('')  
			+'~'+RTRIM('')+'~'+RTRIM('')+'~'+RTRIM('')+'~'+RTRIM('')+'~'+RTRIM(RENDERING_PROV_ORG_NAME)+'~'+RTRIM(RENDERING_PROV_GRP_ID)  
			+'~'+RTRIM(RENDERING_PROV_LAST_NAME)+'~'+RTRIM(RENDERING_PROV_LAST_NAME)  
			+'~'+RTRIM(RENDERING_PROV_MID_INIT)+'~'+RTRIM(RENDERING_PROV_SFX)+'~'+replicate('~',6)+''+RTRIM(RENDERING_PROV_NPI)+'~'+replicate('~',3)+''+RTRIM(RENDERING_PROV_ID)  
  
				---------institutional claim map revision  
			+'~'+replicate('~',4)+''+RTRIM(SERVICE_fAC_NAME)+'~'+RTRIM(SERVICE_FAC_NPI)+'~'+replicate('~',8)+''+RTRIM(SERVICE_FAC_PROV_LIC_NUM)+'~'+RTRIM(SERVICE_FAC_PROV_LOC_NUM)  
			+'~'+replicate('~',9)+''+RTRIM(ATTN_PROV_LNAME)  
			+'~'+RTRIM(ATTN_PROV_FNAME)+'~'+RTRIM(ATTN_PROV_MIDINIT)+'~'+RTRIM(ATTN_PROV_SFX)+'~'+RTRIM(ATTN_PROV_NPI)+'~'+RTRIM(ATTN_PROV_TAXONOMY_CD)+'~'+RTRIM(ATTN_PROV_TAXONOMY_CD2)  
			+'~'+RTRIM(ATTN_PROV_UPIN)+'~'+RTRIM(ATTN_PROV_LOC_NO)+'~'+RTRIM(ATTN_PROV_ID)+'~'+RTRIM(ATTN_PROV_LICENSE_NO)+'~'+RTRIM(OPER_PHYS_LNAME)+'~'+RTRIM(OPER_PHYS_FNAME)+'~'+RTRIM(OPER_PHYS_MID_NAME)+'~'+RTRIM(OPER_PHYS_SFX)  
			+'~'+RTRIM(OPER_PHYS_NPI)+'~'+replicate('~',2)+''+RTRIM(OPER_PHYS_PROV_ID)+'~'+replicate('~',1)+''+RTRIM(OTH_OPER_PHYS_LNAME)+'~'+RTRIM(OTH_OPER_PHYS_FNAME)+'~'+RTRIM(OTH_OPER_PHYS_MID_NAME)+'~'+RTRIM(OTH_OPER_PHYS_SFX)  
			+'~'+RTRIM(OTH_OPER_PHYS_NPI)+'~'+replicate('~',2)+''+RTRIM(OTH_OPER_PHYS_PROV_ID)+'~'+replicate('~',10)  
			+''+RTRIM(PAYER_RESP1)+'~'+RTRIM(REL_CD1)+'~'+RTRIM('')+'~'+RTRIM(OTH_INSR_GRPNAME)+'~'+RTRIM('')+'~'+RTRIM(CLM_FIL_INDCD1)  
			+'~'+RTRIM('')+'~'+RTRIM('')+'~'+RTRIM('')+'~'+RTRIM('')+'~'+  
			+''+replicate('~',91)+''+RTRIM(AMOUNT_PAID)+'~'+RTRIM('')+'~'+replicate('~',1)+''+RTRIM(ASSIGN_BEN_IND1)  
			+'~'+replicate('~',33)+''+RTRIM(MEMBER_LAST_NAME)+'~'+RTRIM(MEMBER_FIRST_NAME)+'~'+RTRIM(MEMBER_MID_INIT)+'~'+RTRIM(MEMBER_SFX)+'~'+RTRIM(HICN_NUM)+'~'+RTRIM(MEMBER_ADDR1)+'~'+RTRIM(MEMBER_ADDR2)+'~'+RTRIM(MEMBER_CITY)  
			+'~'+RTRIM(MEMBER_STATE)+'~'+RTRIM(MEMBER_ZIP)+'~'+RTRIM(MEMBER_ZIP4)+'~'+replicate('~',3)+''+RTRIM(OTH_PAYER1_NAME)+'~'+RTRIM(OTH_PAYER1_PLANID)+'~'+RTRIM(OTH_PAYER1_ADDRESS1)+'~'+RTRIM(OTH_PAYER1_ADDRESS2)  
			+'~'+RTRIM(OTH_PAYER1_CITY)+'~'+RTRIM(OTH_PAYER1_STATE)+'~'+RTRIM(OTH_PAYER1_ZIP)+'~'+RTRIM(OTH_PAYER1_ZIP4)+'~'+replicate('~',2)+''+RTRIM('')+'~'+replicate('~',2215)  
				---------institutional claim map revision  
			+''+RTRIM(OPTIONAL_REPORTING_IND1)+'~'+RTRIM(OPTIONAL_REPORTING_IND2)+'~'+RTRIM(OPTIONAL_REPORTING_IND3)+'~'+RTRIM(PATIENT_DOD)+'~'+RTRIM(PREGNANCY_IND)+'~'+RTRIM(SPEC_PROG_CD)+'~'+RTRIM(LMP_DT)+'~'+RTRIM(EPSDT_REF_COND_RESP_CD)  
			+'~'+RTRIM(EPSDT_REF_COND_IND1)+'~'+RTRIM(EPSDT_REF_COND_IND2)+'~'+RTRIM(EPSDT_REF_COND_IND3)+'~'+replicate('~',11)+''+RTRIM(PRINCIPAL_DIAG_QUAL)+'~'+RTRIM(ADMIT_DIAG_QUAL)  
			+'~'+replicate('~',148)+' '+'^'  
			-- <7/30 before qualifier adjustments> +'~'+replicate('~',161)+' '+'^'  
			-- BEFORE 7/11 CHANGE+'~'+replicate('~',148)+' '+'^'  
		FROM OUTB_INST_HEADER  
	--		if @@ERROR <> 0  
	--			begin  
	--				rollback   
	--			end  
	--COMMIT  
	--BUILD HRP CLAIM RECORD TYPE L - CLAIM LINE  
	--SHOULD SPACING BEFORE REPLICATE INCLUDE +''+ OR +'~'+  
	--BEGIN TRANSACTION  
		INSERT INTO OUTB_INST_CLAIM_MAP  
		SELECT DISTINCT '3000',RTRIM(CLAIM_ID)+''+RTRIM(CLAIM_LINE_NO)+'-'+'3000',RTRIM(RECORD_TYPE)+'~'+RTRIM(CLAIM_ID)+'~'+RTRIM(CLAIM_LINE_NO)+'~'+RTRIM(SERV_START_DT)+'~'+RTRIM(SERV_END_DT)+'~'+RTRIM(REV_CD1)+'~'+RTRIM(REV_CD2)+'~'+RTRIM(REV_CD3)  
			+'~'+RTRIM(SERV_ID_QUAL)+'~'+RTRIM(PROC_CD)+'~'+RTRIM(PROC_MOD1)+'~'+RTRIM(PROC_MOD2)+'~'+RTRIM(PROC_MOD3)+'~'+RTRIM(PROC_MOD4)+'~'+RTRIM(PROC_DESC)+'~'+RTRIM(TOTAL_CHRG_AMT)+'~'+RTRIM(NON_COV_AMT)+'~'+RTRIM('')  
			+'~'+RTRIM(QTY_DAYS)+'~'+RTRIM(QTY_UNITS)  
---------institutional claim map revision  
			+'~'+replicate('~',146)+''+RTRIM(CLAIM_LINE_NO)+'~'+replicate('~',11)+''+RTRIM(GS_TAX_AMT)+'~'+RTRIM(FAC_TAX_AMT)+'~'+replicate('~',147)+''+RTRIM(INST_PRINCIPAL_PROC_TYPE_IND)  
			+'~'+RTRIM(OTH_PAYER1_PRIMEID)+'~'+RTRIM(OTH_PAYER1_PAID_AMT)+'~'+RTRIM(OTH_PAYER1_PROC_CD)+'~'+replicate('~',6)+''+RTRIM(REV_CD1)+'~'+RTRIM(OTH_PAYER1_PAID_QTY)+'~'+RTRIM(OTH_PAYER1_ADJ_BUNDLE)+'~'+RTRIM(CLM_ADJ_GRP111)+'~'+RTRIM(CLM_ADJ_REASON111)  
			+'~'+RTRIM(CLM_ADJ_AMT111)+'~'+RTRIM(CLM_ADJ_QTY111)+'~'+RTRIM(CLM_ADJ_REASON112)+'~'+RTRIM(CLM_ADJ_AMT112)+'~'+RTRIM(CLM_ADJ_QTY112)+'~'+RTRIM(CLM_ADJ_REASON113)+'~'+RTRIM(CLM_ADJ_AMT113)+'~'+RTRIM(CLM_ADJ_QTY113)  
			+'~'+RTRIM(CLM_ADJ_REASON114)+'~'+RTRIM(CLM_ADJ_AMT114)+'~'+RTRIM(CLM_ADJ_QTY114)+'~'+RTRIM(CLM_ADJ_REASON115)+'~'+RTRIM(CLM_ADJ_AMT115)+'~'+RTRIM(CLM_ADJ_QTY115)+'~'+RTRIM(CLM_ADJ_REASON116)+'~'+RTRIM(CLM_ADJ_AMT116)+'~'+RTRIM(CLM_ADJ_QTY116)  
			+'~'+RTRIM(CLM_ADJ_GRP12)+'~'+RTRIM(CLM_ADJ_REASON121)+'~'+RTRIM(CLM_ADJ_AMT121)+'~'+RTRIM(CLM_ADJ_QTY121)+'~'+RTRIM(CLM_ADJ_REASON122)+'~'+RTRIM(CLM_ADJ_AMT122)+'~'+RTRIM(CLM_ADJ_QTY122)+'~'+RTRIM(CLM_ADJ_REASON123)+'~'+RTRIM(CLM_ADJ_AMT123)+'~'+RTRIM(CLM_ADJ_QTY123)  
			+'~'+RTRIM(CLM_ADJ_REASON124)+'~'+RTRIM(CLM_ADJ_AMT124)+'~'+RTRIM(CLM_ADJ_QTY124)+'~'+RTRIM(CLM_ADJ_REASON125)+'~'+RTRIM(CLM_ADJ_AMT125)+'~'+RTRIM(CLM_ADJ_QTY125)+'~'+RTRIM(CLM_ADJ_REASON126)+'~'+RTRIM(CLM_ADJ_AMT126)+'~'+RTRIM(CLM_ADJ_QTY126)  
			+'~'+RTRIM(CLM_ADJ_GRP13)+'~'+RTRIM(CLM_ADJ_REASON131)+'~'+RTRIM(CLM_ADJ_AMT131)+'~'+RTRIM(CLM_ADJ_QTY131)+'~'+RTRIM(CLM_ADJ_REASON132)+'~'+RTRIM(CLM_ADJ_AMT132)+'~'+RTRIM(CLM_ADJ_QTY132)+'~'+RTRIM(CLM_ADJ_REASON133)+'~'+RTRIM(CLM_ADJ_AMT133)+'~'+RTRIM(CLM_ADJ_QTY133)  
			+'~'+RTRIM(CLM_ADJ_REASON134)+'~'+RTRIM(CLM_ADJ_AMT134)+'~'+RTRIM(CLM_ADJ_QTY134)+'~'+RTRIM(CLM_ADJ_REASON135)+'~'+RTRIM(CLM_ADJ_AMT135)+'~'+RTRIM(CLM_ADJ_QTY135)+'~'+RTRIM(CLM_ADJ_REASON136)+'~'+RTRIM(CLM_ADJ_AMT136)+'~'+RTRIM(CLM_ADJ_QTY136)  
			+'~'+RTRIM(CLM_ADJ_GRP14)+'~'+RTRIM(CLM_ADJ_REASON141)+'~'+RTRIM(CLM_ADJ_AMT141)+'~'+RTRIM(CLM_ADJ_QTY141)+'~'+RTRIM(CLM_ADJ_REASON142)+'~'+RTRIM(CLM_ADJ_AMT142)+'~'+RTRIM(CLM_ADJ_QTY142)+'~'+RTRIM(CLM_ADJ_REASON143)+'~'+RTRIM(CLM_ADJ_AMT143)+'~'+RTRIM(CLM_ADJ_QTY143)  
			+'~'+RTRIM(CLM_ADJ_REASON144)+'~'+RTRIM(CLM_ADJ_AMT144)+'~'+RTRIM(CLM_ADJ_QTY144)+'~'+RTRIM(CLM_ADJ_REASON145)+'~'+RTRIM(CLM_ADJ_AMT145)+'~'+RTRIM(CLM_ADJ_QTY145)+'~'+RTRIM(CLM_ADJ_REASON146)+'~'+RTRIM(CLM_ADJ_AMT146)+'~'+RTRIM(CLM_ADJ_QTY146)  
			+'~'+RTRIM(CLM_ADJ_GRP15)+'~'+RTRIM(CLM_ADJ_REASON151)+'~'+RTRIM(CLM_ADJ_AMT151)+'~'+RTRIM(CLM_ADJ_QTY151)+'~'+RTRIM(CLM_ADJ_REASON152)+'~'+RTRIM(CLM_ADJ_AMT152)+'~'+RTRIM(CLM_ADJ_QTY152)+'~'+RTRIM(CLM_ADJ_REASON153)+'~'+RTRIM(CLM_ADJ_AMT153)+'~'+RTRIM(CLM_ADJ_QTY153)  
			+'~'+RTRIM(CLM_ADJ_REASON154)+'~'+RTRIM(CLM_ADJ_AMT154)+'~'+RTRIM(CLM_ADJ_QTY154)+'~'+RTRIM(CLM_ADJ_REASON155)+'~'+RTRIM(CLM_ADJ_AMT155)+'~'+RTRIM(CLM_ADJ_QTY155)+'~'+RTRIM(CLM_ADJ_REASON156)+'~'+RTRIM(CLM_ADJ_AMT156)+'~'+RTRIM(CLM_ADJ_QTY156)  
			+'~'+RTRIM(OTH_PAYER1_ADJ_DT)  
---------institutional claim map revision  
			+'~'+replicate('~',1190)+''+RTRIM(OPT_REPT_IND1)+'~'+RTRIM(OPT_REPT_IND2)+'~'+RTRIM(OPT_REPT_IND3)+'~'+RTRIM(EPSDT_IND)+'~'+RTRIM(FAM_PLAN_IND)+'~'+RTRIM(OBSTET_ANES_UNITS)+'~'+RTRIM(OTH_PAYER1_PROC_CD_QUAL)+'~'+RTRIM(OTH_PAYER2_PROC_CD_QUAL)  
			+'~'+replicate('~',21)+' '+'^'  
		FROM OUTB_INST_DETAIL  
	--	if @@ERROR <> 0  
	--			begin  
	--				rollback   
	--			end  
	--COMMIT  
	--BUILD HRP CLAIM RECORD TYPE S - CLAIM SUPPORT DOCUMENTATION  
	--ASSIGN TO CLAIM HEADER AND CLAIM LINE  
	/*BEGIN TRANSACTION  
		INSERT INTO OUTB_INST_CLAIM_MAP  
		SELECT '4000',RTRIM(CLAIM_ID)+''+'9999'+'-'+'4000','S'+'~'+replicate('~',8)  
		FROM DBO.EXT_HRP_CLAIM  
			if @@ERROR <> 0  
				begin  
					rollback   
				end  
	COMMIT*/  
	--BUILD HRP CLAIM RECORD TYPE T - CLAIM TRAILOR  
	  
	  
	  
	--RESET PARAMETERS DUE TO CHKSUM VALIDATION  
		BEGIN   
		--SET @SUM_TOTAL_CHARGES = 0;  
		--SET @SUM_LINE_CHARGES = 0;  
		SET @TOTAL_PROF_CLM = (SELECT COUNT(*) FROM OUTB_INST_HEADER  
					where CLAIM_TYPE = 'P');  
		SET @TOTAL_INST_CLM = (SELECT COUNT(*) FROM OUTB_INST_HEADER  
					where CLAIM_TYPE = 'I');  
		SET @TOTAL_DENTAL_CLM = (SELECT COUNT(*) FROM OUTB_INST_HEADER  
					where CLAIM_TYPE = 'D');  
		SET @TOTAL_LINES = (SELECT COUNT(*) FROM OUTB_INST_DETAIL);  
		SET @SUM_TOTAL_CHARGES = (SELECT SUM(convert(MONEY, LTRIM(TOT_CHRG_AMT))) FROM OUTB_INST_HEADER);	  
		SET @SUM_LINE_CHARGES = (SELECT SUM(convert(MONEY, LTRIM(TOTAL_CHRG_AMT))) FROM OUTB_INST_DETAIL);				  
		SET @TOTAL_EOF_COUNT = (SELECT COUNT(*) + 2 FROM OUTB_INST_CLAIM_MAP);  
		SET @FOOTER = ('T'+'~'+RTRIM(@FILEID)+'~'+RTRIM(CONVERT(CHAR,@TOTAL_PROF_CLM))+'~'+RTRIM(CONVERT(CHAR, @TOTAL_INST_CLM))+'~'+RTRIM(CONVERT(CHAR, @TOTAL_DENTAL_CLM))  
				+'~'+RTRIM(CONVERT(CHAR, @TOTAL_LINES))+'~'+LTRIM(CONVERT(CHAR, @SUM_TOTAL_CHARGES))+'~'+LTRIM(CONVERT(CHAR, @SUM_LINE_CHARGES))  
				+'~'+LTRIM(CONVERT(CHAR, @TOTAL_EOF_COUNT))+''+'^');  
		SET @TOTAL_CLAIM = (SELECT COUNT(*) FROM OUTB_INST_HEADER);		  
		SET @SOURCEDATAKEY = (SELECT DISTINCT SOURCEDATAKEY FROM OUTB_INST_HEADER);  
		SET @FILEDESC   =  (SELECT RTRIM(SOURCEDESC) FROM SourceDataDim WHERE SourceDataKey = @SOURCEDATAKEY)+ '-'+ @CLAIMTYPE+ '-'+ RTRIM(@LOB);  
		END  
		  
		  
	  
--build HRP CLAIM FILE HEADER  
	--BEGIN TRANSACTION   
		 insert into OUTB_INST_CLAIM_MAP  
		values('1000','0','H'+'~'+'1.0.0'  
				+'~'+'Claim Encounter'  
				+'~'+'1.0.0'  
				+'~'+'Proprietary'  
				+'~'+'Encounter'  
				+'~'+'2.0.0'  
				+'~'+@FILESUBTYPE  
				+'~'+RTRIM(@FILEID)--'CLAIM'+''+RTRIM(@FILEID)  
				+'~'+  
				+'~'+@CREATEDT  
				+'~'+@PRODUCTINDICATOR  
				+'~'+'CIGNA-HSPR'  
				+'~'+'CIGNA-HSPR'  
				+'~'+@FILEDESC  
				+'~'+--Line of Business  
				+'~'+--State  
				+'~'+--reserved  
				+'~'+--reserved  
				+'~'+--reserved  
				+'~'+--reserved  
				+'^')  
		--			if @@ERROR <> 0  
		--	begin  
		--		rollback   
		--	end  
		--commit	  
		  
		  
		  
	--BEGIN TRANSACTION  
		INSERT INTO OUTB_INST_CLAIM_MAP  
		values('5000','9999','T'+'~'+@FILEID/*'CLAIM'+''+RTRIM(@FILEID)*/+'~'+RTRIM(CONVERT(CHAR,@TOTAL_PROF_CLM))+'~'+RTRIM(CONVERT(CHAR, @TOTAL_INST_CLM))+'~'+RTRIM(CONVERT(CHAR, @TOTAL_DENTAL_CLM))  
				+'~'+RTRIM(CONVERT(CHAR, @TOTAL_LINES))+'~'+lTRIM(CONVERT(CHAR, @SUM_TOTAL_CHARGES))+'~'+lTRIM(CONVERT(CHAR, @SUM_LINE_CHARGES))  
				+'~'+lTRIM(CONVERT(CHAR, @TOTAL_EOF_COUNT))+''+'^')   
	--	if @@ERROR <> 0  
	--			begin  
	--				rollback   
	--			end  
	--COMMIT  
	  
	------------------------------------------------------------------------------------------------------------  
	--  
	--		----- HRP MAP AUDITING  
	--		----- COUNT TOTAL DELIMITERS '~' FOR EACH SEGEMENT OF FILE  
	--  
	------------------------------------------------------------------------------------------------------------  
		BEGIN  
				SET @HEADER_CNTRL = (select  distinct dbo.countrecorddelimter(datarow,'~') from OUTB_INST_CLAIM_MAP Where RECORDTYPEID = '1000');  
				SET @FOOTER_CNTRL = (select  distinct dbo.countrecorddelimter(datarow,'~') from OUTB_INST_CLAIM_MAP Where RECORDTYPEID = '5000');  
				SET @RECHEADER_CNTRL = (select  distinct dbo.countrecorddelimter(datarow,'~') from OUTB_INST_CLAIM_MAP Where RECORDTYPEID = '2000');  
				SET @RECDTL_CNTRL = (select  distinct dbo.countrecorddelimter(datarow,'~') from OUTB_INST_CLAIM_MAP Where RECORDTYPEID = '3000');  
				SET @RECOTH_CNTRL = (select  distinct dbo.countrecorddelimter(datarow,'~') from OUTB_INST_CLAIM_MAP Where RECORDTYPEID = '4000');  
				SET @FILE_TYPE = 'Claim Encounter';  
				SET @VERSION = '2.0.0';  
				  
		END  
  
  
  
	--CREATE OUTB_FILE_HIST   
	--RETRIEVE FILE HEADER INFORMATION  
	--BEGIN TRANSACTION  
				INSERT INTO OUTB_FILE_HIST  
				SELECT	@FILEID,GETDATE(),NULL,RTRIM(DATAROW),NULL,GETDATE(),@HEADER_CNTRL  
						,@FOOTER_CNTRL,@RECHEADER_CNTRL,@RECDTL_CNTRL,@RECOTH_CNTRL,@FILE_TYPE,@VERSION  
						,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL  
						,NULL,NULL,NULL,NULL,@TOTAL_CLAIM,@SOURCEDATAKEY,NULL,NULL,NULL,@FILEDESC+'-' + 'JobId' + '-' + convert(char,(@JOBID))  
				FROM OUTB_INST_CLAIM_MAP  
				WHERE RECORDTYPEID = '1000'  
	--			if @@ERROR <> 0  
	--			begin  
	--				rollback   
	--			end  
	--COMMIT  
	--UPDATE FILE FOOTER INFORMATION  
	--BEGIN TRANSACTION   
				UPDATE OUTB_FILE_HIST  
				SET FILEFOOTER = @FOOTER  
				WHERE RTRIM(FILEHEADER) IN (SELECT RTRIM(DATAROW)  
						FROM OUTB_INST_CLAIM_MAP  
						WHERE RECORDTYPEID =  '1000')  
	--			if @@ERROR <> 0  
	--			begin  
	--				rollback   
	--			end  
	--COMMIT  
	--APPEND ALL CLAIMS TO OUTB_INST_HEADER_STATUS TABLE FOR CLAIM LEVEL STATUS TRACKING  
	--BEGIN TRANSACTION   
				INSERT INTO OUTB_CLAIM_STATUS  
				SELECT CLAIM_ID,CLAIM_TYPE,@FILEID,CLM_IND,SOURCEDATAKEY,MEMBER_ID  
						,HICN_NUM,BILL_PROV_GRP_ID,BILL_PROV_ID,REF_PROV_ID,' '  
						,ATTN_PROV_ID,NULL,NULL,NULL,NULL,NULL  
						,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,@CREATEDT,GETDATE(),SUBSTRING(STATE_BEGIN_DT,1,6)  
						,null,null,null  
				FROM OUTB_INST_HEADER  
				--WHERE @FILEID NOT IN (SELECT DISTINCT FILEID FROM OUTB_CLAIM_STATUS)	  
	--			if @@ERROR <> 0  
	--			begin  
	--				rollback   
	--			end  
	--COMMIT  
	end  
  
			-- Append outbound file history   
			execute pr_ClaimInstitutionalExtractHistoryInsert @FILEID  
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RESEND  
							   
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_CLAIM_MAP)  
		----HRP_CLAIM_FILE Update Run Controls  
				--BEGIN TRANSACTION  
						UPDATE EXT_SYS_RUNLOG  
						SET END_DT = GETDATE()	  
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())  
							,TOTAL_RECORDS = @TOTAL_RECORDS  
							,ENTRYDT = GETDATE()  
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_MAP'  
								AND END_DT IS NULL  
						--	IF @@ERROR <> 0  
						--				BEGIN   
						--						ROLLBACK   
						--				END  
						--COMMIT  
  
  
  
