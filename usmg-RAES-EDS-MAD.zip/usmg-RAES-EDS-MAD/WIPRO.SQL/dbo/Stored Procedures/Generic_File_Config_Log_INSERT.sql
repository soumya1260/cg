﻿/*
This procedure is used by the SSIS package Main_Execute_Package to log the config strings passed to it.
Create date 08/30/2023
Author: ASU
-------------------------------------------------------------------------------------------------------
Notes:

*/

CREATE PROCEDURE [dbo].[Generic_File_Config_Log_INSERT]
	@Run_JobConfig_Name varchar(255),
	@Run_String varchar(800)
AS
	DECLARE @Job TABLE ( Job_ID INT NULL);

	INSERT INTO dbo.Generic_File_Config_Log ([Run_Job_Config_Name])
	OUTPUT INSERTED.Job_ID INTO @Job
	SELECT @Run_JobConfig_Name
	EXCEPT
	SELECT
		gfcl.[Run_Job_Config_Name]
	FROM dbo.Generic_File_Config_Log gfcl;

	IF NOT EXISTS (SELECT * FROM @Job) BEGIN  	
		INSERT INTO @Job (Job_ID)
		SELECT TOP 1 
			gfcl.Job_ID 
		FROM dbo.Generic_File_Config_Log gfcl 
		WHERE gfcl.[Run_Job_Config_Name] = @Run_JobConfig_Name;
	END;

	INSERT INTO dbo.Generic_File_Config_Log_Detail 
		(FK_JOB_ID, Run_String, Run_Date)
	SELECT	
		FK_JOB_ID = (SELECT TOP 1 Job_ID FROM @Job)
	   ,Run_String = @Run_String
	   ,Run_Date = GETDATE();
