﻿CREATE PROCEDURE [dbo].[EDS_Claims_Processing_MERGE_Config]

AS BEGIN;
/*
This procedure will update the config table (EDS_Claims_Processing) when called.
New items are inserted and marked new with a default of not submittable (don't submit things not ready yet)
Items marked NEW will be called out in notification later.

NOTES:
2024-06-25		ASU
	Initial Creation
		See Git repo https://github.sys.cigna.com/cigna/RAES-EDS-MAD for changes tagged to RETM-588
2024-10-16		ASU
	Account for nulls present in joins

---------------------------

*/
SET NOCOUNT ON;

WITH config_update AS (
SELECT 
	ecpa.CLAIM_TYPE
   ,ecpa.LOB
   ,ecpa.LOB_CODE
   ,ecpa.SOURCEDATAKEY
   ,ecpa.ISDENIED
   ,ecpa.ISDME
   ,ecpa.ISDMR
   ,ecpa.ISADJUSTMENT 
   ,ecpa.ISEncounter
   ,ENCOUNTERSOURCENAME = iif(ecpa.ISEncounter = 1,ecpa.ENCOUNTERSOURCENAME,NULL)
   ,clm_counts = COUNT(IIF(ecpa.MEDICARESUBMISSIONDATE IS NULL,1,NULL))
   ,ISNEW = 1 --<<-- Default to 1 (if new)
   ,ISSUBMITTABLE = 0 --<<-- Default to 0 
   ,FIRSTSEENDATE = GETDATE()
   ,MODIFIEDDATE = GETDATE()
FROM WIPRO.dbo.EDS_Claims_Processing ecpa
WHERE 1 = 1
	AND ecpa.ISMEDICARE = 1
GROUP BY 
	ecpa.CLAIM_TYPE
   ,ecpa.LOB
   ,ecpa.LOB_CODE
   ,ecpa.SOURCEDATAKEY   
   ,ecpa.ISDENIED
   ,ecpa.ISDME
   ,ecpa.ISDMR
   ,ecpa.ISADJUSTMENT
   ,ecpa.ISMEDICAID
   ,ecpa.ISMEDICARE
   ,ecpa.ISEncounter
   ,IIF(ecpa.ISEncounter = 1,ecpa.ENCOUNTERSOURCENAME,NULL)
)
MERGE dbo.EDS_Claims_Processing_MEDICARE_CONFIG target
USING config_update AS source
	ON  source.CLAIM_TYPE = target.CLAIM_TYPE --not null
		AND source.LOB = target.LOB	--not null
		AND source.SOURCEDATAKEY = target.SOURCEDATAKEY --not null
		AND ((source.LOB_CODE = target.LOB_CODE) OR (source.LOB_CODE IS NULL AND source.LOB_CODE IS NULL))	--nullable
		AND ((source.ISDENIED = target.ISDENIED) OR (source.ISDENIED IS NULL AND target.ISDENIED IS NULL)) --nullable
		AND ((source.ISDME = target.ISDME) OR (source.ISDME IS NULL AND target.ISDME IS NULL))	--nullable
		AND ((source.ISDMR = target.ISDMR) OR (source.ISDMR IS NULL AND target.ISDMR IS NULL))	--nullable
		AND ((source.ISADJUSTMENT = target.ISADJUSTMENT) OR (source.ISADJUSTMENT IS NULL AND target.ISADJUSTMENT IS NULL))	--nullable
		AND ((source.ISEncounter = target.ISENCOUNTER) OR (source.ISEncounter IS NULL AND target.ISENCOUNTER IS NULL)) --nullable
		AND ((source.ENCOUNTERSOURCENAME = target.ENCOUNTERSOURCENAME) OR (source.ENCOUNTERSOURCENAME IS NULL AND target.ENCOUNTERSOURCENAME IS NULL))
WHEN MATCHED AND SOURCE.clm_counts != target.COUNTS THEN UPDATE --<<-- update counts if number differs from last run
SET TARGET.MODIFIEDDATE = GETDATE(), TARGET.COUNTS = source.clm_counts
WHEN NOT MATCHED THEN INSERT
 (CLAIM_TYPE, LOB, LOB_CODE, SOURCEDATAKEY, ISDENIED, ISDME, ISDMR, ISADJUSTMENT, ISENCOUNTER, ENCOUNTERSOURCENAME, COUNTS,
ISNEW, ISSUBMITTABLE, FIRSTSEENDATE, MODIFIEDDATE)
VALUES	(source.CLAIM_TYPE
   ,source.LOB
   ,source.LOB_CODE
   ,source.SOURCEDATAKEY
   ,source.ISDENIED
   ,source.ISDME
   ,source.ISDMR
   ,source.ISADJUSTMENT 
   ,source.ISEncounter
   ,source.ENCOUNTERSOURCENAME
   ,source.clm_counts
   ,source.ISNEW 
   ,source.ISSUBMITTABLE
   ,GETDATE()
   ,GETDATE());
END;

--If items marked as new older than 7 days, remove NEW flag
UPDATE ecpmc
SET ISNEW = 0,
	MODIFIEDDATE = GETDATE()
FROM dbo.EDS_Claims_Processing_MEDICARE_CONFIG ecpmc
WHERE DATEDIFF(DAY,ecpmc.FIRSTSEENDATE,GETDATE()) >= 7;
