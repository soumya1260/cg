﻿CREATE PROCEDURE sp_JobExecutionCheck
AS 

DECLARE @wait INT
CHECK_FOR_RUNNING_JOB:

    IF OBJECT_ID('TEMPDB..#RUNNING') IS NOT NULL 
        DROP TABLE #RUNNING

--check for currently running jobs that can cause a conflict
    SELECT TOP (1)
        j.name AS job_name ,
        last_executed_step_id ,
        ja.start_execution_date ,
        ISNULL(last_executed_step_id, 0) + 1 AS current_executed_step_id ,
        DATEADD(minute, 120, start_execution_date) AS current_expected_completion , --giving 120 minutes to complete before rechecking
        Js.step_name
    INTO
        #running
    FROM
        msdb.dbo.sysjobactivity ja
        LEFT JOIN msdb.dbo.sysjobhistory jh
        ON ja.job_history_id = jh.instance_id
        JOIN msdb.dbo.sysjobs j
        ON ja.job_id = j.job_id
        JOIN msdb.dbo.sysjobsteps js
        ON ja.job_id = js.job_id
           AND ISNULL(ja.last_executed_step_id, 0) + 1 = js.step_id
    WHERE
        ja.session_id = (
                         SELECT TOP 1
                            session_id
                         FROM
                            msdb.dbo.syssessions
                         ORDER BY
                            agent_start_date DESC
                        )
        AND start_execution_date IS NOT NULL
        AND stop_execution_date IS NULL
        AND (j.name LIKE 'EDS WIPRO - %'
             OR j.name LIKE 'refresh%'
            )


 

    IF @@rowcount >= 0 --oops there's a running job so let's wait for a while
        SET @wait =  300

 

    IF @WAIT > 0 --there is a job running so we will pause this process'
        BEGIN 
            WAITFOR DELAY @wait 
			SET @wait = 0
           GOTO CHECK_FOR_RUNNING_JOB -- loop back up and check again after we wait
        END
 
  --yay we have no more running jobs so let's see if we have time to run our job before the next scheduled job starts

CHECK_FOR_SCHEDULED_JOB:


    SET @WAIT = 0

 --CHECK TO SEE IF THERE IS ENOUGH TIME TO RUN THE JOB BEFORE THE NEXT SCHEDULED JOB STARTS

    IF (
        SELECT
            DATEDIFF(MINUTE,
                     MIN(CASE [jobschedule].[next_run_date]
                           WHEN 0 THEN CONVERT(DATETIME, '1900/1/1')
                           ELSE CONVERT(DATETIME, CONVERT(CHAR(8), [jobschedule].[next_run_date], 112)
                                + ' ' + STUFF(STUFF(RIGHT('000000'
                                                          + CONVERT(VARCHAR(8), [jobschedule].[next_run_time]),
                                                          6), 5, 0, ':'), 3, 0,
                                              ':'))
                         END), GETDATE()) - 120
        FROM
            [msdb].[dbo].[sysjobs] AS [jobs] WITH (NOLOCK)
            INNER JOIN [msdb].[dbo].[sysjobschedules] AS [jobschedule] WITH (NOLOCK)
            ON [jobs].[job_id] = [jobschedule].[job_id]
            INNER  JOIN [msdb].[dbo].[sysschedules] AS [schedule] WITH (NOLOCK)
            ON [jobschedule].[schedule_id] = [schedule].[schedule_id]
        WHERE
            [jobs].[enabled] = 1
            AND [schedule].[enabled] = 1
            AND (jobs.name LIKE 'EDS WIPRO - %'
                 OR jobs.name LIKE 'refresh%'
                )
       ) > 0 
        GOTO EXIT_PROCEDURE -- no jobs running and no jobs are scheduled to run within two hours
    
	
	SET @wait = 600 -- lets wait a while then check again

--oops we don't have enough time to run our job as one is scheduled to start before our job can complete
    IF @WAIT > 0 --there is a job scheduled so we will pause this process'
        BEGIN 
            WAITFOR DELAY @wait 
            PRINT @wait
            GOTO CHECK_FOR_RUNNING_JOB -- loop back up and check for completion of the job and check for another scheduled job
			
        END





EXIT_PROCEDURE:
	
 --there is no running job nor is there a scheduled job, let's start processing!


 