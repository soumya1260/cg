﻿
												
												
 CREATE procedure [dbo].[pr_Build_EDS_Master_Claim_Status_Exclusions]
 (@ENTRYDT DATETIME)
AS
/***************************************************************************************************
** CREATE DATE: 05/2016
**
** AUTHOR: LOYAL RICKS - Loyal Ricks 
**
** DESCRIPTION: Procedure Updates EDS_MASTER_CLAIM_STATUS table , EDS_STATUS & EDS_STATUS_DT COLUMNS
**				with all current exclusion codes for each individual claim.
**
**
**
**
**
**
**
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------

*****************************************************************************************************/													
												
												
		DECLARE 
				@TOTAL_RECORDS INT										
												
												
									INSERT INTO EXT_SYS_RUNLOG
									(PROC_NAME
									,STEP
									,START_DT
									,END_DT
									,RUN_MINUTES
									,TOTAL_RECORDS
									,ENTRYDT
									)
									VALUES('pr_Build_EDS_Master_Claim_Status_Exclusions'
											,'6000'
											,GETDATE()
											,NULL
											,NULL
											,0
											,GETDATE()
											)
											
											IF OBJECT_ID('TEMPDB..#DP_EXCL') <> 0
													DROP TABLE #DP_EXCL

												CREATE TABLE #DP_EXCL
												(
												EXCL_ID INT
												)

												INSERT INTO #DP_EXCL		
												select CONVERT(INT, substring(cntrl_txt,6,4))
												from EXT_SYS_CLM_JOBCNTRL
												where sourcedatakey = 999999999

												---Add Verisk Submissions to #DP_EXCL
												
												insert into #DP_EXCL
												VALUES(999999999)

												IF OBJECT_ID('TEMPDB..#EXCL_ID') <> 0
													DROP TABLE #EXCL_ID

												CREATE TABLE #EXCL_ID
												(
												EXCL_ID INT
												)

												INSERT INTO #EXCL_ID
												SELECT EXCL_ID 
												FROM ClaimExclusionCode
												WHERE EXCL_ID <> 999999999

												DELETE FROM #EXCL_ID
												WHERE EXCL_ID IN (SELECT EXCL_ID FROM #DP_EXCL)

						
												IF OBJECT_ID('TEMPDB..#tmp_excl') <> 0
													DROP TABLE #tmp_excl

												CREATE TABLE #tmp_excl
												(
														sourcedatakey int,
														claim_id varchar(20),
														excl_id INT,
														SEQ INT
												)

												insert into #tmp_excl
												select sourcedatakey,
														claim_id,
														H.excl_id,
														row_number() over (partition by sourcedatakey,claim_id order by sourcedatakey,claim_id) as seq
												from ext_claim_exclusion_hist H
												INNER JOIN #EXCL_ID E
												ON H.EXCL_ID = E.EXCL_ID 
												group by sourcedatakey,
														claim_id,
														h.excl_id


												------CURSOR SP 
													IF OBJECT_ID('TEMPDB..#tmp_clm_excl') <> 0
													DROP TABLE #tmp_clm_excl

												CREATE TABLE #tmp_clm_excl
												(		sourcedatakey int,
														claimid varchar(20),
														EDS_STATUS VARCHAR(255)
												)

												INSERT INTO #TMP_CLM_EXCL 
												SELECT DISTINCT 
														T.SOURCEDATAKEY,
														T.claim_id,
														''
												FROM #tmp_excl  T
												INNER JOIN EDS_MASTER_CLAIM_STATUS C
												ON T.SOURCEDATAKEY = C.SOURCEDATAKEY 
												AND T.CLAIM_ID = C.CLAIMID
												order by T.sourcedatakey,
														T.claim_id
												DECLARE

												@SEQ INT
						
												DECLARE C_EXCL CURSOR 
												FOR	SELECT MIN(SEQ)
												FROM #tmp_excl
											
												open C_EXCL
												FETCH NEXT FROM C_EXCL INTO @SEQ
												wHILE @@FETCH_STATUS = 0 
												BEGIN

													UPDATE #tmp_clm_excl
													SET EDS_STATUS = RTRIM(EDS_STATUS) +'-'+ RTRIM(CONVERT(CHAR, T.EXCL_ID))--,
														--EDS_STATUS_DT = GETDATE() ----@ENTRYDT
													FROM #tmp_clm_excl C
													INNER JOIN #tmp_excl T
													ON T.SOURCEDATAKEY = C.SOURCEDATAKEY 
													AND T.CLAIM_ID = C.CLAIMID 
													WHERE T.SEQ = @SEQ
												
													delete #tmp_excl
													WHERE SEQ = @SEQ
												--end
										FETCH NEXT FROM C_EXCL INTO @SEQ
												 	end
												close C_EXCL
												DEALLOCATE C_EXCL

												update EDS_MASTER_CLAIM_STATUS 
												SET EDS_STATUS = SUBSTRING(T.EDS_STATUS,2,LEN(T.EDS_STATUS)),
													EDS_STATUS_DT = @ENTRYDT
												FROM #tmp_clm_excl T
												inner join EDS_MASTER_CLAIM_STATUS C
												ON T.SOURCEDATAKEY = C.SOURCEDATAKEY 
												AND T.CLAIMID = C.CLAIMID


								SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EDS_MASTER_CLAIM_STATUS
														WHERE EDS_STATUS NOT IN ('P','A','R',' '))

							UPDATE EXT_SYS_RUNLOG
										SET END_DT = GETDATE()	
											,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
											,TOTAL_RECORDS = @TOTAL_RECORDS
											,ENTRYDT = GETDATE()
										WHERE PROC_NAME = 'pr_Build_EDS_Master_Claim_Status_Exclusions'
													AND END_DT IS NULL
