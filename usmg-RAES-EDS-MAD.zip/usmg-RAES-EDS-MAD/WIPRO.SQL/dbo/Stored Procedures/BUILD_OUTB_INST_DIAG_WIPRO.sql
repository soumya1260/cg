﻿













--
						
CREATE PROCEDURE [dbo].[BUILD_OUTB_INST_DIAG_WIPRO]
(@SOURCEDATAKEY INT)
AS
/***************************************************************************************************
** CREATE DATE: 06/2012
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM HEADER 
**              AND LINE LEVE DIAGNOSIS CODE INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
2012-10-19		Dwight Staggs	Remove database name from table references
2013-03-22		Loyal Ricks		Revised Diag. 1-9 update to include appropriate logic for sequence
								number in join. Facets uses 1 char '1', all others using '01' for 
								claim header updates (OUTB_PROF_HEADER)
2013-04-26		Loyal Ricks		Revised Diag. 1-9 update to include appropriate logic for sequence
								number in join. Facets uses 1 char '1', all others using '01' for 
								claim detail updates (OUTB_PROF_DETAIL)
2013-05-16		Loyal Ricks		Added Facets OUTB_PROF_DETAIL Update Logic (line level diagnosis
								& pointer info)
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation		
2014-07-31		Loyal Ricks		Added Qualifier Codes (Principal, Institutional Visit, Daig Code) and 
								logic for updating appropriate codes for this sp.	
2014-11-19		Loyal Ricks		WIPRO Pointer revision, revise pointer logic to be sequential in order 
								and not be the actual pointer to the diagnosis submission.	
2015-02-09		Loyal Ricks		EDS-706 Facets professional Claim integration - evaluate @sourcedatakey in 
								order to determine appropriate DX selection criteria for each sdk. QNXT and
								MHC use same code blocks, Facets uses indepeent code block. 		
2015-02-25		Loyal Ricks		EDS-711 Replace all diagnosis code values of 'UNKNOWN' with a blank value.	
				Loyal Ricks		Performance and fine tuning - removal of explicit transactions	
2015-10-31		Loyal Ricks		TETDM-438 Professional Claim ICD10 Revisions- Revise #claimdetaildiagnosisdim.daignosiscode to varchar10 
2015-10-28		Loyal Ricks		TETDM-438 ICD-10 Qualifier Revisions		
2016-03-01		Loyal Ricks		Realign DIAG_CD shifting DIAG_CD 2-30 up to populate DIAG_CD1 -30. Institutional primary diagnosis code
								is assigned for Institutional claims so outbound file DIAG_CD1 should be populated by DIAG_CD2 (SEQUENCE = 2) 
								from BIDW source claimdiagnosisdim	
2017-08-10      Henry Faust		Added logic to only ouput uique diagnosis codes. 	
2019-12-05      Henry Faust     TETDM-2184 get DX codes when sequence is >30 (47 max)	
                                 also removed a bunch of commented out code.																												    
*****************************************************************************************************/		
--UPDATE DIAGNOSIS POINTERS
		--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM OUTB_PROF_HEADER_RES
			DECLARE
			
			@TOTAL_HEADER_RECORDS INT,
			@TOTAL_DETAIL_RECORDS INT,
			@TOTAL_RECORDS INT
--HRP_CLAIM_FILE Run controls
INSERT INTO EXT_SYS_RUNLOG
		(PROC_NAME
		,STEP
		,START_DT
		,END_DT
		,RUN_MINUTES
		,TOTAL_RECORDS
		,ENTRYDT
		)
		VALUES('BUILD_OUTB_INST_DIAG_WIPRO'
				,'4'
				,GETDATE()
				,NULL
				,NULL
				,0
				,GETDATE()
				)
	IF OBJECT_ID('TEMPDB..#claimdetaildiagnosisdim') <> 0
					DROP TABLE #claimdetaildiagnosisdim
					
					CREATE TABLE #claimdetaildiagnosisdim
					(  claimid varchar(20)
						,CLAIMLINEID varchar(4)
						,DIAGNOSISCODE varchar(10)
						,SEQUENCE int
					)


EXECUTE dbo.BUILD_OUTB_INST_INSERT_CCCR  --1632



--UPDATE DIAGNOSIS CODES
-- 1632 we dont need to change anything for primary diag code.
			--UPDATE OUTB_INST_HEADER
			--SET  INST_PRINCIPAL_DIAG_CD = dgcd
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('01','1')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 1

			UPDATE OUTB_INST_HEADER
			SET  INST_PRINCIPAL_DIAG_CD =  REPLACE( dgcd,'.','')			
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON e.CLAIM_ID = cccr.claim_id   AND cccr.rownum = 1




---- HF 1632 additions  CD1
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD1 = dgcd,
			--    POA_IND1 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--    DIAG_CD_QUAL1 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('01','1')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 2

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD1 = CASE WHEN dgcd IS NULL THEN '' ELSE  REPLACE( dgcd,'.','') end ,
--			SET  DIAG_CD1 =   REPLACE( dgcd,'.','')  ,
                            POA_IND1 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL1 = 'BF'				
			FROM OUTB_INST_HEADER E
			  left JOIN OUTB_INST_CCCR cccr ON  e.CLAIM_ID = cccr.claim_id   AND cccr.rownum = 2
			 WHERE cccr.ROWNUM IS NOT NULL  


---- HF 1632 additions  CD2
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD2 = cccr.dgcd,
			--    POA_IND2 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL2 = 'BF'
				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('02','2')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 3									

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD2 =REPLACE( dgcd,'.',''),
                            POA_IND2 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL2 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON  e.CLAIM_ID = cccr.claim_id  AND cccr.rownum = 3
			 WHERE cccr.ROWNUM IS NOT NULL  

---- HF 1632 additions  CD3
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD3 = cccr.dgcd
			--    ,POA_IND3 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL3 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('03','3')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 4	

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD3 =REPLACE( dgcd,'.',''),
                            POA_IND3 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL3 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON  e.CLAIM_ID = cccr.claim_id   AND cccr.rownum = 4
			 WHERE cccr.ROWNUM IS NOT NULL  

-- HF 1632 additions  CD4
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD4 = cccr.dgcd
			--    ,POA_IND4 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL4 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('04','4')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 5			

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD4 =REPLACE( dgcd,'.',''),
                            POA_IND4 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL4 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON  e.CLAIM_ID = cccr.claim_id   AND cccr.rownum = 5		
			 WHERE cccr.ROWNUM IS NOT NULL  


---- HF 1632 additions  CD5
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD5 = cccr.dgcd
			--    ,POA_IND5 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL5 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('05','5')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 6					

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD5 =REPLACE( dgcd,'.',''),
                            POA_IND5 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL5 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON  e.CLAIM_ID = cccr.claim_id   AND cccr.rownum = 6	
			 WHERE cccr.ROWNUM IS NOT NULL  
			
---- HF 1632 additions  CD6
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD6 = cccr.dgcd
			--    ,POA_IND6 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL6 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('06','6')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 7				

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD6 =REPLACE( dgcd,'.',''),
                            POA_IND6 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL6 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON  e.CLAIM_ID = cccr.claim_id   AND cccr.rownum = 7			
			 WHERE cccr.ROWNUM IS NOT NULL  

			
---- HF 1632 additions  C7
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD7 = cccr.dgcd
			--    ,POA_IND7 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL7 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('07','6')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 8				

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD7 =REPLACE( dgcd,'.',''),
                            POA_IND7 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL7 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON  e.CLAIM_ID = cccr.claim_id   AND cccr.rownum = 8					 
			 WHERE cccr.ROWNUM IS NOT NULL  
			

			
---- HF 1632 additions  C8
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD8 = cccr.dgcd
			--    ,POA_IND8 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL8= 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('08','8')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 9					

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD8 =REPLACE( dgcd,'.',''),
                            POA_IND8 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL8 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON  e.CLAIM_ID = cccr.claim_id   AND cccr.rownum = 9					 
			 WHERE cccr.ROWNUM IS NOT NULL  
			
		

---- HF 1632 additions  C9
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD9 = cccr.dgcd
			--    ,POA_IND9 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL9= 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('09','9')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 10				

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD9 =REPLACE( dgcd,'.',''),
                            POA_IND9 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL9 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON  e.CLAIM_ID = cccr.claim_id   AND cccr.rownum = 10					 
			 WHERE cccr.ROWNUM IS NOT NULL  

			
------ HF 1632 additions  C10
--			--UPDATE OUTB_INST_HEADER
--			--SET  DIAG_CD10 = cccr.dgcd
--			--    ,POA_IND10 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
--			--	DIAG_CD_QUAL10= 'BF'				
--			--FROM OUTB_INST_HEADER E
--			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
--			--	,OUTB_INST_CCCR cccr
--			--WHERE E.CLAIM_ID = CDG.CLAIMID 
--			--	AND CDG.SEQUENCE in ('10')	
--			--	AND cccr.claim_id = e.CLAIM_ID
--			--	AND cccr.rownum = 11			

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD10 =REPLACE( dgcd,'.',''),
                            POA_IND10 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL10 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 11					 
			 WHERE cccr.ROWNUM IS NOT NULL  

			
			
---------------------------------------11 to 20 -----------------				 
---- HF 1632 additions  CD11
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD11 = dgcd,
			--    POA_IND11 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--    DIAG_CD_QUAL11 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('11')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 12

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD11 =REPLACE( dgcd,'.',''),
                            POA_IND11 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL11 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 12				
			 WHERE cccr.ROWNUM IS NOT NULL  

---- HF 1632 additions  CD12
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD12 = cccr.dgcd,
			--    POA_IND12 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL12 = 'BF'
				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('12')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 13									

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD12 =REPLACE( dgcd,'.',''),
                            POA_IND12 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL12 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 13			
			 WHERE cccr.ROWNUM IS NOT NULL  


---- HF 1632 additions  CD13
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD13 = cccr.dgcd
			--    ,POA_IND13 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL13 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE  = '13'	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 14	

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD13 =REPLACE( dgcd,'.',''),
                            POA_IND13 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL13 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 14			
			 WHERE cccr.ROWNUM IS NOT NULL  

			
---- HF 1632 additions  CD14
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD14 = cccr.dgcd
			--    ,POA_IND14 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL14 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('14')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 15			

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD14 =REPLACE( dgcd,'.',''),
                            POA_IND14 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL14 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 15			
			 WHERE cccr.ROWNUM IS NOT NULL  


---- HF 1632 additions  CD15
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD15 = cccr.dgcd
			--    ,POA_IND15 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL15 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('15')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 16					

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD15 =REPLACE( dgcd,'.',''),
                            POA_IND15 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL15 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 16				
			 WHERE cccr.ROWNUM IS NOT NULL  
		

			
---- HF 1632 additions  CD16
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD16 = cccr.dgcd
			--    ,POA_IND16 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL16 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('16')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 17				

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD16 =REPLACE( dgcd,'.',''),
                            POA_IND16 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL16 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 17			
			 WHERE cccr.ROWNUM IS NOT NULL  

			
			
---- HF 1632 additions  C17
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD17 = cccr.dgcd
			--    ,POA_IND17 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL17 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('17')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 18				

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD17 =REPLACE( dgcd,'.',''),
                            POA_IND17 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL17 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 18					 
			 WHERE cccr.ROWNUM IS NOT NULL  
			

			
---- HF 1632 additions  C18
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD18 = cccr.dgcd
			--    ,POA_IND18 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL18= 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('18')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 19					

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD18 =REPLACE( dgcd,'.',''),
	                            POA_IND18 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL18 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 19					 
			 WHERE cccr.ROWNUM IS NOT NULL  

			
---- HF 1632 additions  C19
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD19 = cccr.dgcd
			--    ,POA_IND19 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL19= 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('19')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 20				

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD19 =REPLACE( dgcd,'.',''),
                            POA_IND19 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL19 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 20					 
			 WHERE cccr.ROWNUM IS NOT NULL  
			

			
---- HF 1632 additions  C20
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD20 = cccr.dgcd
			--    ,POA_IND20 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL20= 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('20')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 21			

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD20 =REPLACE( dgcd,'.',''),
                            POA_IND20 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL20 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 21
			 WHERE cccr.ROWNUM IS NOT NULL  
									 
---------------------------------------21 to 30 -----------------				 
---- HF 2501 additions  CD21
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD21 = dgcd,
			--    POA_IND21 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--    DIAG_CD_QUAL21 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('11')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 22

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD21 =REPLACE( dgcd,'.',''),
                            POA_IND21 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL21 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 22			
			 WHERE cccr.ROWNUM IS NOT NULL  

---- HF 2501 additions  CD22
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD22 = cccr.dgcd,
			--    POA_IND22 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL22 = 'BF'
				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('22')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 23									

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD22 =REPLACE( dgcd,'.',''),
                            POA_IND22 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL22 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 23		
			 WHERE cccr.ROWNUM IS NOT NULL  


---- HF 2501 additions  CD23
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD23 = cccr.dgcd
			--    ,POA_IND23 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL23 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE  = '23'	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 24	

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD23 =REPLACE( dgcd,'.',''),
                            POA_IND23 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL23 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 24		
			 WHERE cccr.ROWNUM IS NOT NULL  

			
---- HF 2501 additions  CD24
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD24 = cccr.dgcd
			--    ,POA_IND24 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL24 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('24')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 25			

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD24 =REPLACE( dgcd,'.',''),
                            POA_IND24 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL24 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 25		
			 WHERE cccr.ROWNUM IS NOT NULL  


---- HF 2501 additions  CD25
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD25 = cccr.dgcd
			--    ,POA_IND25 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL25 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('25')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 26					

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD25 =REPLACE( dgcd,'.',''),
                            POA_IND25 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL25 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 26			
			 WHERE cccr.ROWNUM IS NOT NULL  
		

			
---- HF 2501 additions  CD26
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD26 = cccr.dgcd
			--    ,POA_IND26 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL26 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('26')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 27				

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD26 =REPLACE( dgcd,'.',''),
                            POA_IND26 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL26 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 27		
			 WHERE cccr.ROWNUM IS NOT NULL  

			
			
---- HF 2501 additions  C27
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD27 = cccr.dgcd
			--    ,POA_IND27 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL27 = 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('27')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 28				

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD27 =REPLACE( dgcd,'.',''),
                            POA_IND27 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL27 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 28				 
			 WHERE cccr.ROWNUM IS NOT NULL  
			

			
---- HF 2501 additions  C28
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD28 = cccr.dgcd
			--    ,POA_IND28 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL28= 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('28')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 29					

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD28 =REPLACE( dgcd,'.',''),
                            POA_IND28 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL28 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 29				 
			 WHERE cccr.ROWNUM IS NOT NULL  

			
---- HF 2501 additions  C29
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD29 = cccr.dgcd
			--    ,POA_IND29 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL29= 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('29')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 30				

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD29 =REPLACE( dgcd,'.',''),
                            POA_IND29 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL29 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 30				 
			 WHERE cccr.ROWNUM IS NOT NULL  
			

			
---- HF 2501 additions  C30
			--UPDATE OUTB_INST_HEADER
			--SET  DIAG_CD30 = cccr.dgcd
			--    ,POA_IND30 = case CDG.POAind when 'Y' then 'Y' else 'N' END ,
			--	DIAG_CD_QUAL30= 'BF'				
			--FROM OUTB_INST_HEADER E
			--	,EDPS_Data.dbo.claimdiagnosisdim CDG
			--	,OUTB_INST_CCCR cccr
			--WHERE E.CLAIM_ID = CDG.CLAIMID 
			--	AND CDG.SEQUENCE in ('30')	
			--	AND cccr.claim_id = e.CLAIM_ID
			--	AND cccr.rownum = 31			

			UPDATE OUTB_INST_HEADER
			SET  DIAG_CD30 =REPLACE( dgcd,'.',''),
                            POA_IND29 =  CASE cccr.POAind 
		                          WHEN 'Y'  THEN 'Y'
			                  WHEN 'N'  THEN 'N'
			                  WHEN 'W'  THEN 'W'
			                  WHEN 'U'  THEN 'U'
		                      WHEN '-'  THEN ' '
		                          ELSE  ' ' 
		                        END,
			    DIAG_CD_QUAL30 = 'BF'				
			FROM OUTB_INST_HEADER E
			    JOIN OUTB_INST_CCCR cccr ON cccr.claim_id = e.CLAIM_ID AND cccr.rownum = 31				 						
			 WHERE cccr.ROWNUM IS NOT NULL  


----------------------------------------------------------------------------------------------------------





			
				--TETDM-438 ICD-10 Qualifier Revisions
	
				--TETDM-438 ICD-10 Qualifier Revisions
				--ICD-10 Principal Diag Qual
				Update OUTB_INST_HEADER 
				SET PRINCIPAL_DIAG_QUAL = 'A'+''+RTRIM(PRINCIPAL_DIAG_QUAL)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND H.PRINCIPAL_DIAG_QUAL = 'BK'


				--ICD-10 DIAG_CD_QUAL1
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL1 = 'A'+''+RTRIM(DIAG_CD_QUAL1)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL1 =  'BF'

				--ICD-10 DIAG_CD_QUAL2
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL2 = 'A'+''+RTRIM(DIAG_CD_QUAL2)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL2 =  'BF'


				--ICD-10 DIAG_CD_QUAL3
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL3 = 'A'+''+RTRIM(DIAG_CD_QUAL3)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL3=  'BF'

				--ICD-10 DIAG_CD_QUAL4
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL4 = 'A'+''+RTRIM(DIAG_CD_QUAL4)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL4 =  'BF'

				--ICD-10 DIAG_CD_QUAL5
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL5 = 'A'+''+RTRIM(DIAG_CD_QUAL5)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL5 =  'BF'

				--ICD-10 DIAG_CD_QUAL6
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL6 = 'A'+''+RTRIM(DIAG_CD_QUAL6)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL6 =  'BF'

				--ICD-10 DIAG_CD_QUAL7
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL7 = 'A'+''+RTRIM(DIAG_CD_QUAL7)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL7 =  'BF'

				--ICD-10 DIAG_CD_QUAL8
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL8 = 'A'+''+RTRIM(DIAG_CD_QUAL8)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL8 =  'BF'

				--ICD-10 DIAG_CD_QUAL9
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL9 = 'A'+''+RTRIM(DIAG_CD_QUAL9)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL9 =  'BF'

				--ICD-10 DIAG_CD_QUAL1
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL10 = 'A'+''+RTRIM(DIAG_CD_QUAL10)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL10 =  'BF'

				--ICD-10 DIAG_CD_QUAL11
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL11 = 'A'+''+RTRIM(DIAG_CD_QUAL11)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL11 =  'BF'

				--ICD-10 DIAG_CD_QUAL12
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL12 = 'A'+''+RTRIM(DIAG_CD_QUAL12)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL12 =  'BF'

				--ICD-10 DIAG_CD_QUAL13
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL13 = 'A'+''+RTRIM(DIAG_CD_QUAL13)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL13 =  'BF'

				--ICD-10 DIAG_CD_QUAL14
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL14 = 'A'+''+RTRIM(DIAG_CD_QUAL14)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL14 =  'BF'

				--ICD-10 DIAG_CD_QUAL15
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL15 = 'A'+''+RTRIM(DIAG_CD_QUAL15)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL15 =  'BF'

				--ICD-10 DIAG_CD_QUAL16
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL16 = 'A'+''+RTRIM(DIAG_CD_QUAL16)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL16 =  'BF'

				--ICD-10 DIAG_CD_QUAL17
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL17 = 'A'+''+RTRIM(DIAG_CD_QUAL17)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL17 =  'BF'

				--ICD-10 DIAG_CD_QUAL18
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL18 = 'A'+''+RTRIM(DIAG_CD_QUAL18)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL18 =  'BF'

				--ICD-10 DIAG_CD_QUAL19
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL19 = 'A'+''+RTRIM(DIAG_CD_QUAL19)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL19 =  'BF'

				--ICD-10 DIAG_CD_QUAL20
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL20 = 'A'+''+RTRIM(DIAG_CD_QUAL20)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL20 =  'BF'

				--ICD-10 DIAG_CD_QUAL21
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL21 = 'A'+''+RTRIM(DIAG_CD_QUAL21)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL21 =  'BF'

				--ICD-10 DIAG_CD_QUAL22
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL22 = 'A'+''+RTRIM(DIAG_CD_QUAL22)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL22 =  'BF'

				--ICD-10 DIAG_CD_QUAL23
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL23 = 'A'+''+RTRIM(DIAG_CD_QUAL23)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL23 =  'BF'

				--ICD-10 DIAG_CD_QUAL24
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL24 = 'A'+''+RTRIM(DIAG_CD_QUAL24)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL24 =  'BF'

				--ICD-10 DIAG_CD_QUAL25
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL25 = 'A'+''+RTRIM(DIAG_CD_QUAL25)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL25 =  'BF'

				--ICD-10 DIAG_CD_QUAL26
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL26 = 'A'+''+RTRIM(DIAG_CD_QUAL26)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL26 =  'BF'

				--ICD-10 DIAG_CD_QUAL27
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL27 = 'A'+''+RTRIM(DIAG_CD_QUAL27)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL27 =  'BF'

				--ICD-10 DIAG_CD_QUAL28
				Update OUTB_INST_HEADER 
				SET DIAG_CD_QUAL28 = 'A'+''+RTRIM(DIAG_CD_QUAL28)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL28 =  'BF'

				--ICD-10 DIAG_CD_QUAL29
				UPDATE OUTB_INST_HEADER 
				SET DIAG_CD_QUAL29 = 'A'+''+RTRIM(DIAG_CD_QUAL29)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL29 =  'BF'

				--ICD-10 DIAG_CD_QUAL30
				UPDATE OUTB_INST_HEADER 
				SET DIAG_CD_QUAL30 = 'A'+''+RTRIM(DIAG_CD_QUAL30)
				FROM OUTB_INST_HEADER H
				INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
				ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
				AND H.CLAIM_ID = CDD.CLAIMID 
				WHERE diagnosiscodeversion = '0'
					AND DIAG_CD_QUAL30 =  'BF'
			 
			
			
		
		
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_INST_HEADER_RES
			
			SET  @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_HEADER)		 
												
----HRP_CLAIM_FILE Update Run Controls
				
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'BUILD_OUTB_INST_DIAG_WIPRO'
							AND END_DT IS NULL
							
										
												 
										
						















