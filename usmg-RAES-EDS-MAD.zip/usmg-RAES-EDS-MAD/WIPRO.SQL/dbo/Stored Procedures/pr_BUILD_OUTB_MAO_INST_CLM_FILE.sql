﻿



CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_MAO_INST_CLM_FILE]
(@SOURCEDATAKEY INT, @LOB CHAR(10), @JOBID INT, @LOBCODE VARCHAR(15) = ' ')--, @REJ_REA_ID CHAR(8) = ' ')--,@BEGIN_BILLTYPECODE CHAR(5) , @END_BILLTYPECODE CHAR(5))
AS
/***************************************************************************************************
** CREATE DATE: 08/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL EXECUTE REQUIRD STEPS FOR COMPILING HRP MHC CLAIM SUBMISSIONS.
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.2. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
09/25/13		Loyal Ricks		Replaced call to EXSP_HRP_CLAIM_EDSPROVIDER_INST with call to 
								EXSP_HRP_CLAIM_INST_EDSPROVIDER
11/08/13		Loyal Ricks		Add bed type range input parameters
06/19/14		Loyal Ricks		Upgrade Verisk Map from V3.2 to V4.0 - EXSP_HRP_CLAIM_INST_MAP_V40
------------------------------------------------------------------------------------------------------
08/2014			Loyal Ricks		WIPRO Implementation
09/10/14		Loyal Ricks		EDS-396 - Add sp - pr_BUILD_OUTB_INST_WIPRO_DATASCRUB
09/23/14		Loyal Ricks		Add @LOB to be used during BUILD_OUTB_INST_MAP
07/10/15		Loyal Ricks		Add @LOBCODE to comply with SSIS package requirements supporting all 
								EDS lob. @LOBCODE required for MMAI submissions.
2015-07-23		Loyal Ricks		TETDM-276 Add JOBID to filedesc	
2016-02-18		Loyal Ricks		TETDM-643 Add claim header diagnosis codes 
2016-03-14		Loyal Ricks		TETDM-673 Add procedure BUILD_OUTB_INST_DIAG_ADJ_WIPRO
2016-09-12		Loyal Ricks		TETDM-987 - Denied Claim Adjustments Added - BUILD_OUTB_INST_DENIED_ADJUSTMENTS_WIPRO
2016-10-18		Loyal Ricks		Add procedure - BUILD_OUTB_INST_DENIED_LINE_ADJUSTMENTS_WIPRO for 1 claim testbed test of prod submission
2016-12-13		Loyal Ricks		TETDM-644 - Add procedure - pr_BUILD_OUTB_INST_OTH_PROC_CD
2018-01-17      JohnBartholomay TETDM-1715 Remove Zero dollar amount CAS Segments
2018-05-10      Henry Faust     TETDM-1632 remove duplicate DX codes and blank codes
*****************************************************************************************************/	
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT
		

--HRP_CLAIM_FILE Run controls
			BEGIN TRANSACTION 
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('pr_BUILD_OUTB_MAO_INST_CLM_FILE' + '-' +CONVERT(CHAR,@JOBID)
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					if @@ERROR <> 0
							begin
								rollback 
							end
				commit
					----JOBID = 9000 is the EDS Exclusion submission job. Exclusion history build should not be excuted for JOBID 9000
					IF @JOBID < 10
					BEGIN
						EXECUTE EXSP_WIPRO_CLAIM_EXCLUSION @SOURCEDATAKEY
					END
					EXECUTE pr_BUILD_OUTB_MAO_INST_CLAIM_HEADER @SOURCEDATAKEY,@JOBID--,@REJ_REA_ID
					--EXECUTE EXSP_HRP_CLAIM_INST_CLMHEADER @SOURCEDATAKEY,@BEGIN_BILLTYPECODE  , @END_BILLTYPECODE 
					EXECUTE pr_BUILD_OUTB_INST_CLM_DETAIL
					EXECUTE BUILD_OUTB_INST_DIAG_WIPRO @SOURCEDATAKEY
--					EXECUTE BUILD_OUTB_INST_DIAG_ADJ_WIPRO @SOURCEDATAKEY --TETDM-1632
					--EXECUTE EXSP_HRP_CLAIM_PROF_DIAG_POINTERS
					EXECUTE pr_BUILD_OUTB_INST_EDSPROVIDER
					EXECUTE pr_BUILD_OUTB_INST_ADJUSTMENTS
					EXECUTE BUILD_OUTB_INST_DENIED_ADJUSTMENTS_WIPRO
					execute BUILD_OUTB_INST_DENIED_LINE_ADJUSTMENTS_WIPRO
					--EXECUTE EXSP_HRP_CLAIM_INST_REQ5010
					EXECUTE pr_BUILD_OUTB_INST_OCCURANCECODE
					EXECUTE pr_BUILD_OUTB_INST_CONDITIONCODE
					EXECUTE pr_BUILD_OUTB_INST_OTH_PROC_CD
					EXECUTE pr_BUILD_OUTB_INST_WIPRO_DATASCRUB
					EXECUTE pr_BUILD_OUTB_INST_REMOVE_DUP_ADJUSTMENTS --TETDM-1645
					EXECUTE pr_BUILD_OUTB_INST_REMOVE_ZERO_CAS_AMTS --TETDM-1715
					----MAP CLAIM DATA FOR FILE PREPARATION
					--EXECUTE pr_BUILD_OUTB_INST_MAP @LOB,@LOBCODE,@JOBID
					---TETDM-643 Testing Only
					EXECUTE pr_BUILD_OUTB_INST_MAP  @LOB,@LOBCODE,@JOBID
					
			
	
			
			--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_INST_HEADER)
			SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM OUTB_INST_DETAIL)
									
		----HRP_CLAIM_FILE Update Run Controls
				BEGIN TRANSACTION
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'pr_BUILD_OUTB_MAO_INST_CLM_FILE' + '-' +CONVERT(CHAR,@JOBID)
										and END_DT is null
							IF @@ERROR <> 0
										BEGIN 
												ROLLBACK 
										END
						COMMIT



