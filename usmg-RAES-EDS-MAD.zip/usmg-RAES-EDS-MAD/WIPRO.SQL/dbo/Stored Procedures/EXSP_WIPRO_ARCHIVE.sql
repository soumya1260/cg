﻿

CREATE procedure [dbo].[EXSP_WIPRO_ARCHIVE]
(@JOB_ID INT = 1 )---ARHIVE JOB ID, Type of archiving to perform.
AS
/***************************************************************************************************
** CREATE DATE: 12/2014
**
** AUTHOR: LOYAL RICKS - LOYAL RICKS
**
** DESCRIPTION: Procedure will be used to execute various EDS WIPRO archiving processes. Use the @JOB_ID
**				to determine appropriate archive steps. 
**				@JOB_ID used to schedule archiving routines. 
**
**
**
**
**
Modification History
====================
Date			Who				Description

--------------------------------------------------------------------------------------------------------------------------------------------------------------
09/25/14		Loyal Ricks		Archive the following tables: OUTB_CLAIM_STATUS - OUTB_CLAIM_STATUS_DTL - OUTB_FILE_HIST.
								@JOBID - 
								1 -  Archive all available records. No deletion performed. Regular snapshot of existing records
							   200 - Last known fileid archive -Archive all records, keep most recent fileid for every claim, archive and delete all other transactions 
									 from OUTB_CLAIM_STATUS - OUTB_CLAIM_STATUS_DTL tables.
							   999 - Production Roll Back. Delete all records except for initial production Professional and Institutional files. 

*******************************************************************************************************************************************************************/
--DECLARE VARIABLES

			DECLARE
			
			@TOTAL_RECORDS INT
--HRP_CLAIM_FILE Run controls
			
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('EXSP_WIPRO_ARCHIVE JOB' + '-' +CONVERT(CHAR,  @JOB_ID)
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					
DECLARE 

	@ARCHIVE_DT DATETIME

	SET @ARCHIVE_DT = GETDATE();


				--begin standard archiving. Save all existing records to _ARCHIVE tables. 
	if OBJECT_ID ('tempdb..#OUTB_CLAIM_STATUS_ARCHIVE') <> 0
	drop table #OUTB_CLAIM_STATUS_ARCHIVE
				
CREATE TABLE [#OUTB_CLAIM_STATUS_ARCHIVE](
	[CLAIM_ID] [varchar](20) NULL,
	[CLAIM_TYPE] [varchar](1) NULL,
	[FILEID] [char](50) NULL,
	[CLM_IND] [varchar](20) NULL,
	[SOURCEDATAKEY] [int] NULL,
	[MEMBER_ID] [char](80) NULL,
	[HICN_NUM] [char](20) NULL,
	[BILL_PROV_GRP_ID] [char](40) NULL,
	[BILL_PROV_ID] [char](40) NULL,
	[REF_PROV_ID] [char](50) NULL,
	[REF_PCP_PROV_ID] [char](50) NULL,
	[ATTN_PROV_ID] [char](50) NULL,
	[CLMSTAT_STATUS] [varchar](1) NULL,
	[STAT_CLM_TYPE] [varchar](1) NULL,
	[WIPRO_CLAIM_ID] [varchar](20) NULL,
	[CMS_ICN] [varchar](20) NULL,
	[STAT_FATAL_ERR_FLAG] [varchar](1) NULL,
	[STAT_REJ_REA_ID] [varchar](8) NULL,
	[REJ_REA_MSG] [varchar](200) NULL,
	[LINE_SEQ_NO] [varchar](4) NULL,
	[OTH_PAYER_ID] [varchar](50) NULL,
	[FIELD_TYPE] [varchar](100) NULL,
	[SUBTYPE] [varchar](50) NULL,
	[FIELD_SUB_QUAL] [varchar](15) NULL,
	[FIELD_POS] [varchar](50) NULL,
	[FIELD_ERR] [varchar](100) NULL,
	[VAL_ERR] [varchar](1024) NULL,
	[FILEDATE] [varchar](14) NULL,
	[LAST_UPD_DATE] [datetime] NULL,
	[DOS_MONTH] [varchar](6) NULL,
	[SecondaryPlanClaimNumber] [varchar](20) NULL,
	[EffectiveEncounterFlag] [char](1) NULL,
	[OriginalPlanClaimID] [varchar](20) NULL
) 

if OBJECT_ID ('tempdb..#OUTB_CLAIM_STATUS_DTL_ARCHIVE') <> 0
	drop table #OUTB_CLAIM_STATUS_DTL_ARCHIVE
CREATE TABLE [dbo].[#OUTB_CLAIM_STATUS_DTL_ARCHIVE](
	[FILEID] [varchar](50) NULL,
	[RECORD_TYPE] [varchar](1) NULL,
	[CLAIM_TYPE] [varchar](1) NULL,
	[FATAL_ERR_FLAG] [varchar](1) NULL,
	[PAPER_CLM_FLAG] [varchar](1) NULL,
	[PLAN_CLAIM_NUMBER] [varchar](20) NULL,
	[WIPRO_CLAIM_NUMBER] [varchar](20) NULL,
	[REJ_REA_ID] [varchar](8) NULL,
	[REJ_REA_MSG] [varchar](200) NULL,
	[SERV_LINE_SEQ_NO] [varchar](4) NULL,
	[OTHER_PAYER_ID] [varchar](20) NULL,
	[FIELD_TYPE] [varchar](100) NULL,
	[FIELD_SUBTYPE] [varchar](50) NULL,
	[FILE_SUBTYPE_QUAL] [varchar](15) NULL,
	[FIELD_POS] [varchar](50) NULL,
	[FIELD_ERR] [varchar](100) NULL,
	[VAL_ERR] [varchar](1024) NULL,
	[LAST_UPD_DATE] [datetime] NULL,
	[SOURCEDATAKEY] [int] NULL,
	[CURRENT_FLAG] [varchar](5) NULL,
	[SecondaryPlanClaimNumber] [varchar](20) NULL,
	[EffectiveEncounterFlag] [char](1) NULL,
	[OriginalPlanClaimID] [varchar](20) NULL
) 






if OBJECT_ID ('tempdb..#CURR_CLM_FILEID') <> 0
	drop table #CURR_CLM_FILEID
				
CREATE TABLE [#CURR_CLM_FILEID](
	[CLAIM_ID] [varchar](20) NULL,
	[FILEID] [char](50) NULL,
	[SOURCEDATAKEY] INT
)

				--Archive existing table 

		-----OUTB_CLAIM_STATUS
		--begin transaction 
		--insert into #OUTB_CLAIM_STATUS_ARCHIVE
		--select *,@ARCHIVE_DT
		--from OUTB_CLAIM_STATUS
		--IF @@ERROR <> 0
		--	BEGIN 
		--		ROLLBACK
		--	END
		--COMMIT
		
		
		--Append new archive records to archive table 
		
		
		insert into OUTB_CLAIM_STATUS_ARCHIVE
		select *,@ARCHIVE_DT
		from OUTB_CLAIM_STATUS	
		


		--Archive file history table
		--OUTB_FILE_HIST
		
		insert into OUTB_FILE_HIST_ARCHIVE
		select *,@ARCHIVE_DT
		from OUTB_FILE_HIST
		
		

		--Archive file history table
		--OUTB_CLAIM_STATUS_DTL
		
 
		insert into OUTB_CLAIM_STATUS_DTL_Archive
		select *,@ARCHIVE_DT
		from OUTB_CLAIM_STATUS_DTL
		

		--Archived Data Jobs
		--
		--	@JOB_ID = 200 Monthly Post Cycle Refresh - Keep most recent fileid for each claim
		--

				if @JOB_ID = 200
						
						BEGIN 

							--Get Current Fileid for every outbound claim
							
							insert into #CURR_CLM_FILEID
							select claim_id,max(fileid),sourcedatakey
							from OUTB_CLAIM_STATUS
							GROUP BY CLAIM_ID,SOURCEDATAKEY
							

							--Get most recent fileid for claims

							---OUTB_CLAIM_STATUS
								
								insert into #OUTB_CLAIM_STATUS_ARCHIVE
								select CS.*
								from OUTB_CLAIM_STATUS CS
								inner join #CURR_CLM_FILEID CC
								ON CS.SOURCEDATAKEY = CC.SOURCEDATAKEY 
								AND CS.CLAIM_ID = CC.CLAIM_ID 
								AND CS.FILEID = CC.FILEID
								

							---OUTB_CLAIM_STATUS_DTL
								
								insert into #OUTB_CLAIM_STATUS_DTL_ARCHIVE
								select CS.*
								from OUTB_CLAIM_STATUS_DTL CS
								inner join #CURR_CLM_FILEID CC
								ON CS.SOURCEDATAKEY = CC.SOURCEDATAKEY 
								AND CS.PLAN_CLAIM_NUMBER = CC.CLAIM_ID 
								AND CS.FILEID = CC.FILEID
								

								TRUNCATE TABLE OUTB_CLAIM_STATUS
								TRUNCATE TABLE OUTB_CLAIM_STATUS_DTL

								
								INSERT INTO OUTB_CLAIM_STATUS
								SELECT *
								FROM #OUTB_CLAIM_STATUS_ARCHIVE
								

								
								INSERT INTO OUTB_CLAIM_STATUS_DTL
								SELECT *
								FROM #OUTB_CLAIM_STATUS_DTL_ARCHIVE
								
						END
		----@JOBID = 999000000 Production Roll Back

				if @JOB_ID = 999
						
						BEGIN 

							SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_CLAIM_STATUS)
							SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM OUTB_CLAIM_STATUS_DTL)


							
							DELETE 
							FROM OUTB_CLAIM_STATUS
							WHERE FILEID NOT IN ('HSCE.DEV.50.P.CARE.20140828151956','HSCE.DEV.50.I.CARE.20140828145453'
													  ,'HSCE.DEV.50.P.CARE.20141020173446','HSCE.DEV.50.I.CARE.20141020211839'
													,'HSCE.DEV.50.I.CARE.20141008143131', 'HSCE.DEV.50.P.CARE.20141008143114')                 
							

							
							DELETE 
							FROM OUTB_CLAIM_STATUS_DTL
							WHERE FILEID NOT IN ('HSCE.DEV.50.P.CARE.20140828151956','HSCE.DEV.50.I.CARE.20140828145453'
													  ,'HSCE.DEV.50.P.CARE.20141020173446','HSCE.DEV.50.I.CARE.20141020211839'
													,'HSCE.DEV.50.I.CARE.20141008143131', 'HSCE.DEV.50.P.CARE.20141008143114')                  
							

						end
--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM
				
				IF @JOB_ID = 200 
					BEGIN 
						SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #OUTB_CLAIM_STATUS_ARCHIVE)
						SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM #OUTB_CLAIM_STATUS_DTL_ARCHIVE)
					END	
						
				IF @JOB_ID = 1 
					BEGIN 
						SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_CLAIM_STATUS)
						SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM OUTB_CLAIM_STATUS_DTL)	
					END
		----HRP_CLAIM_FILE Update Run Controls
				
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'EXSP_WIPRO_ARCHIVE JOB' + '-'+ CONVERT(CHAR,  @JOB_ID)
										and END_DT is null
							
