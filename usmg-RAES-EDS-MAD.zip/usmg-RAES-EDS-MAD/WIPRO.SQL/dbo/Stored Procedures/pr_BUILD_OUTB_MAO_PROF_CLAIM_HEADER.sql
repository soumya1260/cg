﻿
CREATE  PROCEDURE [dbo].[pr_BUILD_OUTB_MAO_PROF_CLAIM_HEADER]
(
	@ExecutionMode		CHAR(1) = 'M',
	@sourcedatakey		INT,
	@JOBID 		INT = 1
	--
	--	NOTE:	Pass in 'A' for new "automated" execution
	--			Default is [M]anual mode...
	--
)

AS
/***************************************************************************************************
** CREATE DATE: 01/2012
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY TO SUBMIT CLAIM INFORMATION 
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
2012-10-19		Dwight Staggs	Remove database name from table references
2012-10-24		Loyal Ricks		Add Exclusion table logic (build and selection into OUTB_PROF_HEADER)
2012-10-24		Loyal Ricks		replace ##TMP_ with ##TMPDEV_ in order to support use of tempdb
2012-10-24		Loyal Ricks		between EDPS and EDPS_PROD databases.
2012-10-24		Loyal Ricks	    remove update, mapping rules change do not include CMS_CONTRACT_NUM
2013-02-08		Loyal Ricks		INVALID CHARACTER MEMBER RECORD PARSE
2013-03-06		Loyal Ricks		Remove DOS claim selection criteria
								Remove input parms
2013-04-25		Loyal Ricks		Add parsing logic for member address to, set '***' to ' '      
2013-04-30		Loyal Ricks		Remap default code for OTH_INSR_TYPECD1 to CLM_FIL_INDCD1 
								Due to CMS 999 rejection issue. 
2013-05-09		Loyal Ricks		Add Rendering Provider 
								Reject 103 adjustment - Remove cd.MemberPaidAmt from claim header. 
								When populated this data element is causing balance issues between
								claim header and claim line.
								scrub cd.pcpid when 'UNKNOWN' SET TO ' '	
2013-07-24		Dwight Staggs	Use new dbo.EDS_ClaimExtractParams and dbo.EDS_AllExtractClaims tables
								in SSIS package to pull all available claims for each source
2013-09-18		Dwight Staggs	Added @ExecutionMode input parameter for backward compatibility.  The
								default of 'M' executes the same as previously:
									1.	#tmplob table is created
									2.	The claims inserted into #ELIG_CLM are pulled directly from
										EDPS_Data.dbo.ClaimDim, JOINed to #tmplob
									3.	# of claims extracted is hard-codeded in this SP
								When set to 'A':
									1.	The claims inserted into #ELIG_CLM are pulled from dbo.EDS_AllExtractClaims,
										which is populated in the SSIS package before this SP is executed
									2.	The number of claims to be extracted is obtained from the 
									    EDS_ClaimExtractParams table for the appropriate SourceDataKey
2013-10-29		Dwight Staggs	For manual option, use ManualMaxClaimsPerFile in param table and eliminate 
								hardcoded value in this SP 	
2013-10-31		Loyal Ricks		PAYER_CLAIM_CNTRL_NUM - Revise logic to set this value to blank instead of 1 
								when BIDW defaults are assigned. REquired to support new Verisk edit 
								check on this data element.   
2014-01-22		Loyal Ricks		Add additional data scrub for Member Middle Name & Member Zip4	
2014-02-04		Loyal Ricks		Remove individual data element Invalid EDI parse and replace with function 
								dbo.fn_edi_parse.
2014-02-07		Loyal Ricks		Remove MDQOLib references (Memberdim, Lineofbusinessdim)
2014-02-11		Loyal Ricks		Additional invalid EDI character parsing - member first & last name		
------------------------------------------------------------------------------------------------------
2014-09-23		Loyal Ricks		WIPRO Code Migration from EDPS(Verisk) to WIPRO		
2014-10-08		Loyal Ricks		WIPRO MAO QNXT & MHC WIPRO claim header build	
2014-10-10		Loyal Ricks		WIPRO MAO BIDW Refersh test casess @JOBID - 500 series		
2014-10-29		Loyal Ricks		Remove use of @SOURCEDESC as source system value in claim header.
								 Use @sourcedatakey instead of sourcedesc.
								Decission made during 10/29 WIPRO Unique Id call. The sourcedatakey 
								will be used in conjunction with other values cancatenated by WIPRO
								on all clmstat files (WIPRO ICN number).		
2014-12-01		Loyal Ricks		Add logic for default assignment of PRINCIPAL_DIAG_QUAL = 'BK'	
2015-02-09		Loyal Ricks		EDS-706 - Facets professional Claim integration - evaluate @sourcedatakey in 
								order to determine appropriate selection criteria for each sdk. QNXT and
								MHC use same code blocks, Facets uses indepeendent code block. 	
2015-05-07		Loyal Ricks		Add Paper claim logic for non QNXT claims	
2015-05-28		Loyal Ricks		Remove parameter limiting sdk (2,50) for test bed submissions to allow for all sources 
								to have the option to use test bed.		
2015-08-01		Loyal Ricks		Add claimdim.formtypecode evaluation for Facets claim due to BIDW CR change which 
								added the Facets claim type to BIDW. 
								Remove Facets specific claim retrieval logic and combined logic with all other sdk	
2015-10-28		Loyal Ricks		TETDM-438 ICD-10 Qualifier Revisions
2015-10-30		Loyal Ricks		TETDM-448 Add @ExtractCount=EDS_ClaimExtractParams.Claim_Type ='P'		
2016-04-02		Loyal Ricks		TETDM-667 Add Ambulance Pickup and Dropoff fields	
2016-04-08		Loyal Ricks		TETDM-737 Remove Pay To Vendor Flag		
2016-08-15		Loyal Ricks		Add Outbound claims per file for DME claims			
2016-09-22		Loyal Ricks		Remove Jobid 3 Denied claim logic. Denied claims to get submitted with Jobid 1 for prod release	
2016-09-26		Loyal Ricks		Added back Jobid 3 Denied claim logic. additional volume testing required.		
2016-10-05		Loyal Ricks		Revise DME logic, remove deniedflag logic to enable submission of denied and non denied	
2018-02-02		Mike Vega		TETDM-1629 Add field ADM_DT to the Header	
2018-02-12		Mike Vega		TETDM-1629 uncommented the '0' to '' logic for ADM_DT that was comment out in 2/2/18 task	
2018-02-12		Mike Vega		TETDM-1629 formatted ADM_DT field to 'YYYYMMDD' format	
2018-03-23		Mike Vega		TETDM-1629 updated Lookup Logic to new less complex Lookup logic using BeginServiceDateKey					    	    
2018-10-10      Henry Faust     TETDM-1812 Professional Claim/Inpatient POS 21, 51, 61 Admission Date Logic-Permanent fix				    	    
2018-11-05      Henry Faust     TETDM-1783 CREATE generic resubmission jobs TESTIDs 2020 - 2028			
2019-11-25      Aaron Ridley    TETDM-2175-2181 Exclude SOS Compliance Holds in resubmission logic
2019-12-13     Aaron Ridley     TETDM-2201: 
                                   1) Add SafeGuard Logic to exclude any Compliance Hold claims not captured as an exclusion.
								   2) Add Exclusion '7001' to resub logic 	    	    
**********************************************************************************************************************/			

	SET NOCOUNT ON;
	
	DECLARE @CatchErrorMessage VARCHAR(2200);
	DECLARE	@TOTAL_RECORDS INT,
			@ExtractCount INT,
			@SOURCEDESC		CHAR(350)

			
			BEGIN 
			SET @SOURCEDESC = (select rtrim(sourcedesc) from WIPRO.DBO.sourcedatadim where sourcedatakey = @sourcedatakey);
			end

	IF OBJECT_ID('TEMPDB..#ELIG_CLM') <> 0
		DROP TABLE #ELIG_CLM
	
	CREATE TABLE #ELIG_CLM
	(
		ClaimID		VARCHAR(20)
	)
	
	IF OBJECT_ID('TEMPDB..#TMPDEV_HPLAN') <> 0
		DROP TABLE #TMPDEV_HPLAN

	CREATE TABLE #TMPDEV_HPLAN
	(
		ClaimId			VARCHAR(20),
		LOBCode			VARCHAR(15),
		HCFACode		VARCHAR(5)
	)

	IF OBJECT_ID('TEMPDB..#tmplob') <> 0
		DROP TABLE #tmplob

	CREATE TABLE #tmplob
	(
		LOBCode			VARCHAR(15)
	)



BEGIN TRY

--	Init Run controls
	INSERT INTO EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT
			)
			VALUES('pr_BUILD_OUTB_MAO_PROF_CLAIM_HEADER ' + '' + rtrim(@SOURCEDESC)
					,'2'
					,GETDATE()
					,NULL
					,NULL
					,0
					,GETDATE()
					)
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH
				
BEGIN TRY

	SELECT
			@ExtractCount = ManualMaxClaimsPerFile
		FROM
			dbo.EDS_ClaimExtractParams	
		WHERE
			SourceDataKey = @sourcedatakey
			AND CLAIM_TYPE ='P'
			
		INSERT INTO 
			#tmplob
		( 
			LOBCode
		)
		SELECT
			LOBCode
		FROM
			MDQOLib.dbo.LineofBusinessDim
		WHERE	
			ProductType = 'Medicare'
		AND Active = 1
		ORDER BY LOBCode



	--
	--	EDS "Happy Claim"/Standard submissions
	--	Backward compatibility mode....
	--
	IF @ExecutionMode <> 'A' AND @JOBID = 1 --- and  @sourcedatakey in (2,50) AND @JOBID = 1
	BEGIN

		INSERT INTO
			#ELIG_CLM
		( 
			ClaimID
		)
		SELECT	TOP(@ExtractCount) ClaimID
		FROM 
			EDPS_Data.dbo.CLAIMDIM C
			left outer join EXT_CLAIM_EXCLUSION E
			ON C.SOURCEDATAKEY = E.SOURCEDATAKEY 
			AND C.CLAIMID = E.CLAIM_ID 
		WHERE 
			c.SOURCEDATAKEY = @sourcedatakey
			AND c.FormTypeCode = 'H'
			AND E.CLAIM_ID IS NULL
			AND DeniedFlag = 0
			--AND charindex('R',claimid) = 0
			--AND charindex('A',claimid) = 0
			--AND c.LOBCODE IN (SELECT LOBCODE from #tmplob)
			--AND CLAIMID NOT IN (SELECT DISTINCT CLAIM_ID FROM EXT_CLAIM_EXCLUSION)
		
		
	END
	
	----
	----	EDS DME Claim Submissions
	----

	IF @ExecutionMode <> 'A' AND @JOBID = 2 --- and  @sourcedatakey in (2,50) AND @JOBID = 1
			BEGIN
				SELECT
					@ExtractCount = ManualMaxClaimsPerFile
				FROM
					dbo.EDS_ClaimExtractParams	
				WHERE
					SourceDataKey = @sourcedatakey
					AND CLAIM_TYPE ='E'

				INSERT INTO
						#ELIG_CLM
					( 
						ClaimID
					)
					SELECT
						--TOP 100000 C.ClaimID		--	<--  Change value here for Manual mode...
						TOP(@ExtractCount) C.ClaimID
					FROM 
						EDPS_Data.dbo.CLAIMDIM C
						inner join EXT_CLAIM_DME D
						on c.sourcedatakey = D.SOURCEDATAKEY 
						AND C.CLAIMID = D.CLAIMID
						left outer join EXT_CLAIM_EXCLUSION E
						ON C.SOURCEDATAKEY = E.SOURCEDATAKEY 
						AND C.CLAIMID = E.CLAIM_ID 
					WHERE 
						c.SOURCEDATAKEY = @sourcedatakey
						--AND c.FormTypeCode = 'H'
						AND E.CLAIM_ID IS NULL
						---AND DeniedFlag = 0
						--AND charindex('R',claimid) = 0
						--AND charindex('A',claimid) = 0
						--AND c.LOBCODE IN (SELECT LOBCODE from #tmplob)

			END

	----
	----	EDS Denied Claim Submissions
	----
	IF @ExecutionMode <> 'A' AND @JOBID = 3 --- and  @sourcedatakey in (2,50) AND @JOBID = 1
	BEGIN

		INSERT INTO
			#ELIG_CLM
		( 
			ClaimID
		)
		SELECT
--			TOP 100000 ClaimID		--	<--  Change value here for Manual mode...
			TOP(@ExtractCount) ClaimID
		FROM 
			EDPS_Data.dbo.CLAIMDIM C
			left outer join EXT_CLAIM_EXCLUSION E
			ON C.SOURCEDATAKEY = E.SOURCEDATAKEY 
			AND C.CLAIMID = E.CLAIM_ID 
		WHERE 
			c.SOURCEDATAKEY = @sourcedatakey
			AND c.FormTypeCode = 'H'
			AND E.CLAIM_ID IS NULL
			and c.DENIEDFLAG = 1
			--AND DeniedFlag = 0
			--AND charindex('R',claimid) = 0
			--AND charindex('A',claimid) = 0
			--AND c.LOBCODE IN (SELECT LOBCODE from #tmplob)
			--AND CLAIMID NOT IN (SELECT DISTINCT CLAIM_ID FROM EXT_CLAIM_EXCLUSION)
		
		
	END




	IF @ExecutionMode <> 'A'  AND @JOBID > 10
	BEGIN
--
--	Added 10-29-2013 to use ManualMaxClaimsPerFile in param table and eliminate hardcoded value in this SP
--
		--SELECT
		--	@ExtractCount = ManualMaxClaimsPerFile
		--FROM
		--	dbo.EDS_ClaimExtractParams	
		--WHERE
		--	SourceDataKey = @sourcedatakey
			
		--INSERT INTO 
		--	#tmplob
		--( 
		--	LOBCode
		--)
		--SELECT
		--	LOBCode
		--FROM
		--	MDQOLib.dbo.LineofBusinessDim
		--WHERE	
		--	ProductType = 'Medicare'
		--AND Active = 1
		--ORDER BY LOBCode
		
		INSERT INTO	#ELIG_CLM
		( ClaimID )
		SELECT
			--TOP 100000 ClaimID		--	<--  Change value here for Manual mode...z
		TOP(@ExtractCount) TB.ClaimID
		FROM WIPRO.dbo.OUTB_WIPRO_TEST_BED TB
		where 1 = 1
			AND TB.SOURCEDATAKEY = @sourcedatakey
			AND TB.TESTID = @JOBID
			AND TB.CLAIM_TYPE = 'P'
			AND NOT EXISTS( SELECT
								*
							FROM WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST ece
							WHERE 1 = 1
								AND ece.claim_id = TB.CLAIMID
								AND SOURCEDATAKEY != 4 --don't want encounters here (can't join on sourcedatakey because some sources don't have a direct match)
								AND ece.EXCL_ID ='5'); --TETDM-2183 Exclude SOS compliance holds, TETDM-2389 remove 'A-Ace','UnWrk'

	END
--tetdm-1783 just check here didn't change anything
	IF @ExecutionMode <> 'A'  AND @JOBID BETWEEN 2020 AND 2038
	BEGIN
--
--
		INSERT INTO	#ELIG_CLM
		( ClaimID )
		SELECT
			--TOP 100000 ClaimID		--	<--  Change value here for Manual mode...
			TOP(@ExtractCount) ClaimID
		FROM WIPRO.dbo.OUTB_WIPRO_TEST_BED TB
		WHERE 1 = 1
			AND TB.SOURCEDATAKEY = @sourcedatakey
			AND TB.TESTID = @JOBID
			AND TB.CLAIM_TYPE = 'E' --DME Claims
			AND NOT EXISTS( SELECT
								*
							FROM WIPRO.dbo.EXT_CLAIM_EXCLUSION_HIST eceh
							WHERE 1 = 1
								AND eceh.claim_id = TB.CLAIMID
								AND SOURCEDATAKEY != 4 --don't want encounters here (can't join on sourcedatakey because some sources don't have a direct match)
								AND eceh.EXCL_ID ='5'); --TETDM-2183 Exclude SOS compliance holds, TETDM-2389 remove 'A-Ace','UnWrk'
	END
	------
	--	Facets Sourcedatakey = 30 Claim Selection
	------

	--if @sourcedatakey = 30 and @ExecutionMode <> 'A' AND @JOBID = 1
	--	begin 
	--	--	SELECT
	--	--	@ExtractCount = ManualMaxClaimsPerFile
	--	--FROM
	--	--	dbo.EDS_ClaimExtractParams	
	--	--WHERE
	--	--	SourceDataKey = @sourcedatakey
			
	--	--INSERT INTO 
	--	--	#tmplob
	--	--( 
	--	--	LOBCode
	--	--)
	--	--SELECT
	--	--	LOBCode
	--	--FROM
	--	--	MDQOLib.dbo.LineofBusinessDim
	--	--WHERE	
	--	--	ProductType = 'Medicare'
	--	--AND Active = 1
	--	--ORDER BY LOBCode
	----Get eligible claims
	--	INSERT INTO
	--		#ELIG_CLM
	--	( 
	--		ClaimID
	--	)
	--	SELECT DISTINCT
	--		TOP(@ExtractCount) cd.ClaimID
	--	FROM 
	--		EDPS_DATA.dbo.CLAIMDIM cd
	--	join EDPS_DATA.dbo.CLAIMDETAILDIM cdd
	--	on cd.CLAIMID = cdd.CLAIMID
	--	and cd.SOURCEDATAKEY = cdd.SOURCEDATAKEY
	--	LEFT OUTER JOIN
	--		dbo.EXT_CLAIM_EXCLUSION		e
	--		ON cd.SOURCEDATAKEY = e.SOURCEDATAKEY
	--		AND cd.CLAIMID = e.claim_id
	--	WHERE 
	--		cd.SOURCEDATAKEY = '30'
	--		--AND FormTypeCode = 'H'
	--		AND DeniedFlag = 0
	--		AND cd.DELETED = 0
	--		AND SUBSTRING(cd.CLAIMID,12,1) NOT IN ('A','R')
	--		AND SUBSTRING(cd.CLAIMID,1,1) <> 'D'
	--		AND LOBCODE IN (SELECT LOBCODE from #tmplob)
	--		AND PROCEDURECODE NOT BETWEEN '100' AND '219'
	--		AND e.claim_id IS NULL
	--		--AND cd.CLAIMID NOT IN (SELECT DISTINCT CLAIM_ID FROM EXT_HRP_CLAIM_EXCLUSION)
	--	end 

	IF @ExecutionMode = 'A' 
	
	BEGIN	
		--
		--	Automated mode...
		--
		SELECT
			@ExtractCount = MaxClaimsPerFile
		FROM
			dbo.EDS_ClaimExtractParams	
		WHERE
			SourceDataKey = @sourcedatakey

		INSERT INTO
			#ELIG_CLM
		( 
			ClaimID
		)
		SELECT
			TOP(@ExtractCount) ClaimID
		FROM
			dbo.EDS_AllExtractClaims
		WHERE	
			SOURCEDATAKEY = @sourcedatakey
	END
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY
	--
	--	Build Claim Headers 
	--

			/* TEDM-2231 Suppressing submission of Claims with SourceDataKey mismatches to the 
			exclusion table  */

			--RETM-677 - Allow for the submission of SOS Filtered Claims 
			--DELETE a
			--FROM #ELIG_CLM a
			--INNER JOIN WIPRO.DBO.EXT_CLAIM_EXCLUSION b on a.CLAIMID = b.CLAIM_ID
			--where Excl_id IN ('7000','7001')

			-------------------------------------------------------------------------------------

		-- TETDM-2101 Compliance Filter Safeguard -----------------------------------------------
	-----------------------------------------------------------------------------------------
-- TETDM2505 adding 11, 12, 13, 14, 15 per this ticket
	--select distinct a.claimid, HOLD_DATE, GETDATE() AS INSERT_DATE
	--into #tmpcompfilter 
	--from #ELIG_CLM a
	--join WIPRO.[dbo].[DX_COMPLIANCE_HOLD] b on a.claimid = b.clm_no 
	--where b.hold_table_status not in ('2','3','5', '11', '12', '13', '14', '15') and a.claimid 
	--not in (select clm_no from WIPRO.[dbo].[DX_COMPLIANCE_HOLD] where hold_table_status in ('2','3','5', '11', '12', '13', '14', '15'))

	--delete a
	--from #ELIG_CLM a
	--inner join  #tmpcompfilter b  on a.claimid = b.claimid

	--INSERT INTO WIPRO.[dbo].[EDS_SUB_COMPLIANCE_FILTER_SAFEGUARD]
	--SELECT * FROM #tmpcompfilter

		-- End of Compliance Filter Safeguard ----------------------------------------------------------

	TRUNCATE TABLE OUTB_PROF_HEADER
	TRUNCATE TABLE OUTB_PROF_DETAIL


	--BEGIN TRANSACTION 
	INSERT INTO 
		OUTB_PROF_HEADER
	SELECT  DISTINCT
		'C'
		,case cd.formtypecode when 'H' then 'P'
			when 'U' then 'I'
			else cd.formtypecode
		end
		,rtrim(convert(char, @sourcedatakey))
		,' '--cd.sourcedatakey--CMS_CONTRACT_NUM
		,mb.MEDICAREID

		,cd.claimid
		,substring(cd.PatientID,1,20)
		,REPLACE(cd.MemberID,'*','-') 
		,dbo.fn_edi_parse(mb.lastname)
		,dbo.fn_edi_parse(mb.firstname)
		,CASE dbo.fn_edi_parse(mb.middlename) 
			WHEN 'UNKNOWN' THEN ' '
			ELSE dbo.fn_edi_parse(mb.middlename)
		 END
		,' '--MEMBER_SFX
		,dbo.fn_edi_parse(substring(mb.AddressLine1,1,55))
		,CASE dbo.fn_edi_parse(substring(mb.AddressLine2,1,55))
			WHEN 'UNKNOWN' THEN ' '
			when '***' then ' '                                                    
			ELSE dbo.fn_edi_parse(substring(mb.AddressLine2,1,55))
		 END
		,mb.City
		,mb.State
		,CASE substring(mb.Zip,1,5) WHEN 'UNKNO' THEN '99999' ELSE SUBSTRING(mb.Zip,1,5) END
		,substring(mb.Zip,6,4) 
		,' '--MEMBER_CTY
		,' '--MEMBER_CTRY
		,' '--MEMBER_CTRY_SUBD
		,REPLACE(cd.GroupID,'*','-')
		,case cd.formtypecode 
			when 'H' then '14'
			else ' '
		end
		,mb.DOBDateKey
		,mb.Gender
		,CASE mb.SSN WHEN 'UNKNOWN' THEN ' ' ELSE mb.SSN END
		,' '--POS
		,' '--INST_PRINCIPAL_DIAG_CD
		,' '--INST_PRINCIPAL_POA_CD
		,' '--INST_ADM_DIGA_CD
		,' '--DIAG_CD1
		,' '--POA_IND1
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--DIAG_CD20
		,' '--POA_IND20
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--DIAG_CD30
		,' '--POA_IND30
		,' '--BILL_PROV_NPI
		,cd.PCPVendor
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--BILL_PROV_LICENSE_NO
		,cd.PCPVendor
		,' '--TETDM-737,case cd.PayToVendorOrFamilyFlag 
		--	when 'V' then '1'
		--	else ' '
		--end
		,' '--PAYTO_ADDR1
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,'P'--PAYER_RESP
		,ltrim(cd.ClaimBilledAmt)
		,' '--ltrim(cd.MemberPaidAmt)
		,' '
		,CASE cd.PreviousClaimID WHEN 'N/A' THEN '1'  when 'UNKNOWN' THEN '1' ELSE '7' END
		,'C'--PROV_ASSGN_IND
		,'Y'--INSR_BEN_ASSGN_IND
		,' '
		,' '
		,' '
		,case cd.admissiondatekey when '-1' then ' ' when '0' then ' ' else cd.AdmissionDateKey end
		,' '
		,' '
		,' '
		,case cd.dischargedatekey when '-1' then ' '  when '0' then ' ' else cd.DischargeDateKey end
		,' '
		,CASE cd.DispositionCode WHEN 'N/A' THEN ' ' WHEN '--' THEN ' ' ELSE cd.DispositionCode END
		,CASE replace(cd.AuthorizationID,'*','-') WHEN 'UNKNOWN' THEN ' ' ELSE replace(cd.AuthorizationID,'*','-')  END
		,' '--CPO_NPI
		,' '--PRICE_METHOD
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--REF_PROV_UPIN
		,CASE cd.ReferringPhysicianID WHEN 'UNKNOWN' THEN ' ' ELSE cd.ReferringPhysicianID END
		,' '--REF_PCP_LNAME
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--REF_PCP_PROV_UPIN
		,case cd.PCPID WHEN 'UNKNOWN' THEN ' ' ELSE cd.PCPID end
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--ATTN_PROV_LOC_NO
		,CASE cd.AttendingPhysicianID WHEN 'UNKNOWN' THEN ' ' ELSE cd.AttendingPhysicianID END
		,' '--ATTN_PROV_LICENSE_NO
		,' '--EMER_FLAG
		,' '--PROD_DESC
		,' '--ANES_FLAG
		,'P'--PAYER_RESP1 default values for CMS COB
		,'18'--REL_CD1 default values for CMS COB
		,' '--OTH_INSR_GRPNO1 CHAR(50),
		,'HealthSpring'--OTH_INSR_GRPNAME CHAR(60),
		,' '--OTH_INSR_TYPECD1 CHAR(10),
		,'16'--CLM_FIL_INDCD1 CHAR(10),
		,' '--CLM_ADJ_GRP_TYPE1 CHAR(2),
		,' '--CLM_ADJ_REA_CD1 CHAR(5),
		,' '--SUM(CD.CLAIMBILLEDAMT - cd.TotalPaid)--CLM_ADJ_AMT1 CHAR(18),
		,' '--CLM_ADJ_UNIT1 CHAR(18)
		,ltrim(cd.TotalPaid)
		,' '--cd.MHCFinancialDateKey--USE CLAIMAGG PAYDATEKEY WHICH IS 
		,' '--ltrim(cd.MemberPaidAmt)
		,' '
		,'HealthSpring'--OTHER PAYER 1 NAME
		,' '---OTHER PAYER1 PLAN ID
		,'530 GREAT CIRCLE' --OTHER PAYER1 ADDRESS
		,' '  --OTHER PAYER1 ADDRESS2
		,'NASHVILLE'--OTHER PAYER1 CITY
		,'TN' --OTHER PAYER1 STATE
		,'37228'--OTH PAYER1 ZIP
		,'9999' -- OTHER PAYER1 ZIP4
		,' '--cd.MHCFinancialDateKey
		,cd.sourcedatakey
		,'Y'--PROV_SIGNATURE_FLAG
		,'Y'--REL_OF_INFO_FLAG
		,'Y'--ASSIGN_BEN_IND1
		,CASE cd.PreviousClaimID WHEN 'N/A' THEN ' ' when 'UNKNOWN' THEN ' ' ELSE cd.PreviousClaimID END
		,' '--OPTIONAL REPORTING INDICATOR
		,' '--rendoring provider 
		,' '
		,' '
		,' '
		,' '
		,' '
		,' '--rendering prov taxonomy
		,' '--rendering provider org name
		,' '--rendering provider group id
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '
			,' '--TETDM-667 - Ambulance Pickup Addr1
			,' '
			,' '
			,' '
			,' '
			,' '--Ambulance dropoff addr1
			,' '
			,' '
			,' '
			,' '
	from 
		EDPS_Data.dbo.claimdim					cd
	INNER JOIN
		MDQOLib.dbo.MemberDim			mb
		ON cd.SOURCEDATAKEY = mb.SourceDataKey
		AND cd.MEMBERID = mb.MemberID
    
	INNER JOIN
		#ELIG_CLM						e
		ON cd.CLAIMID = e.ClaimID
	WHERE
		cd.SOURCEDATAKEY = @sourcedatakey

	--COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY
	--UPDATE CMS_CONTRACT_NUM WITH MEMBER HPLAN_NO
	INSERT INTO 
		#TMPDEV_HPLAN
	(
		ClaimId, 
		LOBCode, 
		HCFACode
	)
	 SELECT 
		CD.CLAIMID,
		CD.LOBCODE,
		L.HCFACODE
	 FROM 
		OUTB_PROF_HEADER					C
	INNER JOIN
		EDPS_Data.dbo.CLAIMDIM					CD
		ON C.SOURCEDATAKEY = CD.SOURCEDATAKEY
		AND C.CLAIM_ID = CD.CLAIMID
	INNER JOIN
		MDQOLib.dbo.LineofBusinessDim	L
		ON CD.SOURCEDATAKEY = L.SourceDataKey
		AND	CD.LOBCODE = L.LOBCode


	--BEGIN TRANSACTION 
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			 CMS_CONTRACT_NUM = T.HCFACode
			,OTH_PAYER1_PLANID = T.HCFACode
		FROM 
			OUTB_PROF_HEADER C
		INNER JOIN
			#TMPDEV_HPLAN T	
			ON C.CLAIM_ID = T.CLAIMID
		
	--COMMIT TRANSACTION
	
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	


BEGIN TRY	
	--
	--	Update PAYER1_PAID_DT from ClaimAgg
	--
	--BEGIN TRANSACTION
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			PAYER1_PAID_DT = CA.PaidDateKey
		FROM 
			OUTB_PROF_HEADER			HC
		INNER JOIN
			EDPS_Data.dbo.CLAIMAGG			CA
		ON 
			HC.SOURCEDATAKEY = CA.SOURCEDATAKEY
			AND HC.CLAIM_ID = CA.CLAIMID

		--COMMIT TRANSACTION
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY

------------------------------------------------
------------------------------------------------
--	Update ADM_DT and DISCHRG_DT to '' when 0...
------------------------------------------------
		-- TETDM-1629 Removed this update, see next ADM_DT update
		UPDATE OUTB_PROF_HEADER
		SET ADM_DT = ''
		WHERE ADM_DT = '0'

------------------------------------------------

	--
	--	Update DISCHRG_DT to '' when 0...
	--

		UPDATE OUTB_PROF_HEADER
		SET DISCHRG_DT = ''
		WHERE DISCHRG_DT = '0'

		UPDATE OUTB_PROF_HEADER 
		SET CLAIM_TYPE = 'P'
		WHERE SOURCEDATAKEY = 30


END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY
	--UPDATE PROFESSIONAL CLAIM PLACE OF SERVICE
	--BEGIN TRANSACTION
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			POS = cd.ServicePlaceCode
		FROM 
			OUTB_PROF_HEADER			E
		INNER JOIN
			EDPS_Data.dbo.CLAIMDETAILDIM		CD
			ON E.SOURCEDATAKEY = CD.SOURCEDATAKEY
			AND E.CLAIM_ID = CD.CLAIMID
		WHERE
			E.CLAIM_TYPE = 'P'
					
	--COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	


BEGIN TRY
	--UPDATE INSTITUTIONAL CLAIM PLACE OF SERVICE
	--BEGIN TRANSACTION
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			POS = UA.billtypecode
		FROM 
			OUTB_PROF_HEADER			E
		INNER JOIN
			EDPS_Data.dbo.UB921ADMISSIONDIM	UA
			ON E.SOURCEDATAKEY = UA.SourceDataKey
			AND E.CLAIM_ID = UA.claimid
		WHERE
			E.CLAIM_TYPE = 'I'	

	--COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	


BEGIN TRY
	--UPDATE INST_PRINCIPAL_DIAG_CD
	--BEGIN TRANSACTION
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			INST_PRINCIPAL_DIAG_CD = replace(CDD.DIAGNOSISCODE,'.',''),
			INST_PRINCIPAL_POA_CD = CASE CDD.POAind WHEN 'Y' THEN 'Y' ELSE 'N' END,
			PRINCIPAL_DIAG_QUAL = 'BK'
		FROM 
			OUTB_PROF_HEADER				E
		INNER JOIN	
			EDPS_Data.dbo.CLAIMDIAGNOSISDIM		CDD
			ON E.SOURCEDATAKEY = CDD.SourceDataKey
			AND E.CLAIM_ID = CDD.CLAIMID
			AND CDD.DIAGNOSISTYPECODE = 'P'
	
	--COMMIT TRANSACTION
	

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY
		--UPDATE SERVICE DATE
	--BEGIN TRANSACTION 
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			SERV_DT = BeginServiceDateKey
		FROM 
			OUTB_PROF_HEADER					E
		INNER JOIN
			EDPS_Data.dbo.CLAIMDETAILDIM				CDD
			ON E.SOURCEDATAKEY = CDD.SOURCEDATAKEY
			AND E.CLAIM_ID = CDD.CLAIMID
			AND CDD.CLAIMLINEID = '0001'

	--COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY
	--
	--	Updates from UB921AdmissionDim
	--
	
		--UPDATE ADM_TYPE_CD
		--BEGIN TRANSACTION
		UPDATE OUTB_PROF_HEADER
		SET 
			ADM_TYPE_CD = replace(ub.DIAGNOSISCODE,'.',''),
			ADM_SOURCE_CD = UB.admissioncode,
			ADM_TIME = UB.admissionhour,
			DISCHRG_TIME = case UB.dischargehour when 'N/A' then ' ' else UB.dischargehour end
		FROM 
			OUTB_PROF_HEADER					E
		INNER JOIN
			EDPS_Data.dbo.UB921ADMISSIONDIM			UB
			ON E.SOURCEDATAKEY = UB.SourceDataKey
			AND E.CLAIM_ID = UB.claimid	
			AND UB.admissiondiagnosistypecode = 'A'
	
		--COMMIT TRANSACTION
		
		--
		--	These original updates were all combined into the above...
		--
		--
		----UPDATE ADM_SOURCE_CD
		--BEGIN TRANSACTION
		--UPDATE OUTB_PROF_HEADER
		--SET ADM_SOURCE_CD = UB.admissioncode
		--FROM OUTB_PROF_HEADER E
		--	,EDPS_Data.dbo.ub921admissiondim UB
		--WHERE E.CLAIM_ID = UB.claimid
		--	AND UB.admissiondiagnosistypecode = 'A'
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		----UPDATE ADM_TIME
		--BEGIN TRANSACTION
		--UPDATE OUTB_PROF_HEADER
		--SET ADM_TIME = UB.admissionhour
		--FROM OUTB_PROF_HEADER E
		--	,EDPS_Data.dbo.ub921admissiondim UB
		--WHERE E.CLAIM_ID = UB.claimid
		--	AND UB.admissiondiagnosistypecode = 'A'
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--commit
		
		--UPDATE DISCHRG_TIME
		--BEGIN TRANSACTION
		--UPDATE OUTB_PROF_HEADER
		--SET DISCHRG_TIME = case UB.dischargehour when 'N/A' then ' ' else UB.dischargehour end
		--FROM OUTB_PROF_HEADER E
		--	,EDPS_Data.dbo.ub921admissiondim UB
		--WHERE E.CLAIM_ID = UB.claimid
		--	AND UB.admissiondiagnosistypecode = 'A'
		--if @@ERROR <> 0
		--	begin
		--		rollback 
		--	end
		--COMMIT
		
		

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY

---------------------------------

--TETDM-1629 --> M.Vega -- Use script to pull ADM_DT for CLAIMID to be placed in HEADER
		UPDATE OPH
		SET ADM_DT = adm.ADM_DT
		FROM OUTB_PROF_HEADER OPH
		INNER JOIN --TETDM-1629
			(
			select distinct a.CLAIM_ID,BeginServiceDateKey as ADM_DT
			from wipro.dbo.outb_claim_status a
				inner join edps_data.dbo.claimdim b on b.claimid = a.claim_id 
			where a.claim_type	=	'P' 
				and stat_rej_rea_id =	'20109' 
				and dos_month		>	'201412'
			) adm on adm.claim_id = OPH.claim_id				

----------------------------------


	------ OLD ADM_DT UPDATE CODE ---
	----	Update "0" dates...
	--
	--begin transaction 
		UPDATE OUTB_PROF_HEADER
		SET ADM_DT = ''
		WHERE ADM_DT = '0'


		UPDATE OUTB_PROF_HEADER
		SET DISCHRG_DT = ''
		WHERE DISCHRG_DT = '0'
	--commit

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

		
BEGIN TRY		

		--
		--	UPDATE CMS_CONTRACT_NUMBER and NonCov_Chrg...
		--
		--BEGIN TRANSACTION

			--UPDATE 
			--	OUTB_PROF_HEADER
			--SET 
			--	CMS_CONTRACT_NUM = MR.[plan]
			--FROM 
			--	OUTB_PROF_HEADER						EC
			--INNER JOIN
			--	EDPS_Data.dbo.MMR						MR
			--	ON EC.MEMBER_ID = MR.MEM_ID
			--	AND  MR.[payt_dt] = '201208'  --ADD PARAMETER FOR PRODUCTION
			--	AND MR.adj_code = ''
			--	AND substring(mr.[plan],1,1) <> 'S'
				

			UPDATE 
				OUTB_PROF_HEADER
			SET 
				NONCOV_CHRG = ' '
			WHERE 
				CONVERT(INT, NONCOV_CHRG)< 0

		--COMMIT TRANSACTION
		
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

		
BEGIN TRY
	--
	--	Update claim indicators...
	--		
		
	--BEGIN TRANSACTION 

		--CLAIM INDICATOR - CLAIM REVERSAL LOGIC
		--UPDATE CLAIM INDICATOR TO DELETE FOR R REVERSAL CLAIM 
		UPDATE 
			OUTB_PROF_HEADER 
		SET  CLM_IND = '8'
			,PAYER_CLAIM_CNTRL_NUM = CA.PreviousClaimID
		FROM 
			OUTB_PROF_HEADER				C
		INNER JOIN
			EDPS_Data.dbo.CLAIMAGG				CA
			ON C.SOURCEDATAKEY = CA.SOURCEDATAKEY
			AND C.CLAIM_ID = CA.CLAIMID
			AND CHARINDEX('R',CA.ClaimID) > 0

		
		--UPDATE CLAIM INDICATOR TO REPLACE FOR REPLACEMENT CLAIM
		--'A' (A1-A10)
		UPDATE 
			OUTB_PROF_HEADER
		SET  CLM_IND = '7'
			,PAYER_CLAIM_CNTRL_NUM = CA.PreviousClaimID
		FROM
			OUTB_PROF_HEADER				C
		INNER JOIN
			EDPS_Data.dbo.CLAIMAGG				CA
			ON C.SOURCEDATAKEY = CA.SOURCEDATAKEY 
			AND C.CLAIM_ID = CA.CLAIMID
			AND CHARINDEX('A',CA.ClaimID) > 0
			AND CA.CurrentStatusCode = 'P'
			AND CA.PREVIOUSCLAIMID NOT IN ('N/A','UNKNOWN')
		
	
		--PAPER CLAIM INDICATOR UPDATE for QNXT
		UPDATE 
			OUTB_PROF_HEADER
		SET 
			OPTIONAL_REPORTING_IND = 'PAPER'
		WHERE SOURCEDATAKEY = 50 
				AND CHARINDEX('E',CLAIM_ID) = 0

		--PAPER claim logic for Non QNXT claims
		  UPDATE  OUTB_PROF_HEADER
        SET     OPTIONAL_REPORTING_IND = 'PAPER'
        FROM    EXT_HRP_CLAIM E
                INNER JOIN EDPS_DATA.DBO.CLAIMSTATUSDIM CS ON E.SOURCEDATAKEY = CS.SOURCEDATAKEY
                                                AND E.CLAIM_ID = CS.ClaimID
        WHERE   AdjudicatorInitials = 'OCR'
		and		E.sourcedatakey <> 50
		
		

		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY

		--01/21/14 Additional Parsing
		 
		UPDATE OUTB_PROF_HEADER
		SET MEMBER_ZIP4 = '9998'
		WHERE LEN(MEMBER_ZIP4) < 4

		-- DME ClaimType Logic 

		if @jobid = 2 
			begin 
				update OUTB_PROF_HEADER
				SET CLAIM_TYPE = 'E'
			END
	
		----TETDM-438 ICD-10 Qualifier Revisions
	
		--		--TETDM-438 ICD-10 Qualifier Revisions
		--		--ICD-10 Principal Diag Qual
		--		Update OUTB_PROF_HEADER 
		--		SET PRINCIPAL_DIAG_QUAL = 'A'+''+RTRIM(PRINCIPAL_DIAG_QUAL)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND H.PRINCIPAL_DIAG_QUAL = 'BK'


		--		--ICD-10 DIAG_CD_QUAL1
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL1 = 'A'+''+RTRIM(DIAG_CD_QUAL1)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL1 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL2
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL2 = 'A'+''+RTRIM(DIAG_CD_QUAL2)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL2 =  'BF'


		--		--ICD-10 DIAG_CD_QUAL3
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL3 = 'A'+''+RTRIM(DIAG_CD_QUAL3)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL3=  'BF'

		--		--ICD-10 DIAG_CD_QUAL4
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL4 = 'A'+''+RTRIM(DIAG_CD_QUAL4)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL4 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL5
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL5 = 'A'+''+RTRIM(DIAG_CD_QUAL5)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL5 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL6
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL6 = 'A'+''+RTRIM(DIAG_CD_QUAL6)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL6 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL7
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL7 = 'A'+''+RTRIM(DIAG_CD_QUAL7)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL7 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL8
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL8 = 'A'+''+RTRIM(DIAG_CD_QUAL8)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL8 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL9
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL9 = 'A'+''+RTRIM(DIAG_CD_QUAL9)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL9 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL1
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL10 = 'A'+''+RTRIM(DIAG_CD_QUAL10)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL10 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL11
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL11 = 'A'+''+RTRIM(DIAG_CD_QUAL11)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL11 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL12
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL12 = 'A'+''+RTRIM(DIAG_CD_QUAL12)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL12 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL13
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL13 = 'A'+''+RTRIM(DIAG_CD_QUAL13)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL13 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL14
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL14 = 'A'+''+RTRIM(DIAG_CD_QUAL14)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL14 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL15
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL15 = 'A'+''+RTRIM(DIAG_CD_QUAL15)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL15 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL16
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL16 = 'A'+''+RTRIM(DIAG_CD_QUAL16)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL16 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL17
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL17 = 'A'+''+RTRIM(DIAG_CD_QUAL17)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL17 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL18
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL18 = 'A'+''+RTRIM(DIAG_CD_QUAL18)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL18 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL19
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL19 = 'A'+''+RTRIM(DIAG_CD_QUAL19)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL19 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL20
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL20 = 'A'+''+RTRIM(DIAG_CD_QUAL20)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL20 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL21
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL21 = 'A'+''+RTRIM(DIAG_CD_QUAL21)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL21 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL22
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL22 = 'A'+''+RTRIM(DIAG_CD_QUAL22)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL22 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL23
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL23 = 'A'+''+RTRIM(DIAG_CD_QUAL23)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL23 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL24
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL24 = 'A'+''+RTRIM(DIAG_CD_QUAL24)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL24 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL25
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL25 = 'A'+''+RTRIM(DIAG_CD_QUAL25)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL25 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL26
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL26 = 'A'+''+RTRIM(DIAG_CD_QUAL26)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL26 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL27
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL27 = 'A'+''+RTRIM(DIAG_CD_QUAL27)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL27 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL28
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL28 = 'A'+''+RTRIM(DIAG_CD_QUAL28)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL28 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL29
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL29 = 'A'+''+RTRIM(DIAG_CD_QUAL29)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL29 =  'BF'

		--		--ICD-10 DIAG_CD_QUAL30
		--		Update OUTB_PROF_HEADER 
		--		SET DIAG_CD_QUAL30 = 'A'+''+RTRIM(DIAG_CD_QUAL30)
		--		FROM OUTB_PROF_HEADER H
		--		INNER JOIN EDPS_DATA.DBO.claimdiagnosisdim cdd
		--		ON H.SOURCEDATAKEY = CDD.SOURCEDATAKEY 
		--		AND H.CLAIM_ID = CDD.CLAIMID 
		--		WHERE diagnosiscodeversion = '0'
		--			AND DIAG_CD_QUAL30 =  'BF'
		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

-- TETDM-1812 ---------------------Professional Claim/Inpatient POS 21, 51, 61 Admission Date Logic-Permanent fix 

 UPDATE dbo.OUTB_PROF_HEADER
 SET adm_dt = cd.BeginServiceDateKey
 FROM outb_prof_header oph
 JOIN edps_data.dbo.CLAIMDIM cd ON cd.CLAIMID = oph.CLAIM_ID AND cd.SOURCEDATAKEY = oph.SOURCEDATAKEY AND cd.ADMISSIONDATEKEY = -1
 WHERE oph.pos IN ('21', '51','61') 
   AND cd.ADMISSIONDATEKEY = '-1'





BEGIN TRY
	--
	--	Update Run Controls
	--
			
	SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_HEADER)
							
	
		UPDATE 
			EXT_SYS_RUNLOG
		SET END_DT = GETDATE()	
			,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
			,TOTAL_RECORDS = @TOTAL_RECORDS
			,ENTRYDT = GETDATE()
		WHERE 
			PROC_NAME = 'pr_BUILD_OUTB_MAO_PROF_CLAIM_HEADER ' + '' + rtrim(@SOURCEDESC)
			AND END_DT IS NULL

	
						
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	

BEGIN TRY
	--
	--	If executing in "A" mode, remove claims processed for next loop in SSIS package
	--
	IF @ExecutionMode = 'A'
	BEGIN
		DELETE
			c 
		FROM
			dbo.EDS_AllExtractClaims	c
		INNER JOIN
			#ELIG_CLM					e
			ON c.ClaimID = e.ClaimID
	END
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH	


	IF OBJECT_ID('TEMPDB..#ELIG_CLM') <> 0
		DROP TABLE #ELIG_CLM

	IF OBJECT_ID('TEMPDB..#TMPDEV_HPLAN') <> 0
		DROP TABLE #TMPDEV_HPLAN
		
	IF OBJECT_ID('TEMPDB..#tmplob') <> 0
		DROP TABLE #tmplob




/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()

BEGIN TRANSACTION

	EXEC [dbo].[pr_EXSP_CLAIM_PROF_QNXT_CLMHEADER]
		@ExecutionMode	 = 'M'	
		
ROLLBACK TRANSACTION

SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/
