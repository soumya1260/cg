﻿
/*
	Usage:
		This procedure is intended to be used by the SSIS package MOR_Non_Parsed_Import to insert staged records 
		into the MOR nonparsed hard tables used in the queries below.		

	Created by ASU
	--------------
	NOTES:
		ASU 7/8/2024 - Refactor to pull in non-parsed data


*/
CREATE PROCEDURE [dbo].[MOR_Nonparsed_File_INSERT]
AS

	SET NOCOUNT ON;

	--disable indexes for insert (won't disable clustered index)
	EXEC dbo.utility_disable_enable_index @Table_Name = N'MMR_Non_Parsed'
										 ,@Schema = N'dbo';
 
	WITH headerinfo AS (
		SELECT
			mnp.File_Name,
			Contract_Number = SUBSTRING(mnp.Data_Row,2,5),
			File_Run_Date = TRY_CONVERT(DATE,SUBSTRING(mnp.Data_Row,7,8)),
			Payment_Year_Month = SUBSTRING(mnp.Data_Row,15,6)
		FROM staging.MOR_Non_Parsed mnp
		WHERE mnp.Record_Type_Code = '1'),
	other_rows AS (
		SELECT
			mnp.File_Name,
			MBI = IIF(mnp.Record_Type_Code NOT IN ('1', '3'), SUBSTRING(mnp.Data_Row,2,11),NULL),
			mnp.Data_Row,
			mnp.Record_Type_Code
		FROM staging.MOR_Non_Parsed mnp)
	INSERT INTO dbo.MOR_Non_Parsed (File_Name, Record_Type_Code, Contract_Number, File_Run_Date, Payment_Year_Month, MBI, Data_Row, Load_Date)
	SELECT DISTINCT
		hi.File_Name
	   ,orr.Record_Type_Code
	   ,hi.Contract_Number
	   ,hi.File_Run_Date
	   ,hi.Payment_Year_Month   
	   ,orr.MBI
	   ,orr.Data_Row
	   ,GETDATE()
	FROM headerinfo hi
	JOIN other_rows orr
		ON hi.File_Name = orr.File_Name
	WHERE NOT EXISTS (SELECT * FROM dbo.MOR_Non_Parsed mnp WHERE mnp.File_Name = hi.File_Name);
	
	EXEC dbo.utility_disable_enable_index @Table_Name = N'MOR_Non_Parsed'
										 ,@Schema = N'dbo'
										 ,@Enable = 1;

	/*
		The below select statement is used in the SSIS package MOR_File_Import
		Any alterations to this statement will require an update to the SSIS package as well.
	*/
	SELECT
		mnp.File_Name,
		mnp.Contract_Number,
		File_Reported_Count = FORMAT(COUNT(*),'N0'),
		File_Detail_Record_Count = FORMAT(COUNT(IIF(mnp.Record_Type_Code NOT IN ('1','3'),1,NULL)),'N0')
	FROM dbo.MOR_Non_Parsed mnp
	WHERE EXISTS (SELECT * FROM staging.MOR_Non_Parsed mfn WHERE mfn.File_Name = mnp.File_Name) 
	--compare dbo to stage to figure out what loaded for counts
	GROUP BY mnp.File_Name, mnp.Contract_Number;

	SET NOCOUNT OFF;