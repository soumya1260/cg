﻿



CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_PROF_CLM_FILE]
(
	@ExecutionMode		CHAR(1) = 'M'
	,@exclusionmode		char(1) = 'R'
	--
	--	NOTE:	Pass in 'A' for new "automated" execution
	--			Default is [M]anual mode...
	-- @exclusionmode - Pass 'M' for migration exclusions, 'R' default = regular exclusion
)

AS
/***************************************************************************************************
** CREATE DATE: 08/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL EXECUTE REQUIRD STEPS FOR COMPILING HRP MHC CLAIM SUBMISSIONS.
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
10/28/12		LOYAL RICKS		REMOVED EXSP_HRP_CLAIM_RESEND procedure call, replaed with 
								EXSP_HRP_CLAIM_EXCLUSION procedure call
03/06/2013		LOYAL RICKS		ADD CATCHALL REQUIRED TABLE TO PROCESS - EXECUTE EXSP_HRP_CLAIM_REQ5010
								REMOVE EXSP_HRP_CLAIM_PROVIDER 
								ADD EXSP_HRP_CLAIM_EDSPROVIDER
07/24/2013		Dwight Staggs	Removed creating of EXT_HRP_CLAIM_EXCLUSION table.  That table is now
								created in the first step of the SSIS Extract Package when the table
								dbo.EDS_AllExtractClaims is built							
09/18/2013		Dwight Staggs	Added @ExecutionMode input parameter for backward compatibility.  The
								default of 'M' executes the same as previously.  When set to 'A', we 
								by-pass creating the EXT_HRP_CLAIM_EXCLUSION table (see 7/24 comments).
								This parameter is also used in the Claim Header SP executed herein.
10/10/2013		Loyal Ricks		Add procedure EXSP_HRP_CLAIM_PROF5010	
11/15/2013		Loyal Ricks		Add input parameter @exclusionmode for main procedure and calling procedure
								EXSP_HRP_CLAIM_EXCLUSION. Parm used by exclusion process to determine 
								whether to execute in migration mode "M" or regular mode "R" default.
11/15/2013		Loyal Ricks		Replace @sourcedatakey parameter with @DATASOURCEKEY for procedure
								EXSP_HRP_CLAIM_EXCLUSION	
05/02/2014		Loyal Ricks		Upgrade mapping from Verisk 3.2 to Verisk 4.0 - EXSP_HRP_CLAIM_MAP_V4	
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation		
09/10/14		Loyal Ricks		EDS-397 - Add sp - pr_BUILD_OUTB_INST_WIPRO_DATASCRUB
01/18/18        John Bartholomay TETDM-1715 Remove Zero dollar CAS Segments																						    
*****************************************************************************************************/


	SET NOCOUNT ON;
	
	DECLARE @CatchErrorMessage VARCHAR(2200);
	DECLARE	@TOTAL_RECORDS INT
			,@DATASOURCEKEY INT
			
	SET @DATASOURCEKEY = '50'; --QNXT


BEGIN TRY
	--HRP_CLAIM_FILE Run controls
	BEGIN TRANSACTION 

	INSERT INTO EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT
			)
	VALUES('pr_EXSP_QNXT_CLAIM'
			,'1'
			,GETDATE()
			,NULL
			,NULL
			,0
			,GETDATE()
			)
	COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY

		--	
		-- Note 
		--6/25 - disable automation steps for initial testing
		--		

		--IF @ExecutionMode <> 'A'
		--BEGIN
		--	EXECUTE EXSP_HRP_CLAIM_EXCLUSION @DATASOURCEKEY,@exclusionmode
		--END

		--IF @ExecutionMode <> 'A'
		--BEGIN
		--	EXECUTE dbo.pr_EXSP_CLAIM_PROF_QNXT_CLMHEADER @ExecutionMode = 'M'
		--END
		--ELSE
		--BEGIN
		--	EXECUTE dbo.pr_EXSP_CLAIM_PROF_QNXT_CLMHEADER @ExecutionMode = 'A'
		--END
		
		EXECUTE dbo.pr_BUILD_OUTB_PROF_CLAIM_HEADER

		EXECUTE dbo.BUILD_OUTB_PROF_CLM_DETAIL

		EXECUTE dbo.BUILD_OUTB_PROF_DIAG

		EXECUTE dbo.BUILD_OUTB_PROF_DIAG_POINTERS

		EXECUTE dbo.BUILD_OUTB_PROF_EDSPROVIDER

		EXECUTE dbo.BUILD_OUTB_PROF_ADJUSTMENTS

		EXECUTE dbo.BUILD_OUTB_PROF_REQ5010
		
		EXECUTE dbo.BUILD_OUTB_PROF_5010

		EXECUTE dbo.pr_BUILD_OUTB_PROF_WIPRO_DATASCRUB

		EXECUTE	pr_BUILD_OUTB_PROF_REMOVE_DUP_ADJUSTMENTS --TETDM-1645

		EXECUTE pr_BUILD_OUTB_PROF_REMOVE_ZERO_CAS_AMTS --TETDM-1715

		EXECUTE dbo.BUILD_OUTB_PROF_MAP

		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY

	SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM EXT_HRP_CLAIM)
	SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM EXT_HRP_CLAIM_DETAIL)
									
	----HRP_CLAIM_FILE Update Run Controls
	BEGIN TRANSACTION

	UPDATE EXT_SYS_RUNLOG
	SET END_DT = GETDATE()	
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
		,TOTAL_RECORDS = @TOTAL_RECORDS
		,ENTRYDT = GETDATE()
	WHERE PROC_NAME = 'pr_EXSP_QNXT_CLAIM'
					and END_DT is null
		IF @@ERROR <> 0
					BEGIN 
							ROLLBACK 
					END
	COMMIT TRANSACTION

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH




/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()

BEGIN TRANSACTION

	EXEC [dbo].[pr_EXSP_QNXT_CLAIM]
		@ExecutionMode	= 'M'
		
ROLLBACK TRANSACTION

SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/









