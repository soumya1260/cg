﻿CREATE PROCEDURE dbo.pr_SUPP_CLM_DIAG_COUNTS
/******************************************
Creation Date 7/24/2019
Author: ASU
Loads "SUPP_CLM_DIAG_COUNTS" items into Supplemental_Input

Notes:
*/
AS

SET NOCOUNT ON;

IF OBJECT_ID('tempdb.dbo.#Raw_Pull') IS NOT NULL
	DROP TABLE #Raw_Pull;

CREATE TABLE #Raw_Pull
(
	Plan_no VARCHAR(5),
	HicNo VARCHAR(20),
	X_HICN VARCHAR(12),
	X_MBI VARCHAR(11),
	MemberID VARCHAR(16),
	From_Date date,
	Thru_Date DATE,
	Provider_Type VARCHAR(2),
	DxCode VARCHAR(10),
	icdversion INT,
	SourceSystem VARCHAR(20),
	SourceSystemNumber VARCHAR(20),
	SourceType VARCHAR(200),
	Patient_Control_No VARCHAR(70),
	DOS_YR VARCHAR(4),
	Linked_Claim_number VARCHAR(20),
	WIPRO_CLAIM_NO VARCHAR(20),
	CHS_CLM_EDPS VARCHAR(20),
	CMS_ICN VARCHAR(20),
	Supp_Type VARCHAR(20),
	[Data_Source] VARCHAR(25),
	DocumentProvID VARCHAR(20),
	ChartProv VARCHAR(20),
	ChartChase_NPI VARCHAR(10),
	EXCL_ID VARCHAR(2),
	Status_Code VARCHAR(3) DEFAULT '000',
	Status_desc VARCHAR(20) DEFAULT 'New_Claims',
	Process_Date DATE,
	Last_Modified_Date DATE
);

DECLARE @Max_Load_Date DATETIME = (SELECT MAX(scdct.LOADDATE) FROM WIPRO.dbo.SUPP_CLAIM_DIAG_COUNTS scdct),
		@Process_Date DATE = GETDATE();

IF OBJECT_ID('tempdb.dbo.#working_clmdim') IS NOT NULL
	DROP TABLE #working_clmdim;

SELECT
	*
	,FormTypeCode_Prep = CASE 
                     		WHEN c.FORMTYPECODE = 'U' THEN '01'
                     		WHEN c.FORMTYPECODE = 'H' THEN '20'
							ELSE NULL                     	
						 END
	,SourceSystem_Prep = CASE 
                    		WHEN c.SourceDataKey = 50 THEN 'QNXT'
                    		WHEN c.SourceDataKey = 30 THEN 'LEON'
							ELSE NULL
						 END
	,BeginServiceDateKey_Cast = TRY_CAST(TRY_CAST(c.BeginServiceDateKey AS VARCHAR(8)) AS DATE)
	,EndServiceDateKey_Cast = TRY_CAST(TRY_CAST(NULLIF(c.EndServiceDateKey,0) AS VARCHAR(8)) AS DATE)
INTO #working_clmdim
FROM EDPS_Data.dbo.CLAIMDIM c
WHERE EXISTS (	SELECT 1 
				FROM WIPRO.dbo.SUPP_CLAIM_DIAG_COUNTS scdct 
				WHERE 1 = 1
					AND scdct.CLAIMID = c.CLAIMID 
					AND scdct.SOURCEDATAKEY = c.SOURCEDATAKEY
					AND scdct.LOADDATE = @Max_Load_Date);



WITH monthly_member AS ( --get subset of member data for below and cast dates from INTs for DATE to DATE compare
	SELECT DISTINCT
		mmd.MemberID,
		mmd.MedicareID,
		mmd.HCFACode,
		BeginCoverageDateKey_Convert = TRY_CAST(TRY_CAST(mmd.BeginCoverageDateKey AS VARCHAR(8)) AS DATE),
		EndCoverageDateKey_Convert = TRY_CAST(TRY_CAST(mmd.EndCoverageDateKey AS VARCHAR(8)) AS DATE),
		mmd.PCPID
	FROM EDPS_Data.dbo.MonthlyMembershipDim mmd
	WHERE 1 = 1
		AND mmd.HCFACode NOT LIKE '%S%'
		AND mmd.HCFACode  != '-----'
		AND EXISTS (SELECT 1 FROM #working_clmdim wc WHERE wc.MemberID = mmd.MemberID)
),
source_type AS ( --get distinct source types
	SELECT DISTINCT
		srsdt.Type
	   ,Source = TRY_CAST(srsdt.Source AS INT)
	FROM WIPRO.dbo.SUPP_RAPS_Source_Desc_Type srsdt
	WHERE EXISTS (SELECT 1 FROM #working_clmdim wc WHERE srsdt.Source = TRY_CAST(wc.SourceDataKey AS varchar)))
INSERT INTO #Raw_Pull (	Plan_no, HicNo, X_HICN, X_MBI, MemberID, From_Date, Thru_Date, Provider_Type, DxCode, icdversion,
						SourceSystem, SourceSystemNumber, SourceType, Patient_Control_No, DOS_YR,  
						Data_Source, DocumentProvID, ChartProv, ChartChase_NPI, 
						Process_Date, Last_Modified_Date)
SELECT
	 Plan_no = mm.HCFACode
	,HicNo = mm.MedicareID --original field was mixed with HicNo and MBI.  Field was split below to X_HICN and XMBI
	,X_HICN = NULL
	,x_MBI = NULL
	,MemberID = wc.MemberID
	,From_Date = wc.BeginServiceDateKey_Cast
	,Thru_Date = wc.EndServiceDateKey_Cast
	,Provider_Type = wc.FormTypeCode_Prep
	,DxCode = REPLACE(cdx.DIAGNOSISCODE,'.','')
	,icdversion = IIF(cdx.DiagnosisCodeVersion = '0','10',cdx.DiagnosisCodeVersion)
	,SourceSystem = wc.SourceSystem_Prep
	,SourceSystemNumber = wc.CLAIMID
	,SourceType = st.Type
	,Patient_Control_No =	ISNULL(wc.MemberID,'') + '-' + 	ISNULL(wc.SourceSystem_Prep,'') + '-' + ISNULL(wc.CLAIMID,'')
	,DOS_YR = LEFT(TRY_CAST(wc.EndServiceDateKey AS VARCHAR(8)),4)
	,Data_Source = 'SUPP_CLM_DIAG_COUNTS'
	,DocumentProvID = ''
	,ChartProv = ''
	,ChartChase_NPI = IIF(c.VENDORNPI IS NOT NULL, c.VENDORNPI, '')
	,Process_Date = @Process_Date
	,Last_Modified_Date = @Process_Date
FROM #working_clmdim wc
JOIN EDPS_Data.dbo.CLAIMDIAGNOSISDIM cdx
	ON wc.CLAIMID = cdx.CLAIMID
	AND wc.SOURCEDATAKEY = cdx.SourceDataKey
JOIN EDPS_Data.dbo.CLAIMDIM c
	ON wc.CLAIMID = c.CLAIMID
	AND wc.BeginServiceDateKey_Cast = TRY_CAST(TRY_CAST(c.BeginServiceDateKey AS VARCHAR(8)) AS DATE)
	AND wc.EndServiceDateKey_Cast = TRY_CAST(TRY_CAST(c.EndServiceDateKey AS VARCHAR(8)) AS DATE)
LEFT JOIN monthly_member mm
	ON wc.MemberID = mm.MemberID
	AND wc.BeginServiceDateKey_Cast BETWEEN mm.BeginCoverageDateKey_Convert AND mm.EndCoverageDateKey_Convert
LEFT JOIN Source_Type st
	ON st.Source = wc.SourceDataKey

INSERT INTO WIPRO.dbo.Supplemental_INPUT (	Plan_No, Hic_No, X_HICN, X_MBI, Member_ID, From_Date, Thru_Date, Provider_Type, Dx_Code,
											icd_version, Source_System, Source_System_Number, Source_Type, Patient_Control_No, 
											DOS_YR, Linked_Claim_number, WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type, Data_Source, 
											Document_Prov_ID, Chart_Prov, Chart_Chase_NPI, EXCL_ID, STATUS_CODE, Status_desc, Process_Date, Last_Modified)
SELECT DISTINCT
	rp.Plan_no
   ,rp.HicNo
   ,rp.X_HICN
   ,rp.X_MBI
   ,rp.MemberID
   ,rp.From_Date
   ,rp.Thru_Date
   ,rp.Provider_Type
   ,rp.DxCode
   ,rp.icdversion
   ,rp.SourceSystem
   ,rp.SourceSystemNumber
   ,rp.SourceType
   ,rp.Patient_Control_No
   ,rp.DOS_YR
   ,rp.Linked_Claim_number
   ,rp.WIPRO_CLAIM_NO
   ,rp.CHS_CLM_EDPS
   ,rp.CMS_ICN
   ,rp.Supp_Type
   ,rp.Data_Source
   ,rp.DocumentProvID
   ,rp.ChartProv
   ,rp.ChartChase_NPI
   ,rp.EXCL_ID
   ,rp.Status_Code
   ,rp.Status_desc
   ,rp.Process_Date
   ,rp.Last_Modified_Date
FROM #Raw_Pull rp;

IF OBJECT_ID('tempdb.dbo.#working_clmdim') IS NOT NULL
	DROP TABLE #working_clmdim;
IF OBJECT_ID('tempdb.dbo.#Raw_Pull') IS NOT NULL
	DROP TABLE #Raw_Pull;

SET NOCOUNT OFF;
