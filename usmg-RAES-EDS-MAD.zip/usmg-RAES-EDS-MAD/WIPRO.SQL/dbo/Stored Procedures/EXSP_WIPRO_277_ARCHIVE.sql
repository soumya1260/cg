﻿
CREATE PROCEDURE [dbo].[EXSP_WIPRO_277_ARCHIVE]
AS
/*	************************************************************************************************
Scott Waller April 2016

I have cloned this from the MAO002 version.  I am leaving all comments here from the MAO002 version
too.

***************************************************************************************************/

/***************************************************************************************************
** CREATE DATE: 03/2014
**
** AUTHOR: LOYAL RICKS - Loyal Ricks
**
** DESCRIPTION: Procedure will archive inbound mao004 data from "mao004 Daily Tables" to 
**				apropriate "mao004 Non Daily" tables. 
**				Archive process designed to execute before daily execution of mao004 job.
**				Archiving daily before process will allow business group access to daily
**				update data for auditing and validation.
**				Daily mao004 tables will be truncated after archiving.
**				
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
03/27/2015		Loyal Ricks		WIPRO mao004 - TETDM-53 - Revised procedure append to EXT_SYS_RUNLOG
								replacing Verisk label with WIPRO label.
04/08/2015		Loyal Ricks		TETDM-73 mao-004 Version 1.1.0 Updates -mao_004_DETAIL/mao_004_DETAIL_DAILY
08/03/2017		Subhash Acharya TETDM-1526 changed delete to truncate
05/31/2019		Subhash Acharya TETDM-2056 LoadDate
*****************************************************************************************************/
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
DECLARE @TOTAL_RECORDS INT;


--HRP_CLAIM_FILE Run controls

INSERT INTO EXT_SYS_RUNLOG
(
    PROC_NAME,
    STEP,
    START_DT,
    END_DT,
    RUN_MINUTES,
    TOTAL_RECORDS,
    ENTRYDT
)
VALUES
('EXSP_WIPRO_277_ARCHIVE', '1', GETDATE(), NULL, NULL, 0, GETDATE());

--Archive WIPRO_277_HEADER
INSERT INTO [dbo].[WIPRO_277_Header]
(
    [HeaderID],
    [InboundFileName],
    [RecordType],
    [HeaderVersion],
    [FileCategory],
    [FileCategoryTrailerVersion],
    [FileStandardBody],
    [FileType],
    [FileVersion],
    [FileSubType],
    [FileID],
    [RESERVED01],
    [FileCreateDate],
    [ProductionIndicator],
    [ClientID],
    [VendorID],
    [SystemSource],
    [RESERVED02],
    [RESERVED03],
    [RESERVED04],
    [RESERVED05],
    [RESERVED06],
    [RESERVED07]
)
SELECT HeaderID,
       InboundFileName,
       RecordType,
       HeaderVersion,
       FileCategory,
       FileCategoryTrailerVersion,
       FileStandardBody,
       FileType,
       FileVersion,
       FileSubType,
       FileID,
       RESERVED01,
       FileCreateDate,
       ProductionIndicator,
       ClientID,
       VendorID,
       SystemSource,
       RESERVED02,
       RESERVED03,
       RESERVED04,
       RESERVED05,
       RESERVED06,
       RESERVED07
FROM WIPRO_277_Header_Daily;

---Archive WIPRO_277_FileStatus
INSERT INTO dbo.WIPRO_277_FileStatus
(
    FSID,
    InboundFileName,
    RecordType,
    ClaimsReceived,
    ClaimsAccepted,
    ClaimsRejected,
    CMSTransDate
)
SELECT FSID,
       InboundFileName,
       RecordType,
       ClaimsReceived,
       ClaimsAccepted,
       ClaimsRejected,
       CMSTransDate
FROM WIPRO_277_FileStatus_Daily;

--Archive Trailer
INSERT INTO dbo.WIPRO_277_Trailer
(
    TrailerID,
    InboundFileName,
    RecordType,
    FileID,
    NumberOfAcceptedRecords,
    NumberOfRejectedRecords
)
SELECT TrailerID,
       InboundFileName,
       RecordType,
       FileID,
       NumberOfAcceptedRecords,
       NumberOfRejectedRecords
FROM WIPRO_277_Trailer_Daily;

--Archive Accepted
INSERT INTO dbo.WIPRO_277_Accepted
(
    DetailID,
    InboundFileName,
    RecordType,
    ClaimType,
    BillingProviderNPI,
    BillingProviderLastName,
    BillingProviderFirstName,
    BillingProviderMiddle,
    WIPROID,
    ProviderStatusActionCode,
    HCClaimStatusCategoryCode,
    HCClaimStatusCode,
    AssignedRejectMessageID,
    AssignedRejectMessageIDDetail,
    HICN,
    StatusActionCode,
    ClaimStatusCategoryCode,
    ClaimStatusCode,
    AssRejectMessageID,
    AssRejectMessageIDDetail,
    TotalClaimChargeAmount,
    ClaimStatusTrackingNumber,
    PlanClaimNumber,
    ServiceStartDate,
    ServiceEndDate
)
SELECT DetailID,
       InboundFileName,
       RecordType,
       ClaimType,
       BillingProviderNPI,
       BillingProviderLastName,
       BillingProviderFirstName,
       BillingProviderMiddle,
       WIPROID,
       ProviderStatusActionCode,
       HCClaimStatusCategoryCode,
       HCClaimStatusCode,
       AssignedRejectMessageID,
       AssignedRejectMessageIDDetail,
       HICN,
       StatusActionCode,
       ClaimStatusCategoryCode,
       ClaimStatusCode,
       AssRejectMessageID,
       AssRejectMessageIDDetail,
       TotalClaimChargeAmount,
       ClaimStatusTrackingNumber,
       PlanClaimNumber,
       ServiceStartDate,
       ServiceEndDate
FROM WIPRO_277_Accepted_Daily;

--Archive Rejected
INSERT INTO dbo.WIPRO_277_Rejected
(
    DetailID,
    InboundFileName,
    RecordType,
    ClaimType,
    WIPROID,
    PlanClaimNumber,
    ServiceLineNumber,
    ServiceIDQualifier,
    ProcedureCode,
    ProcedureModifier1,
    ProcedureModifier2,
    ProcedureModifier3,
    ProcedureModifier4,
    LineItemTotalChargeAmt,
    RevenueCode,
    Quantity,
    HCClaimStatusCategoryCode,
    HCClaimStatusCode,
    ActionCode,
    AssignedRejectMessageID,
    AssignedRejectMessageIDDetail
)
SELECT DetailID,
       InboundFileName,
       RecordType,
       ClaimType,
       WIPROID,
       PlanClaimNumber,
       ServiceLineNumber,
       ServiceIDQualifier,
       ProcedureCode,
       ProcedureModifier1,
       ProcedureModifier2,
       ProcedureModifier3,
       ProcedureModifier4,
       LineItemTotalChargeAmt,
       RevenueCode,
       Quantity,
       HCClaimStatusCategoryCode,
       HCClaimStatusCode,
       ActionCode,
       AssignedRejectMessageID,
       AssignedRejectMessageIDDetail
FROM WIPRO_277_Rejected_Daily;


--ASSIGN @TOTAL_RECORDS - GET RECORD COUNTS For table being archived
SET @TOTAL_RECORDS =
(
    SELECT COUNT(*) FROM WIPRO_277_Header_Daily
);
SET @TOTAL_RECORDS = @TOTAL_RECORDS +
                     (
                         SELECT COUNT(*) FROM WIPRO_277_FileStatus_Daily
                     );
SET @TOTAL_RECORDS = @TOTAL_RECORDS +
                     (
                         SELECT COUNT(*) FROM WIPRO_277_Trailer_Daily
                     );
SET @TOTAL_RECORDS = @TOTAL_RECORDS +
                     (
                         SELECT COUNT(*) FROM WIPRO_277_Accepted_Daily
                     );
SET @TOTAL_RECORDS = @TOTAL_RECORDS +
                     (
                         SELECT COUNT(*) FROM WIPRO_277_Rejected_Daily
                     );

--Truncate Daily tables
TRUNCATE TABLE WIPRO_277_Header_Daily;
TRUNCATE TABLE WIPRO_277_FileStatus_Daily;
TRUNCATE TABLE WIPRO_277_Trailer_Daily;
TRUNCATE TABLE WIPRO_277_Accepted_Daily;
TRUNCATE TABLE WIPRO_277_Rejected_Daily;

----HRP_CLAIM_FILE Update Run Controls
UPDATE EXT_SYS_RUNLOG
SET END_DT = GETDATE(),
    RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()),
    TOTAL_RECORDS = @TOTAL_RECORDS,
    ENTRYDT = GETDATE()
WHERE PROC_NAME = 'EXSP_WIPRO_WIPRO_277_ARCHIVE'
      AND END_DT IS NULL;




