﻿CREATE PROCEDURE [dbo].[EDS_Claims_Processing_CSV_Insert]
(		@LOB VARCHAR(25),
		@ISDME BIT = 0,
		@CLAIM_TYPE VARCHAR(20),		
		@SOURCEDATAKEY INT,		
		@ISADJUSTMENT BIT,
		@ENCOUNTERSOURCENAME VARCHAR(120) = NULL, --Optional, if not provided, only non-encounters pulled.
		@IsResub BIT = 0, --Optional, if not provided, run regular claims
		@IsRetraction BIT = 0,
		@RETRACTION_TYPE VARCHAR(20) = '')
AS

SET NOCOUNT ON;
DECLARE  @sql NVARCHAR(MAX)
		,@sql_params NVARCHAR(MAX)
		,@PRODUCTINDICATOR VARCHAR(4)
		,@FILEID CHAR(50)
		,@FILE_TYPE CHAR(50) = 'Claim Encounter'
		,@VERSION CHAR(10) = '1.5.3'
		,@Procedure_Name VARCHAR(75) = 'EDIFECS.dbo.EDS_Claims_Processing_CSV_Insert'
		,@Sender_ID VARCHAR(15)
		,@Receiver_ID VARCHAR(8)
		,@header_record VARCHAR(255)
		,@trailer_record VARCHAR(255)
		,@datarow_record_counts INT
		,@ENV VARCHAR(4) = (SELECT TOP 1 re.Enviornment FROM dbo.Resolve_Environment re WHERE @@servername = re.Server_Name)
		,@Short_Claim_Type VARCHAR(1) = CASE 
											WHEN @CLAIM_TYPE = 'PROFESSIONAL' AND @ISDME = 1 THEN 'E'
											WHEN @CLAIM_TYPE = 'PROFESSIONAL' THEN 'P'
											WHEN @CLAIM_TYPE = 'INSTITUTIONAL' THEN 'I'
											ELSE ''
										END
		,@RetractionNode VARCHAR(20)
		,@FileDesignation VARCHAR(20);

--Sender/Receiver ID setup										
IF @SOURCEDATAKEY IN (210,40) 
BEGIN;
	SELECT
		@Sender_ID = 'CHSAZCLP',
		@Receiver_ID = 'CHSAZAPP';
END;
ELSE
BEGIN;
	SELECT
		@Sender_ID = 'CHSMAOCLP',
		@Receiver_ID = 'ENC0159';
END;


--test setup
--SET @CLAIM_TYPE = 'INSTITUTIONAL';
--SET @ISDME = NULL;
--SET @LOB = 'MAO';
--SET @SOURCEDATAKEY = 50;
--SET @ENCOUNTERSOURCENAME = 'wellmed';

--lookup table
IF OBJECT_ID('tempdb.dbo.#clm_list') IS NOT NULL
	DROP TABLE #clm_list;

CREATE TABLE #clm_list
(
	CLAIMID VARCHAR(50),
	CLAIM_TYPE VARCHAR(50),
	SOURCEDATAKEY INT,
	SOURCEDESC VARCHAR(255),
	File_Number INT,
	Header_Record VARCHAR(255),
	Trailer_Record VARCHAR(100),
	[File_Name] VARCHAR(50),
	Counts_Per_File INT
);

--Begin populate initial claims
--need to switch lookup based on this
--future: make parameter for file_number and chunks for INST and PROF
--100000 for INST?, 75000 PROF?
 SET @sql = '
		INSERT INTO #CLM_list (CLAIMID, CLAIM_TYPE,SOURCEDATAKEY,SOURCEDESC,File_Number)
			SELECT
				ecpa.CLAIMID,
				ecpa.CLAIM_TYPE, 
				ecpa.SOURCEDATAKEY,
				ecpa.SOURCEDESC,
				File_Number = (ROW_NUMBER() OVER (ORDER BY(SELECT NULL)) - 1) / 100000
			FROM dbo.EDS_Claims_Processing ecpa
			WHERE 1 = 1
				AND ecpa.LOB = @LOB
				AND ecpa.SOURCEDATAKEY = @SOURCEDATAKEY
				AND ecpa.CLAIM_TYPE = @CLAIM_TYPE
				AND ecpa.ISMEDICARE = 1 ';

IF @ISDME = 1 BEGIN;
	SET @sql += 'AND ecpa.ISDME = 1 ';	
END;
ELSE BEGIN;
	SET @sql += 'AND ecpa.ISDME = 0 ';	
END;

--Normal Run
IF @ISRESUB = 0 AND @IsRetraction = 0 
 BEGIN
	SET @sql += 'AND ecpa.MEDICARESUBMISSIONDATE IS NULL AND ecpa.ISRESUB = 0 AND ecpa.ISRETRACTION = 0 '
END;
--Resub toggle
IF @IsResub = 1 BEGIN
	SET @sql += 'AND ecpa.ISRESUB = 1 '
END
--Retraction toggle
IF @IsRetraction = 1 BEGIN
	SET @sql += 'AND ecpa.ISRetraction = 1 AND ecpa.MEDICARESUBMISSIONDATE IS NULL AND ecpa.RETRACTION_TYPE = @RETRACTION_TYPE '
END

--encounter toggle
IF NULLIF(@ENCOUNTERSOURCENAME,'') IS NOT NULL  BEGIN;
	SET @sql += 'AND ecpa.ISEncounter = 1 AND ecpa.ENCOUNTERSOURCENAME = @ENCOUNTERSOURCENAME ';	
	SET @sql_params = CONCAT_WS(',',@sql_params, '@ENCOUNTERSOURCENAME VARCHAR(120) = '+ ''''+@ENCOUNTERSOURCENAME+'''');
END;    
ELSE BEGIN; -- default to no encounters
	SET @sql += 'AND ecpa.ISEncounter = 0 ';	
END;

IF @ISADJUSTMENT = 1 BEGIN;
	SET @sql += 'AND ecpa.ISADJUSTMENT = 1 ';	
END;
ELSE BEGIN;
	SET @sql += 'AND ecpa.ISADJUSTMENT = 0 ';
END;

--required
IF @LOB IS NOT NULL OR LTRIM(RTRIM(@LOB)) != '' BEGIN;
	SET @sql_params = CONCAT_WS(',',@sql_params, '@LOB VARCHAR(25) = '+ ''''+@LOB+'''');
END
ELSE RETURN;

--required
IF @SOURCEDATAKEY IS NOT NULL BEGIN;	
	SET @sql_params = CONCAT_WS(',',@sql_params, '@SOURCEDATAKEY INT = ' + CAST(@SOURCEDATAKEY AS VARCHAR));
END
ELSE RETURN;

--required
IF @CLAIM_TYPE IS NOT NULL OR LTRIM(RTRIM(@CLAIM_TYPE)) != '' BEGIN;	
	SET @sql_params = CONCAT_WS(',',@sql_params, '@CLAIM_TYPE VARCHAR(20) = '+ ''''+@CLAIM_TYPE+'''');
END
ELSE RETURN;

--required
IF @RETRACTION_TYPE IS NOT NULL OR LTRIM(RTRIM(@RETRACTION_TYPE)) != '' BEGIN;	
	SET @sql_params = CONCAT_WS(',',@sql_params, '@RETRACTION_TYPE VARCHAR(20) = '+ ''''+@RETRACTION_TYPE+'''');
END
ELSE RETURN;

--SELECT @sql_params
--SET @sql = CONCAT_WS(',',@sql,@sql_params);
--SELECT @sql

EXEC sys.sp_executesql @sql,@sql_params;

--end populate initial claims

--generate filename, header, trailer records

/* Filenaming convention updates (Retraction impact) */ 
SET @RetractionNode = (SELECT DISTINCT CASE WHEN RII.CLAIMID IS NOT NULL AND @SOURCEDATAKEY IN ('40','210') THEN '99' ELSE NULL END FROM #CLM_list cl
								LEFT JOIN WIPRO.dbo.Retraction_Input_Interim RII ON cl.CLAIMID = RII.CLAIMID);

SET @FileDesignation = (SELECT DISTINCT 
									CASE 
									   WHEN @RETRACTION_TYPE = 'CLM_DELETE' THEN 'VOID.DELETE' 
									   WHEN @RETRACTION_TYPE = 'CLM_VOID'	THEN 'VOID' 
									   WHEN @RETRACTION_TYPE = 'CR_DELETE'  THEN 'DELETE' 
									   WHEN @RETRACTION_TYPE = 'CR_VOID'	THEN 'VOID'
								       ELSE   'CARE' --<<-- ASK ABOUT THIS (NOT SURE IF ALL NEW ITEMS WILL BE CARE ONLY)
								  END 
								FROM #CLM_list cl
						);


WITH fl_config AS (
	SELECT
		File_Number
		,File_Claim_Counts = COUNT(cl.CLAIMID)
		,FILEID = CONCAT_WS('.'
								,'HSCE'
								,@ENV
								,CASE WHEN @IsRetraction = 1 THEN @LOB + '.AZ' ELSE @LOB END 
								,CASE WHEN @IsRetraction = 1 THEN @RetractionNode ELSE @SOURCEDATAKEY END
								,@Short_Claim_Type
								,@FileDesignation
								 ,FORMAT(GETDATE(),'yyyyMMddhhmmss')
								 ,File_Number
								)
	FROM #CLM_list cl
	GROUP BY File_Number
)
UPDATE cl
SET Header_Record = 
		CONCAT_WS('|','00','EMCSV',LTRIM(RTRIM(@VERSION)),LTRIM(RTRIM(FILEID)),'Medical',FORMAT(GETDATE(),'yyyyMMddhhmmss'),@Sender_ID,@Receiver_ID)
	, Trailer_Record = CONCAT_WS('|','01','TRT','0',File_Claim_Counts,'0',File_Claim_Counts)
	,[File_Name] = FILEID
	,Counts_Per_File = File_Claim_Counts
FROM #clm_list cl
JOIN fl_config fl 
	ON cl.File_Number = fl.File_Number;

/*
Reset claim type back to "P" after file name is created
Done because claims are really type "P" but file needs to go as type "E" if DME is sent by itself
*/
IF @ISDME = 1 BEGIN;
	SET @Short_Claim_Type = 'P';
END;

--end generate filename, header, trailer records

	--SELECT
	--	File_Name
	--   ,'H'
	--   ,SOURCEDATAKEY
	--   ,SOURCEDESC
	--   ,1
	--   ,Header_Record
	--   ,0
	--FROM #clm_list cl
	--UNION
	--SELECT
	--	File_Name
	--   ,'T'
	--   ,SOURCEDATAKEY
	--   ,SOURCEDESC
	--   ,9999
	--   ,Trailer_Record
	--   ,0
	--FROM #clm_list cl; --<<--DEBUG
	
	--SELECT
	--*
	--FROM #CLM_list; --<<--DEBUG


--temp table for csv pull (used later)
DECLARE @temp TABLE
(	
	extract_table_name VARCHAR(50),
	extract_table_schema VARCHAR(10),
	table_record_lead NVARCHAR(6),
	claim_type VARCHAR(1),
	table_order INT
);

DECLARE @csv_sql NVARCHAR(MAX)
	   ,@max_ordinal INT
	   ,@counter INT = 0
	   ,@extract_table_name VARCHAR(50)
	   ,@extract_table_schema VARCHAR(10)
	   ,@table_record_lead NVARCHAR(6)
	   ,@table_order INT;

INSERT INTO @temp (extract_table_name, extract_table_schema, table_record_lead, claim_type, table_order)
	VALUES  ('EE_CSV_100I_Rec_Header', 'dbo', '100|','I', 1),
			('EE_CSV_150I_Rec_Header', 'dbo', '150|','I', 2),
			('EE_CSV_20I_Rec_Header', 'dbo', '20I|','I', 3),
			('EE_CSV_310I_Rec_Header', 'dbo', '310|','I', 4),
			('EE_CSV_40I_Rec_Detail', 'dbo', '40I|','I', 5),
			('EE_CSV_431I_Rec_Detail', 'dbo', '431|','I', 6),
			('EE_CSV_100P_Rec_Header', 'dbo', '100|','P', 1),
			('EE_CSV_150P_Rec_Header', 'dbo', '150|','P', 2),
			('EE_CSV_20P_Rec_Header', 'dbo', '20P|','P', 3),
			('EE_CSV_310P_Rec_Header', 'dbo', '310|','P', 4),
			('EE_CSV_40P_Rec_Detail', 'dbo', '40P|','P', 5),
			('EE_CSV_431P_Rec_Detail', 'dbo', '431|','P', 6);

--Begin staging to dbo CSV table transfers

--set max ordinal based on claim type being pulled
SET @max_ordinal = (SELECT 
						MAX(table_order) 
					FROM @temp 
					WHERE claim_type = @Short_Claim_Type);
SET @counter = 1;
--Begin CSV table transfers (target claims from staging to dbo table)
WHILE @max_ordinal >= @counter BEGIN; 	
	SELECT
		@extract_table_name = extract_table_name
	   ,@extract_table_schema = extract_table_schema
	   ,@table_record_lead = table_record_lead
	FROM @temp
	WHERE 1 = 1
		AND table_order = @counter 
		AND claim_type = @Short_Claim_Type;

	SET @csv_sql =  '
					DELETE EDIFECS.dbo.'+@extract_table_name+';'+
					'INSERT INTO EDIFECS.dbo.'+@extract_table_name+'
						SELECT
							*
						FROM EDIFECS.staging.'+@extract_table_name+' a
						WHERE EXISTS (SELECT
											*
										FROM #clm_list cl
										WHERE 1 = 1
											AND a.ClaimID = cl.CLAIMID
											AND a.SourceDataKey = cl.SOURCEDATAKEY'
					+ IIF( NULLIF(@ENCOUNTERSOURCENAME,'') IS NOT NULL,' AND a.SourceDesc = cl.SOURCEDESC);',');')
	--SELECT @csv_sql; --debug only
	SET @counter += 1;
	EXEC sys.sp_executesql @csv_sql;
END;
--end CSV table transfers
     
--Begin CSV format table inserts (formated output for claims extract)
SET @counter = 1; --reset counter


WHILE @max_ordinal >= @counter BEGIN; 	
	SELECT
		@extract_table_name = extract_table_name
	   ,@extract_table_schema = extract_table_schema
	   ,@table_record_lead = table_record_lead
	FROM @temp
	WHERE 1 = 1
		AND table_order = @counter
		AND claim_type = @Short_Claim_Type;;

	SELECT
	@csv_sql =  'INSERT INTO WIPRO.dbo.OUTB_CLAIM_MAP_GENERIC  
				(File_Name, CLAIMID, Record_Type, CLAIM_TYPE, ClaimLineNumber, SOURCEDATAKEY, SOURCEDESC, Data_Row_Sort_Order, DATAROW, IsExportDone)

				select 
				cl.[File_Name],
				t.[ClaimID],
				[Record_Type] = ''D'',
				'''+@Short_Claim_Type+''','
				+IIF(@counter IN (5,6),' CAST(t.ClaimLineNumber AS INT), ',' NULL, ')  --if table order changes, UPDATE THIS!!!
				+'t.[SourceDataKey],
				t.[SourceDesc],
				record_order = ' +CAST(@counter AS VARCHAR)+','''
				+@table_record_lead+''' + '  
				+ STRING_AGG(CONCAT(	IIF(c.column_id != 1,'''|''+ ','')
						,'ISNULL(LTRIM(RTRIM('
						,IIF(t1.name = 'varchar' ,'t.['+ CAST(c.name AS VARCHAR(MAX))+']' , CONCAT('CAST(', '['+CAST(c.name AS VARCHAR(MAX) )+']',' AS VARCHAR)')) 
						,')),'''')'
						,char(13)
						,char(9)
					  )
				,' + ') WITHIN GROUP (ORDER BY c.column_id) 
				+' ,0 ' 
				+' FROM EDIFECS.'+@extract_table_schema+'.'+@extract_table_name + ' t'
				+' JOIN #CLM_list cl ON cl.CLAIMID = t.ClaimID'
				+';'
	FROM EDIFECS.sys.tables t
	JOIN EDIFECS.sys.columns c
		ON t.object_id = c.object_id
	JOIN EDIFECS.sys.schemas s
		ON t.schema_id = s.schema_id
	JOIN EDIFECS.sys.types t1
		ON c.system_type_id = t1.system_type_id
	WHERE t.name = '' +@extract_table_name + '' AND s.name = ''+@extract_table_schema+''
	AND c.name NOT IN ('SourceDataKey','SourceDesc','CreateDate','ClaimLineNumber');

	--SELECT 1, @csv_sql; --debug only
	SET @counter += 1;
	EXEC sys.sp_executesql @csv_sql;

END;



--reuse counter from last (should be max table counter from last statement)
SET @counter += 1; --<<-- used for trailer record sort order


IF EXISTS(	SELECT 
			* 
			FROM WIPRO.dbo.OUTB_CLAIM_MAP_GENERIC g
			WHERE EXISTS (SELECT * FROM #clm_list cl WHERE g.File_Name = cl.File_Name))
BEGIN; 
	INSERT INTO WIPRO.dbo.OUTB_CLAIM_MAP_GENERIC
	(File_Name,Record_Type, CLAIM_TYPE, SOURCEDATAKEY, SOURCEDESC, Data_Row_Sort_Order, DATAROW, IsExportDone)
		SELECT
			File_Name
		   ,'H'
		   ,@Short_Claim_Type
		   ,SOURCEDATAKEY
		   ,SOURCEDESC
		   ,0
		   ,Header_Record
		   ,0
		FROM #clm_list cl
		UNION
		SELECT
			 File_Name
		    ,'T'
		   	,@Short_Claim_Type
		   ,SOURCEDATAKEY
		   ,SOURCEDESC
		   ,@counter
		   ,Trailer_Record
		   ,@counter
		FROM #clm_list cl;
END;

SET NOCOUNT OFF;