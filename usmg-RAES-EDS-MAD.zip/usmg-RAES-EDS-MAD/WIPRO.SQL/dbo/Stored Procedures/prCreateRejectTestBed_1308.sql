﻿
CREATE PROCEDURE [dbo].[prCreateRejectTestBed_1308] (@RejectReason VARCHAR(20))
AS
/* 
Instructions:  set the reject reason id variable

*/

 ---------------------------------------------------------------
 --#REJECT_DETAIL
 ---------------------------------------------------------------
  SET NOCOUNT ON
  IF object_id('tempdb..#reject_detail') IS NOT NULL DROP TABLE #reject_detail

  SELECT
    CASE WHEN fileid LIKE '%mao%' THEN 'MAO'
         WHEN  fileid LIKE '%mmai%' THEN 'MMAI'
    ELSE 'unk' end AS JobType,
    *
  INTO
     #reject_detail
  FROM
     wipro.dbo.MAO_002_Detail WITH (NOLOCK)
  WHERE
     RejectReasonID = @RejectReason

   -----------------------------------------
   --##OUTPUT
   -----------------------------------------
   IF object_id('tempdb..##output') IS NOT NULL DROP TABLE ##output

   SELECT DISTINCT
      d.* ,
      s.SOURCEDATAKEY,
	  s.FILEID AS FILED_A
   INTO
      ##output
   FROM
      #reject_detail d
      LEFT JOIN OUTB_CLAIM_STATUS s
        ON d.PlanClaimNumber = s.CLAIM_ID
        AND d.hicn = s.HICN_NUM
	    
   -----------------------
   -- UPDATE JOB ID
   -- MMAI DIL
   -----------------------
   UPDATE ##output
   SET JobType = 'MMAI',
       RejectReasonID = '17311' 
   WHERE FILED_A LIKE '%MMAI.DIL%' 
   
   -----------------------
   -- UPDATE JOB ID
   -- MMAI MMP
   -----------------------
   UPDATE ##output
   SET JobType = 'MMAI',
       RejectReasonID = '17312' 
   WHERE FILED_A LIKE '%MMAI.DTX%' 	   


   ---------------------------------
   -- UPDATE OUTPUT
   ---------------------------------
   UPDATE ##output
   SET sourcedatakey = CASE WHEN LEFT(WIPRO_UNQ_ID,1) = 'A' THEN '2'
					WHEN LEFT(WIPRO_UNQ_ID,1) = 'B' THEN '3'
					WHEN LEFT(WIPRO_UNQ_ID,1) = 'C' THEN '4'
					WHEN LEFT(WIPRO_UNQ_ID,1) = 'D' THEN '30'
					WHEN LEFT(WIPRO_UNQ_ID,1) = 'E' THEN '50' END
   FROM ##output
   WHERE ISNULL(SOURCEDATAKEY,'') = ''
	
  ------------------------------------------------	   
  --insert these records into OUTB_WIPRO_TEST_BED
  ------------------------------------------------
  DELETE FROM [dbo].[OUTB_WIPRO_TEST_BED]
  WHERE TESTID IN ('17310','17311','17312')

 
  -------------------------------------------
  --TEST BED
  -------------------------------------------
  INSERT INTO [dbo].[OUTB_WIPRO_TEST_BED]
           ([TESTID]
           ,[TEST_DESC]
           ,[CLAIMID]
           ,[SOURCEDATAKEY]
           ,[CLAIM_TYPE] 
		   ,[typecode]
		   ,[ORIG_BIDW_EXTRACT_DT]
		   ,[LAST_BIDW_EXTRACT_DT]
           )
  SELECT DISTINCT
      RejectReasonID ,
      RejectReasonMessage ,
      PlanClaimNumber ,
      [SOURCEDATAKEY] ,
      CASE WHEN DMEFlag = 'Y' THEN DMEFlag ELSE [CLAIMTYPE] END,
	  JobType,
      GETDATE() AS ORIG_BIDW_EXTRACT_DT,
	  GETDATE() AS LAST_BIDW_EXTRACT_DT
  FROM
      ##output

	  
  ----------------------------------
  --QUERY
  ----------------------------------
  SELECT TESTID, TYPECODE,   SOURCEDATAKEY, CLAIM_TYPE, COUNT(*)ClaimCount FROM [OUTB_WIPRO_TEST_BED]
  WHERE TESTID IN ('17310','17311','17312')
GROUP BY TESTID, TYPECODE, SOURCEDATAKEY, CLAIM_TYPE
