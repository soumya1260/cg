﻿CREATE PROCEDURE dbo.Supp_Filter_Inbound_Dataset

(@Filter_Date_Floor DATE)
AS BEGIN
/*
This procedure will take fresh (or re-run data) supplemental data and apply designated filters.  
Data found here will be updated in the inbound supplemental table for export.
This procedure depends on a unique index on the staging.Supp_Excluded table
	This index is setup to silently drop duplicate IDs as they are entered so the filters do not 
	add the same data over and over per single run.

NOTES:
2023-09-03		ASU
	Initial Creation
2023-10-20		ASU
	Updates for RETM-502
		See Git repo https://github.sys.cigna.com/cigna/RAES-EDS-MAD for changes tagged to RETM-502
2024-05-15		ASU
	Updates for RETM-234
		See Git repo https://github.sys.cigna.com/cigna/RAES-EDS-MAD for changes/commits tagged to RETM-234
---------------------------

*/

	SET NOCOUNT ON;
	SET ANSI_NULLS ON;
	SET QUOTED_IDENTIFIER ON;

	DECLARE @Filter_Date_Floor_INT INT,
			@Filter_Date_Floor_VARCHAR VARCHAR(8),
			@Filter_Date_Floor_DATE DATE, --<< get around parameter sniffing SQL bug
			@Rolling_30_Date_Floor DATE = DATEADD(DAY,-30,CAST(GETDATE() AS DATE)),
			@Run_Log_ID INT = (SELECT ISNULL(MAX(sssl.Run_ID),0) + 1 FROM dbo.Supplemental_Submission_Sys_Log sssl),
			@Step INT = 0, --denote step in log table (used below)
			@Status_Code VARCHAR(3), --used below for log table
			@Step_Start_DateTime DATETIME = GETDATE(), --used for log table;
			@Overall_Start_Time DATETIME = GETDATE(), --Log start of process (used at very end)
			@Status_Zero_Count INT = (SELECT COUNT(*) FROM dbo.Supplemental_INPUT si WHERE si.STATUS_CODE = '000');

	--pre-converted dates for use in joins and where clauses below
   	SET @Filter_Date_Floor_INT =  CONVERT(VARCHAR(8), @Filter_Date_Floor, 112);
	SET @Filter_Date_Floor_VARCHAR = CONVERT(VARCHAR(8), @Filter_Date_Floor, 112);
	SET @Filter_Date_Floor_DATE = @Filter_Date_Floor;
	

	--Clear stage table before run
	TRUNCATE TABLE staging.Supp_Excluded;

	/*
	Begin temp table data gathering
	These temp tables below are used in the designated filters
	*/

		--log start claim numbers in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, 'Start','New Claims', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @Status_Zero_Count);

	--Create temp from MAO_004 for "exclusion ICNs" to be used in other queries below
	IF OBJECT_ID('tempdb.dbo.#CMS_MAO_004_Detail_Exclude_ICNS') IS NOT NULL
		DROP TABLE #CMS_MAO_004_Detail_Exclude_ICNS;
	IF OBJECT_ID('tempdb.dbo.#MAO002') IS NOT NULL
		DROP TABLE #MAO002;
	IF OBJECT_ID('tempdb.dbo.#Claim_Detail_Filter') IS NOT NULL
		DROP TABLE #Claim_Detail_Filter;

	--#CMS_MAO_004_Detail_Exclude_ICNS is Used by filters 9,10,12,13,14
	--And used in rough MAO-002 temp table generation
	--ICNs in this temp are assumed to be an exclusion
	SELECT 
		cmd.Linked_ENCICN
	INTO #CMS_MAO_004_Detail_Exclude_ICNS
	FROM CMS_MAO_004_Detail cmd
	WHERE 1 = 1	
		AND cmd.Encounter_Type_Switch IN ('2','5','7')
		AND cmd.Linked_ENCICN IS NOT NULL
		AND cmd.Linked_ENCICN != ''
	GROUP BY cmd.Linked_ENCICN;

	CREATE NONCLUSTERED INDEX idx_Linked_ENCICN
	ON #CMS_MAO_004_Detail_Exclude_ICNS (Linked_ENCICN ASC);


	--MAO-002 rough temp table
	--Get Rough dataset for this filter
	--data from below temp is used in filter 11 and filter 14
	SELECT 
		md.PlanClaimNumber,
		md.WIPRO_UNQ_ID,
		md.CMSICN,
		md.HICN,		
		md.ServiceEndDate,
		md.Billing_Prov_NPI,
		md.ClaimType
	INTO #MAO002
	FROM WIPRO.dbo.MAO_002_Detail md
	WHERE 1 = 1
		AND md.ServiceLineSequenceNumber = '000'
		AND md.ClaimType IN ('P', 'I')
		AND md.SubmissionType != 'CR'
		AND md.RecordType = 'A'
		AND md.PRELIMRaFlag = 'PA'
		AND md.ServiceEndDate > @Filter_Date_Floor_VARCHAR 
		AND CAST(md.LoadDate AS DATE) >= @Rolling_30_Date_Floor --<<-- Rolling 30 day lookback
		AND EXISTS (SELECT	*
					FROM dbo.Supplemental_INPUT si
					WHERE 1 = 1
						AND md.HICN = si.Hic_No
						AND si.Submission_Indicator = 1)
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd 
						WHERE cmd.Linked_ENCICN = md.CMSICN);
	--Generation time estimate: 00:02:32 - 00:10:05
	ALTER TABLE #MAO002 REBUILD PARTITION = ALL WITH (DATA_COMPRESSION = PAGE);

	CREATE NONCLUSTERED INDEX idx_CMSICN_HICN_ServiceEndDate_Billing_Prov_NPI
	ON #MAO002 (CMSICN, HICN, ServiceEndDate, Billing_Prov_NPI ASC)
	INCLUDE (WIPRO_UNQ_ID,PlanClaimNumber);

	--The below temp table is only used for filter 8
	--about 4 min for generation
	--This temp primarily exist to avoid doing join on DX_CODE_DROP_PERIOD with replace function
	--If this field is changed this temp could be eliminated
	SELECT DISTINCT
		c.CLAIMID,
		c.MEMBERID,	
		EndServiceDateKey,
		DX_CODE_DROP_PERIOD = REPLACE(c1.DIAGNOSISCODE,'.','')
	INTO #Claim_Detail_Filter
	FROM EDPS_Data.dbo.CLAIMDIM c
	JOIN EDPS_Data.dbo.CLAIMDIAGNOSISDIM c1
		ON c.CLAIMID = c1.CLAIMID
	WHERE 1 = 1
		AND c.EndServiceDateKey >= @Filter_Date_Floor_INT 
		AND EXISTS ( SELECT 
						* 
					FROM dbo.Supplemental_INPUT si
					WHERE 1 = 1
						AND si.Member_ID = c.MEMBERID
						AND (si.Submission_Indicator = 1)
						AND si.J_Thru_Date_INT = c.EndServiceDateKey)  
		AND EXISTS ( SELECT 
						*
					FROM WIPRO.dbo.MAO_002_Detail md
					WHERE 1 = 1
						AND md.PlanClaimNumber = c.CLAIMID
						AND md.ServiceLineSequenceNumber = '000'
						AND md.RecordType = 'A'
						AND md.PRELIMRaFlag = 'PA'
						AND md.ServiceEndDate > @Filter_Date_Floor_VARCHAR); 

	/*END Temp table generations*/

	/*
		Filter duplicate claims first	
		Compare claims in status code ('008','009','111','000')
		against all the items already in the table
		take the lowest ID as "Original"
	*/
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '666',
			@Step_Start_DateTime = GETDATE();

	WITH dup_test_1 AS (
		SELECT
			Min_Accepted_ID = MIN(original.ID)
			,Duplicated_ID =	  dup.ID	
		FROM dbo.Supplemental_INPUT original
		JOIN dbo.Supplemental_INPUT dup ON
			original.Member_ID = dup.Member_ID			
			AND original.From_Date = dup.From_Date
			AND original.Thru_Date = dup.Thru_Date		
			AND original.Dx_Code = dup.Dx_Code
			AND original.ID < dup.ID	
		WHERE 1 = 1
				AND original.STATUS_CODE IN ('008','009','111','000')		
		GROUP BY dup.ID, dup.Process_Date)
	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator, Original_ID)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_desc = 'Dup_Claim',
		Submission_Indicator = 0,
		dt.Min_Accepted_ID
	FROM Supplemental_INPUT si
	JOIN dup_test_1 dt ON 
		si.ID = dt.Duplicated_ID;

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Dup_Claim', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	/*
	Secondary duplicate filter to check against output table
	for claims submitted already
	*/
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '666',
			@Step_Start_DateTime = GETDATE();

	WITH Supp_Out AS (
		SELECT
			so.HIC_NBR,
			From_Date = TRY_CAST(so.From_Date AS DATE),
			Thru_Date = TRY_CAST(so.Thru_Date AS DATE),
			so.DIAG01_CODE,
			IS_Resubmit = IIF(so.Response_Status_Reserverd_1 != 'A-ICN',0,1)
		FROM dbo.Supplemental_OUTPUT so
		WHERE so.Response_Status_Reserverd_1 IN ('A-ICN','A','A-999','A-277')			
	),
	dup_test_2 AS (
		SELECT
			dup.ID
			,original.IS_Resubmit
		FROM Supp_Out original
		JOIN dbo.Supplemental_INPUT dup ON
			original.HIC_NBR = dup.Hic_No
			AND original.From_Date = dup.From_Date
			AND original.Thru_Date = dup.Thru_Date		
			AND original.DIAG01_CODE = dup.Dx_Code
		WHERE dup.STATUS_CODE IN ('000')) --000 --> New Claims
	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_desc = IIF(si.IS_Resubmit = 0,'Prior_Cycle_Claim', 'Dup_Claim_In_Motion'),
		Submission_Indicator = si.IS_Resubmit
	FROM dup_test_2 si;

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,('Prior_Cycle_Claim'+' OR '+ 'Dup_Claim_In_Motion'), @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);



	/*End duplicate claim filter */

	--Filter 1 AZ match
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '001',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'AZ_match',
		Submission_Indicator = 0
	FROM dbo.Supplemental_INPUT si
	WHERE 1 = 1
		AND (si.Submission_Indicator = 1)
		AND si.Plan_No = 'H0354';

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'AZ_match', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);



	--Filter 2 Diag Match found from MAO004 table
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '006',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Diag_Match_found_MAO004',
		Submission_Indicator = 0,
		CLAIMID
	FROM dbo.Supplemental_INPUT si
	JOIN dbo.EDS_Submissions_MAO004_Detail esmd
	ON 	esmd.MemberId = si.Member_Id
		AND esmd.DOS_THRU BETWEEN si.J_From_Date_VARCHAR AND si.J_Thru_Date_VARCHAR 
		AND esmd.Dx_Code = si.Dx_Code
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND esmd.DOS_THRU > @Filter_Date_Floor_VARCHAR 
		AND esmd.AllowedDisallowedFlagENCICN = 'A'
		AND esmd.Diag_Retraction_Flag = '0'
		AND esmd.Encounter_Type_Switch IN ('1','3','4');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Diag_Match_found_MAO004', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 3 HCC Not Found
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '333',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator)
	SELECT
		si.ID,
		Status_Code = '333',
		Status_Desc = 'HCC_Not_Found',
		Submission_Indicator = 1
	FROM dbo.Supplemental_INPUT si
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND NOT EXISTS (SELECT * FROM MDQOLib.dim.RAModelDxToHCC xhm WHERE xhm.DxCode = si.Dx_Code)
		AND NOT EXISTS (SELECT * FROM WIPRO.dbo.XREF_HCC_MODEL xhm WHERE xhm.Diagnosis_Code = si.Dx_Code);

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'HCC_Not_Found', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 4 Data Error with HPLAN
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '002',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Data_Error_HPLAN',
		Submission_Indicator = 0
	FROM dbo.Supplemental_INPUT si
	WHERE 1 = 1
		AND Submission_Indicator = 1
		AND (si.Plan_No IN ('','-----', 'NULL','UNKNOWN') OR si.Plan_No IS NULL);

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Data_Error_HPLAN', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 5 Termed HPLAN
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '003',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Termed_HPLAN',
		Submission_Indicator = 0
	FROM dbo.Supplemental_INPUT si
	WHERE 1 = 1 
		AND si.Submission_Indicator = 1
		AND EXISTS (	SELECT
							*
						FROM WIPRO.dbo.EXT_HPLAN_EXCLUDE ehe
						WHERE 1 = 1
							AND si.Plan_No = ehe.HPLAN
							AND si.Thru_Date > ehe.EXCLUSION_DT);

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Termed_HPLAN', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 6 Provider Preclusion
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '004',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Provider_Preclusion',
		Submission_Indicator = 1
	FROM dbo.Supplemental_INPUT si
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND EXISTS (SELECT
						*
					FROM EDPS_Data.dbo.PROVIDERPRECLUSIONLIST p
					WHERE 1 = 1
						AND si.Chart_Chase_NPI = p.NPI
						AND p.CLMREJECTDATE BETWEEN si.J_From_Date_VARCHAR AND si.J_Thru_Date_VARCHAR);

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Provider_Preclusion', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 7a SOS Exclusion
	--NOTE: to be removed at later date (leave in for now)
	--INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
	--	(ID, Filter_Code, Filter_Description, Submission_Indicator)
	--SELECT
	--	si.ID,
	--	Status_Code = '005',
	--	Status_Desc = 'SOS_Exclusion',
	--	Submission_Indicator = 1
	--FROM dbo.Supplemental_INPUT si
	--WHERE 1 = 1
	--	AND si.Submission_Indicator = 1
	--	AND EXISTS (SELECT *
	--				FROM dbo.RAPS_DX_COMPLIANCE_HOLD rdch
	--				WHERE 1 = 1
	--					AND rdch.CLM_NO = si.Source_System_Number
	--					AND rdch.DIAGNOSIS_CODE = si.Dx_Code
	--					AND rdch.HOLD_TABLE_STATUS IN (18,4,16,1));
	
	--Filter 8b Retraction Exclusion
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '005',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Retraction_Exclusion',
		Submission_Indicator = 1
	FROM dbo.Supplemental_INPUT si
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND EXISTS (SELECT *
					FROM dbo.SUPP_RETRACTION_INPUT sri
					WHERE 1 = 1
						AND sri.MEM_ID = si.Member_ID
						AND si.J_From_Date_VARCHAR BETWEEN sri.Dos_dt AND sri.dos_thru_dt
						AND si.Dx_Code = sri.diagnosis_code);

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Retraction_Exclusion', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


---------


	--Filter 9 Diag match found in MAO 002 table
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '007',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded
		(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Diag_Match_found_MAO002',
		Submission_Indicator = 0,
		CLAIMID
	FROM dbo.Supplemental_INPUT si
	JOIN #Claim_Detail_Filter cdf 
		ON	si.Member_ID = cdf.MEMBERID
		AND si.J_Thru_Date_INT = EndServiceDateKey  
		AND si.Dx_Code = DX_CODE_DROP_PERIOD
	WHERE si.Submission_Indicator = 1;

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Diag_Match_found_MAO002', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--drop temp filter table 
	IF OBJECT_ID('tempdb.dbo.#Claim_Detail_Filter') IS NOT NULL
		DROP TABLE #Claim_Detail_Filter;
		

	IF OBJECT_ID('tempdb.dbo.#Claim_Detail_Filter') IS NOT NULL
		DROP TABLE #Claim_Detail_Filter;
	
	--Filter 10 MAO 004 LINKED MATCH NPI
	/*
	
	*/
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '008',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded
	(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number,
		WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type )
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO004_LINKED_MATCH_NPI',
		Submission_Indicator = 0,
		Linked_Claim_number = PROF.ClaimID,
		VendorClaimID = PROF.VendorClaimID,
		CHS_CLM_EDPS = PROF.ClaimID,
		EncounterICN = PROF.EncounterICN,
		Supp_Type = 'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
		JOIN dbo.EDS_Submissions_MAO004_Detail PROF
		ON si.Member_id = PROF.MemberId
			AND si.J_Thru_Date_VARCHAR = PROF.DOS_THRU
			AND si.Chart_Chase_NPI IN ( PROF.Billing_Prov_NPI, PROF.Rendering_NPI)
	WHERE 1 = 1				
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name NOT LIKE '%INST%'
		AND PROF.DOS_THRU > @Filter_Date_Floor_VARCHAR
		AND PROF.AllowedDisallowedFlagENCICN = 'A'
		AND PROF.Diag_Retraction_Flag = '0'
		AND PROF.Encounter_Type_Switch IN ('1')
		AND PROF.ClaimType IN ('P')
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmdei 
						WHERE PROF.Linked_ENCICN = cmdei.Linked_ENCICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE PROF.ClaimID = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%')
	UNION
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO004_LINKED_MATCH_NPI',
		Submission_Indicator = 0,
		Linked_Claim_number = INST.ClaimID, 
		VendorClaimID = INST.VendorClaimID, 
		CHS_CLM_EDPS = INST.ClaimID,
		EncounterICN = INST.EncounterICN, 
		Supp_Type = 'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN dbo.EDS_Submissions_MAO004_Detail INST
	ON si.Member_id = INST.MemberId
		AND si.J_Thru_Date_VARCHAR = INST.DOS_THRU
		AND si.Chart_Chase_NPI IN ( INST.Billing_Prov_NPI, INST.Rendering_NPI)		
	WHERE 1 = 1				
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name LIKE '%INST%'
		AND INST.DOS_THRU > @Filter_Date_Floor_VARCHAR
		AND INST.AllowedDisallowedFlagENCICN = 'A'
		AND INST.Diag_Retraction_Flag = '0'
		AND INST.Encounter_Type_Switch IN ('1')
		AND INST.ClaimType IN ('I','N','O')
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmdei 
						WHERE INST.Linked_ENCICN = cmdei.Linked_ENCICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE INST.ClaimID = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'MAO004_LINKED_MATCH_NPI', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 11 Master Recon LINKED MATCH NPI
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '008',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded 
		(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number,
			WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type )
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Master_Recon_LINKED_MATCH_NPI',
		Submission_Indicator = 0,
		Linked_Claim_number = PROF.claimid,
		-- this is not present in Master recon table it is in outbound status table? we can add that while creating the file
		VendorClaimID = (	SELECT TOP 1 ocs.WIPRO_CLAIM_ID  --<<--QUESTION
							FROM OUTB_CLAIM_STATUS ocs 
							WHERE 1 = 1
								AND PROF.CMS_ICN = ocs.CMS_ICN),
		CHS_CLM_EDPS = PROF.claimid,
		CMS_ICN = PROF.CMS_ICN,
		Supp_Type = 'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN dbo.EDS_Claims_Master_Recon PROF
	ON si.Member_id = PROF.MemberId
		AND si.J_Thru_Date_INT = PROF.EndServiceDate
	AND si.Chart_Chase_NPI IN ( PROF.BillingProvNPI, PROF.RenderingProvNPI)
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name NOT LIKE '%INST%'
		AND PROF.EndServiceDate > @Filter_Date_Floor_INT 
		AND PROF.HCC_Eligible = '1'
		AND PROF.ClaimType = 'P'
		AND PROF.claim_status = 'A-ICN'
		AND CAST(PROF.LastModifiedDate AS DATE) >= @Rolling_30_Date_Floor
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd
						WHERE cmd.Linked_ENCICN = PROF.CMS_ICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE PROF.claimid = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%')
	UNION
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Master_Recon_LINKED_MATCH_NPI',
		Submission_Indicator = 0,
		Linked_Claim_number = INST.claimID,
		-- this is not present in Master recon table it is in outbound status table? we can add that while creating the file
		VendorClaimID = (	SELECT TOP 1 ocs.WIPRO_CLAIM_ID  --<<--QUESTION
							FROM OUTB_CLAIM_STATUS ocs 
							WHERE 1 = 1
								AND INST.CMS_ICN = ocs.CMS_ICN),
		CHS_CLM_EDPS = INST.claimID,
		CMS_ICN = INST.CMS_ICN,
		Supp_Type = 'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN dbo.EDS_Claims_Master_Recon INST
	ON si.Member_id = INST.MemberId
		AND si.J_Thru_Date_INT = INST.EndServiceDate
		AND si.Chart_Chase_NPI IN ( INST.BillingProvNPI, INST.RenderingProvNPI)		
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name LIKE '%INST%'
		AND INST.EndServiceDate > @Filter_Date_Floor_INT 
		AND INST.HCC_Eligible = '1'
		AND INST.ClaimType = 'I'
		AND INST.claim_status = 'A-ICN'
		AND CAST(INST.LastModifiedDate AS DATE) >= @Rolling_30_Date_Floor
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd
						WHERE cmd.Linked_ENCICN = INST.CMS_ICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE INST.claimid = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Master_Recon_LINKED_MATCH_NPI', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 12 MAO-002 LINKED MATCH NPI
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '008',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
			(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number,
				WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type )
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO002_LINKED_MATCH_NPI',
		Submission_Indicator = 0,
		PlanClaimNumber,
		WIPRO_UNQ_ID,
		PlanClaimNumber,
		CMSICN,		
		'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN #MAO002 mao2
		ON si.Hic_No = mao2.HICN
		AND si.J_Thru_Date_VARCHAR = mao2.ServiceEndDate
		AND si.Chart_Chase_NPI = mao2.Billing_Prov_NPI		
	WHERE 1 = 1
		AND mao2.ClaimType = 'P'
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name NOT LIKE '%INST%'
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE mao2.PlanClaimNumber = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%')
	UNION
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO002_LINKED_MATCH_NPI',
		Submission_Indicator = 0,
		PlanClaimNumber,
		WIPRO_UNQ_ID,
		PlanClaimNumber,
		CMSICN,		
		'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN #MAO002 mao2
		ON si.Hic_No = mao2.HICN
		AND si.J_Thru_Date_VARCHAR = mao2.ServiceEndDate
		AND si.Chart_Chase_NPI = mao2.Billing_Prov_NPI
	WHERE 1 = 1
		AND mao2.ClaimType = 'I'
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name LIKE '%INST%'
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE mao2.PlanClaimNumber = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'MAO002_LINKED_MATCH_NPI', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 12a MAO004_LINKED_MATCH_CLM (wellmed only)
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '010',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number,
			WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type )
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO004_LINKED_MATCH_CLM',
		Submission_Indicator = 0,
		Linked_Claim_number = ClaimID,
		VendorClaimID,
		CHS_CLM_EDPS = ClaimID,
		EncounterICN,		
		Supp_Type = 'LINKED_SUB'		
	FROM dbo.Supplemental_INPUT si
	JOIN dbo.EDS_Submissions_MAO004_Detail esmd
	ON si.Member_id = esmd.MemberId
		AND si.J_Thru_Date_VARCHAR = esmd.DOS_THRU		
		AND si.Source_System_Number = esmd.claimid
	WHERE 1 = 1				
		AND si.Submission_Indicator = 1
		AND esmd.DOS_THRU > @Filter_Date_Floor_VARCHAR
		AND esmd.AllowedDisallowedFlagENCICN = 'A'
		AND esmd.Diag_Retraction_Flag = '0'
		AND esmd.Source_desc like 'WEL%'
		AND esmd.Encounter_Type_Switch IN ('1')
		AND esmd.ClaimType = 'P'
		AND si.Input_File_Name NOT LIKE '%INST%'
		AND NOT EXISTS (SELECT * 
		    			FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd 
						WHERE cmd.Linked_ENCICN = esmd.Linked_ENCICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE esmd.ClaimID = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%')
	UNION ALL --<<-- should be ok not filtering duplicates here
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO004_LINKED_MATCH_CLM',
		Submission_Indicator = 0,
		Linked_Claim_number = ClaimID,
		VendorClaimID,
		CHS_CLM_EDPS = ClaimID,
		EncounterICN,		
		Supp_Type = 'LINKED_SUB'		
	FROM dbo.Supplemental_INPUT si
	JOIN dbo.EDS_Submissions_MAO004_Detail esmd
	ON si.Member_id = esmd.MemberId
		AND si.J_Thru_Date_VARCHAR = esmd.DOS_THRU		
		AND si.Source_System_Number = esmd.claimid
	WHERE 1 = 1				
		AND si.Submission_Indicator = 1
		AND esmd.DOS_THRU > @Filter_Date_Floor_VARCHAR
		AND esmd.AllowedDisallowedFlagENCICN = 'A'
		AND esmd.Diag_Retraction_Flag = '0'
		AND esmd.Source_desc like 'WEL%'
		AND esmd.Encounter_Type_Switch IN ('1')
		AND esmd.ClaimType = 'I'
		AND si.Input_File_Name LIKE '%INST%'
		AND NOT EXISTS (SELECT * 
		    			FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd 
						WHERE cmd.Linked_ENCICN = esmd.Linked_ENCICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE esmd.ClaimID = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'MAO004_LINKED_MATCH_CLM', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 12b MAO004_LINKED_MATCH_CLM (wellmed only)
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '010',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number,
			WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Master_Recon_LINKED_MATCH_CLM',
		Submission_Indicator = 0,
		Linked_Claim_number = ClaimID,
		-- this is not present in Master recon table it is in outbound status table? we can add that while creating the file
		VendorClaimID = (SELECT TOP 1 ocs.WIPRO_CLAIM_ID FROM OUTB_CLAIM_STATUS ocs WHERE esmd.CMS_ICN = ocs.CMS_ICN),
		CHS_CLM_EDPS = ClaimID,
		esmd.CMS_ICN,		
		Supp_Type = 'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN  [WIPRO].[dbo].[EDS_Claims_Master_Recon] esmd
		ON si.Member_id = esmd.MemberId
		AND si.J_From_Date_INT = esmd.BeginServiceDate 		
		AND si.Source_System_Number = esmd.claimid
	WHERE 1 = 1
		AND si.Input_File_Name NOT LIKE '%INST%'
		AND si.Submission_Indicator = 1
		AND CAST(esmd.LastModifiedDate AS DATE) >= @Rolling_30_Date_Floor
		AND esmd.EndServiceDate > @Filter_Date_Floor_INT 
		AND esmd.HCC_Eligible = '1'
		AND esmd.ClaimType = 'P'
		AND esmd.claimid like '%WEL%'
		AND esmd.claim_status = 'A-ICN'				
		AND	NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd
						WHERE cmd.Linked_ENCICN = esmd.CMS_ICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE esmd.claimid = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%')
	UNION ALL --<<-- should be ok not filtering duplicates here
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Master_Recon_LINKED_MATCH_CLM',
		Submission_Indicator = 0,
		Linked_Claim_number = ClaimID,
		-- this is not present in Master recon table it is in outbound status table? we can add that while creating the file
		VendorClaimID = (SELECT TOP 1 ocs.WIPRO_CLAIM_ID FROM OUTB_CLAIM_STATUS ocs WHERE esmd.CMS_ICN = ocs.CMS_ICN),
		CHS_CLM_EDPS = ClaimID,
		esmd.CMS_ICN,		
		Supp_Type = 'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN  WIPRO.dbo.EDS_Claims_Master_Recon esmd
		ON si.Member_id = esmd.MemberId
		AND si.J_From_Date_INT = esmd.BeginServiceDate		
		AND si.Source_System_Number = esmd.claimid
	WHERE 1 = 1
		AND si.Input_File_Name LIKE '%INST%'
		AND si.Submission_Indicator = 1
		AND CAST(esmd.LastModifiedDate AS DATE) >= @Rolling_30_Date_Floor
		AND esmd.EndServiceDate > @Filter_Date_Floor_INT 
		AND esmd.HCC_Eligible = '1'
		AND esmd.ClaimType = 'I'
		AND esmd.claimid like '%WEL%'
		AND esmd.claim_status = 'A-ICN'				
		AND	NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd
						WHERE cmd.Linked_ENCICN = esmd.CMS_ICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE esmd.claimid = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Master_Recon_LINKED_MATCH_CLM', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 12c MAO004_LINKED_MATCH_CLM (wellmed only)
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '010',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number,
			WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type)
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO002_LINKED_MATCH_CLM',
		Submission_Indicator = 0,
		PlanClaimNumber,
		WIPRO_UNQ_ID,
		PlanClaimNumber,
		CMSICN,		
		'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN #MAO002 mao2
		ON si.Hic_No = mao2.HICN
		AND si.J_Thru_Date_VARCHAR = mao2.ServiceEndDate			
		AND si.Source_System_Number = mao2.planclaimnumber
	WHERE 1 = 1
		AND si.Source_System_Number LIKE '%WEL%'
		AND si.Input_File_Name LIKE '%INST%'
		AND si.Submission_Indicator = 1
		AND mao2.ClaimType = 'I'
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE mao2.PlanClaimNumber = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%')
	UNION ALL --<<-- should be ok not filtering duplicates here
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO002_LINKED_MATCH_CLM',
		Submission_Indicator = 0,
		PlanClaimNumber,
		WIPRO_UNQ_ID,
		PlanClaimNumber,
		CMSICN,		
		'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN #MAO002 mao2
		ON si.Hic_No = mao2.HICN
		AND si.J_Thru_Date_VARCHAR = mao2.ServiceEndDate			
		AND si.Source_System_Number = mao2.planclaimnumber
	WHERE 1 = 1
		AND si.Source_System_Number LIKE '%WEL%'
		AND si.Input_File_Name NOT LIKE '%INST%'
		AND si.Submission_Indicator = 1
		AND mao2.ClaimType = 'P'
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE mao2.PlanClaimNumber = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'MAO002_LINKED_MATCH_CLM', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);



	--Filter 13 MAO-004 LINKED MATCH MBRID
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '009',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded WITH (TABLOCK)
		(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number,
			WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type )
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO004_LINKED_MATCH_MBRID',
		Submission_Indicator = 0,
		Linked_Claim_number = ClaimID,
		VendorClaimID,
		CHS_CLM_EDPS = ClaimID,
		EncounterICN,		
		Supp_Type = 'LINKED_SUB'		
	FROM dbo.Supplemental_INPUT si
	JOIN dbo.EDS_Submissions_MAO004_Detail esmd
		ON si.Member_id = esmd.MemberId
		AND si.Thru_Date = esmd.DOS_THRU	
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name NOT LIKE '%INST%'
		AND esmd.DOS_THRU > @Filter_Date_Floor_VARCHAR 
		AND esmd.AllowedDisallowedFlagENCICN = 'A'
		AND esmd.Diag_Retraction_Flag = '0'
		AND esmd.Encounter_Type_Switch = '1'
		AND esmd.ClaimType = 'P'
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd
						WHERE cmd.Linked_ENCICN = esmd.EncounterICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE esmd.ClaimID = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%')
	UNION ALL --<<-- should be ok not filtering duplicates here
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO004_LINKED_MATCH_MBRID',
		Submission_Indicator = 0,
		Linked_Claim_number = ClaimID,
		VendorClaimID,
		CHS_CLM_EDPS = ClaimID,
		EncounterICN,		
		Supp_Type = 'LINKED_SUB'		
	FROM dbo.Supplemental_INPUT si
	JOIN dbo.EDS_Submissions_MAO004_Detail esmd
		ON si.Member_id = esmd.MemberId
		AND si.Thru_Date = esmd.DOS_THRU	
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name LIKE '%INST%'
		AND esmd.DOS_THRU > @Filter_Date_Floor_VARCHAR 
		AND esmd.AllowedDisallowedFlagENCICN = 'A'
		AND esmd.Diag_Retraction_Flag = '0'
		AND esmd.Encounter_Type_Switch = '1'
		AND esmd.ClaimType = 'I'
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd
						WHERE cmd.Linked_ENCICN = esmd.EncounterICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE esmd.ClaimID = ocs.CLAIM_ID
						AND ocs.FILEID LIKE '%ADJ%');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'MAO004_LINKED_MATCH_MBRID', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


		--Filter 14 Master Recon LINKED MATCH MBR
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '009',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded 
		(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number,
			WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type )
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Master_Recon_LINKED_MATCH_MBR',
		Submission_Indicator = 0,
		Linked_Claim_number = ClaimID,
		-- this is not present in Master recon table it is in outbound status table
		VendorClaimID = (SELECT TOP 1 ocs.WIPRO_CLAIM_ID FROM OUTB_CLAIM_STATUS ocs WHERE esmd.CMS_ICN = ocs.CMS_ICN),
		CHS_CLM_EDPS = ClaimID,
		esmd.CMS_ICN,		
		Supp_Type = 'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN [dbo].[EDS_Claims_Master_Recon] esmd
		ON si.Member_id = esmd.MemberId
		AND si.J_Thru_Date_INT = esmd.EndServiceDate
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name NOT LIKE '%INST%'
		AND CAST(esmd.RefreshDate AS DATE) >= @Rolling_30_Date_Floor
		AND esmd.EndServiceDate > @Filter_Date_Floor_INT  
		AND esmd.HCC_Eligible = '1'
		AND esmd.ClaimType = 'P'
		AND esmd.claim_status = 'A-ICN'
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd
						WHERE cmd.Linked_ENCICN = esmd.CMS_ICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE 1 = 1
							AND esmd.claimid = ocs.CLAIM_ID
							AND ocs.FILEID LIKE '%ADJ%')
	UNION ALL --<<-- should be ok not filtering duplicates here
	SELECT 
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Master_Recon_LINKED_MATCH_MBR',
		Submission_Indicator = 0,
		Linked_Claim_number = ClaimID,
		-- this is not present in Master recon table it is in outbound status table
		VendorClaimID = (SELECT TOP 1 ocs.WIPRO_CLAIM_ID FROM OUTB_CLAIM_STATUS ocs WHERE esmd.CMS_ICN = ocs.CMS_ICN),
		CHS_CLM_EDPS = ClaimID,
		esmd.CMS_ICN,		
		Supp_Type = 'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN [dbo].[EDS_Claims_Master_Recon] esmd
		ON si.Member_id = esmd.MemberId
		AND si.J_Thru_Date_INT = esmd.EndServiceDate
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name LIKE '%INST%'
		AND CAST(esmd.RefreshDate AS DATE) >= @Rolling_30_Date_Floor
		AND esmd.EndServiceDate > @Filter_Date_Floor_INT  
		AND esmd.HCC_Eligible = '1'
		AND esmd.ClaimType = 'I'
		AND esmd.claim_status = 'A-ICN'
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd
						WHERE cmd.Linked_ENCICN = esmd.CMS_ICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE 1 = 1
							AND esmd.claimid = ocs.CLAIM_ID
							AND ocs.FILEID LIKE '%ADJ%');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Master_Recon_LINKED_MATCH_MBR', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 15
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '009',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded 
			(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number,
				WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type )
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO002_LINKED_MATCH_MBR',
		Submission_Indicator = 0,
		PlanClaimNumber,
		WIPRO_UNQ_ID,
		PlanClaimNumber,
		CMSICN,
		'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN #MAO002 mao2
		ON si.Hic_No = HICN
		AND si.J_Thru_Date_VARCHAR = mao2.ServiceEndDate
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name LIKE '%INST%'
		AND mao2.ClaimType = 'I'
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd
						WHERE cmd.Linked_ENCICN = mao2.CMSICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE 1 = 1
							AND mao2.PlanClaimNumber = ocs.CLAIM_ID
							AND ocs.FILEID LIKE '%ADJ%')
	UNION ALL --<<-- should be ok not filtering duplicates here
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'MAO002_LINKED_MATCH_MBR',
		Submission_Indicator = 0,
		PlanClaimNumber,
		WIPRO_UNQ_ID,
		PlanClaimNumber,
		CMSICN,
		'LINKED_SUB'
	FROM dbo.Supplemental_INPUT si
	JOIN #MAO002 mao2
		ON si.Hic_No = HICN
		AND si.J_Thru_Date_VARCHAR = mao2.ServiceEndDate	
	WHERE 1 = 1
		AND si.Submission_Indicator = 1
		AND si.Input_File_Name NOT LIKE '%INST%'
		AND mao2.ClaimType = 'P'
		AND NOT EXISTS (SELECT * 
						FROM #CMS_MAO_004_Detail_Exclude_ICNS cmd
						WHERE cmd.Linked_ENCICN = mao2.CMSICN)
		AND NOT EXISTS (SELECT * 
						FROM dbo.OUTB_CLAIM_STATUS ocs
						WHERE 1 = 1
							AND mao2.PlanClaimNumber = ocs.CLAIM_ID
							AND ocs.FILEID LIKE '%ADJ%');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'MAO002_LINKED_MATCH_MBR', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 16
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '112',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded
			(ID, Filter_Code, Filter_Description, Submission_Indicator, Linked_Claim_number,
				WIPRO_CLAIM_NO, CHS_CLM_EDPS, CMS_ICN, Supp_Type)
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Master_Recon_Claim_In_Motion_REJ',
		Submission_Indicator = 1,
		ClaimID,
		-- this is not present in Master recon table it is in outbound status table
		VendorClaimID = (SELECT TOP 1 ocs.WIPRO_CLAIM_ID FROM OUTB_CLAIM_STATUS ocs WHERE esmd.CMS_ICN = ocs.CMS_ICN),
		ClaimID,
		esmd.CMS_ICN,		
		'LINKED_SUB_motion'
	FROM dbo.Supplemental_INPUT si
	JOIN  [WIPRO].[dbo].[EDS_Claims_Master_Recon] esmd
	ON si.Member_id = esmd.MemberId
	AND si.J_From_Date_INT = esmd.BeginServiceDate 
	WHERE 1 = 1
		AND si.Submission_Indicator = 1	
		AND esmd.EndServiceDate > @Filter_Date_Floor_INT 
		AND esmd.HCC_Eligible = '1'
		AND esmd.ClaimType = 'P'
		AND esmd.claim_status in ('R', 'R-ICN', 'R-999', 'R-277');

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Master_Recon_Claim_In_Motion_REJ', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);


	--Filter 17 Blanket update filter
	--log step start
	SELECT  @Step += 1,
			@Status_Code = '111',
			@Step_Start_DateTime = GETDATE();

	INSERT INTO staging.Supp_Excluded 
			(ID, Filter_Code, Filter_Description, Submission_Indicator, 
				 Supp_Type )
	SELECT
		si.ID,
		Status_Code = @Status_Code,
		Status_Desc = 'Unlinked',
		Submission_Indicator = 0,				
		'UNLINKED'
	FROM dbo.Supplemental_INPUT si
	WHERE si.Submission_Indicator = 1;

	--log step end in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID, @Step, @Status_Code,'Unlinked', @Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime), @@rowcount);



	--cleanup temp tables
	IF OBJECT_ID('tempdb.dbo.#CMS_MAO_004_Detail_Exclude_ICNS') IS NOT NULL
		DROP TABLE #CMS_MAO_004_Detail_Exclude_ICNS;
	IF OBJECT_ID('tempdb.dbo.#MAO002') IS NOT NULL
		DROP TABLE #MAO002;
	IF OBJECT_ID('tempdb.dbo.#Claim_Detail_Filter') IS NOT NULL
		DROP TABLE #Claim_Detail_Filter;

	SET @Step_Start_DateTime = GETDATE();

	/*Update Input Table*/
	UPDATE si
	SET si.STATUS_CODE = se.Filter_Code,
		si.Status_desc = se.Filter_Description,
		si.Submission_Indicator = se.Submission_Indicator,				
		si.Linked_Claim_number = se.Linked_Claim_number,
		si.WIPRO_CLAIM_NO = se.WIPRO_CLAIM_NO,
		si.CHS_CLM_EDPS = se.CHS_CLM_EDPS,
		si.CMS_ICN = se.CMS_ICN,
		si.Supp_Type = se.Supp_Type,		
		si.Last_Modified = GETDATE(),
		si.Process_Date = GETDATE(),
		si.Original_ID = se.Original_ID
	FROM dbo.Supplemental_INPUT si WITH (TABLOCK)
	JOIN staging.Supp_Excluded se 
		ON si.ID = se.ID;

	--log update duration in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description, Step_Start_Date, Step_End_Date,Step_Duration, Step_Record_Count)
		VALUES (@Run_Log_ID,(@Step + 1),'Done','Update Records',@Step_Start_DateTime,GETDATE(),(GETDATE() - @Step_Start_DateTime),@@rowcount);

	--log process duration in table
	INSERT INTO dbo.Supplemental_Submission_Sys_Log 
		(Run_ID, Step_Order, Step_Status_Code,Step_Description,  Step_Duration)
		VALUES (@Run_Log_ID, (@Step + 2),'Stats','Run Stats',CAST(GETDATE() - @Overall_Start_Time AS TIME(0)));

	SET NOCOUNT OFF;
END