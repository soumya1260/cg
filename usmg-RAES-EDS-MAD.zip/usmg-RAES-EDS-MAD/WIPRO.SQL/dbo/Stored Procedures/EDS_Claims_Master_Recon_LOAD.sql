﻿
CREATE PROCEDURE [dbo].[EDS_Claims_Master_Recon_LOAD]

/* 
04/09/2021	Scott Waller	TETDM-2497.   New procedure to keep track of "new" (delta) claims after each refresh.
							Cloned from the EDS_Claims_Master processes.
							

---------------------------------------------------------------------------
Modifications
Date		Developer		Description
---------------------------------------------------------------------------
08/04/2021	Scott Waller	TETDM-2530 correct the SDK 4 claim collection.  
							It is grabbing all rows for each claim, not just the header.
							Which over inflates the claim counts.

02/07/2022	Scott Waller	RETM-26	Update Column Value for BeginService Date in
							the EDS_Claims_Master_Recon_LOAD table.
							Do for both ClaimDim claims and EncounterClaimDim claims.

12/07/2022	Scott Waller	RETM-157	Many columns were added to the EDS_Claims_Master_Recon and
							EDS_Claims_Master_Recon_Archive but are not being populated.  This
							ticket has requested we populate these 4 columns:
							gender, EndServiceDate, RenderingProvNPI, BillingProvNPI

01/23/2023	Scott Waller	RETM-177 Correction to the change in RETM-157.   
							SourceDataKey needs to be a part of the join to the 
							MDQOLib.dbo.MemberDim table.

05/01/2023	Scott Waller	RETM-249  Change the EncounterClaimDim table data retrieval.
							Remove this logic:  AND	e.ClaimFrequencyCode	= '1' 
							We want ALL ClaimFrequencyCode values.
------------------------------------------------------------------------------ */
AS 
    BEGIN
        DECLARE @TOTAL_RECORDS INT

        INSERT  INTO dbo.EXT_SYS_RUNLOG
                ( PROC_NAME ,
                  STEP ,
                  START_DT ,
                  END_DT ,
                  RUN_MINUTES ,
                  TOTAL_RECORDS ,
                  ENTRYDT
                )
        VALUES  ( 'EDS_Claims_Master_Recon_LOAD' ,
                  '1' ,
                  GETDATE() ,
                  NULL ,
                  NULL ,
                  0 ,
                  GETDATE()
                )

-------------------------------------------------------------------------------------
-- Collect the "new claims"
-------------------------------------------------------------------------------------

-- get a single static date/time that will act as the unique idenifier to this set of data being loaded
        DECLARE @vCurrentDateTime DATETIME
        SET @vCurrentDateTime = GETDATE()	

-- load all "new" regular claims (that aren't already in EDS_Claims_Master_Recon_Archive table)
-- RETM-157  Populating 4 values for 4 new columns
        INSERT  INTO WIPRO.dbo.EDS_Claims_Master_Recon
			(claimid, sourcedatakey, RefreshDate, sourcedesc, memberid, DOS_Year, BeginServiceDate, ClaimType, LastModifiedDate,
			 EndServiceDate, BillingProvNPI, gender, RenderingProvNPI) 
                SELECT  DISTINCT 
						a.claimid,
                        a.sourcedatakey,
						@vCurrentDateTime,
						NULL,
						a.memberid,
-- RETM-26						YEAR(getdate()),
						substring(cast(a.BeginServiceDateKey as char(20)), 1, 4) as DOS_Year,	-- RETM-26
						a.BeginServiceDateKey,
						CASE a.FORMTYPECODE 
							WHEN 'H' THEN 'P' 
							WHEN 'U' THEN 'I' 
							ELSE a.FORMTYPECODE
						END,
						@vCurrentDateTime AS LastModifiedDate,
-- RETM-157 next 4 columns
						EndServiceDate		= a.EndServiceDateKey,
						BillingProvNPI		= a.VENDORNPI,
						Gender				= MD.Gender,
						RenderingProvNPI	= (	SELECT	MAX(CDD.PROVIDERNPI)
												FROM	EDPS_Data.dbo.ClaimDetailDim CDD
												WHERE	CDD.sourcedatakey	= a.sourcedatakey
												AND		CDD.claimid			= a.claimid )
                FROM    EDPS_Data.dbo.claimdim	a
				LEFT OUTER JOIN	MDQOLib.dbo.MemberDim MD		-- RETM-157
					ON	MD.MemberID			= a.memberid	
					AND	MD.SourceDataKey	= a.SOURCEDATAKEY	-- RETM-177
				where not exists	(select	1 
									 from	WIPRO.dbo.EDS_Claims_Master_Recon_Archive b
									 where	b.sourcedatakey		= a.SOURCEDATAKEY
									 and	b.claimid			= a.CLAIMID)
				and	not exists		(select	1 
									 from	WIPRO.dbo.EDS_Claims_Master_Recon c
									 where	c.sourcedatakey		= a.SOURCEDATAKEY
									 and	c.claimid			= a.CLAIMID)
-- identifying new claims that dont already exist in the Recon Archive table or the Recon table
-- this is because this new process will not necessarily be archiving the Recon table on a monthly basis
-- it'll more likely be quarterly

       ;WITH EncounterClaimBasket AS 
       (	SELECT	*
			FROM ( SELECT
						e.ClaimNum , 
                        e.sourcedatakey , 
						@vCurrentDateTime as RefreshDate,
						e.Sourcedesc,
						e.MemberID,
						MD.Gender,	-- RETM-157 4 columns
						e.EndServiceDateKey,
						e.vendorid, 
						e.ProviderID,  
-- RETM-26				YEAR(getdate()) as DOS_Year,
						substring(cast(e.BeginServiceDateKey as char(20)), 1, 4) as DOS_Year,	-- RETM-26
						e.BeginServiceDateKey,
						e.ClaimType,
						@vCurrentDateTime as LastModifiedDate,
                        latest = ROW_NUMBER() OVER (PARTITION BY e.CLAIMNUM, e.ClaimLineNum, e.MemberID, e.SOURCEDESC ORDER BY  e.LoadDateKey DESC, e.BeginServiceDateKey, e.FILENAME DESC)
                   FROM	EDPS_Data.dbo.encounterclaimdim e
				   	INNER JOIN EDS_Audit.dbo.EDS_Encounter_SourceDesc s		-- this logic/join assures we only get active Vendors (SourceDesc)
						ON	e.SourceDesc			= s.SourceDesc
						AND e.BeginServiceDateKey		BETWEEN startdate AND enddate
					LEFT JOIN dbo.EDS_Claims_Master_Recon_Archive a 
						ON	a.claimid				= e.ClaimNum 
						AND a.sourcedatakey			= e.SourceDataKey 
						AND A.sourcedesc			= e.sourcedesc 
						AND A.memberid				= e.memberid
					LEFT JOIN MDQOLib.dbo.MemberDim MD					-- RETM-157
						ON	MD.MemberID				= e.MemberID
						AND	MD.SourceDataKey		= e.SourceDataKey	-- RETM-177
                   WHERE	1 = 1
-- RETM-249        AND	e.ClaimFrequencyCode	= '1' 
				   AND	e.BeginServiceDateKey	>= 20150101 
                   AND  e.sourcedatakey			= 4 
				   AND	e.claimlinenum			= 1		-- TETDM-2530
                   AND  a.claimid				IS NULL) sub
              WHERE sub.latest = 1
       )

		INSERT  INTO WIPRO.dbo.EDS_Claims_Master_Recon
			(claimid, sourcedatakey, RefreshDate, sourcedesc, memberid, DOS_Year, BeginServiceDate, ClaimType, LastModifiedDate,
			 gender, EndServiceDate, BillingProvNPI, RenderingProvNPI) -- RETM-157
                 SELECT  DISTINCT 
                        c.ClaimNum , 
                        c.sourcedatakey , 
						c.RefreshDate,
						c.SourceDesc,
						c.MemberID,
						c.DOS_Year,
						c.BeginServiceDateKey,
						c.ClaimType,
						c.LastModifiedDate,
						c.Gender,
						c.EndServiceDateKey,
						c.vendorid, 
						c.ProviderID
                FROM    EncounterClaimBasket c 
				where not exists	(select	1 
									 from	WIPRO.dbo.EDS_Claims_Master_Recon b
									 where	b.sourcedatakey		= c.SOURCEDATAKEY
									 and	b.claimid			= c.ClaimNum)
-- identifying new claims that dont already exist in the Recon Archive table or the Recon table
-- this is because this new process will not necessarily be archiving the Recon table on a monthly basis
-- it'll more likely be quarterly

        SELECT  @TOTAL_RECORDS = COUNT(*)
        FROM    WIPRO.dbo.EDS_Claims_Master_Recon
		WHERE	RefreshDate = @vCurrentDateTime		-- just want the count of the new claims added during this current run

-- now update data for LOB
	UPDATE	dbo.EDS_Claims_Master_Recon
	SET		LOB		=	 mmd.lobcode
	FROM	dbo.EDS_Claims_Master_Recon ECMR
	INNER JOIN EDPS_Data.dbo.MonthlyMembershipDim	mmd
		ON	mmd.MemberID				= ECMR.MemberID
		AND ECMR.BeginServiceDate		BETWEEN mmd.ModifiedReportDateKey - 14
										AND     mmd.ReportDateKey

-- update Run Controls
        UPDATE  dbo.EXT_SYS_RUNLOG
        SET     END_DT = GETDATE() ,
                RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
                TOTAL_RECORDS = @TOTAL_RECORDS ,
                ENTRYDT = GETDATE()
        WHERE   PROC_NAME = 'EDS_Claims_Master_Recon_LOAD'
                AND END_DT IS NULL
                AND STEP = '1'
  
    END


GO
