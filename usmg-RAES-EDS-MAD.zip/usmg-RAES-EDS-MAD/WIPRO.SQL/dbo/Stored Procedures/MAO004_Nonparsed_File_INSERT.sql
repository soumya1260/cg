﻿CREATE PROCEDURE dbo.MAO004_Nonparsed_File_INSERT
AS
	SET NOCOUNT ON;

	DECLARE @rebuild BIT = 1; --default to rebuild mode (used later)
	--disable indexes for large inserts (won't disable clustered index)
	IF (SELECT count(*) FROM staging.MAO004_Non_Parsed mnp) > 10000000
	BEGIN;
		SET @rebuild = 0;
    	EXEC dbo.utility_disable_enable_index @Table_Name = N'MAO004_Non_Parsed'
										,@Schema = N'dbo';
    END;
 
	WITH header_info AS (
		SELECT DISTINCT
			mnpt.File_Name,
			Report_ID = SUBSTRING(mnpt.[Data_Row],3,7),
			Contract_ID = SUBSTRING(mnpt.[Data_Row],11,5),
			Report_Date = SUBSTRING(mnpt.[Data_Row],17,8),
			Submission_File_Type = SUBSTRING(mnpt.[Data_Row],111,4),
			Phase = SUBSTRING(mnpt.[Data_Row],116,1),
			[Version] = SUBSTRING(mnpt.[Data_Row],118,1)
		FROM staging.MAO004_Non_Parsed mnpt
		WHERE LEFT(mnpt.[Data_Row],1) = '0'
	),
	other_rows AS (
		SELECT
			mnp.File_Name,
			MBI = IIF(LEFT(mnp.Data_Row,1) = '1',SUBSTRING(mnp.Data_Row,17,12),NULL),
			Record_Type = SUBSTRING(mnp.[Data_Row],1,1),
			mnp.Data_Row
		FROM staging.MAO004_Non_Parsed mnp
	)
	INSERT INTO dbo.MAO004_Non_Parsed (FILE_NAME, Record_Type, Contract_ID, Report_Date, Submission_File_Type, Phase, VERSION, MBI, Data_Row)
	SELECT
		hi.File_Name,
		orw.Record_Type,
		hi.Contract_ID,
		hi.Report_Date,
		hi.Submission_File_Type,
		hi.Phase,
		hi.Version,
		orw.MBI,
		orw.Data_Row
	FROM header_info hi
	JOIN other_rows orw
		ON hi.File_Name = orw.File_Name
	WHERE 1 = 1
		AND NOT EXISTS (SELECT * FROM dbo.MAO004_Non_Parsed mnp where hi.File_Name = mnp.File_Name);
	
	IF @rebuild = 1
		BEGIN;
			EXEC dbo.utility_disable_enable_index @Table_Name = N'MAO004_Non_Parsed'
											,@Schema = N'dbo'
											,@Rebuild_Only = 1;
		END;
	ELSE
		BEGIN;
			EXEC dbo.utility_disable_enable_index @Table_Name = N'MAO004_Non_Parsed'
												 ,@Schema = N'dbo'
												 ,@Enable = 1;
		END;

	SET NOCOUNT OFF;

	/*
		The below select statement is used in the SSIS package MOR_File_Import
		Any alterations to this statement will require an update to the SSIS package as well.
	*/
	SELECT
		mnp.File_Name,
		File_Record_Count = FORMAT(COUNT(*),'N0')	
	FROM dbo.MAO004_Non_Parsed mnp
	WHERE EXISTS (SELECT * FROM staging.MAO004_Non_Parsed mfn WHERE mfn.File_Name = mnp.File_Name) 
	--compare dbo to stage to figure out what loaded for counts
	GROUP BY mnp.File_Name;

	SET NOCOUNT OFF;