﻿
 
 
 
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_INST_ENCOUNTER_HISTORICAL_CLAIM] 
(@SOURCE_DESC VARCHAR(60))--,@SOURCE_ENVIRONMENT VARCHAR(10)) 
AS 
/*************************************************************************************************** 
** CREATE DATE: 08/2016 
** 
** AUTHOR: LOYAL RICKS - Loyal Ricks - Loyal.Ricks@healthspring.com 
** 
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS NECCESSARY OBTAIN PROVIDER SPECIFIC   
**              INFORMATION NEEDED FOR THE WIPRO Professional ENCOUNTER CLAIM FILE.  
** 
** 
Modification History 
==================== 
Date			Who				Description
01/14/2019		Anthony Ulmer	TETDM-1945/1944 Updated to account for missing claims in HistoricalClaimDim Table

05/20/2019		Scott Waller	TETDM-2058  Performance of this sproc has gone downhill terribly.  
								To try and improve performance, we need to remove the RTRIM on the joins
								to HistoricalClaims.  It causes it to table scan and not use the indexes.
09/11/2020      Aaron Ridley	TETDM-2346 Exclude FrequencyCode = '1' filter
----------------------------------------------------------------------------------------------------- 
 
*****************************************************************************************************/			 
	--DECLARE VARIABLES 
 
			DECLARE 
			 
			@TOTAL_RECORDS INT 
			 
 
--HRP_CLAIM_FILE Run controls 
INSERT INTO EXT_SYS_RUNLOG 
		(PROC_NAME 
		,STEP 
		,START_DT 
		,END_DT 
		,RUN_MINUTES 
		,TOTAL_RECORDS 
		,ENTRYDT 
		) 
		VALUES('pr_BUILD_OUTB_INST_ENCOUNTER_HISTORICAL_CLAIM' 
				,'4' 
				,GETDATE() 
				,NULL 
				,NULL 
				,0 
				,GETDATE() 
				) 
			 
 
			 
				 
						IF OBJECT_ID('TEMPDB..##HistoricalClaim_INST_PROVIDER') <> 0 
											DROP TABLE ##HistoricalClaim_INST_PROVIDER 
 
 
						CREATE TABLE [dbo].##HistoricalClaim_INST_PROVIDER( 
							--[HistoricalClaimID] [int] NOT NULL, 
							[ClaimID] [varchar](50) NOT NULL, 
							[ClaimNo] [varchar](50) NULL, 
							[CLM01] [varchar](50) NULL,	 
							--[BillProvIdentifier] [varchar](50) NULL, 
							--[BillProvEntity] [varchar](10) NULL, 
							--[BillProvIDType] [varchar](50) NULL, 
							[BillProvID] [varchar](80) NULL, 
							[BillProvNPI] [varchar](80) NULL, 
							[BillProvTaxID] [varchar](50) NULL, 
							--[BillProvSecondaryIDType] [varchar](50) NULL, 
							--[BillProvSecondaryID] [varchar](80) NULL, 
							--[BillProvStateLicense] [varchar](50) NULL, 
							[BillProvUPINLicense] [varchar](50) NULL, 
							--[BillProvRefID1] [varchar](50) NULL, 
							--[BillProvRefID2] [varchar](50) NULL, 
							--[BillProvRefID3] [varchar](50) NULL, 
							--[BillProvRefID4] [varchar](50) NULL, 
							--[BillProvRefID5] [varchar](50) NULL, 
							--[BillProvRefID6] [varchar](50) NULL, 
							--[BillProvRefID7] [varchar](50) NULL, 
							--[BillProvRefID8] [varchar](50) NULL, 
							--[BillProvRefID9] [varchar](50) NULL, 
							--[BillProvRefID10] [varchar](50) NULL, 
							[BillProvLast] [varchar](60) NULL, 
							[BillProvFirst] [varchar](35) NULL, 
							[BillProvMiddle] [varchar](25) NULL, 
							--[BillProvSuffix] [varchar](10) NULL, 
							--[BillProvSpecialty] [varchar](50) NULL, 
							[BillProvTaxonomy] [varchar](50) NULL, 
							[BillProvAddress] [varchar](55) NULL, 
							[BillProvAddress2] [varchar](55) NULL, 
							[BillProvCity] [varchar](30) NULL, 
							[BillProvState] [varchar](2) NULL, 
							[BillProvZip] [varchar](15) NULL, 
							--[BillProvContact] [varchar](60) NULL, 
							--[BillProvTel] [varchar](256) NULL, 
							--[BillProvTelExt] [varchar](256) NULL, 
							--[BillProvFax] [varchar](256) NULL, 
							--[BillProvEmail] [varchar](256) NULL, 
							--[BillProvCreditCard] [varchar](30) NULL, 
							[RendProvEntity] [varchar](50) NULL, 
							[RendProvIDType] [varchar](50) NULL, 
							[RendProvID] [varchar](80) NULL, 
							[RendProvNPI] [varchar](80) NULL, 
							[RendProvTaxID] [varchar](50) NULL, 
							[RendProvSecondaryIDType] [varchar](50) NULL, 
							[RendProvSecondaryID] [varchar](80) NULL, 
							[RendProvRefID1] [varchar](50) NULL, 
							[RendProvRefID2] [varchar](50) NULL, 
							[RendProvRefID3] [varchar](50) NULL, 
							[RendProvRefID4] [varchar](50) NULL, 
							[RendProvRefID5] [varchar](50) NULL, 
							[RendProvRefID6] [varchar](50) NULL, 
							[RendProvRefID7] [varchar](50) NULL, 
							[RendProvRefID8] [varchar](50) NULL, 
							[RendProvRefID9] [varchar](50) NULL, 
							[RendProvRefID10] [varchar](50) NULL, 
							[RendProvLast] [varchar](60) NULL, 
							[RendProvFirst] [varchar](35) NULL, 
							[RendProvMiddle] [varchar](25) NULL, 
							[RendProvSuffix] [varchar](10) NULL, 
							[RendProvSpecialty] [varchar](50) NULL, 
							[RendProvTaxonomy] [varchar](50) NULL, 
							[AmbulancePatientWeight] [real] NULL, 
							[AmbulanceTransCode] [varchar](50) NULL, 
							[AmbulanceTransReason] [varchar](50) NULL, 
							[AmbulanceUOM] [varchar](50) NULL, 
							[AmbulanceDistance] [real] NULL, 
							[AmbulanceTripDesc] [varchar](80) NULL, 
							[AmbulanceStretcher] [varchar](80) NULL, 
							[AmbulancePickupName] [varchar](60) NULL, 
							[AmbulancePickupAddress] [varchar](55) NULL, 
							[AmbulancePickupCity] [varchar](50) NULL, 
							[AmbulancePickupState] [varchar](50) NULL, 
							[AmbulancePickupZip] [varchar](50) NULL, 
							[AmbulanceDropName] [varchar](60) NULL, 
							[AmbulanceDropAddress] [varchar](55) NULL, 
							[AmbulanceDropCity] [varchar](50) NULL, 
							[AmbulanceDropState] [varchar](50) NULL, 
							[AmbulanceDropZip] [varchar](50) NULL, 
							[AmbulancePatientCondition] [varchar](50) NULL, 
							[AmbulancePatientCount] [varchar](50) NULL, 
							[AmbulanceCategoryCode] [varchar](2) NULL, 
							[AmbulanceConditionInd] [varchar](1) NULL, 
							[AmbulanceConditionCode] [varchar](3) NULL, 
							[AmbulanceConditionCode2] [varchar](3) NULL, 
							[AmbulanceConditionCode3] [varchar](3) NULL, 
							[AmbulanceConditionCode4] [varchar](3) NULL, 
							[AmbulanceConditionCode5] [varchar](3) NULL, 
							[CLAIM_ID] [VARCHAR] (50) NULL, 
							[SOURCE_DESC] [VARCHAR] (60) NULL 
							) 
	 
						INSERT INTO ##HistoricalClaim_INST_PROVIDER 
						select DISTINCT 
								--HISTORICALCLAIMID, 
								CLAIMID, 
								CLAIMNO, 
								CLM01, 
								BILLPROVID, 
								BILLPROVNPI, 
								BILLPROVTAXID, 
								BILLPROVUPINLICENSE, 
								BILLPROVLAST, 
								BILLPROVFIRST,		 
								BILLPROVMIDDLE, 
								BillProvTaxonomy, 
								BILLPROVADDRESS, 
								BILLPROVADDRESS2, 
								BILLPROVCITY, 
								BILLPROVSTATE, 
								BILLPROVZIP, 
								[RendProvEntity] 
								  ,[RendProvIDType] 
								  ,[RendProvID] 
								  ,[RendProvNPI] 
								  ,[RendProvTaxID] 
								  ,[RendProvSecondaryIDType] 
								  ,[RendProvSecondaryID] 
								  ,[RendProvRefID1] 
								  ,[RendProvRefID2] 
								  ,[RendProvRefID3] 
								  ,[RendProvRefID4] 
								  ,[RendProvRefID5] 
								  ,[RendProvRefID6] 
								  ,[RendProvRefID7] 
								  ,[RendProvRefID8] 
								  ,[RendProvRefID9] 
								  ,[RendProvRefID10] 
								  ,[RendProvLast] 
								  ,[RendProvFirst] 
								  ,[RendProvMiddle] 
								  ,[RendProvSuffix] 
								  ,[RendProvSpecialty] 
								  ,[RendProvTaxonomy] 
								  	 ,[AmbulancePatientWeight] 
								  ,[AmbulanceTransCode] 
								  ,[AmbulanceTransReason] 
								  ,[AmbulanceUOM] 
								  ,[AmbulanceDistance] 
								  ,[AmbulanceTripDesc] 
								  ,[AmbulanceStretcher] 
								  ,[AmbulancePickupName] 
								  ,[AmbulancePickupAddress] 
								  ,[AmbulancePickupCity] 
								  ,[AmbulancePickupState] 
								  ,[AmbulancePickupZip] 
								  ,[AmbulanceDropName] 
								  ,[AmbulanceDropAddress] 
								  ,[AmbulanceDropCity] 
								  ,[AmbulanceDropState] 
								  ,[AmbulanceDropZip] 
								  ,[AmbulancePatientCondition] 
								  ,[AmbulancePatientCount] 
								  ,[AmbulanceCategoryCode] 
								  ,[AmbulanceConditionInd] 
								  ,[AmbulanceConditionCode] 
								  ,[AmbulanceConditionCode2] 
								  ,[AmbulanceConditionCode3] 
								  ,[AmbulanceConditionCode4] 
								  ,[AmbulanceConditionCode5] 
								,claim_id 
								,SOURCEDESC 
						from edps_data.dbo.HistoricalClaim HC 
						inner join OUTB_INST_HEADER PH 
-- TETDM-2058			ON RTRIM(HC.clm01 ) = RTRIM(PH.Claim_ID) 
						ON HC.clm01 = PH.Claim_ID
						inner join EDPS_Data.dbo.encounterclaimdim EC 
						ON PH.CLAIM_ID = EC.CLAIMNUM 
						--AND RTRIM(PH.SYSTEM_SOURCE) = RTRIM(EC.SOURCEDESC) 
						where len(BILL_PROV_NPI) = 0 
 
						---Update Billing Provider Info 
						Update OUTB_INST_HEADER 
							--SET BILL_PROV_ID = BILLPROVID, 
						SET		BILL_PROV_NPI = RTRIM(BILLPROVNPI), 
								BILL_PROV_TAX_ID = RTRIM(BILLPROVTAXID), 
								---BILLPROVUPINLICENSE, 
								BILL_PROV_LNAME = RTRIM(BILLPROVLAST), 
								BILL_PROV_FNAME = RTRIM(BILLPROVFIRST),		 
								BILL_PROV_MID_INIT = RTRIM(BILLPROVMIDDLE), 
								BILL_PROV_TAXONOMY_CD = RTRIM(BillProvTaxonomy), 
								BILL_PROV_ADDR1 = RTRIM(BILLPROVADDRESS), 
								BILL_PROV_ADDR2 =RTRIM(BILLPROVADDRESS2), 
								BILL_PROV_CITY = RTRIM(BILLPROVCITY), 
								BILL_PROV_STATE = RTRIM(BILLPROVSTATE), 
								BILL_PROV_ZIP = substring(BILLPROVZIP,1,5), 
								BILL_PROV_ZIP4 = substring(BILLPROVZIP,6,4), 
								RENDERING_PROV_ID = [RendProvID], 
								RENDERING_PROV_NPI = RTRIM([RendProvNPI]), 
								--RENDERING_PROV_TAXONOMY = RTRIM([RendProvTaxonomy]), 
								 RENDERING_PROV_LAST_NAME = RTRIM([RendProvLast]), 
								 RENDERING_PROV_FIRST_NAME =RTRIM([RendProvFirst]), 
								 RENDERING_PROV_MID_INIT =RTRIM([RendProvMiddle]) 
							FROM OUTB_INST_HEADER H 
							INNER JOIN ##HistoricalClaim_INST_PROVIDER HP 
-- TETDM-2058				ON RTRIM(HP.clm01 ) = RTRIM(H.Claim_ID) 
							ON HP.clm01 = H.Claim_ID
							where len(bill_prov_fname) > 0  
 
						---Update Billing Provider Group Info  
							Update OUTB_INST_HEADER 
							--SET BILL_PROV_ID = BILLPROVID, 
						SET		BILL_PROV_GRP_NPI = RTRIM(BILLPROVNPI), 
								BILL_PROV_TAX_ID = RTRIM(BILLPROVTAXID), 
								---BILLPROVUPINLICENSE, 
								BILL_PROV_ORG_NAME = RTRIM(BILLPROVLAST), 
								--BILL_PROV_FNAME = RTRIM(BILLPROVFIRST),		 
								--BILL_PROV_MID_INIT = RTRIM(BILLPROVMIDDLE), 
								BILL_PROV_TAXONOMY_CD = RTRIM(BillProvTaxonomy), 
								BILL_PROV_ADDR1 = RTRIM(BILLPROVADDRESS), 
								BILL_PROV_ADDR2 =RTRIM(BILLPROVADDRESS2), 
								BILL_PROV_CITY = RTRIM(BILLPROVCITY), 
								BILL_PROV_STATE = RTRIM(BILLPROVSTATE), 
								BILL_PROV_ZIP = substring(BILLPROVZIP,1,5), 
								BILL_PROV_ZIP4 = substring(BILLPROVZIP,6,4), 
								RENDERING_PROV_ID = [RendProvID], 
								RENDERING_PROV_NPI = RTRIM([RendProvNPI]), 
								--RENDERING_PROV_TAXONOMY = RTRIM([RendProvTaxonomy]), 
								 RENDERING_PROV_LAST_NAME = RTRIM([RendProvLast]), 
								 RENDERING_PROV_FIRST_NAME =RTRIM([RendProvFirst]), 
								 RENDERING_PROV_MID_INIT =RTRIM([RendProvMiddle]) 
							FROM OUTB_INST_HEADER H 
							INNER JOIN ##HistoricalClaim_INST_PROVIDER HP 
-- TETDM-2058				ON RTRIM(HP.clm01 ) = RTRIM(H.Claim_ID) 
							ON HP.clm01 = H.Claim_ID 
							where len(bill_prov_fname) = 0  

		/* TETDM-1945/1944
		Get claim data from edps_data DB when claim does not exist in HistoricalClaim Tables
		Claims received after June 2018 do not have data in HistoricalClaimDim table
		VendorID = Bill_Prov_ID in outbound header table
		EDPS_Data.dbo.EDS_ProviderDim = 1 to many join

		The temp table is here to make sure the claim vendorID, TaxID, and Vendor name match the claim that was
			chosen in the header and detail tables (can't directly glean that info from the header table);
			These three fields should probably be pulled in the Header procedure but is done here to 
			preserve the old data pulls from historical claims above.
		*/	
		IF OBJECT_ID('tempdb.dbo.#RoughClaimBasket') IS NOT NULL
			DROP TABLE #RoughClaimBasket

		SELECT
			sub.Claimnum AS Claim_ID,
			sub.VendorID AS BILL_PROV_GRP_NPI,
			sub.FederalTaxID AS BILL_PROV_TAX_ID,
			sub.VendorLastName AS BILL_PROV_ORG_NAME,
			sub.ProviderID AS ProviderID,
            sub.SourceDesc AS SourceDesc,
            sub.TaxonomyCode AS TaxonomyCode,
            sub.ProvTaxonomyCode AS ProvTaxonomyCode
			INTO #RoughClaimBasket
		FROM (
				SELECT
					e.*
					--TETDM 1772 NOTE: The sort order in this over partition by is critical in the selection of the claims.  This will determine which claim from a set of duplicates will be picked up.
					--TETDM 1889 NOTE: The sort order is for LoadDateKey and BeginServiceDateKey is reversed to try to account for latest claim lines (DETAIL PROCEDURE ONLY).
					,latest = ROW_NUMBER() OVER (PARTITION BY e.CLAIMNUM, e.ClaimLineNum, e.ClaimType, e.MemberID, e.SOURCEDESC ORDER BY  e.LoadDateKey DESC, e.BeginServiceDateKey, e.FILENAME DESC)
					FROM EDPS_Data.dbo.encounterclaimdim e
					WHERE 1 = 1
						AND e.ClaimType = 'I'
						--AND e.ClaimFrequencyCode = '1' TETDM-2346
						AND EXISTS (SELECT 1 
									FROM WIPRO.DBO.OUTB_INST_HEADER oih 
									WHERE oih.CLAIM_ID = e.Claimnum 
										AND REPLACE(oih.SYSTEM_SOURCE,'EDPS-','') = e.SourceDesc) --remove EDPS- from source.  source is needed to not cross claim IDs
			)sub
		LEFT JOIN EDPS_Data.dbo.HistoricalClaim hc
			ON hc.CLM01 = sub.Claimnum
			AND hc.TypeOfClaim = 'Encounter'
            AND hc.ClaimType = sub.ClaimType
		WHERE 1 = 1
            AND sub.latest = 1
			AND sub.ClaimLineNum = 1
			AND hc.CLM01 IS NULL; --just to make sure data is only backfilled for claims that do not exist in the historical claims table
								  --Claims that are in the historical claims table will be updated via prior code above.

		;WITH EncounterProvider AS(
			SELECT
				epd.ProviderID
				,epd.Address1
				,epd.Address2
				,epd.City
				,epd.State
				,Zip_5 = LTRIM(RTRIM(IIF(LEN(REPLACE(epd.Zip,'-','')) != 0 ,LEFT(LTRIM(RTRIM(REPLACE(epd.Zip,'-',''))),5),NULL)))
				,Zip_4 = LTRIM(RTRIM(IIF(LEN(REPLACE(epd.Zip,'-','')) > 5,LEFT(LTRIM(RTRIM(REPLACE(epd.Zip,'-',''))),4),NULL)))
				,epd.FederalTaxID
				,epd.TaxonomyCode
				,epd.ProviderNPI
				,epd.SourceDesc
			FROM EDPS_Data.dbo.EncounterProviderDim epd
			WHERE 1 = 1
				AND EXISTS (SELECT 1 FROM #RoughClaimBasket RCB WHERE epd.ProviderID = RCB.ProviderID)
				AND epd.EncounterProviderKey = (SELECT MAX(epd1.EncounterProviderKey) FROM EDPS_Data.dbo.EncounterProviderDim epd1 WHERE epd1.ProviderID = epd.ProviderID)                
		),
        INST_5010 AS (
            SELECT 
                ei.ClaimNo,
                ei.BillProvTaxonomy,
                ei.BillProvAddress,
                ei.BillProvAddress2,
                ei.BillProvCity,
                ei.BillProvState,
				Zip_5 = IIF(LEN(REPLACE(ei.BillProvZip,'-','')) != 0, LEFT(LTRIM(RTRIM(REPLACE(ei.BillProvZip,'-',''))),5),' '),
				Zip_4 = IIF(LEN(REPLACE(ei.BillProvZip,'-','')) > 5, RIGHT(LTRIM(RTRIM(REPLACE(ei.BillProvZip,'-',''))),4),' '),
                ei.RendProvNPI,
                ei.RendProvLast,
                ei.RendProvFirst,
                ei.RendProvMiddle
            FROM EDPS_Data.dbo.EDI_Inst_5010 ei
            WHERE 1 = 1
                AND EXISTS (SELECT 1 FROM #RoughClaimBasket rcb WHERE rcb.CLAIM_ID = ei.ClaimNo AND rcb.SourceDesc = ei.SourceDesc)
                AND ei.ID = (	SELECT MAX(ID) 
								FROM EDPS_Data.dbo.EDI_Inst_5010 ei1 
								WHERE 1 = 1
									AND ei1.ClaimNo = ei.ClaimNo 
									AND ei1.SourceDesc = ei.SourceDesc
									AND ei1.LineID = 1)
        )
		UPDATE oph
		SET
			BILL_PROV_GRP_NPI           = ISNULL(LTRIM(RTRIM(RCB.BILL_PROV_GRP_NPI)),' '),
			BILL_PROV_TAX_ID            = ISNULL(LTRIM(RTRIM(RCB.BILL_PROV_TAX_ID)),' '),
			BILL_PROV_ORG_NAME          = ISNULL(LTRIM(RTRIM(RCB.BILL_PROV_ORG_NAME)),' '),
			BILL_PROV_TAXONOMY_CD       = ISNULL(LTRIM(RTRIM(COALESCE(NULLIF(NULLIF(encprov.TaxonomyCode,''),'NPROVIDED'),ei.BillProvTaxonomy))),' '),
			BILL_PROV_ADDR1             = ISNULL(LTRIM(RTRIM(COALESCE(NULLIF(NULLIF(encprov.Address1,''),'NPROVIDED'), ei.BillProvAddress))),' '),
			BILL_PROV_ADDR2             = ISNULL(LTRIM(RTRIM(COALESCE(NULLIF(NULLIF(encprov.Address2,' '),'NPROVIDED'), ei.BillProvAddress2))),' '),
			BILL_PROV_CITY              = ISNULL(LTRIM(RTRIM(COALESCE(NULLIF(NULLIF(encprov.City,' '),'NPROVIDED'), ei.BillProvCity))),' '),
			BILL_PROV_STATE             = ISNULL(LTRIM(RTRIM(COALESCE(NULLIF(NULLIF(encprov.State,' '),'NPROVIDED'), ei.BillProvState))),' '),
			BILL_PROV_ZIP               = ISNULL(COALESCE(NULLIF(NULLIF(encprov.Zip_5,''),'NPROV'), ei.Zip_5 ),' '),
			BILL_PROV_ZIP4              = ISNULL(COALESCE(NULLIF(NULLIF(encprov.Zip_4,''),'NPRO'), ei.Zip_4 ),' '),
			RENDERING_PROV_ID           = ISNULL(LTRIM(RTRIM(ei.RendProvNPI)),' '), --Rendering_Prov_ID and Rendering_Prov_NPI are the same value
			RENDERING_PROV_NPI          = ISNULL(LTRIM(RTRIM(ei.RendProvNPI)),' '),
			RENDERING_PROV_LAST_NAME    = ISNULL(LTRIM(RTRIM(ei.RendProvLast)),' '),
			RENDERING_PROV_FIRST_NAME   = ISNULL(LTRIM(RTRIM(ei.RendProvFirst)),' '),
			RENDERING_PROV_MID_INIT     = ISNULL(LEFT(LTRIM(RTRIM(ei.RendProvMiddle)),1),' ')
		FROM WIPRO.dbo.OUTB_INST_HEADER oph
		JOIN #RoughClaimBasket RCB
			ON RCB.Claim_ID = oph.CLAIM_ID
		LEFT JOIN EncounterProvider encprov
			ON RCB.ProviderID = encprov.ProviderID
			   AND RCB.SourceDesc = encprov.SourceDesc
		LEFT JOIN Inst_5010 ei
			ON oph.CLAIM_ID = ei.ClaimNo;	
		
		
		/******END TETDM-1945/1944 UPDATE******/

							 
						--Create archive of provider records 
						INSERT INTO OUTB_ENCOUNTER_HistoricalClaim_PROVIDER 
						select * , GETDATE() 
						FROM ##HistoricalClaim_INST_PROVIDER 
 
				--TETDM-983 
					--update OUTB_INST_HEADER 
					--SET BILL_PROV_NPI = vb.BILLPROVNPI 
					--FROM OUTB_INST_HEADER H 
					--INNER JOIN ##HistoricalClaim_BILLPROV VB 
					--on H.CLAIM_ID = VB.CLAIM_ID  
					--WHERE LEN(H.BILL_PROV_NPI) = 0  
					--and  vb.SOURCE_DESC = @SOURCE_DESC 
				--TETDM-984 
					--update OUTB_INST_HEADER 
					--SET BILL_PROV_TAX_ID = vb.BILLPROVTAXID 
					--FROM OUTB_INST_HEADER H 
					--INNER JOIN ##HistoricalClaim_BILLPROV VB 
					--on H.CLAIM_ID = VB.CLAIM_ID  
					--WHERE LEN(H.BILL_PROV_TAX_ID) = 0  
					--and  vb.SOURCE_DESC = @SOURCE_DESC 
				--TETDM-985 
					--update OUTB_INST_HEADER 
					--SET BILL_PROV_TAXONOMY_CD = VB.BillProvTaxonomy 
					--FROM OUTB_INST_HEADER H 
					--INNER JOIN ##HistoricalClaim_BILLPROV VB 
					--on H.CLAIM_ID = VB.CLAIM_ID 
					--WHERE LEN(H.BILL_PROV_TAXONOMY_CD) = 0  
					--and  vb.SOURCE_DESC = @SOURCE_DESC 
			 
			 
	--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM OUTB_INST_HEADER_RESEND 
	 
	 
							  
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM ##HistoricalClaim_INST_PROVIDER) 
			 
	----HRP_CLAIM_FILE Update Run Controls 
				BEGIN TRANSACTION 
						UPDATE EXT_SYS_RUNLOG 
						SET END_DT = GETDATE() 
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()) 
							,TOTAL_RECORDS = @TOTAL_RECORDS 
							,ENTRYDT = GETDATE() 
						WHERE PROC_NAME = 'pr_BUILD_OUTB_INST_ENCOUNTER_HISTORICAL_CLAIM' 
							AND END_DT IS NULL 
							IF @@ERROR <> 0 
										BEGIN  
												ROLLBACK  
										END 
						COMMIT
