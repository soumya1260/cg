﻿


CREATE PROCEDURE [dbo].[EXSP_WIPRO_MA0_002]

AS
/******************************************************************************************************************
** CREATE DATE: 03/2014
**
** AUTHOR: LOYAL RICKS - Loyal Ricks
**
** DESCRIPTION: Procedure will update inbound MAO002 file information to back end tables to support
**				EDS claim inventory and tracking. The EXT_EDPS_CLAIM_STATUS - EDS Inventory table and
**				OUTB_CLAIM_STATUS - Outbound claim status table updates will be applied.
**				Updates applied based on EDS environment. 
**				EDPS_PROD (Production updates) are applied 
**				using the MAO002 PlanClaimNumber and WIPRO_UNQ_ID as foreign keys for updates. These
**				values exist in production from the Outbound transmission and Inbound WIPRO clmstat update.
**				EDPS_DEV & EDPS_QA updates will attempt to use the MAO002 PlanClaimNumber as the foreign key.
**				The WIPRO_UNQ_ID from the production submission of the claim is not available in the
**				EDPS_DEV & EDPS_QA data. An attempt to update this information in DEV & QA are required to 
**				support existing outbound claim exclusion logic and inventory reporting. Due to the relaxed
**				foreign key rules EDPS_DEV & EDPS_QA updates may not be as accurate as EDPS_PROD updates.
**				--EXEC [dbo].[EXSP_WIPRO_MA0_002]
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
04-07-14		Loyal Ricks		Change CLMSTAT_STATUS from 'R-ICN' to 'R'. No need to track R-ICN
								claims for reporting purposes. There will be no need to change inventory
								SSRS reports to account for the "R-ICN" status that is being introduced
								with the implementation of the MAO002 file.
05-21-2014		Loyal Ricks		Add Inventory Updates procedure call. Procedure will update WIPRO 
								Accepted and Rejected claim status on a daily basis. EXSP_HRP_CLAIM_UPD_INVENTORY
05-22-2014		Loyal Ricks		Change CLMSTAT_STATUS from 'R' to 'R-ICN'. Need to track R-ICN identified by EDS
								team.
------------------------------------------------------------------------------------------------------------------
03-27-2015		Loyal Ricks		WIPRO Revisions -TETDM-53 - Replace all Verisk & HRP references with WIPRO
								Replace EXT_HRP_CLAIM_STATUS with OUTB_CLAIM_STATUS
								MAO002 loading and processing required to support EDS QA (CMS tier 2 results) (hstnedsdevdb01) and 
								PROD (hstnedsdb01). 
04-03-2015		Loyal Ricks		Revise typo change 'HSTNEDSDB02' to 'HSTNEDSDEVDB02'
04-08-2015		Loyal Ricks		Add MAO002 V1.1.0 revisions - WIPRO_UNQ_ID related updates
04-10-2015		Loyal Ricks		Comment out call to Update Inventory. Add logic for conditional execution of update
								inventory to job/package
04-15-2015		Loyal Ricks		Data length adjustments for: #MAO_002_Detail_DAILY - WIPRO_UNQ_ID,WIPRO_FILE_ICN,FILEID
05-09-2018      Subhash Acharya TETDM-1785 changes to update the claim status
05-17-2018      Subhash Acharya TETDM-1642 
05-29-1018      Henry Faust     TETDN-1684 add 2 colums to the outb_claim_status tables and update it with info from the MAO002 
                                           file, where CLMSTAT_STATUS = 'R-ICN'
06-27-2018      Subhash Acharya TETDM-1642 Putting back my changes 
11-13-2019      Subhash Acharya TETDM-2165 update ICN if blank
******************************************************************************************************************/	
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE
			
			@TOTAL_RECORDS INT,
			@LAST_UPD_DATE DATETIME
		

--HRP_CLAIM_FILE Run controls
			
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('EXSP_WIPRO_MA0_002'
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)
					
				
				--Set @Last_Upd_Date variable
				
				begin
					set @LAST_UPD_DATE = GETDATE()
				end
				
				-- Gather information to update EXT_EDPS_CLAIM_STATUS FROM DAILY MAO_002 FILES

 									IF OBJECT_ID('TEMPDB..#MAO_002_Detail_DAILY') <> 0
										DROP TABLE #MAO_002_Detail_DAILY
										
								CREATE TABLE #MAO_002_Detail_DAILY

								(
									
									[InboundFileName] [varchar](256) NULL,
									[PlanClaimNumber] [varchar](60) NULL,
									[WIPRO_UNQ_ID] [varchar](34) NULL,
									[WIPRO_FILE_ICN] [varchar](60) NULL,
									[CMSICN] [varchar](20) NULL,	
									[RecordType] [char](1) NULL,
									[FILEID] [VARCHAR] (50) NULL,
									[SOURCEDATAKEY] INT,
									[RejectReasonID] VARCHAR(8) NULL,       --TETDM-1684
									[RejectReasonMessage] VARCHAR(200) NULL --TETDM-1684
								) 
				----Server Evaluation 
				----MAO_002 foreign key updates vary based on EDS evironment
				----MAO_002 HSTNEDSDEVDB01 & HSTNEDSDB01 Processing
				----Valid MAO002 files expected to be processed in EDS QA & PROD envrionment only
				----as a result EDS QA & PROD require a different fk join then EDS dev (hstnedsdevdb02)						
				
				
				if @@SERVERNAME <> 'HSTNEDSDEVDB02'	
				
				begin 
								--Gather inbound MAO_002 data and existing OUTB_CLAIM_STATUS Information needed for update
								
								INSERT INTO #MAO_002_Detail_DAILY
								select InboundFileName,
										PlanClaimNumber,
										WIPRO_UNQ_ID,
										WIPRO_FILE_ICN,
										CMSICN,
										RecordType ,
										CS.FILEID,
										CS.SOURCEDATAKEY,
										ma.RejectReasonID,        --TETDM-1684
										ma.RejectReasonMessage    --TETDM-1684
								from MAO_002_Detail_Daily MA
								INNER JOIN OUTB_CLAIM_STATUS CS
								ON MA.PlanClaimNumber = CS.CLAIM_ID
								AND MA.WIPRO_UNQ_ID = CS.WIPRO_CLAIM_ID
								where ServiceLineSequenceNumber = '000' 
-- not needed					ORDER BY SOURCEDATAKEY,PlanClaimNumber
								

								SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #MAO_002_Detail_DAILY)

								if @TOTAL_RECORDS > 0
								BEGIN

								--apply updates to EXT_EDPS_CLAIM_STATUS
								
								INSERT INTO WIPRO.dbo.ClaimStatusNull
								--SELECT c.CLAIM_ID,C.SOURCEDATAKEY,C.FILEID,C.CLMSTAT_STATUS,C.LAST_UPD_DATE,w.CLMSTAT_STATUS,* 
								SELECT c.CLAIM_ID,C.SOURCEDATAKEY,C.FILEID,C.CLMSTAT_STATUS,C.LAST_UPD_DATE,GETDATE()
								FROM OUTB_CLAIM_STATUS C
								INNER JOIN  #MAO_002_Detail_DAILY W
								ON C.CLAIM_ID = W.PlanClaimNumber 
								AND C.WIPRO_CLAIM_ID = W.[WIPRO_UNQ_ID]
								WHERE c.CLMSTAT_STATUS IS NULL


								UPDATE EXT_EDPS_CLAIM_STATUS
								SET CLMSTAT_STATUS = CASE RecordType WHEN 'A' THEN 'A-ICN' WHEN 'R' THEN 'R-ICN' else RecordType END,
									HRP_CLAIM_ID = T.WIPRO_UNQ_ID,
									INBOUNDFILENAME = T.InboundFileName,
									--WIPRO_UNQ_ID = T.WIPRO_FILE_ICN,
									FILEID = T.FILEID,
									CMS_ICN = T.CMSICN,
									LAST_UPD_DATE = @LAST_UPD_DATE
								FROM EXT_EDPS_CLAIM_STATUS P
								JOIN #MAO_002_Detail_DAILY T
								ON P.SOURCEDATAKEY = T.SOURCEDATAKEY
								AND P.CLAIMID = T.PLANCLAIMNUMBER
								



								----apply update to OUTB_CLAIM_STATUS
								
						UPDATE P
								SET p.CMS_ICN = T.CMSICN
									,p.CLMSTAT_STATUS = CASE 
									WHEN RecordType = 'A' AND (p.CLMSTAT_STATUS IN ('A','R','A-999','R-999','R-277','A-277','R-ICN','MAO-004') OR p.CLMSTAT_STATUS IS NULL ) THEN 'A-ICN' 
									WHEN RecordType = 'R' AND (p.CLMSTAT_STATUS IN ('A','R','A-999','R-999','R-277','A-277','MAO-004') OR p.CLMSTAT_STATUS IS NULL) THEN 'R-ICN' 
									--ELSE 'No Change'
									ELSE p.CLMSTAT_STATUS
									END --AS UpdatedValue
									--SELECT p.CLMSTAT_STATUS,*
									--SELECT TOP 1000 p.CLMSTAT_STATUS,*
									,p.LAST_UPD_DATE = GETDATE()
									,p.STAT_REJ_REA_ID = NULL --CASE WHEN W.CLMSTAT_STATUS = 'A-999' THEN NULL ELSE STAT_REJ_REA_ID  END
									,p.REJ_REA_MSG = NULL --CASE WHEN W.CLMSTAT_STATUS = 'A-999' THEN NULL ELSE REJ_REA_MSG END
									,p.FIELD_ERR = NULL
									,p.VAL_ERR = NULL
								FROM #MAO_002_Detail_DAILY T
								JOIN OUTB_CLAIM_STATUS P
								ON P.SOURCEDATAKEY = T.SOURCEDATAKEY
								AND P.CLAIM_ID = T.PLANCLAIMNUMBER
								AND P.WIPRO_CLAIM_ID = T.WIPRO_UNQ_ID
								WHERE P.CLAIM_ID not in 
											(
											select distinct claim_id 
											from OUTB_CLAIM_STATUS
											where CLMSTAT_STATUS in
												( 
												 'A-ICN' 
												 ) 
											)
										OR (P.CLMSTAT_STATUS = 'A-ICN' AND  ISNULL(T.CMSICN,'') <> '' AND ISNULL(p.CMS_ICN,'') = '') 


--
--TETDM-1684
--
							UPDATE OUTB_CLAIM_STATUS
								SET 
							        STAT_REJ_REA_ID =  T.RejectReasonID 
							       ,REJ_REA_MSG  =  T.RejectReasonMessage                                    
								FROM #MAO_002_Detail_DAILY T
								JOIN OUTB_CLAIM_STATUS P
								ON P.SOURCEDATAKEY = T.SOURCEDATAKEY
								AND P.CLAIM_ID = T.PLANCLAIMNUMBER
								--AND P.WIPRO_CLAIM_ID = T.WIPRO_UNQ_ID
								where CLMSTAT_STATUS = 'R-ICN'


								
				end
				end  

				----MAO_002 HSTNEDSDEVDB02  Processing
				----Valid MAO002 files expected to be processed in EDS QA & PROD envrionment only
				----as a result EDS QA & PROD require a different fk join then EDS dev (hstnedsdevdb02)	
				----hstnedsdevdb02 processing performed for testing and special circumstance loading only 		
					if @@SERVERNAME = 'HSTNEDSDEVDB02'	
				
				begin 
								--Gather inbound MAO_002 data and existing OUTB_CLAIM_STATUS Information needed for update
								
								INSERT INTO #MAO_002_Detail_DAILY
								select InboundFileName,
										PlanClaimNumber,
										WIPRO_UNQ_ID,
										WIPRO_FILE_ICN,
										CMSICN,
										RecordType ,
										CS.FILEID,
										CS.SOURCEDATAKEY,
										ma.RejectReasonID,        --TETDM-1684
										ma.RejectReasonMessage    --TETDM-1684
								from MAO_002_Detail_Daily MA
								INNER JOIN OUTB_CLAIM_STATUS CS
								ON MA.PlanClaimNumber = CS.CLAIM_ID
								where ServiceLineSequenceNumber = '000' 
-- not needed					ORDER BY SOURCEDATAKEY,PlanClaimNumber
								

								SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #MAO_002_Detail_DAILY)

								if @TOTAL_RECORDS > 0
								BEGIN

								--apply updates to EXT_EDPS_CLAIM_STATUS

								INSERT INTO WIPRO.dbo.ClaimStatusNull
								--SELECT c.CLAIM_ID,C.SOURCEDATAKEY,C.FILEID,C.CLMSTAT_STATUS,C.LAST_UPD_DATE,w.CLMSTAT_STATUS,* 
								SELECT c.CLAIM_ID,C.SOURCEDATAKEY,C.FILEID,C.CLMSTAT_STATUS,C.LAST_UPD_DATE,GETDATE()
								FROM OUTB_CLAIM_STATUS C
								INNER JOIN  #MAO_002_Detail_DAILY W
								ON C.CLAIM_ID = W.PlanClaimNumber 
								AND C.WIPRO_CLAIM_ID = W.[WIPRO_UNQ_ID]
								WHERE c.CLMSTAT_STATUS IS NULL

								
								UPDATE EXT_EDPS_CLAIM_STATUS
								SET CLMSTAT_STATUS = CASE RecordType WHEN 'A' THEN 'A-ICN' WHEN 'R' THEN 'R-ICN' else RecordType END,
									HRP_CLAIM_ID = T.WIPRO_UNQ_ID,
									INBOUNDFILENAME = T.InboundFileName,
									--OUTBOUNDVHCLAIMID = T.WIPRO_FILE_ICN,
									CMS_ICN = T.CMSICN,
									FILEID = T.FILEID,
									LAST_UPD_DATE = @LAST_UPD_DATE
								FROM EXT_EDPS_CLAIM_STATUS P
								JOIN #MAO_002_Detail_DAILY T
								ON P.SOURCEDATAKEY = T.SOURCEDATAKEY
								AND P.CLAIMID = T.PLANCLAIMNUMBER
								
								UPDATE P
								SET p.CMS_ICN = T.CMSICN
									,p.CLMSTAT_STATUS = CASE WHEN RecordType = 'A' AND (p.CLMSTAT_STATUS IN ('A','R','A-999','R-999','R-277','A-277','R-ICN','MAO-004') OR p.CLMSTAT_STATUS IS NULL ) THEN 'A-ICN' 
									WHEN RecordType = 'R' AND (p.CLMSTAT_STATUS IN ('A','R','A-999','R-999','R-277','A-277','MAO-004') OR p.CLMSTAT_STATUS IS NULL) THEN 'R-ICN' 
									--ELSE 'No Change'
									ELSE p.CLMSTAT_STATUS
									END --AS UpdatedValue
									--SELECT p.CLMSTAT_STATUS,*
									--SELECT TOP 1000 p.CLMSTAT_STATUS,*
									,p.LAST_UPD_DATE = GETDATE()
									,p.STAT_REJ_REA_ID = NULL --CASE WHEN W.CLMSTAT_STATUS = 'A-999' THEN NULL ELSE STAT_REJ_REA_ID  END
									,p.REJ_REA_MSG = NULL --CASE WHEN W.CLMSTAT_STATUS = 'A-999' THEN NULL ELSE REJ_REA_MSG END
									,p.FIELD_ERR = NULL
									,p.VAL_ERR = NULL
								FROM #MAO_002_Detail_DAILY T
								JOIN OUTB_CLAIM_STATUS P
								ON P.SOURCEDATAKEY = T.SOURCEDATAKEY
								AND P.CLAIM_ID = T.PLANCLAIMNUMBER
								AND P.WIPRO_CLAIM_ID = T.WIPRO_UNQ_ID
								Where P.CLAIM_ID not in 
											(
											select distinct claim_id 
											from OUTB_CLAIM_STATUS
											where CLMSTAT_STATUS in
												( 
												 'A-ICN' 
												 ) 
											)
--TETDM-1684
--																
							UPDATE OUTB_CLAIM_STATUS
								SET 
							        STAT_REJ_REA_ID =  T.RejectReasonID 
							       ,REJ_REA_MSG  =  T.RejectReasonMessage                                    
								FROM #MAO_002_Detail_DAILY T
								JOIN OUTB_CLAIM_STATUS P
								ON P.SOURCEDATAKEY = T.SOURCEDATAKEY
								AND P.CLAIM_ID = T.PLANCLAIMNUMBER
								--AND P.WIPRO_CLAIM_ID = T.WIPRO_UNQ_ID
								where CLMSTAT_STATUS = 'R-ICN'
								
				end
				end 

				---Update Inventory - WIPRO Accepted and Rejected Claim Status Updates

				--begin 
				--		execute EXSP_CLAIM_UPD_INVENTORY
				--end
				

	--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM #MAO_002_Detail_DAILY
							 
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #MAO_002_Detail_DAILY)
									
		----HRP_CLAIM_FILE Update Run Controls
				
						UPDATE EXT_SYS_RUNLOG
						SET END_DT = GETDATE()	
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
							,TOTAL_RECORDS = @TOTAL_RECORDS
							,ENTRYDT = GETDATE()
						WHERE PROC_NAME = 'EXSP_WIPRO_MA0_002'
										and END_DT is null
						
					

