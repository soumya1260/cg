﻿

CREATE PROCEDURE [dbo].[EXSP_WIPRO_277_Updates]
(@JOBID INT = 1)

AS

/***************************************************************************************************
** CREATE DATE: 02/2016
**
** AUTHOR: LOYAL RICKS - Loyal Ricks
**
** DESCRIPTION: Procedure will update the OUTB_CLAIM_STATUS table from the  inbound WIPRO 277.
**				these updates will be used to facilitate updates for EDS claim submissions as 
**				claims are processed from WIPRO to CMS
**				When JOBID = 1 Use Daily Job to use WIPRO_277_Accepted_Daily as source
**				When JOBID = 2 Use Historical Job to use WIPRO_277_Accepted as source.
**						Historical job may be required to sync production status in the event
**				

				Sample Invocation 

				EXEC [dbo].[EXSP_WIPRO_277_Updates]

		
**				
Modification History
====================
Date			Who				  Description
08/03/2017		Subhash Acharya   TETDM-1526
10/10/2017		Subhash Acharya   TETDM-1641 update logic for Claim Status
04/10/2018      Subhash Acharya   TETDM-1641 only update rows based on conditions
04/27/2018		Subhash Acharya   TETDM-1641 update based on match with claim id and unique cliam id
08/15/2018		Subhash Acharya   TETDM-1802 Update to the outb_claim_status table for the CMS 277 
												Response Files to add the 277 reject ID and message
-----------------------------------------------------------------------------------------------------

*****************************************************************************************************/	
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND
			DECLARE	@TOTAL_RECORDS INT
		
					INSERT INTO EXT_SYS_RUNLOG
							(PROC_NAME
							,STEP
							,START_DT
							,END_DT
							,RUN_MINUTES
							,TOTAL_RECORDS
							,ENTRYDT
							)
					VALUES('EXSP_WIPRO_277_Updates' + '-' + 'JOBID' +'='+ CONVERT(CHAR, @JOBID)
							,'1'
							,GETDATE()
							,NULL
							,NULL
							,0
							,GETDATE()
							)

								if OBJECT_ID ('tempdb..#TMP_WIPRO_277') <> 0	
								DROP TABLE #TMP_WIPRO_277

								CREATE TABLE #TMP_WIPRO_277
								(CLAIM_ID VARCHAR(20),
								WIPRO_CLAIM_ID VARCHAR(20),
								CLMSTAT_STATUS VARCHAR(50),
								[RejectReasonID] VARCHAR(8) NULL,   
								[RejectReasonMessage] VARCHAR(200) NULL 
								)

						----When JOBID = 1 Use Daily Job to use WIPRO_277_Accepted_Daily as source
if @JOBID = 1 
	begin
		--Process Accepted 277 records
		INSERT INTO #TMP_WIPRO_277
		select DISTINCT  PlanClaimNumber,
					WIPROID,
					CASE WHEN recordtype = 'A' AND StatusActionCode = 'WQ' AND providerstatusactioncode = 'WQ' THEN 'A-277' 
					     WHEN recordtype = 'A' AND StatusActionCode = 'U' AND providerstatusactioncode = 'WQ' THEN 'R-277' 
						 WHEN recordtype = 'A' AND providerstatusactioncode = 'U' THEN 'R-277' 
						 WHEN recordtype = 'R' AND providerstatusactioncode = 'U' THEN 'R-277'END,
						 AssignedRejectMessageID,
						 AssignedRejectMessageIDDetail
		from WIPRO..WIPRO_277_Accepted_Daily
	end 

if @JOBID = 2
	begin 
	--Process Accepted 277 historical records
		INSERT INTO #TMP_WIPRO_277
		select DISTINCT  PlanClaimNumber,
					WIPROID,
					CASE WHEN recordtype = 'A' AND StatusActionCode = 'WQ' AND providerstatusactioncode = 'WQ' THEN 'A-277' 
					     WHEN recordtype = 'A' AND StatusActionCode = 'U' AND providerstatusactioncode = 'WQ' THEN 'R-277' 
						 WHEN recordtype = 'A' AND providerstatusactioncode = 'U' THEN 'R-277' 
						 WHEN recordtype = 'R' AND providerstatusactioncode = 'U' THEN 'R-277'END,
						 AssignedRejectMessageID,
						 AssignedRejectMessageIDDetail
		from WIPRO..WIPRO_277_Accepted
	end 
		

		

INSERT INTO WIPRO.dbo.ClaimStatusNull
		--SELECT c.CLAIM_ID,C.SOURCEDATAKEY,C.FILEID,C.CLMSTAT_STATUS,C.LAST_UPD_DATE,w.CLMSTAT_STATUS,* 
		SELECT c.CLAIM_ID,C.SOURCEDATAKEY,C.FILEID,C.CLMSTAT_STATUS,C.LAST_UPD_DATE,GETDATE()
		FROM OUTB_CLAIM_STATUS C
		INNER JOIN  #TMP_WIPRO_277 W
		ON C.CLAIM_ID = W.CLAIM_ID 
		AND C.WIPRO_CLAIM_ID = W.WIPRO_CLAIM_ID
		WHERE c.CLMSTAT_STATUS IS NULL


--BEGIN TRAN
--SET ROWCOUNT 10 

		---Update OUTB_CLAIM_STATUS.CLMSTAT_STATUS FROM INBOUND 277
		UPDATE C 
		SET c.CLMSTAT_STATUS --= W.CLMSTAT_STATUS
		= CASE WHEN ((c.CLMSTAT_STATUS IN ('A','R','A-999','R-999','R-277','MAO-004') OR c.CLMSTAT_STATUS IS NULL)
										AND W.CLMSTAT_STATUS like 'A%')
			THEN 'A-277'
	 WHEN ((c.CLMSTAT_STATUS IN ('A','R','A-999','R-999','MAO-004') OR c.CLMSTAT_STATUS IS NULL)
										AND W.CLMSTAT_STATUS like 'R%')
			THEN 'R-277'
			--ELSE 'No Change'
			ELSE c.CLMSTAT_STATUS
			END --AS UpdatedValue
			,LAST_UPD_DATE = getdate()
			,STAT_REJ_REA_ID = CASE WHEN C.CLMSTAT_STATUS = 'R-277' then STAT_REJ_REA_ID ELSE NULL END	 --CASE WHEN W.CLMSTAT_STATUS like 'A%' THEN NULL ELSE STAT_REJ_REA_ID  END
		,REJ_REA_MSG = CASE WHEN C.CLMSTAT_STATUS = 'R-277' then REJ_REA_MSG ELSE NULL END--CASE WHEN W.CLMSTAT_STATUS like 'A%' THEN NULL ELSE REJ_REA_MSG END
		,FIELD_ERR = NULL
		,VAL_ERR = NULL
		--SELECT C.CLMSTAT_STATUS,*
		--SELECT TOP 1000 C.CLMSTAT_STATUS,*
		FROM OUTB_CLAIM_STATUS C
		INNER JOIN  #TMP_WIPRO_277 W
		ON C.CLAIM_ID = W.CLAIM_ID
		and w.WIPRO_CLAIM_ID = c.WIPRO_CLAIM_ID
		--INNER JOIN 
		--(
		--SELECT CLAIM_ID,max(LAST_UPD_DATE) as LAST_UPD_DATE
		--FROM OUTB_CLAIM_STATUS
		--GROUP BY CLAIM_ID
		--) Z ON C.CLAIM_ID = Z.CLAIM_ID AND C.LAST_UPD_DATE = Z.LAST_UPD_DATE 
				--AND C.WIPRO_CLAIM_ID = W.WIPRO_CLAIM_ID
		Where C.CLAIM_ID not in 
		(
		select distinct claim_id 
		from OUTB_CLAIM_STATUS
		where CLMSTAT_STATUS in
			( 'A-ICN' 
			 ,'R-ICN' 
			 ,'A-277' 
					) 
		)
	

--TETDM-1802
/*
				UPDATE OUTB_CLAIM_STATUS
				SET 
				       P.STAT_REJ_REA_ID =  R.AssignedRejectMessageID
				      ,P.REJ_REA_MSG  =  R.AssignedRejectMessageIDDetail 
				SELECT T.RejectReasonID AS RejectIDFromAcceptedFile, T.RejectReasonMessage  AS RejectMessageFromAcceptedFile,t.CLAIM_ID,t.WIPRO_CLAIM_ID,
				R.AssignedRejectMessageID AS RejectIDFromRejectedFile,R.AssignedRejectMessageIDDetail AS RejectMessageFromRejectedFile,*                                   
				FROM #TMP_WIPRO_277 T
				JOIN 
				--FROM
				WIPRO..OUTB_CLAIM_STATUS P
				ON --P.SOURCEDATAKEY = T.SOURCEDATAKEY
				--AND 
				P.CLAIM_ID = T.CLAIM_ID
				--AND P.WIPRO_CLAIM_ID = T.WIPRO_CLAIM_ID
				JOIN WIPRO..Wipro_277_Rejected R
						ON t.CLAIM_ID = r.PlanClaimNumber
						--ON P.CLAIM_ID = r.PlanClaimNumber
				where P.CLMSTAT_STATUS = 'R-277'
			    AND ISNULL(R.AssignedRejectMessageID,'') <> ''
				AND P.CLAIM_ID IN (
				 '23296823'
				,'23323279'
				,'23323286'
				,'23334513'
				,'23335208'
				)
				ORDER BY P.LAST_UPD_DATE DESC	
*/
--Rejected Claims
				UPDATE P
				SET 
				       P.STAT_REJ_REA_ID =  R.AssignedRejectMessageID
				      ,P.REJ_REA_MSG  =  R.AssignedRejectMessageIDDetail 			
				--SELECT P.STAT_REJ_REA_ID,R.AssignedRejectMessageID,P.REJ_REA_MSG,R.AssignedRejectMessageIDDetail ,P.CLAIM_ID, r.PlanClaimNumber
				FROM
				WIPRO..OUTB_CLAIM_STATUS P
				JOIN
				(
				SELECT z.AssignedRejectMessageID ,
                       z.AssignedRejectMessageIDDetail ,
                       z.PlanClaimNumber
                       FROM 
				(
				SELECT  
				R.AssignedRejectMessageID ,R.AssignedRejectMessageIDDetail ,r.PlanClaimNumber                        
				,ROW_NUMBER() OVER (PARTITION BY R.PlanClaimNumber  ORDER BY R.PlanClaimNumber ) AS RwNum
				FROM WIPRO..Wipro_277_Rejected R
				--WHERE R.PlanClaimNumber IN 
				--(
				-- '23296823'
				--,'23323279'
				--,'23323286'
				--,'23334513'
				--,'23335208'
				--)
				) z WHERE z.RwNum = 1 
				) R ON P.CLAIM_ID = r.PlanClaimNumber
				where P.CLMSTAT_STATUS = 'R-277'


--Accepted Claims
				UPDATE P
				SET 
				       P.STAT_REJ_REA_ID =  A.AssignedRejectMessageID
				      ,P.REJ_REA_MSG  =  A.AssignedRejectMessageIDDetail 			
				--SELECT P.STAT_REJ_REA_ID,A.AssignedRejectMessageID,P.REJ_REA_MSG,A.AssignedRejectMessageIDDetail ,P.CLAIM_ID, r.PlanClaimNumber
				FROM
				WIPRO..OUTB_CLAIM_STATUS P
				LEFT JOIN WIPRO..Wipro_277_Rejected R ON P.CLAIM_ID = r.PlanClaimNumber
				JOIN
				(
				SELECT z.AssignedRejectMessageID ,
                       z.AssignedRejectMessageIDDetail ,
                       z.PlanClaimNumber
                       FROM 
				(
				SELECT  
				A.AssRejectMessageID AS AssignedRejectMessageID,A.AssRejectMessageIDDetail AS AssignedRejectMessageIDDetail,A.PlanClaimNumber,
				A.StatusActionCode                       
				,ROW_NUMBER() OVER (PARTITION BY a.PlanClaimNumber  ORDER BY a.PlanClaimNumber ) AS RwNum
				FROM WIPRO..WIPRO_277_Accepted A
				WHERE A.StatusActionCode = 'U' 
				) z WHERE z.RwNum = 1 
				) A ON P.CLAIM_ID = A.PlanClaimNumber
				where P.CLMSTAT_STATUS = 'R-277'
				AND r.PlanClaimNumber IS NULL
				
				/*
				AND  z.PlanClaimNumber = '16054E067449'
				*/


				
		

--ROLLBACK TRAN
--COMMIT TRAN


/*
--Create Sample Records
SET ROWCOUNT 0
SET ROWCOUNT 10 
SELECT c.CLMSTAT_STATUS,w.CLMSTAT_STATUS,
CASE WHEN ((c.CLMSTAT_STATUS IN ('A','R','A-999','R-999','R-277','MAO-004') OR c.CLMSTAT_STATUS IS NULL)
										AND W.CLMSTAT_STATUS = 'A-277')
			THEN 'A-277'
	 WHEN ((c.CLMSTAT_STATUS IN ('A','R','A-999','R-999','MAO-004') OR c.CLMSTAT_STATUS IS NULL)
										AND W.CLMSTAT_STATUS = 'R-277')
			THEN 'R-277'
			--ELSE 'No Change'
			ELSE c.CLMSTAT_STATUS
			END AS UpdatedValue
			,*
		--SELECT C.CLMSTAT_STATUS,*
		--SELECT TOP 1000 C.CLMSTAT_STATUS,*
		FROM OUTB_CLAIM_STATUS C
		INNER JOIN  #TMP_WIPRO_277 W
		ON C.CLAIM_ID = W.CLAIM_ID 
		AND C.WIPRO_CLAIM_ID = W.WIPRO_CLAIM_ID

--(CLMSTAT_STATUS IN ('A','R','A-999','R-999','R-277','A-277','R-ICN','MAO-004') OR CLMSTAT_STATUS IS NULL)


SELECT * FROM #TMP_WIPRO_277
where clmstat_status not in ('a-277','r-277')
*/



		

--ASSIGN @TOTAL_RECORDS - GET RECORD COUNTS For table being archived
		SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #TMP_WIPRO_277)
		
													
	---- Update Run Controls 
									
								UPDATE EXT_SYS_RUNLOG
								SET END_DT = GETDATE()	
									,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
									,TOTAL_RECORDS = @TOTAL_RECORDS
									,ENTRYDT = GETDATE()
								WHERE PROC_NAME = 'EXSP_WIPRO_277_Updates' + '-' + 'JOBID' +'='+ CONVERT(CHAR, @JOBID)
												and END_DT is null

