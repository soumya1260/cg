﻿ 
CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_PROF_ENCEDI_PROF_5010] 
(@SOURCEDESC VARCHAR(50))--,@SOURCE_ENVIRONMENT VARCHAR(10)) 
AS 
/************************************************************************************************************************ 
** CREATE DATE: 06/12/2013 
** 
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM 
** 
** DESCRIPTION: PROCEDURE WILL PERFORM REQUIRED TRANSFORMATIONS REQUIRED TO OBTAIN INFORMATION FROM THE ODS EDI PROFESSIONAL   
**              EDI CATCH ALL TABLE. THIS INFORMATION IS NEEDED FOR THE HRP CLAIM FILE.  
**              TABLES SUPPORTING THIS SCRIPT ARE OWNED AND MAINTAINED BY THE ODS TEAM.  
** 
** 
Modification History 
==================== 
Date			Who				Description 
-------------------------------------------------------------------------------------------------------------------------- 
05/16/2014		Loyal Ricks		Add input parameter @SOURCE_ENVIRONMENT in order to select appropriate "catch all" records 
								according to job run parameters 
07/15/2016		Loyal Ricks		Remove input parameters @SOURCE_ENVIRONMENT 
								job will utilize exclusion build "DP" logic for selection of valid claims. All PROD 
								only claims will be selected. Functionality to select UAT claims removed, no longer  
								needed.		 
**************************************************************************************************************************/ 
--DECLARE VARIABLES 
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND 
			DECLARE 
			 
			@TOTAL_RECORDS INT 
 
 
--HRP_CLAIM_FILE Run controls 
INSERT INTO EXT_SYS_RUNLOG 
		(PROC_NAME 
		,STEP 
		,START_DT 
		,END_DT 
		,RUN_MINUTES 
		,TOTAL_RECORDS 
		,ENTRYDT 
		) 
		VALUES('pr_BUILD_OUTB_PROF_ENCEDI_PROF_5010' 
				,'8' 
				,GETDATE() 
				,NULL 
				,NULL 
				,0 
				,GETDATE() 
				) 
				 
				--GET ALL OUTBOUND CLAIMS WITH MODIFIER 1 = '90' 
				IF OBJECT_ID('TEMPDB..#TMP_CLIA') <> 0 
				DROP TABLE #TMP_CLIA 
				 
					SELECT CLAIM_ID,CLAIM_LINE_NO,CLIA_NO 
					INTO #TMP_CLIA 
					FROM OUTB_PROF_DETAIL 
					WHERE PROC_MOD1 = '90' 
 
				--UPDATE #TMP_CLIA FROM EDI_PROF_5010 
				 
					UPDATE #TMP_CLIA 
					SET CLIA_NO = ISNULL(EP.CLIA,' ') 
					FROM #TMP_CLIA T 
					JOIN edps_data.dbo.EDI_Prof_5010 EP 
					ON T.CLAIM_ID = EP.ClaimNo 
					AND T.CLAIM_LINE_NO = EP.LineID 
					AND EP.SourceDesc = @SOURCEDESC  
					--and EP.SourceEnvironment = @SOURCE_ENVIRONMENT 
					 
				--UPDATE EXT_HRP_CLAIM_DETAIL CLIA_NO 
					UPDATE OUTB_PROF_DETAIL 
					SET CLIA_NO = T.CLIA_NO 
					FROM EXT_HRP_CLAIM_DETAIL CD 
					JOIN #TMP_CLIA T 
					ON CD.CLAIM_ID = T.CLAIM_ID 
					AND CD.CLAIM_LINE_NO = T.CLAIM_LINE_NO  
					 
		 
		--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RESEND 
							  
			SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #TMP_CLIA) 
									 
		----HRP_CLAIM_FILE Update Run Controls 
				BEGIN TRANSACTION 
						UPDATE EXT_SYS_RUNLOG 
						SET END_DT = GETDATE()	 
							,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()) 
							,TOTAL_RECORDS = @TOTAL_RECORDS 
							,ENTRYDT = GETDATE() 
						WHERE PROC_NAME = 'pr_BUILD_OUTB_PROF_ENCEDI_PROF_5010' 
							AND END_DT IS NULL 
							IF @@ERROR <> 0 
										BEGIN  
												ROLLBACK  
										END 
						COMMIT 
						 
