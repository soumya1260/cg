﻿

CREATE PROCEDURE dbo.usp_Auto_Resub_Insert
AS BEGIN
/*************************************************************************************************************
** CREATE DATE: 09/28/2021
**
** AURTHOR: Anthony Ulmer
**
** DESCRIPTION: This procedure will take items loaded from auto resub files and place them in the test bed
**              
**              
**
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
09/28/2021		Anthony Ulmer	TETDM-2570 Initial creation
04/22/2024		Anthony Ulmer	RETM-575	
									Update to accomodate add/delete for DME claims 


**************************************************************************************************************/
SET NOCOUNT ON;

--Begin Claim Check
DECLARE @Deleted_Items TABLE(
	File_Name_ID VARCHAR(255),
	Row_ID INT
);

/*
	created to accomodate OSS SDK maps for future date
	Add new mappings to the table variable insert below
*/
DECLARE @SDK_Map TABLE 
(
	SDK INT PRIMARY KEY,
	Is_FFS BIT
);

INSERT INTO @SDK_Map (SDK, Is_FFS)
	VALUES (4, 0),
		   (50, 1),
		   (30, 1);

/*
These two checks do not check DME claims
*/
INSERT INTO dbo.OUTB_AUTO_TEST_BED_ERRORS (Row_Error_Message, Row_ID, File_Name_ID, Claim_Error, Entry_Date)
OUTPUT INSERTED.File_Name_ID,INSERTED.Row_ID
INTO @Deleted_Items
SELECT
	CONCAT('Claim (',owatb1.Claim_ID, ') not found in CLAIMDIM'),
	owatb1.File_Row_ID,
	owatb1.File_Name,
	'Claim Error',
	owatb1.Load_Date	
FROM staging.OUTB_WIPRO_AUTO_TEST_BED owatb1
WHERE EXISTS ( SELECT
					owatb.Source_Data_Key,
					owatb.Claim_ID
				FROM staging.OUTB_WIPRO_AUTO_TEST_BED owatb
				WHERE 1 = 1
					AND owatb.Claim_Type != 'E'
					AND owatb.Claim_ID = owatb1.Claim_ID
					AND owatb.Source_Data_Key = owatb1.Source_Data_Key
					AND EXISTS (SELECT * FROM @SDK_Map M WHERE M.SDK = owatb.Source_Data_Key AND M.Is_FFS = 1)
				EXCEPT
				SELECT
					c.SOURCEDATAKEY,
					c.CLAIMID
				FROM EDPS_Data.dbo.CLAIMDIM c);


INSERT INTO dbo.OUTB_AUTO_TEST_BED_ERRORS (Row_Error_Message, Row_ID, File_Name_ID, Claim_Error, Entry_Date)
OUTPUT INSERTED.File_Name_ID,INSERTED.Row_ID
INTO @Deleted_Items
SELECT
	CONCAT('Claim (',owatb1.Claim_ID, ') not found in encounterclaimdim for source: ',owatb1.Source_Desc),
	owatb1.File_Row_ID,
	owatb1.File_Name,
	'Claim Error',
	owatb1.Load_Date	
FROM staging.OUTB_WIPRO_AUTO_TEST_BED owatb1
WHERE EXISTS (	SELECT
					owatb.Source_Desc,
					owatb.Claim_ID,
					owatb.Claim_Type
				FROM staging.OUTB_WIPRO_AUTO_TEST_BED owatb
				WHERE 1 = 1
					AND owatb.Claim_Type != 'E'
					AND owatb1.Source_Desc = owatb.Source_Desc
					AND owatb1.Claim_ID = owatb.Claim_ID
					AND owatb1.Claim_Type = owatb.Claim_Type
					AND EXISTS (SELECT * FROM @SDK_Map M WHERE M.SDK = owatb.Source_Data_Key AND M.Is_FFS = 0)
				EXCEPT
				SELECT
					e.SourceDesc,
					e.ClaimNum,
					e.ClaimType
				FROM EDPS_Data.dbo.encounterclaimdim e);


DELETE owatb
FROM staging.OUTB_WIPRO_AUTO_TEST_BED owatb
JOIN @Deleted_Items DI
	ON DI.File_Name_ID = owatb.File_Name
	AND DI.Row_ID = owatb.File_Row_ID;
--End claim check

--clear temporal results table
TRUNCATE TABLE staging.OUTB_AUTO_TEST_BED_TEMPORAL;

--Begin test bed inserts
--EncounterClaims
WITH stage_claims AS (
	SELECT DISTINCT
		owatb.Test_ID
	   ,owatb.Source_Data_Key
	   ,owatb.Source_Desc
	   ,owatb.Type_Code_LOB -- this field must be provided on file due to job ID setup for encounters
	   ,owatb.LOB_Code -- this field must be provided on file due to job ID setup for encounters
	   ,Claim_ID = LTRIM(RTRIM(owatb.Claim_ID))
	   ,owatb.Claim_Type
	   ,owatb.Previous_Claim_ID
	   ,owatb.Frequency_Code
	   ,owatb.Adjustment
	   ,[Action] = LTRIM(RTRIM(owatb.Action))
	   ,owatb.File_Name
	   ,owatb.Load_Date
	FROM staging.OUTB_WIPRO_AUTO_TEST_BED owatb
	WHERE 1 = 1
		AND owatb.Claim_Type != 'E'
		AND (owatb.Adjustment != 'Y' OR owatb.Adjustment IS NULL)
		AND EXISTS (SELECT * FROM @SDK_Map M WHERE M.SDK = owatb.Source_Data_Key AND M.Is_FFS = 0)
)
MERGE dbo.OUTB_WIPRO_TEST_BED AS target
USING stage_claims AS source
	ON source.Test_ID = target.TESTID
	AND source.Source_Data_Key = target.SOURCEDATAKEY
	AND source.Claim_ID = target.CLAIMID
	AND source.Claim_Type = target.CLAIM_TYPE
	AND source.Source_Desc = target.SOURCEDESC --required for encounters	
WHEN NOT MATCHED BY TARGET AND (source.Action != 'D' OR source.Action IS NULL) THEN
INSERT (TESTID, TEST_DESC,CLAIMID,typecode,SOURCEDATAKEY, SOURCEDESC, CLAIM_TYPE, LAST_UPD_DATE, ORIG_BIDW_EXTRACT_DT, LAST_BIDW_EXTRACT_DT)
VALUES (source.Test_ID,
		LEFT(CONCAT('Auto-Resub-',source.File_Name),50),
		source.Claim_ID,
		source.Type_Code_LOB,
		source.Source_Data_Key,
		source.Source_Desc,
		source.Claim_Type,
		CAST(GETDATE() AS SMALLDATETIME),
		CONVERT(VARCHAR,getdate(),100),
		CONVERT(VARCHAR,getdate(),100))
WHEN MATCHED AND SOURCE.Action = 'D' THEN DELETE --remove if marked for deletion
OUTPUT	 COALESCE(INSERTED.TESTID, DELETED.TESTID)
		,$ACTION 
		,COALESCE(INSERTED.CLAIMID,DELETED.CLAIMID)
		,COALESCE(INSERTED.CLAIM_TYPE,DELETED.CLAIM_TYPE)		
		,0 INTO staging.OUTB_AUTO_TEST_BED_TEMPORAL;
		
--EncounterClaims DME
WITH stage_claims AS (
SELECT DISTINCT
	owatb.Claim_ID,
	owatb.Source_Desc,
	owatb.Source_Data_Key,
	owatb.Claim_Type,
	[Action] = LTRIM(RTRIM(owatb.Action))
FROM staging.OUTB_WIPRO_AUTO_TEST_BED owatb
WHERE 1 = 1
	AND owatb.Claim_Type = 'E' 
	AND EXISTS (SELECT * FROM @SDK_Map M WHERE M.SDK = owatb.Source_Data_Key AND M.Is_FFS = 0)
)
MERGE dbo.EXT_ENCOUNTER_DME AS target
USING stage_claims AS source
	ON source.Claim_ID = target.CLAIMNUM
	AND source.Source_Data_Key = target.SourceDataKey
	AND source.Source_Desc = target.SOURCEDESC
WHEN NOT MATCHED BY TARGET AND (source.Action != 'D' OR source.Action IS NULL) THEN
INSERT (CLAIMNUM, CLAIM_TYPE, SOURCEDESC, SourceDataKey, IS_AUTO_RESUB)
VALUES (source.Claim_ID,		
		source.Claim_Type,
		source.Source_Desc,
		source.Source_Data_Key,
		1) --set bit on table to indicate it was inserted as part of automated process
WHEN MATCHED AND SOURCE.Action = 'D' THEN DELETE --remove if marked for deletion
OUTPUT	 NULL --no test ID for DME here
		,$ACTION 
		,COALESCE(INSERTED.CLAIMNUM,DELETED.CLAIMNUM)
		,COALESCE(INSERTED.CLAIM_TYPE,DELETED.CLAIM_TYPE)		
		,0 INTO staging.OUTB_AUTO_TEST_BED_TEMPORAL;	


--FFS Claims
WITH stage_claims AS (
	SELECT DISTINCT
		owatb.Test_ID
	   ,owatb.Source_Data_Key
	   ,owatb.Source_Desc
	   ,LOB_Code = CASE 
                        	WHEN owatb.Test_ID IN (2004,2006, 2008,2010) THEN 'C54581391'                        	
                        	ELSE NULL
                        END
	   ,Type_Code_LOB = CASE 
                   		WHEN owatb.Test_ID IN (2000,2001,2002,2003,2020,2021) THEN 'MAO'
                   		WHEN owatb.Test_ID IN (2004,2006) THEN 'MMAI'
                   		WHEN owatb.Test_ID IN (2008,2010) THEN 'CAID'
						ELSE NULL
                   END
	   ,Claim_ID = LTRIM(RTRIM(owatb.Claim_ID))
	   ,owatb.Claim_Type
	   ,owatb.Previous_Claim_ID
	   ,owatb.Frequency_Code
	   ,owatb.Adjustment
	   ,[Action] = LTRIM(RTRIM(owatb.Action))
	   ,owatb.File_Name
	   ,owatb.Load_Date
	FROM staging.OUTB_WIPRO_AUTO_TEST_BED owatb
	WHERE 1 = 1
		AND owatb.Claim_Type != 'E'
		AND (owatb.Adjustment != 'Y' OR owatb.Adjustment IS NULL)
		AND EXISTS (SELECT * FROM @SDK_Map M WHERE M.SDK = owatb.Source_Data_Key AND M.Is_FFS = 1)
)
MERGE dbo.OUTB_WIPRO_TEST_BED AS target
USING stage_claims AS source
	ON source.Test_ID = target.TESTID
	AND source.Source_Data_Key = target.SOURCEDATAKEY
	AND source.Claim_ID = target.CLAIMID
	AND source.Claim_Type = target.CLAIM_TYPE		
WHEN NOT MATCHED BY TARGET AND (source.Action != 'D' OR source.Action IS NULL) THEN
INSERT (TESTID, TEST_DESC,CLAIMID,typecode,SOURCEDATAKEY, Claim_Type, LOBCODE, LAST_UPD_DATE, ORIG_BIDW_EXTRACT_DT, LAST_BIDW_EXTRACT_DT)
VALUES (source.Test_ID,
		LEFT(CONCAT('Auto-Resub-',source.File_Name),50),
		source.Claim_ID,
		source.Type_Code_LOB,
		source.Source_Data_Key,
		source.Claim_Type,
		source.LOB_Code,
		CAST(GETDATE() AS SMALLDATETIME),
		CONVERT(VARCHAR,getdate(),100),
		CONVERT(VARCHAR,getdate(),100))
WHEN MATCHED AND SOURCE.Action = 'D' THEN DELETE --remove if marked for deletion
OUTPUT	 COALESCE(INSERTED.TESTID, DELETED.TESTID)
		,$ACTION
		,COALESCE(INSERTED.CLAIMID,DELETED.CLAIMID)
		,COALESCE(INSERTED.CLAIM_TYPE,DELETED.CLAIM_TYPE)
		,0 INTO staging.OUTB_AUTO_TEST_BED_TEMPORAL;

--FFS DME
WITH stage_claims AS (
	SELECT DISTINCT
		owatb.Claim_ID,
		owatb.Source_Desc,
		owatb.Source_Data_Key,
		owatb.Claim_Type,
		[Action] = LTRIM(RTRIM(owatb.Action))
	FROM staging.OUTB_WIPRO_AUTO_TEST_BED owatb
	WHERE 1 = 1
		AND owatb.Claim_Type = 'E' 
		AND EXISTS (SELECT * FROM @SDK_Map M WHERE M.SDK = owatb.Source_Data_Key AND M.Is_FFS = 1))
MERGE dbo.EXT_CLAIM_DME AS target
USING stage_claims AS source
	ON source.Claim_ID = target.CLAIMID
	AND source.Source_Data_Key = target.SourceDataKey
WHEN NOT MATCHED BY TARGET AND (source.Action != 'D' OR source.Action IS NULL) THEN
INSERT (CLAIMID, CLAIM_TYPE, SourceDataKey,vendornpi, IS_AUTO_RESUB)
VALUES (source.Claim_ID,		
		source.Claim_Type,
		source.Source_Data_Key,
		'', --vendornpi is required for some odd reason (I don't think it is ever used)
		1) --set bit on table to indicate it was inserted as part of automated process
WHEN MATCHED AND SOURCE.Action = 'D' THEN DELETE --remove if marked for deletion
OUTPUT	 NULL --no test ID for DME here
		,$ACTION
		,COALESCE(INSERTED.CLAIMID,DELETED.CLAIMID)
		,COALESCE(INSERTED.CLAIM_TYPE,DELETED.CLAIM_TYPE)		
		,0 INTO staging.OUTB_AUTO_TEST_BED_TEMPORAL;	


--Adjustments
--LOB_Code is required on the file input for these
WITH stage_claims AS (
	SELECT DISTINCT
		owatb.Test_ID
	   ,owatb.Source_Data_Key
	   ,owatb.Source_Desc
	   ,Type_Code_LOB = CASE 
                        	WHEN owatb.LOB_Code = 'MMAI' AND  owatb.Test_ID IN (3000,3001,3006,3060,3061) THEN 'C54581391'                        	
                        	ELSE NULL
                        END
	   ,typecode = owatb.Type_Code_LOB
	   ,Claim_ID = LTRIM(RTRIM(owatb.Claim_ID))
	   ,Claim_Type = CASE 
                     	WHEN owatb.Test_ID IN (3000,3060) THEN 'I'
                     	WHEN owatb.Test_ID IN (3001,3061) THEN 'P'
						WHEN owatb.Test_ID IN (3006,3066) THEN 'E'
                     	ELSE NULL
                     END
	   ,owatb.Previous_Claim_ID
	   ,owatb.Frequency_Code
	   ,owatb.Adjustment
	   ,[Action] = LTRIM(RTRIM(owatb.Action))
	   ,owatb.File_Name
	   ,owatb.Load_Date
	FROM staging.OUTB_WIPRO_AUTO_TEST_BED owatb
	WHERE owatb.Adjustment = 'Y'
		AND owatb.Claim_Type != 'E'
		AND owatb.Test_ID BETWEEN 3000 AND 3066
)
MERGE dbo.OUTB_WIPRO_TEST_BED_ADJUSTMENTS AS target
USING stage_claims AS source
	ON source.Test_ID = target.TESTID
	AND source.Source_Data_Key = target.SOURCEDATAKEY
	AND source.Claim_ID = target.CLAIMID
	AND source.Claim_Type = target.CLAIM_TYPE		
WHEN NOT MATCHED BY TARGET AND (source.Action != 'D' OR source.Action IS NULL) THEN
INSERT (TESTID, TEST_DESC,CLAIMID,typecode,SOURCEDATAKEY,
		Claim_Type, LOBCODE, LAST_UPD_DATE, ORIG_BIDW_EXTRACT_DT, LAST_BIDW_EXTRACT_DT,
		NEWFREQUENCYCODE, ORIGCLAIMNO, SOURCEDESC)
VALUES (source.Test_ID,
		LEFT(CONCAT('Auto-Resub-',source.File_Name),50),
		source.Claim_ID,
		source.typecode,
		source.Source_Data_Key,
		source.Claim_Type,
		source.Type_Code_LOB,
		CAST(GETDATE() AS SMALLDATETIME),
		CONVERT(VARCHAR,getdate(),100),
		CONVERT(VARCHAR,getdate(),100),
		SOURCE.Frequency_Code,
		SOURCE.Previous_Claim_ID,
		source.Source_Desc)
WHEN MATCHED AND SOURCE.Action = 'D' THEN DELETE --remove if marked for deletion
OUTPUT	 COALESCE(INSERTED.TESTID, DELETED.TESTID)
		,$ACTION
		,COALESCE(INSERTED.CLAIMID,DELETED.CLAIMID)
		,COALESCE(INSERTED.CLAIM_TYPE,DELETED.CLAIM_TYPE)
		,1 INTO staging.OUTB_AUTO_TEST_BED_TEMPORAL;

	RETURN 0;
END