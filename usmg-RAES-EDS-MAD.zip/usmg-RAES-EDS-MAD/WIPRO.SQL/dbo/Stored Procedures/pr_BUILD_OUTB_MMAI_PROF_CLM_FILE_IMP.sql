﻿


CREATE PROCEDURE [dbo].[pr_BUILD_OUTB_MMAI_PROF_CLM_FILE_IMP]
(
	@ExecutionMode		CHAR(1) = 'M'
	,@exclusionmode		char(1) = 'R'
	,@sourcedatakey		int
	,@LOB				CHAR(10)
	,@JOBID				INT
	--
	--	NOTE:	Pass in 'A' for new "automated" execution
	--			Default is [M]anual mode...
	-- @exclusionmode - Pass 'M' for migration exclusions, 'R' default = regular exclusion
)

AS
/***************************************************************************************************
** CREATE DATE: 08/2012
**
** AUTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL EXECUTE REQUIRD STEPS FOR COMPILING HRP MHC CLAIM SUBMISSIONS.
**              USING THE HRP HealthSpring CLAIM ENCOUNTER Import File Speficiations 3.0.0. THE SOURCE  
**              TABLES SUPPORTING THIS SCRIPT RESIDE IN THE BIDW AND MDQOLIB DATABASES. 
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
10/28/12		LOYAL RICKS		REMOVED EXSP_HRP_CLAIM_RESEND procedure call, replaed with 
								EXSP_HRP_CLAIM_EXCLUSION procedure call
03/06/2013		LOYAL RICKS		ADD CATCHALL REQUIRED TABLE TO PROCESS - EXECUTE EXSP_HRP_CLAIM_REQ5010
								REMOVE EXSP_HRP_CLAIM_PROVIDER 
								ADD EXSP_HRP_CLAIM_EDSPROVIDER
07/24/2013		Dwight Staggs	Removed creating of EXT_HRP_CLAIM_EXCLUSION table.  That table is now
								created in the first step of the SSIS Extract Package when the table
								dbo.EDS_AllExtractClaims is built							
09/18/2013		Dwight Staggs	Added @ExecutionMode input parameter for backward compatibility.  The
								default of 'M' executes the same as previously.  When set to 'A', we 
								by-pass creating the EXT_HRP_CLAIM_EXCLUSION table (see 7/24 comments).
								This parameter is also used in the Claim Header SP executed herein.
10/10/2013		Loyal Ricks		Add procedure EXSP_HRP_CLAIM_PROF5010	
11/15/2013		Loyal Ricks		Add input parameter @exclusionmode for main procedure and calling procedure
								EXSP_HRP_CLAIM_EXCLUSION. Parm used by exclusion process to determine 
								whether to execute in migration mode "M" or regular mode "R" default.
11/15/2013		Loyal Ricks		Replace @sourcedatakey parameter with @DATASOURCEKEY for procedure
								EXSP_HRP_CLAIM_EXCLUSION	
05/02/2014		Loyal Ricks		Upgrade mapping from Verisk 3.2 to Verisk 4.0 - EXSP_HRP_CLAIM_MAP_V4	
*****************************************************************************************************	
------------------------------------------------------------------------------------------------------
******************************************************************************************************
------------------------------------------------------------------------------------------------------

2014-06-25		Loyal Ricks		WIPRO Implementation			
2014-08-22		Loyal Ricks		Revise for MMAI Import, preliminary prod selection from 
								MMAIClaimDetailDim	
09/10/14		Loyal Ricks		EDS-397 - Add sp - pr_BUILD_OUTB_INST_WIPRO_DATASCRUB		
09/30/14		Loyal Ricks		Added @SOURCEDATAKEY for future use and @LOB for outbound map procedure	
10/17/14		Loyal Ricks		EXECUTE dbo.pr_BUILD_OUTB_MMAI_PROF_CLAIM_HEADER_IMP @ExecutionMode	,@JOBID	
12/23/14		Loyal Ricks		Add - 	EXECUTE dbo.pr_BUILD_PROF_DME
								Remove transactions			
03/03/15		Loyal Ricks		EDS-763 Professional Code Base Updates. 													    
*****************************************************************************************************/


	SET NOCOUNT ON;
	
	DECLARE @CatchErrorMessage VARCHAR(2200);
	DECLARE	@TOTAL_RECORDS INT
			,@DATASOURCEKEY INT
			
	SET @DATASOURCEKEY = 50; --QNXT


BEGIN TRY
	--HRP_CLAIM_FILE Run controls
	

	INSERT INTO EXT_SYS_RUNLOG
			(PROC_NAME
			,STEP
			,START_DT
			,END_DT
			,RUN_MINUTES
			,TOTAL_RECORDS
			,ENTRYDT
			)
	VALUES('pr_EXSP_QNXT_MMAI_IMP'
			,'1'
			,GETDATE()
			,NULL
			,NULL
			,0
			,GETDATE()
			)
	

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH


BEGIN TRY

		--	
		-- Note 
		--6/25 - disable automation steps for initial testing
		--	
		-- Note
		--
		-- 10/17	- Add @JOBID 9000 Check for exclusion history build
		--	

		--IF @ExecutionMode <> 'A' AND @JOBID <> 9000
		BEGIN
			EXECUTE EXSP_WIPRO_CLAIM_EXCLUSION @DATASOURCEKEY,@exclusionmode
		END

		--IF @ExecutionMode <> 'A'
		--BEGIN
		--	EXECUTE dbo.pr_EXSP_CLAIM_PROF_QNXT_CLMHEADER @ExecutionMode = 'M'
		--END
		--ELSE
		--BEGIN
		--	EXECUTE dbo.pr_EXSP_CLAIM_PROF_QNXT_CLMHEADER @ExecutionMode = 'A'
		--END
		
		EXECUTE dbo.pr_BUILD_OUTB_MMAI_PROF_CLAIM_HEADER_IMP @ExecutionMode	,@JOBID		

		EXECUTE dbo.BUILD_OUTB_PROF_CLM_DETAIL

		EXECUTE dbo.BUILD_OUTB_PROF_DIAG_WIPRO @SOURCEDATAKEY

		EXECUTE dbo.BUILD_OUTB_PROF_DIAG_POINTERS

		EXECUTE dbo.BUILD_OUTB_PROF_EDSPROVIDER

		EXECUTE dbo.BUILD_OUTB_PROF_ADJUSTMENTS_WIPRO

		EXECUTE dbo.BUILD_OUTB_PROF_REQ5010
		
		EXECUTE dbo.BUILD_OUTB_PROF_5010

		EXECUTE dbo.pr_BUILD_PROF_DME

		EXECUTE dbo.pr_BUILD_OUTB_PROF_WIPRO_DATASCRUB

		EXECUTE dbo.BUILD_OUTB_PROF_MAP @LOB

		
END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH

BEGIN TRY

	SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM OUTB_PROF_HEADER)
	SET @TOTAL_RECORDS = @TOTAL_RECORDS + (SELECT COUNT(*) FROM OUTB_PROF_DETAIL)
									
	----HRP_CLAIM_FILE Update Run Controls
	

	UPDATE EXT_SYS_RUNLOG
	SET END_DT = GETDATE()	
		,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE())
		,TOTAL_RECORDS = @TOTAL_RECORDS
		,ENTRYDT = GETDATE()
	WHERE PROC_NAME = 'pr_EXSP_QNXT_MMAI_IMP'
					and END_DT is null
	

END TRY

BEGIN CATCH
	SELECT @CatchErrorMessage = 
		'Procedure: ' + 
		OBJECT_NAME(@@PROCID) +
		' || ErrorNumber: ' + 
		CAST(ERROR_NUMBER() AS VARCHAR(10)) +
		' || ErrorMessage: ' +
		ERROR_MESSAGE() +
		' || ErrorLine: ' +
		CAST(ERROR_LINE() AS VARCHAR(10));
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;
	RAISERROR(@CatchErrorMessage, 16, 1);
END CATCH




/******************************************************************************
UNIT TEST:

DECLARE @StartTime DATETIME
SET @StartTime = GETDATE()

BEGIN TRANSACTION

	EXEC [dbo].[pr_EXSP_QNXT_CLAIM]
		@ExecutionMode	= 'M'
		
ROLLBACK TRANSACTION

SELECT DATEDIFF(ss,@StartTime,GETDATE()) as SecondsElasped
*************************************************************************************/








