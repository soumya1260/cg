﻿





CREATE PROCEDURE [dbo].[LoadClaimsDetails]
    (
      @FILEEXTENSION VARCHAR(50) ,
      @FILENAME VARCHAR(100) 
    )
AS 
/**********************************************************************************************************
** CREATE DATE: 04/07/2012
**
** AUTHOR:		BHARAT YENDLURI - BHARAT.YENDLURI@HEALTHSPRING.COM
**
** DESCRIPTION: PROCEDURE WILL UPDATE OUTB_FILE_HIST TABLE WITH ACCEPT, REJECT AND STATUS DATA, UPDATE 
**			    OUTB_CLAIM_STATUS TABLE WITH CLAIM LEVEL DATA AND INSERT CLAIM LEVEL DETAILS (MULTIPLE 
**				REJECT REASONS) INTO OUTB_CLAIM_STATUS_DTL FROM THE INBOUND HRP FILES. 
**				
** VALIDATIONS:	'HSPR' PRESENCE IN EACH FILE HEADER IS VERIFIED (FILE GENERATED AT HEALTH SPRING HAS HSPR).
**				'FILEID' FROM EACH FILE IS VALIDATED AGAINST THE FILEID ALREADY EXISTING IN HISTORY TABLE.
**				'CLAIM_ID' FROM STATUS FILE ID VALIDATED AGAINST THE CLAIM_ID EXISTING IN STATUS TABLE.
**
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------
2012-10-19		Dwight Staggs	Remove database name from table references
2013-04-30		Dwight Staggs	Added the columns FILEREJECTIONREASONCODE, FILEREJECTIONREASONMESSAGE, TRAILERFIELD,
								VALUEREPORTED, and VALUECALCULATED back to the Temp table DBO.TEMP_REJFILELOAD  
								and uncommented	the code that populates the corresponding columns in EXT_HRP_MAP_HIST
2013-06-09		Dwight Staggs	Recoded logic for getting VAL_ERR column in STATUS FILE REJECTs
2013-09-06		Dwight Staggs	Modified to include 3 new columns on VH v1.5.0 CMLSTAT specs:
									SecondaryPlanClaimNumber
									EffectiveEncounterFlag
									OriginalPlanClaimID
2014-11-06		Scott Waller	Added logic to validate that all the claims in the file being processed were originally
								sent to WIPRO on that same fileid.  They have been sending us claims that originated
								on different fileid's.  Reject the whole file if this occurs.
2015-02-17		Scott Waller	Fixed an issue where CLMSTAT 'R' records had invalid values (NULLs) in the WIPRO_CLAIM_ID
								column in the OUTB_CLAIM_STATUS and OUTB_CLAIM_STATUS_DTL tables .
************************************************************************************************************/
    BEGIN
        SET NOCOUNT ON 
                     
        DECLARE @FILETYPE INT
            
        SELECT  @FILETYPE = CASE WHEN @FILEEXTENSION = 'CLMACK' THEN 1
                                 WHEN @FILEEXTENSION = 'REJ' THEN 2
                                 WHEN @FILEEXTENSION = 'CLMSTAT' THEN 3
                            END	

----ACKNOWLEDGE FILE CODE
            
        IF ( @FILETYPE <= 1 ) 
            BEGIN

                DECLARE @CLIENTID VARCHAR(100)
                DECLARE @INBOUNDFILEID VARCHAR(100)
                DECLARE @FILECREATEDATE VARCHAR(14)
                
                SELECT  @CLIENTID = CLIENTID ,
                        @INBOUNDFILEID = I_FILEID,
                        @FILECREATEDATE=FILECREATEDATE
                FROM    DBO.TEMP_ACKFILELOAD
                                 
                IF EXISTS(  SELECT * FROM  DBO.OUTB_FILE_HIST  WHERE   FILEID = @INBOUNDFILEID AND @CLIENTID LIKE '%HSPR%' )  
                      
                          BEGIN                     
                                    SELECT  1 AS RESULTSVALIDFILE
                            BEGIN   
                             
                                UPDATE  A
                                SET     A.ACK_FILE_ID = SUBSTRING(B.FILEID,1,50),
                                        A.ACK_FILE_DT = SUBSTRING(@FILECREATEDATE,1,14) ,
                                        A.ACK_TOTALREC_REC_AMT = SUBSTRING (B.TOTALRECORDSRECEIVED,1,10),
                                        A.ACK_HDR_REC_AMT = SUBSTRING(B.CLAIMSHEADERRECORDSRECEIVED,1,10) ,
                                        A.ACK_LINE_REC_AMT = SUBSTRING(B.CLAIMLINERECORDRECEIVED,1,10) ,
                                        A.ACK_SUPL_REC_AMT =CASE  WHEN (CHARINDEX('^',B.SUPPORTINGDOCUMENTATION)-1)<=0 THEN '' ELSE SUBSTRING(B.SUPPORTINGDOCUMENTATION,1,(CHARINDEX('^',B.SUPPORTINGDOCUMENTATION))-1) END,
                                        A.LAST_UPD_DT = B.LAST_UPDATED_DATE
                                FROM    DBO.OUTB_FILE_HIST A
                                        INNER JOIN DBO.TEMP_ACKFILELOAD B ON A.FILEID = B.I_FILEID
                            END
                            
                    END
						    ELSE 
									BEGIN
										SELECT  0 AS RESULTSVALIDFILE 
									END
					END
			ELSE
        
---- REJECT FILE CODE 
          
           IF (	@FILETYPE <= 2
            AND @FILETYPE > 1 ) 
               
                BEGIN	
						DECLARE @REJINBOUNDFILEID VARCHAR(100)
					    DECLARE @REJCLIENTID VARCHAR(100)
					                          
                        SELECT  @REJCLIENTID = CLIENTID ,
								@REJINBOUNDFILEID = I_FILEID 
                        FROM    DBO.TEMP_REJFILELOAD  
                      
			 IF EXISTS(  SELECT  * FROM  DBO.OUTB_FILE_HIST WHERE FILEID = @REJINBOUNDFILEID AND @REJCLIENTID LIKE '%HSPR%') 
								
							BEGIN 
									 SELECT  2 AS RESULTSVALIDFILE            
                            BEGIN 
                             
								UPDATE  R
                                SET     R.REJ_FILE_ID  = SUBSTRING(S.FILEID,1,50),
                                        R.REJ_FILE_DT  = SUBSTRING(S.FILECREATEDATE,1,14) ,
                                        R.REJ_REA_CD   = SUBSTRING(S.FILEREJECTIONREASONCODE,1,20) ,
                                        R.REJ_REA_MSG  = SUBSTRING(S.FILEREJECTIONREASONMESSAGE,1,60) ,
                                        R.REJ_TRAILER  = SUBSTRING(S.TRAILERFIELD,1,60) ,
                                        R.REJ_VAL_RPTD = SUBSTRING(S.VALUEREPORTED,1,10) ,
                                        R.REJ_VAL_CALC = CASE  WHEN (CHARINDEX('^',S.VALUECALCULATED)-1)<=0 THEN '' ELSE SUBSTRING(S.VALUECALCULATED,1,(CHARINDEX('^',S.VALUECALCULATED))-1) END ,
                                        R.LAST_UPD_DT = S.LAST_UPDATED_DATE
                                FROM    DBO.OUTB_FILE_HIST R
                                        INNER JOIN DBO.TEMP_REJFILELOAD S ON R.FILEID = S.I_FILEID
                               
                               END
                               
                            END
                    ELSE
                    
						BEGIN 
									 SELECT  0 AS RESULTSVALIDFILE       
						END						
				END
	
	END     
	
----STATUS FILE CODE
                    
					IF ( @FILETYPE <= 3
                     AND @FILETYPE > 2 ) 
					    
                    BEGIN			
						DECLARE @STATINBOUNDIFILEID VARCHAR(100)
                        DECLARE @STATCLAIMNUMBER VARCHAR(20)
                        DECLARE @HISTFILEID INT
                        DECLARE @STATUSFILEID INT
                        DECLARE @STATCLIENTID VARCHAR(100)
                        DECLARE @MISSINGSTATCLAIMNUMBER VARCHAR(20)
                        DECLARE @ERRORSTATCLAIMNUMBER  VARCHAR(20)

-- 11/06/14 swaller
--		validate that all the claims in the file being processed were originally
--		sent to WIPRO on that same fileid.  They have been sending us claims that originated
--		on different fileid's.  Reject the whole file if this occurs.
						DECLARE @MISMATCHCLAIMANDFILE	CHAR(1)	= 'N'
						DECLARE @STATRECORDCOUNT		INT = 0
						DECLARE	@MISMATCHTESTCOUNT		INT = 0

						SELECT	@STATRECORDCOUNT = COUNT(*)
						FROM	DBO.TEMP_STATFILELOAD
						WHERE	NOT ((RECORDTYPE = '') OR (RECORDTYPE IS NULL))	-- count the non-header STAT records

						SELECT	@MISMATCHTESTCOUNT = COUNT(A.I_FILEID)
						FROM	DBO.TEMP_STATFILELOAD A
						INNER JOIN DBO.OUTB_CLAIM_STATUS B
							ON	B.FILEID		= A.I_FILEID
							AND	B.CLAIM_ID		= A.PLANCLAIMNUMBER
						WHERE	NOT ((A.RECORDTYPE = '') OR (A.RECORDTYPE IS NULL))	-- count the non-header STAT records

						IF (@STATRECORDCOUNT <> @MISMATCHTESTCOUNT)
							SELECT @MISMATCHCLAIMANDFILE = 'Y'
-- end swaller
-- 01/12/2015	- Scott Waller
--				- for testing purposes, I am overriding the MISMATCH logic
--				- REMOVE THIS WHEN TEST IS COMPLETE
						SELECT @MISMATCHCLAIMANDFILE = 'N'
-- end swaller
                        SELECT  @STATINBOUNDIFILEID = I_FILEID,
								@STATCLIENTID = CLIENTID
                        FROM    DBO.TEMP_STATFILELOAD  
                        
                        SELECT  @HISTFILEID=1
                        FROM    DBO.OUTB_FILE_HIST
                        WHERE   ( FILEID = @STATINBOUNDIFILEID )
                                                        
                        SELECT  @STATUSFILEID=1
                        FROM    DBO.OUTB_CLAIM_STATUS
                        WHERE   ( FILEID = @STATINBOUNDIFILEID ) 
                                
                        SELECT @STATCLAIMNUMBER=1
                        FROM DBO.TEMP_STATFILELOAD
                        WHERE RECORDTYPE<>'' AND PLANCLAIMNUMBER IN (SELECT DISTINCT CLAIM_ID FROM DBO.OUTB_CLAIM_STATUS)
                        
                       	SELECT @MISSINGSTATCLAIMNUMBER=1
						FROM DBO.TEMP_STATFILELOAD 
						WHERE RECORDTYPE<>'' AND PLANCLAIMNUMBER NOT IN (SELECT DISTINCT CLAIM_ID FROM DBO.OUTB_CLAIM_STATUS)
						
						SELECT @ERRORSTATCLAIMNUMBER=1
						FROM    DBO.OUTB_FILE_HIST
                        WHERE   ( FILEID <> @STATINBOUNDIFILEID OR @STATCLIENTID NOT LIKE '%HSPR%')
/*
select	@INBOUNDFILEID as INBOUNDFILEID,
		@STATINBOUNDIFILEID as STATINBOUNDIFILEID, 
		@STATCLIENTID as STATCLIENTID, 
		@STATUSFILEID as STATUSFILEID, 
		@STATCLAIMNUMBER as STATCLAIMNUMBER, 
		@MISSINGSTATCLAIMNUMBER as MISSINGSTATCLAIMNUMBER, 
		@ERRORSTATCLAIMNUMBER as ERRORSTATCLAIMNUMBER,
		@HISTFILEID as HISTFILEID
*/
IF EXISTS(  SELECT * 
			FROM  DBO.OUTB_FILE_HIST  
			WHERE   ((FILEID = @STATINBOUNDIFILEID)
			AND		 (@STATCLIENTID LIKE '%HSPR%' )
			AND		 (@MISMATCHCLAIMANDFILE = 'N')))

						IF(  (@HISTFILEID=@STATUSFILEID) AND (@STATCLIENTID LIKE '%HSPR%') AND @STATCLAIMNUMBER=1)                              
                         
                            BEGIN  
                                 SELECT 1 AS RESULTSVALIDFILE
                                
                            BEGIN
                                UPDATE  C
                                SET     STAT_FILE_ID =SUBSTRING( D.H_FILEID,1,50) ,
                                        STAT_FILE_DT =SUBSTRING(CAST( D.FILECREATEDATE AS VARCHAR(14)),1,14),
                                        STAT_REC_AMT = SUBSTRING(D.CLAIMSRECEIVED,1,10),
                                        STAT_ACCPT_AMT = SUBSTRING(D.CLAIMSACCEPTED,1,10) ,
                                        STAT_REJ_AMT = SUBSTRING(D.CLAIMSREJECTED,1,10),
                                        STAT_FATAL_ERR_AMT = SUBSTRING(D.ClaimsInFatalErrors,1,10),
                                        STAT_DUP_CLM_AMT = SUBSTRING(D.DuplicateClaims,1,10) ,
                                        STAT_INV_DOS_AMT = SUBSTRING(replace(D.InvalidDOSClaims,'^',''),1,10),
                                        C.LAST_UPD_DT = D.LAST_UPDATED_DATE
                                FROM    DBO.OUTB_FILE_HIST C
                                        INNER JOIN DBO.TEMP_STATFILELOAD D ON C.FILEID = D.I_FILEID
                                WHERE (RECORDTYPE='' OR RECORDTYPE IS NULL)
                                
---- STATUS FILE ACCEPTED CLAIM FILE DETAIL
                                UPDATE  P
                                SET     P.[CLMSTAT_STATUS] = Q.RECORDTYPE ,
					                    P.[STAT_CLM_TYPE] = Q.CLAIMTYPE ,
                                        P.[WIPRO_CLAIM_ID] = Q.[HRPCLAIMNUMBER] ,	-- was CLAIM_ID
                                        P.[CMS_ICN] = REPLACE(Q.CMSICN, '^', ''), 
                                        P.LAST_UPD_DATE = Q.LAST_UPDATED_DATE 
-- swaller 01/13/15                     ,P.SecondaryPlanClaimNumber = REPLACE(Q.SecondaryPlanClaimNumber, '^', '')  -- this has "WALLER"
                                        ,P.EffectiveEncounterFlag = REPLACE(Q.EffectiveEncounterFlag, '^', '')
                                        ,P.OriginalPlanClaimID = REPLACE(Q.OriginalPlanClaimID, '^', '')
                                        
                                FROM    DBO.OUTB_CLAIM_STATUS P
                                        INNER JOIN DBO.TEMP_STATFILELOAD Q ON P.FILEID = Q.I_FILEID
																	 AND Q.PLANCLAIMNUMBER = P.[CLAIM_ID]
																	 AND Q.RECORDTYPE = 'A'   
                                            
----STATUS FILE REJECTED CLAIM FILE DETAIL
                                UPDATE  P
                                SET     P.[CLMSTAT_STATUS] = Q.RECORDTYPE ,
                                        P.[STAT_CLM_TYPE] = Q.CLAIMTYPE ,
                                        P.[STAT_FATAL_ERR_FLAG] = CAST([FATALERRORFLAG] AS VARCHAR(1)) ,
--2015-02-17		Scott Waller
                                        P.[WIPRO_CLAIM_ID] = Q.[HRPCLAIMNUMBER] ,  -- was updating CLAIM_ID column...not good.  switched to WIPRO_CLAIM_ID
-- end 
                                        P.[STAT_REJ_REA_ID] = CAST(Q.[REJECTREASONID] AS VARCHAR(8)) ,
                                        P.[REJ_REA_MSG] = CAST(Q.[REJECTREASONMESSAGE] AS VARCHAR(200)) ,
                                        P.[LINE_SEQ_NO] = CAST(Q.[SERVICELINESEQUENCENUMBER] AS VARCHAR(4)) ,
                                        P.[OTH_PAYER_ID] = CAST(Q.[OTHERPAYERID] AS VARCHAR(50)) ,
                                        P.[FIELD_TYPE] = CAST(Q.[FIELDTYPE] AS VARCHAR(100)) ,
                                        P.[SUBTYPE] = CAST(Q.[FIELDSUBTYPE] AS VARCHAR(50)) ,
                                        P.[FIELD_SUB_QUAL] = CAST(Q.[FIELDSUBTYPEQUALIFIER] AS VARCHAR(15)) ,
                                        P.[FIELD_POS] = CAST(Q.[FIELDPOSITION] AS VARCHAR(50)) ,
                                        P.[FIELD_ERR] = CAST(Q.[FIELDINERROR] AS VARCHAR(100)) ,
                                        P.[VAL_ERR] = CAST(REPLACE(Q.VALUEINERROR, '^', '') AS varchar(1024)),
                                        P.LAST_UPD_DATE = Q.LAST_UPDATED_DATE
                                        ,P.SecondaryPlanClaimNumber = REPLACE(Q.SecondaryPlanClaimNumber, '^', '')
                                        ,P.EffectiveEncounterFlag = REPLACE(Q.EffectiveEncounterFlag, '^', '')
                                        ,P.OriginalPlanClaimID = REPLACE(Q.OriginalPlanClaimID, '^', '')

                                FROM    DBO.OUTB_CLAIM_STATUS P
                                        INNER JOIN DBO.TEMP_STATFILELOAD Q ON P.FILEID = Q.I_FILEID
																	 AND Q.PLANCLAIMNUMBER = P.[CLAIM_ID]
																	 AND Q.RECORDTYPE = 'R' 
								UPDATE [DBO].[TEMP_STATFILELOAD]
								SET CURRENT_FLAG = 'Y'
								WHERE I_FILEID IS NOT NULL 
								AND ((@STATUSFILEID=@HISTFILEID)AND @STATCLAIMNUMBER=1)
								                                                                          
 -- ONCE UPDATE IS COMPLETE IN STATUS TABLE , INSERT RECORDS INTO DBO.EXT_HRP_CLAM_STATUS_DTL BASED ON FILEID AND CLAIMID
 -- THIS IS TO CAPTURE THE MULTIPLE REJECT REASONS FOR EACH CLAIM
									INSERT INTO DBO.OUTB_CLAIM_STATUS_DTL
									(
										   [FILEID]
										  ,[RECORD_TYPE]
										  ,[CLAIM_TYPE]
										  ,[FATAL_ERR_FLAG]
										  ,[PAPER_CLM_FLAG]
										  ,[PLAN_CLAIM_NUMBER]
										  ,[WIPRO_CLAIM_NUMBER]
										  ,[REJ_REA_ID]
										  ,[REJ_REA_MSG]
										  ,[SERV_LINE_SEQ_NO]
										  ,[OTHER_PAYER_ID]
										  ,[FIELD_TYPE]
										  ,[FIELD_SUBTYPE]
										  ,[FILE_SUBTYPE_QUAL]
										  ,[FIELD_POS]
										  ,[FIELD_ERR]
										  ,[VAL_ERR]
										  ,[LAST_UPD_DATE]
										  ,[SOURCEDATAKEY]
										  ,[CURRENT_FLAG]
										  ,SecondaryPlanClaimNumber
										  ,EffectiveEncounterFlag
										  ,OriginalPlanClaimID
									)

									SELECT DISTINCT
										   SUBSTRING(B.I_FILEID,1,50) AS [FILEID]
										  ,SUBSTRING(B.RECORDTYPE,1,1) AS [RECORD_TYPE]
										  ,SUBSTRING(B.CLAIMTYPE,1,1) AS [CLAIM_TYPE]
										  ,SUBSTRING(B.FATALERRORFLAG,1,1) AS  [FATAL_ERR_FLAG]
										  ,SUBSTRING(B.PAPERCLAIMFLAG,1,1) AS  [PAPER_CLM_FLAG]
										  ,SUBSTRING(B.PLANCLAIMNUMBER ,1,20)AS  [PLAN_CLAIM_NUMBER]
										  ,SUBSTRING(B.HRPCLAIMNUMBER ,1,20)AS  [HRP_CLAIM_NUMBER]
										  ,SUBSTRING(B.REJECTREASONID ,1,8)AS  [REJ_REA_ID]
										  ,SUBSTRING(B.REJECTREASONMESSAGE ,1,200)AS  [REJ_REA_MSG]
										  ,SUBSTRING(B.SERVICELINESEQUENCENUMBER,1,4) AS  [SERV_LINE_SEQ_NO]
										  ,SUBSTRING(B.OTHERPAYERID,1,20) AS  [OTHER_PAYER_ID]
										  ,SUBSTRING(B.FIELDTYPE,1,100) AS  [FIELD_TYPE]
										  ,SUBSTRING(B.FIELDSUBTYPE,1,50) AS  [FIELD_SUBTYPE]
										  ,SUBSTRING(B.FIELDSUBTYPEQUALIFIER,1,15) AS  [FILE_SUBTYPE_QUAL]
										  ,SUBSTRING(B.FIELDPOSITION,1,50) AS  [FIELD_POS]
										  ,SUBSTRING(B.FIELDINERROR,1,100) AS  [FIELD_ERR]
										,CAST(REPLACE(B.VALUEINERROR, '^', '') AS varchar(1024)) AS [VAL_ERR] 
										  --,CASE  WHEN (CHARINDEX('^',B.VALUEINERROR)-1)<=0 THEN '' ELSE SUBSTRING(B.VALUEINERROR,1,(CHARINDEX('^',B.VALUEINERROR))-1) END AS  [VAL_ERR]
										  ,B.LAST_UPDATED_DATE AS [LAST_UPD_DATE]
										  ,A.SOURCEDATAKEY AS [SOURCEDATAKEY]
										  ,B.CURRENT_FLAG AS [CURRENT_FLAG]
										  ,REPLACE(B.SecondaryPlanClaimNumber, '^', '') AS SecondaryPlanClaimNumber
										  ,REPLACE(B.EffectiveEncounterFlag, '^', '') AS EffectiveEncounterFlag
										  ,REPLACE(B.OriginalPlanClaimID, '^', '') AS OriginalPlanClaimID
										  
									  FROM [DBO].[OUTB_CLAIM_STATUS] A										   
									  INNER JOIN  [DBO].[TEMP_STATFILELOAD] B
									  ON (B.I_FILEID=A.FILEID AND B.PLANCLAIMNUMBER=A.CLAIM_ID )
									  WHERE A.CLMSTAT_STATUS = 'R' 
									  
							END
						END
							
							ELSE
							IF(  (@HISTFILEID=@STATUSFILEID) AND (@STATCLIENTID LIKE '%HSPR%') AND @MISSINGSTATCLAIMNUMBER=1)
                               
						        BEGIN  
									 SELECT 3 AS RESULTSVALIDFILE
                                
								BEGIN
									 INSERT INTO MISSING_CLAIMS
										( 
										[CLAIM_ID],
										[FILEID],
										[MISSING_OCCURENCE_DATE]	  
										)

									SELECT DISTINCT B.PLANCLAIMNUMBER , B.I_FILEID, GETDATE()
									FROM TEMP_STATFILELOAD B  
									WHERE B.PLANCLAIMNUMBER <> '' EXCEPT 
																	(SELECT DISTINCT CLAIM_ID, FILEID, GETDATE()
																	FROM DBO.OUTB_CLAIM_STATUS )	
																								
									ORDER BY B.I_FILEID, B.PLANCLAIMNUMBER
								END
							END	
										
						
							ELSE
							
							IF	@ERRORSTATCLAIMNUMBER=1
							
								BEGIN 
										SELECT 0 AS RESULTSVALIDFILE
								END
															 						
							ELSE
								BEGIN
										SELECT 0 AS RESULTSVALIDFILE 
								END
							END	

-- 11/06/14 swaller
	IF (@MISMATCHCLAIMANDFILE = 'Y')
		BEGIN 
			INSERT INTO MISMATCH_CLAIMS
				([MISMATCH_OCCURENCE_DATE], [CLAIM_ID], [FILEID])
			SELECT	DISTINCT getdate() as MISMATCH_OCCURENCE_DATE, A.PLANCLAIMNUMBER , A.I_FILEID
			FROM	TEMP_STATFILELOAD A  
			LEFT OUTER JOIN DBO.OUTB_CLAIM_STATUS B
				ON	B.FILEID		= A.I_FILEID
				AND	B.CLAIM_ID		= A.PLANCLAIMNUMBER
			WHERE	NOT ((A.RECORDTYPE = '') OR (A.RECORDTYPE IS NULL))	-- count the non-header STAT records
			ORDER BY A.I_FILEID, A.PLANCLAIMNUMBER

			SELECT 4 AS RESULTSVALIDFILE
		END

-- TRUNCATE TEMP TABLES FOR NEXT LOAD TO EXCLUDE THE DUPLICATES 
				IF OBJECT_ID('DBO.TEMP_ACKFILELOAD') IS NOT NULL
				
						BEGIN
							TRUNCATE TABLE DBO.TEMP_ACKFILELOAD
						END
						
				--IF OBJECT_ID('DBO.TEMP_STATFILELOAD') IS NOT NULL
				
				--		BEGIN
				--			TRUNCATE TABLE DBO.TEMP_STATFILELOAD
				--		END
					
				--IF OBJECT_ID('DBO.TEMP_REJFILELOAD') IS NOT NULL
				
				--		BEGIN
				--			TRUNCATE TABLE DBO.TEMP_REJFILELOAD
				--		END








