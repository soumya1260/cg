﻿
CREATE PROCEDURE [dbo].[EXSP_CLAIM_RECON_MMAI]
AS /***************************************************************************************************
** CREATE DATE: 08/2014
**
** AURTHOR: LOYAL RICKS - LOYALRICKS@NTEGRITY.COM
**
** DESCRIPTION: PROCEDURE WILL POPULATE EXT_HRP_CLAIM_RECON  & EXT_EDPS_CLAIM_STATUS TABLE WITH CLAIM INVENTORY
**			    DATA FROM THE MONTHLY BIDW EXTRACT. THIS DATA WILL BE USED TO ASSIST MDQO WITH 
**				AUDITING AND TRACKING CLAIM INVENTORY SENT TO HRP FOR EDS CMS SUBMISSIONS.
**				THIS PROCEDURE WILL RUN DIRECTLY AFTER EACH BIDW EXTRACT. THE EXT_HRP_CLAIM_RECON
**				TABLE IS A HISTORICAL TABLE. DATA WILL ALWAYS GET APPENDED BY CLAIM DOS MONTH (YYYYMM)
Modification History
====================
Date			Who				Description
-----------------------------------------------------------------------------------------------------

1/02/13		LOYAL RICKS     HPLAN ADDED TO EXT_EDPS_CLAIM_STATUS. ADDED LOGIC FOR POPULATING THIS VALUE
1/25/13		Dwight Staggs	PAPER_IND was added to the table EXT_EDPS_CLAIM_STATUS
2/18/13		Loyal Ricks		Add Sourcedesc to "---APPEND INVENTORY INTO EXT_EDPS_CLAIM_STATUS"
2/18/13		Loyal Ricks		Add datasource 4 - Encounter to inventory updates
10/1/13		Dwight Staggs	Had to qualify occurances of BeginServiceDate as it is now in both 
							ClaimDim and ClaimDetailDim
12/31/31	Loyal Ricks		Add EXT_EDPS_CLAIM_STATUS.HRP_CLAIM_ID
02/20/14	Loyal Ricks		Add revision for EXT_EDPS_CLAIM_STATUS table definition revisions
07/03/14	Loyal Ricks		Add deletions of EXT_EDPS_CLAIM_STATUS table by: sourcedatakey, first char 
							of HPLAN and producttype. 
							Add attempt to identify HPLAN
-----------------------------------------------------------------------------------------------------
08/20/14	Loyal Ricks		WIPRO Implementation 
08/20/14	Loyal Ricks		Revision to support temporary import of export.dbo.MMAIClaimDetailDim
09/17/14	Loyal Ricks		Default HPLAN assignment. Use lineofbusinessdim logic once MMAI QNXT
							configuration of claimdetaildim is deployed to BIDW production.
09/24/14	Loyal Ricks		Removed deletion of non medicare claims. Non Medicare claims added to 
							exclusion history build. All categories wil use exclusion id 9020. Further
							breakdown of 9020 may be required if certain groups need to be isolated 
							for inventory purposes.
09/11/15	Loyal Ricks		Removed MMAI "Duct Tape" references to MMAIClaimDetaildim, replaced with 
							references to claimdim and lineofbusinessdim
							Add lineofbusinessdim ProductType BIDW revisions "Care-Caid" value eavluation
10/27/15	Loyal Ricks		Revisions to use claimdetaildim.producttype to determine production for entire
							Claim. Whether the claim is Medicare Only, Medicaid Only, Dual or Unknown.
							Incorporate use of the EXT_MMAI_CLAIM_PRODUCT and EXT_MMAI_CLAIM_PRODUCT_Archive
							tables. These tables will be used during MMAI outbound claim selection to 
							ensure only the appropriate claims (Medicare Only, Medicaid Only, Dual, Unknown)
							are selected for submission based on Job parameters. Currently EDS team only 
							submitting Care Only claims. 

05/25/2017	PGREENLEA		TETDM-1286 CORRECT UNKNOWN PRODUCT TYPES FOR MMAI
06/30/2017  John Bartholoma TETDM-1601  Correct logic for UNKNOWN product type for MMAI
07/06/2017	Scott Waller	TETDM-1605  Change WHERE clause in TETDM-1601 code change.
07/17/2017  Johnbartholomay TETDM-1604 ADD logic for the UKNOWN product type for Medicaid
09/21/2017  Johnbartholomay TETDM-1621 Add logic to flip Medicare-Medicaid,Dual to Medicare
*****************************************************************************************************/	
		
		

			
--DECLARE VARIABLES
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RECON WHERE ENTRYDT = @ENTRYDT
    DECLARE
        @TOTAL_RECORDS INT ,
        @ENTRYDT DATETIME
								
							--ASSIGN @ENTRYDT TO EXECUTION DATETIME

    SET @ENTRYDT = (GETDATE())
							--EXSP_HRP_CLAIM_RECON RUN CONTROLS
    INSERT  INTO EXT_SYS_RUNLOG
            (PROC_NAME ,
             STEP ,
             START_DT ,
             END_DT ,
             RUN_MINUTES ,
             TOTAL_RECORDS ,
             ENTRYDT
									
            )
    VALUES
            ('EXSP_CLAIM_RECON_MMAI' ,
             'BIDW EXTRACT' ,
             GETDATE() ,
             NULL ,
             NULL ,
             0 ,
             GETDATE()
            )

							--Archive previous month EXT_MMAI_CLAIM_PRODUCT data
								
    INSERT  INTO EXT_MMAI_CLAIM_PRODUCT_Archive
            SELECT
                * ,
                GETDATE()
            FROM
                EXT_MMAI_CLAIM_PRODUCT

							--truncate EXT_MMAI_CLAIM_PRODUCT

    TRUNCATE TABLE EXT_MMAI_CLAIM_PRODUCT

							--Temporary MMAI Claim LOB logic
							--Assign appropriate LOB Code for inbound MMAI claims
							--Valid lob codes are (Medicare, Medicaid, Dual, Unknown)

    IF OBJECT_ID('TEMPDB..#TMP_MMAI_CLM') <> 0 
        DROP TABLE #TMP_MMAI_CLM
									
    CREATE TABLE #TMP_MMAI_CLM
        (
         CLAIMID VARCHAR(20) ,
         SOURCEDATAKEY INT ,
         LOBCODE VARCHAR(15)
        )

    INSERT  INTO #TMP_MMAI_CLM
            SELECT
                claimid ,
                C.SOURCEDATAKEY ,
                C.LOBCODE
            FROM
                EDPS_DATA.DBO.CLAIMDIM C
                INNER JOIN MDQOLib.DBO.LineofBusinessDim L
                ON C.LOBCODE = L.LOBCODE
            WHERE
                L.ProductType = 'Care-Caid'

    INSERT  INTO EXT_MMAI_CLAIM_PRODUCT
            SELECT
                SOURCEDATAKEY ,
                CLAIMID ,
                ' ' ,
                LOBCODE ,
                GETDATE()
            FROM
                #TMP_MMAI_CLM


    IF OBJECT_ID('TEMPDB..#TMP_MMAI_CLMLOB') <> 0 
        DROP TABLE #TMP_MMAI_CLMLOB
									
    CREATE TABLE #TMP_MMAI_CLMLOB
        (
         CLAIMID VARCHAR(20) ,
         CLAIMPRODUCTTYPE VARCHAR(50) ,
								--LOBCODE VARCHAR(15),
								--converagecodeid varchar(15),
         SEQNO INT
        )
			
    INSERT  INTO #TMP_MMAI_CLMLOB
            SELECT DISTINCT
                cD.CLAIMID ,
                cd.PRODUCTTYPE ,
                ROW_NUMBER() OVER (PARTITION BY cD.ClaimID ORDER BY cd.PRODUCTTYPE, cD.CLAIMID)
            FROM
                EDPS_DATA.DBO.claimdetaildim cd
                INNER JOIN #TMP_MMAI_CLM C
                ON c.sourcedatakey = cd.sourcedatakey
                   AND c.claimid = cD.claimid
            GROUP BY
                cD.CLAIMID ,
                cd.PRODUCTTYPE--,c.LOBCODE 
            ORDER BY
                cD.CLAIMID ,
                cd.PRODUCTTYPE  
						
    ---Update EXT_MMAI_CLAIM_PRODUCT.EDS_MMAI_PRODUCT

    --Update EXT_EDPS_CLAIM_STATUS.PRODUCTTYPE FROM INBOUND MMAIClaimDetailDim
    --An individual claim may have 3 potential products (Medicare, Medicaid, Unknown)
    --Claims that have both a Medicare & Medicaid producttype are considered Dual eligible products
							 
    UPDATE
        EXT_MMAI_CLAIM_PRODUCT
    SET 
        EDS_MMAI_PRODUCT = RTRIM(CLAIMPRODUCTTYPE)
    FROM
        EXT_MMAI_CLAIM_PRODUCT EC
        INNER JOIN #TMP_MMAI_CLMLOB T
        ON EC.CLAIMID = T.CLAIMID
           AND T.SEQNO = 1
							
    UPDATE
        EXT_MMAI_CLAIM_PRODUCT
    SET 
        EDS_MMAI_PRODUCT = RTRIM(EDS_MMAI_PRODUCT) + '-'
        + RTRIM(CLAIMPRODUCTTYPE)
    FROM
        EXT_MMAI_CLAIM_PRODUCT EC
        INNER JOIN #TMP_MMAI_CLMLOB T
        ON EC.CLAIMID = T.CLAIMID
           AND T.SEQNO = 2

    UPDATE
        EXT_MMAI_CLAIM_PRODUCT
    SET 
        EDS_MMAI_PRODUCT = RTRIM(EDS_MMAI_PRODUCT) + '-'
        + RTRIM(CLAIMPRODUCTTYPE)
    FROM
        EXT_MMAI_CLAIM_PRODUCT EC
        INNER JOIN #TMP_MMAI_CLMLOB T
        ON EC.CLAIMID = T.CLAIMID
           AND T.SEQNO = 3
--tetdm-1621 begin
    --UPDATE
    --    EXT_MMAI_CLAIM_PRODUCT
    --SET 
    --    EDS_MMAI_PRODUCT = 'DUAL'
    --WHERE
    --    UPPER(EDS_MMAI_PRODUCT) IN ('MEDICARE-MEDICAID', 'MEDICAID-MEDICARE')

     UPDATE
        EXT_MMAI_CLAIM_PRODUCT
    SET 
        EDS_MMAI_PRODUCT = 'MEDICARE'
    WHERE
        UPPER(EDS_MMAI_PRODUCT) IN ('MEDICARE-MEDICAID', 'MEDICAID-MEDICARE')

    UPDATE
        EXT_MMAI_CLAIM_PRODUCT
    SET 
        EDS_MMAI_PRODUCT = 'MEDICARE'
    WHERE
        UPPER(EDS_MMAI_PRODUCT) IN ('MEDICAID-MEDICARE-UNKNOWN')

--tetdm-1621 end


    UPDATE
        EXT_EDPS_CLAIM_STATUS
    SET 
        PRODUCTTYPE = RTRIM(EDS_MMAI_PRODUCT)
    FROM
        EXT_EDPS_CLAIM_STATUS EC
        INNER JOIN EXT_MMAI_CLAIM_PRODUCT EM
        ON EM.SOURCEDATAKEY = EC.SOURCEDATAKEY
           AND EM.CLAIMID = EC.CLAIMID 

--1601 jab comment out code and add correct logic belof

    --UPDATE
    --    [WIPRO].[dbo].[EXT_MMAI_CLAIM_PRODUCT]
    --SET 
    --    [EDS_MMAI_PRODUCT] = 'MEDICARE'
    --WHERE
    --    [EDS_MMAI_PRODUCT] LIKE '%UNKNOWN%'

	UPDATE
        [WIPRO].[dbo].[EXT_MMAI_CLAIM_PRODUCT]
    SET 
        [EDS_MMAI_PRODUCT] = 'MEDICARE'
    WHERE
        LTRIM(RTRIM(UPPER([EDS_MMAI_PRODUCT]))) = 'MEDICARE-UNKNOWN'
 -- TETDM-1605 change LIKE to =
 --1601   end 

 --TETDM-1604 BEGIN
    UPDATE
        [WIPRO].[dbo].[EXT_MMAI_CLAIM_PRODUCT]
    SET 
        [EDS_MMAI_PRODUCT] = 'MEDICAID'
    WHERE
        LTRIM(RTRIM(UPPER([EDS_MMAI_PRODUCT]))) = 'MEDICAID-UNKNOWN'
 --TETDM 1604 END


				--ASSIGN @TOTAL_RECORDS - GET RECORD COUNT FROM EXT_HRP_CLAIM_RECON
								
    SET @TOTAL_RECORDS = (
                          SELECT
                            COUNT(*)
                          FROM
                            EXT_EDPS_CLAIM_STATUS
                         )
													
						----EXSP_HRP_CLAIM_RECON UPDATE RUN CONTROLS
								
    UPDATE
        EXT_SYS_RUNLOG
    SET 
        END_DT = GETDATE() ,
        RUN_MINUTES = DATEDIFF(MI, START_DT, GETDATE()) ,
        TOTAL_RECORDS = @TOTAL_RECORDS ,
        ENTRYDT = @ENTRYDT
    WHERE
        PROC_NAME = 'EXSP_CLAIM_RECON_MMAI'
        AND END_DT IS NULL
											

