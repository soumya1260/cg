﻿
 
CREATE	 PROCEDURE [dbo].[EXSP_WIPRO_999_Updates] 
AS 
 
/*************************************************************************************************** 
** CREATE DATE: 02/2016 
** 
** AUTHOR: LOYAL RICKS - Loyal Ricks 
** 
** DESCRIPTION: Procedure will update the OUTB_CLAIM_STATUS table from the  inbound WIPRO 999. 
**				these updates will be used to facilitate updates for EDS claim submissions as  
**				claims are processed from WIPRO to CMS 
**				 
** EXEC [dbo].[EXSP_WIPRO_999_Updates]

Modification History 
==================== 
Date			Who				Description 
08/03/2017		Subhash Acharya TETDM-1526
10/10/2017		Subhash Acharya   TETDM-1640 update logic for Claim Status
03/18/2018		Subhash Acharya   update only the latest record base don last update date
03/26/2018		Subhash Acharya   update claim_id that are already not in 'A-999','A-ICN','R-ICN','A-277','R-277'
----------------------------------------------------------------------------------------------------- 
*****************************************************************************************************/	 
--DECLARE VARIABLES 
--VARIABLES (@TOTAL_RECORDS = COUNT(*) FROM EXT_HRP_CLAIM_RESEND 
			DECLARE	@TOTAL_RECORDS INT 
		 
					INSERT INTO EXT_SYS_RUNLOG 
							(PROC_NAME 
							,STEP 
							,START_DT 
							,END_DT 
							,RUN_MINUTES 
							,TOTAL_RECORDS 
							,ENTRYDT 
							) 
					VALUES('EXSP_WIPRO_999_Updates' 
							,'1' 
							,GETDATE() 
							,NULL 
							,NULL 
							,0 
							,GETDATE() 
							) 
								if OBJECT_ID ('tempdb..#TMP_WIPRO_999') <> 0	 
								DROP TABLE #TMP_WIPRO_999 
 
								CREATE TABLE #TMP_WIPRO_999 
								(CLAIM_ID VARCHAR(20), 
								WIPRO_CLAIM_ID VARCHAR(20), 
								CLMSTAT_STATUS VARCHAR(50) 
								) 
 
								--Process Accepted 999 records 
								INSERT INTO #TMP_WIPRO_999 
								select DISTINCT  CLAIMID, 
											WIPRO_CLAIMID, 
											RECORDTYPE +''+'-999' 
								from WIPRO_999_ACCEPTED_DETAIL_DAILY  
 
								--Process Rejected 999 records 
								INSERT INTO #TMP_WIPRO_999 
								SELECT DISTINCT CLAIM_ID, 
												WIPRO_CLAIMID, 
												RECORDTYPE+''+'-999' 
								FROM WIPRO_999_REJECT_DETAIL_Daily 


INSERT INTO WIPRO.dbo.ClaimStatusNull
SELECT c.CLAIM_ID,C.SOURCEDATAKEY,C.FILEID,C.CLMSTAT_STATUS,C.LAST_UPD_DATE,GETDATE()
FROM OUTB_CLAIM_STATUS C
INNER JOIN  #TMP_WIPRO_999 W
ON C.CLAIM_ID = W.CLAIM_ID 
AND C.WIPRO_CLAIM_ID = W.WIPRO_CLAIM_ID
WHERE c.CLMSTAT_STATUS IS NULL

---Update OUTB_CLAIM_STATUS.CLMSTAT_STATUS FROM INBOUND 999 Where OUTB_CLAIM_STATUS = 'A' (WIPRO ACCEPTED) 
---to avoid updating the status of a claim that has made it beyond the 999 due to implementation timing  
---of WIPRO CMS Responses. The 999 is the first status update after WIPRO Accepted, logic will prevent  
---delayed 999 responses from overwriting 277, MAO002, MAO004 status that have already been applied. This  
---logic also needed to ensure EDS inventory always reflects latest CMS response status. 

--BEGIN TRAN
--SET ROWCOUNT 0 



UPDATE OUTB_CLAIM_STATUS  
SET CLMSTAT_STATUS --= W.CLMSTAT_STATUS 
= CASE WHEN ((c.CLMSTAT_STATUS IN ('A','R','R-999','MAO-004') OR c.CLMSTAT_STATUS IS NULL)
										AND W.CLMSTAT_STATUS = 'A-999')
			THEN 'A-999'
	 WHEN ((c.CLMSTAT_STATUS IN ('A','R','MAO-004') OR c.CLMSTAT_STATUS IS NULL)
										AND W.CLMSTAT_STATUS = 'R-999')
			THEN 'R-999'
			--ELSE 'No Change'
			ELSE c.CLMSTAT_STATUS
			END --AS UpdatedValue
		--SELECT C.CLMSTAT_STATUS,*
		--SELECT TOP 1000 C.CLMSTAT_STATUS,*
		,LAST_UPD_DATE = GETDATE()
		,STAT_REJ_REA_ID = NULL --CASE WHEN W.CLMSTAT_STATUS = 'A-999' THEN NULL ELSE STAT_REJ_REA_ID  END
		,REJ_REA_MSG = NULL --CASE WHEN W.CLMSTAT_STATUS = 'A-999' THEN NULL ELSE REJ_REA_MSG END
        ,FIELD_ERR = NULL
		,VAL_ERR = NULL
FROM OUTB_CLAIM_STATUS C 
INNER JOIN  #TMP_WIPRO_999 W 
ON C.CLAIM_ID = W.CLAIM_ID  
and w.WIPRO_CLAIM_ID = c.WIPRO_CLAIM_ID
--INNER JOIN 
--(
--SELECT CLAIM_ID,max(LAST_UPD_DATE) as LAST_UPD_DATE
--FROM OUTB_CLAIM_STATUS
--GROUP BY CLAIM_ID
--) Z ON C.CLAIM_ID = Z.CLAIM_ID AND C.LAST_UPD_DATE = Z.LAST_UPD_DATE
--AND C.WIPRO_CLAIM_ID = W.WIPRO_CLAIM_ID 
--where LEFT(C.CLMSTAT_STATUS,1) = 'A' 
Where C.CLAIM_ID not in 
(
select distinct claim_id 
from OUTB_CLAIM_STATUS
where CLMSTAT_STATUS in
	( 'A-999' 
	 ,'A-ICN' 
	 ,'R-ICN' 
	 ,'A-277' 
	 ,'R-277' ) 
)






--ROLLBACK TRAN
--COMMIT TRAN


						--ASSIGN @TOTAL_RECORDS - GET RECORD COUNTS For table being archived 
								SET @TOTAL_RECORDS = (SELECT COUNT(*) FROM #TMP_WIPRO_999) 
								 
																			 
							---- Update Run Controls  
									 
								UPDATE EXT_SYS_RUNLOG 
								SET END_DT = GETDATE()	 
									,RUN_MINUTES = DATEDIFF(MI,START_DT,GETDATE()) 
									,TOTAL_RECORDS = @TOTAL_RECORDS 
									,ENTRYDT = GETDATE() 
								WHERE PROC_NAME = 'EXSP_WIPRO_999_Updates' 
												and END_DT is null 
 


