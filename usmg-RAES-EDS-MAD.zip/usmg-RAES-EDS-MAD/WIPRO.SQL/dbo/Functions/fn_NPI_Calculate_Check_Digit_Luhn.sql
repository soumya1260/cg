﻿
CREATE FUNCTION [dbo].[fn_NPI_Calculate_Check_Digit_Luhn]
/*
Created by Anthony Ulmer
10/12/2020
-------------------------
This function will take an NPI and provide the check digit (which should match the last digit in the NPI)
	to make sure the NPI is a valid NPI number.

NULL is provided in the following scenarios
	- when the NPI does not match the length requirements (must be 10 digits)
	- when the NPI has non-numeric characters

This function uses the Luhn Algorithm used in the CMS NPI guide.

This function is based on light modifications of the concepts from the following:
	-https://dwaincsql.com/2014/03/27/tally-tables-in-t-sql/
	-https://www.red-gate.com/simple-talk/sql/t-sql-programming/calculating-and-verifying-check-digits-in-t-sql/
	-https://www.cms.gov/Regulations-and-Guidance/Administrative-Simplification/NationalProvIdentStand/Downloads/NPIcheckdigit.pdf
*/
(
    @StringToCheck VARCHAR(8000)
)
RETURNS TABLE WITH SCHEMABINDING
RETURN
	WITH Tally (n) AS
	(
		SELECT TOP (LEN(LEFT(@StringToCheck,9))) --exclude 10th check digit
			ROW_NUMBER() OVER (ORDER BY (SELECT NULL))
		FROM (VALUES (0),(0),(0),(0),(0),(0),(0),(0),(0)) a(n)
		WHERE 1 = 1
			AND LEN(@StringToCheck) = 10 AND ISNUMERIC(@StringToCheck) = 1
	)
	-- Luhn algorithm
	SELECT StringToCheck=@StringToCheck, CheckDigit=9*(SUM(SumOfDigits) + 24)%10
	FROM Tally a
	CROSS APPLY
	(		
		SELECT [Digit*Multiplier] = (1+n%2) * SUBSTRING(REVERSE(LEFT(TRY_CAST(@StringToCheck AS INT),9)), n, 1) WHERE ISNUMERIC(@StringToCheck) = 1
	) b
	CROSS APPLY
	(		
		SELECT SumOfDigits = [Digit*Multiplier]%10 + [Digit*Multiplier]/10
	) c
	WHERE ISNUMERIC(@StringToCheck) = 1;
