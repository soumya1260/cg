﻿
CREATE  FUNCTION [dbo].[fn_edi_parse] (@Temp varchar(255))
	
RETURNS varchar(255)
/*****************************************************************************   
**  Function	     :   fn_edi_parse
**  Date Written     :  02/2014   
**  Author           :  Loyal Ricks   
******************************************************************************   
** Description       :  function will parse invalid EDI characters from 
**					 :  text data elements
**					 :	Invalid characters:
**					 :	'`'
**					 :	';'
**					 :	'`;'
**					 : '~'
**					 : '*'
**					 : ':'
**					 : '^'
**					 : '"'
**					 : 2/27 revision, add '.' 
**					 : 06/24/14 add additional scrubs

TETDM-2054	Replacing our original Parsing with new version that Patricia Greenlea 
			came up with.
			Scott Waller 05/14/2019

*****************************************************************************/
AS
BEGIN
 
 
	    while PatIndex('%[`;~*:".|]%', @Temp) > 0
        Set @Temp = Stuff(@Temp, PatIndex('%[`;~*:".|]%', @Temp), 1, '')
 
	return rtrim((@Temp))
end	

