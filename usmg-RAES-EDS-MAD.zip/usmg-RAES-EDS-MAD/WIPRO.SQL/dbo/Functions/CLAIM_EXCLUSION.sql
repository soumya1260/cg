﻿


CREATE FUNCTION [dbo].[CLAIM_EXCLUSION]
	(@sourcedatekey			int     ,
	 @claimid				varchar(30) )     
RETURNS varchar(200)
AS
     
/***************************************************************************************************     
** CREATE DATE: 03/11/2019
**     
** AUTHOR: Scott Waller	for TETDM-1960
**     
** DESCRIPTION: This function will return a string listing all Exclusions that a claim belongs to
				or it will return 'NO EXCLUSIONS' if the claim belongs to no exclusions.

Here are the values it will return:
	HAS ICN#			Claim Status is A-ICN or MAO-004
	HAS ICN#			Claim Status is one of: A-ICN, MAO-004, A-999, A-277
	Accepted			Claim Status is 'A'
	Rejected			Claim Status is 'R'
	Submitted			Claim Status is NULL and the LAST_UPD_DATE is less than the # of Exclusion Days limit
	REJ999				Claim Status is R-999 and the LAST_UPD_DATE is less than the # of 999 Reject Exclusion Days limit
	REJ277				Claim Status is R-277 and the LAST_UPD_DATE is less than the # of 277 Reject Exclusion Days limit
	REJICN				Claim Status is R-ICN and the LAST_UPD_DATE is less than the # of MAO002 Reject Exclusion Days limit
	Exclusion IDs		A string of all the Exlcusion IDs the claim belongs to
	NO EXCLUSIONS		if the claim is not a part of any exclusions

Modification History     
====================     
Date			Who				Description     


*****************************************************************************************************/	     
BEGIN
	DECLARE     
			@EXCL_DAYS				INT     
			,@REJ_EXCL_DAYS			INT     
			,@REJ_999_EXCL_DAYS		INT  
			,@REJ_277_EXCL_DAYS		INT
			,@MAO002_Rej_Excl_days	INT
			,@EXCLUSION_STRING		VARCHAR(200)
			,@WORK_STRING			VARCHAR(200)
			,@CURSOR_STRING			VARCHAR(200);
			     
	SET @EXCL_DAYS = (SELECT CNTRL_VAL FROM EXT_SYS_CLM_JOBCNTRL     
									WHERE CNTRL_DESC = 'EXCLUSION DAYS'     
										and CNTRL_STATUS = 'A'     
										AND SOURCEDATAKEY = @sourcedatekey);     
	SET @REJ_EXCL_DAYS  = (SELECT CNTRL_VAL FROM EXT_SYS_CLM_JOBCNTRL      
									WHERE CNTRL_DESC = 'REJECTION EXCLUSION DAYS'     
										and CNTRL_STATUS = 'A'     
										AND SOURCEDATAKEY = @sourcedatekey);     
	SET @REJ_999_EXCL_DAYS  = (SELECT CNTRL_VAL FROM EXT_SYS_CLM_JOBCNTRL      
									WHERE CNTRL_DESC = '999 Rejection Exclusion Days'     
										and CNTRL_STATUS = 'A'     
										AND SOURCEDATAKEY = @sourcedatekey);     
	SET @REJ_277_EXCL_DAYS  = (SELECT CNTRL_VAL FROM EXT_SYS_CLM_JOBCNTRL      
									WHERE CNTRL_DESC = '277 Rejection Exclusion Days'     
										and CNTRL_STATUS = 'A'     
										AND SOURCEDATAKEY = @sourcedatekey);     
     			
	SET @MAO002_Rej_Excl_days  = (	SELECT 
										CNTRL_VAL 
									FROM EXT_SYS_CLM_JOBCNTRL      
									WHERE CNTRL_DESC = 'MAO002 Rejection Exclusion days'     
										and CNTRL_STATUS = 'A'     
										AND SOURCEDATAKEY = @sourcedatekey);     

	SET		@EXCLUSION_STRING	= '';
     
	--Exclusion #1 - CLAIMS WITH CMS ICN NUMBERS     
	SET		@WORK_STRING		= '';	
									     
	SELECT	@WORK_STRING		= 'HAS ICN #, '
	from	OUTB_CLAIM_STATUS     
	where	SOURCEDATAKEY		= @sourcedatekey     
	AND		CLAIM_ID			= @claimid
	AND		len(CMS_ICN) > 0     
	AND		CLMSTAT_STATUS IN ('A-ICN','MAO-004')     

	SET		@EXCLUSION_STRING = @EXCLUSION_STRING + @WORK_STRING
	--

	SET		@WORK_STRING		= '';	

	SELECT	@WORK_STRING		= 'HAS ICN #, '
	from	OUTB_CLAIM_STATUS     
	where	SOURCEDATAKEY		= @sourcedatekey     
	AND		CLAIM_ID			= @claimid
	AND		CLMSTAT_STATUS IN ('A-ICN','MAO-004','A-999','A-277')     

	SET		@EXCLUSION_STRING = @EXCLUSION_STRING + @WORK_STRING
	--
																     
	--Exclusion #2 -  HRP Accpeted Claims     
   	SET		@WORK_STRING		= '';	 

	SELECT	@WORK_STRING		= 'Accepted, '
	from	VW_CLAIM_STATUS EC     
			,OUTB_CLAIM_STATUS CS     
	where	EC.SOURCEDATAKEY	= @sourcedatekey     
	AND		EC.CLAIM_ID			= @claimid 
	AND		EC.sourcedatakey	= CS.SOURCEDATAKEY
	AND		EC.CLAIM_ID			= CS.CLAIM_ID     
	AND		EC.FILEID			= CS.FILEID      
	AND		CS.CLMSTAT_STATUS	= 'A'     
										     
	SET		@EXCLUSION_STRING = @EXCLUSION_STRING + @WORK_STRING
	--

	--Exclusion #3 -  HRP Rejected Claims     
	--Exclude all rejects that have been reported in the last @REJ_EXCL_DAYS     
	SET		@WORK_STRING			= '';	 

	SELECT	@WORK_STRING		= 'Rejected, '									
	FROM	VW_CLAIM_STATUS EC     
			,OUTB_CLAIM_STATUS CS     
	where	EC.sourcedatakey	= @sourcedatekey
	AND		EC.CLAIM_ID			= @claimid
	AND		EC.sourcedatakey	= CS.SOURCEDATAKEY
	AND		EC.CLAIM_ID			= CS.CLAIM_ID     
	AND		EC.FILEID			= CS.FILEID      
	AND		CS.CLMSTAT_STATUS	= 'R'     
	AND		DATEDIFF(D,CS.LAST_UPD_DATE,GETDATE()) <  @REJ_EXCL_DAYS     

	SET		@EXCLUSION_STRING = @EXCLUSION_STRING + @WORK_STRING
	--

	--Exclusion #4 -  HRP Recently Submitted Claims     
	SET		@WORK_STRING			= '';	 

	SELECT	@WORK_STRING		= 'Submitted, '									
	FROM	VW_CLAIM_STATUS EC     
			,OUTB_CLAIM_STATUS CS     
	where	EC.sourcedatakey	= @sourcedatekey
	AND		EC.CLAIM_ID			= @claimid
	AND		EC.sourcedatakey	= CS.SOURCEDATAKEY
	AND		EC.CLAIM_ID			= CS.CLAIM_ID     
	AND		EC.FILEID			= CS.FILEID      
	AND		CS.CLMSTAT_STATUS	is null     
	AND  DATEDIFF(D,CS.LAST_UPD_DATE,GETDATE()) < @EXCL_DAYS     

	SET		@EXCLUSION_STRING = @EXCLUSION_STRING + @WORK_STRING
	--
    
	-- Exclusion #5 - Rejected 999 claims      
	SET		@WORK_STRING			= '';	 

	SELECT	@WORK_STRING		= 'REJ999, '	     
	FROM	VW_CLAIM_STATUS EC     
			,OUTB_CLAIM_STATUS CS     
	where	EC.sourcedatakey	= @sourcedatekey
	AND		EC.CLAIM_ID			= @claimid
	AND		EC.sourcedatakey	= CS.SOURCEDATAKEY
	AND		EC.CLAIM_ID			= CS.CLAIM_ID     
	AND		EC.FILEID			= CS.FILEID      
	AND		CS.CLMSTAT_STATUS	= 'R-999'     
	AND		DATEDIFF(D,CS.LAST_UPD_DATE,GETDATE()) <  @REJ_999_EXCL_DAYS     
     
	SET		@EXCLUSION_STRING = @EXCLUSION_STRING + @WORK_STRING
	--

	-- Exclusion #6 - Rejected 999 claims      
	SET		@WORK_STRING			= '';	 

	SELECT	@WORK_STRING		= 'REJ277, '	     
	FROM	VW_CLAIM_STATUS EC     
			,OUTB_CLAIM_STATUS CS     
	where	EC.sourcedatakey	= @sourcedatekey
	AND		EC.CLAIM_ID			= @claimid
	AND		EC.sourcedatakey	= cs.SOURCEDATAKEY
	AND		EC.CLAIM_ID			= CS.CLAIM_ID     
	AND		EC.FILEID			= CS.FILEID      
	AND		CS.CLMSTAT_STATUS	= 'R-277'     
	AND		DATEDIFF(D,CS.LAST_UPD_DATE,GETDATE()) <  @REJ_277_EXCL_DAYS     

	SET		@EXCLUSION_STRING = @EXCLUSION_STRING + @WORK_STRING
	--

	-- Exclusion 7 regular Reject
	SET		@WORK_STRING			= '';	 

	SELECT	@WORK_STRING		= 'REJICN, '	     
	FROM	VW_CLAIM_STATUS EC     
			,OUTB_CLAIM_STATUS CS     
	where	EC.sourcedatakey	= @sourcedatekey
	AND		EC.CLAIM_ID			= @claimid
	AND		EC.sourcedatakey	= CS.SOURCEDATAKEY
	AND		EC.CLAIM_ID			= CS.CLAIM_ID     
	AND		EC.FILEID			= CS.FILEID      
	AND		CS.CLMSTAT_STATUS	= 'R-ICN'     
	AND		DATEDIFF(D,CS.LAST_UPD_DATE,GETDATE()) <  @MAO002_Rej_Excl_days  

	SET		@EXCLUSION_STRING = @EXCLUSION_STRING + @WORK_STRING


-- get the predefined Exclusion IDs

	SET		@WORK_STRING			= '';
	SET		@CURSOR_STRING			= '';

	DECLARE db_cursor CURSOR FOR
		SELECT	DISTINCT EXCL_ID
		FROM	EXT_CLAIM_EXCLUSION_HIST
		WHERE	SOURCEDATAKEY	= @sourcedatekey
		AND		claim_id		= @claimid
		ORDER BY EXCL_ID

	OPEN db_cursor
	
	FETCH NEXT FROM db_CURSOR INTO @CURSOR_STRING

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @WORK_STRING = @WORK_STRING + RTRIM(@CURSOR_STRING) + ' '

		FETCH NEXT FROM db_cursor INTO @CURSOR_STRING
	END

	CLOSE		db_cursor  
	DEALLOCATE	db_cursor 

	SET		@EXCLUSION_STRING = @EXCLUSION_STRING + @WORK_STRING

------ Return the value
	SET		@EXCLUSION_STRING = ISNULL(@EXCLUSION_STRING, 'NO EXCLUSIONS')
	IF	@EXCLUSION_STRING = ''
		SET @EXCLUSION_STRING = 'NO EXCLUSIONS'

	RETURN	@EXCLUSION_STRING									     
END     

