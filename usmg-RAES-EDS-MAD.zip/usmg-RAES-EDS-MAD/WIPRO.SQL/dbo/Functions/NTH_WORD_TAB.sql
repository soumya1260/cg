﻿CREATE FUNCTION [dbo].[NTH_WORD_TAB]
(@str VARCHAR(8000), @occurrence INT)
 RETURNS varchar(255)
 AS
 BEGIN

 /*
IF EXISTS (
    SELECT * FROM sysobjects WHERE id = object_id(N'NTH_WORD_TAB') 
    AND xtype IN (N'FN', N'IF', N'TF')
)
    DROP FUNCTION NTH_WORD_TAB


	*/


 -- Declare variables and place-holders
 DECLARE @found INT = @occurrence,
 @word VARCHAR(8000),
 @text VARCHAR(100),
 @end int;
  --@substr VARCHAR(255) = ' ',
 -- Start an infinite loop that will only end when the Nth word is found
 WHILE 1=1
 BEGIN
 IF @found = 1
 BEGIN
 SET @end = CHARINDEX(CHAR(9) , @str)
 IF @end IS NULL or @end = 0
 BEGIN
 SET @end = LEN(@str)
 END
 SET @text = LEFT(@str,@end)
 BREAK
 END;
 -- If the selected word is beyond the number of words, NULL is returned
 IF CHARINDEX(CHAR(9), @str) IS NULL or CHARINDEX(CHAR(9), @str) = 0
 BEGIN
 SET @text = NULL;
 BREAK;
 END

 -- Each iteration of the loop will remove the first word fromt the left
 SET @str = RTRIM(LTRIM(RIGHT(@str, LEN(@str)-CHARINDEX(CHAR(9), @str))));
 SET @found = @found - 1
 END

 RETURN REPLACE(@text, CHAR(9) , '');
 END

