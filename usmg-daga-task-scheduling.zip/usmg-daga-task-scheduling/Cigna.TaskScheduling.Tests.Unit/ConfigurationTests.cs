﻿using Cigna.TaskScheduling.Configuration;
using NUnit.Framework;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace Cigna.TaskScheduling.Tests.Unit
{
    [TestFixture, ExcludeFromCodeCoverage]
    public class ConfigurationTests
    {
        private SchedulerConfiguration _schedulerConfiguration;

        [SetUp]
        public void Setup()
        {
            _schedulerConfiguration = ConfigurationManager.GetSection("Cigna.TaskScheduling") as SchedulerConfiguration;
        }

        #region Non-calendar tests

        [TestCase("DummyTask", "true")]
        [TestCase("DummyTaskTwo", "false")]
        public void TasksIndexer_ReturnsExpectedEnabled(string taskName, string enabled)
        {
            Configuration.Appointment task = _schedulerConfiguration.Appointments[taskName];
            Assert.That(task.Enabled == bool.Parse(enabled));
        }

        [TestCase("DummyTask", "HS.BUM.Services.dll")]
        [TestCase("DummyTaskTwo", "HS.ProviderPortal.Services.dll")]
        public void TasksIndexer_ReturnsExpectedAssemblyName(string taskName, string assemblyName)
        {
            Configuration.Appointment task = _schedulerConfiguration.Appointments[taskName];
            Assert.That(task.AssemblyName == assemblyName);
        }

        [TestCase("DummyTask", "HS.BUM.Services.DummyTask")]
        [TestCase("DummyTaskTwo", "HS.ProviderPortal.Services.DummyTaskTwo")]
        public void TasksIndexer_ReturnsExpectedClassName(string taskName, string className)
        {
            Configuration.Appointment task = _schedulerConfiguration.Appointments[taskName];
            Assert.That(task.ClassName == className);
        }

        [TestCase("DummyTask", "6:00 AM")]
        [TestCase("DummyTaskTwo", "7:00 aM")]
        public void TasksIndexer_ReturnsExpectedStartTime(string taskName, string startTime)
        {
            Configuration.Appointment task = _schedulerConfiguration.Appointments[taskName];
            Assert.That(task.StartTime == startTime);
        }

        [TestCase("DummyTask", "8:00 PM")]
        [TestCase("DummyTaskTwo", "7:30 am")]
        public void TasksIndexer_ReturnsExpectedStopTime(string taskName, string stopTime)
        {
            Configuration.Appointment task = _schedulerConfiguration.Appointments[taskName];
            Assert.That(task.StopTime == stopTime);
        }

        [TestCase("DummyTask", 5)]
        [TestCase("DummyTaskTwo", 1440)]
        public void TasksIndexer_ReturnsExpectedRunInterval(string taskName, int expectedRunInterval)
        {
            Configuration.Appointment task = _schedulerConfiguration.Appointments[taskName];
            Assert.That(task.RunIntervalInMinutes == expectedRunInterval);
        }

        [TestCase("DummyTask", "All")]
        [TestCase("DummyTaskTwo", "tue")]
        public void TasksIndexer_ReturnsExpectedActiveDays(string taskName, string expectedActiveDays)
        {
            Configuration.Appointment task = _schedulerConfiguration.Appointments[taskName];
            Assert.That(task.ActiveWeekDays, Is.EqualTo(expectedActiveDays));
        }

        [TestCase("DummyTask", "true")]
        [TestCase("DummyTaskTwo", "false")]
        public void TasksIndexer_ReturnsExpectedRunEveryDay(string taskName, string runEveryDay)
        {
            Configuration.Appointment task = _schedulerConfiguration.Appointments[taskName];
            Assert.That(task.RunEveryWeekDay == bool.Parse(runEveryDay));
        }

        [TestCase("Disabled task", Domain.AppointmentType.Scheduled)]
        [TestCase("Ad hoc task", Domain.AppointmentType.AdHoc)]
        public void TasksIndexer_ReturnsCorrectTypeValueForExplicitAndDefaultedTasks(
            string taskName,
            Domain.AppointmentType type)
        {
            Configuration.Appointment task = _schedulerConfiguration.Appointments[taskName];
            Assert.That(task.TaskType, Is.EqualTo(type));
        }

        #endregion

        #region Calendar tests



        #endregion Calendar tests

        #region Incompatible Tasks tests

        [Test]
        public void IncompatibleTasksIndexer_ReturnsExpectedNumberOfGroups()
        {
            IncompatibleTasksGroupCollection groups = _schedulerConfiguration.IncompatibleTasksGroups;
            Assert.That(groups.Count, Is.EqualTo(2));
        }

        [TestCase("DoNotPlayWell")]
        [TestCase("DoNotPlayWell2")]
        public void IncompatibleTasksIndexer_ReturnsRequestedGroup(string groupName)
        {
            var group = _schedulerConfiguration.IncompatibleTasksGroups[groupName];
            Assert.That(group, Is.Not.Null);
            Assert.That(group.Name, Is.EqualTo(groupName));
        }

        [TestCase("DoNotPlayWell", 2)]
        [TestCase("DoNotPlayWell2", 2)]
        public void IncompatibleTasksIndexer_ReturnsCorrectNumberOfTasksForGroup(string groupName, int numberOfTasks)
        {
            var group = _schedulerConfiguration.IncompatibleTasksGroups[groupName];
            Assert.That(group.Tasks.Count, Is.EqualTo(numberOfTasks));
        }

        [TestCase("DoNotPlayWell", "DummyTask")]
        [TestCase("DoNotPlayWell", "DummyTaskTwo")]
        [TestCase("DoNotPlayWell2", "Ad hoc task")]
        [TestCase("DoNotPlayWell2", "Disabled task")]
        public void IncompatibleTasksIndexer_ReturnsExpectedTasksForGroup(string groupName, string expectedTaskName)
        {
            IncompatibleTasksCollection tasks = _schedulerConfiguration.IncompatibleTasksGroups[groupName].Tasks;
            Assert.That(tasks, Is.Not.Null);
            foreach (IncompatibleTask task in tasks)
            {
                if (task.Name.Equals(expectedTaskName))
                {
                    Assert.True(true);
                    return;
                }
            }
            Assert.True(false);
        }

        #endregion  Incompatible Tasks tests
    }
}