﻿using Cigna.TaskScheduling.Configuration;
using Cigna.TaskScheduling.Exceptions;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using Cigna.TaskScheduling.Domain;

namespace Cigna.TaskScheduling.Tests.Unit
{
    [TestFixture, ExcludeFromCodeCoverage, Category("Unit")]
    public class SchedulerTests
    {
        [Test]
        public void CreateTask_SetsRunEveryDayCorrectlyForAll()
        {
            var schedulerConfiguration = ConfigurationManager.GetSection("Cigna.TaskScheduling") as SchedulerConfiguration;
            Configuration.Appointment configTask = schedulerConfiguration?.Appointments["DummyTask"];
            var appointment = Scheduler.CreateAppointment(configTask, new object() as Domain.Task);
            Assert.That(appointment.RunEveryWeekday, Is.EqualTo(true));
        }

        #region DetermineNextStartTime() tests.  (Non-calendar)

        [TestCase("30-NOV-2017 12:37 PM", "30-NOV-2017 12:37 PM", true)]   // start = current time
        [TestCase("30-NOV-2017 12:37 PM", "30-NOV-2017 12:47 PM", false)]  // start = current time + 10 minutes
        [TestCase("30-NOV-2017 04:31 AM", "30-NOV-2017 06:00 AM", true)]   // start = daily start
        [TestCase("30-NOV-2017 04:31 AM", "30-NOV-2017 06:00 AM", false)]  // start = daily start
        [TestCase("30-NOV-2017 11:00 PM", "01-DEC-2017 06:00 AM", true)]   // start = daily start on next day
        [TestCase("30-NOV-2017 11:00 PM", "01-DEC-2017 06:00 AM", false)]  // start = daily start on next day
        [TestCase("30-NOV-2017 07:55 PM", "01-DEC-2017 06:00 AM", false)]  // start = daily start on next day because interval spills over stop time.
        [TestCase("30-NOV-2017 05:55 AM", "30-NOV-2017 06:00 AM", false)]  // start = daily start without interval causing delay
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForTaskWhenStartIsEarlierThanEnd(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                StartTime = "6:00 AM",
                StopTime = "8:00 PM",
                RunIntervalInMinutes = 10,
                RunEveryWeekday = true,
                ActiveWeekDays = new List<string> { "all" }
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [TestCase("30-NOV-2017 11:37 PM", "30-NOV-2017 11:37 PM", true)]   // start = current time
        [TestCase("30-NOV-2017 11:37 PM", "30-NOV-2017 11:47 PM", false)]  // start = current time + 10 minutes
        [TestCase("30-NOV-2017 01:37 AM", "30-NOV-2017 01:37 AM", true)]   // start = current time
        [TestCase("30-NOV-2017 01:37 AM", "30-NOV-2017 01:47 AM", false)]  // start = current time + 10 minutes
        [TestCase("30-NOV-2017 12:37 PM", "30-NOV-2017 08:00 PM", true)]   // start = daily start time
        [TestCase("30-NOV-2017 12:37 PM", "30-NOV-2017 08:00 PM", false)]  // start = daily start time
        [TestCase("30-NOV-2017 05:57 AM", "30-NOV-2017 08:00 PM", false)]  // start = daily start time because interval spills over end time
        [TestCase("30-NOV-2017 07:57 PM", "30-NOV-2017 08:00 PM", false)]
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForTaskWhenStartIsLaterThanEnd(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            //
            // This tests tasks that have an active window that crosses midnight.
            //
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                StartTime = "8:00 PM",
                StopTime = "6:00 AM",
                RunIntervalInMinutes = 10,
                RunEveryWeekday = true,
                ActiveWeekDays = new List<string> { "all" }
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [TestCase("12-DEC-2017 4:24 PM", "13-DEC-2017 8:00 PM", false)]  // Tuesday, expect Wednesday
        [TestCase("13-DEC-2017 4:24 PM", "13-DEC-2017 8:00 PM", false)]  // Wednesday, expect later in day
        [TestCase("13-DEC-2017 8:45 PM", "13-DEC-2017 8:55 PM", false)]  // Wednesday, within time frame
        [TestCase("14-DEC-2017 1:27 AM", "14-DEC-2017 1:37 AM", false)]  // Thursday, but within time frame
        [TestCase("14-DEC-2017 6:01 AM", "20-DEC-2017 8:00 PM", false)]  // Just outside of the window... got to next Wed
        [TestCase("13-DEC-2017 7:58 PM", "13-DEC-2017 8:00 PM", false)]  // Ensure that the interval doesn't cause a delayed start
        [TestCase("14-DEC-2017 6:00 AM", "20-DEC-2017 8:00 PM", false)]  // End of window is a hard boundary... go to next Wed
        public void DetermineNextStartTime_SetsExpectedScheduleTimeWhenActiveDaysAreRestricted(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            //
            // This tests appointments that have an active window that crosses midnight.
            //
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                StartTime = "8:00 PM",
                StopTime = "6:00 AM",
                RunIntervalInMinutes = 10,
                RunEveryWeekday = false,
                ActiveWeekDays = new List<string> { "wed" }
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [Test]
        public void DetermineNextStartTime_WorksWithWhiteSpaceAfterCommaInActiveDaysList()
        {
            var schedulerConfiguration = ConfigurationManager.GetSection("Cigna.TaskScheduling") as SchedulerConfiguration;
            Configuration.Appointment configTask = schedulerConfiguration?.Appointments["DummyTaskThree"];
            var appointment = Scheduler.CreateAppointment(configTask, new object() as Domain.Task);
            DateTime currentTimeString = DateTime.Parse("13-DEC-2017 7:05 am");
            DateTime result = Scheduler.DetermineNextStartTime(appointment, currentTimeString, true);
            Assert.That(result, Is.EqualTo(currentTimeString));
        }

        #endregion DetermineNextStartTime() tests.  (Non-calendar)

        #region DetermineNextStartTime() tests.  (Calendar)

        [TestCase("12-DEC-2017 4:24 PM", "01-NOV-2018 8:00 PM", false)]
        [TestCase("01-NOV-2018 4:24 PM", "01-NOV-2018 8:00 PM", false)]
        [TestCase("30-NOV-2018 4:24 PM", "30-NOV-2018 8:00 PM", false)]
        [TestCase("30-NOV-2018 9:24 PM", "01-NOV-2019 8:00 PM", false)]
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForMonthsAttribute(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                ActiveMonths = new List<string> { "Nov" },
                RunEveryMonth = false,
                StartTime = "8:00 PM",
                StopTime = "9:00 PM",
                RunIntervalInMinutes = 10,
                RunEveryWeekday = true
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [TestCase("12-DEC-2017 4:24 PM", "01-MAY-2018 8:00 PM", false)]
        [TestCase("01-NOV-2018 4:24 PM", "01-NOV-2018 8:00 PM", false)]
        [TestCase("05-NOV-2018 4:24 PM", "05-NOV-2018 8:00 PM", false)]
        [TestCase("30-NOV-2022 9:24 PM", "01-MAY-2023 8:00 PM", false)]
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForMultipleMonthsAttribute(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                ActiveMonths = new List<string> { "May", "Nov" },
                RunEveryMonth = false,
                StartTime = "8:00 PM",
                StopTime = "9:00 PM",
                RunIntervalInMinutes = 10,
                RunEveryWeekday = true
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [TestCase("12-DEC-2017 4:24 PM", "15-DEC-2017 8:00 PM", false)]
        [TestCase("15-NOV-2018 4:24 PM", "15-NOV-2018 8:00 PM", false)]
        [TestCase("16-NOV-2018 4:24 PM", "15-DEC-2018 8:00 PM", false)]
        [TestCase("15-DEC-2018 9:24 PM", "15-JAN-2019 8:00 PM", false)]
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForSingleDaysAttribute(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                ActiveMonths = new List<string> { "All" },
                ActiveDaysOfTheMonth = new List<int> { 15 },
                StartTime = "8:00 PM",
                StopTime = "9:00 PM",
                RunIntervalInMinutes = 10
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [TestCase("12-DEC-2017 4:24 PM", "15-DEC-2017 8:00 PM", false)]
        [TestCase("15-NOV-2018 4:24 PM", "15-NOV-2018 8:00 PM", false)]
        [TestCase("16-NOV-2018 4:24 PM", "01-DEC-2018 8:00 PM", false)]
        [TestCase("15-DEC-2018 9:24 PM", "01-JAN-2019 8:00 PM", false)]
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForMultipleDaysAttribute(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                ActiveMonths = new List<string> { "All" },
                ActiveDaysOfTheMonth = new List<int> { 1, 15 },
                StartTime = "8:00 PM",
                StopTime = "9:00 PM",
                RunIntervalInMinutes = 10
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [TestCase("2021-JAN-01 12:34:56 PM", "2023-FEB-01 08:00 PM", false)]
        [TestCase("2023-FEB-01 10:34:56 PM", "2023-FEB-02 08:00 PM", false)]
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForInitialRunAttribute(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                InitialRun = DateTime.Parse("2023-FEB-01"),
                ActiveMonths = new List<string> { "All" },
                StartTime = "8:00 PM",
                StopTime = "9:00 PM",
                RunIntervalInMinutes = 10
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [TestCase("2023-JAN-01 12:34:56 AM", "2023-JAN-01 6:00 AM", false)]
        [TestCase("2024-JAN-01 12:34:56 AM", "9999-DEC-31", false)]
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForFinalRunAttribute(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                FinalRun = DateTime.Parse("31-DEC-2023"),
                StartTime = "6:00 AM",
                StopTime = "8:00 PM",
                RunIntervalInMinutes = 10
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.GreaterThanOrEqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [TestCase("2021-01-01 12:34:56", "2021-11-25 20:00:00", false)]
        [TestCase("2023-02-01 12:34:56", "2023-11-23 20:00:00", false)]
        [TestCase("2024-02-01 12:34:56", "2024-11-28 20:00:00", false)]
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForThanksGiving(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                WeekdayOrdinal = "Fourth",
                ActiveWeekDays = new List<string> { "Thu" },
                ActiveMonths = new List<string> { "Nov" },
                StartTime = "8:00 PM",
                StopTime = "9:00 PM",
                RunIntervalInMinutes = 10
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [TestCase("2021-01-01 12:34:56", "2021-01-31 20:00:00", false)]
        [TestCase("2023-09-01 12:34:56", "2023-09-30 20:00:00", false)]
        [TestCase("2023-02-01 12:34:56", "2023-02-28 20:00:00", false)]
        [TestCase("2024-02-01 12:34:56", "2024-02-29 20:00:00", false)]
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForLastDayOfTheMonth(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                ActiveMonths = new List<string> { "All" },
                ActiveDaysOfTheMonth = new List<int> {0}, // Zero is the placeholder for last day
                StartTime = "8:00 PM",
                StopTime = "9:00 PM",
                RunIntervalInMinutes = 10
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        [TestCase("2021-01-01 12:34:56", "2021-01-28 20:00:00", false)]
        [TestCase("2023-09-01 12:34:56", "2023-09-28 20:00:00", false)]
        [TestCase("2023-02-01 12:34:56", "2023-02-23 20:00:00", false)]
        [TestCase("2024-02-01 12:34:56", "2024-02-29 20:00:00", false)]
        public void DetermineNextStartTime_SetsExpectedScheduleTimeForLastThursdayOfTheMonth(
            string currentTimeString,
            string expectedScheduleTimeString,
            bool ignoreInterval)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                WeekdayOrdinal = "Last",
                ActiveWeekDays = new List<string> { "Thu" },
                ActiveMonths = new List<string> { "All" },
                StartTime = "8:00 PM",
                StopTime = "9:00 PM",
                RunIntervalInMinutes = 10
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            DateTime scheduledTime = Scheduler.DetermineNextStartTime(appointment, currentTime, ignoreInterval);

            Assert.That(scheduledTime, Is.EqualTo(DateTime.Parse(expectedScheduleTimeString)));
        }

        #endregion DetermineNextStartTime() tests.  (Calendar)

        #region Incompatible Tasks tests

        [Test]
        public void RequeueTaskIfOutsideOfExecutionWindow_DoesNotRequeueAdHocRequestForScheduledTaskIfOutsideOfNormalScheduleWindow()
        {
            var appointment = new Appointment
            {
                Name = "ScheduledTaskWithSmallWindow",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                StartTime = DateTime.Now.AddHours(-2).ToShortTimeString(),
                StopTime = DateTime.Now.AddHours(-1).ToShortTimeString(),
                RunIntervalInMinutes = 10,
                RunEveryWeekday = true,
                ActiveWeekDays = new List<string> { "all" },
                AppointmentType = AppointmentType.Scheduled,
                ExecutionRequestType = AppointmentType.AdHoc
            };
            appointment.Validate();

            var scheduler = new Scheduler();
            scheduler.Appointments.Add(appointment);

            var queue = new Queue<string>();
            queue.Enqueue(appointment.Name);
            queue.Enqueue("some other task");
            queue.Enqueue("yet another silly task");

            int expectedCount = queue.Count;

            scheduler.RequeueTaskIfOutsideOfExecutionWindow(queue);

            //
            // Make sure the task is still at the front of the queue.
            //
            Assert.That(queue.Count, Is.EqualTo(expectedCount));
            Assert.That(queue.Peek(), Is.EqualTo(appointment.Name));
        }
        
        [TestCase("2021-09-10 4:00 PM", true)]
        [TestCase("2021-09-10 9:00 PM", false)]
        public void TaskExecutionWindowIsOpen_ReturnsExpectedResultWithWindowThatDoesNotCrossMidnight(string currentTimeString, bool expectedResult)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                StartTime = "6:00 AM",
                StopTime = "8:00 PM",
                RunIntervalInMinutes = 10,
                RunEveryWeekday = true,
                ActiveWeekDays = new List<string> { "all" }
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            bool result = Scheduler.AppointmentExecutionWindowIsOpen(appointment, currentTime);

            Assert.That(result, Is.EqualTo(expectedResult));
        }

        [TestCase("2021-09-10 4:00 PM", false)]
        [TestCase("2021-09-10 9:00 PM", true)]
        public void TaskExecutionWindowIsOpen_ReturnsExpectedResultWithWindowThatCrossesMidnight(string currentTimeString, bool expectedResult)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                StartTime = "6:00 PM",
                StopTime = "8:00 AM",
                RunIntervalInMinutes = 10,
                ActiveWeekDays = new List<string> { "all" }
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            bool result = Scheduler.AppointmentExecutionWindowIsOpen(appointment, currentTime);

            Assert.That(result, Is.EqualTo(expectedResult));
        }

        [TestCase("10-SEP-2021 4:00 PM", false)] // Friday
        [TestCase("10-SEP-2021 9:00 PM", true)]  // Friday
        [TestCase("11-SEP-2021 6:00 AM", true)]  // Saturday
        [TestCase("11-SEP-2021 8:01 AM", false)]  // Saturday
        public void TaskExecutionWindowIsOpen_ReturnsExpectedResultWithWindowThatCrossesMidnightWithFridaySchedule(string currentTimeString, bool expectedResult)
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ConfigurationTests",
                StartTime = "6:00 PM",
                StopTime = "8:00 AM",
                RunIntervalInMinutes = 10,
                ActiveWeekDays = new List<string> { "fri" }
            };
            appointment.Validate();

            DateTime currentTime = DateTime.Parse(currentTimeString);
            bool result = Scheduler.AppointmentExecutionWindowIsOpen(appointment, currentTime);

            Assert.That(result, Is.EqualTo(expectedResult));
        }

        [TestCase(1, false)]
        [TestCase(5, true)]
        public void ExecuteSchedule_LogsErrorWhenTimeGapHasBeenExceeded(int secondsBetweenMethodCalls, bool expectedResult)
        {
            var scheduler = new Scheduler();
            scheduler.ExecuteSchedule(new object(), EventArgs.Empty as ElapsedEventArgs);
            Thread.Sleep(secondsBetweenMethodCalls * 1000);
            scheduler.ExecuteSchedule(new object(), EventArgs.Empty as ElapsedEventArgs);

            Assert.That(scheduler.TimeIntervalErrorTriggered, Is.EqualTo(expectedResult));
        }

        private Scheduler _scheduler;

        [Test]
        public void ExecuteSchedule_DoesNotAllowMultipleThreadsToRunMethodIfItIsAlreadyRunningOnAnotherThread()
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ObeyStopTask",
                StartTime = "12:00 AM",
                StopTime = "11:59 PM",
                RunIntervalInMinutes = 10,
                ActiveWeekDays = new List<string> { "all" },
                Task = new ObeyStopTask()
            };
            appointment.Validate();

            _scheduler = new Scheduler();

            //
            // Add our appointment to the list of scheduled appointments an schedule it to run immediately.
            //
            _scheduler.Schedule.Add(new ScheduledAppointment(new DateTime(2022,2,4,6,1,0), appointment));

            //
            // Now spin up multiple threads as simultaneously as possible to call ExecuteSchedule(),
            // but we'll need to employ a proxy because ExecuteSchedule() has two non-optional
            // parameters.
            //
            var threads = new List<Thread>();
            for (int counter = 0; counter < 100; ++counter)
            {
                var thread = new Thread(ExecuteScheduleProxy);
                thread.Start();
                threads.Add(thread);
            }

            //
            // Wait long enough for our threads to do their thing.
            //
            Thread.Sleep(1000);

            //
            // Our task will run for 25 seconds, so if everything has gone to plan, there will be 
            // exactly one task in the RunningTasks list.
            //
            Assert.That(_scheduler.RunningTasks.Count, Is.EqualTo(1));

            //
            // Clean-up our messes.
            //
            Parallel.ForEach(threads,
                thread =>
                {
                    thread.Join();
                });

            _scheduler.StopAllTasks();
        }

        #endregion Incompatible Tasks tests
        
        #region Appointment Validation tests

        [Test]
        public void Validate_ThrowsIncompatibleDaysConfigurationExceptionWhenWeekDaysAndMonthDaysAreSpecified()
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ObeyStopTask",
                StartTime = "12:00 AM",
                StopTime = "11:59 PM",
                RunIntervalInMinutes = 10,
                ActiveWeekDays = new List<string> { "tue" },
                ActiveDaysOfTheMonth = new List<int> {1, 15},
                Task = new ObeyStopTask()
            };

            Assert.Throws<IncompatibleDaysConfigurationException>(appointment.Validate);
        }

        [Test]
        public void Validate_ThrowsIncompatibleWeekdayOrdinalConditionsExceptionWhenTooManyWeekDaysAreSet()
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ObeyStopTask",
                StartTime = "12:00 AM",
                StopTime = "11:59 PM",
                RunIntervalInMinutes = 10,
                ActiveWeekDays = new List<string> { "tue", "wed" },
                WeekdayOrdinal = "Last",
                Task = new ObeyStopTask()
            };

            Assert.Throws<IncompatibleWeekdayOrdinalConditionsException>(appointment.Validate);
        }

        [Test]
        public void Validate_ThrowsIncompatibleWeekdayOrdinalConditionsExceptionWhenAllWeekDaysAreSet()
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ObeyStopTask",
                StartTime = "12:00 AM",
                StopTime = "11:59 PM",
                RunIntervalInMinutes = 10,
                ActiveWeekDays = new List<string> { "all" },
                WeekdayOrdinal = "First",
                Task = new ObeyStopTask()
            };

            Assert.Throws<IncompatibleWeekdayOrdinalConditionsException>(appointment.Validate);
        }

        [Test]
        public void Validate_ThrowsInvalidDateBoundariesExceptionWhenFinalRunIsEarlierThanInitialRun()
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ObeyStopTask",
                StartTime = "12:00 AM",
                StopTime = "11:59 PM",
                RunIntervalInMinutes = 10,
                InitialRun = new DateTime(2023,3,1),
                FinalRun = new DateTime(2023,2,28),
                ActiveWeekDays = new List<string> { "all" },
                Task = new ObeyStopTask()
            };

            Assert.Throws<InvalidDateBoundariesException>(appointment.Validate);
        }

        [Test]
        public void Validate_ThrowsInvalidDayOfMonthExceptionWhenDaysIncludes31AndMonthsIncludesFebruary()
        {
            var appointment = new Appointment
            {
                Name = "DummyTask",
                AssemblyName = "Cigna.TaskScheduling.Tests.Unit.dll",
                ClassName = "Cigna.TaskScheduling.Tests.Unit.ObeyStopTask",
                StartTime = "12:00 AM",
                StopTime = "11:59 PM",
                RunIntervalInMinutes = 10,
                ActiveWeekDays = new List<string> { "all" },
                ActiveMonths = new List<string> {"Feb", "may", "aug", "nov"},
                ActiveDaysOfTheMonth = new List<int> { 15, 31 },
                Task = new ObeyStopTask()
            };

            Assert.Throws<InvalidDayOfMonthException>(appointment.Validate);
        }

        #endregion Appointment Validation tests

        #region Private helper methods

        private void ExecuteScheduleProxy()
        {
            _scheduler.ExecuteSchedule(new object(), EventArgs.Empty as ElapsedEventArgs);
        }

        #endregion Private helper methods
    }
}