﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using Cigna.TaskScheduling.Domain;

namespace Cigna.TaskScheduling.Tests.Unit
{
    [ExcludeFromCodeCoverage]
    public class ObeyStopTask : Domain.Task
    {
        public override void Start()
        {

            try
            {
                Console.WriteLine(
                    $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(ObeyStopTask)} started.");

                for (int count = 0; count < 100 && !StopCalled; ++count)
                {
                    Console.WriteLine(
                        $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(ObeyStopTask)} is running!");
                    Thread.Sleep(250); // Sleep for 1/4 second
                }
            }
            catch (ThreadInterruptedException)
            {
                //
                // Do nothing.  This is the result of a KillTask() call in the scheduler.
                //
                Console.WriteLine(
                    $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - Thread interrupt received on {nameof(ObeyStopTask)}.  Shutting down.");
            }
            catch (Exception)
            {
                //
                // Do nothing.
                //
            }
            finally
            {
                Console.WriteLine(
                    $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(ObeyStopTask)} stopped.");

                CompletionStatus = StopCalled
                    ? TaskCompletionStatus.Stopped
                    : TaskCompletionStatus.Succeeded;
            }
        }

        public override void Stop()
        {
            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - Stop called on {nameof(ObeyStopTask)}");
            base.Stop();
        }
    }
}
