﻿using System.Reflection;

[assembly: AssemblyVersion("2023.2.2.0")]
[assembly: AssemblyFileVersion("2023.2.2.0")]

[assembly: AssemblyCopyright("Copyright © 2023 Cigna - All Rights Reserved")]