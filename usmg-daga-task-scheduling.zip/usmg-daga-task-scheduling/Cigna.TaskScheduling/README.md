﻿# Cigna.TaskScheduling

Cigna.TaskScheduling is a configuration-based task scheduling library that
can be added to any non-ephermeral executable, such as a console application
or Windows service.  It uses a Reflection-based plug-in model for adding
tasks via configuration.

Documentation for using the library can be found [here](https://confluence.sys.cigna.com/display/DAT/Cigna.TaskScheduling+-+Building+from+Scratch).

Documentation for configuring tasks can be found [here](https://confluence.sys.cigna.com/display/DAT/Cigna.TaskScheduling+-+Configuration+Guide).

## Using the interface in new applications

1. Install this library using NuGet/Artifactory.

2. Add task configurations to your application.

3. Ensure that your application references your plug-in library/libraries or 
   that they are referenced properly in your configuration file.

4. Add a call to `Scheduler.Instance.Start();`


To create plug-ins, do the following:

1. For each plug-in class, add `using Cigna.TaskScheduling.Domain;` to the 
   using preamble.

2. Derive each task from `Domain.Task`.  (Be sure to explicitly use the
   `Domain` qualifier so that you don't create conflicts with the system
   threading libraries.)
 
   For example:
 
   `public class CleanUpTempFilesTask: Domain.Task { ... }`

3. Write your plug-in code!

4. Be sure to implement a `Start()` method.  This method will get called by
   the scheduler to start the task. 

5. `Domain.Task` provides a `StopCalled` property that you can check to see
   if the task needs to terminate early.  This property is self-locking and
   thread-safe.

6. You can also override the `Stop()` method from the Task base class if you
   need to do additional processing at the moment `Stop()` is called.  Be 
   sure, though, to call `base.Stop()` in your override method.  Also, make
   sure you don't perform any long-running maintenance within this method.
   It is intended to return immediately and will likely be called on a 
   different thread from the one running the task.

## Change Log
### 2023.2.2
#### Bug Fixes
- Fixed an issue where scheduled tasks that are run _ad hoc_ get removed if
  they are part of an incompatible tasks group and are run outside of their
  scheduled window.

- Fixed an issue where the base class name is displayed in the log instead
  of the task name when a conflicting task is removed from the incompatible
  tasks queue because it is outside of its run window.

### 2023.2.1
#### Bug Fixes
- Fixed issue where Ping() and GetEnvironmentInfo() calls disappeared from
  the REST API.

### 2023.2.0
#### New Features
##### Addition of calendar-based configurations
Added calendar-based configurations.  New <task> attributes are:

- `months` - Value is "All" or a comma-separated list of three-letter 
  English abbreviations.

- `days` - 	Value is "All", "Last" or a comma-separated list of numbers
  representing days of the month.  "Last" will pick the appropriate value for
  the last day of the month.  (E.g.: 31 for January, 28 for February in a 
  non-leap year, etc.)

- `initialRun` - The date when a schedule will become effective.  Must be
  expressed as yyyy-MM-dd.

- `finalRun` - The date _after_ which the schedule will no longer be used.
  Must be expressed as yyyy-MMM-dd.

- `weekdayOrdinal` - A comma-separated list of ordinal values used in
  conjunction with activeDays to indicate the ordinal value of the weekday
  to schedule.  Valid values are "All", "First", "Second", "Third",
  "Fourth", "Last".

### 2023.1.0
#### Internal Changes
##### Conversion to SDK-style projects and move to netstandard20/net6.0
- Converted all projects to SDK-style.  This has no operational effects, 
  but simplifies future work.

- Changed target frameworks to .NET Standard 2.0, which is compatible
  with all .NET Framework versions 4.5 through 4.8.x (except for 4.6.1),
  and .NET 6.

### 2022.2.2
#### Bug Fixes
This fixes several problems found related to the RunOncePerDay feature.  
It should now work correctly.

#### Internal Changes
Several objects in the scheduler code have been renamed to use the word 
"Appointment" instead of "Task" in order to distinguish scheduling metadata
containers from "worker" tasks derived from Domain.Task.  Changes are
non-breaking and we still use the "Task" terminology in the configuration
files and when presenting data through the web API. 

### 2022.2.1
#### Bug Fixes
- A defect related to running weekday jobs that cross the midnight boundary 
  into a weekend has been fixed. 
- Fixed a defect where a job that gets stopped won't run properly if the
  task obeys the StopCalled property.

### 2022.2.0
#### New Features
In response to issues found on the MRDE servers, we added protection to our 
task starting mechanism to ensure that it is not run simultaneously from 
different threads.  We also added additional logging to point out when the
server's timer mechanics are not responding fluidly.

Also in support of MRDE, we added explicit route attributes to all of the 
web API entry points in Cigna.TaskScheduling.WebApi.

#### Bug Fixes
- We changed how we determine which assembly name to use when presenting the 
  application version number in the WebApi.  It will now display the 
  application's version number and not the version of Cigna.TaskScheduling.

### 2022.1.0
#### New Features
Cigna.TaskScheduling now supports daily tasks.  There are two new 
configuration attributes for this:

- `runOncePerActiveDay` -- This will cause the task to be a daily task that 
  runs only once per day if it succeeds;
- `retries` -- setting this to a positive integer value will cause a 
  once-per-day task to retry up to the specified number of times on a 
  failure.

This feature still obeys the startTime/stopTime window and activeDays 
setting, so if a retry would start outside of the specified window, the 
retry counter is reset and the task is scheduled for the next available
window.
