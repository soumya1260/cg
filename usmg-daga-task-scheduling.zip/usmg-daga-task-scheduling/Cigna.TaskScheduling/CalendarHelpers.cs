﻿using System;

namespace Cigna.TaskScheduling
{
    public static class CalendarHelpers
    {
        public static int Month(string abbreviatedMonth)
        {
            switch (abbreviatedMonth.ToUpperInvariant())
            {
                case "JAN": return  1;
                case "FEB": return  2;
                case "MAR": return  3;
                case "APR": return  4;
                case "MAY": return  5;
                case "JUN": return  6;
                case "JUL": return  7;
                case "AUG": return  8;
                case "SEP": return  9;
                case "OCT": return 10;
                case "NOV": return 11;
                case "DEC": return 12;
                default:    return  0;
            }
        }

        public static DayOfWeek WeekDay(string dayOfWeekString)
        {
            switch (dayOfWeekString.ToUpperInvariant())
            {
                case "SUN": return DayOfWeek.Sunday;
                case "MON": return DayOfWeek.Monday;
                case "TUE": return DayOfWeek.Tuesday;
                case "WED": return DayOfWeek.Wednesday;
                case "THU": return DayOfWeek.Thursday;
                case "FRI": return DayOfWeek.Friday;
                case "SAT": return DayOfWeek.Saturday;
                default:    return DayOfWeek.Sunday;
            }
        }

        public static int OrdinalValue(string ordinalString)
        {
            switch (ordinalString.ToUpperInvariant())
            {
                case "FIRST":  return 1;
                case "SECOND": return 2;
                case "THIRD":  return 3;
                case "FOURTH": return 4;
                case "LAST":
                default:       return 5;
            }
        }
    }
}
