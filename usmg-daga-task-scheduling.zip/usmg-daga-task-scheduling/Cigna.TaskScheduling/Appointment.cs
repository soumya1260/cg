﻿using Cigna.TaskScheduling.Domain;
using Cigna.TaskScheduling.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cigna.TaskScheduling
{
    /// <summary>
    /// Appointment wrapper for a task (worker) describing how it should be scheduled.
    /// </summary>
    public class Appointment
    {
        public string Name { get; set; }
        public string AssemblyName { private get; set; }
        public string ClassName { get; set; }
        public Task Task { get; set; }
        public string StartTime { get; set; }
        public string StopTime { get; set; }
        public int RunIntervalInMinutes { get; set; }
        public bool Enabled { get; set; }
        public bool RunEveryWeekday { get; set; }
        public List<string> ActiveWeekDays { get; set; } = new List<string>();
        public AppointmentType AppointmentType { get; set; } = AppointmentType.Scheduled;

        //
        // New feature for 2022!  Run once per day with retries.
        //
        public bool RunOncePerActiveDay { get; set; }
        public int Retries { get; set; }
        public int TimesRetried { get; set; }

        //
        // New for 2023 - Calendar attributes.
        //
        public List<string> ActiveMonths { get; set; } = new List<string>();
        public bool RunEveryMonth { get; set; } = true;

        public List<int> ActiveDaysOfTheMonth { get; set; } = new List<int>();
        public bool RunEveryDayOfTheMonth { get; set; } = true;

        public DateTime InitialRun { get; set; } = DateTime.MinValue;
        public DateTime FinalRun { get; set; } = DateTime.MaxValue;
        public string WeekdayOrdinal { get; set; } = "All";

        //
        // Execution request type tracking.  Added to version 2023.2.2.
        //
        public AppointmentType ExecutionRequestType { get; set; }

        public Appointment()
        {
        }

        /// <summary>
        /// Copy constructor.
        /// </summary>
        /// <param name="appointment">appointment to be copied</param>
        /// <remarks>
        /// This is a shallow copy.
        /// </remarks>
        protected Appointment(Appointment appointment)
        {
            Name = appointment.Name;
            AssemblyName = appointment.AssemblyName;
            ClassName = appointment.ClassName;
            Task = appointment.Task;
            StartTime = appointment.StartTime;
            StopTime = appointment.StopTime;
            RunIntervalInMinutes = appointment.RunIntervalInMinutes;
            Enabled = appointment.Enabled;
            RunEveryWeekday = appointment.RunEveryWeekday;
            ActiveWeekDays = appointment.ActiveWeekDays;
            AppointmentType = appointment.AppointmentType;
            RunOncePerActiveDay = appointment.RunOncePerActiveDay;
            Retries = appointment.Retries;
            TimesRetried = appointment.TimesRetried;
            ActiveMonths = appointment.ActiveMonths;
            ActiveDaysOfTheMonth = appointment.ActiveDaysOfTheMonth;
            InitialRun = appointment.InitialRun;
            FinalRun = appointment.FinalRun;
            WeekdayOrdinal = appointment.WeekdayOrdinal;
            RunEveryDayOfTheMonth = appointment.RunEveryDayOfTheMonth;
            RunEveryMonth = appointment.RunEveryMonth;
        }

        /// <summary>
        /// Sets summary values and validates that the model is sane.
        /// </summary>
        /// <exception cref="InvalidDayOfMonthException"></exception>
        /// <exception cref="IncompatibleDaysConfigurationException"></exception>
        /// <exception cref="InvalidDateBoundariesException"></exception>
        /// <exception cref="IncompatibleWeekdayOrdinalConditionsException"></exception>
        public void Validate()
        {
            EnsureWeekdaySettingsAreSane();
            EnsureMonthSettingsAreSane();
            EnsureDayOfMonthSettingsAreSane();
            EnsureBoundaryDatesAreSane();
            EnsureWeekdayOrdinalIsSane();
        }

        private void EnsureWeekdaySettingsAreSane()
        {
            //
            // This first check is mainly to facilitate unit tests.  It
            // shouldn't happen when called from the scheduler.
            //
            if (ActiveWeekDays.Any(day => day.Equals("All", StringComparison.InvariantCultureIgnoreCase)))
            {
                ActiveWeekDays.Clear();
            }

            RunEveryWeekday = !ActiveWeekDays.Any();

            //
            // Logical reduction if all the days of the week are specified
            // instead of "All".
            //
            if (ActiveWeekDays.Distinct().Count() != 7) return;

            RunEveryWeekday = true;
            ActiveWeekDays.Clear();
        }

        private void EnsureMonthSettingsAreSane()
        {
            //
            // This first check is mainly to facilitate unit tests.  It
            // shouldn't happen when called from the scheduler.
            //
            if (ActiveMonths.Any(month => month.Equals("All", StringComparison.InvariantCultureIgnoreCase)))
            {
                ActiveMonths.Clear();
            }

            RunEveryMonth = !ActiveMonths.Any();

            //
            // Logical reduction if every month is specified instead of
            // "All"
            //
            if (ActiveMonths.Distinct().Count() != 12) return;

            RunEveryMonth = true;
            ActiveMonths.Clear();
        }

        /// <summary>
        /// Validates settings related to days of the month.
        /// </summary>
        /// <exception cref="InvalidDayOfMonthException"></exception>
        /// <exception cref="IncompatibleDaysConfigurationException"></exception>
        private void EnsureDayOfMonthSettingsAreSane()
        {
            RunEveryDayOfTheMonth = !ActiveDaysOfTheMonth.Any();

            //
            // 2023 was chosen for this test because it is not a leap year.
            //
            foreach (var month in ActiveMonths)
                foreach (var day in ActiveDaysOfTheMonth)
                    if (day > DateTime.DaysInMonth(2023, CalendarHelpers.Month(month)))
                        throw new InvalidDayOfMonthException(day, month);

            if (!RunEveryDayOfTheMonth && !RunEveryWeekday)
                throw new IncompatibleDaysConfigurationException();
        }

        /// <summary>
        /// Validates that the boundary dates make sense.
        /// </summary>
        /// <exception cref="InvalidDateBoundariesException"></exception>
        private void EnsureBoundaryDatesAreSane()
        {
            if (FinalRun <= InitialRun)
                throw new InvalidDateBoundariesException();
        }

        /// <summary>
        /// Validates that there are no conflicts when setting the weekday ordinal value.
        /// </summary>
        /// <exception cref="IncompatibleWeekdayOrdinalConditionsException"></exception>
        private void EnsureWeekdayOrdinalIsSane()
        {
            if (!WeekdayOrdinal.Equals("All", StringComparison.InvariantCultureIgnoreCase) &&
                ActiveWeekDays.Count != 1)
            {
                throw new IncompatibleWeekdayOrdinalConditionsException();
            }
        }
    }
}