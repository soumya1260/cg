﻿using System.Threading;

namespace Cigna.TaskScheduling
{
    internal class ActiveAppointment : Appointment
    {
        public Thread Thread { get; }
        public bool Completed { get; set; }

        public ActiveAppointment(Thread thread, ScheduledAppointment task) : base(task)
        {
            Thread = thread;
            Completed = false;
        }
    }
}