﻿using Cigna.TaskScheduling.Configuration;
using Cigna.TaskScheduling.Domain;
using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using IncompatibleTask = Cigna.TaskScheduling.Configuration.IncompatibleTask;

[assembly: InternalsVisibleTo("Cigna.TaskScheduling.Tests.Unit")]
[assembly: InternalsVisibleTo("Cigna.TaskScheduling.Tests.Integration")]

namespace Cigna.TaskScheduling
{
    public sealed class Scheduler
    {
        #region Internal Fields

        /// <summary>
        /// Contains a list of scheduled dates/times for upcoming appointments.
        /// </summary>
        internal readonly List<ScheduledAppointment> Schedule;

        /// <summary>
        /// The complete list of appointments specified in the configuration file,
        /// including disabled appointments.
        /// </summary>
        internal readonly List<Appointment> Appointments;

        /// <summary>
        /// This variable facilitates unit testing and debugging. It has no direct use in the
        /// Scheduler itself.
        /// </summary>
        internal bool TimeIntervalErrorTriggered;

        internal readonly List<ActiveAppointment> RunningTasks;

        #endregion Internal Fields

        #region Private Fields

        private const int TimerIntervalInSeconds = 1;
        private static readonly int MaximumAcceptableDriftInMilliseconds = 3 * TimerIntervalInSeconds * 1000;

        //
        // Singleton Pattern implementation.
        //
        private static readonly Lazy<Scheduler> Lazy = new Lazy<Scheduler>(() => new Scheduler());

        /// <summary>
        /// Contains a list of active appointments and their associated threads.
        /// </summary>
        private readonly object _runningAppointmentsLock;

        private readonly ILog _log;
        private readonly object _scheduleLock;
        private readonly object _appointmentsLock;
        private readonly object _incompatibleTaskGroupsLock;
        private readonly object _executeScheduleLock;
        private DateTime _previousTimerTick;
        private readonly System.Timers.Timer _timer;
        private bool _stopped;

        private readonly Dictionary<string, IncompatibleTasksGroup> _incompatibleTaskGroups;

        #endregion Private Fields

        #region Internal Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        internal Scheduler()
        {
            Appointments = new List<Appointment>();
            Schedule = new List<ScheduledAppointment>();
            RunningTasks = new List<ActiveAppointment>();
            _appointmentsLock = new object();
            _scheduleLock = new object();
            _runningAppointmentsLock = new object();
            _incompatibleTaskGroupsLock = new object();
            _executeScheduleLock = new object();
            _previousTimerTick = DateTime.Now;
            _timer = new System.Timers.Timer();
            _log = LogManager.GetLogger(GetType());
            _incompatibleTaskGroups = new Dictionary<string, IncompatibleTasksGroup>();
        }

        #endregion Internal Constructors

        #region Public Properties

        //
        // This class is a lazy-instanced singleton.
        //
        public static Scheduler Instance => Lazy.Value;

        #endregion Public Properties

        #region Public Methods



        /// <summary>
        /// Adds the supplied appointment to the ScheduledAppointments list, scheduling its next run time.
        /// </summary>
        /// <param name="appointment">The appointment to schedule</param>
        /// <param name="currentDateTime">The date/time to schedule the appointment relative to its parameters</param>
        /// <param name="ignoreInterval">Ignore the interval when scheduling the appointment</param>
        /// <param name="forRetry">Consider that this is an attempt to reschedule the appointment because a retry has been requested</param>
        /// <remarks>
        /// This is the unit-testable version that allows the current date and time to be supplied as a parameter.
        /// </remarks>
        public static DateTime DetermineNextStartTime(Appointment appointment, DateTime currentDateTime, bool ignoreInterval = false, bool forRetry = false)
        {
            if (appointment.InitialRun > DateTime.MinValue && currentDateTime < appointment.InitialRun)
            {
                currentDateTime = appointment.InitialRun;
            }

            //
            // Bail out early if the date is already past the FinalRun limit.
            //
            if (ScheduledDateIsBeyondFinalRunDate(appointment, currentDateTime)) return DateTime.MaxValue;

            //
            // Assumption: appointment start and stop times are valid.
            //
            DateTime startTime = currentDateTime.Date.Add(DateTime.Parse(appointment.StartTime).TimeOfDay);
            DateTime endTime = currentDateTime.Date.Add(DateTime.Parse(appointment.StopTime).TimeOfDay);

            endTime = AdjustActivityWindowForWindowsThatCrossMidnight(currentDateTime, endTime, ref startTime);

            //
            // Attempt to schedule appointment based on the current time.
            //
            DateTime scheduledTime = SetScheduledTime(appointment, currentDateTime, ignoreInterval, forRetry, startTime, endTime);
            if (ScheduledDateIsBeyondFinalRunDate(appointment, scheduledTime)) return DateTime.MaxValue;

            //
            // If the window __start time__ is on a valid appointment day, we are done.
            // This is important because of appointment windows that cross midnight.
            //
            if (ValidAppointmentDate(
                    appointment,
                    scheduledTime > endTime ? scheduledTime : startTime)) return scheduledTime;

            //
            // Start by moving to the next day's start time.
            //
            scheduledTime = startTime.AddDays(1);

            //
            // Since the appointment has day of week restrictions, advance forward until the scheduled time
            // is on a valid day.
            //
            while (!ValidAppointmentDate(appointment, scheduledTime))
            {
                if (ScheduledDateIsBeyondFinalRunDate(appointment, scheduledTime)) return DateTime.MaxValue;
                scheduledTime = scheduledTime.AddDays(1);
                appointment.TimesRetried = 0;
            }

            return ScheduledDateIsBeyondFinalRunDate(appointment, scheduledTime)
                ? DateTime.MaxValue
                : scheduledTime;
        }

        private static bool ScheduledDateIsBeyondFinalRunDate(
            Appointment appointment,
            DateTime currentDateTime) =>
            currentDateTime >= (DateTime.MaxValue.AddDays(-2)) ||
            (appointment.FinalRun < DateTime.MaxValue.Date &&
             currentDateTime > appointment.FinalRun);

        public TaskStatus GetTask(string taskName)
        {
            TaskStatus taskStatus = null;

            try
            {
                Appointment appointment;
                lock (_appointmentsLock)
                {
                    appointment = Appointments.FirstOrDefault(t =>
                        t.Name.Equals(taskName, StringComparison.CurrentCultureIgnoreCase));
                }

                taskStatus = GetTaskStatus(appointment);

            }
            catch (Exception)
            {
                // Swallow exception
            }

            return taskStatus;
        }

        /// <summary>
        /// Communications interface for querying tasks.
        /// </summary>
        /// <returns></returns>
        public List<TaskStatus> GetAppointments()
        {
            List<TaskStatus> tasks = new List<TaskStatus>();

            lock (_appointmentsLock)
            {
                tasks.AddRange(Appointments.OrderBy(t => t.Name).Select(GetTaskStatus));
            }

            return tasks;
        }

        public TaskRunRequestResult KillAllTasks()
        {
            try
            {
                List<string> names;
                lock (_runningAppointmentsLock)
                {
                    names = RunningTasks.Select(task => task.Name).ToList();
                }

                Parallel.ForEach(names, name => KillTask(name));

                return TaskRunRequestResult.Succeeded;
            }
            catch (Exception exception)
            {
                _log.Error("Error killing all tasks.", exception);
                return TaskRunRequestResult.Failed;
            }
        }

        public TaskRunRequestResult KillTask(string taskName)
        {
            _log.InfoFormat($"Kill called for task '{taskName}'");

            Appointment task;
            lock (_appointmentsLock)
            {
                task = Appointments.FirstOrDefault(t => t.Name == taskName);
            }

            if (task == null)
            {
                _log.WarnFormat($"Could not find task '{taskName}' in the task list.");
                return TaskRunRequestResult.TaskDoesNotExist;
            }

            ActiveAppointment activeTask;
            lock (_runningAppointmentsLock)
            {
                activeTask = RunningTasks.FirstOrDefault(t => t.Name == taskName);
            }

            if (activeTask != null)
            {
                try
                {
                    activeTask.Thread.Interrupt();
                    if (!activeTask.Thread.Join(2000))
                    {
                        activeTask.Thread.Abort();
                    }
                }
                catch (Exception exception)
                {
                    _log.Error($"Error attempting to kill thread for task {taskName}.", exception);
                    return TaskRunRequestResult.Failed;
                }
            }

            return TaskRunRequestResult.Succeeded;
        }

        /// <summary>
        /// Start task.  Intended to be called on its own thread by the SchedulerService.
        /// </summary>
        public void Start()
        {
            _log.Info("Scheduler started.");

            InitializeIncompatibleTaskGroups();
            InitializeSchedule();
            InitializeTimer();
        }

        public TaskRunRequestResult StartTask(string taskName)
        {
            _log.Info($"Start called for task '{taskName}'.");

            Appointment task;
            lock (_appointmentsLock)
            {
                task = Appointments.FirstOrDefault(t => t.Name == taskName);
            }
            if (task == null)
            {
                _log.Info(
                    $"Task '{taskName}' could not be scheduled to run immediately.  Task not found in the task list.");

                return TaskRunRequestResult.TaskDoesNotExist;
            }

            if (!task.Enabled)
            {
                _log.Info($"Task '{taskName}' is disabled and cannot be run.");
                return TaskRunRequestResult.TaskIsDisabled;
            }

            //
            // Mark the task as being an ad hoc request.
            //
            task.ExecutionRequestType = AppointmentType.AdHoc;

            ScheduledAppointment previouslyScheduledTask;
            lock (_scheduleLock)
            {
                previouslyScheduledTask = Schedule.FirstOrDefault(t => t.Name == taskName);
            }

            if (previouslyScheduledTask != null)
            {
                //
                // Reschedule the task to run now.  Regular schedule will resume afterward.
                //
                previouslyScheduledTask.ExecutionRequestType = AppointmentType.AdHoc;
                previouslyScheduledTask.ScheduledTime = DateTime.Now;
            }
            else
            {
                //
                // The task is an ad hoc only task.  Schedule it to run now.
                //
                lock (_scheduleLock)
                {
                    Schedule.Add(new ScheduledAppointment(DateTime.Now, task));
                }
            }


            _log.InfoFormat($"Task '{taskName}' has been scheduled to run at the next timer tick.");

            return TaskRunRequestResult.Succeeded;
        }

        // ReSharper restore UnusedMember.Global
        /// <summary>
        /// Callback to stop all active tasks and shut down.
        /// </summary>
        // ReSharper disable UnusedMember.Global
        public void Stop()
        {
            _log.Info("Stop called for all tasks.");

            //
            // Signal the main thread that we are shutting down.
            //
            _stopped = true;
            _timer.Stop();
            _timer.Dispose();

            _log.Info("Scheduler stop requested.");

            //
            // Clear the schedule.
            //
            lock (_scheduleLock)
            {
                Schedule.Clear();
            }

            //
            // Inform any active threads to shut down and then wait for them to end.
            //
            StopAllTasks();

            List<ActiveAppointment> activeTasks;
            lock (_runningAppointmentsLock)
            {
                //
                // Force enumeration so that we aren't using the protected List outside of a lock
                // context.
                //
                activeTasks = RunningTasks.ToList();
            }

            Parallel.ForEach(activeTasks,
                task =>
                {
                    task.Thread.Join();
                    RecordTaskCompletion(task);
                });

            _log.Info("All active tasks have completed.  Scheduler will now shut down.");
        }

        public TaskRunRequestResult StopAllTasks()
        {
            List<string> names;
            lock (_runningAppointmentsLock)
            {
                names = RunningTasks.Select(task => task.Name).ToList();
            }

            Parallel.ForEach(names, name => StopTask(name));

            return TaskRunRequestResult.Succeeded;
        }

        public TaskRunRequestResult StopTask(string taskName)
        {
            _log.InfoFormat($"Stop called for task '{taskName}'");

            Appointment task;
            lock (_appointmentsLock)
            {
                task = Appointments.FirstOrDefault(t => t.Name == taskName);
            }

            if (task == null)
            {
                _log.WarnFormat($"Could not find task '{taskName}' in the task list.");
                return TaskRunRequestResult.TaskDoesNotExist;
            }

            ActiveAppointment activeTask;
            lock (_runningAppointmentsLock)
            {
                activeTask = RunningTasks.FirstOrDefault(t => t.Name == taskName);
            }

            //
            // Task may have already stopped normally.
            //
            if (activeTask == null) return TaskRunRequestResult.Succeeded;

            try
            {
                activeTask.Task.Stop();
                _log.InfoFormat($"Stop request sent to task '{taskName}'.");
            }
            catch (Exception exception)
            {
                _log.Error("Could not call Stop() on task.  See stack trace.", exception);
                return TaskRunRequestResult.Failed;
            }

            return TaskRunRequestResult.Succeeded;
        }

        #endregion Public Methods

        #region Internal Methods

        /// <summary>
        /// Creates a scheduler appointment based on a configuration appointment object.
        /// </summary>
        /// <param name="appointment">the configuration appointment object to create the appointment from</param>
        /// <param name="worker">the worker task to associate with the appointment</param>
        /// <returns></returns>
        /// <exception cref="InvalidDayOfMonthException">
        /// This happens when a day of month value isn't valid for one of the months specified
        /// </exception>
        /// <exception cref="IncompatibleDaysConfigurationException">
        /// Both 'days' (days of the month) and 'activeDays' (days of the week) were specified.
        /// </exception>
        /// <exception cref="InvalidDateBoundariesException">
        /// initialRun value must be earlier than finalRun value.
        /// </exception>
        internal static Appointment CreateAppointment(Configuration.Appointment appointment, Domain.Task worker)
        {
            //
            // Create the task.
            //
            var schedulerAppointment = new Appointment
            {
                Name = appointment.Name,
                AssemblyName = appointment.AssemblyName,
                ClassName = appointment.ClassName,
                Task = worker,
                StartTime = appointment.StartTime,
                StopTime = appointment.StopTime,
                RunIntervalInMinutes = appointment.RunIntervalInMinutes,
                Enabled = appointment.Enabled,
                AppointmentType = appointment.TaskType,
                Retries = appointment.Retries,
                RunOncePerActiveDay = appointment.RunOncePerActiveDay,
                TimesRetried = 0,
                InitialRun = appointment.InitialRun,
                FinalRun = appointment.FinalRun,
                WeekdayOrdinal = appointment.WeekdayOrdinal,
            };

            GetActiveWeekDays(appointment, schedulerAppointment);
            GetActiveMonths(appointment, schedulerAppointment);
            GetDaysOfTheMonth(appointment, schedulerAppointment);

            schedulerAppointment.Validate();

            return schedulerAppointment;
        }

        private static void GetActiveWeekDays(Configuration.Appointment appointment, Appointment schedulerAppointment)
        {
            if (appointment.RunEveryWeekDay ||
                string.Equals(appointment.ActiveWeekDays.Trim(), "All", StringComparison.InvariantCultureIgnoreCase))
            {
                schedulerAppointment.RunEveryWeekday = true;
                schedulerAppointment.ActiveWeekDays.Clear();
            }
            else
            {
                schedulerAppointment.RunEveryWeekday = false;
                schedulerAppointment.ActiveWeekDays = appointment.ActiveWeekDays
                    .Split(',')
                    .Select(day => day.Trim())
                    .Distinct()
                    .ToList();
            }
        }

        private static void GetActiveMonths(Configuration.Appointment appointment, Appointment schedulerAppointment)
        {
            if (string.Equals(appointment.ActiveMonths.Trim(), "All", StringComparison.InvariantCultureIgnoreCase))
            {
                schedulerAppointment.RunEveryMonth = true;
            }
            else
            {
                schedulerAppointment.RunEveryMonth = false;
                schedulerAppointment.ActiveMonths = appointment.ActiveMonths
                    .Split(',')
                    .Select(month => month.Trim())
                    .Distinct()
                    .ToList();
            }
        }

        private static void GetDaysOfTheMonth(Configuration.Appointment appointment, Appointment schedulerAppointment)
        {
            if (string.Equals(appointment.ActiveDaysOfTheMonth.Trim(), "All"))
            {
                schedulerAppointment.RunEveryDayOfTheMonth = true;
            }
            else
            {
                schedulerAppointment.RunEveryDayOfTheMonth = false;

                schedulerAppointment.ActiveDaysOfTheMonth = appointment.ActiveDaysOfTheMonth
                    .Split(',')
                    .Where(day => !day.Equals("Last", StringComparison.InvariantCultureIgnoreCase))
                    .Select(day => int.TryParse(day.Trim(), out int value) ? (int?)value : null)
                    .Where(day => day != null)
                    .Select(day => (int)day)
                    .Distinct()
                    .ToList();

                if (appointment.ActiveDaysOfTheMonth
                    .Split(',')
                    .Any(day => day.Equals("Last", StringComparison.InvariantCultureIgnoreCase)))
                {
                    schedulerAppointment.ActiveDaysOfTheMonth.Add(0);
                }
            }
        }

        private void InitializeIncompatibleTaskGroups()
        {
            if (!(ConfigurationManager.GetSection("Cigna.TaskScheduling") is SchedulerConfiguration taskConfiguration))
            {
                _log.Error("Could not retrieve task list from configuration file.  This is likely due to a syntax error or missing configuration section.");
                return;
            }

            foreach (Configuration.IncompatibleTasksGroup group in taskConfiguration.IncompatibleTasksGroups)
            {
                var tasks = group.Tasks.Cast<IncompatibleTask>().Select(task => task.Name).ToList();
                lock (_incompatibleTaskGroupsLock)
                {
                    _incompatibleTaskGroups.Add(
                    group.Name,
                    new IncompatibleTasksGroup
                    {
                        Queue = new Queue<string>(),
                        Tasks = tasks
                    });
                }
            }
        }

        /// <summary>
        /// Initializes the schedule with tasks from the application configuration file.
        /// </summary>
        /// <returns>false if there were initialization issues; true otherwise</returns>
        private void InitializeSchedule()
        {
            //
            // Get a reference to our custom configuration section.
            //
            if (!(ConfigurationManager.GetSection("Cigna.TaskScheduling") is SchedulerConfiguration taskConfigSection))
            {
                _log.Error("Could not retrieve task list from configuration file.  This is likely due to a syntax error or missing configuration section.");
                return;
            }

            //
            // Read and schedule the tasks from the configuration task list.
            //
            foreach (Configuration.Appointment configTask in taskConfigSection.Appointments)
            {
                ScheduleAppointmentFromConfiguration(configTask);
            }
        }

        public void ScheduleAppointmentFromConfiguration(Configuration.Appointment configTask)
        {
            //
            // Avoid re-adding existing tasks. This is mainly for compatibility with
            // unit/integration tests using this class as a Singleton.
            //
            lock (_appointmentsLock)
            {
                if (Appointments.Any(t => t.Name.Equals(configTask.Name))) return;
            }

            string assemblyName = configTask.AssemblyName;
            string className = configTask.ClassName;

            //
            // When running under the Services controller, all services default to using
            // %WINDIR%\System32 as the current folder instead of using the folder in which the
            // binaries reside. This can create havoc with relative task DLL file references in
            // our configuration file. So we force the current directory to be the folder where
            // our binaries are installed.
            //
            System.IO.Directory.SetCurrentDirectory(AppDomain.CurrentDomain.BaseDirectory);

            //
            // Load the assembly and construct the task's class object.
            //
            // Note that attempting to load the same assembly reference twice within the same
            // context is okay as long as the assembly name is unchanged. LoadFrom() will return
            // the previously-loaded assembly reference.
            //
            // C.f.: https://msdn.microsoft.com/en-us/library/1009fa28(v=vs.110).aspx#Anchor_2
            //
            // For security reasons, we SHOULD be using Assembly.Load, but we will need to
            // redefine our assembly references to be full references in the scheduler
            // configuration.
            //
            // EXAMPLE: Assembly library = Assembly.Load("library, Version=2.0.0.0, Culture=Neutral, PublicKeyToken=9b184fc90fb9648d");
            //
            Type type = Assembly.GetExecutingAssembly().FullName.Split(',')[0] == assemblyName
                ? Assembly.GetExecutingAssembly().GetType(className)
                : Assembly.LoadFrom(assemblyName).GetType(className);

            ConstructorInfo constructorInformation = type.GetConstructor(Type.EmptyTypes);

            if (constructorInformation == null)
            {
                _log.Error($"Could not find a default constructor for {className} in assembly {assemblyName}");
                return;
            }

            //
            // Try to construct the specified class object.
            //
            if (!(constructorInformation.Invoke(null) is Domain.Task task))
            {
                _log.Error($"Could not create an object for {className} in assembly {assemblyName}");
                return;
            }

            try
            {
                Appointment appointment = CreateAppointment(configTask, task);

                //
                // Add the task to the master list of defined tasks.
                //
                lock (_appointmentsLock) { Appointments.Add(appointment); }

                //
                // Don't schedule disabled or ad hoc tasks.
                //
                if (!configTask.Enabled || configTask.TaskType == AppointmentType.AdHoc) { return; }

                //
                // Schedule the task to run as soon as possible.
                //
                DateTime scheduleTime = DetermineNextStartTime(appointment, true);
                lock (_scheduleLock) { Schedule.Add(new ScheduledAppointment(scheduleTime, appointment)); }
            }
            catch (Exception exception)
            {
                _log.Error($"Could not create scheduled task for task '{configTask.Name}'", exception);
            }
        }

        #endregion Internal Methods

        #region Private Methods

        /// <summary>
        /// Joins any completed threads and removes them from the list of active tasks.
        /// </summary>
        private void CleanUpCompletedTasks()
        {
            try
            {
                List<ActiveAppointment> deadTasks;
                lock (_runningAppointmentsLock)
                {
                    deadTasks = RunningTasks.Where(task => !task.Thread.IsAlive).ToList();
                }

                if (!deadTasks.Any()) return;

                //
                // Force any dead tasks to join the main thread and mark them as completed.
                // 
                Parallel.ForEach(
                    deadTasks,
                    task =>
                        {
                            task.Thread.Join();
                            task.Completed = true;
                            RecordTaskCompletion(task);
                            _log.Debug($"Task {task.Name} has completed with status {task.Task.CompletionStatus}.");
                        });

                ClearRetriesForSuccessfulDailyTasks(deadTasks);
                RescheduleFailedDailyTasks(deadTasks);

                //
                // Remove any tasks that are marked as completed.
                //
                lock (_runningAppointmentsLock)
                {
                    RunningTasks.RemoveAll(task => task.Completed);
                }
            }
            catch (Exception exception)
            {
                _log.Error("Error while cleaning up expired threads.", exception);
            }
        }

        private void ClearRetriesForSuccessfulDailyTasks(List<ActiveAppointment> tasks)
        {
            foreach (var task in tasks.Where(task => task.RunOncePerActiveDay && task.Task.CompletionStatus == TaskCompletionStatus.Succeeded))
            {
                _log.Debug($"Clearing retry status for daily task {task.Name}");
                task.TimesRetried = 0;
            }
        }

        private void RescheduleFailedDailyTasks(List<ActiveAppointment> appointments)
        {
            foreach (var appointment in appointments.Where(appt => appt.RunOncePerActiveDay && appt.Task.CompletionStatus == TaskCompletionStatus.Failed))
            {
                _log.Debug($"Scheduling task {appointment.Name} for retry.  Status is {appointment.Task.CompletionStatus}.");
                ScheduledAppointment scheduledTask;
                DateTime nextScheduledTime;

                lock (_scheduleLock) scheduledTask = Schedule.Find(t => t.Name == appointment.Name);

                if (scheduledTask == null) continue;

                if (++appointment.TimesRetried <= appointment.Retries)
                {
                    nextScheduledTime = DetermineNextStartTime(appointment, DateTime.Now, forRetry: true);
                }
                else
                {
                    _log.Warn($"Retry limit exceeded for the day for task {appointment.Name}.");

                    //
                    // Retry count has been exceeded.  Schedule for the next available task window.
                    //
                    appointment.TimesRetried = 0;
                    nextScheduledTime = DetermineNextStartTime(appointment, DateTime.Now, ignoreInterval: false, forRetry: false);
                }

                lock (_scheduleLock) scheduledTask.ScheduledTime = nextScheduledTime;
            }
        }

        /// <summary>
        /// Adds the supplied task to the ScheduledTasks list, scheduling its next run time.
        /// </summary>
        /// <param name="task">The task to schedule</param>
        /// <param name="ignoreInterval">Ignore the interval when scheduling the task</param>
        /// <remarks>
        /// Overloaded wrapper for the unit-testable version.  This version supplies the
        /// current date and time.
        /// </remarks>
        private static DateTime DetermineNextStartTime(Appointment task, bool ignoreInterval = false)
        {
            return DetermineNextStartTime(task, DateTime.Now, ignoreInterval);
        }

        /// <summary>
        /// Starts any task that is ready to execute and adds it to the list of active tasks.
        /// </summary>
        internal void ExecuteSchedule(object sender, ElapsedEventArgs e)
        {
            bool lockTaken = false;
            try
            {
                _log.Debug("Timer elapsed.  Looking for tasks to run.");
                TimeIntervalErrorTriggered = false;

                //
                // Check to see if our system timer is getting behind schedule.
                //
                var timeGapInMilliseconds = (DateTime.Now - _previousTimerTick).TotalMilliseconds;
                if (timeGapInMilliseconds > MaximumAcceptableDriftInMilliseconds)
                {
                    _log.Error($"{nameof(ExecuteSchedule)} should fire every {TimerIntervalInSeconds} second(s), but it has been {timeGapInMilliseconds / 1000:F3} seconds since the timer last fired.");
                    TimeIntervalErrorTriggered = true;
                }
                _previousTimerTick = DateTime.Now;

                //
                // We are adding a mutex here to protect this method from being executed by more
                // than one thread at a time.
                //
                Monitor.TryEnter(_executeScheduleLock, ref lockTaken);
                if (!lockTaken)
                {
                    _log.Error($"Could not obtain lock for {nameof(ExecuteSchedule)} because it is currently running on another thread.");
                    return;
                }

                CleanUpCompletedTasks();

                if (_stopped) { return; }

                UpdateGroupQueues();

                //
                // Check the schedule and start any tasks that are ready to go.
                //
                List<string> tasksToRemove = new List<string>();
                List<ScheduledAppointment> readyToRun;
                lock (_scheduleLock)
                {
                    //
                    // Get a list of tasks that are ready to be run.
                    //
                    readyToRun = Schedule.Where(task => task.ScheduledTime <= DateTime.Now).ToList();
                }

                foreach (ScheduledAppointment task in readyToRun)
                {
                    bool okayToRun = true;

                    //
                    // Make sure there's not an instance of this task already in play.
                    //
                    lock (_runningAppointmentsLock)
                    {
                        if (RunningTasks.Any(activeTask => activeTask.Name == task.Name))
                        {
                            //
                            // We don't just continue here because we want to reschedule
                            // the task.  So just set the "okay to run" flag to false.
                            //
                            okayToRun = false;
                        }
                    }

                    bool compatibleTask = true;
                    if (okayToRun) { okayToRun = compatibleTask = TaskIsCompatibleWithRunningJobs(task); }

                    //
                    // Schedule the next run time, but only if it is a scheduled task. We may be running
                    // an ad-hoc task that can't be re-scheduled.
                    //
                    if (task.AppointmentType == AppointmentType.Scheduled)
                    {
                        //
                        // If a task is determined to be incompatible with a currently running task,
                        // then schedule it to run as soon as reasonably possible and ignore its
                        // scheduled run interval.  Note that we still use DetermineNextStartTime()
                        // because we don't want to ignore the task's run window.
                        //
                        if (!compatibleTask)
                        {
                            task.ScheduledTime = DetermineNextStartTime(
                                task,
                                DateTime.Now.AddMinutes(1),
                                ignoreInterval: true);
                        }
                        else
                        {
                            task.ScheduledTime = DetermineNextStartTime(task);
                        }
                    }
                    else
                    {
                        //
                        // Note that if an ad hoc task is not okay to run, we just leave it as it is.  It's
                        // scheduled time will remain the same, making it "overdue" on subsequent ticks.
                        //
                        if (okayToRun)
                        {
                            //
                            // Mark the ad hoc task so that it gets removed from the schedule after it gets
                            // run so it's not retained for the next tick.
                            //
                            tasksToRemove.Add(task.Name);
                        }
                    }

                    if (!okayToRun)
                    {
                        _log.Debug(
                            $"Skipping execution of {task.Name} for this interval since it was marked as not okay to execute.");
                        continue;
                    }

                    try
                    {
                        _log.Debug($"Starting task {task.Name} - {task.ClassName}");

                        //
                        // Reset the request type to match the appointment type so that this 
                        // task does not continue look like it was the result of an ad hoc 
                        // request.
                        //
                        task.ExecutionRequestType = task.AppointmentType;

                        //
                        // Start the task.
                        //
                        task.LastRun = DateTime.Now;
                        task.Task.StopCalled = false; // GATM-423
                        Thread thread = new Thread(task.Task.Start);
                        thread.Start();

                        //
                        // Add the active task to our active tasks list.
                        //
                        lock (_runningAppointmentsLock) { RunningTasks.Add(new ActiveAppointment(thread, task)); }
                    }
                    catch (Exception exception)
                    {
                        _log.Error(
                            $"Error while attempting to run task {task.Name}",
                            exception);
                    }
                }

                //
                // Remove any ad hoc tasks from the schedule to keep it tidy.
                //
                lock (_scheduleLock)
                {
                    Schedule.RemoveAll(scheduledTask => tasksToRemove.Contains(scheduledTask.Name));
                }

                _log.Debug("Cycle completed.  Waiting for next timer tick.");
            }
            finally
            {
                if (lockTaken) Monitor.Exit(_executeScheduleLock);
            }
        }

        private void UpdateGroupQueues()
        {
            lock (_incompatibleTaskGroupsLock)
            {
                foreach (var group in _incompatibleTaskGroups)
                {
                    var queue = group.Value.Queue;

                    //
                    // There's no re-shuffling to do if we don't have at least two tasks in the queue.
                    //
                    if (queue.Count < 2) continue;

                    //
                    // Track the first task to make sure we aren't running in circles.
                    //
                    string firstTask = queue.Peek();
                    string mostRecentTask;
                    do
                    {
                        mostRecentTask = queue.Peek();
                        RequeueTaskIfOutsideOfExecutionWindow(queue);
                    } while (queue.Peek() != firstTask && queue.Peek() != mostRecentTask);
                }
            }
        }

        internal void RequeueTaskIfOutsideOfExecutionWindow(Queue<string> queue)
        {
            //
            // If the first task in the queue is outside of its execution window, pop it
            // and move it to the tail of the queue.
            //
            string taskNameToCheck = queue.Peek();
            Appointment task;
            lock (_appointmentsLock) { task = Appointments.FirstOrDefault(myTask => myTask.Name.Equals(taskNameToCheck)); }

            if (task?.AppointmentType != AppointmentType.AdHoc 
                && task?.ExecutionRequestType != AppointmentType.AdHoc 
                && task != null
                && !AppointmentExecutionWindowIsOpen(task, DateTime.Now))
            {
                _log.Info($"Moving task {task.Name} to the end of its queue because it is currently outside of its active window.");
                var taskName = queue.Dequeue();
                queue.Enqueue(taskName);
            }
        }

        internal static bool AppointmentExecutionWindowIsOpen(Appointment appointment, DateTime now)
        {
            if (appointment.AppointmentType == AppointmentType.AdHoc) return true;
            DateTime nextAvailableExecutionTime = DetermineNextStartTime(appointment, now, ignoreInterval: true);
            return nextAvailableExecutionTime == now;
        }

        private bool TaskIsCompatibleWithRunningJobs(ScheduledAppointment appointment)
        {
            bool okayToRun = true;

            //
            // See if the current task is part of any task groups.
            //
            _log.Debug($"Looking to see if task {appointment.Name} is in an incompatibility group.");

            lock (_incompatibleTaskGroupsLock)
            {
                List<IncompatibleTasksGroup> groups = _incompatibleTaskGroups
                    .Where(group => group.Value.Tasks.Any(taskName => taskName == appointment.Name))
                    .Select(group => group.Value)
                    .ToList();


                if (groups.Any())
                {
                    _log.Debug($"Task {appointment.Name} is in {groups.Count} group(s).");
                    //
                    // If the task participates in any groups, then see if any other tasks in the groups are already running.
                    //
                    foreach (var group in groups)
                    {
                        foreach (var currentlyRunningTaskName in group.Tasks.Where(taskName => taskName != appointment.Name))
                        {
                            lock (_runningAppointmentsLock)
                            {
                                if (RunningTasks.Any(activeTask => activeTask.Name == currentlyRunningTaskName))
                                {
                                    _log.Info(
                                        $"Task {appointment.Name} cannot be run now because it conflicts with task {currentlyRunningTaskName}, which is already running.");
                                    okayToRun = false;

                                    if (!group.Queue.Contains(appointment.Name))
                                    {
                                        group.Queue.Enqueue(appointment.Name);
                                        _log.Info($"Task {appointment.Name} has been queued.");
                                    }
                                    else
                                    {
                                        _log.Info($"Task {appointment.Name} was not queued because it is already on the group's queue.");
                                    }
                                }
                            }
                        }
                    }

                    //
                    // So here it gets a bit more complicated.  We don't want a task with a short interval
                    // to "hog" any incompatible tasks groups that it participates in.  So we are only going
                    // to allow the current task to run if it is at the head of one if its queues.
                    //
                    // First check to see if the queues are empty or not.  If all of the queues are empty,
                    // then it's okay to run the current task.  Otherwise, we need to see if the task is
                    // at the head of any of the queues it is associated with.
                    //
                    if (okayToRun && groups.Any(group => group.Queue.Count > 0))
                    {
                        bool atHeadOfAQueue = false;
                        var group = groups.FirstOrDefault(tasksGroup => tasksGroup.Queue.Peek() == appointment.Name);
                        if (group != null)
                        {
                            _log.Info(
                                $"Task {appointment.Name} was found at the head of an incompatible tasks queue.  Removing from queue and setting task as okay to run.");
                            atHeadOfAQueue = true;
                            group.Queue.Dequeue(); // Pop it, but don't do anything with it.
                        }

                        if (!atHeadOfAQueue)
                        {
                            _log.Info(
                                $"Task {appointment.Name} was not at the front of any incompatible tasks queues.  It will not be run during this cycle.");
                            okayToRun = false;

                            //
                            // Add the task to all of its respective queues.
                            //
                            int count = 0;
                            foreach (var tasksGroup in groups.Where(tasksGroup => tasksGroup.Queue.Count > 0 && !tasksGroup.Queue.Contains(appointment.Name)))
                            {
                                tasksGroup.Queue.Enqueue(appointment.Name);
                                _log.Info($"Added {appointment.Name} to queue #{++count}.");
                            }
                        }
                        else if (groups.Count > 1)
                        {
                            _log.Debug(
                                $"Removing {appointment.Name} from all queues since it has been cleared to execute.");
                            //
                            // Make sure that the current task is removed from all Queues it may be on.  This is
                            // kind of a brute force method of doing that.
                            //
                            foreach (var tasksGroup in groups)
                            {
                                tasksGroup.Queue = new Queue<string>(
                                    tasksGroup.Queue.Where(taskName => taskName != appointment.Name).ToArray());
                            }
                        }
                    }
                }
            }

            return okayToRun;
        }

        /// <summary>
        /// We use the term "task" here because that is the verbiage used in the client, plus
        /// this is really a hybrid status of the appointment and its encapsulated task.
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        private TaskStatus GetTaskStatus(Appointment appointment)
        {
            DateTime? scheduled = null;
            DateTime? lastRun = null;
            TaskCompletionStatus lastCompletionStatus = TaskCompletionStatus.NotRun;
            bool running;

            ScheduledAppointment scheduledAppointment;
            lock (_scheduleLock)
            {
                scheduledAppointment =
                    Schedule
                        .OrderBy(tempAppointment => tempAppointment.ScheduledTime)
                        .FirstOrDefault(tempAppointment => tempAppointment.Name == appointment?.Name);
            }

            if (scheduledAppointment != null)
            {
                scheduled = scheduledAppointment.ScheduledTime;
                lastRun = scheduledAppointment.LastRun;
                lastCompletionStatus = scheduledAppointment.Task.CompletionStatus;
            }

            lock (_runningAppointmentsLock)
            {
                ActiveAppointment activeAppointment = RunningTasks.FirstOrDefault(active => active.Name == appointment?.Name);
                running = activeAppointment != null;
            }

            TaskStatus taskStatus = new TaskStatus(appointment, scheduled, running, lastRun, lastCompletionStatus);
            return taskStatus;
        }

        /// <summary>
        /// Sets up a timer to fire at a regular interval.
        /// </summary>
        private void InitializeTimer()
        {
            try
            {
                if (_timer != null)
                {
                    _previousTimerTick = DateTime.Now;

                    _timer.AutoReset = true;
                    _timer.Interval = Convert.ToDouble(TimerIntervalInSeconds * 1000);
                    _timer.Enabled = true;
                    _timer.Elapsed += ExecuteSchedule;
                    _timer.Start();

                    _log.Info("Service timer initialized.");
                }
            }
            catch (Exception exception)
            {
                _log.Error(exception);
            }
        }

        private void RecordTaskCompletion(ActiveAppointment activeAppointment)
        {
            //
            // Record the encapsulated task's completion status for the appointment.
            //
            ScheduledAppointment scheduledAppointment;
            lock (_scheduleLock)
            {
                scheduledAppointment =
                    Schedule
                        .OrderBy(appointment => appointment.ScheduledTime)
                        .FirstOrDefault(appointment => appointment.Name == activeAppointment.Name);
            }

            if (scheduledAppointment != null)
            {
                _log.Debug($"Recording completion status of {activeAppointment.Task.CompletionStatus} for task {activeAppointment.Name}");
                scheduledAppointment.Task.CompletionStatus = activeAppointment.Task.CompletionStatus;
            }
        }

        private static bool ValidAppointmentDate(Appointment appointment, DateTime scheduledDateTime)
        {
            bool valid = true;
            if (!appointment.RunEveryMonth)
            {
                valid = appointment
                    .ActiveMonths
                    .Contains(
                        scheduledDateTime.ToString("MMM"),
                        StringComparer.InvariantCultureIgnoreCase);
            }

            if (!valid) return false;

            if (!appointment.RunEveryDayOfTheMonth)
            {
                valid = appointment
                    .ActiveDaysOfTheMonth
                    .Contains(scheduledDateTime.Day) ||
                        (appointment.ActiveDaysOfTheMonth.Contains(0) &&
                         scheduledDateTime.Day == DateTime.DaysInMonth(scheduledDateTime.Year, scheduledDateTime.Month));
            }

            if (!valid) return false;

            if (!appointment.RunEveryWeekday)
            {
                valid = appointment
                    .ActiveWeekDays
                    .Contains(
                        scheduledDateTime.DayOfWeek.ToString().Substring(0, 3),
                        StringComparer.InvariantCultureIgnoreCase);
            }

            if (!valid) return false;

            if (!appointment.WeekdayOrdinal.Equals("All", StringComparison.InvariantCultureIgnoreCase))
            {
                //
                // TODO: Consider caching this value for a given year and month.
                // This is really expensive to do over and over.
                //
                DateTime ordinalDate = GetWeekDayOrdinalDateForYearAndMonth(
                    appointment.WeekdayOrdinal,
                    appointment.ActiveWeekDays[0],
                    scheduledDateTime);

                valid = scheduledDateTime.Date == ordinalDate.Date;
            }

            return valid;
        }

        private static DateTime GetWeekDayOrdinalDateForYearAndMonth(
            string ordinalString,
            string dayOfWeekString,
            DateTime scheduledDateTime)
        {
            int weekOrdinal = CalendarHelpers.OrdinalValue(ordinalString);

            DayOfWeek day = CalendarHelpers.WeekDay(dayOfWeekString);

            var dateScanner = new DateTime(scheduledDateTime.Year, scheduledDateTime.Month, 1);
            int weekDaysFound = 0;
            DateTime foundDate = DateTime.MaxValue;
            while (dateScanner.Month == scheduledDateTime.Month)
            {
                if (dateScanner.DayOfWeek == day)
                {
                    foundDate = dateScanner;
                    if (++weekDaysFound == weekOrdinal) break;
                }

                dateScanner = dateScanner.AddDays(1);
            }

            return foundDate;
        }

        private static DateTime SetScheduledTime(
            Appointment appointment,
            DateTime currentDateTime,
            bool ignoreInterval,
            bool forRetry,
            DateTime startTime,
            DateTime endTime)
        {
            DateTime scheduledTime;
            if (ignoreInterval)
            {
                //
                // Assume we can run right now.  This will get adjusted if it's not okay to run right now.
                //
                scheduledTime = currentDateTime;
            }
            else
            {
                scheduledTime = appointment.RunOncePerActiveDay && !forRetry
                    ? endTime
                    : currentDateTime.AddMinutes(appointment.RunIntervalInMinutes);
            }

            //
            // If we are before the scheduled start, just schedule for the start time.
            //
            if (scheduledTime < startTime) scheduledTime = startTime;
            else if (!scheduledTime.Between(startTime, endTime))
            {
                //
                // The scheduled time is outside of the window and not earlier than the current day's start, 
                // so advance to the next day.
                //
                scheduledTime = startTime.AddDays(1);
                appointment.TimesRetried = 0;
            }

            //
            // Deal with the odd edge case where the current time is earlier than the start time but
            // the interval causes the scheduled time to dip into the window.  
            //
            // This resolves issues where we should be using the start time, but the interval pushes
            // the first available time beyond the start of the window.
            //
            // For example: if the start time is 8:00 AM and the interval is one hour, we would 
            // calculate the next start time as 8:12 AM if the application was started at 7:12 AM.
            // This bit ensures that the appointment gets scheduled for 8:00 AM instead rather than
            // having a delayed start.
            //
            if (!ignoreInterval && scheduledTime.AddMinutes(-appointment.RunIntervalInMinutes) < startTime)
            {
                scheduledTime = startTime;
            }

            return scheduledTime;
        }

        private static DateTime AdjustActivityWindowForWindowsThatCrossMidnight(DateTime currentDateTime, DateTime endTime, ref DateTime startTime)
        {
            //
            // If the window crosses midnight, then adjust start or end by a day based upon where the current time
            // sits with respect to the window.
            //
            if (endTime < startTime)
            {
                if (currentDateTime < endTime)
                {
                    //
                    // The current time is between midnight and the end time, so adjust the start time
                    // back by a day.
                    // 
                    startTime = startTime.AddDays(-1);
                }
                else
                {
                    //
                    // The current time is past the end time (and now before the start), so adjust the
                    // end time forward by a day.
                    //
                    endTime = endTime.AddDays(1);
                }
            }

            return endTime;
        }

        #endregion Private Methods
    }
}