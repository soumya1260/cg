﻿using System;

namespace Cigna.TaskScheduling.Exceptions
{
    [Serializable]
    public class InvalidDateBoundariesException : Exception
    {
        public InvalidDateBoundariesException()
            : this("initialRun date must be less than finalRun date.")
        { }
        public InvalidDateBoundariesException(string message) : base(message) { }
        public InvalidDateBoundariesException(string message, Exception inner) : base(message, inner) { }
        protected InvalidDateBoundariesException(
            System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}