﻿using System;

namespace Cigna.TaskScheduling.Exceptions
{
    [Serializable]
    public class IncompatibleWeekdayOrdinalConditionsException : Exception
    {
        public IncompatibleWeekdayOrdinalConditionsException() : this("You must supply a single weekday under activeDays when using a weekdayOrdinal other than 'All'.") { }
        public IncompatibleWeekdayOrdinalConditionsException(string message) : base(message) { }
        public IncompatibleWeekdayOrdinalConditionsException(string message, Exception inner) : base(message, inner) { }
        protected IncompatibleWeekdayOrdinalConditionsException(
            System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}