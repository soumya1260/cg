﻿using System;

namespace Cigna.TaskScheduling.Exceptions
{
    [Serializable]
    public class IncompatibleDaysConfigurationException : Exception
    {
        public IncompatibleDaysConfigurationException()
            : this("You can configure either 'days' (days of the month) or 'activeDays' (weekdays).  You cannot use both.")
        { }
        public IncompatibleDaysConfigurationException(string message) : base(message) { }
        public IncompatibleDaysConfigurationException(string message, Exception inner) : base(message, inner) { }
        protected IncompatibleDaysConfigurationException(
            System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}