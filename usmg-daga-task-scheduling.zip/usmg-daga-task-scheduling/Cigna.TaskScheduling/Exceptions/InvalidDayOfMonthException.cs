﻿using System;

namespace Cigna.TaskScheduling.Exceptions
{
    [Serializable]
    public class InvalidDayOfMonthException : Exception
    {
        private static string FormatMessage(int day, string month) =>
            $"Day {day} is incompatible with {month}.  Did you mean 'Last'?";

        public InvalidDayOfMonthException() { }

        public InvalidDayOfMonthException(int day, string month) : base(FormatMessage(day, month)) { }

        public InvalidDayOfMonthException(string message) : base(message) { }
        public InvalidDayOfMonthException(string message, Exception inner) : base(message, inner) { }
        protected InvalidDayOfMonthException(
            System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}