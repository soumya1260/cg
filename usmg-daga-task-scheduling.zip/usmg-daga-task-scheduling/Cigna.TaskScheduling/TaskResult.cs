﻿namespace Cigna.TaskScheduling
{
    /// <summary>
    /// Result enumeration for ad hoc run requests.
    /// </summary>
    public enum TaskRunRequestResult
    {
        Succeeded,
        Failed,
        TaskDoesNotExist,
        TaskIsDisabled
    }
}