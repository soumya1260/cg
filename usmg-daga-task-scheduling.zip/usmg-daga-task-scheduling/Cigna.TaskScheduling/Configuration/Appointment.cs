﻿using Cigna.TaskScheduling.Domain;
using System;
using System.ComponentModel;
using System.Configuration;

namespace Cigna.TaskScheduling.Configuration
{
    [Description("Configuration element for a single task.")]
    public class Appointment : ConfigurationElement
    {
        private const string TimeRegEx      = @"^(?:0{0,1}[1-9]|1[0-2]):[0-5][0-9] (?i:[AP]M)$";
        private const string DaysRegEx      = @"^(?i:All|(?:(?:Sun|Mon|Tue|Wed|Thu|Fri|Sat), *)*(?:Sun|Mon|Tue|Wed|Thu|Fri|Sat))$";
        private const string MonthsRegEx    = @"^(?i:All|(?:(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec), *)*(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec))$";
        private const string OrdinalsRegEx  = @"^(?i:All|(?:First|Second|Third|Fourth|Last))$";
        private const string MonthDaysRegEx = @"^(?i:All|(?:(?:\d{1,2}|Last), *)*(?:\d{1,2}|Last))$";

        public Appointment() : base() {}

        public Appointment(
            string name,
            string assemblyName,
            string className,
            bool enabled,
            string startTime,
            string stopTime,
            int runInterval,
            string activeDays,
            bool runEveryDay,
            bool runOncePerActiveDay,
            int retries,
            AppointmentType appointmentType,
            string activeMonths,
            string activeDaysOfTheMonth,
            DateTime initialRun,
            DateTime finalRun,
            string weekdayOrdinal) : base()
        {
            this["name"] = name;
            this["assemblyName"] = assemblyName;
            this["className"] = className;
            this["enabled"] = enabled;
            this["startTime"] = startTime;
            this["stopTime"] = stopTime;
            this["runIntervalInMinutes"] = runInterval;
            this["activeDays"] = activeDays;
            this["runEveryDay"] = runEveryDay;
            this["runOncePerActiveDay"] = runOncePerActiveDay;
            this["retries"] = retries;
            this["type"] = appointmentType;
            this["months"] = activeMonths;
            this["days"] = activeDaysOfTheMonth;
            this["initialRun"] = initialRun;
            this["finalRun"] = finalRun;
            this["weekdayOrdinal"] = weekdayOrdinal;
        }
        
        [ConfigurationProperty("name", IsKey = true),
         Description("The name of the task.  This will be used for display and also for starting/stopping a task.")]
        public string Name => (string)this["name"];

        [ConfigurationProperty("assemblyName"),
        Description("The name of the assembly containing the task.")]
        public string AssemblyName => (string)this["assemblyName"];

        [ConfigurationProperty("className"), 
        Description("The name of the task.")]
        public string ClassName => (string)this["className"];

        [ConfigurationProperty("enabled", DefaultValue = true),
         Description("Indicates whether the task is enabled and can be started or not.")]
        public bool Enabled => (bool)this["enabled"];

        [ConfigurationProperty("startTime", DefaultValue = "12:00 AM")]
        [RegexStringValidator(TimeRegEx)]
        [Description("The start time of the active task window expressed as an AM/PM value relative to system local time.")]
        public string StartTime => (string)this["startTime"];

        [ConfigurationProperty("stopTime", DefaultValue = "12:00 AM")]
        [RegexStringValidator(TimeRegEx)]
        [Description("The end time of the active task window expressed as an AM/PM value relative to system local time.")]
        public string StopTime => (string)this["stopTime"];

        [ConfigurationProperty("runIntervalInMinutes", DefaultValue = 1)]
        [IntegerValidator]
        [Description("How often (in minutes) the task should run within the active task window.")]
        public int RunIntervalInMinutes => (int)this["runIntervalInMinutes"];

        [ConfigurationProperty("activeDays", DefaultValue = "All"), RegexStringValidator(DaysRegEx)]
        [Description("A list of days that the active task window is valid expressed as three-character day values or \"All\".")]
        public string ActiveWeekDays => (string)this["activeDays"];

        [ConfigurationProperty("runEveryDay", DefaultValue = false)]
        [Description("An alternative to activeDays=\"All\".")]
        public bool RunEveryWeekDay => (bool)this["runEveryDay"];

        [ConfigurationProperty("runOncePerActiveDay", DefaultValue = false)]
        [Description("Is this a daily task that should only run once per active day?")]
        public bool RunOncePerActiveDay => (bool)this["runOncePerActiveDay"];

        [ConfigurationProperty("retries", DefaultValue = 0)]
        [IntegerValidator]
        [Description("Number of times to retry a daily task if it fails")]
        public int Retries => (int)this["retries"];
        
        [ConfigurationProperty("type", DefaultValue = AppointmentType.Scheduled)]
        [Description("Is this a scheduled or ad-hoc task?")]
        public AppointmentType TaskType => (AppointmentType) this["type"];

        [ConfigurationProperty("months", DefaultValue="All"), RegexStringValidator(MonthsRegEx)]
        [Description("Months to apply this appointment")]
        public string ActiveMonths => (string)this["months"];

        [ConfigurationProperty("days", DefaultValue = "All"), RegexStringValidator(MonthDaysRegEx)]
        [Description("Days of the month to apply to this appointment")]
        public string ActiveDaysOfTheMonth => (string)this["days"];

        [ConfigurationProperty("initialRun", DefaultValue = "0001-JAN-01")]
        [Description("The date when the appointment will become effective")]
        public DateTime InitialRun
        {
            get => (DateTime)this["initialRun"];
            set => this["initialRun"] = value;
        }

        [ConfigurationProperty("finalRun", DefaultValue = "9999-12-31")]
        [Description("The date after which the appointment will no longer run")]
        public DateTime FinalRun 
        {
            get => (DateTime)this["finalRun"];
            set => this["finalRun"] = value;
        }

        [ConfigurationProperty("weekdayOrdinal", DefaultValue = "All"), RegexStringValidator(OrdinalsRegEx)]
        [Description("A single ordinal value used to indicate the ordinal value of the weekday to schedule.")]
        public string WeekdayOrdinal => (string)this["weekdayOrdinal"];
    }
}