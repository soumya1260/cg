﻿using System.Configuration;

namespace Cigna.TaskScheduling.Configuration
{
    public class IncompatibleTasksGroup: ConfigurationElement
    {
        [ConfigurationProperty("name", IsKey = true)]
        public string Name => (string)this["name"];

        [ConfigurationProperty("tasks")]
        public IncompatibleTasksCollection Tasks => (IncompatibleTasksCollection)this["tasks"];
    }
}