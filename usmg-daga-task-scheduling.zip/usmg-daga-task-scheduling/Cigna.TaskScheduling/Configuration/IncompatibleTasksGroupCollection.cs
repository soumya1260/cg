﻿using System.Configuration;

namespace Cigna.TaskScheduling.Configuration
{
    // ReSharper disable once ClassNeverInstantiated.Global
    public class IncompatibleTasksGroupCollection : ConfigurationElementCollection
    {
        /// <inheritdoc />
        protected override ConfigurationElement CreateNewElement()
        {
            return new IncompatibleTasksGroup();
        }

        /// <inheritdoc />
        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((IncompatibleTasksGroup)element).Name;
        }

        protected override string ElementName => "group";

        protected override bool IsElementName(string elementName)
        {
            return !string.IsNullOrEmpty(elementName) && elementName == ElementName;
        }

        public override ConfigurationElementCollectionType CollectionType => ConfigurationElementCollectionType.BasicMap;

        public IncompatibleTasksGroup this[int index] => BaseGet(index) as IncompatibleTasksGroup;

        public new IncompatibleTasksGroup this[string key] => BaseGet(key) as IncompatibleTasksGroup;
    }
}