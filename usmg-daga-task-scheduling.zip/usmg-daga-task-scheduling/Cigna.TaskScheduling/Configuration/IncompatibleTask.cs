﻿using System.Configuration;

namespace Cigna.TaskScheduling.Configuration
{
    public class IncompatibleTask: ConfigurationElement
    {
        [ConfigurationProperty("name", IsKey = true)]
        public string Name => (string)this["name"];
    }
}