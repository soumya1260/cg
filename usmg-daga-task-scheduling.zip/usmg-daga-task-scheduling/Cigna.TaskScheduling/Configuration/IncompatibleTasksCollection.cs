﻿using System.Configuration;

namespace Cigna.TaskScheduling.Configuration
{
    // ReSharper disable once ClassNeverInstantiated.Global
    public class IncompatibleTasksCollection: ConfigurationElementCollection
    {
        /// <inheritdoc />
        protected override ConfigurationElement CreateNewElement()
        {
            return new IncompatibleTask();
        }

        /// <inheritdoc />
        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((IncompatibleTask)element).Name;
        }

        protected override string ElementName => "task";

        protected override bool IsElementName(string elementName)
        {
            return !string.IsNullOrEmpty(elementName) && elementName == ElementName;
        }

        public override ConfigurationElementCollectionType CollectionType => ConfigurationElementCollectionType.BasicMap;

        public IncompatibleTask this[int index] => BaseGet(index) as IncompatibleTask;

        public new IncompatibleTask this[string key] => BaseGet(key) as IncompatibleTask;    }
}