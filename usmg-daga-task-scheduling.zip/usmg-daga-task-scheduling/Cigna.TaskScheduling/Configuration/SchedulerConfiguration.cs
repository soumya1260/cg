﻿using System.ComponentModel;
using System.Configuration;

namespace Cigna.TaskScheduling.Configuration
{
    public class SchedulerConfiguration : ConfigurationSection
    {
        [ConfigurationProperty("tasks", IsDefaultCollection = true, IsKey = false, IsRequired = true),
         Description("Configuration container for a list of scheduling tasks.")]
        public AppointmentCollection Appointments
        {
            get => base["tasks"] as AppointmentCollection;
            set => base["tasks"] = value;
        }

        [ConfigurationProperty("incompatibleTasks", IsRequired = false)]
        public IncompatibleTasksGroupCollection IncompatibleTasksGroups
        {
            get => base["incompatibleTasks"] as IncompatibleTasksGroupCollection;
            set => base["incompatibleTasks"] = value;
        }
    }
}