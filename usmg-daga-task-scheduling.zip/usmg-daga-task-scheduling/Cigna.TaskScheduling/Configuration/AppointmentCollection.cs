﻿using System.Configuration;

namespace Cigna.TaskScheduling.Configuration
{
    /// <summary>
    /// Key/Value collection mapper for tasks.
    /// </summary>
    // ReSharper disable once ClassNeverInstantiated.Global
    public class AppointmentCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new Appointment();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((Appointment)element).Name;
        }

        protected override string ElementName => "task";

        protected override bool IsElementName(string elementName)
        {
            return !string.IsNullOrEmpty(elementName) && elementName == ElementName;
        }

        public override ConfigurationElementCollectionType CollectionType => ConfigurationElementCollectionType.BasicMap;

        public Appointment this[int index] => BaseGet(index) as Appointment;

        public new Appointment this[string key] => BaseGet(key) as Appointment;
    }
}