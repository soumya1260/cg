﻿using System.Collections.Generic;

namespace Cigna.TaskScheduling
{
    /// <summary>
    /// Represents a group of tasks that cannot be run at the same time and a queue for 
    /// prioritizing which task can run next when there are conflicts.
    /// </summary>
    internal class IncompatibleTasksGroup
    {
        public Queue<string> Queue { get; set; }
        public List<string> Tasks { get; set; }
    }
}