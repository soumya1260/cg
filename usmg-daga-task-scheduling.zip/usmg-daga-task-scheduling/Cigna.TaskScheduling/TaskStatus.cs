﻿using Cigna.TaskScheduling.Domain;
using System;

namespace Cigna.TaskScheduling
{
    /// <summary>
    /// Presentation model representing information about the task and its appointment state.
    /// </summary>
    public class TaskStatus
    {
        #region Public Constructors

        public TaskStatus(
                    Appointment appointment,
                    DateTime? scheduledTime = null,
                    bool running = false,
                    DateTime? lastRun = null,
                    TaskCompletionStatus lastRunStatus = TaskCompletionStatus.NotRun)
        {
            Name = appointment.Name;
            StartTime = appointment.StartTime;
            StopTime = appointment.StopTime;
            RunIntervalInMinutes = appointment.RunIntervalInMinutes;
            Enabled = appointment.Enabled;
            RunEveryDay = appointment.RunEveryWeekday;
            ActiveDays = appointment.ActiveWeekDays == null ? "All" : string.Join(", ", appointment.ActiveWeekDays);
            ScheduledTime = scheduledTime;
            Running = running;
            LastRunStatus = CompletionStatusString(lastRunStatus);

            string HasNotRun()
            {
                return appointment.Enabled ? "Has not run" : string.Empty;
            }

            LastRun = lastRun != null ? lastRun.ToString() : HasNotRun();
        }

        #endregion Public Constructors

        #region Public Properties

        // ReSharper disable MemberCanBePrivate.Global
        // ReSharper disable UnusedAutoPropertyAccessor.Global
        // ReSharper disable AutoPropertyCanBeMadeGetOnly.Global
        
        public string ActiveDays { get; set; }

        public bool Enabled { get; set; }

        public string LastRun { get; set; }

        public string LastRunStatus { get; set; }

        public string Name { get; set; }
        public bool RunEveryDay { get; set; }
        public int RunIntervalInMinutes { get; set; }
        public bool Running { get; set; }
        public DateTime? ScheduledTime { get; set; }
        public string StartTime { get; set; }
        public string StopTime { get; set; }

        // ReSharper restore AutoPropertyCanBeMadeGetOnly.Global
        // ReSharper restore UnusedAutoPropertyAccessor.Global
        // ReSharper restore MemberCanBePrivate.Global

        #endregion Public Properties

        #region Private Methods

        private static string CompletionStatusString(TaskCompletionStatus lastRunStatus)
        {
            switch (lastRunStatus)
            {
                case TaskCompletionStatus.Failed: return "Failed";
                case TaskCompletionStatus.NotRun: return "Not run";
                case TaskCompletionStatus.Stopped: return "Stopped";
                case TaskCompletionStatus.Succeeded: return "Succeeded";
                default: return string.Empty;
            }
        }

        #endregion Private Methods
    }
}