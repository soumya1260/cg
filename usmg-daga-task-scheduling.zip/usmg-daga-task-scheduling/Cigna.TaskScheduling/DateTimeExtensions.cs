﻿using System;

namespace Cigna.TaskScheduling
{
    public static class DateTimeExtensions
    {
        public static bool Between(this DateTime target, DateTime start, DateTime end)
        {
            return (start <= target && target < end);
        }
    }
}