﻿using System;

namespace Cigna.TaskScheduling
{
    public class ScheduledAppointment : Appointment
    {
        public DateTime ScheduledTime { get; set; }
        public DateTime? LastRun { get; set; }

        public ScheduledAppointment(DateTime scheduledTime, Appointment appointment) : base(appointment)
        {
            ScheduledTime = scheduledTime;
            LastRun = null;
        }
    }
}