﻿#
# Extract the proposed version number from VersionInfo.cs
#
$build = $ENV:BUILD_ID;
$version = (Select-String -Path VersionInfo.cs 'AssemblyVersion\("(\d+\.\d+\.\d+)' -AllMatches | ForEach-Object {$_.Matches} | ForEach-Object {$_.Groups[1].Value})
$version = "$version.$build";

#
# Update the PackageVersion field in each file.
# 
Get-ChildItem -Recurse -Path . -Filter *.csproj | ForEach-Object {
    $fileName = $_.FullName;
    (Get-Content $fileName) -replace "<PackageVersion>.*</PackageVersion>", "<PackageVersion>$version</PackageVersion>" | Out-File $fileName;
}
