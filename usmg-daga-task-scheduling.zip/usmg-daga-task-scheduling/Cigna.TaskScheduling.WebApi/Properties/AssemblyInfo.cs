﻿using System.Resources;
using System.Runtime.InteropServices;

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("53f3d890-2d8a-45b3-bdf2-6771d8038acd")]
[assembly: NeutralResourcesLanguage("en-US")]
