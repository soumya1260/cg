﻿using System.Web.Http;
using System.Web.Http.SelfHost;
// ReSharper disable UnusedType.Global

namespace Cigna.TaskScheduling.WebApi
{
    public class ServiceActivator
    {
        /// <summary>
        /// Starts the self-hosted REST API for scheduling.
        /// </summary>
        // ReSharper disable once UnusedMember.Global
        public virtual void Start(string protocol, string endpoint)
        {
            string serviceEndpointUrl = $"{protocol}://localhost/{endpoint}";
            HttpSelfHostConfiguration config = new HttpSelfHostConfiguration(serviceEndpointUrl);

            config.Routes.MapHttpRoute(
                "DefaultRoute",
                "{controller}/{action}/{id}",
                new { id = RouteParameter.Optional });

            config.Formatters.XmlFormatter.SupportedMediaTypes.Clear();
            config.Formatters.JsonFormatter.SupportedMediaTypes.Add(
                new System.Net.Http.Headers.MediaTypeHeaderValue("application/json"));

            HttpSelfHostServer server = new HttpSelfHostServer(config);
            server.OpenAsync().Wait();
        }
    }
}