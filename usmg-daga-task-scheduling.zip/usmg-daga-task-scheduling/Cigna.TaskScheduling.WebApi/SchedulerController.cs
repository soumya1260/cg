﻿using Cigna.TaskScheduling.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Reflection;
using System.Text;
using System.Web.Http;

namespace Cigna.TaskScheduling.WebApi
{
    /// <summary>
    ///     Scheduling controller with diagnostics.
    /// </summary>
    /// <remarks>
    ///     This services the URI path that looks like:
    /// 
    ///         {protocol}://localhost/{serviceEndpoint}/Scheduler/{action}/{id}
    ///
    ///     For example: http://localhost/myApp.Cigna.Com/Scheduler/StartTask/ClearCache
    ///     assuming a task named "ClearCache" has been defined and configured.
    /// </remarks>
    //
    // TODO: The return types of the public methods in this controller do not conform to Web API 2.
    //       These need to be re-written as async Tasks using some form of IHttpActionResult.
    //       C.f.: https://docs.microsoft.com/en-us/aspnet/web-api/overview/getting-started-with-aspnet-web-api/action-results
    //
    public class SchedulerController : ApiController
    {
        private readonly Scheduler _scheduler = Scheduler.Instance;

        #region Public web methods

        /// <summary>
        ///     Returns all of the tasks that the Scheduler knows about, including disabled tasks.
        /// </summary>
        /// <returns>
        ///     an <cref see="Cigna.TaskScheduling.Domain.ApiResponse">ApiResponse</cref> object with
        ///     the result of the request
        /// </returns>
        [HttpGet]
        [Description("Gets a list of all scheduled tasks managed by this scheduler instance.")]
        [Route("~/Scheduler/GetAllScheduledTasks")]
        public ApiResponse GetAllScheduledTasks()
        {
            var apiResponse = new ApiResponse
            {
                Successful = true,
                Response = _scheduler.GetAppointments(),
                Message = ""
            };
            return apiResponse;
        }

        [HttpGet]
        [Description("Gets detail information about the requested task.")]
        [Route("~/Scheduler/GetTask/{taskName}")]
        public ApiResponse GetTask(string taskName)
        {
            TaskStatus task = _scheduler.GetTask(taskName);

            var apiResponse = new ApiResponse
            {
                Successful = task == null,
                Response = task,
                Message = task == null ? $"No task found matching the name {taskName}" : string.Empty
            };

            return apiResponse;
        }

        /// <summary>
        ///     Attempts to start the specified task.
        /// </summary>
        /// <param name="taskName">a string containing the name of the task to be started</param>
        /// <returns>
        ///     an <cref see="Cigna.TaskScheduling.Domain.ApiResponse">ApiResponse</cref> object with
        ///     the result of the request
        /// </returns>
        [HttpPost]
        [Description("Attempts to start the specified task.")]
        [Route("~/Scheduler/StartTask/{taskName}")]
        public ApiResponse StartTask(string taskName)
        {
            switch (_scheduler.StartTask(taskName))
            {
                case TaskRunRequestResult.TaskDoesNotExist:
                    return new ApiResponse
                        { Message = "Task not found in Schedule", Successful = false, Response = null };

                case TaskRunRequestResult.TaskIsDisabled:
                    return new ApiResponse { Message = "Task is disabled", Successful = false, Response = null };

                case TaskRunRequestResult.Succeeded:
                    return new ApiResponse
                        { Message = "Task scheduled to start on next cycle", Successful = true, Response = true };

                default: // Not possible.
                    return new ApiResponse();
            }
        }

        /// <summary>
        ///     Attempts to stop a running task.
        /// </summary>
        /// <param name="taskName">a string containing the name of the task to be stopped</param>
        /// <returns>
        ///     an <cref see="Cigna.TaskScheduling.Domain.ApiResponse">ApiResponse</cref> object with
        ///     the result of the request
        /// </returns>
        [HttpPost]
        [Route("~/Scheduler/StopTask/{taskName}")]
        public ApiResponse StopTask(string taskName)
        {
            switch (_scheduler.StopTask(taskName))
            {
                case TaskRunRequestResult.Succeeded:
                    return new ApiResponse { Message = "Task stopped", Successful = true, Response = true };
                case TaskRunRequestResult.Failed:
                    return new ApiResponse { Message = "Error stopping task", Successful = false, Response = null };
                case TaskRunRequestResult.TaskDoesNotExist:
                    return new ApiResponse
                        { Message = "Task was not running or does not exist", Successful = false, Response = null };
            }

            return new ApiResponse();
        }

        /// <summary>
        ///     Attempts to stop all running tasks.
        /// </summary>
        /// <returns>
        ///     an <cref see="Cigna.TaskScheduling.Domain.ApiResponse">ApiResponse</cref> object with
        ///     the result of the request
        /// </returns>
        [HttpPost]
        [Route("~/Scheduler/StopAllTasks")]
        public ApiResponse StopAllTasks()
        {
            switch (_scheduler.StopAllTasks())
            {
                case TaskRunRequestResult.Succeeded:
                    return new ApiResponse { Message = "Task stop requests sent", Successful = true, Response = true };
                case TaskRunRequestResult.Failed:
                    return new ApiResponse
                        { Message = "Error stopping all tasks", Successful = false, Response = null };
            }

            return new ApiResponse();
        }

        /// <summary>
        ///     Terminates the specified task.
        /// </summary>
        /// <param name="taskName">a string containing the name of the task to be terminated</param>
        /// <returns>
        ///     an <cref see="Cigna.TaskScheduling.Domain.ApiResponse">ApiResponse</cref> object with
        ///     the result of the request
        /// </returns>
        [HttpPost]
        [Route("~/Scheduler/KillTask/{taskName}")]
        public ApiResponse KillTask(string taskName)
        {
            switch (_scheduler.KillTask(taskName))
            {
                case TaskRunRequestResult.Succeeded:
                    return new ApiResponse { Message = "Task kill requested", Successful = true, Response = true };
                case TaskRunRequestResult.Failed:
                    return new ApiResponse { Message = "Error killing task", Successful = false, Response = null };
                case TaskRunRequestResult.TaskDoesNotExist:
                    return new ApiResponse
                        { Message = "Task was not running or does not exist", Successful = false, Response = null };
            }

            return new ApiResponse();
        }

        /// <summary>
        ///     Terminates all running tasks.
        /// </summary>
        /// <returns>
        ///     an <cref see="Cigna.TaskScheduling.Domain.ApiResponse">ApiResponse</cref> object with
        ///     the result of the request
        /// </returns>
        [HttpPost]
        [Route("~/Scheduler/KillAllTasks")]
        public ApiResponse KillAllTasks()
        {
            switch (_scheduler.KillAllTasks())
            {
                case TaskRunRequestResult.Succeeded:
                    return new ApiResponse { Message = "Task kill requests sent", Successful = true, Response = true };
                case TaskRunRequestResult.Failed:
                    return new ApiResponse { Message = "Error killing all tasks", Successful = false, Response = null };
            }

            return new ApiResponse();
        }

        #region Diagnostic web methods

        /// <summary>
        ///     Diagnostic method returning information about the operating environment the assembly is
        ///     running under.
        /// </summary>
        /// <returns>
        ///     an <cref see="Cigna.TaskScheduling.Domain.ApiResponse">ApiResponse</cref> object with
        ///     the result of the request
        /// </returns>
        [HttpGet]
        [Description(
            "Gets diagnostic information about the environment under which the scheduler instance is running.")]
        [Route("~/Scheduler/GetEnvironmentInfo")]
        public ApiResponse GetEnvironmentInfo()
        {
            var apiResponse = new ApiResponse
            {
                Successful = true,
                Response = EnvironmentInfo(),
                Message = ""
            };

            return apiResponse;
        }

        /// <summary>
        ///     A diagnostic method that a client can use to determine if the web API is available.
        /// </summary>
        /// <returns>
        ///     an <cref see="Cigna.TaskScheduling.Domain.ApiResponse">ApiResponse</cref> object with
        ///     the result of the request
        /// </returns>
        [HttpGet]
        [Description(
            "Provides a no-action method call that returns the machine name as additional payload.  (Conforms to self-test Ping() calls in other Digital Apps applications.)")]
        [Route("~/Scheduler/Ping")]
        public ApiResponse Ping()
        {
            return new ApiResponse
            {
                Successful = true,
                Response = Environment.MachineName,
                Message = ""
            };
        }

        #endregion Diagnostic web methods

        #endregion Public web methods

        #region Private methods

        /// <summary>
        ///     Formats the environment information payload for GetEnvironmentInfo()
        /// </summary>
        /// <returns>
        ///     an <cref see="Cigna.TaskScheduling.Domain.ApiResponse">ApiResponse</cref> object with
        ///     the result of the request
        /// </returns>
        private static string EnvironmentInfo()
        {
            var assembly = Assembly.GetEntryAssembly();
            var fileInfo = new FileInfo(assembly?.Location ?? string.Empty);
            DateTime lastModified = fileInfo.LastWriteTime;

            var environmentXml = $@"
<Configuration>
    <Environment>
            <Setting Name='CallingAssembly' Value='{assembly}'></Setting>
            <Setting Name='CallingAssemblyLastModified' Value='{lastModified}'></Setting>
            <Setting Name='HostedUrl' Value='[HostedUrl]'></Setting>
    </Environment>
    <Connections>
        [Connections]
    </Connections>
</Configuration>";

            var connectionStrings = new List<string>();
            for (var i = 0; i < ConfigurationManager.ConnectionStrings.Count; i++)
            {
                ConnectionStringSettings item = ConfigurationManager.ConnectionStrings[i];
                string dbName = item.Name;
                string connectionString = item.ConnectionString;
                connectionString = RemovePasswordFromConnectionString(connectionString);
                connectionStrings.Add($"<Setting Name='{dbName}' Value='{connectionString}'></Setting>");
            }

            environmentXml = environmentXml.Replace(
                "[Connections]",
                string.Join(Environment.NewLine, connectionStrings));

            return environmentXml;
        }

        /// <summary>
        ///     Removes the password segment from the supplied connection string if it exists.
        /// </summary>
        /// <param name="connectionString">connection string to be cleaned</param>
        /// <returns>
        ///     the "clean" version of the connection string without the password segment
        /// </returns>
        private static string RemovePasswordFromConnectionString(string connectionString)
        {
            if (connectionString != null)
            {
                string[] stringPieces = connectionString.Split(';');
                int size = stringPieces.Length;
                var sb = new StringBuilder();
                for (var i = 0; i < size; i++)
                    if (!stringPieces[i].ToUpper().Contains("PASSWORD"))
                        sb.AppendFormat("{0};", stringPieces[i]);
                connectionString = sb.ToString();
            }

            return connectionString;
        }

        #endregion Private methods
    }
}