﻿# Cigna.TaskScheduling.WebApi
This package is an optional add-on to the Cigna.TaskScheduling package.
Add it if you want to leverage the API for getting task status information or for
adding command and control capabilities from an outside source.


## Adding the Web API to a new scheduling application

1. Add this NuGet package (Cigna.TaskScheduling.WebApi) to your project that contains the scheduler.

2. In the start-up code for your application or service, make a call to
   `ServiceActivator.Start()`.  You will need to supply the protocol ("http" or "https")
   and a base endpoint.
  
	For example:  
 
	```c#
	var activator = new Cigna.TaskScheduling.WebApi.ServiceActivator();
	activator.Start("http", "my.base.endpoint");
	```
	
	would create a base URL of `http://localhost/my.base.endpoint` and any
	scheduler commands would need to be sent to
	`http://localhost/my.base.endpoint/Scheduler`.

	NOTE: The "Scheduler" controller name is embedded into the API and cannot be changed.

3. Outside of your code, you will need to set up the service ACL URI permissions on
   each server that hosts your application.  The commands to grant these permissions typically
   look like this:
 
	```batch
    netsh add urlacl url=http://+:80/my.base.endpoint user=my.service.account
    netsh add urlacl url=https://+:443/my.base.endpoint user=my.service.account
	```

## Change Log
### Release 2023.2.2
#### Bug Fixes
- Clean-up of README.md

### Release 2023.2.1
#### Bug Fixes
- Fixed issue where Ping() and GetEnvironmentInfo() calls disappeared from the
  API.
