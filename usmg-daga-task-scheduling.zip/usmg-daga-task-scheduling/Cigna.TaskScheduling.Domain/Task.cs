﻿namespace Cigna.TaskScheduling.Domain
{
    /// <summary>
    /// Base class for all plug-in tasks used with Cigna.Scheduling
    /// </summary>
    public abstract class Task
    {
        #region Private Fields

        private static readonly object StopLock = new object();
        private bool _stopCalled;

        #endregion Private Fields

        #region Public Properties

        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public TaskCompletionStatus CompletionStatus { get; set; }

        #endregion Public Properties

        #region Protected Properties

        public bool StopCalled
        {
            get
            {
                lock (StopLock)
                {
                    return _stopCalled;
                }
            }

            // ReSharper disable once MemberCanBePrivate.Global
            set
            {
                lock (StopLock)
                {
                    _stopCalled = value;
                }
            }
        }

        #endregion Protected Properties

        #region Public Methods

        /// <summary>
        /// Starts the the task.  Intended to be used as a thread delegate.
        /// </summary>
        public abstract void Start();

        /// <summary>
        /// Signals that the current task should be stopped.  This method should return immediately.
        /// </summary>
        // ReSharper disable once VirtualMemberNeverOverridden.Global
        public virtual void Stop()
        {
            StopCalled = true;
        }

        #endregion Public Methods
    }
}