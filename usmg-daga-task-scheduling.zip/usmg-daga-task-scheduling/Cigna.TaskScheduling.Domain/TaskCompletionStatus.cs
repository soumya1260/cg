﻿namespace Cigna.TaskScheduling.Domain
{
    public enum TaskCompletionStatus
    {
        NotRun,
        Succeeded,
        Failed,
        Stopped
    }
}