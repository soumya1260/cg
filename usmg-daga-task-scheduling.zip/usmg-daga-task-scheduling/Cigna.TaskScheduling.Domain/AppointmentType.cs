﻿namespace Cigna.TaskScheduling.Domain
{
    public enum AppointmentType
    {
        Scheduled,
        AdHoc
    }
}
