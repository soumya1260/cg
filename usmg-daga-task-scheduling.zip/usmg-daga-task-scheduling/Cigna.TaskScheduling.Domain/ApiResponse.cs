﻿namespace Cigna.TaskScheduling.Domain
{
    public class ApiResponse
    {
        // ReSharper disable UnusedAutoPropertyAccessor.Global
        
        public bool Successful { get; set; }
        public string Message { get; set; }
        public object Response { get; set; }

        // ReSharper restore UnusedAutoPropertyAccessor.Global
    }
}