﻿# Cigna.TaskScheduling.Domain

This package is needed for projects that include Task Scheduling plug-ins
that are not hosted within the same project as Cigna.TaskScheduling.

**NOTE:** This document is a work in progress.  It may not cover all of the 
steps required for new projects or for project conversions.

## Using this package in new plug-in projects

1. Add this package via NuGet/Artifactory to your project.

2. For each plug-in class, add "`using Cigna.TaskScheduling.Domain;`" to the 
   using preamble.

3. Derive each task from `Domain.Task`.
 
   For example:
 
   `public class CleanUpTempFilesTask: Domain.Task { ... }`

4. Write your plug-in code!

5. Be sure to implement a `Start()` method.  This method will get called by the
   scheduler to start the task. 

6. Task provides a `StopCalled` property that you can check to see if the task
   needs to terminate early.  

   **Note:** `StopCalled` now is self-locking.  You no longer need to wrap it in
   a lock() block.


7. You can also override the `Stop()` method from the Task base class if you
need to do additional processing at the moment Stop() is called.  Be sure,
though, to call `base.StopCalled()` in your override method.  Also, make sure
you don't perform any long-running maintenance within this method.  It is
intended to return immediately and will be called on a different thread from 
the one running the task.
