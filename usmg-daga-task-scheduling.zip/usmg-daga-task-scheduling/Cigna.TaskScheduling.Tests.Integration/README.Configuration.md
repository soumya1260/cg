﻿# What to Do If Your Tests Are Failing Because They Can't Find Their Configuration Information

So, first off, this will only be a problem if you are running your
tests under .NET Core.  The framework used is determined by which one
is listed first in the \<TargetFrameworks> list.  So to test under 
different frameworks, you need to re-order the list in your .csproj
file.

But, if you insist on running your tests using .NET Core, you may run
into any number of configuration failures.  This is because different
test runners will use different DLLs to actually host your tests. 
This means that you will have to tailor the name of your 
configuration file to match the name of the test host.  You can 
always figure this out by running the debugger and evaluating:

`ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).FilePath`

This will tell you the name of the .exe or .dll file that your test
runner is using.  Just copy `app.config` to that name and append 
`.config` onto it.  Be sure to also set the "Copy to output 
directory" property of the file to "Copy Always".

`App.config` should still be the "canon" file for changes, since it
is what most people expect and is still valid for .NET 4.x test 
frameworks.

## Examples:
- NUnit3: `testhost.dll.config`
- ReSharper: `ReSharperTestRunner64.dll.config`