﻿using Cigna.TaskScheduling.Domain;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;

namespace Cigna.TaskScheduling.Tests.Integration
{
    [ExcludeFromCodeCoverage]
    public class IgnoreStopTask : Domain.Task
    {
        public override void Start()
        {
            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(IgnoreStopTask)} started.");

            try
            {
                for (int count = 0; count < 100; ++count)
                {
                    Console.WriteLine(
                        $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(IgnoreStopTask)} is running!");
                    Thread.Sleep(250); // Sleep for 1/4 second
                }
            }
            catch (ThreadInterruptedException)
            {
                Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - Thread interrupt received on {nameof(IgnoreStopTask)}.  Shutting down.");
            }
            catch (Exception)
            {
                // Do nothing.  Thread interrupt likely happened.
            }
            finally
            {
                Console.WriteLine(
                    $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(IgnoreStopTask)} stopped/killed.");

                CompletionStatus = StopCalled
                    ? TaskCompletionStatus.Stopped
                    : TaskCompletionStatus.Succeeded;
            }
        }

        public override void Stop()
        {
            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - Stop called on {nameof(IgnoreStopTask)} but it will be ignored.");
            base.Stop();
        }
    }
}
