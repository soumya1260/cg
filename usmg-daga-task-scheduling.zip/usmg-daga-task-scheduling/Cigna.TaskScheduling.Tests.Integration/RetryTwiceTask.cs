﻿using Cigna.TaskScheduling.Domain;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;

namespace Cigna.TaskScheduling.Tests.Integration
{
    [ExcludeFromCodeCoverage]
    public class RetryTwiceTask : Domain.Task
    {
        private int _runs;
        public override void Start()
        {
            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(RetryTwiceTask)} started.");
            CompletionStatus = TaskCompletionStatus.Failed;
            try
            {
                for (int count = 0; count < 20; ++count)
                {
                    Console.WriteLine(
                        $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(RetryTwiceTask)} is running!");
                    Thread.Sleep(250); // Sleep for 1/4 second
                }

                CompletionStatus = ++_runs < 3 ? TaskCompletionStatus.Failed : TaskCompletionStatus.Succeeded;
            }
            catch (ThreadInterruptedException)
            {
                Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - Thread interrupt received on {nameof(TriesHarderTask)}.  Shutting down.");
            }
            catch (Exception)
            {
                // Do nothing.  Thread interrupt likely happened.
            }
            finally
            {
                Console.WriteLine(
                    $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(RetryTwiceTask)} stopped/killed.");

                if (StopCalled) CompletionStatus = TaskCompletionStatus.Stopped;
            }

            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - Exiting with status {CompletionStatus}.");
        }

        public override void Stop()
        {
            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - Stop called on {nameof(RetryTwiceTask)} but it will be ignored.");
            base.Stop();
        }
    }
}
