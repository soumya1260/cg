﻿using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Threading;

namespace Cigna.TaskScheduling.Tests.Integration
{
    [ExcludeFromCodeCoverage]
    public class DisabledTask : Domain.Task
    {
        public override void Start()
        {
            try
            {
                Console.WriteLine($"{DateTime.Now} - ERROR: {nameof(DisabledTask)} started!");

                for (int count = 0; count < 100 && !StopCalled; ++count)
                {
                    Console.WriteLine($"{DateTime.Now} - ERROR: {nameof(DisabledTask)} should not be running!");
                    Thread.Sleep(250); // Sleep for 2 seconds
                }
            }
            catch (ThreadInterruptedException)
            {
                Console.WriteLine(
                    $"{DateTime.Now} - ERROR: {nameof(DisabledTask)} received {nameof(ThreadInterruptedException)}.");
            }
            finally
            {
                Console.WriteLine($"{DateTime.Now} - ERROR: {nameof(DisabledTask)} stopped.");
            }
        }
    }
}
