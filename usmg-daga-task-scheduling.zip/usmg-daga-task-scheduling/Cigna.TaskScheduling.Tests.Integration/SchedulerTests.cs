﻿using System;
using System.Diagnostics.CodeAnalysis;
using NUnit.Framework;
using System.Linq;
using System.Reflection;
using System.Threading;
using Cigna.TaskScheduling.Domain;

namespace Cigna.TaskScheduling.Tests.Integration
{
    [TestFixture, Category("Integration"), ExcludeFromCodeCoverage]
    public class SchedulerTests
    {
        private const string IgnoreStopTaskName = "Task That Ignores Stop";
        private const string ObeyStopTaskName = "Task That Obeys Stop";
        private const string DisabledTaskName = "Disabled Task";
        private const string AdHocTaskName = "Ad Hoc Task";
        private const string TriesHarderTaskName = "Task That Tries Harder";
        private const string RetriesOnceTaskName = "Task That Retries Once";
        private const string RetriesTwiceTaskName = "Task That Retries Twice";
        private const string AlwaysFailsTaskName = "Task That Always Fails";
        private const string FailsWeeklyTaskName = "Fails Weekly Task";

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            Console.SetOut(TestContext.Progress);
        }

        [Test]
        public void GetTask_WorksAsExpectedForExistingTask()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            var taskStatus = scheduler.GetTask(IgnoreStopTaskName);

            Assert.That(taskStatus, Is.Not.Null);
            Assert.That(taskStatus.Name, Is.EqualTo(IgnoreStopTaskName));

            scheduler.KillAllTasks();
            scheduler.Stop();
        }

        [Test]
        public void GetTask_ReturnsNullForBadName()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            var taskStatus = scheduler.GetTask("Non-existent task");

            Assert.That(taskStatus, Is.Null);

            scheduler.KillAllTasks();
            scheduler.Stop();
        }

        [Test]
        public void StopAllTasks_WorksAsExpected()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            //
            // Wait for timer to tick.
            //
            Thread.Sleep(1500);
            Assert
                .That(scheduler
                    .GetAppointments()
                    .Count(task => task.Name.Equals(ObeyStopTaskName) && task.Running),
                    Is.EqualTo(1),
                    $"The task named \"{ObeyStopTaskName}\" is expected to be running with exactly one instance.");

            //
            // Try to stop them.
            //
            var result = scheduler.StopAllTasks();
            Assert.That(
                result,
                Is.EqualTo(TaskRunRequestResult.Succeeded),
                $"StopAllTasks() returned a result of {result}.");

            //
            // Wait for sleep loops to complete.
            //
            Thread.Sleep(2000);

            Assert.That(
                scheduler
                    .GetAppointments()
                    .Count(task => task.Running && task.Name.Equals(ObeyStopTaskName)),
                Is.EqualTo(0),
                $"\"{ObeyStopTaskName}\" is still running.");

            scheduler.KillAllTasks();
            scheduler.Stop();
        }

        [Test]
        public void StopTask_WorksAsExpected()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            //
            // Wait for timer to tick.
            //
            Thread.Sleep(1500);

            Assert.That(scheduler
                    .GetAppointments()
                    .Count(task => task.Name.Equals(ObeyStopTaskName) && task.Running),
                Is.EqualTo(1),
                $"\"{ObeyStopTaskName}\" should be running, but it is not.");
            //
            // Try to stop them.
            //
            var result = scheduler.StopTask(ObeyStopTaskName);
            Assert.That(result, Is.EqualTo(TaskRunRequestResult.Succeeded));

            //
            // Wait for sleep loop to complete.
            //
            Thread.Sleep(1000);

            Assert.That(scheduler.GetAppointments().Count(task => task.Running && task.Name.Equals(ObeyStopTaskName)), Is.EqualTo(0));

            scheduler.KillAllTasks();
            scheduler.Stop();
        }

        [Test]
        public void KillTask_WorksAsExpected()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            //
            // Wait for timer to tick.
            //
            Thread.Sleep(2100);

            Assert.That(scheduler
                .GetAppointments()
                .Count(task => task.Name.Equals(IgnoreStopTaskName) && task.Running),
                Is.EqualTo(1), $"\"{IgnoreStopTaskName}\" should be running, but is not.");

            Assert.That(scheduler
                .GetAppointments()
                .Count(task => task.Name.Equals(ObeyStopTaskName) && task.Running),
                Is.EqualTo(1),
                $"\"{ObeyStopTaskName}\" should be running, but it is not.");

            //
            // Kill the task that ignores StopTask().
            //
            var taskResult = scheduler.KillTask(IgnoreStopTaskName);
            Assert.That(taskResult == TaskRunRequestResult.Succeeded);

            //
            // Wait for sleep loops to complete.
            //
            Thread.Sleep(3000);

            Assert.That(scheduler.GetAppointments().Count(task => task.Running && task.Name.Equals(IgnoreStopTaskName)), Is.EqualTo(0));
            Assert.That(scheduler.GetAppointments().Count(task => task.Running), Is.GreaterThan(0));

            scheduler.Stop();
        }

        [Test]
        public void KillAllTasks_WorksAsExpected()
        {
            var scheduler = new Scheduler();
            scheduler.Start();
            Console.WriteLine("Scheduler started.");

            //
            // Wait for timer to tick.
            //
            Thread.Sleep(1500);


            Assert.That(scheduler
                    .GetAppointments()
                    .Count(task => task.Name.Equals(IgnoreStopTaskName) && task.Running),
                Is.EqualTo(1), $"\"{IgnoreStopTaskName}\" should be running, but is not.");

            Assert.That(scheduler
                    .GetAppointments()
                    .Count(task => task.Name.Equals(ObeyStopTaskName) && task.Running),
                Is.EqualTo(1),
                $"\"{ObeyStopTaskName}\" should be running, but it is not.");

            Console.WriteLine("Threads started successfully.");

            //
            // Try to kill them.
            //
            Console.WriteLine("Calling KillAllTasks()...");
            var taskResult = scheduler.KillAllTasks();
            Console.WriteLine($"KillAllTasks() exited with result {taskResult}.");
            Assert.That(taskResult == TaskRunRequestResult.Succeeded);

            //
            // Wait for sleep loops to complete.
            //
            Thread.Sleep(1000);
            Console.WriteLine("Verifying test results...");
            Assert.That(scheduler.GetAppointments().Count(task => task.Running), Is.EqualTo(0));

            Console.WriteLine("Test complete.  Stopping Scheduler.");
            scheduler.Stop();
        }

        [Test]
        public void StartTask_FailsWhenGivenADisabledTask()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            var result = scheduler.StartTask(DisabledTaskName);
            Assert.That(result == TaskRunRequestResult.TaskIsDisabled);

            scheduler.KillAllTasks();
            scheduler.Stop();
        }

        [Test]
        public void StartTask_RemovesAdHocTaskFromScheduledTasksAfterTaskRuns()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            //
            // Start the ad hoc task.
            //
            var result = scheduler.StartTask(AdHocTaskName);

            Assert.That(result, Is.EqualTo(TaskRunRequestResult.Succeeded));
            Assert.That(scheduler.Appointments.First(task => task.Name.Equals(AdHocTaskName)).AppointmentType, Is.EqualTo(AppointmentType.AdHoc), "Type in Tasks is wrong.");
            Assert.That(scheduler.Schedule.First(task => task.Name.Equals(AdHocTaskName)).AppointmentType, Is.EqualTo(AppointmentType.AdHoc), "Type in Schedule is wrong.");
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(AdHocTaskName) && task.Running) == null);

            //
            // Wait for task to be run.
            //
            Thread.Sleep(2000);

            //
            // Make sure that it is not scheduled to run again.
            //
            Assert.That(scheduler.Schedule.FirstOrDefault(task => task.Name.Equals(AdHocTaskName)), Is.Null);

            scheduler.KillAllTasks();
            scheduler.Stop();
        }

        [Test]
        public void StartTask_DoesNotRetryWhenRunOnceTaskFinishes()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            //
            // Wait for task to be run.
            //
            Thread.Sleep(2000);

            //
            // Verify that the task is running
            //
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(TriesHarderTaskName) && task.Running),
                Is.Not.Null,
                $"{TriesHarderTaskName} is not running.");

            //
            // Wait for the task to finish.
            //
            Thread.Sleep(8000);
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(TriesHarderTaskName) && task.Running),
                Is.Null,
                $"{TriesHarderTaskName} is still running, but it should have completed.");

            //
            // Make sure that it is not scheduled to run again today
            //
            var appointment = scheduler.Schedule.First(task => task.Name.Equals(TriesHarderTaskName));
            Assert.That(appointment?.ScheduledTime.Date,
                Is.Not.EqualTo(DateTime.Now.Date),
                $"{TriesHarderTaskName} has been scheduled to run at {appointment.ScheduledTime}");

            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.Name}] - {TriesHarderTaskName} scheduled for {appointment.ScheduledTime}");

            scheduler.KillAllTasks();
            scheduler.Stop();
        }


        [Test]
        public void StartTask_RetriesOnceForRetryOnceTask()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            //
            // Wait for task to be run.
            //
            Thread.Sleep(2000);

            //
            // Verify that the task is running
            //
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(RetriesOnceTaskName) && task.Running),
                Is.Not.Null,
                $"{RetriesOnceTaskName} is not running.");

            //
            // Wait for the task to finish.
            //
            Thread.Sleep(8000);
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(RetriesOnceTaskName) && task.Running),
                Is.Null,
                $"{RetriesOnceTaskName} is still running, but it should have completed.");

            //
            // Make sure that it is scheduled to run again today
            //

            var appointment = scheduler.Schedule.First(task => task.Name.Equals(RetriesOnceTaskName));
            Assert.That(appointment.Task.CompletionStatus == TaskCompletionStatus.Failed);
            Assert.That(appointment?.ScheduledTime.Date,
                Is.EqualTo(DateTime.Now.Date),
                $"{RetriesOnceTaskName} has been scheduled to run at {appointment.ScheduledTime}");

            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.Name}] - {RetriesOnceTaskName} scheduled for {appointment.ScheduledTime}");

            //
            // Wait for retry
            //
            TimeSpan delay = appointment.ScheduledTime - DateTime.Now;

            Thread.Sleep(delay);
            Thread.Sleep(1000);// Add one second for good measure.

            //
            // Verify that the task is running
            //
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(RetriesOnceTaskName) && task.Running),
                Is.Not.Null,
                $"{RetriesOnceTaskName} is not running.");

            //
            // Wait for the task to finish.
            //
            Thread.Sleep(8000);
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(RetriesOnceTaskName) && task.Running),
                Is.Null,
                $"{RetriesOnceTaskName} is still running, but it should have completed.");

            //
            // Make sure that it is not scheduled to run again today
            //
            appointment = scheduler.Schedule.First(task => task.Name.Equals(RetriesOnceTaskName));
            Assert.That(appointment?.ScheduledTime.Date,
                Is.Not.EqualTo(DateTime.Now.Date),
                $"{RetriesOnceTaskName} has been scheduled to run at {appointment.ScheduledTime}");

            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.Name}] - {RetriesOnceTaskName} scheduled for {appointment.ScheduledTime}");

            scheduler.KillAllTasks();
            scheduler.Stop();
        }

        [Test]
        public void StartTask_RetriesTwiceForRetryTwiceTask()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            //
            // Wait for task to be run.
            //
            Thread.Sleep(2000);

            ScheduledAppointment appointment;
            for (int i = 0; i < 2; ++i)
            {
                //
                // Verify that the task is running
                //
                Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(RetriesTwiceTaskName) && task.Running),
                    Is.Not.Null,
                    $"{RetriesTwiceTaskName} is not running.");

                //
                // Wait for the task to finish.
                //
                Thread.Sleep(8000);
                Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(RetriesTwiceTaskName) && task.Running),
                    Is.Null,
                    $"{RetriesTwiceTaskName} is still running, but it should have completed.");

                //
                // Make sure that it is scheduled to run again today
                //
                appointment = scheduler.Schedule.First(task => task.Name.Equals(RetriesTwiceTaskName));
                Assert.That(appointment.Task.CompletionStatus == TaskCompletionStatus.Failed, "Task should have failed.");
                Assert.That(appointment?.ScheduledTime.Date,
                    Is.EqualTo(DateTime.Now.Date),
                    $"{RetriesTwiceTaskName} has been scheduled to run at {appointment.ScheduledTime}");

                Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.Name}] - {RetriesTwiceTaskName} scheduled for {appointment.ScheduledTime}");

                //
                // Wait for retry
                //
                TimeSpan delay = appointment.ScheduledTime - DateTime.Now;

                Thread.Sleep(delay);
                Thread.Sleep(1000);// Add one second for good measure.

            }

            //
            // Verify that the task is running
            //
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(RetriesTwiceTaskName) && task.Running),
                Is.Not.Null,
                $"{RetriesTwiceTaskName} is not running.");

            //
            // Wait for the task to finish.
            //
            Thread.Sleep(8000);
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(RetriesTwiceTaskName) && task.Running),
                Is.Null,
                $"{RetriesTwiceTaskName} is still running, but it should have completed.");

            //
            // Make sure that it is not scheduled to run again today
            //
            appointment = scheduler.Schedule.First(task => task.Name.Equals(RetriesTwiceTaskName));
            Assert.That(appointment.Task.CompletionStatus == TaskCompletionStatus.Succeeded, "Task should have succeeded on third run.");
            Assert.That(appointment?.ScheduledTime.Date,
                Is.Not.EqualTo(DateTime.Now.Date),
                $"{RetriesTwiceTaskName} has been scheduled to run at {appointment.ScheduledTime}");

            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.Name}] - {RetriesTwiceTaskName} scheduled for {appointment.ScheduledTime}");

            scheduler.KillAllTasks();
            scheduler.Stop();
        }

        //
        // This task has zero retries, so it should skip to the next
        // available day on failures.
        //
        [Test]
        public void StartTask_SkipsToNextDayOnAlwaysFailsTask()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            //
            // Wait for task to be run.
            //
            Thread.Sleep(2000);

            //
            // Verify that the task is running
            //
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(AlwaysFailsTaskName) && task.Running),
                Is.Not.Null,
                $"{AlwaysFailsTaskName} is not running.");

            //
            // Wait for the task to finish.
            //
            Thread.Sleep(8000);
            Assert.That(scheduler.GetAppointments().FirstOrDefault(task => task.Name.Equals(AlwaysFailsTaskName) && task.Running),
                Is.Null,
                $"{AlwaysFailsTaskName} is still running, but it should have completed.");

            //
            // Make sure that it is not scheduled to run again today
            //
            ScheduledAppointment appointment = scheduler.Schedule.First(task => task.Name.Equals(AlwaysFailsTaskName));
            Assert.That(appointment.Task.CompletionStatus == TaskCompletionStatus.Failed, "Task should have failed.");
            Assert.That(appointment?.ScheduledTime.Date,
                Is.Not.EqualTo(DateTime.Now.Date),
                $"{AlwaysFailsTaskName} has been scheduled to run at {appointment.ScheduledTime}");

            Assert.That(appointment.ScheduledTime.Date, Is.EqualTo(DateTime.Now.Date.AddDays(1)));

            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.Name}] - {AlwaysFailsTaskName} scheduled for {appointment.ScheduledTime}");

            scheduler.KillAllTasks();
            scheduler.Stop();
        }

        [Test]
        public void Scheduler_CorrectlyReschedulesFailedTaskWhenFrequencyIsOncePerWeek()
        {
            var scheduler = new Scheduler();
            scheduler.Start();

            DateTime appointmentStart = DateTime.Now;
            var configTask = new Configuration.Appointment(
                FailsWeeklyTaskName,
                "Cigna.TaskScheduling.Tests.Integration.dll",
                "Cigna.TaskScheduling.Tests.Integration.AlwaysFailsTask",
                true,
                appointmentStart.ToShortTimeString(),
                appointmentStart.AddMinutes(5).ToShortTimeString(),
                10,
                appointmentStart.DayOfWeek.ToString().Substring(0, 3),
                false,
                true,
                1,
                AppointmentType.Scheduled,
                "All",
                "All",
                DateTime.MinValue,
                DateTime.MaxValue,
                "All");

            scheduler.ScheduleAppointmentFromConfiguration(configTask);
            Thread.Sleep(10000);  // AlwaysFailsTask takes at least 5 seconds to run.

            ScheduledAppointment appointment = scheduler.Schedule.First(task => task.Name.Equals(FailsWeeklyTaskName));
            Assert.That(appointment.ScheduledTime, Is.GreaterThan(appointmentStart.AddDays(7).Date));
        }


        //[Test]
        //public void Start_Exercise()
        //{
        //    var scheduler = new Scheduler();
        //    scheduler.Start();

        //    //
        //    // Wait for task to be run.
        //    //
        //    Thread.Sleep(10 * 60 * 1000);  // Ten minutes

        //    scheduler.KillAllTasks();
        //    scheduler.Stop();
        //}
    }
}