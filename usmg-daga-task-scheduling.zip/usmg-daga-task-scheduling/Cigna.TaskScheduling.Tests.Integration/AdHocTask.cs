﻿using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using Cigna.TaskScheduling.Domain;

namespace Cigna.TaskScheduling.Tests.Integration
{
    [ExcludeFromCodeCoverage]
    public class AdHocTask : Domain.Task
    {
        public override void Start()
        {
            try
            {
                Console.WriteLine(
                    $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(AdHocTask)} started.");

                for (int count = 0; count < 100 && !StopCalled; ++count)
                {
                    Console.WriteLine(
                        $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(AdHocTask)} is running.");
                    Thread.Sleep(250); // Sleep for 2 seconds
                }
            }
            catch (ThreadInterruptedException)
            {
                Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - Thread interrupt received on {nameof(AdHocTask)}.  Shutting down.");
            }
            catch (Exception)
            {
                //
                // Do nothing.
                //
            }
            finally
            {
                Console.WriteLine(
                    $"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - {nameof(AdHocTask)} stopped.");

                CompletionStatus = StopCalled
                    ? TaskCompletionStatus.Stopped
                    : TaskCompletionStatus.Succeeded;
            }
        }

        
        public override void Stop()
        {
            Console.WriteLine($"{DateTime.Now} [{Thread.CurrentThread.ManagedThreadId}] - Stop called on {nameof(AdHocTask)}");
            base.Stop();
        }
    }
}
