[![Build Status](https://w2-jenkins.sys.cigna.com/buildStatus/icon?job=HEALTHSPRING/CHSDEVOPS/GBS-DigitalApps/TaskSchedulingLibrary)](https://w2-jenkins.sys.cigna.com/job/HEALTHSPRING/job/CHSDEVOPS/job/GBS-DigitalApps/job/TaskSchedulingLibrary/)
[![Quality Gate Status](https://sonarqube.sys.cigna.com/api/project_badges/measure?project=CHS.InternalTools.TaskScheduling&metric=alert_status)](https://sonarqube.sys.cigna.com/dashboard?id=CHS.InternalTools.TaskScheduling)
# daga-task-scheduling
## A simple scheduling library for lightweight, repetitive tasks.

*More to come...*
