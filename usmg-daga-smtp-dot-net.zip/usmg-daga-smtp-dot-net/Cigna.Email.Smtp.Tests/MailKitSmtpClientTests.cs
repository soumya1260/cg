﻿using Cigna.Email.Smtp.Clients;
using MimeKit;
using NUnit.Framework;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace Cigna.Email.Smtp.Tests
{
    [TestFixture, ExcludeFromCodeCoverage]
    public class MailKitSmtpClientTests
    {
        [SetUp]
        public void Setup()
        {
        }

        private const string FromAddress = "Don.Perkins@cignahealthcare.com";
        private const string ToAddress = "Don.Perkins@cignahealthcare.com";

        [Test]
        public void Send_PlainTextMessageReturnsOnlyOneMimeBodyElement()
        {
            var message = new Message()
            {
                To = EmailAddress.AddressList(ToAddress),
                From = EmailAddress.AddressList(FromAddress),
                Cc = Array.Empty<EmailAddress>().ToList(),
                Bcc = Array.Empty<EmailAddress>().ToList(),
                Subject = "Test",
                PlainTextBody = "This is a test"
            };

            var mailKitMessage = MailKitSmtpClient.PrepareOutgoingMessage(message);

            Assert.Multiple(() =>
            {
                Assert.That(
                    mailKitMessage.BodyParts.Count,
                    Is.EqualTo(1));

                Assert.That(
                    mailKitMessage.Body.ContentType.MimeType,
                    Is.EqualTo("text/plain"));
            });
        }

        [Test]
        public void Send_HtmlTextMessageReturnsOnlyOneMimeBodyElement()
        {
            var message = new Message()
            {
                To = EmailAddress.AddressList(ToAddress),
                From = EmailAddress.AddressList(FromAddress),
                Cc = Array.Empty<EmailAddress>().ToList(),
                Bcc = Array.Empty<EmailAddress>().ToList(),
                Subject = "Test",
                HtmlTextBody = "<h1>This is a test</h1>"
            };

            var mailKitMessage = MailKitSmtpClient.PrepareOutgoingMessage(message);

            Assert.Multiple(() =>
            {
                Assert.That(
                    mailKitMessage.BodyParts.Count,
                    Is.EqualTo(1));

                Assert.That(
                    mailKitMessage.Body.ContentType.MimeType,
                    Is.EqualTo("text/html"));
            });
        }

        [Test]
        public void Send_MixedMessageReturnsTwoMimeBodyElements()
        {
            var message = new Message()
            {
                To = EmailAddress.AddressList(ToAddress),
                From = EmailAddress.AddressList(FromAddress),
                Cc = Array.Empty<EmailAddress>().ToList(),
                Bcc = Array.Empty<EmailAddress>().ToList(),
                Subject = "Test",
                PlainTextBody = "This is a test",
                HtmlTextBody = "<h1>This is a test</h1>"
            };

            var mailKitMessage = MailKitSmtpClient.PrepareOutgoingMessage(message);

            var partCounts = CountParts(mailKitMessage);

            Assert.Multiple(() =>
            {
                Assert.That(
                    mailKitMessage.BodyParts.Count,
                    Is.EqualTo(2));

                Assert.That(partCounts.Item1, Is.EqualTo(1)); // html
                Assert.That(partCounts.Item2, Is.EqualTo(1)); // plain
                Assert.That(partCounts.Item3, Is.EqualTo(0)); // attachments
            });
        }

        [Test]
        public void Send_MixedMessageWithAttachmentReturnsThreeMimeBodyElements()
        {
            var message = new Message()
            {
                To = EmailAddress.AddressList(ToAddress),
                From = EmailAddress.AddressList(FromAddress),
                Cc = Array.Empty<EmailAddress>().ToList(),
                Bcc = Array.Empty<EmailAddress>().ToList(),
                Subject = "Test",
                PlainTextBody = "This is a test",
                HtmlTextBody = "<h1>This is a test</h1>"
            };

            message.Attachments.AddAttachment(new EmailAttachment
            {
                Content = new byte[] { 0x00, 0x00 },
                ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                FileName = "Empty.xlsx"
            });

            var mailKitMessage = MailKitSmtpClient.PrepareOutgoingMessage(message);

            var partCounts = CountParts(mailKitMessage);

            Assert.Multiple(() =>
            {
                Assert.That(
                    mailKitMessage.BodyParts.Count,
                    Is.EqualTo(3));

                Assert.That(partCounts.Item1, Is.EqualTo(1)); // html
                Assert.That(partCounts.Item2, Is.EqualTo(1)); // plain
                Assert.That(partCounts.Item3, Is.EqualTo(1)); // attachments
            });
        }

        private static Tuple<int, int, int> CountParts(MimeMessage mailKitMessage)
        {
            int numHtml = 0;
            int numText = 0;
            int numAttachment = 0;

            foreach (var messagePart in mailKitMessage.BodyParts)
            {
                switch (messagePart.ContentType.MimeType)
                {
                    case "text/html": ++numHtml; break;
                    case "text/plain": ++numText; break;
                }
                if (messagePart.IsAttachment) ++numAttachment;
            }

            return new Tuple<int, int, int>(numHtml, numText, numAttachment);
        }
    }
}