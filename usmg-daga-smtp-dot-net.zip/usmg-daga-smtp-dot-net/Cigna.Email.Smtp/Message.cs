﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cigna.Email.Smtp
{
    /// <summary>
    ///     Message class for containing a simple email message.
    /// </summary>
    /// <remarks>
    ///     Defined as a `DataContract` in order to provide framework-level
    ///     serialization for WCF consumers.
    /// </remarks>
    [DataContract]
    public class Message
    {
        /// <summary>
        ///     Address list of the authors of the email.  If there is only one
        ///     author and no Sender is indicated, then it is assumed the author
        ///     and sender are the same entity.
        /// </summary>
        /// <remarks>
        ///     This object and the associated mail clients currently support
        ///     email lists in the From: field.  BUT, when more than one address
        ///     is specified for From:, then a single address needs to be
        ///     supplied in a Sender: field.  As of 2024.2.0, the Sender: field
        ///     is not yet supported.
        ///
        ///     Note that both MailKit (as of 4.7.1) and HSEmail are
        ///     non-conformant in that neither supports the Sender header.
        ///
        ///     Relevant RFCs and subsections:
        ///     - RFC 822 - A.2.7
        ///     - RFC 2822 - 3.6.2
        ///     - RFC 5322 - 3.6.2
        /// </remarks>
        [DataMember] public List<EmailAddress> From { get; set; }

        /// <summary>
        /// Primary recipients' list.
        /// </summary>
        [DataMember] public List<EmailAddress> To { get; set; }

        /// <summary>
        /// "Carbon copy" recipients' list.
        /// </summary>
        [DataMember] public List<EmailAddress> Cc { get; set; }
        
        /// <summary>
        /// Blind "carbon copy" recipients' list.
        /// </summary>
        [DataMember] public List<EmailAddress> Bcc { get; set; }
        
        /// <summary>
        /// Subject line of the email message.
        /// </summary>
        [DataMember] public string Subject { get; set; }

        /// <summary>
        /// Alternative text-only version of the message.  Optional.
        /// </summary>
        [DataMember] public string PlainTextBody { get; set; } = string.Empty;

        /// <summary>
        /// Contains the HTML content for the message body, independent of
        /// attachments.  Optional.
        /// </summary>
        [DataMember] public string HtmlTextBody { get; set; } = string.Empty;

        /// <summary>
        /// List of attachments to be included in the email message
        /// </summary>
        [DataMember]
        public EmailAttachmentCollection Attachments { get; private set; } = new EmailAttachmentCollection();
    }
}
