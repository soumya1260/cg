﻿namespace Cigna.Email.Smtp.Contracts
{
    // ReSharper disable once InconsistentNaming
    /// <summary>
    /// Provides a contract for implementing SMTP client factories
    /// </summary>
    public abstract class SmtpClientFactory
    {
        /// <summary>
        ///     Set to true if the code is currently running on a developer
        ///     workstation.
        /// </summary>
        protected bool Localhost { get; set; }

        /// <summary>
        ///     SMTP Server name (fully-qualified)
        /// </summary>
        protected string SmtpServer { get; set; }

        /// <summary>
        ///     SMTP UserName for authentication
        /// </summary>
        protected string SmtpUserName { get; set; }

        /// <summary>
        ///     SMTP Password for authentication
        /// </summary>
        protected string SmtpPassword { get; set; }

        /// <summary>
        ///     Factory constructor.  Used to inject key configuration values at
        ///     creation.
        /// </summary>
        /// <param name="localhost">
        ///     set to `true` if this is a localhost development environment;
        ///     `false` otherwise
        /// </param>
        /// <param name="smtpServer">
        ///     The fully-qualified name of the SMTP server
        /// </param>
        /// <param name="smtpUserName">
        ///     The username for authenticating to the SMTP server
        /// </param>
        /// <param name="smtpPassword">
        ///     The password associated with `smtpUserName`
        /// </param>
        protected SmtpClientFactory(
            bool localhost,
            string smtpServer,
            string smtpUserName = "",
            string smtpPassword = "")
        {
            Localhost = localhost;
            SmtpServer = smtpServer;
            SmtpUserName = smtpUserName;
            SmtpPassword = smtpPassword;
        }

        /// <summary>
        ///     Factory method to create an SMTP Client.
        /// </summary>
        /// <returns>an SMTP client</returns>
        public abstract SmtpClient CreateSmtpClient();
    }
}