﻿namespace Cigna.Email.Smtp.Contracts
{
    // ReSharper disable once InconsistentNaming
    /// <summary>
    /// Provides a contract for implementing SMTP clients.
    /// </summary>
    public abstract class SmtpClient
    {
        /// <summary>
        /// SMTP Server name (fully-qualified)
        /// </summary>
        protected string SmtpServer { get; set; }

        /// <summary>
        /// SMTP UserName for authentication
        /// </summary>
        protected string SmtpUserName { get; set; }

        /// <summary>
        /// SMTP Password for authentication
        /// </summary>
        protected string SmtpPassword { get; set; }

        /// <summary>
        ///     Override this property to supply a unique client name.  This is
        ///     useful for debugging.
        /// </summary>
        public abstract string ClientName { get; }

        /// <summary>
        /// Constructor for SMTP Clients
        /// </summary>
        /// <param name="smtpServer">
        ///     The fully-qualified SMTP server host name.
        /// </param>
        /// <param name="smtpUserName">
        ///     The username used for authentication to the SMTP server.  Not
        ///     used by all clients.
        /// </param>
        /// <param name="smtpPassword">
        ///     The password associated with `smtpUserName`.  Not used by all
        ///     clients.
        /// </param>
        protected SmtpClient(string smtpServer, string smtpUserName, string smtpPassword)
        {
            SmtpServer = smtpServer;
            SmtpUserName = smtpUserName;
            SmtpPassword = smtpPassword;
        }

        /// <summary>
        ///     Sends the message to the SMTP server for delivery.
        /// </summary>
        /// <param name="message">
        ///     A message object containing the message and addressing metadata
        ///     to be sent.
        /// </param>
        /// <returns>true if successful; false otherwise</returns>
        public abstract bool Send(Message message);
    }
}
