﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace Cigna.Email.Smtp
{
    /// <summary>
    /// Simple EmailAddress domain object.  Decorated as a DataContract for compatibility with
    /// WCF consumers.
    /// </summary>
    [DataContract]
    public class EmailAddress
    {
        /// <summary>
        /// Required address value conforming to RFC-5322's "name@domain" format.
        /// </summary>
        [DataMember] public string Address { get; set; }

        /// <summary>
        /// Optional display name as defined by RFC-5322.  Associates a descriptive name with an email address.
        /// </summary>
        [DataMember] public string DisplayName { get; set; }

        /// <summary>
        /// Constructor - defined with optional parameters to enable use with initializers.
        /// </summary>
        /// <param name="address">Required email address conforming to RFC-5322's "name@domain" format</param>
        /// <param name="displayName">Optional Display Name per RFC-5322</param>
        public EmailAddress(string address = "", string displayName = "")
        {
            Address = address;
            DisplayName = displayName;
        }

        /// <summary>
        /// Helper method for creating address lists with only one EmailAddress object.
        /// </summary>
        /// <param name="address">the email address</param>
        /// <param name="displayName">(optional) the name to be displayed for the sender or recipient</param>
        /// <returns>a list with one EmailAddress object</returns>
        public static List<EmailAddress> SingleAddress(string address, string displayName = "")
        {
            var list = new List<EmailAddress> { new EmailAddress(address, displayName) };
            return list;
        }

        /// <summary>
        /// Converts a comma-separated list of email addresses into a List structure.
        /// </summary>
        /// <param name="addressList">comma-separated list of email addresses without display names</param>
        /// <returns></returns>
        public static List<EmailAddress> AddressList(string addressList)
        {
            var result = new List<EmailAddress>();

            if (string.IsNullOrWhiteSpace(addressList)) return result;

            string[] addresses = addressList.Split(',');
            result.AddRange(addresses
                .Where(address => !string.IsNullOrWhiteSpace(address))
                .Select(address => new EmailAddress(address.Trim())));

            return result;
        }

        /// <summary>
        /// Helper method to create an address list compatible with RFC-5322.
        /// </summary>
        /// <param name="addresses">A list of addresses to format.</param>
        /// <returns>A comma-separated list of RFC-5322-formatted addresses with optional display names.</returns>
        public static string CommaSeparatedAddressList(List<EmailAddress> addresses)
        {
            if (addresses == null || addresses.Count == 0 || addresses.TrueForAll(address => address == null))
            {
                return string.Empty;
            }

            var addressesToJoin = addresses
                .Where(address => address != null && !string.IsNullOrWhiteSpace(address.Address))
                .Select(FormatRfc5322Address);

            return string.Join(",", addressesToJoin);
        }

        /// <summary>
        /// Presents an email address in the RFC-5322 address format
        /// </summary>
        /// <param name="address">an EmailAddress object to be formatted</param>
        /// <returns>the formatted address as a string</returns>
        private static string FormatRfc5322Address(EmailAddress address) =>
            $"{FormatRfc5322DisplayName(address)}<{address.Address}>";

        /// <summary>
        /// Formats an RFC-5322 Display Name
        /// </summary>
        /// <param name="address">an EmailAddress object to be formatted</param>
        /// <returns>the formatted Display Name, which could be an empty string</returns>
        private static string FormatRfc5322DisplayName(EmailAddress address) =>
            IncludeDisplayName(address) 
                ? $"\"{address.DisplayName}\" " 
                : string.Empty;

        /// <summary>
        /// Determines whether or not the RFC-5322 Display Name should be included as part of the address.
        /// </summary>
        /// <param name="address">an EmailAddress object to be formatted</param>
        /// <returns>`true` if the Display Name should be included; `false` otherwise.</returns>
        private static bool IncludeDisplayName(EmailAddress address) =>
            string.IsNullOrWhiteSpace(address.DisplayName) ||
            address.DisplayName.Equals(address.Address, StringComparison.CurrentCultureIgnoreCase);
    }
}
