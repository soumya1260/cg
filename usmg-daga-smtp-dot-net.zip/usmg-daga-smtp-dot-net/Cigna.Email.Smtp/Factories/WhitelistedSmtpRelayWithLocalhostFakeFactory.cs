﻿using Cigna.Email.Smtp.Clients;
using Cigna.Email.Smtp.Contracts;

namespace Cigna.Email.Smtp.Factories
{
    public class WhitelistedSmtpRelayWithLocalhostFakeFactory: SmtpClientFactory
    {
        /// <inheritdoc />
        public WhitelistedSmtpRelayWithLocalhostFakeFactory(
            bool localhost,
            string smtpServer,
            string smtpUserName = "",
            string smtpPassword = "")
            : base(localhost, smtpServer, smtpUserName, smtpPassword)
        {}

        /// <inheritdoc />
        public override SmtpClient CreateSmtpClient() =>
            Localhost 
                ? (SmtpClient) new FakeSmtpClient(SmtpServer, SmtpUserName, SmtpPassword)
                : new WhitelistedCignaSmtpRelayClient(SmtpServer, SmtpUserName, SmtpPassword);
    }
}