﻿using Cigna.Email.Smtp.Clients;
using Cigna.Email.Smtp.Contracts;

namespace Cigna.Email.Smtp.Factories
{
    public class WhitelistedSmtpRelayWithLocalhostExchangeFactory
        : SmtpClientFactory
    {
        /// <inheritdoc />
        public WhitelistedSmtpRelayWithLocalhostExchangeFactory(
            bool localhost,
            string smtpServer,
            string smtpUserName = "",
            string smtpPassword = "")
            : base(localhost, smtpServer, smtpUserName, smtpPassword)
        {
        }

        /// <inheritdoc />
        public override SmtpClient CreateSmtpClient() =>
            Localhost
                ? (SmtpClient) new OutlookSmtpClient(SmtpServer, SmtpUserName, SmtpPassword)
                : new WhitelistedCignaSmtpRelayClient(SmtpServer, SmtpUserName, SmtpPassword);
    }
}