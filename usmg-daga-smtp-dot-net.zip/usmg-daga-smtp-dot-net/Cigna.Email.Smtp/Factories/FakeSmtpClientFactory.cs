﻿using Cigna.Email.Smtp.Clients;
using Cigna.Email.Smtp.Contracts;

namespace Cigna.Email.Smtp.Factories
{
     /// <summary>
     /// Supplies a factory that only creates Fake SMTP clients regardless of
     /// the runtime environment.
     /// </summary>
    public class FakeSmtpClientFactory: SmtpClientFactory
    {
        /// <inheritdoc />
        public FakeSmtpClientFactory(
            bool localhost,
            string smtpServer,
            string smtpUserName = "",
            string smtpPassword = "")
            : base(localhost, smtpServer, smtpUserName, smtpPassword)
        {}

        /// <inheritdoc />
        public override SmtpClient CreateSmtpClient() => 
            new FakeSmtpClient(SmtpServer, SmtpUserName, SmtpPassword);
    }
}