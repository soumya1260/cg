﻿using Cigna.Email.Smtp.Clients;
using Cigna.Email.Smtp.Contracts;

namespace Cigna.Email.Smtp.Factories
{
    public class AuthenticatedSmtpRelayWithLocalhostExchangeFactory: SmtpClientFactory
    {
        /// <inheritdoc />
        public AuthenticatedSmtpRelayWithLocalhostExchangeFactory(
            bool localhost,
            string smtpServer,
            string smtpUserName,
            string smtpPassword)
            : base(localhost, smtpServer, smtpUserName, smtpPassword)
        {
        }

        /// <inheritdoc />
        public override SmtpClient CreateSmtpClient() =>
            Localhost 
                ? (SmtpClient) new OutlookSmtpClient(SmtpServer, SmtpUserName, SmtpPassword)
                : new AuthenticatedCignaSmtpRelayClient(SmtpServer, SmtpUserName, SmtpPassword);
    }
}