﻿using Cigna.Email.Smtp.Clients;
using Cigna.Email.Smtp.Contracts;

namespace Cigna.Email.Smtp.Factories
{
    public class WhitelistedSmtpRelayWithLocalhostAuthenticatedSmtpRelayFactory
        : SmtpClientFactory
    {
        /// <inheritdoc />
        public WhitelistedSmtpRelayWithLocalhostAuthenticatedSmtpRelayFactory(
            bool localhost,
            string smtpServer,
            string smtpUserName = "",
            string smtpPassword = "")
            : base(localhost, smtpServer, smtpUserName, smtpPassword)
        {
        }

        /// <inheritdoc />
        public override SmtpClient CreateSmtpClient() =>
            Localhost
                ? (SmtpClient) new AuthenticatedCignaSmtpRelayClient(SmtpServer, SmtpUserName, SmtpPassword)
                : new WhitelistedCignaSmtpRelayClient(SmtpServer, SmtpUserName, SmtpPassword);
    }
}