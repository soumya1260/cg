﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Cigna.Email.Smtp
{
    public class EmailAttachmentCollection: IEnumerable<EmailAttachment>
    {
        private readonly List<EmailAttachment> _attachments = new List<EmailAttachment>();

        /// <inheritdoc/>
        public IEnumerator<EmailAttachment> GetEnumerator()
        {
            return _attachments.GetEnumerator();
        }

        /// <inheritdoc/>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        /// <summary>
        ///     Adds an attachment to the collection by loading the file
        ///     referenced by the supplied file name.
        /// </summary>
        /// <exception cref="T:System.ArgumentException">
        ///     <paramref name="fileName">fileName</paramref>
        ///     is a zero-length string, contains only white space, or contains
        ///     one or more invalid characters as defined by
        ///     <see cref="F:System.IO.Path.InvalidPathChars"></see>.
        /// </exception>
        /// <exception cref="T:System.ArgumentNullException">
        ///     <paramref name="fileName">fileName</paramref>
        ///     is null.
        /// </exception>
        /// <exception cref="T:System.IO.PathTooLongException">
        ///     The specified path, file name, or both exceed the system-defined
        ///     maximum length. For example, on Windows-based platforms, paths
        ///     must be less than 248 characters, and file names must be less
        ///     than 260 characters.
        /// </exception>
        /// <exception cref="T:System.IO.DirectoryNotFoundException">
        ///     The specified path is invalid (for example, it is on an unmapped drive).
        /// </exception>
        /// <exception cref="T:System.IO.IOException">
        ///     An I/O error occurred while opening the file.
        /// </exception>
        /// <exception cref="T:System.UnauthorizedAccessException">
        ///     This operation is not supported on the current platform.   -or-
        ///     <paramref name="fileName">fileName</paramref>
        ///     specified a directory.   -or-   The caller does not have the
        ///     required permission.
        /// </exception>
        /// <exception cref="T:System.IO.FileNotFoundException">
        ///     The file specified in <paramref name="fileName">
        ///     fileName</paramref> was not found.
        /// </exception>
        /// <exception cref="T:System.NotSupportedException">
        ///     <paramref name="fileName">path</paramref> is in an invalid format.
        /// </exception>
        /// <exception cref="T:System.Security.SecurityException">
        ///     The caller does not have the required permission.
        /// </exception>
        public void AddAttachment(string fileName)
        {
            var attachment = new EmailAttachment { FileName = fileName };
            attachment.GetContent();
            
            if (attachment.Content.Length == 0)
                throw new EmptyFileException($"{fileName} is empty.");

            _attachments.Add(attachment);
        }

        /// <summary>
        ///     Adds an EmailAttachment object to the collection
        /// </summary>
        /// <param name="attachment">
        ///     the EmailAttachment object to be added to the collection
        /// </param>
        /// <exception cref="T:System.ArgumentException">
        ///     <paramref name="attachment.FileName">attachment.FileName</paramref>
        ///     is a zero-length string, contains only white space, or contains
        ///     one or more invalid characters as defined by
        ///     <see cref="F:System.IO.Path.InvalidPathChars"></see>.
        /// </exception>
        /// <exception cref="T:System.ArgumentNullException">
        ///     <paramref name="attachment.FileName">attachment.FileName</paramref>
        ///     is null.
        /// </exception>
        /// <exception cref="T:System.IO.PathTooLongException">
        ///     The specified path, file name, or both exceed the system-defined
        ///     maximum length. For example, on Windows-based platforms, paths
        ///     must be less than 248 characters, and file names must be less
        ///     than 260 characters.
        /// </exception>
        /// <exception cref="T:System.IO.DirectoryNotFoundException">
        ///     The specified path is invalid (for example, it is on an unmapped drive).
        /// </exception>
        /// <exception cref="T:System.IO.IOException">
        ///     An I/O error occurred while opening the file.
        /// </exception>
        /// <exception cref="T:System.UnauthorizedAccessException">
        ///     This operation is not supported on the current platform.   -or-
        ///     <paramref name="attachment.FileName">attachment.FileName</paramref>
        ///     specified a directory.   -or-   The caller does not have the
        ///     required permission.
        /// </exception>
        /// <exception cref="T:System.IO.FileNotFoundException">
        ///     The file specified in <paramref name="attachment.FileName">
        ///     attachment.FileName</paramref> was not found.
        /// </exception>
        /// <exception cref="T:System.NotSupportedException">
        ///     <paramref name="attachment.FileName">attachment.FileName</paramref>
        ///     is in an invalid format.
        /// </exception>
        /// <exception cref="T:System.Security.SecurityException">
        ///     The caller does not have the required permission.
        /// </exception>
        /// <exception cref="T:EmptyFileException">
        ///     The file associated with <paramref name="attachment">attachment
        ///     </paramref> is empty.
        /// </exception>
        public void AddAttachment(EmailAttachment attachment)
        {
            attachment.GetContent();
            
            if (attachment.Content.Length == 0)
                throw new EmptyFileException($"{attachment.FileName} is empty.");

            _attachments.Add(attachment);
        }
    }

    [Serializable]
    public class EmptyFileException : Exception
    {
        public EmptyFileException() { }
        public EmptyFileException(string message) : base(message) { }
        public EmptyFileException(string message, Exception inner)
            : base(message, inner) { }
        protected EmptyFileException(
            System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
