﻿using MailKit.Net.Smtp;
using MailKit.Security;

namespace Cigna.Email.Smtp.Clients
{
    /// <summary>
    /// Provides an SMTP client that should be compatible with Microsoft
    /// Exchange.
    /// </summary>
    public sealed class OutlookSmtpClient : MailKitSmtpClient
    {
        /// <inheritdoc />
        protected override int SmtpPort => 587;

        /// <inheritdoc />
        public OutlookSmtpClient(
            string smtpServer,
            string smtpUserName,
            string smtpPassword) 
            : base(smtpServer, smtpUserName, smtpPassword)
        {}

        /// <inheritdoc />
        protected override void Connect(SmtpClient client)
        {
            client.Connect(SmtpServer, SmtpPort, SecureSocketOptions.Auto);
        }

        /// <inheritdoc />
        protected override void Authenticate(SmtpClient client)
        {
            client.Authenticate(SmtpUserName, SmtpPassword);
        }

        /// <inheritdoc />
        public override string ClientName => "Outlook SMTP Client (MailKit)";
    }

}