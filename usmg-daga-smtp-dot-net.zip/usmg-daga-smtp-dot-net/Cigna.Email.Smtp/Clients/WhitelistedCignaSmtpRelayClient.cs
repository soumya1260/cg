﻿using MailKit.Net.Smtp;

namespace Cigna.Email.Smtp.Clients
{
    /// <summary>
    /// Provides an SMTP client that works with the Cigna SMTP Relays on
    /// whitelisted servers.  See: https://getsmtp.cigna.com/Default.aspx
    /// </summary>
    public sealed class WhitelistedCignaSmtpRelayClient : MailKitSmtpClient
    {
        //
        // Cigna's internal SMTP relays use port 25
        //
        protected override int SmtpPort => 25;

        public WhitelistedCignaSmtpRelayClient(string smtpServer, string smtpUserName, string smtpPassword)
            : base(smtpServer, smtpUserName, smtpPassword)
        {}

        protected override void Authenticate(SmtpClient client)
        {
            //
            // Do nothing!  Whitelisted servers don't authenticate.
            //
        }

        public override string ClientName => "Whitelisted Cigna SMTP Relay (MailKit)";
    }
}