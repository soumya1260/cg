﻿using Cigna.Email.Smtp.Contracts;

namespace Cigna.Email.Smtp.Clients
{
     /// <summary>
     /// Fake SMTP client suitable for use in unit testing or in localhost
     /// development scenarios where email does not need to be sent anywhere.
     /// </summary>
    public sealed class FakeSmtpClient : SmtpClient
    {
        /// <inheritdoc />
        public FakeSmtpClient(
            string smtpServer,
            string smtpUserName,
            string smtpPassword)
            : base(smtpServer, smtpUserName, smtpPassword)
        {}

        /// <inheritdoc />
        public override bool Send(Message message)
        {
            return true;
        }

        /// <inheritdoc />
        public override string ClientName => "Fake SMTP client";
    }
}
