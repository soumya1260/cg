﻿using MailKit.Net.Smtp;

namespace Cigna.Email.Smtp.Clients
{
    /// <summary>
    /// Provides an SMTP client that works with the Cigna SMTP Relays using
    /// service account authentication.
    /// See: https://getsmtp.cigna.com/Default.aspx
    /// </summary>
    public sealed class AuthenticatedCignaSmtpRelayClient : MailKitSmtpClient
    {
        //
        // Cigna's internal SMTP relays use port 25
        //
        /// <inheritdoc />
        protected override int SmtpPort => 25;

        /// <inheritdoc />
        public AuthenticatedCignaSmtpRelayClient(
            string smtpServer,
            string smtpUserName,
            string smtpPassword)
            : base(smtpServer, smtpUserName, smtpPassword)
        {}

        /// <inheritdoc />
        protected override void Authenticate(SmtpClient client)
        {
            client.Authenticate(SmtpUserName, SmtpPassword);
        }

        /// <inheritdoc />
        public override string ClientName =>
            "Authenticated Cigna SMTP Relay (MailKit)";
    }

}