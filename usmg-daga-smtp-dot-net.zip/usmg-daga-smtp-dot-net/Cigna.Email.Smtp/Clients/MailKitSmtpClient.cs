﻿using MailKit.Net.Smtp;
using MimeKit;
using System.Collections.Generic;
using System.Linq;

namespace Cigna.Email.Smtp.Clients
{
    /// <summary>
    /// Abstract class that simplifies the creation of MailKit-based SMTP
    /// clients.
    /// </summary>
    public abstract class MailKitSmtpClient : Contracts.SmtpClient
    {
        /// <summary>
        /// SMTP Port number.  Typically 25 (relay), 587 (TLS) or 465 (SSL/obsolete).
        /// </summary>
        protected abstract int SmtpPort { get; }

        protected MailKitSmtpClient(
            string smtpServer,
            string smtpUserName,
            string smtpPassword) 
            : base(smtpServer, smtpUserName, smtpPassword)
        {}

        /// <inheritdoc />
        public override bool Send(Message message)
        {
            var outgoingMessage = PrepareOutgoingMessage(message);

            using (var client = new SmtpClient())
#if NET6_0_OR_GREATER
            ;
#elif NETSTANDARD
            {
#endif
                Connect(client);
                Authenticate(client);
                client.Send(outgoingMessage);
                client.Disconnect(true);
#if NETSTANDARD
            }
#endif

            return true;
        }

        public static MimeMessage PrepareOutgoingMessage(Message message)
        {
            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = string.IsNullOrWhiteSpace(message.HtmlTextBody)
                    ? null
                    : message.HtmlTextBody,

                TextBody = string.IsNullOrWhiteSpace(message.PlainTextBody)
                    ? null
                    : message.PlainTextBody
            };

            if (message.Attachments.Any())
            {
                AddAttachments(message.Attachments, bodyBuilder);
            }

            var outgoingMessage = new MimeMessage
            {
                Subject = message.Subject,
                Body = bodyBuilder.ToMessageBody()
            };
            
            AddAddresses(message.From, outgoingMessage.From);
            AddAddresses(message.To, outgoingMessage.To);
            AddAddresses(message.Cc, outgoingMessage.Cc);
            AddAddresses(message.Bcc, outgoingMessage.Bcc);
            return outgoingMessage;
        }

        private static void AddAttachments(
            EmailAttachmentCollection attachments,
            BodyBuilder bodyBuilder)
        {
            foreach (var attachment in attachments)
            {
                bodyBuilder.Attachments.Add(
                    attachment.FileName,
                    attachment.Content,
                    ContentType.Parse(attachment.ContentType));
            }
        }

        /// <summary>
        ///     Overridable Connect method.  You can override this method if you
        ///     want to supply additional options to the MailKit
        ///     `client.Connect()` method.
        /// </summary>
        /// <param name="client"></param>
        protected virtual void Connect(SmtpClient client)
        {
            client.Connect(SmtpServer, SmtpPort);
        }

        /// <summary>
        ///     You must override this method.  If your server doesn't require
        ///     authentication (because it is whitelisted, for example), you can
        ///     supply an empty method.
        /// 
        ///     Otherwise, override with a method that makes a call to
        ///     `client.Authenticate()`.
        /// </summary>
        /// <param name="client">SmtpClient object to authenticate</param>
        protected abstract void Authenticate(SmtpClient client);

        /// <summary>
        ///     Helper method to convert the abstraction interface's address
        ///     list to the format used by MailKit.
        /// </summary>
        /// <param name="source">
        ///     a list of EmailAddress objects
        /// </param>
        /// <param name="destination">
        ///     The container to receive the email addresses from
        ///     <paramref name="source">source</paramref>
        /// </param>
        private static void AddAddresses(
            List<EmailAddress> source,
            InternetAddressList destination)
        {
            if (source == null || source.Count == 0) return;

            foreach (var address in source)
            {
                destination.Add(new MailboxAddress(address.DisplayName, address.Address));
            }
        }
    }
}