
[//]: # (Nothing to see here.  Skip past this badge gobbledegook to get to the GOOD STUFF.)

[![Build Status](https://w2-jenkins.sys.cigna.com/buildStatus/icon?job=HEALTHSPRING/CHSDEVOPS/GBS-DigitalApps/SmtpLibraryBuild)](https://w2-jenkins.sys.cigna.com/job/HEALTHSPRING/job/CHSDEVOPS/job/GBS-DigitalApps/job/SmtpLibraryBuild/) [![Quality Gate Status](https://sonarqube.sys.cigna.com/api/project_badges/measure?project=CHS.DigApps.Cigna.Email.Smtp&metric=alert_status&token=sqb_5aeb588fcf405db2b7eb4b76c79a48a91a4c0ed9)](https://sonarqube.sys.cigna.com/dashboard?id=CHS.DigApps.Cigna.Email.Smtp)

[//]: # (GOOD STUFF starts here.)

# Cigna.Email.Smtp

This is a library that abstracts email _send_ (SMTP) operations so that you can
easily incorporate email into your application with minimal code and configuration.

It uses an abstract factory pattern so that you can inject the correct factory to 
suit your particular use case.

While you can certainly build your own factories and client adapters, we provide 
several pre-built factories and clients.  These pre-built factories all deal
with the problem where localhost development within the Cigna network has to use
different types of servers than those that the test and production servers use.

## Advantages
- Very simple to use.
- Your code is written to an abstraction.
- All dependencies are injected - we even provide a fake client for you to use!
- Supplied clients are based on the .NET MailKit.
- There are clients and factories to support the Cigna SMTP Relays in both 
  Whitelisted and Authenticated modes.
- Built-in static address methods can convert comma-separated address lists to 
  the `List<EmailAddress>` objects used by the Message object.
- Addressing model supports "fancy" RFC-5322 addresses.  _E.g._: "Don Perkins" \<don.perkins@cigna.com\>
- Built for .NET Standard 2.0, which supports all modern .NET Frameworks except
  4.6.1.
- Native support for .NET 6.0
- If you need the old HealthSpring HSEmail/HSLogger proxy to support localhost 
  development, a client and factory is available as a separate NuGet package.
  (See `Cigna.Email.Smtp.HsLogger`)  We kept it separate because of its dependency
  on `HS.Core`.
  
  Note that the HSEmail proxy does not support .NET CORE/5/6/7 because
  of its dependency on HS.Core.  Also, HSEmail doesn't support the BCC email 
  header.

## Disadvantages
- None! :smile:

## How to use
1. Add the `Cigna.Email.Smtp` package to your project.  If you need the HSLogger/HSEmail proxy,
   also add `Cigna.Email.Smtp.HsLogger`.

2. Create a `MailFactory` or use an existing one included with the package.

3. Inject the `MailFactory` object into any class that needs SMTP support.

4. Create your `Message` object

5. Use the factory to create your client and SEND!


## Example Code

### .NET 8.0 Example

```c#
    using Cigna.Email.Smtp;
    using Cigna.Email.Smtp.Contracts;
    using Cigna.Email.Smtp.Factories;

    ...

    var factory = new WhitelistedSmtpRelayWithLocalhostFakeFactory(
	    builder.IsDevelopment, "server", "username", "password");

    var client = factory.CreateSmtpClient();

    var emailMessage = new Message()
    {
        To = EmailAddress.AddressList(_configuration["MailErrors:ToAddress"]),
        From = EmailAddress.SingleAddress(_configuration["MailErrors:FromAddress"]),
        Cc = new List<EmailAddress>(),
        Bcc = new List<EmailAddress>(),
        Subject = _configuration["MailErrors:Subject"],
        PlainTextBody = "You've got mail!",
        HtmlTextBody = "<h1>You've got mail!</h1>"
    };

    Attachments.AddAttachment(@"C:\PriceList.xlsx");

    bool sendSuccessful;
    try 
    {
        sendSuccessful = client.Send(emailMessage);
    }
    catch (Exception exception)
    {
        Logger.LogError(exception, "Something bad happened");
    }
```

In production code you would inject either the factory or the client as a dependency.

Note that the username and password must be supplied even if they are not used, 
such as with the `FakeSmtpClient` and `WhitelistedCignaSmtpRelayClient` above.  In these
cases, submitting an empty string or informative text is okay.


### .NET 4.6.2 Example

Here is a real-world example, taken from the CHS Online Provider Directory, that converts
from code that called HS.Log.SendMail() using an HS.EmailService.Email object:

```c#
using Cigna.Email.Smtp;
using Cigna.Email.Smtp.HsLogger;
using HS.HSEmailService;
using System;
using System.Collections.Generic;
using System.Configuration;
...
        public void SendEmail()
        {
            if (this._logWrapperEnum != LogWrapperEnum.SendEmail)
                return;

            var message = new Message
            {
                From = EmailAddress.AddressList(_myEmail.From),
                To = EmailAddress.AddressList(_myEmail.To),
                Cc = EmailAddress.AddressList(_myEmail.CC),
                Bcc = new List<EmailAddress>(),
                Subject = _myEmail.Subject,
                HtmlTextBody = _myEmail.isHTML ? _myEmail.Body : string.Empty,
                PlainTextBody = _myEmail.isHTML ? string.Empty : _myEmail.Body
            };

            bool developmentHost = ConfigurationManager.AppSettings["Environment"].ToLower().Contains("localhost");
            var smtpServer = ConfigurationManager.AppSettings["SmtpServer"];

            var client = 
                new WhitelistedSmtpRelayWithLocalhostHsLoggerFactory(developmentHost, smtpServer)
                .CreateSmtpClient();

            client.Send(message);
        }
```

All emails for the application vectored through this method, so we made our change here.

## Attachment support

MIME attachments are now supported as of version 2024.2.0.  All clients, including HSEmail, have attachment support.

Attachments are added to a Message object using the `Attachments.AddAttachment()` method.

This method has two overloads:

- `AddAttachment(string fileName)`: This overload will take the submitted file name and,
  under the covers, will create an `EmailAttachment` object by loadoing the file from
  the specified path.  If successful, it will then add the attachment to the Attachments
  collection.  It's very simple to use.  Just make sure that the file name is a 
  fully-qualified path or that its relative location is accessible from your application's
  current working folder.

- `AddAttachment(EmailAttachment attachment)`: This alternative overload is useful if you 
  have composed your document in memory rather than using a physical file.  In this case,
  you need to initialize the three EmailAttachment properties with your file contents and
  metadata before calling `AddAttachment()`.

  If you supply an attachment object with empty contents, the `AddAttachment()` method will
  attempt to load the Contents using the file name specified in FileName.  It will also 
  attempt to resolve the Content Type using MimeKit's conent type resolver.


## Built-in Clients

- `AuthenticatedCignaSmtpRelayClient` - Works with the Cigna SMTP relays in
  authenticated mode.  Assumes the relay uses port 25.

- `WhitelistedCignaSmtpRelayClient` - Works with the Cigna SMTP relays in
  whitelisted mode.  Assumes the relay uses port 25.

- `FakeSmtpClient` - Does nothing, but returns true for all calls to the
  `Send()` method.  Useful in localhost development if you don't actually
  need to send an email.  Also useful as a fake for unit testing.

- `ExchangeClient` - Not tested, but should work fine with a Microsoft
  Exchange server.  Assumes the Exchange server uses port 587 and SSL.
  Uses `MailKit`.


## Built-in Factories

Most of the built-in factories will use one client for the localhost
environment and a different client for the test and production 
environments.  This was designed around the restrictions of the 
Cigna SMTP Relay servers.

| **Factory**                                                    | **Localhost client**         | **All other environments**        |
|:---------------------------------------------------------------|:-----------------------------|:----------------------------------|
| AuthenticatedSmtpRelayWithLocalhostExchangeFactory             | ExchangeClient               | AuthenticatedCignaSmtpRelayClient |
| AuthenticatedSmtpRelayWithLocalhostFakeFactory                 | FakeSmtpClient               | AuthenticatedCignaSmtpRelayClient |
| WhitelistedSmtpRelayWithLocalhostAuthenticatedSmtpRelayFactory | AuthenticatedSmtpRelayClient | WhitelistedCignaSmtpRelayClient   |
| WhitelistedSmtpRelayWithLocalhostExchangeFactory               | ExchangeClient               | WhitelistedCignaSmtpRelayClient   |
| WhitelistedSmtpRelayWithLocalhostFakeFactory                   | FakeSmtpClient               | WhitelistedCignaSmtpRelayClient   |
| FakeSmtpClientFactory                                          | FakeSmtpClient               | FakeSmtpClient                    |


## Custom Clients

Writing your own SMTP client is fairly simple.  Just follow some simple
rules:
- Implement your client from `SmtpClient`
- Implement the ClientName property as a function body (`=>`)
- Provide an override for the `Send()` method
- Within `Send()`, map the `Message` object to the client you wish to use.

If you just want to tweak how MailKt sends messages, you can simplify
your work by deriving your implementation from the built-in `MailKitSmtpClient`
abstract class.  This is how most of the built-in clients were implemented.

## Changelog

### 2024.2.0.\*
This release introduces Attachments. 

Subsequent builds under this version will be code cleaning
(refactoring) and security updates.  Any bug fixes will cause
me to update the version number's "hotfix" value (third
position).

#### Behavioral Changes
- Added support for attachments (finally!)

#### Documentation
- Added example for adding a file attachment by name.
- Documented the overloaded `Attachments.AddAttachment()` methods

----

### 2024.1.0.\*

Updated to latest versions of MailKit and MimeKit due to a
security issue with a library that MimeKit depends upon.

----

### 2023.1.0.27 

#### Behavioral changes

- The static `EmailAddress.CommaSeparatedAddressList()` method will now omit the
  Display Name if it is empty or is the same as the email address.
- :warning: ***BREAKING CHANGE*** :warning: The constructor overloads for 
  `EmailAddress` have been consolidated to a single constructor that accepts two
  optional parameters for `emailAddress` and `displayName`.  ***The order of
  parameters when using the two parameter constructor has changed!***  
  `emailAddress` is now the first parameter.
- :warning: ***BREAKING CHANGE*** :warning:  The overloads for the static method
  `EmailAddress.CommaSeparatedAddressList()` have been consolidated into a single
  method accepting two optional parameters.  ***The order of
  parameters when using the two parameter constructor has changed!***  
  `emailAddress` is now the first parameter.


#### Documentation fixes

- Lots of documentation to the various README files

#### Non-behavioral changes 

- Some refactoring throughout the code base to improve maintainability.
- Added lots of missing XMLDoc 
