﻿using Cigna.Email.Smtp.Contracts;
using System.Collections.Generic;
using System.Linq;

using Attachment = HS.HSEmailService.Attachment;

namespace Cigna.Email.Smtp.HsLogger
{
    /// <summary>
    /// Provides an SMTP client suitable for use with HSLogger/HSEmail
    /// </summary>
    public sealed class HsLoggerSmtpClient : SmtpClient
    {
        /// <inheritdoc />
        public HsLoggerSmtpClient(
            string smtpServer,
            string smtpUserName,
            string smtpPassword)
            : base(smtpServer, smtpUserName, smtpPassword) 
        { }

        /// <inheritdoc />
        public override bool Send(Message message)
        {
            var email = new HS.HSEmailService.Email
            {
                From = CsvList(message.From),
                To = CsvList(message.To),
                CC = CsvList(message.Cc),
                // Logger Email doesn't support BCC!
                Subject = message.Subject,
                Body = string.IsNullOrWhiteSpace(message.HtmlTextBody)
                    ? message.PlainTextBody
                    : message.HtmlTextBody,
                isHTML = !string.IsNullOrWhiteSpace(message.HtmlTextBody)
            };

            if (message.Attachments.Any()) 
                email.Attachments = ConvertToHsEmailAttachments(message.Attachments);

            HS.Log.SendEmail(email);

            return true;
        }

        private static Attachment[] ConvertToHsEmailAttachments(
            EmailAttachmentCollection attachments) =>
            attachments.Select(attachment =>
                new Attachment
                {
                    Bytes = attachment.Content,
                    ContentType = attachment.ContentType,
                    Filename = attachment.FileName
                }).ToArray();

        /// <inheritdoc />
        public override string ClientName => "HSEmail SMTP Client";

        private static string CsvList(List<EmailAddress> addresses) =>
            addresses == null || !addresses.Any()
                ? string.Empty
                : string.Join(",", addresses.Select(address => address.Address));
    }
}