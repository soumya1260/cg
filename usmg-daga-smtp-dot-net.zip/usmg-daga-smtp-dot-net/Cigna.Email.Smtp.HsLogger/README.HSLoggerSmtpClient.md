﻿# Cigna.Email.Smtp.HsLogger

This library provides an SMTP client and factories appropriate
for using the HSLogger/HSEmail client for localhost development
in applications that require access to the Cigna SMTP relays in
production.

`Cigna.Email.Smtp` and `HS.Core 5.0` are required dependencies.

## Built-in Client
- `HsLoggerSmtpClient` - This client uses the `HS.Log.SendMail()` method
  along with the `HS.HSEmailService.Email` data object to send email 
  using the HS.Log email proxy.

## Built-in Factories
- `AuthenticatedSmtpRelayWithLocalhostHsLoggerFactory` - This factory
  returns an `HsLoggerSmtpClient` in a localhost development environment
  and an `AuthenticatedCignaSmtpRelayClient` in all other environments.

- `WhitelistedSmtpRelayWithLocalhostHsLoggerFactory` - This factory
  returns an `HsLoggerSmtpClient` in a localhost development environment
  and a `WhitelistedCignaSmtpRelayClient` in all other environments.


## Configuration
Because the underlying HSLogger email client uses Windows
Communication Foundation (WCF), a significant amount of XML
configuration is required in order to use this library.