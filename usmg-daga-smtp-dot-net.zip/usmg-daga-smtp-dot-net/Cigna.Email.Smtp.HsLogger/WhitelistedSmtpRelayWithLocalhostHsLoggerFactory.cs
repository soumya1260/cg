﻿using Cigna.Email.Smtp.Clients;
using Cigna.Email.Smtp.Contracts;

namespace Cigna.Email.Smtp.HsLogger
{
    public sealed class WhitelistedSmtpRelayWithLocalhostHsLoggerFactory: SmtpClientFactory
    {
        /// <inheritdoc />
        public WhitelistedSmtpRelayWithLocalhostHsLoggerFactory(
            bool localhost,
            string smtpServer,
            string smtpUserName = "",
            string smtpPassword = "")
            : base(localhost, smtpServer, smtpUserName, smtpPassword)
        {}

        /// <inheritdoc />
        public override SmtpClient CreateSmtpClient() =>
            Localhost 
                ? (SmtpClient) new HsLoggerSmtpClient(SmtpServer, SmtpUserName, SmtpPassword)
                : new WhitelistedCignaSmtpRelayClient(SmtpServer, SmtpUserName, SmtpPassword);
    }
}