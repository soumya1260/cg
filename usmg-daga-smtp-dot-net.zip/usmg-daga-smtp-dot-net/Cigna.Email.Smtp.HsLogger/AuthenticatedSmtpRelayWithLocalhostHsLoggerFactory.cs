﻿using Cigna.Email.Smtp.Clients;
using Cigna.Email.Smtp.Contracts;

namespace Cigna.Email.Smtp.HsLogger
{
    public sealed class AuthenticatedSmtpRelayWithLocalhostHsLoggerFactory: SmtpClientFactory
    {
        /// <inheritdoc />
        public AuthenticatedSmtpRelayWithLocalhostHsLoggerFactory(
            bool localhost,
            string smtpServer,
            string smtpUserName,
            string smtpPassword)
            : base(localhost, smtpServer, smtpUserName, smtpPassword)
        {}

        /// <inheritdoc />
        public override SmtpClient CreateSmtpClient()
        {
            return Localhost 
                ? (SmtpClient) new HsLoggerSmtpClient(SmtpServer, SmtpUserName, SmtpPassword)
                : new AuthenticatedCignaSmtpRelayClient(SmtpServer, SmtpUserName, SmtpPassword);
        }
    }
}