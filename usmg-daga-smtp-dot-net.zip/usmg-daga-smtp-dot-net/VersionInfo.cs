﻿using System.Reflection;

[assembly: AssemblyVersion("2024.2.0.0")]
[assembly: AssemblyFileVersion("2024.2.0.0")]

[assembly: AssemblyCopyright("Copyright © 2024 Cigna - All Rights Reserved")]
