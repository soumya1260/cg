CREATE TABLE [EOB].[EOB_0005Comments_Archive]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_ProcessHeaderID] DEFAULT ((-1)),
[Insured_PolicyNumber] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_Insured_PolicyNumber] DEFAULT (''),
[IncurredYear] [int] NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_IncurredYear] DEFAULT ((1980)),
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_Source] DEFAULT (''),
[ClaimType] [char] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_ClaimType] DEFAULT ('DF'),
[DocumentID] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_DocumentID] DEFAULT (''),
[RecordType] [varchar] (4) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_RecordType] DEFAULT ('0005'),
[Key] [varchar] (23) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_Key] DEFAULT (''),
[Version] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_Version] DEFAULT ('05'),
[Claim_Sequence] [varchar] (6) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_Claim_Sequence] DEFAULT (''),
[Claim_Number] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_Claim_Number] DEFAULT (''),
[Line_Number] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_Line_Number] DEFAULT ('000'),
[Notes_Code] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_Notes_Code] DEFAULT (''),
[Description] [varchar] (200) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_Description] DEFAULT (''),
[Open_Field1] [varchar] (100) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_Open_Field1] DEFAULT (''),
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_CreateID] DEFAULT (suser_sname()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_UpdateID] DEFAULT (suser_sname()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_0005Comments_Archive_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_0005Comments_Archive] ADD CONSTRAINT [PK_EOB_0005Comments_Archive] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [Insured_PolicyNumber], [IncurredYear], [Source], [ClaimType], [Claim_Number], [Line_Number], [Notes_Code], [Open_Field1])
GO
