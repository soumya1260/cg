CREATE TABLE [EOB].[Rx_Plan_Tiers]
(
[ContractCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PBPCode] [varchar] (4) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PlanYear] [int] NOT NULL,
[Tier] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Par_Ind] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[CoInsurance_Percentage] [decimal] (9, 2) NOT NULL
)
GO
ALTER TABLE [EOB].[Rx_Plan_Tiers] ADD CONSTRAINT [CHK_Rx_Plan_Tiers_Contract_LENGTH] CHECK ((len([ContractCode])=(5)))
GO
ALTER TABLE [EOB].[Rx_Plan_Tiers] ADD CONSTRAINT [CHK_Rx_Plan_Tiers_PBP_LENGTH] CHECK ((len([PBPCode])>=(3)))
GO
ALTER TABLE [EOB].[Rx_Plan_Tiers] ADD CONSTRAINT [CHK_Rx_Plan_Tiers_PlanYear_Year] CHECK (([PlanYear]>=(1900) AND [PlanYear]<=(9999)))
GO
ALTER TABLE [EOB].[Rx_Plan_Tiers] ADD CONSTRAINT [PK_Rx_Plan_Tiers] PRIMARY KEY CLUSTERED  ([ContractCode], [PBPCode], [PlanYear], [Tier], [Par_Ind])
GO
