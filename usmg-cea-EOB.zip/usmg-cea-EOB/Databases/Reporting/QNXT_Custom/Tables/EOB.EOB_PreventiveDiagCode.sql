CREATE TABLE [EOB].[EOB_PreventiveDiagCode]
(
[GroupId] [int] NOT NULL,
[CodeId] [varchar] (8) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
ALTER TABLE [EOB].[EOB_PreventiveDiagCode] ADD CONSTRAINT [PK_EOB_PreventiveDiagCode] PRIMARY KEY CLUSTERED  ([GroupId], [CodeId])
GO
