CREATE TABLE [EOB].[EOB_Recon_Purge]
(
[ProcessHeaderID] [int] NOT NULL,
[ClaimID] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[MemberID] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[EOBFileName] [varchar] (100) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[CreateDate] [smalldatetime] NOT NULL,
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[LastUpdate] [smalldatetime] NOT NULL,
[FTP_Complete] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[EOBFileGenerationDate] [varchar] (8) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL,
[IsReceived] [bit] NULL,
[MailDate] [varchar] (8) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL,
[Purge_ProcessHeaderID] [int] NULL
)
GO
