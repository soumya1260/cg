CREATE TABLE [EOB].[EOB_IDN_DenialLanguage]
(
[MessageID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Status] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Par] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[NonPar] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
