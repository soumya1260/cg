CREATE TABLE [EOB].[EOB_0003ServiceLine_Archive]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_ProcessHeaderID] DEFAULT ((-1)),
[Insured_PolicyNumber] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Insured_PolicyNumber] DEFAULT (''),
[Claim_Number] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Claim_Number] DEFAULT (''),
[ClaimLineID] [int] NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_ClaimLineID] DEFAULT ((1)),
[DocumentID] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_DocumentID] DEFAULT (''),
[EncounterType] [char] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_EncounterType] DEFAULT ('DF'),
[IncurredYear] [int] NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_IncurredYear] DEFAULT ((1980)),
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Source] DEFAULT (''),
[RecordType] [varchar] (4) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_RecordType] DEFAULT ('0003'),
[Key] [varchar] (23) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Key] DEFAULT (''),
[Version] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Version] DEFAULT ('05'),
[Claim_Sequence] [varchar] (6) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Claim_Sequence] DEFAULT (''),
[Line_Number] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Line_Number] DEFAULT ('000'),
[Type_Of_Service] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Type_Of_Service] DEFAULT (''),
[Procedure_Code] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Procedure_Code] DEFAULT (''),
[Place_Of_Service] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Place_Of_Service] DEFAULT (''),
[Units] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Units] DEFAULT (''),
[Procedure] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Procedure] DEFAULT (''),
[Dates_Of_Service] [varchar] (17) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Dates_Of_Service] DEFAULT (''),
[Total_Charge] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Total_Charge] DEFAULT ((0)),
[Discount] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Discount] DEFAULT ((0)),
[Ineligible] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Ineligible] DEFAULT ((0)),
[Pended] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Pended] DEFAULT ((0)),
[Allowed] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Allowed] DEFAULT ((0)),
[Notes_Code1] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Notes_Code1] DEFAULT (''),
[Notes_Code2] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Notes_Code2] DEFAULT (''),
[Notes_Code3] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Notes_Code3] DEFAULT (''),
[Deductible] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Deductible] DEFAULT ((0)),
[Copay] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Copay] DEFAULT ((0)),
[Coinsurance] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Coinsurance] DEFAULT ((0)),
[Balance] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Balance] DEFAULT ((0)),
[Percent] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Percent] DEFAULT ((0)),
[Other_Carrier] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Other_Carrier] DEFAULT (''),
[Payment] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Payment] DEFAULT ((0)),
[Patient_Responsibility] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Patient_Responsibility] DEFAULT ((0)),
[Description] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Description] DEFAULT (''),
[Tooth_Number] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Tooth_Number] DEFAULT (''),
[Tooth_Surface] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Tooth_Surface] DEFAULT (''),
[Provider_TIN] [varchar] (9) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Provider_TIN] DEFAULT (''),
[Provider_SubTIN] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Provider_SubTIN] DEFAULT (''),
[Alt_ProviderID] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Alt_ProviderID] DEFAULT (''),
[Provider_Name] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Provider_Name] DEFAULT (''),
[Provider_Address1] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Provider_Address1] DEFAULT (''),
[Provider_Address2] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Provider_Address2] DEFAULT (''),
[Provider_Address3] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Provider_Address3] DEFAULT (''),
[Patient_Account_Number] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Patient_Account_Number] DEFAULT (''),
[Shade_Flag] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Shade_Flag] DEFAULT (''),
[Other_Amount1] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Other_Amount1] DEFAULT ((0)),
[Other_Amount2] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Other_Amount2] DEFAULT ((0)),
[Other_Amount3] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Other_Amount3] DEFAULT ((0)),
[Other_Amount4] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Other_Amount4] DEFAULT ((0)),
[Other_Amount5] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Other_Amount5] DEFAULT ((0)),
[Open_Field1] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Open_Field1] DEFAULT (''),
[Open_Field2] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Open_Field2] DEFAULT (''),
[Open_Field3] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Open_Field3] DEFAULT (''),
[Open_Field4] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Open_Field4] DEFAULT (''),
[Open_Field5] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Open_Field5] DEFAULT (''),
[Open_Field6] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Open_Field6] DEFAULT (''),
[Open_Field7] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Open_Field7] DEFAULT (''),
[Open_Field8] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Open_Field8] DEFAULT (''),
[Open_Field9] [varchar] (200) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Open_Field9] DEFAULT (''),
[Open_Field10] [varchar] (200) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_Open_Field10] DEFAULT (''),
[RX_Number] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_RX_Number] DEFAULT (''),
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_CreateID] DEFAULT (suser_sname()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_UpdateID] DEFAULT (suser_sname()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_0003ServiceLine_Archive_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_EncounterType] CHECK (([EncounterType]='DF' OR [EncounterType]='SU' OR [EncounterType]='RX' OR [EncounterType]='EN' OR [EncounterType]='CL'))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Allowed] CHECK ((isnumeric([Allowed])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Balance] CHECK ((isnumeric([Balance])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Coinsurance] CHECK ((isnumeric([Coinsurance])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Copay] CHECK ((isnumeric([Copay])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Deductible] CHECK ((isnumeric([Deductible])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Discount] CHECK ((isnumeric([Discount])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Ineligible] CHECK ((isnumeric([Ineligible])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Other_Amount1] CHECK ((isnumeric([Other_Amount1])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Other_Amount2] CHECK ((isnumeric([Other_Amount2])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Other_Amount3] CHECK ((isnumeric([Other_Amount3])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Other_Amount4] CHECK ((isnumeric([Other_Amount4])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Other_Amount5] CHECK ((isnumeric([Other_Amount5])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Patient_Responsibility] CHECK ((isnumeric([Patient_Responsibility])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Payment] CHECK ((isnumeric([Payment])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Total_Charge] CHECK ((isnumeric([Total_Charge])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [CHK_EOB_0003ServiceLine_Archive_Line_Number] CHECK ((len(ltrim(rtrim([Line_Number])))=(3)))
GO
ALTER TABLE [EOB].[EOB_0003ServiceLine_Archive] ADD CONSTRAINT [PK_EOB_0003ServiceLine_Archive] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [Claim_Number], [Line_Number], [EncounterType], [Source])
GO
