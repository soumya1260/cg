CREATE TABLE [EOB].[EOB_MemberLanguageXref]
(
[languageid] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[description] [varchar] (255) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
ALTER TABLE [EOB].[EOB_MemberLanguageXref] ADD CONSTRAINT [PK_EOB_MemberLanguageXref] PRIMARY KEY CLUSTERED  ([languageid], [description])
GO
