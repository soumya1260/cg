CREATE TABLE [EOB].[EOB_OptSup_Plan]
(
[FullPlanID] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[QNXTPlanID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[UPID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Year] [smallint] NOT NULL,
[ServCode] [varchar] (6) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[OptLevel] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Active] [bit] NOT NULL CONSTRAINT [DF_OptSup_Plan_Active] DEFAULT ((1)),
[EffDate] [date] NOT NULL CONSTRAINT [DF_OptSup_Plan_EffDate] DEFAULT ('1/1/1900'),
[TermDate] [date] NOT NULL CONSTRAINT [DF_OptSup_Plan_TermDate] DEFAULT ('12/31/2078'),
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_OptSup_Plan_CreateID] DEFAULT (suser_sname()),
[CreateDate] [datetime] NOT NULL CONSTRAINT [DF_OptSup_Plan_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_OptSup_Plan_UpdateID] DEFAULT (suser_sname()),
[LastUpdate] [datetime] NOT NULL CONSTRAINT [DF_OptSup_Plan_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_OptSup_Plan] ADD CONSTRAINT [CHK_OptSup_Plan_OptLevel_LENGTH] CHECK ((len([OptLevel])>=(4)))
GO
ALTER TABLE [EOB].[EOB_OptSup_Plan] ADD CONSTRAINT [CHK_OptSup_Plan_ServCode_LENGTH] CHECK ((len([ServCode])>=(4)))
GO
ALTER TABLE [EOB].[EOB_OptSup_Plan] ADD CONSTRAINT [CHK_OptSup_Plan_UPID_LENGTH] CHECK ((len([UPID])>=(8)))
GO
ALTER TABLE [EOB].[EOB_OptSup_Plan] ADD CONSTRAINT [CHK_OptSup_Plan_Year_LENGTH] CHECK ((len([Year])=(4)))
GO
ALTER TABLE [EOB].[EOB_OptSup_Plan] ADD CONSTRAINT [PK_OptSup_Plan] PRIMARY KEY CLUSTERED  ([FullPlanID], [QNXTPlanID], [UPID], [Year] DESC, [ServCode], [OptLevel], [Active] DESC, [EffDate] DESC)
GO
