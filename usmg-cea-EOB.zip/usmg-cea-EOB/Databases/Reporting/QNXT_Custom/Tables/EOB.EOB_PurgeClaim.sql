CREATE TABLE [EOB].[EOB_PurgeClaim]
(
[ProcessHeaderID] [int] NOT NULL,
[Insured_PolicyNumber] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimId] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Recipient] [varchar] (600) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Check_Number] [varchar] (16) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Check_Amount] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Paid_Date] [varchar] (8) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_PurgeClaim_CreateDate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_PurgeClaim] ADD CONSTRAINT [PK_EOB_PurgeClaim] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [Insured_PolicyNumber], [ClaimId], [Paid_Date])
GO
