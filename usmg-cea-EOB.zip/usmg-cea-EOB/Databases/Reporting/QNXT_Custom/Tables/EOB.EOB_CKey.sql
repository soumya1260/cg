CREATE TABLE [EOB].[EOB_CKey]
(
[IncurredYear] [int] NOT NULL,
[CKey_FileSeqID] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Uid] [int] NOT NULL IDENTITY(1, 1)
)
GO
