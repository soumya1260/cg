CREATE TABLE [EOB].[EOB_PartBPharmacy]
(
[ClaimID] [varchar] (18) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[MemberID] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimStatus] [char] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[CurrentEligibiltyStatus] [char] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PaidDate] [int] NOT NULL,
[BeginServiceDate] [int] NOT NULL,
[EndServiceDate] [int] NOT NULL,
[NDC] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[NDCDesc] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ProviderName] [varchar] (55) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ProviderID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[BilledAmount] [decimal] (9, 2) NOT NULL,
[DeductibleAmount] [decimal] (9, 2) NOT NULL,
[CopayAmount] [decimal] (9, 2) NOT NULL,
[CoinsuranceAmount] [decimal] (9, 2) NOT NULL,
[TDC] [decimal] (9, 2) NOT NULL,
[PatientPay] [decimal] (9, 2) NOT NULL,
[OtherPay] [decimal] (9, 2) NOT NULL,
[ApprovedAmount] [decimal] (9, 2) NOT NULL,
[Active] [bit] NOT NULL CONSTRAINT [DF_Active] DEFAULT ((1)),
[LoadDate] [datetime] NOT NULL,
[LastUpdateKey] [int] NOT NULL,
[SourceDataKey] [int] NOT NULL,
[ContractCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PBPCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Tier] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_PartBPharmacy_Tier] DEFAULT ('')
)
GO
ALTER TABLE [EOB].[EOB_PartBPharmacy] ADD CONSTRAINT [CHK_Contract_LENGTH] CHECK ((len([ContractCode])=(5) OR len([ContractCode])=(0)))
GO
ALTER TABLE [EOB].[EOB_PartBPharmacy] ADD CONSTRAINT [CHK_PBP_LENGTH] CHECK ((len([PBPCode])=(5) OR len([PBPCode])=(4) OR len([PBPCode])=(3) OR len([PBPCode])=(0)))
GO
ALTER TABLE [EOB].[EOB_PartBPharmacy] ADD CONSTRAINT [PK_EOB_PartBPharmacy] PRIMARY KEY CLUSTERED  ([ClaimID], [ClaimStatus], [LoadDate])
GO
CREATE NONCLUSTERED INDEX [IX_MemID] ON [EOB].[EOB_PartBPharmacy] ([MemberID]) INCLUDE ([BeginServiceDate], [EndServiceDate], [NDC], [PaidDate], [ProviderID])
GO
