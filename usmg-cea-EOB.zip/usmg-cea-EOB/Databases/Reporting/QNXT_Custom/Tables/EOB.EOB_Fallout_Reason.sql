CREATE TABLE [EOB].[EOB_Fallout_Reason]
(
[ClaimType] [char] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ReasonID] [tinyint] NOT NULL,
[Description] [varchar] (255) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Is_Valid] [bit] NOT NULL,
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Fallout_Reason_CreateID] DEFAULT (suser_name()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Fallout_Reason_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Fallout_Reason_UpdateID] DEFAULT (suser_name()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Fallout_Reason_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_Fallout_Reason] ADD CONSTRAINT [CHK_EOB_Fallout_Reason_ClaimType] CHECK (([ClaimType]='RX' OR [ClaimType]='EN' OR [ClaimType]='CL'))
GO
ALTER TABLE [EOB].[EOB_Fallout_Reason] ADD CONSTRAINT [PK_EOB_Fallout_Reason] PRIMARY KEY CLUSTERED  ([ClaimType], [ReasonID])
GO
