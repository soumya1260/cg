CREATE TABLE [EOB].[EOB_Run_Detail]
(
[RunRequestID] [int] NOT NULL,
[ClaimID] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[MemberID] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Source] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
