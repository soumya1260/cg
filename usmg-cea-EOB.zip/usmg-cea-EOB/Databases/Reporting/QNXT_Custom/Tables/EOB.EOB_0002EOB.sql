CREATE TABLE [EOB].[EOB_0002EOB]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_EOB_0002EOB_ProcessHeaderID] DEFAULT ((-1)),
[DocumentID] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_DocumentID] DEFAULT (''),
[IncurredYear] [int] NOT NULL CONSTRAINT [DF_EOB_0002EOB_IncurredYear] DEFAULT ((1980)),
[MemberPlan] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_MemberPlan] DEFAULT (''),
[ServiceCategory] [tinyint] NOT NULL CONSTRAINT [DF_EOB_0002EOB_ServiceCategory] DEFAULT (''),
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Source] DEFAULT (''),
[RecordType] [varchar] (4) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_RecordType] DEFAULT ('0002'),
[Key] [varchar] (23) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Key] DEFAULT (''),
[Version] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Version] DEFAULT ('05'),
[Claim_Sequence] [varchar] (6) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Claim_Sequence] DEFAULT (''),
[Claim_Number] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Claim_Number] DEFAULT (''),
[Insured_Name] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Insured_Name] DEFAULT (''),
[Insured_Social] [varchar] (9) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Insured_Social] DEFAULT (''),
[Insured_PolicyNumber] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Insured_PolicyNumber] DEFAULT (''),
[Insured_Address1] [varchar] (35) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Insured_Address1] DEFAULT (''),
[Insured_Address2] [varchar] (35) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Insured_Address2] DEFAULT (''),
[Insured_Address3] [varchar] (35) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Insured_Address3] DEFAULT (''),
[Patient_Name] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Patient_Name] DEFAULT (''),
[Dependent_Number] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Dependent_Number] DEFAULT (''),
[Patient_Relationship] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_PatientRelationship] DEFAULT (''),
[Received_Date] [varchar] (8) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Received_Date] DEFAULT (''),
[Processed_Date] [varchar] (8) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_ProcessedDate] DEFAULT (''),
[Paid_Date] [varchar] (8) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Paid_Date] DEFAULT ('1/1/1980'),
[Processor_ID] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Processor_ID] DEFAULT (''),
[Processor_Name] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Processor_Name] DEFAULT (''),
[Claim_Year] [varchar] (4) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Claim_Year] DEFAULT (''),
[Group_Hierarchy1] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Group_Hierarchy1] DEFAULT (''),
[Group_Name1] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Group_Name1] DEFAULT ('Cigna-HealthSpring'),
[Group_Hierarchy2] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Group_Hierarchy2] DEFAULT (''),
[Group_Name2] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Group_Name2] DEFAULT (''),
[Group_Hierarchy3] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Group_Hierarchy3] DEFAULT (''),
[Group_Name3] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Group_Name3] DEFAULT (''),
[Group_Hierarchy4] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Group_Hierarchy4] DEFAULT (''),
[Group_Name4] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Group_Name4] DEFAULT (''),
[Check_Number] [varchar] (16) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Check_Number] DEFAULT (''),
[Check_Amount] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_CheckAmount] DEFAULT ((0)),
[Voucher_Number] [varchar] (16) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Voucher_Number] DEFAULT (''),
[FormLetter_Provider_Name] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_FormLetter_Provider_Name] DEFAULT (''),
[FormLetter_TIN] [varchar] (9) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_FormLetter_TIN] DEFAULT (''),
[FormLetter_Name] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_FormLetter_Name] DEFAULT (''),
[FormLetter_ID] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_FormLetter_ID] DEFAULT (''),
[Customer_Info1] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Customer_Info1] DEFAULT (''),
[Customer_Info2] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Customer_Info2] DEFAULT (''),
[Customer_Info3] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Customer_Info3] DEFAULT (''),
[Customer_Info4] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Customer_Info4] DEFAULT (''),
[Return_Logo] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Return_Logo] DEFAULT (''),
[Return_Style] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Return_Style] DEFAULT (''),
[Return_Name] [varchar] (70) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Return_Name] DEFAULT (''),
[Return_Address1] [varchar] (70) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Return_Address1] DEFAULT (''),
[Return_Address2] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Return_Address2] DEFAULT (''),
[Return_Address3] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Return_Address3] DEFAULT (''),
[Network] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Network] DEFAULT (''),
[Group_Logo] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Group_Logo] DEFAULT (''),
[PRE_Treatment_Flag] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_PRE_Treatment_Flag] DEFAULT (''),
[WaterMark1] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_WaterMark1] DEFAULT (''),
[WaterMark2] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_WaterMark2] DEFAULT (''),
[Copy_Number] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Copy_Number] DEFAULT ('01'),
[Billing_Code] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Billing_Code] DEFAULT (''),
[Open_Field1] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field1] DEFAULT (''),
[Open_Field2] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field2] DEFAULT (''),
[Open_Field3] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_OpenField3] DEFAULT ('DF'),
[Open_Field4] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field4] DEFAULT (''),
[Open_Field5] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field5] DEFAULT (''),
[Open_Field6] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field6] DEFAULT (''),
[Open_Field7] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field7] DEFAULT (''),
[Open_Field8] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field8] DEFAULT (''),
[Open_Field9] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field9] DEFAULT (''),
[Open_Field10] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field10] DEFAULT (''),
[Open_Field11] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field11] DEFAULT ('Bravo Health'),
[Open_Field12] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field12] DEFAULT ('Claims Department'),
[Open_Field13] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field13] DEFAULT ('PO Box 4432'),
[Open_Field14] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field14] DEFAULT ('Baltimore MD 21223'),
[Open_Field15] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field15] DEFAULT (''),
[Open_Field16] [varchar] (80) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field16] DEFAULT (''),
[Open_Field17] [varchar] (80) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field17] DEFAULT (''),
[Open_Field18] [varchar] (80) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field18] DEFAULT (''),
[Open_Field19] [varchar] (80) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field19] DEFAULT (''),
[Open_Field20] [varchar] (80) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field20] DEFAULT (''),
[Open_Field21] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field21] DEFAULT (''),
[Open_Field22] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field22] DEFAULT (''),
[Open_Field23] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field23] DEFAULT (''),
[Open_Field24] [varchar] (240) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field24] DEFAULT (''),
[Open_Field25] [varchar] (240) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Open_Field25] DEFAULT (''),
[Dakota_Image_Number] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Dakota_Image_Number] DEFAULT (''),
[Separator_Indicator] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Separator_Indicator] DEFAULT (''),
[Tax_ID] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Tax_ID] DEFAULT (''),
[National_Provider_ID_NPI] [varchar] (17) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_National_Provider_ID_NPI] DEFAULT (''),
[Return_Reason_Code] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Return_Reason_Code] DEFAULT (''),
[Return_Name2] [varchar] (70) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Return_Name2] DEFAULT (''),
[Dependent_Seq_Number] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_Dependent_Seq_Number] DEFAULT (''),
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_CreateID] DEFAULT (suser_sname()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_0002EOB_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0002EOB_UpdateID] DEFAULT (suser_sname()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_0002EOB_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_0002EOB] ADD CONSTRAINT [CHK_EOB_0002EOB_Open_Field10] CHECK (([Open_Field10]='' OR [Open_Field10]='Y'))
GO
ALTER TABLE [EOB].[EOB_0002EOB] ADD CONSTRAINT [CHK_EOB_0002EOB_OpenField3] CHECK (([Open_Field3]='DF' OR [Open_Field3]='SU' OR [Open_Field3]='RX' OR [Open_Field3]='EN' OR [Open_Field3]='CL'))
GO
ALTER TABLE [EOB].[EOB_0002EOB] ADD CONSTRAINT [CHK_EOB_0002EOB_Open_Field9] CHECK (([Open_Field9]='' OR [Open_Field9]='N' OR [Open_Field9]='Y'))
GO
ALTER TABLE [EOB].[EOB_0002EOB] ADD CONSTRAINT [CHK_EOB_0002EOB_CheckAmount] CHECK ((isnumeric([Check_Amount])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0002EOB] ADD CONSTRAINT [PK_EOB_0002EOB] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [Claim_Number], [Open_Field3], [Source])
GO
CREATE NONCLUSTERED INDEX [IX_EOB_0002EOB_IncurredYear] ON [EOB].[EOB_0002EOB] ([IncurredYear])
GO
CREATE NONCLUSTERED INDEX [IX_EOB_0002EOB_Insured_PolicyNumber] ON [EOB].[EOB_0002EOB] ([Insured_PolicyNumber])
GO
CREATE NONCLUSTERED INDEX [IX_EOB_0002EOB_OpenField3] ON [EOB].[EOB_0002EOB] ([Open_Field3])
GO
CREATE NONCLUSTERED INDEX [IX_EOB_0002EOB] ON [EOB].[EOB_0002EOB] ([Open_Field3]) INCLUDE ([Claim_Number], [IncurredYear], [Insured_PolicyNumber], [MemberPlan], [Open_Field1], [Open_Field2], [Open_Field21], [Open_Field24], [Source])
GO
