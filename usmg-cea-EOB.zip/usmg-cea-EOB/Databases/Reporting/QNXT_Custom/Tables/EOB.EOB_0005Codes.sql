CREATE TABLE [EOB].[EOB_0005Codes]
(
[NoteID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[CodeID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[CodeType] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Source] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[GroupType] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
ALTER TABLE [EOB].[EOB_0005Codes] ADD CONSTRAINT [PK_EOB.EOB_0005Codes] PRIMARY KEY CLUSTERED  ([NoteID], [CodeID], [CodeType], [Source], [GroupType])
GO
