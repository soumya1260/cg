CREATE TABLE [EOB].[EOB_NoteList]
(
[NoteID] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[SortKey] [int] NOT NULL,
[Identifier] [varchar] (25) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[NoteType] [varchar] (25) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[NoteText] [varchar] (max) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
ALTER TABLE [EOB].[EOB_NoteList] ADD CONSTRAINT [PK_EOB_NoteList] PRIMARY KEY CLUSTERED  ([NoteID], [Identifier])
GO
