CREATE TABLE [EOB].[EOB_MOOP]
(
[EnrollID] [varchar] (25) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[MemberID] [char] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[UPID] [char] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL,
[MinMemberEffectiveDate] [int] NOT NULL,
[MaxMemberEffectiveDate] [int] NOT NULL,
[InNetworkDeductible] [money] NULL,
[InNetworkMOOP] [numeric] (19, 4) NULL,
[OutNetworkDeductible] [numeric] (19, 4) NULL,
[OutNetworkMOOP] [numeric] (19, 4) NULL,
[InDeductPaid] [money] NULL,
[InMOOPPaid] [money] NULL,
[OutDeductPaid] [money] NULL,
[OutMOOPPaid] [money] NULL,
[LoadDate] [date] NOT NULL,
[RunBeginPeriod] [date] NOT NULL,
[RunEndPeriod] [date] NOT NULL,
[RowNumber] [int] NOT NULL IDENTITY(1, 1)
)
GO
CREATE NONCLUSTERED INDEX [idx_member_upid] ON [EOB].[EOB_MOOP] ([MemberID], [UPID]) INCLUDE ([MaxMemberEffectiveDate], [MinMemberEffectiveDate])
GO
