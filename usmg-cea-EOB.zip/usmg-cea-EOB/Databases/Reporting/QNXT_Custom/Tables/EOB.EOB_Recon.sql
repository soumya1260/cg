CREATE TABLE [EOB].[EOB_Recon]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_EOB_Recon_ProcessHeaderID] DEFAULT ((0)),
[ClaimID] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[MemberID] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[EOBFileName] [varchar] (100) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Recon_FileName] DEFAULT (''),
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Recon_Source] DEFAULT (''),
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Recon_CreateID] DEFAULT (suser_sname()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Recon_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Recon_UpdateID] DEFAULT (suser_sname()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Recon_LastUpdate] DEFAULT (getdate()),
[FTP_Complete] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Recon_FTP_Complete] DEFAULT (''),
[EOBFileGenerationDate] [varchar] (8) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL,
[IsReceived] [bit] NULL,
[MailDate] [varchar] (8) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL
)
GO
ALTER TABLE [EOB].[EOB_Recon] ADD CONSTRAINT [PK_EOB_Recon] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [ClaimID], [MemberID], [EOBFileName], [Source])
GO
