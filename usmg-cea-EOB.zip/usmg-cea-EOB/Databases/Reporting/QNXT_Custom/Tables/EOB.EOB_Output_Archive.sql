CREATE TABLE [EOB].[EOB_Output_Archive]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_EOB_Output_ProcessHeaderID_Archive] DEFAULT ((-1)),
[ClaimID] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_ClaimID_Archive] DEFAULT (''),
[ClaimLineID] [int] NOT NULL CONSTRAINT [DF_EOB_Output_ClaimLineID_Archive] DEFAULT ((0)),
[Insured_PolicyNumber] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_Insured_PolicyNumber_Archive] DEFAULT (''),
[IncurredYear] [int] NOT NULL CONSTRAINT [DF_EOB_Output_IncurredYear_Archive] DEFAULT ((1980)),
[RecordType] [varchar] (4) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_RecordType_Archive] DEFAULT (''),
[Claim_Sequence] [varchar] (6) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_Claim_Sequence_Archive] DEFAULT (''),
[CKey] [varchar] (17) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_CKey_Archive] DEFAULT (''),
[DocumentID] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_DocumentID_Archive] DEFAULT (''),
[DataRow] [varchar] (4000) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_DataRow_Archive] DEFAULT (''),
[ClaimType] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_ClaimType_Archive] DEFAULT (''),
[Source] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_Source_Archive] DEFAULT (''),
[SortKey] [int] NOT NULL CONSTRAINT [DF_EOB_Output_Archive_SortKey] DEFAULT ((1)),
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_CreateID_Archive] DEFAULT (suser_sname()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Output_CreateDate_Archive] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_UpdateID_Archive] DEFAULT (suser_sname()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Output_LastUpdate_Archive] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_Output_Archive] ADD CONSTRAINT [PK_EOB_Output_Archive] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [ClaimID], [ClaimLineID], [Insured_PolicyNumber], [IncurredYear], [RecordType], [DocumentID], [ClaimType], [Source], [SortKey])
GO
