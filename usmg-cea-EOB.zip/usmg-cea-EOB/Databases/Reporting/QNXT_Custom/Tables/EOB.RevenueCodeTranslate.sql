CREATE TABLE [EOB].[RevenueCodeTranslate]
(
[Code] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[CCMShortDescription] [varchar] (40) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Language] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
