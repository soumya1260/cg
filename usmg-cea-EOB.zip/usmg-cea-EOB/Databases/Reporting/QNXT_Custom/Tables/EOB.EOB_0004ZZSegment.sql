CREATE TABLE [EOB].[EOB_0004ZZSegment]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_ProcessHeaderID] DEFAULT ((-1)),
[Insured_PolicyNumber] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Insured_PolicyNumber] DEFAULT (''),
[Claim_Number] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Claim_Number] DEFAULT (''),
[ContractCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_ContractCode] DEFAULT (''),
[PBPCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_PBPCode] DEFAULT (''),
[IncurredYear] [int] NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_IncurredYear] DEFAULT ((1980)),
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Source] DEFAULT (''),
[DocumentID] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_DocumentID] DEFAULT (''),
[RecordType] [varchar] (4) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_RecordType] DEFAULT ('0004'),
[Key] [varchar] (23) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_EOB_0004ZZSegment_Key] DEFAULT (''),
[Version] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Version] DEFAULT ('05'),
[Claim_Sequence] [varchar] (6) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Claim_Sequence] DEFAULT (''),
[Total_Charge] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Claim_Sequence_Total_Charge] DEFAULT ((0)),
[Discount] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Discount] DEFAULT ((0)),
[Ineligible] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Ineligible] DEFAULT ((0)),
[Pended] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Pended] DEFAULT (''),
[Allowed] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Allowed] DEFAULT ((0)),
[Deductible] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Deductible] DEFAULT ((0)),
[Copay] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Copay] DEFAULT ((0)),
[Coinsurance] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Coinsurance] DEFAULT ((0)),
[Balance] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Balance] DEFAULT ((0)),
[Other_Carrier] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Other_Carrier] DEFAULT (''),
[Payment] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Payment] DEFAULT ((0)),
[Patient_Responsibility] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Patient_Responsibility] DEFAULT ((0)),
[Flex_Med_Annual] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Med_Annual] DEFAULT (''),
[Flex_Med_YTD_Claims] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Med_YTD_Claims] DEFAULT (''),
[Flex_Med_YTD_Contributions] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Med_YTD_Contributions] DEFAULT (''),
[Flex_Med_YTD_Payment] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Med_YTD_Payment] DEFAULT (''),
[Flex_Med_YTD_Remaining] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Med_YTD_Remaining] DEFAULT (''),
[Flex_Med_YTD_Balance] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Med_YTD_Balance] DEFAULT (''),
[Flex_Med_YTD_Denied] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Med_YTD_Denied] DEFAULT (''),
[Flex_Med_YTD_Pended] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Med_YTD_Pended] DEFAULT (''),
[Flex_Med_YTD_Deposit] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Med_YTD_Deposit] DEFAULT (''),
[Flex_Dep_Annual] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Dep_Annual] DEFAULT (''),
[Flex_Dep_YTD_Claims] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Dep_YTD_Claims] DEFAULT (''),
[Flex_Dep_YTD_Contributions] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Dep_YTD_Contributions] DEFAULT (''),
[Flex_Dep_YTD_Payment] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Dep_YTD_Payment] DEFAULT (''),
[Flex_Dep_YTD_Remaining] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Dep_YTD_Remaining] DEFAULT (''),
[Flex_Dep_YTD_Balance] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Dep_YTD_Balance] DEFAULT (''),
[Flex_Dep_YTD_Denied] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Dep_YTD_Denied] DEFAULT (''),
[Flex_Dep_YTD_Pended] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Dep_YTD_Pended] DEFAULT (''),
[Flex_Dep_YTD_Deposit] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Flex_Dep_YTD_Deposit] DEFAULT (''),
[Other_Amount1] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Other_Amount1] DEFAULT (''),
[Other_Amount2] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Other_Amount2] DEFAULT (''),
[Other_Amount3] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Other_Amount3] DEFAULT (''),
[Other_Amount4] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Other_Amount4] DEFAULT (''),
[Other_Amount5] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Other_Amount5] DEFAULT (''),
[Open_Field1] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Open_Field1] DEFAULT (''),
[Open_Field2] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Open_Field2] DEFAULT (''),
[Open_Field3] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Open_Field3] DEFAULT (''),
[Open_Field4] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Open_Field4] DEFAULT (''),
[Open_Field5] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_Open_Field5] DEFAULT (''),
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_CreateID] DEFAULT (suser_sname()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_UpdateID] DEFAULT (suser_sname()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_0004ZZSegment_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_0004ZZSegment] ADD CONSTRAINT [CHK_EOB_0004ZZSegment_Allowed] CHECK ((isnumeric([Allowed])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0004ZZSegment] ADD CONSTRAINT [CHK_EOB_0004ZZSegment_Balance] CHECK ((isnumeric([Balance])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0004ZZSegment] ADD CONSTRAINT [CHK_EOB_0004ZZSegment_Coinsurance] CHECK ((isnumeric([Coinsurance])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0004ZZSegment] ADD CONSTRAINT [CHK_EOB_0004ZZSegment_Copay] CHECK ((isnumeric([Copay])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0004ZZSegment] ADD CONSTRAINT [CHK_EOB_0004ZZSegment_Deductible] CHECK ((isnumeric([Deductible])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0004ZZSegment] ADD CONSTRAINT [CHK_EOB_0004ZZSegmentServiceLine_Discount] CHECK ((isnumeric([Discount])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0004ZZSegment] ADD CONSTRAINT [CHK_EOB_0004ZZSegment_Ineligible] CHECK ((isnumeric([Ineligible])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0004ZZSegment] ADD CONSTRAINT [CHK_EOB_0004ZZSegment_Payment] CHECK ((isnumeric([Payment])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0004ZZSegment] ADD CONSTRAINT [CHK_EOB_0004ZZSegment_Claim_Sequence_Total_Charge] CHECK ((isnumeric([Total_Charge])<>(0)))
GO
ALTER TABLE [EOB].[EOB_0004ZZSegment] ADD CONSTRAINT [PK_EOB_0004ZZSegment] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [Insured_PolicyNumber], [ContractCode], [PBPCode], [IncurredYear])
GO
CREATE NONCLUSTERED INDEX [IX_EOB_0004ZZSegment] ON [EOB].[EOB_0004ZZSegment] ([IncurredYear]) INCLUDE ([ContractCode], [PBPCode])
GO
