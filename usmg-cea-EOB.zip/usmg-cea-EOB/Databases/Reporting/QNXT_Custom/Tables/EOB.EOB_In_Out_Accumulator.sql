CREATE TABLE [EOB].[EOB_In_Out_Accumulator]
(
[accumid] [char] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[description] [char] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[accum_type] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[active] [int] NOT NULL
)
GO
ALTER TABLE [EOB].[EOB_In_Out_Accumulator] ADD CONSTRAINT [PK_EOB_In_Out_Accumulator] PRIMARY KEY CLUSTERED  ([accumid], [accum_type], [active])
GO
