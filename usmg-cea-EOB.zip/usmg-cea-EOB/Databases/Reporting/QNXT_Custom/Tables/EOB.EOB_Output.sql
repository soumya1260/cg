CREATE TABLE [EOB].[EOB_Output]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_EOB_Output_ProcessHeaderID] DEFAULT ((-1)),
[ClaimID] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_ClaimID] DEFAULT (''),
[ClaimLineID] [int] NOT NULL CONSTRAINT [DF_EOB_Output_ClaimLineID] DEFAULT ((0)),
[Insured_PolicyNumber] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_Insured_PolicyNumber] DEFAULT (''),
[IncurredYear] [int] NOT NULL CONSTRAINT [DF_EOB_Output_IncurredYear] DEFAULT ((1980)),
[RecordType] [varchar] (4) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_RecordType] DEFAULT (''),
[Claim_Sequence] [varchar] (6) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_Claim_Sequence] DEFAULT (''),
[CKey] [varchar] (17) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_CKey] DEFAULT (''),
[DocumentID] [varchar] (10) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_DocumentID] DEFAULT (''),
[DataRow] [varchar] (4000) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_DataRow] DEFAULT (''),
[ClaimType] [varchar] (3) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_ClaimType] DEFAULT (''),
[Source] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_Source] DEFAULT (''),
[SortKey] [int] NOT NULL CONSTRAINT [DF_EOB_Output_SortKey] DEFAULT ((1)),
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_CreateID] DEFAULT (suser_sname()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Output_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Output_UpdateID] DEFAULT (suser_sname()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Output_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_Output] ADD CONSTRAINT [PK_EOB_Output] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [ClaimID], [ClaimLineID], [Insured_PolicyNumber], [IncurredYear], [RecordType], [DocumentID], [ClaimType], [Source], [SortKey])
GO
