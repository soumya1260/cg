CREATE TABLE [EOB].[EOB_YearlyTotals_ClaimDetail_Archive]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_YT_CD_ArchiveProcessHeaderID] DEFAULT ((-1)),
[MemberID] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimID] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimLine] [int] NOT NULL,
[IncurredYear] [int] NOT NULL,
[ContractCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PBPCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimAmt] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ArchiveClaimAmt] DEFAULT ((0.00)),
[AmountPaid] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ArchiveAmountPaid] DEFAULT ((0.00)),
[CoPay] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ArchiveCoPay] DEFAULT ((0.00)),
[CoPayPerDiemAmt] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ArchiveCoPayPerDiemAmt] DEFAULT ((0.00)),
[BeneDeduct] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ArchiveBeneDeduct] DEFAULT ((0.00)),
[CoInsuranceAmt] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ArchiveCoInsuranceAmt] DEFAULT ((0.00)),
[Eligible] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ArchiveEligible] DEFAULT ((0.00)),
[SubmitDiscount] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ArchiveSubmitDiscount] DEFAULT ((0.00)),
[PayDiscount] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ArchivePayDiscount] DEFAULT ((0.00)),
[Par_Ind] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_YT_CD_ArchivePar_Ind] DEFAULT ('N'),
[IDN_Denied_Charge] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ArchiveIDN_Denied_Charge] DEFAULT ((0.00)),
[QNXTPlanID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_YT_CD_ArchiveQNXTPlanID] DEFAULT (''),
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
ALTER TABLE [EOB].[EOB_YearlyTotals_ClaimDetail_Archive] ADD CONSTRAINT [PK_EOB_YearlyTotals_ClaimDetail_Archive] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [MemberID], [ClaimID], [ClaimLine], [Source])
GO
