CREATE TABLE [EOB].[EOB_Run_Master]
(
[RunRequestID] [int] NOT NULL IDENTITY(1, 1),
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_ProcessHeaderID] DEFAULT (''),
[BeginDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Run_Master_BeginDate] DEFAULT (getdate()),
[EndDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Run_Master_EndDate] DEFAULT (getdate()),
[RunDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Run_Master_RunDate] DEFAULT (getdate()),
[Is_LateSubmission] [char] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Run_Master_Is_LateSubmission] DEFAULT ('N'),
[Is_Regen] [char] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Run_Master_Is_Regen] DEFAULT ('N'),
[Status] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Run_Master_Status] DEFAULT ('READY'),
[DisplayBeginDate] [smalldatetime] NOT NULL,
[DisplayEndDate] [smalldatetime] NOT NULL,
[RunYear] [int] NOT NULL,
[CL_Processed_Claims] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_CL_Processed_Claims] DEFAULT ((0)),
[CL_Processed_Members] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_Cl_Processed_Members] DEFAULT ((0)),
[EN_Processed_Claims] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_EN_Processed_Claims] DEFAULT ((0)),
[EN_Processed_Members] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_EN_Processed_Members] DEFAULT ((0)),
[RX_Processed_Claims] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_RX_Processed_Claims] DEFAULT ((0)),
[RX_Processed_Members] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_Processed_Members] DEFAULT ((0)),
[Total_Processed_Members] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_Total_Processed_Members] DEFAULT ((0)),
[CL_Sent_Claims] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_CL_Sent_Claims] DEFAULT ((0)),
[CL_Sent_Members] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_Cl_Sent_Members] DEFAULT ((0)),
[EN_Sent_Claims] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_EN_Sent_Claims] DEFAULT ((0)),
[EN_Sent_Members] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_EN_Sent_Members] DEFAULT ((0)),
[RX_Sent_Claims] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_RX_Sent_Claims] DEFAULT ((0)),
[RX_Sent_Members] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_Sent_Members] DEFAULT ((0)),
[Total_Sent_Members] [int] NOT NULL CONSTRAINT [DF_EOB_Run_Master_Total_Sent_Members] DEFAULT ((0)),
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Run_Master_CreateID] DEFAULT (suser_sname()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Run_Master_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Run_Master_UpdateID] DEFAULT (suser_sname()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Run_Master_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_Run_Master] ADD CONSTRAINT [PK_EOB_Run_Master] PRIMARY KEY CLUSTERED  ([RunRequestID], [RunDate])
GO
