CREATE TABLE [EOB].[EOB_PartBPharmacy_Archive]
(
[ClaimID] [varchar] (18) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[MemberID] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimStatus] [char] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[CurrentEligibiltyStatus] [char] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PaidDate] [int] NOT NULL,
[BeginServiceDate] [int] NOT NULL,
[EndServiceDate] [int] NOT NULL,
[NDC] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[NDCDesc] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ProviderName] [varchar] (55) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ProviderID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[BilledAmount] [decimal] (9, 2) NOT NULL,
[DeductibleAmount] [decimal] (9, 2) NOT NULL,
[CopayAmount] [decimal] (9, 2) NOT NULL,
[CoinsuranceAmount] [decimal] (9, 2) NOT NULL,
[TDC] [decimal] (9, 2) NOT NULL,
[PatientPay] [decimal] (9, 2) NOT NULL,
[OtherPay] [decimal] (9, 2) NOT NULL,
[ApprovedAmount] [decimal] (9, 2) NOT NULL,
[Active] [bit] NOT NULL,
[LoadDate] [datetime] NOT NULL,
[LastUpdateKey] [int] NOT NULL,
[SourceDataKey] [int] NOT NULL,
[ContractCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PBPCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Tier] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_PartBPharmacy_Archive_Tier] DEFAULT ('')
)
GO

GO
CREATE TRIGGER [EOB].[tU_EOB_PartBPharmacy_Archive] ON [EOB].[EOB_PartBPharmacy_Archive]
FOR UPDATE AS

SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
####################################################################################
-- Name:			tU_EOB_PartBPharmacy_Archive.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Adds a FOR UPDATE trigger to the tU_EOB_PartBPharmacy_Archive table.
-- 
-- Called by:		N/A
####################################################################################
-- Parameters
--     N/A
####################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
####################################################################################
*/

BEGIN TRY
	INSERT INTO EOB.EOB_PartBPharmacy_Archive_Audit (
				ChangeType, Time_Of_Change, ClaimID, MemberID, ClaimStatus, CurrentEligibiltyStatus, PaidDate, BeginServiceDate, EndServiceDate, NDC, NDCDesc, 
				ProviderName, ProviderID, BilledAmount, DeductibleAmount, CopayAmount, CoinsuranceAmount, TDC, PatientPay, OtherPay, ApprovedAmount, Active, 
				LoadDate, LastUpdateKey, SourceDataKey, ContractCode, PBPCode, Tier )
	SELECT 'CHANGE BEFORE', GETDATE(), Rx.ClaimID, Rx.MemberID, Rx.ClaimStatus, Rx.CurrentEligibiltyStatus, Rx.PaidDate, Rx.BeginServiceDate, Rx.EndServiceDate, Rx.NDC, Rx.NDCDesc, 
				Rx.ProviderName, Rx.ProviderID, Rx.BilledAmount, Rx.DeductibleAmount, Rx.CopayAmount, Rx.CoinsuranceAmount, Rx.TDC, Rx.PatientPay, Rx.OtherPay, Rx.ApprovedAmount, Rx.Active, 
				Rx.LoadDate, Rx.LastUpdateKey, Rx.SourceDataKey, Rx.ContractCode, Rx.PBPCode, Rx.Tier
	FROM [deleted] AS Rx
END TRY

BEGIN CATCH
	;THROW
END CATCH
GO
ALTER TABLE [EOB].[EOB_PartBPharmacy_Archive] ADD CONSTRAINT [PK_EOB_PartBPharmacy_Archive] PRIMARY KEY CLUSTERED  ([ClaimID], [MemberID])
GO
CREATE NONCLUSTERED INDEX [IX_RX_Archive_MemID] ON [EOB].[EOB_PartBPharmacy_Archive] ([MemberID]) INCLUDE ([BeginServiceDate], [EndServiceDate], [NDC], [PaidDate], [ProviderID])
GO
