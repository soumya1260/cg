/*************************************************************************************************************
  TITLE:			eob.EOBFalloutParms			--Fallout_SSRS_Report
  BUSINESS OWNER:	QNXT Development
  CREATED BY:		Sandie Nantz
  CREATE DATE:		04/01/2019

  DESCRIPTION:		Requested by Kiran

  Modification History: 
  SDE #:        Developer:              Date:                   Desc:
  CM20069439	Sandie Nantz			04/01/2019              User Story 290361: EOB 2.0 - Fallout report request
**************************************************************************************************************/
/****** Object:  Table [EOB].[EOBFalloutParms]    Script Date: 8/6/2019 12:55:56 PM ******/
CREATE TABLE [EOB].[EOBFalloutParms](
	[ProcessHeaderID] [varchar](15) NULL,
	[CurrentUser] [varchar](50) NULL
) ON [PRIMARY]

GO


