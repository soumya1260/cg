CREATE TABLE [EOB].[MemberID_Changes]
(
[pkMemberIDChangeID] [int] NOT NULL,
[strSOURCEMemID] [varchar] (255) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL,
[strSOURCESecondaryID] [varchar] (255) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL,
[strMemID] [char] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL,
[strPreviousSecondaryID] [char] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL,
[strNewSecondaryID] [char] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL,
[strFullName] [varchar] (95) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NULL,
[dtmDateCreated] [datetime2] (3) NULL,
[blnCompleted] [bit] NULL
)
GO
