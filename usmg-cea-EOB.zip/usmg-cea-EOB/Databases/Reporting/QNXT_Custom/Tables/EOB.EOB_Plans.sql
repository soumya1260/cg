CREATE TABLE [EOB].[EOB_Plans]
(
[ContractCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PBPCode] [varchar] (4) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Group] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[GroupPlanID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PlanType] [varchar] (4) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PlanYear] [int] NULL,
[EffDate] [date] NOT NULL,
[TermDate] [date] NOT NULL,
[Active] [bit] NOT NULL CONSTRAINT [DF_EOB_Plans_Active] DEFAULT ((1)),
[ServiceCategory] [tinyint] NOT NULL CONSTRAINT [DF_EOB_Plans_ServiceCategory] DEFAULT ((0)),
[INMOOP] [money] NOT NULL CONSTRAINT [DF_EOB_Plans_INMOOP] DEFAULT ((0.00)),
[OONMOOP] [money] NOT NULL CONSTRAINT [DF_EOB_Plans_OONMOOP] DEFAULT ((0.00)),
[INDeduct] [money] NOT NULL CONSTRAINT [DF_EOB_Plans_INDeduct] DEFAULT ((0.00)),
[OONDeduct] [money] NOT NULL CONSTRAINT [DF_EOB_Plans_OONDeduct] DEFAULT ((0.00)),
[ServiceCategoryDeduct] [money] NOT NULL CONSTRAINT [DF_EOB_Plans_ServiceCategoryDeduct] DEFAULT ((0.00)),
[IsDSNP] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Plans_IsDSNP] DEFAULT ('N'),
[IsPartD] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Plans_IsPartD] DEFAULT ('N'),
[Copay] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Plans_Copay] DEFAULT ('N'),
[CoInsurance] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Plans_CoInsurance] DEFAULT ('N'),
[Deductible] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Plans_Deductible] DEFAULT ('N')
)
GO
ALTER TABLE [EOB].[EOB_Plans] ADD CONSTRAINT [CHK_EOB_Plans_PlanYear_Year] CHECK (([PlanYear]>=(1900) AND [PlanYear]<=(9999)))
GO
ALTER TABLE [EOB].[EOB_Plans] ADD CONSTRAINT [CHK_EOB_Plans_Contract_LENGTH] CHECK ((len([ContractCode])=(5)))
GO
ALTER TABLE [EOB].[EOB_Plans] ADD CONSTRAINT [CHK_EOB_Plans_PBP_LENGTH] CHECK ((len([PBPCode])>=(3)))
GO
ALTER TABLE [EOB].[EOB_Plans] ADD CONSTRAINT [CHK_EOB_Plans_PlanType_LENGTH] CHECK ((len([PlanType])>=(3)))
GO
ALTER TABLE [EOB].[EOB_Plans] ADD CONSTRAINT [PK_EOB_Plans] PRIMARY KEY CLUSTERED  ([ContractCode], [PBPCode], [Group], [PlanType], [EffDate])
GO
