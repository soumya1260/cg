CREATE TABLE [EOB].[EOB_PreventiveProcedureCode]
(
[GroupId] [int] NOT NULL,
[CodeId] [varchar] (6) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Is_ICD] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
ALTER TABLE [EOB].[EOB_PreventiveProcedureCode] ADD CONSTRAINT [PK_EOB_PreventiveProcedureCode] PRIMARY KEY CLUSTERED  ([GroupId], [CodeId], [Is_ICD])
GO
