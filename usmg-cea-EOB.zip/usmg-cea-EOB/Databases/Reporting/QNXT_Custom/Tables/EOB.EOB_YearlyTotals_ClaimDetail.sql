CREATE TABLE [EOB].[EOB_YearlyTotals_ClaimDetail]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_YT_CD_ProcessHeaderID] DEFAULT ((-1)),
[MemberID] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimID] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimLine] [int] NOT NULL,
[IncurredYear] [int] NOT NULL,
[ContractCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PBPCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimAmt] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_ClaimAmt] DEFAULT ((0.00)),
[AmountPaid] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_AmountPaid] DEFAULT ((0.00)),
[CoPay] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_CoPay] DEFAULT ((0.00)),
[CoPayPerDiemAmt] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_CoPayPerDiemAmt] DEFAULT ((0.00)),
[BeneDeduct] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_BeneDeduct] DEFAULT ((0.00)),
[CoInsuranceAmt] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_CoInsuranceAmt] DEFAULT ((0.00)),
[Eligible] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_Eligible] DEFAULT ((0.00)),
[SubmitDiscount] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_SubmitDiscount] DEFAULT ((0.00)),
[PayDiscount] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_PayDiscount] DEFAULT ((0.00)),
[Par_Ind] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_YT_CD_Par_Ind] DEFAULT ('N'),
[IDN_Denied_Charge] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CD_IDN_Denied_Charge] DEFAULT ((0.00)),
[QNXTPlanID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_YT_CD_QNXTPlanID] DEFAULT (''),
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
ALTER TABLE [EOB].[EOB_YearlyTotals_ClaimDetail] ADD CONSTRAINT [PK_EOB_YearlyTotals_ClaimDetail] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [MemberID], [ClaimID], [ClaimLine], [Source])
GO
CREATE NONCLUSTERED INDEX [IX_EOB_YearlyTotals_ClaimDetail] ON [EOB].[EOB_YearlyTotals_ClaimDetail] ([IncurredYear], [ContractCode], [PBPCode], [Source], [Par_Ind]) INCLUDE ([AmountPaid], [BeneDeduct], [ClaimAmt], [ClaimID], [ClaimLine], [CoInsuranceAmt], [CoPay], [CoPayPerDiemAmt], [Eligible], [IDN_Denied_Charge], [MemberID], [PayDiscount], [ProcessHeaderID], [SubmitDiscount])
GO
