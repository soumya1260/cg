CREATE TABLE [EOB].[EOB_YearlyTotals]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_YT_ProcessHeaderID] DEFAULT ((-1)),
[MemberID] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[IncurredYear] [int] NOT NULL,
[ContractCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PBPCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[OOP_Deductible] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_OOP_Deductible] DEFAULT ((0.00)),
[Open_Field3] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_Open_Field3] DEFAULT ((0.00)),
[Open_Field6] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_Open_Field6] DEFAULT ((0.00)),
[Open_Field7] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_Open_Field7] DEFAULT ((0.00)),
[Total_Charge] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_Open_Field8] DEFAULT ((0.00)),
[Open_Field9] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_Open_Field9] DEFAULT ((0.00)),
[Discount] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_Open_Field10] DEFAULT ((0.00)),
[Deductible] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_Deductible] DEFAULT ((0.00)),
[CoPay] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CoPay] DEFAULT ((0.00)),
[CoInsurance] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_CoInsurance] DEFAULT ((0.00)),
[Flex_Med_YTD_Contributions] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_YT_Flex_Med_YTD_Contributions] DEFAULT (''),
[Other_Amount3] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_Other_Amount3] DEFAULT ((0.00)),
[Other_Amount4] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_Other_Amount4] DEFAULT ((0.00)),
[Flex_Med_Annual] [numeric] (15, 2) NOT NULL CONSTRAINT [DF_YT_Flex_Med_Annual] DEFAULT ((0.00)),
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL
)
GO
ALTER TABLE [EOB].[EOB_YearlyTotals] ADD CONSTRAINT [CHK_YT_ContractCode_Length] CHECK ((len([ContractCode])=(5)))
GO
ALTER TABLE [EOB].[EOB_YearlyTotals] ADD CONSTRAINT [CHK_YT_PBP_Length] CHECK ((len([PBPCode])=(5) OR len([PBPCode])=(4) OR len([PBPCode])=(3) OR len([PBPCode])=(0)))
GO
ALTER TABLE [EOB].[EOB_YearlyTotals] ADD CONSTRAINT [PK_EOB_YearlyTotals] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [MemberID], [IncurredYear], [ContractCode], [PBPCode], [Source])
GO
CREATE NONCLUSTERED INDEX [IX_EOB_YearlyTotals] ON [EOB].[EOB_YearlyTotals] ([IncurredYear]) INCLUDE ([CoInsurance], [ContractCode], [CoPay], [Discount], [Flex_Med_Annual], [Flex_Med_YTD_Contributions], [MemberID], [OOP_Deductible], [Other_Amount3], [Other_Amount4], [PBPCode], [Total_Charge])
GO
