CREATE TABLE [EOB].[EOB_ExcludedDenialRemits]
(
[ReasonID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Active] [bit] NOT NULL,
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_ExcludedDenialRemits_CreateID] DEFAULT (suser_sname()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_ExcludedDenialRemits_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_ExcludedDenialRemits_UpdateID] DEFAULT (suser_sname()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_ExcludedDenialRemits_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_ExcludedDenialRemits] ADD CONSTRAINT [PK_EOB_ExcludedDenialRemits] PRIMARY KEY CLUSTERED  ([ReasonID], [Active])
GO
