CREATE TABLE [EOB].[EOB_Run_Staging]
(
[RunRequestID] [int] NOT NULL,
[ClaimID] [varchar] (50) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[MemberID] [varchar] (80) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[IsValid] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Run_Staging_IsValid] DEFAULT ('Y')
)
GO
