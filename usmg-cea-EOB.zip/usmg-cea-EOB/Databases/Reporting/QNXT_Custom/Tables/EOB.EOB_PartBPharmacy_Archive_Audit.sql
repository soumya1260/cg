CREATE TABLE [EOB].[EOB_PartBPharmacy_Archive_Audit]
(
[ChangeType] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Time_Of_Change] [smalldatetime] NOT NULL,
[ClaimID] [varchar] (18) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[MemberID] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimStatus] [char] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[CurrentEligibiltyStatus] [char] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PaidDate] [int] NOT NULL,
[BeginServiceDate] [int] NOT NULL,
[EndServiceDate] [int] NOT NULL,
[NDC] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[NDCDesc] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ProviderName] [varchar] (55) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ProviderID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[BilledAmount] [decimal] (9, 2) NOT NULL,
[DeductibleAmount] [decimal] (9, 2) NOT NULL,
[CopayAmount] [decimal] (9, 2) NOT NULL,
[CoinsuranceAmount] [decimal] (9, 2) NOT NULL,
[TDC] [decimal] (9, 2) NOT NULL,
[PatientPay] [decimal] (9, 2) NOT NULL,
[OtherPay] [decimal] (9, 2) NOT NULL,
[ApprovedAmount] [decimal] (9, 2) NOT NULL,
[Active] [bit] NOT NULL,
[LoadDate] [datetime] NOT NULL,
[LastUpdateKey] [int] NOT NULL,
[SourceDataKey] [int] NOT NULL,
[ContractCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[PBPCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[Tier] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_PartBPharmacy_Archive_Audit_Tier] DEFAULT ('')
)
GO
ALTER TABLE [EOB].[EOB_PartBPharmacy_Archive_Audit] ADD CONSTRAINT [PK_EOB_PartBPharmacy_Archive_Audit] PRIMARY KEY CLUSTERED  ([ClaimID], [MemberID], [ChangeType], [Time_Of_Change] DESC)
GO
CREATE NONCLUSTERED INDEX [IX_RX_Audit_MemID] ON [EOB].[EOB_PartBPharmacy_Archive_Audit] ([MemberID]) INCLUDE ([BeginServiceDate], [EndServiceDate], [NDC], [PaidDate], [ProviderID])
GO
