CREATE TABLE [EOB].[EOB_Fallout]
(
[ClaimType] [char] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ClaimID] [varchar] (100) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[MemberID] [varchar] (100) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ReasonID] [tinyint] NOT NULL,
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL,
[ProcessHeaderID] [int] NOT NULL,
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Fallout_CreateID] DEFAULT (suser_name()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Fallout_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Fallout_UpdateID] DEFAULT (suser_name()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Fallout_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_Fallout] ADD CONSTRAINT [CHK_EOB_Fallout_ClaimType] CHECK (([ClaimType]='RX' OR [ClaimType]='EN' OR [ClaimType]='CL'))
GO
ALTER TABLE [EOB].[EOB_Fallout] ADD CONSTRAINT [PK_EOB_Fallout] PRIMARY KEY CLUSTERED  ([ClaimType], [ClaimID], [Source], [ReasonID], [ProcessHeaderID] DESC)
GO
CREATE NONCLUSTERED INDEX [IX_EOB_Fallout_MemberID] ON [EOB].[EOB_Fallout] ([MemberID])
GO
CREATE NONCLUSTERED INDEX [IX_EOB_Fallout_ReasonID] ON [EOB].[EOB_Fallout] ([ReasonID])
GO
ALTER TABLE [EOB].[EOB_Fallout] ADD CONSTRAINT [FK_EOB_Fallout_ReasonID] FOREIGN KEY ([ClaimType], [ReasonID]) REFERENCES [EOB].[EOB_Fallout_Reason] ([ClaimType], [ReasonID])
GO
