CREATE TABLE [EOB].[EOB_Claim_Archive]
(
[ProcessHeaderID] [int] NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_ProcessHeaderID] DEFAULT ((-1)),
[ClaimID] [varchar] (30) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_ClaimID] DEFAULT (''),
[MemberID] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_MemberID] DEFAULT (''),
[MemberFirstName] [varchar] (45) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_MemberFirstName] DEFAULT (''),
[MemberLastName] [varchar] (45) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_MemberLastName] DEFAULT (''),
[ContractCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_ContractCode] DEFAULT (''),
[PBPCode] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_PBPCode] DEFAULT (''),
[PlanType] [varchar] (5) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_PlanType] DEFAULT (''),
[ProviderID] [varchar] (20) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_ProviderID] DEFAULT (''),
[ProviderName] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_ProviderName] DEFAULT (''),
[ClaimStatus] [char] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_ClaimStatus] DEFAULT (''),
[PaidDate] [datetime] NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_PaidDate] DEFAULT ('1/1/1980'),
[PaidAmount] [decimal] (9, 2) NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_PaidAmount] DEFAULT ((0)),
[BeginServiceDate] [datetime] NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_BeginServiceDate] DEFAULT ('1/1/1980'),
[EndServiceDate] [datetime] NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_EndServiceDate] DEFAULT ('1/1/1980'),
[LoadDate] [datetime] NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_LoadDate] DEFAULT ('1/1/1980'),
[Par_Ind] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_Par_Ind] DEFAULT (''),
[Denial_Language_Ind] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_Denial_Language_Ind] DEFAULT (''),
[Is_PartD] [varchar] (1) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_Is_PartD] DEFAULT (''),
[Source] [varchar] (60) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_Source] DEFAULT (''),
[ClaimType] [varchar] (2) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_ClaimType] DEFAULT ('DF'),
[QNXTPlanID] [varchar] (15) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_QNXTPlanID] DEFAULT (''),
[CreateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_CreateID] DEFAULT (suser_sname()),
[CreateDate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_CreateDate] DEFAULT (getdate()),
[UpdateID] [varchar] (120) COLLATE SQL_Latin1_General_Pref_CP1_CI_AS NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_UpdateID] DEFAULT (suser_sname()),
[LastUpdate] [smalldatetime] NOT NULL CONSTRAINT [DF_EOB_Claim_Archive_LastUpdate] DEFAULT (getdate())
)
GO
ALTER TABLE [EOB].[EOB_Claim_Archive] ADD CONSTRAINT [CHK_EOB_Claim_Archive_ClaimType] CHECK (([ClaimType]='DF' OR [ClaimType]='SU' OR [ClaimType]='RX' OR [ClaimType]='EN' OR [ClaimType]='CL'))
GO
ALTER TABLE [EOB].[EOB_Claim_Archive] ADD CONSTRAINT [CHK_EOB_Claim_Archive_Denial_Language_Ind] CHECK (([Denial_Language_Ind]='' OR [Denial_Language_Ind]='N' OR [Denial_Language_Ind]='Y'))
GO
ALTER TABLE [EOB].[EOB_Claim_Archive] ADD CONSTRAINT [CHK_EOB_Claim_Archive_Par_Ind] CHECK (([Par_Ind]='' OR [Par_Ind]='N' OR [Par_Ind]='P'))
GO
ALTER TABLE [EOB].[EOB_Claim_Archive] ADD CONSTRAINT [PK_EOB_Claim_Archive] PRIMARY KEY CLUSTERED  ([ProcessHeaderID], [ClaimID], [MemberID], [Source])
GO
