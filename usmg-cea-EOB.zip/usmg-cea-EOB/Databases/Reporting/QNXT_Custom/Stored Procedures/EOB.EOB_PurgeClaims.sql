CREATE PROCEDURE [EOB].[EOB_PurgeClaims] (@ProcessHeaderID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_PurgeClaims.sql
-- Date:			12.19.2018
-- Author:			Subash (subash.chandrasekaram@healthspring.com)
-- Purpose:			Remove Claims that were marked for purging
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
-- None
###########################################################################################################################################################
-- Ver  User		Date				US#			Change
-- 1.0  Subash      12.19.2018						Initial release
###########################################################################################################################################################
*/

BEGIN TRY
BEGIN TRANSACTION
		
		INSERT INTO QNXT_Custom.EOB.EOB_Recon_Purge (ProcessHeaderID, ClaimID, MemberID, EOBFileName, [Source], Purge_ProcessHeaderID, 
														CreateID, CreateDate, UpdateID, LastUpdate)
		SELECT	DISTINCT 
					ER.ProcessHeaderID, ER.ClaimID, ER.MemberID, ER.EOBFileName, ER.[Source], @ProcessHeaderID AS Purge_ProcessHeaderID, 
						ER.CreateID, ER.CreateDate, ER.UpdateID, ER.LastUpdate
		FROM	QNXT_Custom.EOB.EOB_Recon ER
		JOIN	QNXT_Custom.EOB.EOB_PurgeClaim EP
			ON	ER.ClaimId = EP.ClaimID
			AND ER.MemberId = EP.Insured_PolicyNumber

		DELETE	ER
		FROM	QNXT_Custom.EOB.EOB_Recon ER
		JOIN	QNXT_Custom.EOB.EOB_PurgeClaim EP
			ON	ER.ClaimId = EP.ClaimID
			AND ER.MemberId = EP.Insured_PolicyNumber
		
COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
