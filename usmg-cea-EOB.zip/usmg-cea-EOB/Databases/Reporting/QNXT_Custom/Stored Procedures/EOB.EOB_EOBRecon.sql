CREATE PROCEDURE [EOB].[EOB_EOBRecon] (@ProcessHeaderID INT, @FileName VARCHAR(100), @IncurredYear INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_EOBRecon.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			08.07.2018			215695		Updated logic to ignore the IncurredYear parameter (CM20024547)
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		INSERT INTO QNXT_Custom.EOB.EOB_Recon (ProcessHeaderID, ClaimID, MemberID, EOBFileName, [Source] )
		SELECT DISTINCT @ProcessHeaderID AS ProcessHeaderID,
						EO.ClaimID,
						EO.Insured_PolicyNumber AS MemberID,
						@FileName AS EOBFileName,
						EO.[Source] AS [Source]
		FROM	EOB.EOB_Output EO
		WHERE	ISNULL(EO.[ClaimID], '') <> ''

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
