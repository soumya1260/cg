CREATE PROCEDURE [EOB].[EOB_Format_Output] (@ProcessHeaderID INT, @BeginDate SMALLDATETIME, @EndDate SMALLDATETIME, @LateSubmissionIndicator VARCHAR(1), @ClientID VARCHAR(4)) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Format_Output.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Format Data for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			07.18.2018			215695		Updated logic to insert Claim_Type as is from MasterDeliv to Output (CM20020425)
-- 1.3  KB			08.20.2018			215695		Removed load date join clause on claim detail insert (CM20027055)
-- 1.4  KB			09.04.2018			215695		Added invoking the data validation SP (CM20029812)
-- 1.5	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
-- 1.6	KB			08.01.2019						CM20097013 - ClientID
###########################################################################################################################################################
*/

TRUNCATE TABLE QNXT_Custom.EOB.EOB_Output 

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		EXEC EOB.EOB_Data_Validation @ProcessHeaderID

		UPDATE MD
		SET MD.Sort_Key = 'ZZZ'
		FROM	QNXT_Custom.EOB.EOB_0001MasterDeliv MD
		JOIN	QNXT_Custom.EOB.EOB_0002EOB E02
			ON	MD.Insured_PolicyNumber = E02.Insured_PolicyNumber
			AND MD.IncurredYear = E02.IncurredYear
		JOIN	Plandata_Prod.dbo.Claim C
			ON	E02.Claim_Number = C.ClaimID
			AND C.OrgClaimID <> ''
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		IF OBJECT_ID('tempdb.dbo.#Claim_Sequence') IS NOT NULL
		DROP TABLE #Claim_Sequence

		CREATE TABLE #Claim_Sequence
		(
			Insured_PolicyNumber VARCHAR(20),
			Claim_Number VARCHAR(30),
			Claim_Type VARCHAR(2),
			[Source] VARCHAR(60),
			Claim_Sequence INT
		)

		INSERT INTO #Claim_Sequence
		SELECT E02.Insured_PolicyNumber,
				E02.Claim_Number,
				E02.Open_Field3 AS Claim_Type,
				E02.[Source],
				ROW_NUMBER() OVER (PARTITION BY E02.Insured_PolicyNumber, E02.DocumentID ORDER BY E02.Open_Field3) AS Claim_Sequence
		FROM QNXT_Custom.EOB.EOB_0002EOB E02
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Insert Master Delivery records
		INSERT INTO QNXT_Custom.EOB.EOB_Output ( ProcessHeaderID, Insured_PolicyNumber, IncurredYear, RecordType, Claim_Sequence, CKey, DocumentID, DataRow, ClaimType, [Source] )
		SELECT DISTINCT
					@ProcessHeaderID AS ProcessHeaderID,
					MD.Insured_PolicyNumber,
					MD.IncurredYear,
					LEFT(LTRIM(RTRIM(MD.RecordType)) + SPACE(4), 4) AS RecordType,
					'002IN' AS Claim_Sequence,
					LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) AS CKey,
					LEFT(LTRIM(RTRIM(MD.DocumentID)) + SPACE(6), 6) AS DocumentID,
					LEFT(LTRIM(RTRIM(MD.RecordType)) + SPACE(4), 4)	+																							--RecordType					
					LEFT(LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) + 
					LEFT(LTRIM(RTRIM(MD.DocumentID)) + SPACE(6), 6) + SPACE(23), 23) +																			--Key
					LEFT(LTRIM(RTRIM(MD.[Version])) + SPACE(2), 2) +																							--Version
					LEFT(LTRIM(RTRIM(MD.Relation_Code)) + SPACE(3), 3) +																						--Relation_Code
					LEFT(LTRIM(RTRIM(MD.Recepient)) + SPACE(2), 2) +																							--Recepient
					SPACE(3) +																																	--Claim_Type
					LEFT(LTRIM(RTRIM(MD.Routing_Code)) + SPACE(2), 2) +																							--Routing_Code
					LEFT(LTRIM(RTRIM(MD.[Name])) + SPACE(45), 45) +																								--Name
					LEFT(LTRIM(RTRIM(MD.Address1)) + SPACE(40), 40) + 																							--Address1
					LEFT(LTRIM(RTRIM(MD.Address2)) + SPACE(40), 40) +																							--Address2
					LEFT(LTRIM(RTRIM(MD.City)) + SPACE(30), 30) +																								--City
					LEFT(LTRIM(RTRIM(MD.[State])) + SPACE(2), 2) +																								--State
					LEFT(LTRIM(RTRIM(MD.Zip)) + SPACE(5), 5) +																									--Zip
					LEFT(LTRIM(RTRIM(MD.Sort_Key)) + SPACE(40), 40) +																							--Sort_Key
					LEFT(LTRIM(RTRIM(MD.FormatID)) + SPACE(3), 3) +																								--FormatID
					SPACE(2) +																																	--Data_Type
					LEFT(LTRIM(RTRIM(MD.Email_Address)) + SPACE(100), 100) +																					--Email_Address
					LEFT(LTRIM(RTRIM(MD.Territory)) + SPACE(30), 30) +																							--Territory
					LEFT(LTRIM(RTRIM(MD.Country)) + SPACE(30), 30) +																							--Country
					LEFT(LTRIM(RTRIM(MD.International_ZipCode)) + SPACE(20), 20) +																				--International_ZipCode
					LEFT(LTRIM(RTRIM(MD.International_City_State_Country_Zip)) + SPACE(50), 50) +																--International_City_State_Country_Zip
					LEFT(LTRIM(RTRIM(MD.Address3)) + SPACE(40), 40) +																							--Address3
					LEFT(LTRIM(RTRIM(MD.Name2)) + SPACE(45), 45) +																								--Name2
					LEFT(LTRIM(RTRIM(MD.Release_Date)) + SPACE(10), 10) +																						--Release_Date
					LEFT(LTRIM(RTRIM(MD.Eft_Number)) + SPACE(30), 30) +																							--Eft_Number
					LEFT(LTRIM(RTRIM(MD.Eft_Date)) + SPACE(8), 8) +																								--Eft_Date
					LEFT(LTRIM(RTRIM(MD.Consol_EOB)) + SPACE(1), 1) +																							--Consol_EOB
					LEFT(LTRIM(RTRIM(MD.Super_Key)) + SPACE(23), 23) +																							--Super_Key
					'@' AS DataRow,
					'' AS ClaimType,
					'' [Source]
		FROM	QNXT_Custom.EOB.EOB_0001MasterDeliv MD
		JOIN	QNXT_Custom.EOB.EOB_CKey CK			
			ON	1=1		
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Insert EOB_0002 records          
		INSERT INTO QNXT_Custom.EOB.EOB_Output ( ProcessHeaderID, ClaimID, Insured_PolicyNumber, IncurredYear, RecordType, CKey, DocumentID, DataRow, ClaimType, [Source] )
		SELECT DISTINCT
					@ProcessHeaderID AS ProcessHeaderID,
					E02.Claim_Number AS ClaimID,
					E02.Insured_PolicyNumber,
					E02.IncurredYear,
					LEFT(LTRIM(RTRIM(E02.RecordType)) + SPACE(4), 4) AS RecordType,		
					LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) AS CKey,
					LEFT(LTRIM(RTRIM(E02.DocumentID)) + SPACE(6), 6) AS DocumentID,
					LEFT(LTRIM(RTRIM(E02.RecordType)) + SPACE(4), 4) +																							--RecordType
					LEFT(LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) + 
					LEFT(LTRIM(RTRIM(E02.DocumentID)) + SPACE(6), 6) + SPACE(23), 23) +																			--Key
					LEFT(LTRIM(RTRIM(E02.[Version])) + SPACE(2), 2) +																			                --Version
					RIGHT('000000' + CAST(CS.Claim_Sequence AS VARCHAR), 6) +																	                --Claim_Sequence
					LEFT(LTRIM(RTRIM(E02.Claim_Number)) + SPACE(30), 30) +																		                --Claim_Number
					LEFT(LTRIM(RTRIM(E02.Insured_Name)) + SPACE(30), 30) +																		                --Insured_Name
					LEFT(LTRIM(RTRIM(E02.Insured_Social)) + SPACE(9), 9) +																		                --Insured_Social
					LEFT(LTRIM(RTRIM(E02.Insured_PolicyNumber)) + SPACE(20), 20) +																                --Insured_PolicyNumber
					LEFT(LTRIM(RTRIM(E02.Insured_Address1)) + SPACE(35), 35) +																	                --Insured_Address1
					LEFT(LTRIM(RTRIM(E02.Insured_Address2)) + SPACE(35), 35) +																	                --Insured_Address2
					LEFT(LTRIM(RTRIM(E02.Insured_Address3)) + SPACE(35), 35) +																	                --Insured_Address3
					LEFT(LTRIM(RTRIM(E02.Patient_Name)) + SPACE(30), 30) +																		                --Patient_Name
					LEFT(LTRIM(RTRIM(E02.Dependent_Number)) + SPACE(20), 20) +																	                --Dependent_Number
					LEFT(LTRIM(RTRIM(E02.Patient_Relationship)) + SPACE(20), 20) +																                --Patient_Relationship
					LEFT(LTRIM(RTRIM(E02.Received_Date)) + SPACE(8), 8) +																		                --Received_Date
					LEFT(LTRIM(RTRIM(E02.Processed_Date)) + SPACE(8), 8) +																		                --Processed_Date
					LEFT(LTRIM(RTRIM(E02.Paid_Date)) + SPACE(8), 8) +																			                --Paid_Date
					LEFT(LTRIM(RTRIM(E02.Processor_ID)) + SPACE(5), 5) +																		                --Processor_ID
					LEFT(LTRIM(RTRIM(E02.Processor_Name)) + SPACE(30), 30) +																	                --Processor_Name
					LEFT(LTRIM(RTRIM(E02.Claim_Year)) + SPACE(4), 4) +																			                --Claim_Year
					LEFT(LTRIM(RTRIM(E02.Group_Hierarchy1)) + SPACE(15), 15) +																	                --Group_Hierarchy1
					LEFT(LTRIM(RTRIM(E02.Group_Name1)) + SPACE(40), 40) +																		                --Group_Name1
					LEFT(LTRIM(RTRIM(E02.Group_Hierarchy2)) + SPACE(15), 15) +																	                --Group_Hierarchy2
					LEFT(LTRIM(RTRIM(E02.Group_Name2)) + SPACE(40), 40) +																		                --Group_Name2
					LEFT(LTRIM(RTRIM(E02.Group_Hierarchy3)) + SPACE(15), 15) +																	                --Group_Hierarchy3
					LEFT(LTRIM(RTRIM(E02.Group_Name3)) + SPACE(40), 40) +																		                --Group_Name3
					LEFT(LTRIM(RTRIM(E02.Group_Hierarchy4)) + SPACE(15), 15) +																	                --Group_Hierarchy4
					LEFT(LTRIM(RTRIM(E02.Group_Name4)) + SPACE(40), 40) +																		                --Group_Name4
					LEFT(LTRIM(RTRIM(E02.Check_Number)) + SPACE(16), 16) +																		                --Check_Number
					LEFT(CASE WHEN SIGN(E02.Check_Amount) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E02.Check_Amount)) + SPACE(15), 15) +							--Check_Amount
					LEFT(LTRIM(RTRIM(E02.Voucher_Number)) + SPACE(16), 16) +																	                --Voucher_Number
					LEFT(LTRIM(RTRIM(E02.FormLetter_Provider_Name)) + SPACE(40), 40) +															                --FormLetter_Provider_Name
					LEFT(LTRIM(RTRIM(E02.FormLetter_TIN)) + SPACE(9), 9) +																			            --FormLetter_TIN
					LEFT(LTRIM(RTRIM(E02.FormLetter_Name)) + SPACE(40), 40) +																	                --FormLetter_Name
					LEFT(LTRIM(RTRIM(E02.FormLetter_ID)) + SPACE(5), 5) +																		                --FormLetter_ID
					LEFT(LTRIM(RTRIM(E02.Customer_Info1)) + SPACE(40), 40) +																	                --Customer_Info1
					LEFT(LTRIM(RTRIM(E02.Customer_Info2)) + SPACE(40), 40) +																	                --Customer_Info2
					LEFT(LTRIM(RTRIM(E02.Customer_Info3)) + SPACE(40), 40) +																	                --Customer_Info3
					LEFT(LTRIM(RTRIM(E02.Customer_Info4)) + SPACE(40), 40) +																	                --Customer_Info4
					LEFT(LTRIM(RTRIM(E02.Return_Logo)) + SPACE(5), 5) +																			                --Return_Logo
					LEFT(LTRIM(RTRIM(E02.Return_Style)) + SPACE(1), 1) +																		                --Return_Style
					LEFT(LTRIM(RTRIM(E02.Return_Name)) + SPACE(70), 70) +																		                --Return_Name
					LEFT(LTRIM(RTRIM(E02.Return_Address1)) + SPACE(70), 70) +																	                --Return_Address1
					LEFT(LTRIM(RTRIM(E02.Return_Address2)) + SPACE(50), 50) +																	                --Return_Address2
					LEFT(LTRIM(RTRIM(E02.Return_Address3)) + SPACE(50), 50) +																	                --Return_Address3
					LEFT(LTRIM(RTRIM(E02.Network)) + SPACE(50), 50) +																			                --Network
					LEFT(LTRIM(RTRIM(E02.Group_Logo)) + SPACE(5), 5) +																			                --Group_Logo
					LEFT(LTRIM(RTRIM(E02.PRE_Treatment_Flag)) + SPACE(1), 1) +																	                --PRE_Treatment_Flag
					LEFT(LTRIM(RTRIM(E02.WaterMark1)) + SPACE(3), 3) +																			                --WaterMark1
					LEFT(LTRIM(RTRIM(E02.WaterMark2)) + SPACE(3), 3) +																			                --WaterMark2
					LEFT(LTRIM(RTRIM(E02.Copy_Number)) + SPACE(2), 2) +																							--Copy_Number
					LEFT(LTRIM(RTRIM(E02.Billing_Code)) + SPACE(30), 30) +																						--Billing_Code
					LEFT(CASE WHEN SIGN(E02.Open_Field1) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E02.Open_Field1)) + SPACE(30), 30) +			                --Open_Field1
					LEFT(CASE WHEN SIGN(E02.Open_Field2) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E02.Open_Field2)) + SPACE(30), 30) +			                --Open_Field2
					LEFT(LTRIM(RTRIM(E02.Open_Field3)) + SPACE(30), 30) +																		                --Open_Field3
					LEFT(LTRIM(RTRIM(E02.Open_Field4)) + SPACE(30), 30) +																		                --Open_Field4
					LEFT(LTRIM(RTRIM(E02.Open_Field5)) + SPACE(30), 30) +																		                --Open_Field5
					LEFT(LTRIM(RTRIM(E02.Open_Field6)) + SPACE(50), 50) +																		                --Open_Field6
					LEFT(LTRIM(RTRIM(E02.Open_Field7)) + SPACE(50), 50) +																		                --Open_Field7
					LEFT(LTRIM(RTRIM(E02.Open_Field8)) + SPACE(50), 50) +																		                --Open_Field8
					LEFT(LTRIM(RTRIM(E02.Open_Field9)) + SPACE(50), 50) +																		                --Open_Field9
					LEFT(LTRIM(RTRIM(E02.Open_Field10)) + SPACE(50), 50) +																						--Open_Field10
					LEFT(LTRIM(RTRIM(E02.Open_Field11)) + SPACE(60), 60) +																		                --Open_Field11
					LEFT(LTRIM(RTRIM(E02.Open_Field12)) + SPACE(60), 60) +																		                --Open_Field12
					LEFT(LTRIM(RTRIM(E02.Open_Field13)) + SPACE(60), 60) +																			            --Open_Field13
					LEFT(LTRIM(RTRIM(E02.Open_Field14)) + SPACE(60), 60) +																		                --Open_Field14
					LEFT(LTRIM(RTRIM(E02.Open_Field15)) + SPACE(60), 60) +																		                --Open_Field15
					LEFT(LTRIM(RTRIM(E02.Open_Field16)) + SPACE(80), 80) +																		                --Open_Field16
					LEFT(LTRIM(RTRIM(E02.Open_Field17)) + SPACE(80), 80) +																			            --Open_Field17
					LEFT(LTRIM(RTRIM(E02.Open_Field18)) + SPACE(80), 80) +																						--Open_Field18
					LEFT(LTRIM(RTRIM(E02.Open_Field19)) + SPACE(80), 80) +																						--Open_Field19
					LEFT(LTRIM(RTRIM(E02.Open_Field20)) + SPACE(80), 80) +																						--Open_Field20
					LEFT(CASE WHEN SIGN(E02.Open_Field21) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E02.Open_Field21)) + SPACE(120), 120) +						--Open_Field21
					LEFT(E02.Open_Field22 + SPACE(120), 120) +																									--Open_Field22
					LEFT(LTRIM(RTRIM(E02.Open_Field23)) + SPACE(120), 120) +																					--Open_Field23
					LEFT(CASE WHEN SIGN(E02.Open_Field24) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E02.Open_Field24)) + SPACE(240), 240) +						--Open_Field24
					LEFT(LTRIM(RTRIM(E02.Open_Field25)) + SPACE(240), 240) +																					--Open_Field25
					LEFT(LTRIM(RTRIM(E02.Dakota_Image_Number)) + SPACE(20), 20) +																				--Dakota_Image_Number
					LEFT(LTRIM(RTRIM(E02.Separator_Indicator)) + SPACE(1), 1) +																					--Separator_Indicator
					LEFT(LTRIM(RTRIM(E02.Tax_ID)) + SPACE(30), 30)  +																							--Tax_ID
					LEFT(LTRIM(RTRIM(E02.National_Provider_ID_NPI)) + SPACE(17), 17) +																            --National_Provider_ID_NPI
					LEFT(LTRIM(RTRIM(E02.Return_Reason_Code)) + SPACE(2), 2) +																	                --Return_Reason_Code
					LEFT(LTRIM(RTRIM(E02.Return_Name2)) + SPACE(70), 70) +																		                --Return_Name2
					LEFT(LTRIM(RTRIM(E02.Dependent_Seq_Number)) + SPACE(2), 2) +																                --Dependent_Seq_Number
					'@' AS DataRow,
					E02.Open_Field3 AS ClaimType,
					E02.[Source]
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	#Claim_Sequence CS
			ON	E02.Claim_Number = CS.Claim_Number
			AND	E02.[Source] = CS.[Source]
		JOIN	QNXT_Custom.EOB.EOB_CKey CK
			ON	1=1		
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		--Insert EOB_0003 records
		INSERT INTO QNXT_Custom.EOB.EOB_Output ( ProcessHeaderID, ClaimID, ClaimLineID, Insured_PolicyNumber, IncurredYear, RecordType, CKey, DocumentID, DataRow, ClaimType, [Source] )
		SELECT DISTINCT
					@ProcessHeaderID AS ProcessHeaderID,
					E03.Claim_Number AS ClaimID,
					E03.Line_Number AS ClaimLineID,
					E03.Insured_PolicyNumber,
					E03.IncurredYear,
					LEFT(LTRIM(RTRIM(E03.RecordType)) + SPACE(4), 4) AS RecordType,
					LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) AS CKey,
					LEFT(LTRIM(RTRIM(E03.DocumentID)) + SPACE(6), 6) AS DocumentID,
					LEFT(LTRIM(RTRIM(E03.RecordType)) + SPACE(4), 4) +																							--RecordType
					LEFT(LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) + 
					LEFT(LTRIM(RTRIM(E03.DocumentID)) + SPACE(6), 6) + SPACE(23), 23) +																			--Key
					LEFT(LTRIM(RTRIM(E03.[Version])) + SPACE(2), 2) +																			                --Version
					RIGHT('000000' + CAST(CS.Claim_Sequence AS VARCHAR), 6) +																					--Claim_Sequence
					SPACE(6) +																																	--Service_Line_Sequence
					RIGHT('000' + CONVERT(VARCHAR(3), ISNULL(E03.Line_Number, '000')), 3) +														                --Line_Number
					LEFT(LTRIM(RTRIM(E03.Type_Of_Service)) + SPACE(2), 2) +																		                --Type_Of_Service
					LEFT(LTRIM(RTRIM(E03.Procedure_Code)) + SPACE(10), 10) +																	                --Procedure_Code
					LEFT(LTRIM(RTRIM(E03.Place_Of_Service)) + SPACE(2), 2) +																	                --Place_Of_Service
					LEFT(LTRIM(RTRIM(E03.Units)) + SPACE(3), 3) +																				                --Units
					LEFT(LTRIM(RTRIM(E03.[Procedure])) + SPACE(30), 30) +																		                --Procedure
					LEFT(LTRIM(RTRIM(E03.Dates_Of_Service)) + SPACE(17), 17) +																	                --Dates_Of_Service
					LEFT(CASE WHEN SIGN(E03.Total_Charge) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Total_Charge)) + SPACE(15), 15) +							--Total_Charge
					LEFT(CASE WHEN SIGN(E03.Discount) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Discount)) + SPACE(15), 15) +									--Discount
					LEFT(CASE WHEN SIGN(E03.Ineligible) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Ineligible)) + SPACE(15), 15) +								--Ineligible
					LEFT(CASE WHEN SIGN(E03.Pended) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Pended)) + SPACE(15), 15) +										--Pended					
					LEFT(CASE WHEN SIGN(E03.Allowed) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Allowed)) + SPACE(15), 15) +					                --Allowed
					LEFT(LTRIM(RTRIM(E03.Notes_Code1)) + SPACE(10), 10) +																		                --Notes_Code1
					LEFT(LTRIM(RTRIM(E03.Notes_Code2)) + SPACE(10), 10) +																		                --Notes_Code2
					LEFT(LTRIM(RTRIM(E03.Notes_Code3)) + SPACE(10), 10) +																			            --Notes_Code3
					LEFT(CASE WHEN SIGN(E03.Deductible) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Deductible)) + SPACE(15), 15) +								--Deductible
					LEFT(CASE WHEN SIGN(E03.Copay) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Copay)) + SPACE(15), 15) +						                --Copay
					LEFT(CASE WHEN SIGN(E03.Coinsurance) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Coinsurance)) + SPACE(15), 15) +			                --Coinsurance
					LEFT(CASE WHEN SIGN(E03.Balance) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Balance)) + SPACE(15), 15) +					                --Balance
					LEFT(CASE WHEN SIGN(E03.[Percent]) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.[Percent])) + SPACE(3), 3) +									--Percent					
					LEFT(LTRIM(RTRIM(E03.Other_Carrier)) + SPACE(15), 15) +																		                --Other_Carrier
					LEFT(CASE WHEN SIGN(E03.Payment) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Payment)) + SPACE(15), 15) +					                --Payment					
					LEFT(CASE WHEN SIGN(E03.Patient_Responsibility) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Patient_Responsibility)) + SPACE(15), 15) +		--Patient_Responsibility
					LEFT(LTRIM(RTRIM(E03.[Description])) + SPACE(60), 60) +																		                --Description
					LEFT(LTRIM(RTRIM(E03.Tooth_Number)) + SPACE(3), 3) +																		                --Tooth_Number
					LEFT(LTRIM(RTRIM(E03.Tooth_Surface)) + SPACE(3), 3) +																		                --Tooth_Surface
					LEFT(LTRIM(RTRIM(E03.Provider_TIN)) + SPACE(9), 9) +																		                --Provider_TIN
					LEFT(LTRIM(RTRIM(E03.Provider_SubTIN)) + SPACE(3), 3) +																		                --Provider_SubTIN
					LEFT(LTRIM(RTRIM(E03.Alt_ProviderID)) + SPACE(20), 20) +																	                --Alt_ProviderID
					LEFT(LTRIM(RTRIM(E03.Provider_Name)) + SPACE(40), 40) +																		                --Provider_Name
					LEFT(LTRIM(RTRIM(E03.Provider_Address1)) + SPACE(40), 40) +																	                --Provider_Address1
					LEFT(LTRIM(RTRIM(E03.Provider_Address2)) + SPACE(40), 40) +																	                --Provider_Address2
					LEFT(LTRIM(RTRIM(E03.Provider_Address3)) + SPACE(40), 40) +																		            --Provider_Address3
					LEFT(LTRIM(RTRIM(E03.Patient_Account_Number)) + SPACE(30), 30) +															                --Patient_Account_Number
					LEFT(LTRIM(RTRIM(E03.Shade_Flag)) + SPACE(1), 1) +																			                --Shade_Flag
					LEFT(CASE WHEN SIGN(E03.Other_Amount1) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Other_Amount1)) + SPACE(15), 15) +					    --Other_Amount1					
					LEFT(CASE WHEN SIGN(E03.Other_Amount2) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Other_Amount2)) + SPACE(15), 15) +					    --Other_Amount2
					LEFT(CASE WHEN SIGN(E03.Other_Amount3) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Other_Amount3)) + SPACE(15), 15) +					    --Other_Amount3
					LEFT(CASE WHEN SIGN(E03.Other_Amount4) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Other_Amount4)) + SPACE(15), 15) +					    --Other_Amount4
					LEFT(CASE WHEN SIGN(E03.Other_Amount5) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E03.Other_Amount5)) + SPACE(15), 15) +					    --Other_Amount5
					LEFT(LTRIM(RTRIM(E03.Open_Field1)) + SPACE(30), 30) +																		                --Open_Field1
					LEFT(LTRIM(RTRIM(E03.Open_Field2)) + SPACE(30), 30) +																		                --Open_Field2
					LEFT(LTRIM(RTRIM(E03.Open_Field3)) + SPACE(30), 30) +																						--Open_Field3
					LEFT(LTRIM(RTRIM(E03.Open_Field4)) + SPACE(30), 30) +																						--Open_Field4
					LEFT(LTRIM(RTRIM(E03.Open_Field5)) + SPACE(30), 30) +																		                --Open_Field5
					LEFT(LTRIM(RTRIM(E03.Open_Field6)) + SPACE(60), 60) +																		                --Open_Field6
					LEFT(LTRIM(RTRIM(E03.Open_Field7)) + SPACE(60), 60) +																			            --Open_Field7
					LEFT(LTRIM(RTRIM(E03.Open_Field8)) + SPACE(120), 120) +																			            --Open_Field8
					LEFT(LTRIM(RTRIM(E03.Open_Field9)) + SPACE(200), 200) +																		                --Open_Field9
					LEFT(LTRIM(RTRIM(E03.Open_Field10)) + SPACE(200), 200) +																	                --Open_Field10
					LEFT(LTRIM(RTRIM(E03.RX_Number)) + SPACE(15), 15) +																			                --RX_Number
					'@' AS DataRow,
					E03.Open_Field5 AS ClaimType,
					E03.[Source]
		FROM	QNXT_Custom.EOB.EOB_0003ServiceLine E03
		JOIN	#Claim_Sequence CS
			ON	E03.Claim_Number = CS.Claim_Number
			AND	E03.[Source] = CS.[Source]
		JOIN	QNXT_Custom.EOB.EOB_CKey CK			
			ON	1=1		
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Insert EOB_0004 records
		INSERT INTO QNXT_Custom.EOB.EOB_Output ( ProcessHeaderID, ClaimID, Insured_PolicyNumber, IncurredYear, RecordType, CKey, DocumentID, DataRow, ClaimType, [Source] )
		SELECT DISTINCT
					@ProcessHeaderID AS ProcessHeaderID,
					E04.Claim_Number AS ClaimID,
					E04.Insured_PolicyNumber,
					E04.IncurredYear,
					LEFT(LTRIM(RTRIM(E04.RecordType)) + SPACE(4), 4) AS RecordType,		
					LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) AS CKey,
					LEFT(LTRIM(RTRIM(E04.DocumentID)) + SPACE(6), 6) AS DocumentID,
					LEFT(LTRIM(RTRIM(E04.RecordType)) + SPACE(4), 4) +																							--RecordType
					LEFT(LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) + 
					LEFT(LTRIM(RTRIM(E04.DocumentID)) + SPACE(6), 6) + SPACE(23), 23) +																			--Key
					LEFT(LTRIM(RTRIM(E04.[Version])) + SPACE(2), 2) +																			                --Version
					RIGHT('000000' + CAST(CS.Claim_Sequence AS VARCHAR), 6) +																	                --Claim_Sequence
					LEFT(CASE WHEN SIGN(E04.Total_Charge) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Total_Charge)) + SPACE(15), 15) +							--Total_Charge
					LEFT(CASE WHEN SIGN(E04.Discount) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Discount)) + SPACE(15), 15) +									--Discount
					LEFT(CASE WHEN SIGN(E04.Ineligible) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Ineligible)) + SPACE(15), 15) +					            --Ineligible					
					LEFT(LTRIM(RTRIM(E04.Pended)) + SPACE(15), 15) +																			                --Pended
					LEFT(CASE WHEN SIGN(E04.Allowed) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Allowed)) + SPACE(15), 15) +					                --Allowed
					LEFT(CASE WHEN SIGN(E04.Deductible) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Deductible)) + SPACE(15), 15) +								--Deductible
					LEFT(CASE WHEN SIGN(E04.Copay) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Copay)) + SPACE(15), 15) +						                --Copay
					LEFT(CASE WHEN SIGN(E04.Coinsurance) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Coinsurance)) + SPACE(15), 15) +			                --Coinsurance
					LEFT(CASE WHEN SIGN(E04.Balance) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Balance)) + SPACE(15), 15) +					                --Balance
					LEFT(LTRIM(RTRIM(E04.Other_Carrier)) + SPACE(15), 15) +																		                --Other_Carrier
					LEFT(CASE WHEN SIGN(E04.Payment) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Payment)) + SPACE(15), 15) +									--Payment					
					LEFT(CASE WHEN SIGN(E04.Patient_Responsibility) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Patient_Responsibility)) + SPACE(15), 15) +		--Patient_Responsibility
					LEFT(LTRIM(RTRIM(E04.Flex_Med_Annual)) + SPACE(15), 15) +																	                --Flex_Med_Annual
					LEFT(LTRIM(RTRIM(E04.Flex_Med_YTD_Claims)) + SPACE(15), 15) +																                --Flex_Med_YTD_Claims
					LEFT(LTRIM(RTRIM(E04.Flex_Med_YTD_Contributions)) + SPACE(15), 15) +															            --Flex_Med_YTD_Contributions
					LEFT(LTRIM(RTRIM(E04.Flex_Med_YTD_Payment)) + SPACE(15), 15) +																                --Flex_Med_YTD_Payment
					LEFT(LTRIM(RTRIM(E04.Flex_Med_YTD_Remaining)) + SPACE(15), 15) +															                --Flex_Med_YTD_Remaining
					LEFT(LTRIM(RTRIM(E04.Flex_Med_YTD_Balance)) + SPACE(15), 15) +																	            --Flex_Med_YTD_Balance
					LEFT(LTRIM(RTRIM(E04.Flex_Med_YTD_Denied)) + SPACE(15), 15) +																	            --Flex_Med_YTD_Denied
					LEFT(LTRIM(RTRIM(E04.Flex_Med_YTD_Pended)) + SPACE(15), 15) +																                --Flex_Med_YTD_Pended
					LEFT(LTRIM(RTRIM(E04.Flex_Med_YTD_Deposit)) + SPACE(15), 15) +																                --Flex_Med_YTD_Deposit
					LEFT(LTRIM(RTRIM(E04.Flex_Dep_Annual)) + SPACE(15), 15) +																	                --Flex_Dep_Annual
					LEFT(LTRIM(RTRIM(E04.Flex_Dep_YTD_Claims)) + SPACE(15), 15) +																                --Flex_Dep_YTD_Claims
					LEFT(LTRIM(RTRIM(E04.Flex_Dep_YTD_Contributions)) + SPACE(15), 15) +														                --Flex_Dep_YTD_Contributions
					LEFT(LTRIM(RTRIM(E04.Flex_Dep_YTD_Payment)) + SPACE(15), 15) +																                --Flex_Dep_YTD_Payment
					LEFT(LTRIM(RTRIM(E04.Flex_Dep_YTD_Remaining)) + SPACE(15), 15) +															                --Flex_Dep_YTD_Remaining
					LEFT(LTRIM(RTRIM(E04.Flex_Dep_YTD_Balance)) + SPACE(15), 15) +																	            --Flex_Dep_YTD_Balance
					LEFT(LTRIM(RTRIM(E04.Flex_Dep_YTD_Denied)) + SPACE(15), 15) +																                --Flex_Dep_YTD_Denied
					LEFT(LTRIM(RTRIM(E04.Flex_Dep_YTD_Pended)) + SPACE(15), 15) +																                --Flex_Dep_YTD_Pended
					LEFT(LTRIM(RTRIM(E04.Flex_Dep_YTD_Deposit)) + SPACE(15), 15) +																                --Flex_Dep_YTD_Deposit
					LEFT(LTRIM(RTRIM(E04.Other_Amount1)) + SPACE(15), 15) +																		                --Other_Amount1
					LEFT(LTRIM(RTRIM(E04.Other_Amount2)) + SPACE(15), 15) +																		                --Other_Amount2
					LEFT(LTRIM(RTRIM(E04.Other_Amount3)) + SPACE(15), 15) +																		                --Other_Amount3
					LEFT(LTRIM(RTRIM(E04.Other_Amount4)) + SPACE(15), 15) +																		                --Other_Amount4
					LEFT(LTRIM(RTRIM(E04.Other_Amount5)) + SPACE(15), 15) +																		                --Other_Amount5
					LEFT(CASE WHEN SIGN(E04.Open_Field1) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Open_Field1)) + SPACE(30), 30) +			                --Open_Field1
					LEFT(CASE WHEN SIGN(E04.Open_Field2) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04.Open_Field2)) + SPACE(30), 30) +			                --Open_Field2
					LEFT(LTRIM(RTRIM(E04.Open_Field3)) + SPACE(30), 30) +																		                --Open_Field3
					LEFT(LTRIM(RTRIM(E04.Open_Field4)) + SPACE(30), 30) +																		                --Open_Field4
					LEFT(LTRIM(RTRIM(E04.Open_Field5)) + SPACE(30), 30) +																			            --Open_Field5
					'@' AS DataRow,
					E04.Open_Field3 AS ClaimType,
					E04.[Source]
		FROM	QNXT_Custom.EOB.EOB_0004TotalLine E04
		JOIN	#Claim_Sequence CS
			ON	E04.Claim_Number = CS.Claim_Number
			AND	E04.[Source] = CS.[Source]
		JOIN	QNXT_Custom.EOB.EOB_CKey CK			
			ON	1=1		
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		--Insert EOB_0004ZZ records
		INSERT INTO QNXT_Custom.EOB.EOB_Output ( ProcessHeaderID, ClaimID, Insured_PolicyNumber, IncurredYear, RecordType, Claim_Sequence, CKey, DocumentID, DataRow, ClaimType, [Source] )		
		SELECT DISTINCT
					@ProcessHeaderID AS ProcessHeaderID,
					'' AS ClaimID,
					E04Z.Insured_PolicyNumber,
					E04Z.IncurredYear,
					LEFT(LTRIM(RTRIM(E04Z.RecordType)) + SPACE(4), 4) AS RecordType,
					'ZZZZZZ' AS Claim_Sequence,		
					LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) AS CKey,
					LEFT(LTRIM(RTRIM(E04Z.DocumentID)) + SPACE(6), 6) AS DocumentID,
					LEFT(LTRIM(RTRIM(E04Z.RecordType)) + SPACE(4), 4) +																							--RecordType					
					LEFT(LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) + 
					LEFT(LTRIM(RTRIM(E04Z.DocumentID)) + SPACE(6), 6) + SPACE(23), 23) +																		--Key
					LEFT(LTRIM(RTRIM(E04Z.[Version])) + SPACE(2), 2) +																			                --Version
					LEFT(LTRIM(RTRIM('ZZZZZZ')) + SPACE(6), 6) +																								--Claim_Sequence
					LEFT(CASE WHEN SIGN(E04Z.Total_Charge) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Total_Charge)) + SPACE(15), 15) +		                --Total_Charge
					LEFT(CASE WHEN SIGN(E04Z.Discount) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Discount)) + SPACE(15), 15) +				                --Discount
					LEFT(CASE WHEN SIGN(E04Z.Ineligible) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Ineligible)) + SPACE(15), 15) +							--Ineligible
					LEFT(LTRIM(RTRIM(E04Z.Pended)) + SPACE(15), 15) +																							--Pended
					LEFT(CASE WHEN SIGN(E04Z.Allowed) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Allowed)) + SPACE(15), 15) +									--Allowed
					LEFT(CASE WHEN SIGN(E04Z.Deductible) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Deductible)) + SPACE(15), 15) +			                --Deductible
					LEFT(CASE WHEN SIGN(E04Z.Copay) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Copay)) + SPACE(15), 15) +										--Copay
					LEFT(CASE WHEN SIGN(E04Z.Coinsurance) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Coinsurance)) + SPACE(15), 15) +							--Coinsurance
					LEFT(CASE WHEN SIGN(E04Z.Balance) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Balance)) + SPACE(15), 15) +									--Balance
					LEFT(LTRIM(RTRIM(E04Z.IncurredYear)) + SPACE(15), 15) +																						--Other_Carrier
					LEFT(CASE WHEN SIGN(E04Z.Payment) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Payment)) + SPACE(15), 15) +									--Payment					
					LEFT(CASE WHEN SIGN(E04Z.Patient_Responsibility) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Patient_Responsibility)) + SPACE(15), 15) +	--Patient_Responsibility
					LEFT(CASE WHEN SIGN(E04Z.Flex_Med_Annual) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Flex_Med_Annual)) + SPACE(15), 15) +					--Flex_Med_Annual					
					LEFT(CASE WHEN SIGN(E04Z.Flex_Med_YTD_Claims) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Flex_Med_YTD_Claims)) + SPACE(15), 15) +			--Flex_Med_YTD_Claims					
					LEFT(LTRIM(RTRIM(E04Z.Flex_Med_YTD_Contributions)) + SPACE(15), 15) +														                --Flex_Med_YTD_Contributions
					LEFT(CASE WHEN SIGN(E04Z.Flex_Med_YTD_Payment) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Flex_Med_YTD_Payment)) + SPACE(15), 15) +		--Flex_Med_YTD_Payment
					LEFT(CASE WHEN SIGN(E04Z.Flex_Med_YTD_Remaining) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Flex_Med_YTD_Remaining)) + SPACE(15), 15) +	--Flex_Med_YTD_Remaining
					LEFT(CASE WHEN SIGN(E04Z.Flex_Med_YTD_Balance) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Flex_Med_YTD_Balance)) + SPACE(15), 15) +		--Flex_Med_YTD_Balance
					LEFT(CASE WHEN SIGN(E04Z.Flex_Med_YTD_Denied) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Flex_Med_YTD_Denied)) + SPACE(15), 15) +			--Flex_Med_YTD_Denied
					LEFT(CASE WHEN SIGN(E04Z.Flex_Med_YTD_Pended) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Flex_Med_YTD_Pended)) + SPACE(15), 15) +			--Flex_Med_YTD_Pended
					LEFT(CASE WHEN SIGN(E04Z.Flex_Med_YTD_Deposit) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Flex_Med_YTD_Deposit)) + SPACE(15), 15) +		--Flex_Med_YTD_Deposit
					LEFT(CASE WHEN SIGN(E04Z.Flex_Dep_Annual) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Flex_Dep_Annual)) + SPACE(15), 15) +					--Flex_Dep_Annual
					LEFT(LTRIM(RTRIM(E04Z.Flex_Dep_YTD_Claims)) + SPACE(15), 15) +																				--Flex_Dep_YTD_Claims
					LEFT(LTRIM(RTRIM(E04Z.Flex_Dep_YTD_Contributions)) + SPACE(15), 15) +														                --Flex_Dep_YTD_Contributions
					LEFT(CASE WHEN SIGN(E04Z.Flex_Dep_YTD_Payment) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Flex_Dep_YTD_Payment)) + SPACE(15), 15) +		--Flex_Dep_YTD_Payment					
					LEFT(LTRIM(RTRIM(E04Z.Flex_Dep_YTD_Remaining)) + SPACE(15), 15) +															                --Flex_Dep_YTD_Remaining
					LEFT(LTRIM(RTRIM(E04Z.Flex_Dep_YTD_Balance)) + SPACE(15), 15) +																                --Flex_Dep_YTD_Balance
					LEFT(LTRIM(RTRIM(E04Z.Flex_Dep_YTD_Denied)) + SPACE(15), 15) +																                --Flex_Dep_YTD_Denied
					LEFT(LTRIM(RTRIM(E04Z.Flex_Dep_YTD_Pended)) + SPACE(15), 15) +																                --Flex_Dep_YTD_Pended
					LEFT(LTRIM(RTRIM(E04Z.Flex_Dep_YTD_Deposit)) + SPACE(15), 15) +																                --Flex_Dep_YTD_Deposit
					LEFT(LTRIM(RTRIM(E04Z.Other_Amount1)) + SPACE(15), 15) +																	                --Other_Amount1
					LEFT(LTRIM(RTRIM(E04Z.Other_Amount2)) + SPACE(15), 15) +																	                --Other_Amount2
					LEFT(CASE WHEN SIGN(E04Z.Other_Amount3) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Other_Amount3)) + SPACE(15), 15) +						--Other_Amount3
					LEFT(CASE WHEN SIGN(E04Z.Other_Amount4) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Other_Amount4)) + SPACE(15), 15) +						--Other_Amount4
					LEFT(LTRIM(RTRIM(E04Z.Other_Amount5)) + SPACE(15), 15) +																		            --Other_Amount5
					LEFT(CASE WHEN SIGN(E04Z.Open_Field1) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Open_Field1)) + SPACE(30), 30) +							--Open_Field1
					LEFT(CASE WHEN SIGN(E04Z.Open_Field2) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Open_Field2)) + SPACE(30), 30) +							--Open_Field2
					LEFT(CASE WHEN SIGN(E04Z.Open_Field3) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E04Z.Open_Field3)) + SPACE(30), 30) +							--Open_Field3
					LEFT(LTRIM(RTRIM(E04Z.Open_Field4)) + SPACE(30), 30) +																						--Open_Field4
					LEFT(LTRIM(RTRIM(E04Z.Open_Field5)) + SPACE(30), 30) +																						--Open_Field5
					'@' AS DataRow,
					'' AS ClaimType,
					'ZZ Summary' AS [Source]
		FROM	QNXT_Custom.EOB.EOB_0004ZZSegment E04Z
		JOIN	QNXT_Custom.EOB.EOB_CKey CK			
			ON	1=1		
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		--Insert EOB_0005 records
		IF OBJECT_ID('tempdb.dbo.#Notes') IS NOT NULL
		DROP TABLE #Notes
		
		;WITH CTE AS
		(
			SELECT	E05.*,
					CS.Claim_Sequence AS Custom_Claim_Sequence,
					CK.CKey_FileSeqID,
					0 AS New_Line_Number, 
					ROW_NUMBER() OVER (PARTITION BY E05.DocumentID, CAST(E05.Notes_Code AS INT) ORDER BY CAST(E05.Notes_Code AS INT)) AS Row_Num
			FROM	QNXT_Custom.EOB.EOB_0005Comments E05
			JOIN	#Claim_Sequence CS
				ON	E05.Claim_Number = CS.Claim_Number
				AND	E05.[Source] = CS.[Source]
			JOIN	QNXT_Custom.EOB.EOB_CKey CK				
				ON	1=1
		)
		SELECT	*
		INTO	#Notes
		FROM	CTE
		WHERE	CTE.Row_Num = 1

		;WITH CTE AS
		(
			SELECT	*,
					ROW_NUMBER() OVER (PARTITION BY N.DocumentID ORDER BY CAST(N.Notes_Code AS INT)) AS New_Row_Num 
			FROM	#Notes N
		)
		UPDATE	N
			SET	N.New_Line_Number = CTE.New_Row_Num
		FROM	CTE
		JOIN	#Notes N
			ON	CTE.Insured_PolicyNumber = N.Insured_PolicyNumber
			AND	CTE.IncurredYear = N.IncurredYear
			AND CTE.[Source] = N.[Source]
			AND CTE.ClaimType = N.ClaimType
			AND CTE.DocumentID = N.DocumentID
			AND CTE.Claim_Number = N.Claim_Number
			AND CTE.Line_Number = N.Line_Number
			AND CTE.Notes_Code = N.Notes_Code
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		INSERT INTO QNXT_Custom.EOB.EOB_Output ( ProcessHeaderID, ClaimID, ClaimLineID, Insured_PolicyNumber, IncurredYear, [Source], RecordType, CKey, DocumentID, DataRow, ClaimType, SortKey )	
		SELECT	DISTINCT
					@ProcessHeaderID AS ProcessHeaderID,					
					'' AS ClaimID,
					0 AS ClaimLineID,
					N.Insured_PolicyNumber,
					N.IncurredYear,
					N.[Source],
					LEFT(LTRIM(RTRIM(N.RecordType)) + SPACE(4), 4) AS RecordType,					
					LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + N.CKey_FileSeqID)) AS CKey,
					LEFT(LTRIM(RTRIM(N.DocumentID)) + SPACE(6), 6) AS DocumentID,
					LEFT(LTRIM(RTRIM(N.RecordType)) + SPACE(4), 4) +																							--RecordType					
					LEFT(LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + N.CKey_FileSeqID)) + 
					LEFT(LTRIM(RTRIM(N.DocumentID)) + SPACE(6), 6) + SPACE(23), 23) +																			--Key
					LEFT(LTRIM(RTRIM(N.[Version])) + SPACE(2), 2) +																								--Version
					RIGHT('000000' + CAST(N.Custom_Claim_Sequence AS VARCHAR), 6) +																			    --Claim_Sequence
					LEFT(LTRIM(RTRIM(N.Claim_Number)) + SPACE(30), 30) +																		                --Claim_Number
					RIGHT('000' + CONVERT(VARCHAR(3), ISNULL(N.New_Line_Number, '000')), 3) +														            --Line_Number
					LEFT(LTRIM(RTRIM(N.Notes_Code)) + SPACE(10), 10) +																							--Notes_Code
					LEFT(LTRIM(RTRIM(N.[Description])) + SPACE(200), 200) +																						--Description
					LEFT(LTRIM(RTRIM(N.Open_Field1)) + SPACE(100), 100) +																						--Open_Field1
					'@' AS DataRow,
					N.ClaimType AS ClaimType,
					CONVERT(INT, N.Notes_Code) AS SortKey
		FROM	#Notes N
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Insert EOB_0008 records
		INSERT INTO QNXT_Custom.EOB.EOB_Output ( ProcessHeaderID, Insured_PolicyNumber, IncurredYear, RecordType, Claim_Sequence, CKey, DocumentID, DataRow )	
		SELECT	DISTINCT
					@ProcessHeaderID AS ProcessHeaderID,					
					E08.Insured_PolicyNumber,
					E08.IncurredYear,
					LEFT(LTRIM(RTRIM(E08.RecordType)) + SPACE(4), 4) AS RecordType,					
					'ZZ0008' AS Claim_Sequence,
					LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) AS CKey,
					LEFT(LTRIM(RTRIM(E08.DocumentID)) + SPACE(6), 6) AS DocumentID,
					LEFT(LTRIM(RTRIM(E08.RecordType)) + SPACE(4), 4) +																							--RecordType					
					LEFT(LEFT(LTRIM(RTRIM(@ClientID)), 4) + LTRIM(RTRIM('028' + CONVERT(VARCHAR, GETDATE(), 112) + CK.CKey_FileSeqID)) + 
					LEFT(LTRIM(RTRIM(E08.DocumentID)) + SPACE(6), 6) + SPACE(23), 23) +																			--Key
					LEFT(LTRIM(RTRIM(E08.[Version])) + SPACE(2), 2) +																			                --Version
					LEFT(LTRIM(RTRIM('ZZ0008')) + SPACE(6), 6) +																								--Claim_Sequence
					LEFT(LTRIM(RTRIM(E08.Accumulator_Description)) + SPACE(40), 40) +																			--Accumulator_Description
					LEFT(LTRIM(RTRIM(E08.Amount_Met)) + SPACE(15), 15) +																						--Amount_Met
					LEFT(LTRIM(RTRIM(E08.Amount_Remaining)) + SPACE(15), 15) +																					--Accumulator_Description
					LEFT(LTRIM(RTRIM(E08.Amount_To_Meet)) + SPACE(15), 15) +																					--Amount_To_Meet
					LEFT(LTRIM(RTRIM(E08.Amount_Type)) + SPACE(1), 1) +																							--Amount_Type
					LEFT(LTRIM(RTRIM(E08.Claim_Year)) + SPACE(4), 4) +																							--Claim_Year
					LEFT(CASE WHEN SIGN(E08.Open_Field1) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E08.Open_Field1)) + SPACE(30), 30) +							--Open_Field1
					LEFT(LTRIM(RTRIM(E08.Open_Field2)) + SPACE(30), 30) +																						--Open_Field2
					LEFT(CASE WHEN SIGN(E08.Open_Field3) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E08.Open_Field3)) + SPACE(30), 30) +							--Open_Field3
					LEFT(CASE WHEN SIGN(E08.Open_Field4) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E08.Open_Field4)) + SPACE(30), 30) +							--Open_Field4
					LEFT(CASE WHEN SIGN(E08.Open_Field5) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E08.Open_Field5)) + SPACE(30), 30) +							--Open_Field5
					LEFT(LTRIM(RTRIM(E08.Open_Field6)) + SPACE(30), 30) +																						--Open_Field6
					LEFT(CASE WHEN SIGN(E08.Open_Field7) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E08.Open_Field7)) + SPACE(30), 30) +							--Open_Field7
					LEFT(CASE WHEN SIGN(E08.Open_Field8) >= 0 THEN '+' ELSE '' END + LTRIM(RTRIM(E08.Open_Field8)) + SPACE(30), 30) +							--Open_Field8
					LEFT(LTRIM(RTRIM(E08.Open_Field9)) + SPACE(30), 30) +																						--Open_Field9
					LEFT(LTRIM(RTRIM(E08.Open_Field10)) + SPACE(30), 30) +																						--Open_Field10
					LEFT(LTRIM(RTRIM(E08.Open_Field11)) + SPACE(30), 30) +																						--Open_Field11
					LEFT(LTRIM(RTRIM(E08.Open_Field12)) + SPACE(30), 30) +																						--Open_Field12
					LEFT(LTRIM(RTRIM(E08.Open_Field13)) + SPACE(30), 30) +																						--Open_Field13
					LEFT(LTRIM(RTRIM(E08.Open_Field14)) + SPACE(30), 30) +																						--Open_Field14
					LEFT(LTRIM(RTRIM(E08.Open_Field15)) + SPACE(30), 30) +																						--Open_Field15
					LEFT(LTRIM(RTRIM(E08.Open_Field16)) + SPACE(60), 60) +																						--Open_Field16
					LEFT(LTRIM(RTRIM(E08.Open_Field17)) + SPACE(60), 60) +																						--Open_Field17
					LEFT(LTRIM(RTRIM(E08.Open_Field18)) + SPACE(60), 60) +																						--Open_Field18
					LEFT(LTRIM(RTRIM(E08.Open_Field19)) + SPACE(60), 60) +																						--Open_Field19
					LEFT(LTRIM(RTRIM(E08.Open_Field20)) + SPACE(60), 60) +																						--Open_Field20
					LEFT(LTRIM(RTRIM(E08.Open_Field21)) + SPACE(200), 200) +																					--Open_Field21
					'@' AS DataRow
		FROM	QNXT_Custom.EOB.EOB_0008Accumulator E08		
		JOIN	QNXT_Custom.EOB.EOB_CKey CK			
			ON	1=1
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_Output REBUILD

		;WITH CTE AS
		(
			SELECT DISTINCT	E02.Insured_PolicyNumber,
							E02.Claim_Number,
							E02.Open_Field3 AS Claim_Type,
							ROW_NUMBER() OVER (PARTITION BY E02.Insured_PolicyNumber, E02.DocumentID ORDER BY E02.Open_Field3) AS Claim_Sequence
			FROM	QNXT_Custom.EOB.EOB_0002EOB E02 
		)
		UPDATE	EO
			SET	EO.Claim_Sequence = CTE.Claim_Sequence
		FROM	CTE
		JOIN	QNXT_Custom.EOB.EOB_Output EO
			ON	CTE.Insured_PolicyNumber = EO.Insured_PolicyNumber
			AND	CTE.Claim_Number = EO.ClaimID
			AND	CTE.Claim_Type = EO.ClaimType
			AND	EO.RecordType IN ('0002','0003','0004')
			AND	EO.Claim_Sequence NOT IN ('ZZZZZZ', 'ZZ0008')
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO