CREATE PROCEDURE [EOB].[EOB_Transform0003ServiceLine] (@BeginDate DATE, @EndDate DATE, @ProcessHeaderID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Transform0003ServiceLine.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			08.13.2018			215695		Updated logic to set the appropriate values on open fields 7 and 8 (CM20025799)
-- 1.3	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
-- 1.4	KB			08.01.2019						CM20097013 - Using member's latest enrollment in QNXT; WYMBB changes
###########################################################################################################################################################
*/

TRUNCATE TABLE EOB.EOB_0003ServiceLine

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		IF OBJECT_ID('TEMPDB..#MemberLanguage') IS NOT NULL
		DROP TABLE #MemberLanguage

		CREATE TABLE #MemberLanguage
		(
			Insured_PolicyNumber VARCHAR(20),
			[Language] VARCHAR(2)
		)

		INSERT INTO #MemberLanguage
		SELECT	DISTINCT 
					MD.Insured_PolicyNumber,
					CASE WHEN L.[Description] LIKE '%SPANISH%' THEN 'SP'
							ELSE 'EN' END AS [Language]
		FROM	QNXT_Custom.EOB.EOB_0001MasterDeliv MD
		JOIN	Plandata_Prod.dbo.Member M
			ON	MD.Insured_PolicyNumber = M.SecondaryID
		LEFT JOIN	QNXT_Custom.EOB.EOB_MemberLanguageXref L
			ON	M.PrimaryLanguage = L.LanguageID
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		CREATE CLUSTERED INDEX IDX_MemberLanguage ON #MemberLanguage ( Insured_PolicyNumber ASC, [Language] ASC )

		INSERT INTO [EOB].[EOB_0003ServiceLine] ( ProcessHeaderID, Claim_Number, Insured_PolicyNumber, EncounterType, Line_Number, Dates_Of_Service, Total_Charge, Discount, Allowed, 
									Deductible, Copay, Coinsurance, Balance, Patient_Responsibility, Open_Field1, Open_Field2, Open_Field3, Open_Field4, Open_Field5, Open_Field6, Open_Field7, 
									Open_Field8, Open_Field9, Open_Field10, IncurredYear, [Source] )
		SELECT
			@ProcessHeaderID AS ProcessHeaderID,
			ECD.ClaimID AS Claim_Number,
			EC.MemberID AS Insured_PolicyNumber,
			ECD.ClaimType AS EncounterType,
			FORMAT(ECD.ClaimLine, '00#') AS Line_Number,
			CASE WHEN ML.[Language] = 'SP' THEN LEFT(REPLACE(CONVERT(VARCHAR, ECD.BeginServiceDate, 103), '/', '') + '-' + REPLACE(CONVERT(VARCHAR, ECD.EndServiceDate, 103), '/', ''), 17)
					ELSE LEFT(REPLACE(CONVERT(VARCHAR, ECD.BeginServiceDate, 101), '/', '') + '-' + REPLACE(CONVERT(VARCHAR, ECD.EndServiceDate, 101), '/', ''), 17) END AS Dates_Of_Service,					
			ECD.BilledAmount AS Total_Charge,
			ECD.Discount AS Discount,
			CASE WHEN ECD.Is_Capitated = 'Y' THEN 0.00
					ELSE ECD.Eligible END AS Allowed,
			ECD.DeductibleAmount AS Deductible,
			ECD.CopayAmount AS Copay,
			ECD.CoinsuranceAmount AS Coinsurance,
			CASE WHEN ECD.Is_Capitated = 'Y' THEN 0.00
					ELSE ECD.PaidAmount END AS Balance,
			CASE WHEN ECD.IDN_Denied_Charge > 0.00 THEN ECD.IDN_Denied_Charge
					ELSE ECD.DeductibleAmount + ECD.CopayAmount + ECD.CoinsuranceAmount END AS Patient_Responsibility,
			CASE WHEN ML.[Language] = 'SP' THEN CONVERT(VARCHAR, ECD.BeginServiceDate, 103)
							ELSE CONVERT(VARCHAR, ECD.BeginServiceDate, 101) END AS Open_Field1,
			CASE WHEN ML.[Language] = 'SP' THEN CONVERT(VARCHAR, ECD.EndServiceDate, 103)
							ELSE CONVERT(VARCHAR, ECD.EndServiceDate, 101) END AS Open_Field2,
			CASE	WHEN ECD.ClaimType = 'RX' AND ISNULL(UPPER(ECD.RX_NDC), '') <> '' THEN UPPER(ECD.RX_NDC)
					WHEN ISNULL(UPPER(MFC.ClientCPTID), '') <> '' AND ISNULL(MFC.CCMShortDescription, '') <> '' THEN UPPER(ECD.Procedure_Code)
					WHEN ISNULL(UPPER(HFC.Code), '') <> '' AND ISNULL(HFC.CCMShortDescription, '') <> '' THEN UPPER(ECD.Procedure_Code)
					WHEN ISNULL(UPPER(ECD.Procedure_Code), '') <> '' AND ISNULL(SCD.SvcDesc, '') <> '' THEN UPPER(ECD.Procedure_Code)
					WHEN ISNULL(ECD.Revenue_Code, '') <> '' AND ISNULL(RFC.Code, '') <> '' AND ISNULL(RFC.CCMShortDescription, '') <> '' THEN UPPER(ECD.Revenue_Code)
					WHEN ISNULL(ECD.Revenue_Code, '') <> '' AND ISNULL(RC.CodeID, '') <> '' AND ISNULL(RC.[Description], '') <> '' THEN UPPER(ECD.Revenue_Code)
					ELSE '' END AS Open_Field3,	
			CASE	WHEN ECD.[Source] IN ('CL', 'RX') AND ECD.ClaimLineStatus = 'D' THEN 'DENIED'
					WHEN ECD.[Source] NOT IN ('CL', 'RX') AND ECD.Is_Capitated <> 'Y' AND ECD.ClaimLineStatus = 'D' THEN 'DENIED'
					ELSE 'APPROVED' END AS Open_Field4,
			ECD.ClaimType AS Open_Field5,
			CASE	WHEN ECD.ClaimType = 'RX' AND ISNULL(UPPER(ECD.RX_NDC), '') <> '' THEN UPPER(LTRIM(RTRIM(ECD.RX_NDCDesc)))
					WHEN ISNULL(UPPER(MFC.ClientCPTID), '') <> '' AND ISNULL(MFC.CCMShortDescription, '') <> '' THEN UPPER(LTRIM(RTRIM(MFC.CCMShortDescription)))
					WHEN ISNULL(UPPER(HFC.Code), '') <> '' AND ISNULL(HFC.CCMShortDescription, '') <> '' THEN UPPER(LTRIM(RTRIM(HFC.CCMShortDescription)))
					WHEN ISNULL(UPPER(ECD.Procedure_Code), '') <> '' AND ISNULL(SCD.SvcDesc, '') <> '' THEN LTRIM(RTRIM(ISNULL(UPPER(SCD.SvcDesc), '')))
					WHEN ISNULL(ECD.Revenue_Code, '') <> '' AND ISNULL(RFC.Code, '') <> '' AND ISNULL(RFC.CCMShortDescription, '') <> '' THEN UPPER(LTRIM(RTRIM(RFC.CCMShortDescription)))
					WHEN ISNULL(ECD.Revenue_Code, '') <> '' AND ISNULL(RC.CodeID, '') <> '' AND ISNULL(RC.[Description], '') <> '' THEN UPPER(LTRIM(RTRIM(RC.[Description])))
					ELSE '' END AS Open_Field6,
			'' AS Open_Field7,
			'' AS Open_Field8,
			'' AS Open_Field9,
			'' AS Open_Field10,
			YEAR(EC.BeginServiceDate) AS IncurredYear,
			ECD.[Source] AS [Source]		
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID
			AND	ECD.[Source] = EC.[Source]
		JOIN	#MemberLanguage ML
			ON	EC.MemberID = ML.Insured_PolicyNumber
		LEFT JOIN	Plandata_Prod.dbo.SvcCodeDescriptor SCD
			ON	ECD.Procedure_Code = SCD.SvcCodeID
			AND	ECD.BeginServiceDate BETWEEN SCD.EffDate AND SCD.TermDate
		LEFT JOIN	Plandata_Prod.dbo.RevCode RC
			ON	ECD.Revenue_Code = RC.CodeID
			AND	ECD.BeginServiceDate BETWEEN RC.EffDate AND RC.TermDate
		LEFT JOIN	QNXT_Custom.EOB.CPTCodeTranslate MFC
			ON	ECD.Procedure_Code = CONVERT(VARCHAR, MFC.ClientCPTID)
			AND	MFC.[Language] = ML.[Language]
		LEFT JOIN	QNXT_Custom.EOB.RevenueCodeTranslate RFC
			ON	ECD.Revenue_Code = CONVERT(VARCHAR, RFC.Code)
			AND	RFC.[Language] = ML.[Language]		
		LEFT JOIN	QNXT_Custom.EOB.HCPCSCodeTranslate HFC
			ON	ECD.Procedure_Code = CONVERT(VARCHAR, HFC.Code)
			AND	HFC.[Language] = ML.[Language]
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_0003ServiceLine REBUILD

		IF OBJECT_ID('TEMPDB..#CoInsurancePercentage') IS NOT NULL
		DROP TABLE #CoInsurancePercentage

		CREATE TABLE #CoInsurancePercentage
		(
			Claim_Number VARCHAR(30),
			Line_Number VARCHAR(3),
			Insured_PolicyNumber VARCHAR(20), 
			[Source] VARCHAR(60),
			Allowed DECIMAL(9,2),
			Deductible DECIMAL(9,2),
			Copay DECIMAL(9,2),
			Coinsurance DECIMAL(9,2),
			[Language] VARCHAR(2),
			CoinsPercent INT,
			Open_Field8 VARCHAR(120),
			Open_Field9 VARCHAR(200),
			Open_Field10 VARCHAR(200)
		)

		INSERT INTO #CoInsurancePercentage ( Claim_Number, Line_Number, Insured_PolicyNumber, [Source], Allowed, Deductible, Copay, Coinsurance, [Language], CoinsPercent, Open_Field9 )
		SELECT	DISTINCT
					E03.Claim_Number,
					E03.Line_Number,
					E03.Insured_PolicyNumber,
					E03.[Source],
					CASE	WHEN	CD.ClaimID IS NOT NULL AND CD.ContractPaid > 0.00
							THEN	CAST(CD.ContractPaid AS DECIMAL(9,2))
							WHEN	ECD.Eligible > 0.00
							THEN	CAST(ECD.Eligible AS DECIMAL(9,2))
							WHEN	CAST(E03.Allowed AS DECIMAL(9,2)) < 0.00 
							THEN	0.00						
							ELSE	CAST(E03.Allowed AS DECIMAL(9,2))
					END AS Allowed,
					CASE	WHEN	CAST(E03.Deductible AS DECIMAL(9,2)) < 0.00 
							THEN	0.00
							ELSE	CAST(E03.Deductible AS DECIMAL(9,2)) 
					END AS Deductible,
					CASE	WHEN	CAST(E03.Copay AS DECIMAL(9,2)) < 0.00 
							THEN	0.00
							ELSE	CAST(E03.Copay AS DECIMAL(9,2)) 
					END AS Copay,
					CASE	WHEN	CAST(E03.Coinsurance AS DECIMAL(9,2)) < 0.00 
							THEN	0.00
							ELSE	CAST(E03.Coinsurance AS DECIMAL(9,2)) END AS Coinsurance,
					ML.[Language] AS [Language],
					0.00 AS CoinsPercent,
					'' AS Open_Field9
		FROM	QNXT_Custom.EOB.EOB_0003ServiceLine E03
		JOIN	#MemberLanguage ML
			ON	E03.Insured_PolicyNumber = ML.Insured_PolicyNumber
		JOIN	QNXT_Custom.EOB.EOB_ClaimDetail ECD
			ON	E03.Claim_Number = ECD.ClaimID
			AND	E03.Line_Number = FORMAT(ECD.ClaimLine, '00#')
			AND E03.[Source] = ECD.[Source]					
		LEFT JOIN	Plandata_Prod.dbo.ClaimDetail CD
			ON	E03.Claim_Number = CD.ClaimID
			AND	E03.Line_Number = FORMAT(CD.ClaimLine, '00#')
		
		CREATE CLUSTERED INDEX IDX_CoInsurancePercentage ON #CoInsurancePercentage ( Claim_Number ASC, Line_Number ASC, Insured_PolicyNumber ASC, [Source] ASC )

		UPDATE	CIP
			SET	CIP.CoinsPercent = CAST(ROUND((CIP.Coinsurance * 100) / (CIP.Allowed - (CIP.Copay + CIP.Deductible)), 0) AS INT)
		FROM	#CoInsurancePercentage CIP
		WHERE	CIP.Coinsurance > 0.00
			AND	(CIP.Allowed - (CIP.Copay + CIP.Deductible)) > 0.00
		
		UPDATE	CIP
			SET	CIP.Open_Field8 =	CASE
										WHEN	CIP.Copay > 0.00 
											AND CIP.[Language] = 'SP'
										THEN	'Usted paga un copago de $' + CAST(FORMAT(CIP.Copay, '#,0.00') AS VARCHAR) + ' por estos servicios, brindados por un proveedor'
										WHEN	CIP.Copay > 0.00											
										THEN	'You pay a $' + CAST(FORMAT(CIP.Copay, '#,0.00') AS VARCHAR) + ' copayment for these services'
										ELSE	''
									END,
				CIP.Open_Field9 =	CASE 
										WHEN	CIP.Deductible > 0.00 
											AND CIP.[Language] = 'SP'
										THEN	'Usted paga un deducible de $' + CAST(FORMAT(CIP.Deductible, '#,0.00') AS VARCHAR) + ' por este servicio o art�culo'
										WHEN	CIP.Deductible > 0.00
										THEN	'You pay a $' + CAST(FORMAT(CIP.Deductible, '#,0.00') AS VARCHAR) + ' deductible for this service or item' 
										ELSE	''
									END,
				CIP.Open_Field10 =	CASE
										WHEN	CIP.Coinsurance > 0.00											
											AND CIP.Copay = 0.00
											AND CIP.Deductible = 0.00
											AND CIP.[Language] = 'SP'
										THEN	'Usted paga el ' + CAST(CIP.CoinsPercent AS VARCHAR) + '% de la cantidad total por los servicios de un proveedor'
										WHEN	CIP.Coinsurance > 0.00											
											AND CIP.Copay = 0.00
											AND CIP.Deductible = 0.00											
										THEN	'You pay ' + CAST(CIP.CoinsPercent AS VARCHAR) + '% of the total amount for services'
										WHEN	CIP.Coinsurance > 0.00
											AND CIP.[Language] = 'SP'
											AND ( CIP.Copay > 0.00
												OR CIP.Deductible > 0.00 )
										THEN	'Usted paga $' + CAST(FORMAT(CIP.Coinsurance, '#,0.00') AS VARCHAR) + ', que es el ' + CAST(CIP.CoinsPercent AS VARCHAR) + '% de la cantidad total, por los servicios de un proveedor'
										WHEN	CIP.Coinsurance > 0.00											
											AND ( CIP.Copay > 0.00
												OR CIP.Deductible > 0.00 )
										THEN	'You pay $' + CAST(FORMAT(CIP.Coinsurance, '#,0.00') AS VARCHAR) + ' which is ' + CAST(CIP.CoinsPercent AS VARCHAR) + '% of the total amount for services'
										ELSE	''
									END
		FROM	#CoInsurancePercentage CIP
		
		UPDATE	CIP
			SET	CIP.Open_Field8 =	CASE 
										WHEN	CIP.Open_Field8 <> ''
											AND CIP.[Language] = 'SP'
										THEN	CIP.Open_Field8 +
											CASE	WHEN C.Par_Ind = 'P' THEN ' de la red'
													ELSE ' fuera de la red'
											END
										WHEN	CIP.Open_Field8 <> ''																				
										THEN	CIP.Open_Field8 + ' from an ' +
											CASE	WHEN C.Par_Ind = 'P' THEN 'in-network provider'
													ELSE 'out-of-network provider'
											END
										ELSE CIP.Open_Field8
									END,				
				CIP.Open_Field10 =	CASE 
										WHEN	CIP.Open_Field10 <> ''											
											AND CIP.[Language] = 'SP'
										THEN	CIP.Open_Field10 +
											CASE	WHEN C.Par_Ind = 'P' THEN ' de la red'
													ELSE ' fuera de la red'
											END
										WHEN	CIP.Open_Field10 <> ''										
										THEN	CIP.Open_Field10 + ' from an ' +
											CASE	WHEN C.Par_Ind = 'P' THEN 'in-network provider'
													ELSE 'out-of-network provider'
											END
										ELSE CIP.Open_Field10
									END
		FROM	#CoInsurancePercentage CIP
		JOIN	QNXT_Custom.EOB.EOB_Claim C
			ON	CIP.Claim_Number = C.ClaimID
			AND	CIP.Insured_PolicyNumber = C.MemberID
			AND CIP.[Source] = C.[Source]
		
		UPDATE	E03
			SET	E03.Open_Field8 = CIP.Open_Field8,
				E03.Open_Field9 = CIP.Open_Field9,
				E03.Open_Field10 = CIP.Open_Field10
		FROM	QNXT_Custom.EOB.EOB_0003ServiceLine E03
		JOIN	#CoInsurancePercentage CIP
			ON	E03.Claim_Number = CIP.Claim_Number
			AND	E03.Insured_PolicyNumber = CIP.Insured_PolicyNumber
			AND	E03.Line_Number = CIP.Line_Number
			AND E03.[Source] = CIP.[Source]

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO