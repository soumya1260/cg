CREATE PROCEDURE [EOB].[EOB_Get_Export_Years] AS
SET XACT_ABORT, NOCOUNT ON
/*
####################################################################################
-- Name:			EOB_Get_Export_Years.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
####################################################################################
-- Parameters
--     N/A
####################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204) 
####################################################################################
*/
BEGIN TRY
	SELECT DISTINCT
		E02.IncurredYear
	FROM	QNXT_Custom.EOB.EOB_0002EOB E02 WITH (NOLOCK)
END TRY

BEGIN CATCH
	THROW;
END CATCH

GO
