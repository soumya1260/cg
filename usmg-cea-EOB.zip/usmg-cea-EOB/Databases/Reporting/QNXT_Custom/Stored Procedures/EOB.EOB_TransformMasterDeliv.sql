CREATE PROCEDURE [EOB].[EOB_TransformMasterDeliv] (@BeginDate DATE, @EndDate DATE, @ProcessHeaderID INT, @RunYear INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_TransformMasterDeliv.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			07.18.2018			215695		Updated logic to help avoid PK violation on insert (CM20020425)
-- 1.3	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
-- 1.4	KB			08.01.2019						CM20097013 - Using member's latest enrollment in QNXT
###########################################################################################################################################################
*/

TRUNCATE TABLE EOB.EOB_0001MasterDeliv

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		IF OBJECT_ID('TEMPDB..#MemberPlanYears') IS NOT NULL
		DROP TABLE #MemberPlanYears

		;WITH CTE AS
		(
			SELECT	EC.MemberID,					
					CASE	WHEN EK.EnrollID IS NULL OR LEN(LTRIM(RTRIM(BP.UPID))) NOT IN (9, 8) THEN EC.ContractCode
							ELSE LEFT(LTRIM(RTRIM(BP.UPID)), 5) 
					END AS ContractCode,
					CASE	WHEN EK.EnrollID IS NULL OR LEN(LTRIM(RTRIM(BP.UPID))) NOT IN (9, 8) THEN EC.PBPCode
							WHEN EK.EnrollID IS NOT NULL AND LEN(LTRIM(RTRIM(BP.UPID))) = 9 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 4)
							WHEN EK.EnrollID IS NOT NULL AND LEN(LTRIM(RTRIM(BP.UPID))) = 8 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 3) 
					END AS PBPCode,
					EC.QNXTPlanID,					
					ROW_NUMBER() OVER (PARTITION BY EC.MemberID ORDER BY EK.EffDate DESC, EK.TermDate DESC) AS RowNum					
			FROM	QNXT_Custom.EOB.EOB_Claim EC
			JOIN	Plandata_Prod.dbo.Member M
				ON	EC.MemberID = M.SecondaryID
			LEFT JOIN	Plandata_Prod.dbo.EnrollKeys EK
				ON	M.MemID = EK.MemID
				AND EK.SegType = 'INT'
			LEFT JOIN	Plandata_Prod.dbo.BenefitPlan BP
				ON	EK.PlanID = BP.PlanID
		)
		SELECT	DISTINCT CTE.MemberID,
							@RunYear AS IncurredYear,
							CTE.ContractCode,
							CTE.PBPCode,
							CTE.QNXTPlanID
		INTO	#MemberPlanYears
		FROM	CTE
		WHERE	CTE.RowNum = 1

		CREATE CLUSTERED INDEX IDX_MemberPlanYears ON #MemberPlanYears ( MemberID ASC, IncurredYear ASC, ContractCode ASC, PBPCode ASC, QNXTPlanID ASC )

		--Generic insert works for QNXT (CL), RX and FDR claims
		INSERT INTO QNXT_Custom.EOB.EOB_0001MasterDeliv( ProcessHeaderID, Insured_PolicyNumber, IncurredYear, [Source], MemberPlan, [Name], Address1, Address2, City, [State], Zip, International_City_State_Country_Zip, Name2, Data_Type )
		SELECT DISTINCT
					@ProcessHeaderID AS ProcessHeaderID,
					MPY.MemberID AS Insured_PolicyNumber,
					MPY.IncurredYear AS IncurredYear,
					'' AS [Source],
					LTRIM(RTRIM(MPY.ContractCode)) + LTRIM(RTRIM(MPY.PBPCode)) AS MemberPlan,
					CASE WHEN M.deathdate IS NOT NULL AND M.deathdate <> '12/31/2078' THEN LEFT('To the Estate of ' + LTRIM(RTRIM(ISNULL(E.FirstName, ''))) + ' ' + LEFT(LTRIM(RTRIM(E.MiddleName)), 1), 45)
							ELSE LEFT(LTRIM(RTRIM(ISNULL(E.FirstName, ''))) + ' ' + LEFT(LTRIM(RTRIM(E.MiddleName)), 1), 45) END AS [Name],
					CASE WHEN E.CountryID = '001' THEN LEFT(LTRIM(RTRIM(ISNULL(E.addr1, ''))), 40) 
							ELSE '' END AS Address1,
					CASE WHEN E.CountryID = '001' THEN LEFT(LTRIM(RTRIM(ISNULL(E.addr2, ''))), 40) 
							ELSE '' END AS Address2,
					CASE WHEN E.CountryID = '001' THEN LEFT(LTRIM(RTRIM(ISNULL(E.city, ''))), 30) 
							ELSE '' END AS City,
					CASE WHEN E.CountryID = '001' THEN LEFT(LTRIM(RTRIM(ISNULL(E.[state], ''))), 2) 
							ELSE '' END AS [State],
					CASE WHEN E.CountryID = '001' THEN LEFT(LTRIM(RTRIM(ISNULL(E.zip, ''))), 5) 
							ELSE '' END AS Zip,
					CASE WHEN E.CountryID <> '001' THEN LEFT(LTRIM(RTRIM(ISNULL(E.addr1, ''))) + ' ' + LTRIM(RTRIM(ISNULL(E.addr2, ''))) + ' ' + LTRIM(RTRIM(ISNULL(E.city, ''))) + ' ' + LTRIM(RTRIM(ISNULL(E.[state], ''))) + ' ' + LTRIM(RTRIM(ISNULL(E.zip, ''))) + ' ' + LTRIM(RTRIM(ISNULL(C.CountryName, ''))), 50)
							ELSE '' END AS International_City_State_Country_Zip,
					LEFT(LTRIM(RTRIM(ISNULL(E.LastName, ''))), 45) AS Name2,
					'' AS Data_Type
		FROM	#MemberPlanYears MPY
		JOIN	Plandata_Prod.dbo.Member M
			ON	MPY.MemberID = M.SecondaryID
		JOIN	Plandata_Prod.dbo.Entity E
			ON	M.EntityID = E.EntID
			AND	E.Addr1 <> ''
			AND E.city <> ''
			AND	E.[State] <> ''
			AND	LEN(LTRIM(RTRIM(E.[State]))) = 2
			AND E.zip <> ''
			AND	LEN(LEFT(LTRIM(RTRIM(ISNULL(E.zip, ''))), 5)) = 5
		JOIN	Plandata_Prod.dbo.Country C
			ON	E.CountryID = C.CountryID
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_0001MasterDeliv REBUILD

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO