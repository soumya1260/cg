CREATE PROCEDURE [EOB].[EOB_Send_Active_Plans] AS
SET XACT_ABORT, NOCOUNT ON
/*
####################################################################################
-- Name:			EOB_Send_Active_Plans.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Rolling counter for EOB File Names
--
-- Called by:		N/A
####################################################################################
-- Parameters
--     N/A
####################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
####################################################################################
*/
BEGIN TRY
	BEGIN TRANSACTION
		IF OBJECT_ID('tempdb.dbo.#ExtractMembers') IS NOT NULL
			DROP TABLE #ExtractMembers
	
		IF OBJECT_ID('tempdb.dbo.#TempKeep') IS NOT NULL
			DROP TABLE #TempKeep

		CREATE TABLE #ExtractMembers (
			Insured_PolicyNumber VARCHAR(20) )

		CREATE TABLE #TempKeep (
			ProcessHeaderID INT,
			ClaimID VARCHAR(30),
			ClaimLineID INT,
			Insured_PolicyNumber VARCHAR(20),
			RecordType VARCHAR(4),
			Claim_Sequence VARCHAR(6),
			CKey VARCHAR(17),
			DocumentID VARCHAR(10),
			DataRow VARCHAR(4000),
			ClaimType CHAR(2),
			[Source] VARCHAR(50) )

		;WITH CTE AS (
			SELECT DISTINCT 
				E02.Insured_PolicyNumber
			FROM	QNXT_Custom.EOB.EOB_0002EOB E02 WITH (NOLOCK)
			JOIN	QNXT_Custom.EOB.EOB_Plans EP WITH (NOLOCK)
				ON	EP.ContractCode = LEFT(LTRIM(RTRIM(E02.MemberPlan)), 5)
				AND EP.PBPCode = RIGHT(LTRIM(RTRIM(E02.MemberPlan)), 3)
				AND	EP.PlanYear = E02.IncurredYear
				AND EP.Active = 1

			UNION ALL
				
			--Blank enrollments
			SELECT DISTINCT 
				E02.Insured_PolicyNumber
			FROM	QNXT_Custom.EOB.EOB_0002EOB E02 WITH (NOLOCK)
			WHERE	E02.MemberPlan = 'DUMMY' )

		INSERT INTO #ExtractMembers ( Insured_PolicyNumber )
		SELECT DISTINCT	
			CTE.Insured_PolicyNumber
		FROM CTE WITH (NOLOCK)

		INSERT INTO #TempKeep ( ProcessHeaderID, ClaimID, ClaimLineID, Insured_PolicyNumber, RecordType, Claim_Sequence, CKey, DocumentID, DataRow, ClaimType, [Source] )
		SELECT
			ProcessHeaderID, 
			ClaimID, 
			ClaimLineID, 
			Insured_PolicyNumber, 
			RecordType, 
			Claim_Sequence, 
			CKey, 
			DocumentID, 
			DataRow, 
			ClaimType, 
			[Source]
		FROM	QNXT_Custom.EOB.EOB_Output AS EO WITH (NOLOCK)
		JOIN	#ExtractMembers EM WITH (NOLOCK)
			ON	EO.Insured_PolicyNumber = EM.Insured_PolicyNumber

		TRUNCATE TABLE QNXT_Custom.EOB.EOB_Output

		INSERT INTO QNXT_Custom.EOB.EOB_Output ( ProcessHeaderID, ClaimID, ClaimLineID, Insured_PolicyNumber, RecordType, Claim_Sequence, CKey, DocumentID, DataRow, ClaimType, [Source] )
			SELECT
				ProcessHeaderID, 
				ClaimID, 
				ClaimLineID, 
				Insured_PolicyNumber, 
				RecordType, 
				Claim_Sequence, 
				CKey, 
				DocumentID, 
				DataRow, 
				ClaimType, 
				[Source]
			FROM #TempKeep

		DROP TABLE #tempKeep
		DROP TABLE #ExtractMembers
	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	THROW;
END CATCH

GO
