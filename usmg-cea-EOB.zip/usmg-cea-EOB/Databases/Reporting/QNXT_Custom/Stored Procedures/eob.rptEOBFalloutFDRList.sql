GO
CREATE PROCEDURE eob.rptEOBFalloutFDRList  (@Source varchar(15) = 'FDR')
	 AS

/*************************************************************************************************************
  TITLE:			rptEOBFalloutFDRList.sql			--Fallout_SSRS_Report
  BUSINESS OWNER:	QNXT Development
  CREATED BY:		Sandie Nantz
  CREATE DATE:		04/01/2019

  DESCRIPTION:		Requested by Kieran

  Modification History: 
  SDE #:        Developer:              Date:                   Desc:
  CM20069439	Sandie Nantz			04/01/2019              User Story 290361: EOB 2.0 - Fallout report request
**************************************************************************************************************/
	BEGIN 
		If NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'eob.FDRList') AND type IN (N'u', N'P', N'PC' ) ) 
				--DROP TABLE QNXT_Custom.eob.FDRList
		BEGIN
			CREATE TABLE QNXT_Custom.EOB.FDRList(FDRDesc varchar(20))
			INSERT INTO QNXT_Custom.EOB.FDRList (FDRDesc)
					values('A2C'),
					('ACCESS2CARE'),
					('ADVOCATE'),
					('AdvocateBar'),
					('ASH_SF'),
					('Aspire'),
					('BLK'),
					('BlockVision'),
					('BP'),
					('CHSProf'),
					('COM'),
					('DAV'),
					('Delta'),
					('DELTADENTAL'),
					('DENTAQUEST'),
					('DQ'),
					('DRYER'),
					('GA_FOODS'),
					('HCSOL'),
					('Kelsey'),
					('LIF'),
					('MED3000'),
					('MedSolutions'),
					('MHN'),
					('MYNEXUS'),
					('NAMM'),
					('NP'),
					('NXT'),
					('OPT'),
					('PROSPECT'),
					('PsychCare'),
					('PWL'),
					('QST'),
					('SD'),
					('SeniorCarePartners'),
					('SILVERSNEAKERS'),
					('SuperiorVision'),
					('Swedish'),
					('UBH'),
					('UNIV_CHI'),
					('WELLMED')
			END

		If @Source = 'FDR' 
			select * from QNXT_Custom.EOB.FDRList
		else
			select 'Only Displayed when Source = FDR' as FDRDesc

End
Go