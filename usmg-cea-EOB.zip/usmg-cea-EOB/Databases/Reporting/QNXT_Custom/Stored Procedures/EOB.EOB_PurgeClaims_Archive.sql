CREATE PROCEDURE [EOB].[EOB_PurgeClaims_Archive] AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_PurgeClaims_Archive.sql
-- Date:			12.19.2018
-- Author:			Subash (subash.chandrasekaram@healthspring.com)
-- Purpose:			Archive all purged claims
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
-- None
###########################################################################################################################################################
-- Ver  User		Date				US#			Change
-- 1.0  Subash      12.19.2018						Initial release
###########################################################################################################################################################
*/
BEGIN TRY
BEGIN TRANSACTION
		
		INSERT INTO QNXT_Custom.EOB.EOB_PurgeClaim_Archive (ProcessHeaderID, Insured_PolicyNumber, ClaimId, Recipient, Check_Number, Check_Amount, Paid_Date, CreateDate)
		SELECT	ProcessHeaderID, Insured_PolicyNumber, ClaimId, Recipient, Check_Number, Check_Amount, Paid_Date, CreateDate
		FROM	EOB.EOB_PurgeClaim
		
COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
