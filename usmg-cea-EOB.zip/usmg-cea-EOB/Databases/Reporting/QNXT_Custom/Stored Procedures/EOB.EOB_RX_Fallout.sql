CREATE PROCEDURE [EOB].[EOB_RX_Fallout] (@ProcessHeaderID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_RX_Fallout.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2	KB			08.01.2019						CM20097013 - Change to not insert dups
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		IF OBJECT_ID('TEMPDB..#RX_Fallout') IS NOT NULL
		DROP TABLE #RX_Fallout

		CREATE TABLE #RX_Fallout 
		(	
			ClaimID VARCHAR(20),
			MemberID VARCHAR(16),
			[Source] VARCHAR(60),
			BeginServiceDate DATE,
			ReasonID INT DEFAULT 0,
			[Status] VARCHAR(10) 
		)

		INSERT INTO #RX_Fallout ( ClaimID, MemberID, [Source], BeginServiceDate, ReasonID, [Status] )
		SELECT DISTINCT ERS.ClaimID, 
						ERS.MemberID,
						ERS.[Source],
						CAST(CONVERT(VARCHAR(8), RXA.BeginServiceDate, 112) AS DATE) AS BeginServiceDate,
						0 AS ReasonID,
						RXA.ClaimStatus
		FROM	QNXT_Custom.EOB.EOB_Run_Staging ERS
		JOIN	QNXT_Custom.EOB.EOB_PartBPharmacy_Archive RXA
			ON	ERS.ClaimID = RXA.ClaimID
			AND	ERS.[Source] = 'RX'
		LEFT JOIN QNXT_Custom.EOB.EOB_Recon ER
			ON	ERS.ClaimID = ER.ClaimID
			AND	ER.[Source] = 'RX'
			AND ER.ProcessHeaderID = @ProcessHeaderID
		LEFT JOIN QNXT_Custom.EOB.EOB_Fallout EF
			ON	ERS.ClaimID = EF.ClaimID
			AND	ERS.[Source] = 'RX'
		WHERE	ER.ClaimID IS NULL
			AND EF.ClaimID IS NULL
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		CREATE CLUSTERED INDEX IDX_RX_Fallout ON #RX_Fallout ( ClaimID ASC, MemberID ASC, [Source] ASC, BeginServiceDate, [Status] ASC )

		UPDATE RXF 
		SET		RXF.ReasonID = CASE	WHEN LTRIM(RTRIM(RXA.ContractCode)) + LTRIM(RTRIM(RXA.PBPCode)) IN ('TX001','TX002','TX003','IL001','IL002','IL003','H6751001','H8423001') AND RXF.ReasonID = 0 THEN 4
									WHEN LTRIM(RTRIM(RXA.ContractCode)) IN ('S1566', 'S5578', 'S5617', 'S5822', 'S5932', 'S5998') AND RXF.ReasonID = 0 THEN 5
									WHEN (LTRIM(RTRIM(RXA.ContractCode)) + LTRIM(RTRIM(RXA.PBPCode)) IN ('H5410001', 'H5410807') OR RXA.ContractCode = 'H0354') AND RXF.ReasonID = 0 THEN 11									 
									WHEN RXF.MemberID IN ('00000001', '') AND RXF.ReasonID = 0 THEN 8
									WHEN M.MemID IS NULL AND RXF.ReasonID = 0 THEN 12
									WHEN EM.MemberID IS NOT NULL AND RXF.ReasonID = 0 THEN 9
									WHEN EP.ContractCode IS NULL AND RXF.ReasonID = 0 THEN 10
									WHEN E.EntID IS NULL AND RXF.ReasonID = 0 THEN 13
									WHEN EP.Copay = '' AND EP.CoInsurance = '' AND EP.Deductible = '' THEN 14
									ELSE 0 END		
		FROM	#RX_Fallout RXF
		JOIN	QNXT_Custom.EOB.EOB_PartBPharmacy_Archive RXA
			ON	RXF.ClaimID = RXA.ClaimID
		LEFT JOIN	Plandata_Prod.dbo.Member M
			ON	RXF.MemberID = M.secondaryid
		LEFT JOIN	Plandata_Prod.dbo.Entity E
			ON	M.EntityID = E.EntID
			AND	E.Addr1 <> ''
			AND E.city <> ''
			AND	E.[State] <> ''
			AND	LEN(LTRIM(RTRIM(E.[State]))) = 2
			AND E.zip <> ''
			AND	LEN(LEFT(LTRIM(RTRIM(ISNULL(E.zip, ''))), 5)) = 5
		LEFT JOIN	Plandata_Prod.dbo.EnrollKeys EK
			ON	M.MemID = EK.MemID
			AND	EK.SegType = 'INT'
			AND	RXF.BeginServiceDate BETWEEN EK.EffDate AND EK.TermDate
		LEFT JOIN	Plandata_Prod.dbo.BenefitPlan BP
			ON	EK.PlanID = BP.PlanID
		LEFT JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	RXA.ContractCode = EP.ContractCode
			AND RXA.PBPCode = EP.PBPCode
			AND	YEAR(RXF.BeginServiceDate) = EP.PlanYear
			AND (EP.GroupPlanID = '' OR EK.planid = EP.GroupPlanID)
			AND EP.Active = 1
		LEFT JOIN	QNXT_Custom.EOB.EOB_MOOP EM
			ON	RXF.MemberID = EM.MemberID
			AND	LTRIM(RTRIM(RXA.ContractCode)) + LTRIM(RTRIM(RXA.PBPCode)) = EM.UPID
			AND	LEFT(RXA.BeginServiceDate, 4) = LEFT(EM.MinMemberEffectiveDate, 4)
			AND RXA.BeginServiceDate > EM.MaxMemberEffectiveDate
		WHERE	RXF.ReasonID = 0
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		INSERT INTO QNXT_Custom.EOB.EOB_Fallout ( ClaimType, ClaimID, MemberID, ReasonID, [Source], ProcessHeaderID )
		SELECT DISTINCT	'RX' AS ClaimType,
						RXF.ClaimID,
						RXF.MemberID,
						RXF.ReasonID,
						RXF.[Source] AS [Source],
						@ProcessHeaderID AS ProcessHeaderID
		FROM    #RX_Fallout RXF
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_Fallout REBUILD

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO