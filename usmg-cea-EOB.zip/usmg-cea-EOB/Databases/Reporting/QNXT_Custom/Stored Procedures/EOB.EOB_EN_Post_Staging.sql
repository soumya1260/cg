CREATE PROCEDURE [EOB].[EOB_EN_Post_Staging] (@BeginDate DATE, @EndDate DATE, @ProcessHeaderID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_EN_Post_Staging.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Stage EN data for EOB runs - Post scripts
--
-- Called by:		NA
###########################################################################################################################################################
-- Parameters
--     
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			08.23.2018			215695		Updated logic to update member's first and last names for encounters (CM20027392)
-- 1.3  KB			09.04.2018			215695		Deleting claims without claim lines (CM20029812)
-- 1.4	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
-- 1.5	KCO			11.19.2018			203786		Updated EOB_Claim insert so that Dual members are appropriately given preference to their Part B plan
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		IF OBJECT_ID('tempdb.dbo.#ClaimsToDelete') IS NOT NULL
			DROP TABLE #ClaimsToDelete

		--Update ContractCode and PBPCode on EOB_Claim
		UPDATE EC SET
			EC.ContractCode = LEFT(LTRIM(RTRIM(BP.UPID)), 5),
			EC.PBPCode = CASE WHEN LEN(LTRIM(RTRIM(BP.UPID))) = 9 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 4)
								ELSE RIGHT(LTRIM(RTRIM(BP.UPID)), 3) END,
			EC.QNXTPlanID = BP.PlanID			
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	Plandata_Prod.dbo.Member M
			ON	EC.MemberID = M.SecondaryID
			AND EC.ClaimType = 'EN'
		JOIN	Plandata_Prod.dbo.Enrollkeys EK
			ON	M.MemID = EK.MemID
			AND	EC.BeginServiceDate BETWEEN EK.EffDate AND EK.TermDate
			AND EK.SegType = 'INT'
		JOIN	Plandata_Prod.dbo.BenefitPlan BP
			ON	EK.PlanID = BP.PlanID
		JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	LTRIM(RTRIM(BP.UPID)) = RTRIM(EP.ContractCode) + RTRIM(EP.PBPCode)
			AND	YEAR(EC.BeginServiceDate) = EP.PlanYear
			AND (EP.GroupPlanID = '' OR EK.planid = EP.GroupPlanID)
			AND EP.Active = 1
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		UPDATE	EC SET
			EC.Is_PartD = EP.IsPartD
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	EC.ContractCode = EP.ContractCode
			AND	EC.PBPCode = EP.PBPCode
			AND YEAR(EC.BeginServiceDate) = EP.PlanYear
			AND (EP.GroupPlanID = '' OR EC.QNXTPlanID = EP.GroupPlanID)
			AND EP.Active = 1			
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		UPDATE	EC SET
			EC.MemberID = MC.strNewSecondaryID
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	QNXT_Custom.EOB.MemberID_Changes MC
			ON	EC.MemberID = MC.strPreviousSecondaryID
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Delete plans that aren't in Contract Dim table
		CREATE TABLE #ClaimsToDelete ( ClaimID VARCHAR(30),
										MemberID VARCHAR(20), 
										[Source] VARCHAR(60) )

		INSERT INTO #ClaimsToDelete
		SELECT DISTINCT
				EC.ClaimID,
				EC.MemberID,
				EC.[Source]
		FROM		QNXT_Custom.EOB.EOB_Claim EC
		LEFT JOIN	QNXT_Custom.EOB.EOB_Plans EP
				ON	EC.ContractCode = EP.ContractCode 
				AND EC.PBPCode = EP.PBPCode
				AND	YEAR(EC.BeginServiceDate) = EP.PlanYear
				AND (EP.GroupPlanID = '' OR EC.QNXTPlanID = EP.GroupPlanID) 
				AND EP.Active = 1				
		WHERE EP.ContractCode IS NULL
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Delete plans that have all three flags Copay, CoInsurance and Deductible set to blank
		INSERT INTO #ClaimsToDelete
		SELECT DISTINCT
			EC.ClaimID,
			EC.MemberID,
			EC.[Source]
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	EC.ContractCode = EP.ContractCode 
			AND EC.PBPCode = EP.PBPCode
			AND	YEAR(EC.BeginServiceDate) = EP.PlanYear
			AND (EP.GroupPlanID = '' OR EC.QNXTPlanID = EP.GroupPlanID)
			AND EP.Active = 1			
		WHERE	EP.Copay = '' 
			AND EP.CoInsurance = '' 
			AND EP.Deductible = ''
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Delete claims without claim lines
		INSERT INTO #ClaimsToDelete
		SELECT DISTINCT 
			EC.ClaimID,
			EC.MemberID,
			EC.[Source]
		FROM		QNXT_Custom.EOB.EOB_Claim EC
		LEFT JOIN	QNXT_Custom.EOB.EOB_ClaimDetail ECD
				ON	EC.ClaimID = ECD.ClaimID
				AND EC.[Source] = ECD.[Source]
		WHERE ECD.ClaimID IS NULL
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		DELETE ECD
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	#ClaimsToDelete X
			ON	ECD.ClaimID = X.ClaimID
			AND	ECD.[Source] = X.[Source]
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		DELETE EC
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	#ClaimsToDelete X
			ON	EC.ClaimID = X.ClaimID
			AND	EC.MemberID = X.MemberID
			AND	EC.[Source] = X.[Source]
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Update remaining claims in EOB_Claim that have a blank ContractCode to be HDUMMY
		UPDATE EC SET 
			EC.ContractCode = 'DUMMY',
			EC.PlanType = 'HMO'
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		WHERE EC.ContractCode = ''
			AND EC.PBPCode = ''
			AND	EC.ClaimType = 'EN'
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Update PlanType on EOB_Claim so we can set FormLetterID
		UPDATE EC SET
			EC.PlanType = EP.PlanType
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	EC.ContractCode = EP.ContractCode
			AND EC.PBPCode = EP.PBPCode
			AND YEAR(BeginServiceDate) = EP.PlanYear
			AND (EP.GroupPlanID = '' OR EC.QNXTPlanID = EP.GroupPlanID)
			AND EP.Active = 1			
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		UPDATE EC SET
			EC.ClaimType = 'SU'
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	QNXT_Custom.EOB.EOB_ClaimDetail ECD
			ON	EC.ClaimID = ECD.ClaimID
			AND	EC.[Source] = ECD.[Source]
			AND EC.[Source] IN ('BLOCKVISION', 'DENTAQUEST', 'DELTADENTAL', 'SUPERIORVISION' )
		JOIN	QNXT_Custom.EOB.EOB_OptSup_Plan OSP
			ON	EC.ContractCode + EC.PBPCode = OSP.UPID
			AND	YEAR(EC.BeginServiceDate) = OSP.[Year]
			AND	ECD.Procedure_Code = OSP.ServCode
		JOIN	Plandata_Prod.dbo.Member M
			ON	EC.MemberID = M.SecondaryID
			AND EC.ClaimType = 'EN'
		JOIN	Plandata_Prod.dbo.Enrollkeys EK
			ON	M.MemID = EK.MemID
			AND	EC.BeginServiceDate BETWEEN EK.EffDate AND EK.TermDate
			AND EK.SegType = 'INT'
		JOIN	Plandata_Prod.dbo.BenefitPlan BP
			ON	EK.PlanID = BP.PlanID
		JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	LTRIM(RTRIM(BP.UPID)) = RTRIM(EP.ContractCode) + RTRIM(EP.PBPCode)
			AND	YEAR(EC.BeginServiceDate) = EP.PlanYear
			AND (EP.GroupPlanID = '' OR EK.planid = EP.GroupPlanID)
			AND EP.Active = 1
		JOIN	Plandata_Prod.dbo.Enrollcoverage ECV
			ON	EK.EnrollID = ECV.EnrollID
			AND	EC.BeginServiceDate BETWEEN ECV.EffDate AND ECV.TermDate
			AND	ECV.CoverageCodeID LIKE '%Opt%'
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Update member's first and last names
		UPDATE EC SET
			EC.MemberFirstName = E.FirstName,
			EC.MemberLastName = E.LastName
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	Plandata_Prod.dbo.Member M
			ON	EC.MemberID = M.SecondaryID
		JOIN	Plandata_Prod.dbo.entity E
			ON	M.EntityID = E.EntID
		WHERE	EC.ClaimType IN ('EN', 'SU')
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
