CREATE PROCEDURE [EOB].[EOB_Rx_Staging] (@BeginDate DATE, @EndDate DATE,  @ProcessHeaderID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Rx_Staging.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Stage Rx data for EOB runs
--
-- Called by:		NA
###########################################################################################################################################################
-- Parameters
--     
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			07.16.2018			215695		Update to type cast all date fields appropriately (CM20019801)
-- 1.3  KB			09.04.2018			215695		Added staging of Allowed and Balance fields (CM20029812)
-- 1.4	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
-- 1.5	KCO			11.19.2018			203786		Updated EOB_Claim insert so that Dual members are appropriately given preference to their Part B plan
-- 1.6	Subash		11.20.2018			203786		Updated to get first enrollment due to inavlid enrollment data in QNXT
-- 1.7	KB			08.01.2019						CM20097013 - Removed coins%
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
BEGIN TRANSACTION
	
	;WITH CTE AS
	(
		SELECT  RX.[ClaimID] AS [ClaimID],
				CASE WHEN LTRIM(RTRIM(LEN(RX.[MemberID]))) > 10 AND LEFT(LTRIM(RTRIM(RX.[MemberID])), 1) <> 'U' THEN STUFF(LTRIM(RTRIM(RX.[MemberID])), LEN(LTRIM(RTRIM(RX.[MemberID]))) - 1, 0, '*')
						ELSE LTRIM(RTRIM(RX.[MemberID])) END AS [MemberID],			
				RX.[ContractCode] AS [ContractCode],
				RX.[PBPCode] AS [PBPCode],
				RX.[ProviderID] AS [ProviderID],
				RX.[ProviderName] AS [ProviderName],
				RX.[ClaimStatus] AS [ClaimStatus],
				CAST(CONVERT(VARCHAR(10), RX.[PaidDate], 112) AS DATE) AS [PaidDate],
				RX.ApprovedAmount AS PaidAmount,
				CAST(CONVERT(VARCHAR(10), RX.[BeginServiceDate], 112) AS DATE) AS [BeginServiceDate],
				CAST(CONVERT(VARCHAR(10), RX.[EndServiceDate], 112) AS DATE) AS [EndServiceDate],
				RX.[Active] AS [Active],
				CAST(CONVERT(VARCHAR(10), RX.[LoadDate], 112) AS DATE) AS [LoadDate],
				CAST(CONVERT(VARCHAR(10), RX.[LastUpdateKey], 112) AS DATE) AS [LastUpdate]
		FROM	EOB.EOB_PartBPharmacy_Archive RX
		WHERE	RX.Active = 1	
			AND CONVERT(CHAR(8), RX.PaidDate, 120) BETWEEN @BeginDate AND @EndDate
		 )
	INSERT INTO QNXT_Custom.EOB.EOB_Claim ( ProcessHeaderID, ClaimID, MemberID, MemberFirstName, MemberLastName, ContractCode, PBPCode, ProviderID, ProviderName, ClaimStatus, 
											PaidDate, PaidAmount, BeginServiceDate, EndServiceDate, LoadDate, Par_Ind, Denial_Language_Ind, CreateDate, LastUpdate, Is_PartD, [Source], ClaimType, QNXTPlanID )
	SELECT	DISTINCT
			@ProcessHeaderID,
			CTE.[ClaimID] AS [ClaimID],
			CAST(CTE.[MemberID] AS VARCHAR(20)) AS [MemberID],
			E.FirstName AS [MemberFirstName],
			E.LastName AS [MemberLastName],
			CTE.[ContractCode] AS [ContractCode],
			CTE.[PBPCode] AS [PBPCode],
			CTE.[ProviderID] AS [ProviderID],
			CTE.[ProviderName] AS [ProviderName],
			CTE.[ClaimStatus] AS [ClaimStatus],
			CTE.[PaidDate] AS [PaidDate],
			CTE.PaidAmount,
			CTE.[BeginServiceDate] AS [BeginServiceDate],
			CTE.[EndServiceDate] AS [EndServiceDate],
			CTE.[LoadDate],
			'P' AS [Par_Ind],
			'' AS [Denial_Language_Ind],
			GETDATE() AS [CreateDate],
			GETDATE() AS [LastUpdate],
			'N' AS [IsPartD],
			'RX' AS [Source],
			'RX' AS [ClaimType],
			BP.PlanID AS QNXTPlanID
	FROM	CTE
	JOIN	Plandata_Prod.[dbo].[member] M
		ON	CTE.[MemberID] = M.[secondaryid]
	JOIN	Plandata_Prod.dbo.entity E
		ON	M.Entityid = E.Entid
	JOIN	QNXT_Custom.EOB.EOB_Run_Staging ERS
		ON CTE.[ClaimID] = ERS.[ClaimID]
		AND ERS.[Source] = 'RX'
		AND ERS.IsValid = 'Y'
	CROSS APPLY	(SELECT EK.enrollid, EK.memid, BP.planid, ROW_NUMBER() OVER (PARTITION BY ek.memid ORDER BY ek.createdate) AS rn
			FROM Plandata_Prod.dbo.Enrollkeys EK
		JOIN	Plandata_Prod.dbo.BenefitPlan BP
			ON	EK.PlanID = BP.PlanID
		JOIN	QNXT_Custom.EOB.EOB_Plans EP
				ON	LTRIM(RTRIM(BP.UPID)) = RTRIM(EP.ContractCode) + RTRIM(EP.PBPCode)
				AND (EP.GroupPlanID = '' OR EK.planid = EP.GroupPlanID)				
				AND EP.Active = 1
		WHERE M.MemID = EK.MemID
			AND	CTE.[BeginServiceDate] BETWEEN EK.EffDate AND EK.TermDate
			AND EK.SegType = 'INT'
			AND	YEAR(CTE.BeginServiceDate) = EP.PlanYear
			) BP
	WHERE	ISNULL(BP.PlanID, '') <> '' AND BP.rn = 1
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	ALTER INDEX ALL ON EOB.EOB_Claim REBUILD

	INSERT INTO QNXT_Custom.EOB.EOB_ClaimDetail ( ProcessHeaderID, ClaimID, ClaimLine, ClaimLineStatus, ClaimType, BeginServiceDate, EndServiceDate, PaidDate, BilledAmount, Eligible, Allowed, DeductibleAmount, 
												CopayAmount, CoinsuranceAmount, PaidAmount, Rx_NDC, Rx_NDCDesc, Rx_TDC, Rx_PatientPay, Rx_OtherPay, CreateDate, LastUpdate, Balance, Coinsurance_Percentage, Is_Capitated, [Source] )
	SELECT	DISTINCT
			@ProcessHeaderID,
			EC.[ClaimID] AS [ClaimID],
			1 AS [ClaimLine],
			EC.[ClaimStatus] AS [ClaimLineStatus],
			EC.[ClaimType],	
			EC.[BeginServiceDate],
			EC.[EndServiceDate],
			EC.[PaidDate],
			RX.[BilledAmount] AS [BilledAmount],
			RX.[ApprovedAmount] + RX.[CopayAmount] + RX.[CoinsuranceAmount] + RX.[DeductibleAmount] AS [Eligible],
			RX.[ApprovedAmount] + RX.[CopayAmount] + RX.[CoinsuranceAmount] + RX.[DeductibleAmount] AS [Allowed],
			RX.[DeductibleAmount] AS [DeductibleAmount],
			RX.[CopayAmount] AS [CopayAmount],
			RX.[CoinsuranceAmount] AS [CoinsuranceAmount],
			RX.[ApprovedAmount] AS [PaidAmount],
			RX.[NDC] AS [Rx_NDC],
			RX.[NDCDesc] AS [Rx_NDCDesc],
			RX.[TDC] AS [Rx_TDC],
			RX.[PatientPay] AS [Rx_PatientPay],
			RX.[OtherPay] AS [Rx_OtherPay],
			EC.CreateDate,
			EC.[LastUpdate],
			RX.[ApprovedAmount] AS [Balance],
			0.00 AS Coinsurance_Percentage,
			'N' AS Is_Capitated,
			'RX' AS [Source]
	FROM	QNXT_Custom.EOB.EOB_Claim EC
	JOIN	QNXT_Custom.EOB.EOB_PartBPharmacy_Archive RX
		ON	EC.[ClaimID] = RX.[ClaimID]
		AND EC.[ClaimStatus] = RX.[ClaimStatus]
		AND EC.[Source] = 'RX'
	JOIN	QNXT_Custom.EOB.EOB_Run_Staging ERS
		ON	EC.[ClaimID] = ERS.[ClaimID]
		AND ERS.[Source] = 'RX'
		AND ERS.IsValid = 'Y'
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	ALTER INDEX ALL ON EOB.EOB_ClaimDetail REBUILD

COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO