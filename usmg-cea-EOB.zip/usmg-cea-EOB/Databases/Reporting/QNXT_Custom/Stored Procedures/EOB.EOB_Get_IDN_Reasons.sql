CREATE PROCEDURE [EOB].[EOB_Get_IDN_Reasons] AS
SET XACT_ABORT, NOCOUNT ON
/*
####################################################################################
-- Name:			EOB_Get_IDN_Reasons.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Stored Procedure to get IDN Denial Reasons
--
-- Called by:		NA
####################################################################################
-- Parameters
--     
####################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
####################################################################################
*/ 
BEGIN TRY
	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[idn].[Idn_XDenialReasons]') AND type in (N'U'))
		BEGIN
			SELECT	MessageID, 
					[Status],
					Par,
					NonPar
			FROM	QNXT_Custom.idn.Idn_XDenialReasons X WITH (NOLOCK)
			WHERE	GETDATE() BETWEEN X.EffDate AND X.TermDate
		END
	ELSE
		BEGIN
			SELECT	DL.QNXT_Code AS MessageID, 
					DL.[Status],
					DL.Par, 
					DL.NonPar 
			FROM EHI.dbo.tblABF_EOBMember_DenialLanguage DL WITH (NOLOCK)
			WHERE DL.[Enable] = 1
		END
END TRY

BEGIN CATCH
	THROW;
END CATCH

GO
