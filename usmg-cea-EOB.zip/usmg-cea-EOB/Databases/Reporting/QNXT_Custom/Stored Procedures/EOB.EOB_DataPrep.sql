CREATE PROCEDURE [EOB].[EOB_DataPrep] (@BeginDate DATETIME, @EndDate DATETIME, @Is_LateSub CHAR(1), @Is_Regen CHAR(1), @RunRequestID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
#######################################################################################################################################################
-- Name:			EOB_DataPrep.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
#######################################################################################################################################################
-- Parameters
--     N/A
#######################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.06.2018			215695		Converted Begin and End dates to integers for Rx data prep (CM20018233)
-- 1.2  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.3  KB			07.26.2018			215695		Updated logic to accurately read claims when run using the regen flag (CM20022379)
-- 1.1	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
#######################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
  
		IF @Is_LateSub = 'N' AND @Is_Regen = 'N'
		BEGIN
			--QNXT claims 
			;WITH CTE AS
			(
								SELECT	DISTINCT 
									C.ClaimID AS ClaimID, 
									M.SecondaryID AS MemberID
								FROM	Plandata_Prod.dbo.Claim C
								JOIN	Plandata_Prod.dbo.Member M
									ON	C.MemID = M.MemID
								LEFT JOIN QNXT_Custom.EOB.EOB_Recon ER
									ON C.ClaimID = ER.ClaimID									
								WHERE C.PaidDate BETWEEN @BeginDate AND @EndDate
									AND C.[Status] IN ('PAID', 'DENIED', 'REVERSED')
									AND ER.ClaimID IS NULL
			)
			INSERT INTO QNXT_Custom.EOB.EOB_Run_Staging ( RunRequestID, ClaimID, MemberID, [Source] )
			SELECT	DISTINCT
						@RunRequestID AS RunRequestID,
						CTE.ClaimID,
						CTE.MemberID,
						'CL' AS [Source]
			FROM		CTE 
			LEFT JOIN	(
								SELECT  DISTINCT 
									CE.ClaimID AS ClaimID,
									M.SecondaryID AS MemberID
								FROM	Plandata_Prod.dbo.Claim C
								JOIN	Plandata_Prod.dbo.Member M
									ON	C.MemID = M.MemID
								JOIN	Plandata_Prod.dbo.ClaimEdit CE
									ON	C.ClaimID = CE.ClaimID
								JOIN	QNXT_Custom.EOB.EOB_ExcludedDenialRemits EDR
									ON  EDR.Active = 1
									AND ((CE.Reason = EDR.ReasonID)
										OR (CE.EobID = EDR.ReasonID))
								WHERE	C.PaidDate BETWEEN @BeginDate AND @EndDate
									AND C.[Status] = 'DENIED'
						) CE
				ON	CTE.ClaimID = CE.ClaimID
				AND	CTE.MemberID = CE.MemberID
			LEFT JOIN	(
								SELECT  DISTINCT 
									CEM.ClaimID AS ClaimID,
									M.SecondaryID AS MemberID
								FROM	Plandata_Prod.dbo.Claim C
								JOIN	Plandata_Prod.dbo.Member M
									ON	C.memid = M.memid
								JOIN	Plandata_Prod.dbo.ClaimEditMessage CEM
									ON	C.ClaimID = CEM.ClaimID								
								JOIN	QNXT_Custom.EOB.EOB_ExcludedDenialRemits EDR
									ON  EDR.Active = 1
									AND CEM.MessageID = EDR.ReasonID
								WHERE	C.PaidDate BETWEEN @BeginDate AND @EndDate
									AND C.[Status] = 'DENIED'
						) CEM
				ON	CTE.ClaimID = CE.ClaimID
				AND	CTE.MemberID = CE.MemberID
			WHERE	CE.ClaimID IS NULL
				AND	CEM.ClaimID IS NULL
			OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
			
			--Rx
			INSERT INTO QNXT_Custom.EOB.EOB_Run_Staging ( RunRequestID, ClaimID, MemberID, [Source] )
			SELECT DISTINCT 
					@RunRequestID AS RunRequestID,
					RX.ClaimID AS ClaimID,
					CASE WHEN LTRIM(RTRIM(LEN(RX.MemberID))) > 10 AND LEFT(LTRIM(RTRIM(RX.MemberID)), 1) <> 'U' THEN STUFF(LTRIM(RTRIM(RX.MemberID)), LEN(LTRIM(RTRIM(RX.MemberID))) - 1, 0, '*')
							ELSE LTRIM(RTRIM(RX.MemberID)) END AS MemberID,
					'RX' AS [Source]
			FROM		QNXT_Custom.EOB.EOB_PartBPharmacy_Archive Rx
			LEFT JOIN	QNXT_Custom.EOB.EOB_Recon ER
					ON	Rx.ClaimID = ER.ClaimID
			WHERE  Rx.PaidDate BETWEEN CONVERT(INT, CONVERT(VARCHAR(8), @BeginDate, 112)) AND CONVERT(INT, CONVERT(VARCHAR(8), @EndDate, 112))
					AND ER.ClaimID IS NULL
			OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		END

		IF @Is_LateSub = 'Y' AND @Is_Regen = 'N'
		BEGIN
			--QNXT claims 
			;WITH CTE AS
			(
								SELECT	DISTINCT 
									C.ClaimID AS ClaimID, 
									M.SecondaryID AS MemberID
								FROM	Plandata_Prod.dbo.Claim C
								JOIN	Plandata_Prod.dbo.Member M
									ON	C.MemID = M.MemID
								LEFT JOIN QNXT_Custom.EOB.EOB_Recon ER
									ON C.ClaimID = ER.ClaimID									
								LEFT JOIN QNXT_Custom.EOB.EOB_Fallout EF
									ON C.ClaimID = EF.ClaimID
									AND EF.ClaimType = 'CL'
								LEFT JOIN QNXT_Custom.EOB.EOB_Fallout_Reason EFR
													ON EF.ClaimType = EFR.ClaimType
													AND EF.ReasonID = EFR.ReasonID
													AND EFR.Is_Valid = 1
								LEFT JOIN QNXT_Custom.EOB.EOB_Fallout_Archive EFA
													ON C.ClaimID = EFA.ClaimID
													AND EFA.ClaimType = 'CL'
								LEFT JOIN QNXT_Custom.EOB.EOB_Fallout_Reason EFR2
													ON EFA.ClaimType = EFR2.ClaimType
													AND EFA.ReasonID = EFR2.ReasonID
													AND EFR2.Is_Valid = 1
								WHERE C.PaidDate BETWEEN @BeginDate AND @EndDate
									AND C.[Status] IN ('PAID', 'DENIED', 'REVERSED')
									AND ER.ClaimID IS NULL
									AND EFR.ClaimType IS NULL
									AND EFR2.ClaimType IS NULL
			)
			INSERT INTO QNXT_Custom.EOB.EOB_Run_Staging ( RunRequestID, ClaimID, MemberID, [Source] )
			SELECT	DISTINCT
						@RunRequestID AS RunRequestID,
						CTE.ClaimID,
						CTE.MemberID,
						'CL' AS [Source]
			FROM		CTE 
			LEFT JOIN	(
								SELECT  DISTINCT 
									CE.ClaimID AS ClaimID,
									M.SecondaryID AS MemberID
								FROM	Plandata_Prod.dbo.Claim C
								JOIN	Plandata_Prod.dbo.Member M
									ON	C.MemID = M.MemID
								JOIN	Plandata_Prod.dbo.ClaimEdit CE
									ON	C.ClaimID = CE.ClaimID
								JOIN	QNXT_Custom.EOB.EOB_ExcludedDenialRemits EDR
									ON  EDR.Active = 1
									AND ((CE.Reason = EDR.ReasonID)
										OR (CE.EobID = EDR.ReasonID))
								WHERE	C.PaidDate BETWEEN @BeginDate AND @EndDate
									AND C.[Status] = 'DENIED'
						) CE
				ON	CTE.ClaimID = CE.ClaimID
				AND	CTE.MemberID = CE.MemberID
			LEFT JOIN	(
								SELECT  DISTINCT 
									CEM.ClaimID AS ClaimID,
									M.SecondaryID AS MemberID
								FROM	Plandata_Prod.dbo.Claim C
								JOIN	Plandata_Prod.dbo.Member M
									ON	C.memid = M.memid
								JOIN	Plandata_Prod.dbo.ClaimEditMessage CEM
									ON	C.ClaimID = CEM.ClaimID								
								JOIN	QNXT_Custom.EOB.EOB_ExcludedDenialRemits EDR
									ON  EDR.Active = 1
									AND CEM.MessageID = EDR.ReasonID
								WHERE	C.PaidDate BETWEEN @BeginDate AND @EndDate
									AND C.[Status] = 'DENIED'
						) CEM
				ON	CTE.ClaimID = CE.ClaimID
				AND	CTE.MemberID = CE.MemberID
			WHERE	CE.ClaimID IS NULL
				AND	CEM.ClaimID IS NULL
			OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

			--Rx
			INSERT INTO QNXT_Custom.EOB.EOB_Run_Staging ( RunRequestID, ClaimID, MemberID, [Source] )
			SELECT DISTINCT @RunRequestID AS RunRequestID,
							RX.ClaimID AS ClaimID,
							CASE WHEN LTRIM(RTRIM(LEN(RX.MemberID))) > 10 AND LEFT(LTRIM(RTRIM(RX.MemberID)), 1) <> 'U' THEN STUFF(LTRIM(RTRIM(RX.MemberID)), LEN(LTRIM(RTRIM(RX.MemberID))) - 1, 0, '*')
								ELSE LTRIM(RTRIM(RX.MemberID)) END AS MemberID,
							'RX' AS [Source]
			FROM		QNXT_Custom.EOB.EOB_PartBPharmacy_Archive Rx
			LEFT JOIN	QNXT_Custom.EOB.EOB_Fallout EF
					ON	Rx.ClaimID = EF.ClaimID
					AND EF.ClaimType = 'RX'
			LEFT JOIN	QNXT_Custom.EOB.EOB_Fallout_Reason EFR
					ON	EF.ClaimType = EFR.ClaimType
					AND EF.ReasonID = EFR.ReasonID
					AND EFR.Is_Valid = 1
			LEFT JOIN	QNXT_Custom.EOB.EOB_Fallout_Archive EFA
					ON	Rx.ClaimID = EFA.ClaimID
					AND EFA.ClaimType = 'RX'
			LEFT JOIN	QNXT_Custom.EOB.EOB_Fallout_Reason EFR2
					ON	EFA.ClaimType = EFR2.ClaimType
					AND EFA.ReasonID = EFR2.ReasonID
					AND EFR2.Is_Valid = 1
			LEFT JOIN	QNXT_Custom.EOB.EOB_Recon ER
					ON	Rx.ClaimID = ER.ClaimID
			WHERE  Rx.PaidDate BETWEEN CONVERT(INT, CONVERT(VARCHAR(8), @BeginDate, 112)) AND CONVERT(INT, CONVERT(VARCHAR(8), @EndDate, 112))
					AND ER.ClaimID IS NULL
					AND EFR.ClaimType IS NULL
					AND EFR2.ClaimType IS NULL
			OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
	
		END

		IF @Is_Regen = 'Y'
		BEGIN
			--All claims 
			;WITH CTE AS
			(
				SELECT DISTINCT	
						RD.ClaimID,
						RD.MemberID,
						RD.[Source]
				FROM	QNXT_Custom.EOB.EOB_Run_Detail RD
			)
			INSERT INTO QNXT_Custom.EOB.EOB_Run_Staging ( RunRequestID, ClaimID, MemberID, [Source] )
			SELECT DISTINCT	@RunRequestID AS RunRequestID,
							CTE.ClaimID AS ClaimID,
							CTE.MemberID AS MemberID,
							CTE.[Source] AS [Source]
			FROM	CTE
			LEFT JOIN	(
								SELECT  DISTINCT 
									CE.ClaimID AS ClaimID,
									M.SecondaryID AS MemberID
								FROM	Plandata_Prod.dbo.Claim C
								JOIN	Plandata_Prod.dbo.Member M
									ON	C.MemID = M.MemID
								JOIN	Plandata_Prod.dbo.ClaimEdit CE
									ON	C.ClaimID = CE.ClaimID
								JOIN	QNXT_Custom.EOB.EOB_ExcludedDenialRemits EDR
									ON  EDR.Active = 1
									AND ((CE.Reason = EDR.ReasonID)
										OR (CE.EobID = EDR.ReasonID))
								WHERE	C.[Status] = 'DENIED'
						) CE
				ON	CTE.ClaimID = CE.ClaimID
				AND	CTE.MemberID = CE.MemberID
			LEFT JOIN	(
								SELECT  DISTINCT 
									CEM.ClaimID AS ClaimID,
									M.SecondaryID AS MemberID
								FROM	Plandata_Prod.dbo.Claim C
								JOIN	Plandata_Prod.dbo.Member M
									ON	C.memid = M.memid
								JOIN	Plandata_Prod.dbo.ClaimEditMessage CEM
									ON	C.ClaimID = CEM.ClaimID								
								JOIN	QNXT_Custom.EOB.EOB_ExcludedDenialRemits EDR
									ON  EDR.Active = 1
									AND CEM.MessageID = EDR.ReasonID
								WHERE	C.[Status] = 'DENIED'
						) CEM
				ON	CTE.ClaimID = CE.ClaimID
				AND	CTE.MemberID = CE.MemberID
			WHERE	CE.ClaimID IS NULL
				AND	CEM.ClaimID IS NULL
			OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		END

		UPDATE	ERS
			SET	ERS.IsValid = 'N'		
		FROM	QNXT_Custom.EOB.EOB_Run_Staging ERS
		JOIN	Plandata_Prod.dbo.Claim C
			ON	ERS.ClaimID = C.ClaimID
			AND	ERS.[Source] = 'CL'
			AND C.[Status] IN ( 'PAID', 'DENIED', 'REVERSED' )
		JOIN	Plandata_Prod.dbo.EnrollKeys EK
			ON	C.EnrollID = EK.EnrollID
		JOIN	Plandata_Prod.dbo.BenefitPlan BP
			ON	EK.PlanID = BP.PlanID
		LEFT JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	LEFT(LTRIM(RTRIM(BP.UPID)), 5) = EP.ContractCode 
			AND CASE WHEN LEN(LTRIM(RTRIM(BP.UPID))) = 9 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 4)
					ELSE RIGHT(LTRIM(RTRIM(BP.UPID)), 3) END = EP.PBPCode
			AND	YEAR(C.StartDate) = EP.PlanYear
			AND (EP.GroupPlanID = '' OR BP.PlanID = EP.GroupPlanID) 
			AND EP.Active = 1
		WHERE	EP.ContractCode IS NULL
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		UPDATE	ERS
			SET	ERS.IsValid = 'N'		
		FROM	QNXT_Custom.EOB.EOB_Run_Staging ERS
		JOIN	QNXT_Custom.EOB.EOB_PartBPharmacy_Archive RX
			ON	ERS.ClaimID = RX.ClaimID
			AND	ERS.[Source] = 'RX'
		LEFT JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	LTRIM(RTRIM(RX.ContractCode)) = EP.ContractCode 
			AND LTRIM(RTRIM(RX.PBPCode)) = EP.PBPCode
			AND	LEFT(RX.BeginServiceDate, 4) = EP.PlanYear			
			AND EP.Active = 1
		WHERE	EP.ContractCode IS NULL
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
