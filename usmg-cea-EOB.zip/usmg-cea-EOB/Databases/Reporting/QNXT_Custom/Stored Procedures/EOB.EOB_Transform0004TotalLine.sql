CREATE PROCEDURE [EOB].[EOB_Transform0004TotalLine] (@BeginDate DATE, @EndDate DATE, @ProcessHeaderID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Transform0004TotalLine.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			08.13.2018			215695		Updated logic to set the appropriate values on open fields 6 and 7 (CM20025799)
-- 1.3  KB			08.23.2018			215695		Removed execution of data validation SP. The package has a new task to execute that SP (CM20027392)
-- 1.4	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
###########################################################################################################################################################
*/

TRUNCATE TABLE EOB.EOB_0004TotalLine

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		INSERT INTO [EOB].[EOB_0004TotalLine] ( ProcessHeaderID, Claim_Number, ContractCode, PBPCode, Insured_PolicyNumber, Total_Charge, Discount, Allowed, Deductible, Copay, Balance, 
												Coinsurance, Patient_Responsibility, Open_Field3, IncurredYear, [Source])
		SELECT
			@ProcessHeaderID AS ProcessHeaderID,
			EC.ClaimID AS Claim_Number,
			EC.ContractCode,
			EC.PBPCode,
			EC.MemberID AS Insured_PolicyNumber,
			SUM(ECD.BilledAmount) AS Total_Charge,
			SUM(ECD.Discount) AS Discount,
			SUM(CASE WHEN ECD.Is_Capitated = 'Y' THEN 0.00 ELSE ECD.Eligible END) AS Allowed,
			SUM(ECD.DeductibleAmount) AS Deductible,
			SUM(ECD.CopayAmount) AS Copay,
			SUM(CASE WHEN ECD.Is_Capitated = 'Y' THEN 0.00 ELSE ECD.PaidAmount END) AS Balance,
			SUM(ECD.CoinsuranceAmount) AS Coinsurance,
			SUM(CASE WHEN ECD.IDN_Denied_Charge > 0.00 THEN ECD.IDN_Denied_Charge
						ELSE ECD.DeductibleAmount + ECD.CopayAmount + ECD.CoinsuranceAmount END) AS Patient_Responsibility,
			EC.ClaimType AS Open_Field3,
			YEAR(EC.BeginServiceDate) AS IncurredYear,
			ECD.[Source]
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	QNXT_Custom.EOB.EOB_ClaimDetail ECD
			ON	EC.ClaimID = ECD.ClaimID
			AND	EC.[Source] = ECD.[Source]		
		GROUP BY EC.ClaimID, EC.MemberID, EC.ContractCode, EC.PBPCode, EC.ClaimType, YEAR(EC.BeginServiceDate), EC.ClaimType, ECD.[Source]
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		UPDATE	E04
		SET		E04.Open_Field1 = IIF(EP.PlanType = 'PPO', CONVERT(NUMERIC(10,2), ISNULL(EM.OutNetworkDeductible, 0.00)), CONVERT(NUMERIC(10,2),ISNULL(EM.InNetworkDeductible, 0.00))),
				E04.Open_Field2 = IIF(EP.PlanType = 'PPO', CONVERT(NUMERIC(10,2),(ISNULL(EM.InMOOPPaid,0.00) + ISNULL(EM.OutMOOPPaid,0.00))), 0.00)
		FROM	QNXT_Custom.EOB.EOB_0004TotalLine E04
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	E04.Claim_Number = EC.ClaimID
			AND	E04.Insured_PolicyNumber = EC.MemberID
		JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	EC.ContractCode = EP.ContractCode 
			AND EC.PBPCode = EP.PBPCode
			AND	YEAR(EC.BeginServiceDate) = EP.PlanYear
			AND EP.Active = 1
			AND (EP.GroupPlanID = '' OR EC.QNXTPlanID = EP.GroupPlanID)
		JOIN	QNXT_Custom.EOB.EOB_MOOP EM
			ON	LTRIM(RTRIM(EC.MemberID)) = LTRIM(RTRIM(EM.MemberID))
			AND	LTRIM(RTRIM(EC.ContractCode)) + LTRIM(RTRIM(EC.PBPCode)) = LTRIM(RTRIM(EM.UPID))
			AND CAST(CONVERT(VARCHAR(8), EC.BeginServiceDate, 112) AS INT) BETWEEN EM.MinMemberEffectiveDate AND EM.MaxMemberEffectiveDate
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		UPDATE	E04
		SET		E04.Open_Field1 = CONVERT(NUMERIC(10,2), ISNULL(EP.ServiceCategoryDeduct, 0.00))
		FROM	QNXT_Custom.EOB.EOB_0004TotalLine E04
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	E04.Claim_Number = EC.ClaimID
			AND	E04.Insured_PolicyNumber = EC.MemberID
		JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	EC.ContractCode = EP.ContractCode 
			AND EC.PBPCode = EP.PBPCode
			AND	YEAR(EC.BeginServiceDate) = EP.PlanYear
			AND EP.Active = 1
			AND (EP.GroupPlanID = '' OR EC.QNXTPlanID = EP.GroupPlanID)
			AND EP.ServiceCategoryDeduct <> 0.00
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_0004TotalLine REBUILD

	COMMIT TRANSACTION	

END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
