CREATE PROCEDURE [EOB].[EOB_Generate_DocumentID] AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Generate_DocumentID.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		IF OBJECT_ID('tempdb.dbo.#Seed') IS NOT NULL
		DROP TABLE #Seed

		CREATE TABLE #Seed ( 
			Insured_PolicyNumber VARCHAR(20),
			DocSeed INT IDENTITY(1,1),
			DocumentID VARCHAR(6) )

		INSERT INTO #Seed ( Insured_PolicyNumber )
		SELECT DISTINCT
			E01.Insured_PolicyNumber
		FROM QNXT_Custom.EOB.EOB_0001MasterDeliv E01

		UPDATE	S 
			SET	S.DocumentID = LEFT(CAST(DocSeed AS VARCHAR) + SPACE(6), 6)
		FROM	#Seed S

		UPDATE E01 SET
			E01.DocumentID = S.DocumentID
		FROM	#Seed S
		JOIN	QNXT_Custom.EOB.EOB_0001MasterDeliv E01
			ON	S.Insured_PolicyNumber = E01.Insured_PolicyNumber			

		UPDATE E02 SET
			E02.DocumentID = S.DocumentID		
		FROM	#Seed S
		JOIN	QNXT_Custom.EOB.EOB_0002EOB E02
			ON	S.Insured_PolicyNumber = E02.Insured_PolicyNumber			

		UPDATE E03 SET
			E03.DocumentID = E02.DocumentID
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	QNXT_Custom.EOB.EOB_0003ServiceLine E03
			ON	E02.Claim_Number = E03.Claim_Number
			AND	E02.[Source] = E03.[Source]

		UPDATE E04 SET
			E04.DocumentID = E02.DocumentID
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	QNXT_Custom.EOB.EOB_0004TotalLine E04
			ON	E02.Claim_Number = E04.Claim_Number
			AND	E02.[Source] = E04.[Source]

		UPDATE E04Z SET
			E04Z.DocumentID = S.DocumentID
		FROM	#Seed S
		JOIN	QNXT_Custom.EOB.EOB_0004ZZSegment E04Z
			ON	S.Insured_PolicyNumber = E04Z.Insured_PolicyNumber

		UPDATE E05 SET
			E05.DocumentID = E02.DocumentID
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	QNXT_Custom.EOB.EOB_0005Comments E05
			ON	E02.Claim_Number = E05.Claim_Number
			AND	E02.[Source] = E05.[Source]
			
		UPDATE E08 SET
			E08.DocumentID = S.DocumentID
		FROM	#Seed S
		JOIN	QNXT_Custom.EOB.EOB_0008Accumulator E08
			ON	S.Insured_PolicyNumber = E08.Insured_PolicyNumber

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION

	;THROW
END CATCH
GO
