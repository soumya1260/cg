CREATE PROCEDURE [EOB].[EOB_Transform0004ZZSegment] (@BeginDate DATE, @EndDate DATE, @ProcessHeaderID INT, @DisplayBeginDate DATE, @DisplayEndDate DATE, @RunYear INT ) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Transform0004ZZSegment.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
-- 1.3	KB			08.01.2019						CM20097013 - Using member's latest enrollment in QNXT
###########################################################################################################################################################
*/

TRUNCATE TABLE EOB.EOB_0004ZZSegment

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		IF OBJECT_ID('tempdb.dbo.#Del_Claims') IS NOT NULL
		DROP TABLE #Del_Claims

		IF OBJECT_ID('tempdb.dbo.#Del_Members') IS NOT NULL
		DROP TABLE #Del_Members

		CREATE TABLE #Del_Claims 
		(
			Claim_Number VARCHAR(100),
			[Source] VARCHAR(60)
		)

		CREATE TABLE #Del_Members 
		(
			Insured_PolicyNumber VARCHAR(100)
		)

		--Deleting all member 01 records where name is blank or null
		INSERT #Del_Members
		SELECT DISTINCT 
				E01.Insured_PolicyNumber
		FROM QNXT_Custom.EOB.EOB_0001MasterDeliv E01
		WHERE LTRIM(RTRIM(E01.[Name] + E01.Name2)) = ''
				OR LTRIM(RTRIM(E01.[Name] + E01.Name2)) IS NULL

		--Deleting all member records that do not have a corresponding claim 02 record
		INSERT #Del_Members
		SELECT DISTINCT
				E01.Insured_PolicyNumber
		FROM		QNXT_Custom.EOB.EOB_0001MasterDeliv E01
		LEFT JOIN	QNXT_Custom.EOB.EOB_0002EOB E02
				ON	E01.Insured_PolicyNumber = E02.Insured_PolicyNumber
		WHERE	E02.Insured_PolicyNumber IS NULL

		--Deleting all claim records that do not have a corresponding 03 record
		INSERT #Del_Claims
		SELECT DISTINCT
				E02.Claim_Number,
				E02.[Source]
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		LEFT OUTER JOIN QNXT_Custom.EOB.EOB_0003ServiceLine E03
			ON	E02.Claim_Number = E03.Claim_Number
			AND	E02.[Source] = E03.[Source]
		WHERE E03.Claim_Number IS NULL

		--Deleting all claim records that do not have a corresponding 04 record
		INSERT #Del_Claims
		SELECT DISTINCT
				E02.Claim_Number,
				E02.[Source]
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		LEFT OUTER JOIN QNXT_Custom.EOB.EOB_0004TotalLine E04
			ON	E02.Claim_Number = E04.Claim_Number
			AND	E02.[Source] = E04.[Source]
		WHERE E04.Claim_Number IS NULL

		--Deleting all claim records that do not have a corresponding 02 record
		INSERT #Del_Claims
		SELECT DISTINCT
				E03.Claim_Number,
				E03.[Source]
		FROM	QNXT_Custom.EOB.EOB_0003ServiceLine E03
		LEFT OUTER JOIN QNXT_Custom.EOB.EOB_0002EOB E02
			ON	E03.Claim_Number = E02.Claim_Number
			AND	E03.[Source] = E02.[Source]
		WHERE E02.Claim_Number IS NULL

		--Deleting all claim records that do not have a corresponding 02 record
		INSERT #Del_Claims
		SELECT DISTINCT
				E04.Claim_Number,
				E04.[Source]
		FROM	QNXT_Custom.EOB.EOB_0004TotalLine E04
		LEFT OUTER JOIN QNXT_Custom.EOB.EOB_0002EOB E02
			ON	E04.Claim_Number = E02.Claim_Number
			AND	E04.[Source] = E02.[Source]
		WHERE E02.Claim_Number IS NULL

		--Deleting all claim records from EOB tables where claim has multiple 02 entries
		INSERT #Del_Claims
		SELECT DISTINCT
				E02.Claim_Number,
				E02.[Source]
		FROM QNXT_Custom.EOB.EOB_0002EOB E02
		GROUP BY E02.Claim_Number, E02.Insured_PolicyNumber, E02.[Source]
		HAVING COUNT(E02.Claim_Number) > 1

		--Deleting all claim records from EOB tables where claim doesn't have a valid service or rev code
		INSERT #Del_Claims
		SELECT DISTINCT
				E03.Claim_Number,
				E03.[Source]
		FROM	QNXT_Custom.EOB.EOB_0003ServiceLine E03
		WHERE	E03.Open_Field3 = ''
			OR	E03.Open_Field6 = ''
		
		--Deleting all claims where the corresponding members are marked for delete
		INSERT #Del_Claims
		SELECT DISTINCT
				E02.Claim_Number,
				E02.[Source]
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	#Del_Members DM
			ON	E02.Insured_PolicyNumber = DM.Insured_PolicyNumber
		
		IF OBJECT_ID('TEMPDB..#YearlyTotals') IS NOT NULL
		DROP TABLE #YearlyTotals

		SELECT	YT.MemberID AS Insured_PolicyNumber,
				YT.IncurredYear,
				YT.ContractCode,
				YT.PBPCode,
				MAX(YT.Flex_Med_YTD_Contributions) AS ServiceCategory,
				SUM(YT.Total_Charge) AS Total_Charge,
				SUM(YT.Discount) AS Discount,
				MAX(YT.OOP_Deductible) AS Deductible,
				SUM(YT.Copay) AS Copay,
				SUM(YT.CoInsurance) AS CoInsurance,
				MAX(YT.Flex_Med_YTD_Contributions) AS Flex_Med_YTD_Contributions,
				SUM(YT.Other_Amount3) AS Other_Amount3,
				SUM(YT.Other_Amount4) AS Other_Amount4,
				SUM(YT.Flex_Med_Annual) AS Flex_Med_Annual,
				MAX(YT.Open_Field6) AS Flex_Med_YTD_Claims
		INTO	#YearlyTotals
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals YT		
		GROUP BY YT.MemberID, YT.IncurredYear, YT.ContractCode, YT.PBPCode
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		CREATE CLUSTERED INDEX IDX_YearlyTotals ON #YearlyTotals ( Insured_PolicyNumber ASC, IncurredYear ASC, ContractCode ASC, PBPCode ASC )

		IF OBJECT_ID('TEMPDB..#MonthlyTotals') IS NOT NULL
		DROP TABLE #MonthlyTotals

		SELECT	E02.Insured_PolicyNumber,				
				SUM(CONVERT(NUMERIC(10, 2), E04.Total_Charge)) AS Total_Charge,
				SUM(CONVERT(NUMERIC(10, 2), E04.Allowed)) AS Discount,
				SUM(CONVERT(NUMERIC(10, 2), E04.Deductible)) AS Deductible,
				SUM(CONVERT(NUMERIC(10, 2), E04.CoPay)) AS CoPay,
				SUM(CONVERT(NUMERIC(10, 2), E04.CoInsurance)) AS CoInsurance,
				SUM(CONVERT(NUMERIC(10, 2), E04.Allowed)) AS Other_Amount3,
				SUM(CONVERT(NUMERIC(10, 2), E04.Balance)) AS Other_Amount4,
				SUM(CONVERT(NUMERIC(10, 2), E04.Patient_Responsibility)) AS Flex_Med_Annual
		INTO	#MonthlyTotals
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	QNXT_Custom.EOB.EOB_0004TotalLine E04
			ON	E02.Claim_Number = E04.Claim_Number
			AND	E02.[Source] = E04.[Source]
			AND	E02.Open_Field3 <> 'SU'
		LEFT JOIN #Del_Claims DC 
			ON	E02.Claim_Number = DC.Claim_Number
			AND	E02.[Source] = DC.[Source]
		WHERE	DC.Claim_Number IS NULL
		GROUP BY E02.Insured_PolicyNumber
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		INSERT INTO #MonthlyTotals
		SELECT		E02O.Insured_PolicyNumber,					
					0.00 AS Total_Charge,
					0.00 AS Discount,
					0.00 AS Deductible,
					0.00 AS CoPay,
					0.00 AS CoInsurance,
					0.00 AS Other_Amount3,
					0.00 AS Other_Amount4,
					0.00 AS Flex_Med_Annual
		FROM		QNXT_Custom.EOB.EOB_0002EOB E02O
		LEFT JOIN	(
						SELECT DISTINCT 
								E02NO.Insured_PolicyNumber
						FROM	QNXT_Custom.EOB.EOB_0002EOB E02NO
						WHERE	E02NO.Open_Field3 <> 'SU'
					) E02NO
				ON	E02O.Insured_PolicyNumber = E02NO.Insured_PolicyNumber				
		LEFT JOIN	#Del_Claims DC 
				ON	E02O.Claim_Number = DC.Claim_Number
				AND	E02O.[Source] = DC.[Source]
		WHERE	E02O.Open_Field3 = 'SU'
			AND	E02NO.Insured_PolicyNumber IS NULL
			AND DC.Claim_Number IS NULL
		GROUP BY E02O.Insured_PolicyNumber
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		CREATE CLUSTERED INDEX IDX_MonthlyTotals ON #MonthlyTotals ( Insured_PolicyNumber ASC )

		IF OBJECT_ID('TEMPDB..#MemberPlanYears') IS NOT NULL
		DROP TABLE #MemberPlanYears

		;WITH CTE AS
		(
			SELECT	EC.MemberID,					
					CASE	WHEN EK.EnrollID IS NULL OR LEN(LTRIM(RTRIM(BP.UPID))) NOT IN (9, 8) THEN EC.ContractCode
							ELSE LEFT(LTRIM(RTRIM(BP.UPID)), 5) 
					END AS ContractCode,
					CASE	WHEN EK.EnrollID IS NULL OR LEN(LTRIM(RTRIM(BP.UPID))) NOT IN (9, 8) THEN EC.PBPCode
							WHEN EK.EnrollID IS NOT NULL AND LEN(LTRIM(RTRIM(BP.UPID))) = 9 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 4)
							WHEN EK.EnrollID IS NOT NULL AND LEN(LTRIM(RTRIM(BP.UPID))) = 8 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 3) 
					END AS PBPCode,
					EC.QNXTPlanID,
					CASE WHEN L.[Description] LIKE '%SPANISH%' THEN 'SP'
							ELSE 'EN' END AS [Language],
					CASE WHEN L.[Description] LIKE '%SPANISH%' THEN CONVERT(VARCHAR, @DisplayBeginDate, 103)
									ELSE CONVERT(VARCHAR, @DisplayBeginDate, 101) END AS Open_Field4,
					CASE WHEN L.[Description] LIKE '%SPANISH%' THEN CONVERT(VARCHAR, @DisplayEndDate, 103)
									ELSE CONVERT(VARCHAR, @DisplayEndDate, 101) END AS Open_Field5,					
					ROW_NUMBER() OVER (PARTITION BY EC.MemberID ORDER BY EK.EffDate DESC, EK.TermDate DESC) AS RowNum					
			FROM	QNXT_Custom.EOB.EOB_Claim EC
			JOIN	Plandata_Prod.dbo.Member M
				ON	EC.MemberID = M.SecondaryID			
			LEFT JOIN	QNXT_Custom.EOB.EOB_MemberLanguageXref L
				ON	M.PrimaryLanguage = L.LanguageID
			LEFT JOIN	Plandata_Prod.dbo.EnrollKeys EK
				ON	M.MemID = EK.MemID
				AND EK.SegType = 'INT'
			LEFT JOIN	Plandata_Prod.dbo.BenefitPlan BP
				ON	EK.PlanID = BP.PlanID
		)
		SELECT	DISTINCT CTE.MemberID,
						 @RunYear AS IncurredYear,
						 CTE.ContractCode,
						 CTE.PBPCode,
						 CTE.QNXTPlanID,
						 CTE.[Language],
						 CTE.Open_Field4,
						 CTE.Open_Field5
		INTO	#MemberPlanYears
		FROM	CTE
		WHERE	CTE.RowNum = 1

		CREATE CLUSTERED INDEX IDX_MemberPlanYears ON #MemberPlanYears ( MemberID ASC, IncurredYear ASC, ContractCode ASC, PBPCode ASC, QNXTPlanID ASC, [Language] ASC, Open_Field4 ASC, Open_Field5 ASC )

		INSERT INTO [EOB].[EOB_0004ZZSegment] ( ProcessHeaderID, Insured_PolicyNumber, IncurredYear, ContractCode, PBPCode, Total_Charge, Discount, Deductible, 
												Copay, CoInsurance, Flex_Med_YTD_Contributions, Other_Amount3, Other_Amount4, Flex_Med_Annual,
												Open_Field1, Open_Field2, Open_Field3, Open_Field4, Open_Field5, Flex_Med_YTD_Payment, Flex_Med_YTD_Remaining, Flex_Med_YTD_Balance,  
												Flex_Med_YTD_Claims )
		SELECT 
			@ProcessHeaderID AS ProcessHeaderID,
			YearlySum.Insured_PolicyNumber,
			YearlySum.IncurredYear,
			YearlySum.ContractCode,
			YearlySum.PBPCode,
			YearlySum.Total_Charge,
			YearlySum.Discount,
			YearlySum.Deductible,
			YearlySum.Copay,
			YearlySum.CoInsurance,
			YearlySum.Flex_Med_YTD_Contributions,
			YearlySum.Other_Amount3,
			YearlySum.Other_Amount4,
			YearlySum.Flex_Med_Annual,
			MonthlySum.Total_Charge AS Open_Field1,
			MonthlySum.Discount AS Open_Field2,
			MonthlySum.Deductible AS Open_Field3,
			MPL.Open_Field4 AS Open_Field4,
			MPL.Open_Field5 AS Open_Field5,
			MonthlySum.Other_Amount3 AS Flex_Med_YTD_Payment,
			MonthlySum.Other_Amount4 AS Flex_Med_YTD_Remaining,
			MonthlySum.Flex_Med_Annual AS Flex_Med_YTD_Balance,			
			YearlySum.Flex_Med_YTD_Claims AS Flex_Med_YTD_Claims
		FROM	#YearlyTotals YearlySum
		JOIN	#MonthlyTotals MonthlySum
			ON	YearlySum.Insured_PolicyNumber = MonthlySum.Insured_PolicyNumber			
		JOIN	#MemberPlanYears MPL
			ON	YearlySum.Insured_PolicyNumber = MPL.MemberID
			AND YearlySum.IncurredYear = MPL.IncurredYear
			AND YearlySum.ContractCode = MPL.ContractCode
			AND YearlySum.PBPCode = MPL.PBPCode
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_0004ZZSegment REBUILD

		UPDATE	E04Z
			SET	E04Z.Flex_Med_YTD_Denied = ISNULL(EM.InMOOPPaid, 0.00),
				E04Z.Flex_Med_YTD_Pended = ISNULL(EM.InMOOPPaid, 0.00) + ISNULL(EM.OutMOOPPaid, 0.00),
				E04Z.Flex_Med_YTD_Deposit = ISNULL(EM.InNetworkMOOP, 0.00),
				E04Z.Flex_DEP_Annual = IIF(ISNULL(EM.InNetworkMOOP, 0.00) > ISNULL(EM.OutNetworkMOOP, 0.00), ISNULL(EM.InNetworkMOOP, 0.00), ISNULL(EM.OutNetworkMOOP, 0.00)),
				E04Z.Flex_Dep_YTD_Contributions = CASE WHEN ISNULL(EP.ServiceCategory, 0) <> 0 THEN 'Y'
														ELSE 'N' END,
				E04Z.Flex_Med_YTD_Claims = CASE WHEN ISNULL(EP.ServiceCategory, 0) <> 0. THEN '0'
														ELSE  E04Z.Flex_Med_YTD_Claims END,
				E04Z.Flex_Dep_YTD_Payment = ISNULL(EP.ServiceCategory, 0)
		FROM	QNXT_Custom.EOB.EOB_0004ZZSegment E04Z
		JOIN	#MemberPlanYears MPY
			ON	E04Z.Insured_PolicyNumber = MPY.MemberID
			AND	E04Z.IncurredYear = MPY.IncurredYear
			AND E04Z.ContractCode = MPY.ContractCode
			AND E04Z.PBPCode = MPY.PBPCode
		JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	MPY.IncurredYear = EP.PlanYear
			AND MPY.ContractCode = EP.ContractCode
			AND	MPY.PBPCode = EP.PBPCode
			AND (EP.GroupPlanID = '' OR MPY.QNXTPlanID = EP.GroupPlanID)
			AND EP.Active = 1
		JOIN	QNXT_Custom.EOB.EOB_MOOP EM
			ON	E04Z.Insured_PolicyNumber = EM.MemberID
			AND	LTRIM(RTRIM(MPY.ContractCode)) + LTRIM(RTRIM(MPY.PBPCode)) = LTRIM(RTRIM(EM.UPID))
			AND LEFT(EM.MinMemberEffectiveDate, 4) = @RunYear

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO