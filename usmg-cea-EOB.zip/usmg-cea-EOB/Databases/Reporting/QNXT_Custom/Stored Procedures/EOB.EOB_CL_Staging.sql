CREATE PROCEDURE [EOB].[EOB_CL_Staging] (@BeginDate DATE, @EndDate DATE, @ProcessHeaderID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_CL_Staging.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Stage CL data for EOB runs
--
-- Called by:		NA
###########################################################################################################################################################
-- Parameters
--     
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			08.13.2018			215695		Updated logic to set the appropriate billed amount (CM20025799)
-- 1.3  KB			08.23.2018			215695		Updated logic to set the appropriate sequestration and interest amounts (CM20027392)
-- 1.4  KB			09.04.2018			215695		Update to staging the provider name and interest amounts (CM20029812)
-- 1.5	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
-- 1.6	KB			01.08.2019			203876		Added Capitated check for Allowed Amount
-- 1.7	KB			08.01.2019						CM20097013 - Removed coins%
###########################################################################################################################################################
*/

TRUNCATE TABLE EOB.EOB_Claim
TRUNCATE TABLE EOB.EOB_ClaimDetail

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
BEGIN TRANSACTION

	INSERT INTO QNXT_Custom.EOB.EOB_Claim ( ProcessHeaderID, ClaimID, MemberID, MemberFirstName, MemberLastName, ContractCode, PBPCode, ProviderID, ProviderName, ClaimStatus, 
											PaidDate, PaidAmount, BeginServiceDate, EndServiceDate, Par_Ind, Denial_Language_Ind, Is_PartD, [Source], ClaimType, QNXTPlanID )
	SELECT DISTINCT 
			@ProcessHeaderID AS ProcessHeaderID,
			C.ClaimID,
			M.SecondaryID AS MemberID,
			E.FirstName AS MemberFirstName,
			E.LastName AS MemberLastName,
			CASE WHEN C.Status = 'DENIED' AND C.EnrollID = '' THEN 'DUMMY'
					ELSE LEFT(LTRIM(RTRIM(BP.UPID)), 5) END AS ContractCode,
			CASE WHEN C.Status = 'DENIED' AND C.EnrollID = '' THEN ''
					WHEN LEN(LTRIM(RTRIM(BP.UPID))) = 9 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 4)
					ELSE RIGHT(LTRIM(RTRIM(BP.UPID)), 3) END AS PBPCode,
			P.ProvID AS ProviderID,
			LTRIM(RTRIM(ISNULL(NULLIF(NULLIF(LTRIM(RTRIM(PE.FirstName)), 'NPROVIDED'), 'UNKNOWN'), '') + ' ' + ISNULL(NULLIF(NULLIF(LTRIM(RTRIM(PE.LastName)), 'NPROVIDED'), 'UNKNOWN'), ''))) AS ProviderName,
			LEFT(LTRIM(RTRIM(C.[Status])), 1) AS ClaimStatus,
			C.PaidDate,
			C.TotalPaid AS PaidAmount,
			C.StartDate AS BeginServiceDate,
			C.EndDate AS EndServiceDate, 
			'' Par_Ind,
			CASE WHEN C.Status = 'DENIED' AND C.EnrollID = '' THEN 'N'
					ELSE '' END AS Denial_Language_Ind,
			'N' AS Is_PartD,
			'CL' AS [Source],
			'CL' AS ClaimType,
			ISNULL(BP.PlanID, '') AS QNXTPlanID
	FROM	QNXT_Custom.EOB.EOB_Run_Staging ERS
	JOIN	Plandata_Prod.dbo.Claim C
		ON	ERS.ClaimID = C.ClaimID
		AND	ERS.[Source] = 'CL'
		AND C.[Status] IN ( 'PAID', 'DENIED', 'REVERSED' )
		AND ERS.IsValid = 'Y'
	JOIN	Plandata_Prod.dbo.EnrollKeys EK
		ON	C.EnrollID = EK.EnrollID
	JOIN	Plandata_Prod.dbo.BenefitPlan BP
		ON	EK.PlanID = BP.PlanID	
	JOIN	Plandata_Prod.dbo.Provider P
		ON	C.ProvID = P.ProvID
	JOIN	Plandata_Prod.dbo.entity PE
		ON	P.entityid = PE.entid
	JOIN	Plandata_Prod.dbo.Member M
		ON	C.MemID = M.MemID
	JOIN	Plandata_Prod.dbo.entity E
		ON	M.EntityID = E.EntID
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	ALTER INDEX ALL ON EOB.EOB_Claim REBUILD
	
	UPDATE  EC
		SET	EC.Par_Ind = CASE WHEN CE.RuleID = '6035' THEN 'P'
								WHEN CE.RuleID = '6036' THEN 'N'
								ELSE '' END
	FROM	QNXT_Custom.EOB.EOB_Claim EC
	JOIN	Plandata_Prod.dbo.ClaimEdit CE
		ON	EC.ClaimID = CE.ClaimID
		AND CE.ClaimLine = 0
		AND CE.RuleID IN ('6035', '6036')
		AND EC.[Source] = 'CL'
	WHERE	EC.Par_Ind = ''
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	UPDATE	EC
		SET EC.Par_Ind = CASE WHEN CI.Contracted = 'Y' THEN 'P' 
								ELSE 'N' END
	FROM	QNXT_Custom.EOB.EOB_Claim EC
	JOIN	Plandata_Prod.dbo.Claim C
		ON	EC.ClaimID = C.ClaimID
		AND	EC.[Source] = 'CL'
	JOIN	Plandata_Prod.dbo.EnrollKeys EK
		ON	C.EnrollID = EK.EnrollID
	LEFT OUTER JOIN	Plandata_Prod.dbo.ContractInfo CI
		ON C.affiliationid = CI.affiliationid
		AND EK.programid = CI.programid
		AND C.contractnetworkid = CI.networkid
		AND C.contractid= CI.contractid
		AND C.startdate BETWEEN CI.effdate AND CI.termdate
	WHERE	EC.Par_Ind = ''
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	ALTER INDEX ALL ON EOB.EOB_Claim REBUILD

	INSERT INTO QNXT_Custom.EOB.EOB_ClaimDetail ( ProcessHeaderID, ClaimID, ClaimLine, ClaimLineStatus, ClaimType, Type_Of_Bill, Revenue_Code, Procedure_Code, Place_Of_Service, Units, 
												BeginServiceDate, EndServiceDate, PaidDate, BilledAmount, Discount, Eligible, Ineligible, Allowed, DeductibleAmount, CopayAmount, 
												CoinsuranceAmount, PaidAmount, Balance, Is_Capitated, PrinDiag, PrinDiag_ICDVersion, Diag1, Diag1_ICDVersion, Diag2, Diag2_ICDVersion, Diag3, Diag3_ICDVersion,
												Diag4, Diag4_ICDVersion, Diag5, Diag5_ICDVersion, Diag6, Diag6_ICDVersion, Diag7, Diag7_ICDVersion, Diag8, Diag8_ICDVersion, [Source] )
	SELECT DISTINCT
			@ProcessHeaderID ProcessHeaderID,
			EC.ClaimID,
			CD.ClaimLine,
			LEFT(LTRIM(RTRIM(CD.[Status])), 1) AS ClaimLineStatus,
			'CL' AS ClaimType,
			C.FacilityCode + C.BillClassCode + C.FrequencyCode AS Type_Of_Bill,
			CD.Revcode AS Revenue_Code,
			CD.Servcode AS Procedure_Code,
			CD.location AS Place_Of_Service, 
			CD.ServUnits AS Units,
			CD.DOSFrom AS BeginServiceDate,
			CD.DOSTo AS EndServiceDate,
			EC.PaidDate AS PaidDate,
			CD.ClaimAmt AS BilledAmount,
			CASE WHEN EC.ClaimStatus = 'R' THEN ABS(CD.PayDiscount)
				 ELSE (-1 * ABS(CD.PayDiscount)) END AS Discount,
			CASE WHEN CD.[Status] IN ('OKAY', 'WARN') AND CD.capitated = 0 THEN CD.ContractPaid
				 ELSE 0.00 END AS Eligible,
			CD.Ineligibleamt AS Ineligible,
			CASE WHEN EC.ClaimStatus = 'R' THEN CD.AmountPaid + (-1 * ABS(CD.PayDiscount)) + (-1 * ABS(CD.SubmitDiscount)) + CD.copay + CD.benededuct + CD.coinsuranceamt + CD.copayperdiemamt
				 ELSE CD.AmountPaid + ABS(CD.PayDiscount) + CD.SubmitDiscount + CD.copay + CD.benededuct + CD.coinsuranceamt + CD.copayperdiemamt END AS Allowed,
			CD.benededuct AS DeductibleAmount,
			CD.Copay + CD.copayperdiemamt AS CopayAmount,
			CD.CoinsuranceAmt AS CoinsuranceAmount,
			CD.AmountPaid AS PaidAmount,
			CASE WHEN EC.ClaimStatus = 'R' THEN CD.AmountPaid + (-1 * ABS(CD.PayDiscount)) + (-1 * ABS(CD.SubmitDiscount))
				 ELSE CD.AmountPaid + ABS(CD.PayDiscount) + CD.SubmitDiscount END AS Balance,			
			CASE WHEN CD.Capitated <> 0 THEN 'Y'
					ELSE 'N' END AS Is_Capitated,
			ISNULL(CD.PrinDiag, '') AS PrinDiag,
			CASE WHEN ISNULL(CD.ICDVersion, '') <> '' AND TRY_CONVERT(INT, CD.ICDVersion) IS NOT NULL AND CD.ICDVersion IN (0, 9) THEN CD.ICDVersion
					ELSE 0 END AS PrinDiag_ICDVersion,
			'' AS Diag1,
			0 AS Diag1_ICDVersion,
			'' AS Diag2,
			0 AS Diag2_ICDVersion,			
			'' AS Diag3,
			0 AS Diag3_ICDVersion,
			'' AS Diag4,
			0 AS Diag4_ICDVersion,
			'' AS Diag5,
			0 AS Diag5_ICDVersion,			
			'' AS Diag6,
			0 AS Diag6_ICDVersion,
			'' AS Diag7,
			0 AS Diag7_ICDVersion,			
			'' AS Diag8,
			0 AS Diag8_ICDVersion,
			'CL' AS [Source]
	FROM	QNXT_Custom.EOB.EOB_Claim EC
	JOIN	Plandata_Prod.dbo.ClaimDetail CD
		ON	EC.ClaimID = CD.ClaimID
	JOIN	Plandata_Prod.dbo.Claim C
		ON	EC.ClaimID = C.ClaimID
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	ALTER INDEX ALL ON EOB.EOB_ClaimDetail REBUILD

	UPDATE	ECD
		SET	ECD.Diag1 = CASE WHEN ISNULL(CDG.CodeID, '') <> '' THEN CDG.CodeID 
								ELSE '' END,
			ECD.Diag1_ICDVersion = CASE WHEN ISNULL(CDG.ICDVersion, '') <> '' AND CDG.ICDVersion IN (0, 9) THEN CDG.ICDVersion 
									ELSE 0 END	
	FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
	JOIN	Plandata_Prod.dbo.ClaimDetail CD
		ON	ECD.ClaimID = CD.ClaimID
		AND	ECD.ClaimLine = CD.ClaimLine
	JOIN	Plandata_Prod.dbo.ClaimDiag CDG
		ON	CD.ClaimID = CDG.ClaimID
		AND CD.Diag1 = CDG.[Sequence]
		AND TRY_CONVERT(INT, CDG.ICDVersion) IS NOT NULL
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	UPDATE	ECD
		SET	ECD.Diag2 = CASE WHEN ISNULL(CDG.CodeID, '') <> '' THEN CDG.CodeID 
								ELSE '' END,
			ECD.Diag2_ICDVersion = CASE WHEN ISNULL(CDG.ICDVersion, '') <> '' AND CDG.ICDVersion IN (0, 9) THEN CDG.ICDVersion 
									ELSE 0 END
	FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
	JOIN	Plandata_Prod.dbo.ClaimDetail CD
		ON	ECD.ClaimID = CD.ClaimID
		AND	ECD.ClaimLine = CD.ClaimLine
	JOIN	Plandata_Prod.dbo.ClaimDiag CDG
		ON	CD.ClaimID = CDG.ClaimID
		AND	CD.Diag2 = CDG.[Sequence]
		AND TRY_CONVERT(INT, CDG.ICDVersion) IS NOT NULL
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	UPDATE	ECD
		SET	ECD.Diag3 = CASE WHEN ISNULL(CDG.CodeID, '') <> '' THEN CDG.CodeID 
								ELSE '' END,
			ECD.Diag3_ICDVersion = CASE WHEN ISNULL(CDG.ICDVersion, '') <> '' AND CDG.ICDVersion IN (0, 9) THEN CDG.ICDVersion 
									ELSE 0 END
	FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
	JOIN	Plandata_Prod.dbo.ClaimDetail CD
		ON	ECD.ClaimID = CD.ClaimID
		AND	ECD.ClaimLine = CD.ClaimLine
	JOIN	Plandata_Prod.dbo.ClaimDiag CDG
		ON	CD.ClaimID = CDG.ClaimID
		AND	CD.Diag3 = CDG.[Sequence]
		AND TRY_CONVERT(INT, CDG.ICDVersion) IS NOT NULL
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	UPDATE	ECD
		SET	ECD.Diag4 = CASE WHEN ISNULL(CDG.CodeID, '') <> '' THEN CDG.CodeID 
								ELSE '' END,
			ECD.Diag4_ICDVersion = CASE WHEN ISNULL(CDG.ICDVersion, '') <> '' AND CDG.ICDVersion IN (0, 9) THEN CDG.ICDVersion 
									ELSE 0 END
	FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
	JOIN	Plandata_Prod.dbo.ClaimDetail CD
		ON	ECD.ClaimID = CD.ClaimID
		AND	ECD.ClaimLine = CD.ClaimLine
	JOIN	Plandata_Prod.dbo.ClaimDiag CDG
		ON	CD.ClaimID = CDG.ClaimID
		AND	CD.Diag4 = CDG.[Sequence]
		AND TRY_CONVERT(INT, CDG.ICDVersion) IS NOT NULL
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	UPDATE	ECD
		SET	ECD.Diag5 = CASE WHEN ISNULL(CDG.CodeID, '') <> '' THEN CDG.CodeID 
								ELSE '' END,
			ECD.Diag5_ICDVersion = CASE WHEN ISNULL(CDG.ICDVersion, '') <> '' AND CDG.ICDVersion IN (0, 9) THEN CDG.ICDVersion 
									ELSE 0 END
	FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
	JOIN	Plandata_Prod.dbo.ClaimDetail CD
		ON	ECD.ClaimID = CD.ClaimID
		AND	ECD.ClaimLine = CD.ClaimLine
	JOIN	Plandata_Prod.dbo.ClaimDiag CDG
		ON	CD.ClaimID = CDG.ClaimID
		AND	CD.Diag5 = CDG.[Sequence]
		AND TRY_CONVERT(INT, CDG.ICDVersion) IS NOT NULL
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	UPDATE	ECD
		SET	ECD.Diag6 = CASE WHEN ISNULL(CDG.CodeID, '') <> '' THEN CDG.CodeID 
								ELSE '' END,
			ECD.Diag6_ICDVersion = CASE WHEN ISNULL(CDG.ICDVersion, '') <> '' AND CDG.ICDVersion IN (0, 9) THEN CDG.ICDVersion 
									ELSE 0 END
	FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
	JOIN	Plandata_Prod.dbo.ClaimDetail CD
		ON	ECD.ClaimID = CD.ClaimID
		AND	ECD.ClaimLine = CD.ClaimLine
	JOIN	Plandata_Prod.dbo.ClaimDiag CDG
		ON	CD.ClaimID = CDG.ClaimID
		AND	CD.Diag6 = CDG.[Sequence]
		AND TRY_CONVERT(INT, CDG.ICDVersion) IS NOT NULL
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	UPDATE	ECD
		SET	ECD.Diag7 = CASE WHEN ISNULL(CDG.CodeID, '') <> '' THEN CDG.CodeID 
								ELSE '' END,
			ECD.Diag7_ICDVersion = CASE WHEN ISNULL(CDG.ICDVersion, '') <> '' AND CDG.ICDVersion IN (0, 9) THEN CDG.ICDVersion 
									ELSE 0 END
	FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
	JOIN	Plandata_Prod.dbo.ClaimDetail CD
		ON	ECD.ClaimID = CD.ClaimID
		AND	ECD.ClaimLine = CD.ClaimLine
	JOIN	Plandata_Prod.dbo.ClaimDiag CDG
		ON	CD.ClaimID = CDG.ClaimID
		AND	CD.Diag7 = CDG.[Sequence]
		AND TRY_CONVERT(INT, CDG.ICDVersion) IS NOT NULL
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	UPDATE	ECD
		SET	ECD.Diag8 = CASE WHEN ISNULL(CDG.CodeID, '') <> '' THEN CDG.CodeID 
								ELSE '' END,
			ECD.Diag8_ICDVersion = CASE WHEN ISNULL(CDG.ICDVersion, '') <> '' AND CDG.ICDVersion IN (0, 9) THEN CDG.ICDVersion 
									ELSE 0 END
	FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
	JOIN	Plandata_Prod.dbo.ClaimDetail CD
		ON	ECD.ClaimID = CD.ClaimID
		AND	ECD.ClaimLine = CD.ClaimLine
	JOIN	Plandata_Prod.dbo.ClaimDiag CDG
		ON	CD.ClaimID = CDG.ClaimID
		AND	CD.Diag8 = CDG.[Sequence]
		AND TRY_CONVERT(INT, CDG.ICDVersion) IS NOT NULL
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	--Change log - 02/28/2017 - Kiran, Kaleb, Ryan - Logic to set COpen_Field9 based on IDN status
	IF OBJECT_ID('TEMPDB..#Denial_Language_Ind') IS NOT NULL
	DROP TABLE #Denial_Language_Ind

	CREATE TABLE #Denial_Language_Ind
	(
		[ClaimID] VARCHAR(15),
		[ClaimLine] INT,
		[Denial_Language_Ind] VARCHAR(2)
	)

	INSERT INTO #Denial_Language_Ind
	SELECT DISTINCT EC.ClaimID,
					CE.ClaimLine,
					CASE WHEN DL.MessageID IS NOT NULL THEN 'N'
							ELSE '' END AS [Denial_Language_Ind]
	FROM	QNXT_Custom.EOB.EOB_Claim EC
	JOIN	Plandata_Prod.dbo.Claim C
		ON	EC.ClaimID = C.ClaimID
		AND C.[status] <> 'REVERSED'
		AND	EC.[Source] = 'CL'
	JOIN	Plandata_Prod.[dbo].[claimdetail] CD
		ON	C.[claimid] = CD.[claimid]
	JOIN	Plandata_Prod.[dbo].[claimedit] CE
		ON	CD.[claimid] = CE.[claimid]
		AND ( CD.[claimline] = CE.[claimline] OR CE.ClaimLine = 0 )
	LEFT OUTER JOIN QNXT_Custom.EOB.[EOB_IDN_DenialLanguage] DL
		ON (CE.[reason] = DL.MessageID AND EC.Par_Ind = 'P' AND DL.[PAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
			 OR (CE.[reason] = DL.MessageID AND EC.Par_Ind = 'N' AND DL.[NONPAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
			 OR (CE.[eobid] = DL.MessageID AND EC.Par_Ind = 'P' AND DL.[PAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
			 OR (CE.[eobid] = DL.MessageID AND EC.Par_Ind = 'N' AND DL.[NONPAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	INSERT INTO #Denial_Language_Ind
	SELECT DISTINCT EC.ClaimID,
					CE.ClaimLine,
					CASE WHEN DL.MessageID IS NOT NULL THEN 'N'
							ELSE '' END AS [Denial_Language_Ind]
	FROM	QNXT_Custom.EOB.EOB_Claim EC
	JOIN	Plandata_Prod.dbo.Claim C
		ON	EC.ClaimID = C.ClaimID
		AND C.[status] <> 'REVERSED'
		AND	EC.[Source] = 'CL'
	JOIN	Plandata_Prod.[dbo].[claimdetail] CD
		ON	C.[claimid] = CD.[claimid]
	JOIN	Plandata_Prod.[dbo].[claimedit] CE
		ON	CD.[claimid] = CE.[claimid]
		AND ( CD.[claimline] = CE.[claimline] OR CE.ClaimLine = 0 )
	JOIN	Plandata_Prod.[dbo].[claimeditmessage] CEM
		ON	CE.[claimid] = CEM.[claimid]
		AND CE.[claimline] = CEM.[claimline]
		AND CE.[ruleid] = CEM.[ruleid]
	LEFT OUTER JOIN QNXT_Custom.EOB.[EOB_IDN_DenialLanguage] DL
		ON (CEM.MessageID = DL.MessageID AND EC.Par_Ind = 'P' AND DL.[PAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
			 OR (CEM.MessageID = DL.MessageID AND EC.Par_Ind = 'N' AND DL.[NONPAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	CREATE CLUSTERED INDEX Idx_Denial_Language_Ind ON #Denial_Language_Ind ( ClaimID ASC, ClaimLine ASC, Denial_Language_Ind ASC)

	DELETE DL
	FROM #Denial_Language_Ind DL
	INNER JOIN (
					SELECT DISTINCT DL.ClaimID,
									COUNT(DISTINCT DL.[Denial_Language_Ind]) AS Counts
					FROM #Denial_Language_Ind DL
					GROUP BY DL.ClaimID
					HAVING COUNT(DISTINCT DL.[Denial_Language_Ind]) > 1
				) DLDUPS
					ON DL.ClaimID = DLDUPS.ClaimID
	WHERE DL.[Denial_Language_Ind] = ''
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	UPDATE	ECD
		SET	ECD.[IDN_Denied_Charge] = CD.ClaimAmt
	FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
	JOIN	#Denial_Language_Ind DL
		ON	ECD.ClaimID = DL.ClaimID
		AND	(ECD.ClaimLine = DL.ClaimLine OR DL.ClaimLine = 0)
		AND DL.[Denial_Language_Ind] = 'N'
	JOIN	Plandata_Prod.dbo.ClaimDetail CD
		ON	ECD.ClaimID = CD.ClaimID
		AND	ECD.ClaimLine = CD.ClaimLine
	OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	ALTER INDEX ALL ON EOB.EOB_ClaimDetail REBUILD

COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO