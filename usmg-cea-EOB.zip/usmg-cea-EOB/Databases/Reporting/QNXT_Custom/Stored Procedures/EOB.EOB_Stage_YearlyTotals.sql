CREATE PROCEDURE [EOB].[EOB_Stage_YearlyTotals] ( @BeginDate DATE, @EndDate DATE, @ProcessHeaderID INT, @RunYear INT ) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Stage_YearlyTotals.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Stage Yearly Totals for CL and RX claims
-- 
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			07.17.2018			215695		Updated the join to be inner instead of left on EOB.EOB_MOOP table (CM20020172)
-- 1.3  KB			08.13.2018			215695		Updated logic to compute the yearly totals (CM20025799)
-- 1.4  KB			09.04.2018			215695		Updated logic to compute RX yearly totals (CM20029812)
-- 1.5  KB			09.11.2018			215695		Updated logic to factor in interest and sequestration amounts appropriately (CM20031271)
-- 1.6	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
-- 1.7	KB			01.06.2019			203876		Updated Capitated flag check for Eligible Amount
-- 1.8	KB			08.01.2019						CM20097013 - Using member's latest enrollment in QNXT; Fix on RX allowed amount YT; Removed the update
--													to 0 out the YT rows (it's not needed)
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRY
	BEGIN TRANSACTION

		IF OBJECT_ID('TEMPDB..#MemberPlanYears') IS NOT NULL
		DROP TABLE #MemberPlanYears

		;WITH CTE AS
		(
			SELECT	EC.MemberID,					
					CASE	WHEN EK.EnrollID IS NULL OR LEN(LTRIM(RTRIM(BP.UPID))) NOT IN (9, 8) THEN EC.ContractCode
							ELSE LEFT(LTRIM(RTRIM(BP.UPID)), 5) 
					END AS ContractCode,
					CASE	WHEN EK.EnrollID IS NULL OR LEN(LTRIM(RTRIM(BP.UPID))) NOT IN (9, 8) THEN EC.PBPCode
							WHEN EK.EnrollID IS NOT NULL AND LEN(LTRIM(RTRIM(BP.UPID))) = 9 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 4)
							WHEN EK.EnrollID IS NOT NULL AND LEN(LTRIM(RTRIM(BP.UPID))) = 8 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 3) 
					END AS PBPCode,
					EC.QNXTPlanID,					
					ROW_NUMBER() OVER (PARTITION BY EC.MemberID ORDER BY EK.EffDate DESC, EK.TermDate DESC) AS RowNum					
			FROM	QNXT_Custom.EOB.EOB_Claim EC
			JOIN	Plandata_Prod.dbo.Member M
				ON	EC.MemberID = M.SecondaryID
			LEFT JOIN	Plandata_Prod.dbo.EnrollKeys EK
				ON	M.MemID = EK.MemID
				AND EK.SegType = 'INT'
			LEFT JOIN	Plandata_Prod.dbo.BenefitPlan BP
				ON	EK.PlanID = BP.PlanID
		)
		SELECT	DISTINCT CTE.MemberID,
							@RunYear AS IncurredYear,
							CTE.ContractCode,
							CTE.PBPCode,
							CTE.QNXTPlanID
		INTO	#MemberPlanYears
		FROM	CTE
		WHERE	CTE.RowNum = 1

		CREATE CLUSTERED INDEX IDX_MemberPlanYears ON #MemberPlanYears ( MemberID ASC, IncurredYear ASC, ContractCode ASC, PBPCode ASC, QNXTPlanID ASC )

		INSERT INTO QNXT_Custom.EOB.EOB_YearlyTotals_ClaimDetail (ProcessHeaderID, MemberID, ClaimID, ClaimLine, IncurredYear, ContractCode, PBPCode, ClaimAmt, AmountPaid,
															CoPay, CoPayPerDiemAmt, BeneDeduct, CoInsuranceAmt, Eligible, SubmitDiscount, PayDiscount, Par_Ind, IDN_Denied_Charge, QNXTPlanID, [Source])
		SELECT	 
			DISTINCT	@ProcessHeaderID AS ProcessHeaderID,
						MPY.MemberID,
						ISNULL(C.ClaimID, '') AS ClaimID,
						ISNULL(CD.ClaimLine, '') AS ClaimLine,
						@RunYear AS IncurredYear,
						MPY.ContractCode,
						MPY.PBPCode,
						ISNULL(CD.ClaimAmt, 0.00) AS ClaimAmt,
						ISNULL(CD.AmountPaid, 0.00) AS AmountPaid,
						ISNULL(CD.CoPay, 0.00) AS CoPay,
						ISNULL(CD.CoPayPerDiemAmt, 0.00) AS CoPayPerDiemAmt,
						ISNULL(CD.BeneDeduct, 0.00) AS BeneDeduct,
						ISNULL(CD.CoInsuranceAmt, 0.00) AS CoInsuranceAmt,
						CASE WHEN CD.[Status] IN ('OKAY', 'WARN') AND CD.capitated = 0 THEN ISNULL(CD.ContractPaid, 0.00)
								ELSE 0.00 END AS Eligible,
						CASE WHEN C.Status = 'REVERSED' THEN ISNULL(-1 * ABS(CD.SubmitDiscount), 0.00)
								ELSE ISNULL(ABS(CD.SubmitDiscount), 0.00) END AS SubmitDiscount,
						CASE WHEN C.Status = 'REVERSED' THEN ISNULL(-1 * ABS(CD.PayDiscount), 0.00)
								ELSE ISNULL(ABS(CD.PayDiscount), 0.00) END AS PayDiscount,
						'' AS Par_Ind,
						0.00 AS IDN_Denied_Charge,
						ISNULL(EK.PlanID, '') AS QNXTPlanID,
						'CL' AS [Source]		
		FROM		#MemberPlanYears MPY
		JOIN		Plandata_Prod.dbo.Member M
				ON	MPY.MemberID = M.SecondaryID
				AND M.SecondaryID <> '00000001'				
		LEFT JOIN	Plandata_Prod.dbo.Claim C
				ON	M.MemID = C.MemID
				AND C.PaidDate <= @EndDate
				AND YEAR(C.StartDate) = @RunYear
		LEFT JOIN	Plandata_Prod.dbo.ClaimDetail CD
				ON	C.ClaimID = CD.ClaimID
				AND C.[Status] IN ('PAID', 'DENIED', 'REVERSED')
		LEFT JOIN	Plandata_Prod.dbo.EnrollKeys EK
				ON	C.EnrollID = EK.EnrollID		
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_YearlyTotals_ClaimDetail REBUILD
		
		--Exclusion criteria
		DELETE	YCD				
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals_ClaimDetail YCD
		JOIN	Plandata_Prod.dbo.Claim C
			ON	YCD.ClaimID = C.ClaimID
		JOIN	Plandata_Prod.dbo.ClaimEdit CE
			ON	C.ClaimID = CE.ClaimID
		JOIN	QNXT_Custom.EOB.EOB_ExcludedDenialRemits EDR
			ON  EDR.Active = 1
			AND ((CE.Reason = EDR.ReasonID)
				OR (CE.EobID = EDR.ReasonID))
		WHERE	C.[Status] = 'DENIED'
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		DELETE	YCD		
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals_ClaimDetail YCD
		JOIN	Plandata_Prod.dbo.Claim C
			ON	YCD.ClaimID = C.ClaimID		
		JOIN	Plandata_Prod.dbo.ClaimEditMessage CEM
			ON	C.ClaimID = CEM.ClaimID								
		JOIN	QNXT_Custom.EOB.EOB_ExcludedDenialRemits EDR
			ON  EDR.Active = 1
			AND CEM.MessageID = EDR.ReasonID
		WHERE	C.[Status] = 'DENIED'
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		UPDATE  YCD
		SET	YCD.Par_Ind = CASE WHEN CE.RuleID = '6035' THEN 'P'
								WHEN CE.RuleID = '6036' THEN 'N'
								ELSE '' END
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals_ClaimDetail YCD
		JOIN	Plandata_Prod.dbo.Claim C
			ON  C.ClaimID = YCD.ClaimID
		JOIN	Plandata_Prod.dbo.ClaimDetail CD
			ON	C.ClaimID = CD.ClaimID
			AND	CD.ClaimLine = YCD.ClaimLine
			AND YCD.ClaimID <> ''
		JOIN	Plandata_Prod.dbo.ClaimEdit CE
			ON	C.ClaimID = CE.ClaimID
			AND CE.ClaimLine = 0
			AND CE.RuleID IN ('6035', '6036')
			AND YCD.[Source] = 'CL'
		WHERE	YCD.Par_Ind = ''

		UPDATE	YCD
			SET	YCD.Par_Ind = CASE WHEN CI.Contracted = 'Y' THEN 'P' 
									ELSE 'N' END
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals_ClaimDetail YCD			
		JOIN	Plandata_Prod.dbo.Claim C
			ON  C.ClaimID = YCD.ClaimID
		JOIN	Plandata_Prod.dbo.ClaimDetail CD
			ON	C.ClaimID = CD.ClaimID			
			AND	CD.ClaimLine = YCD.ClaimLine
			AND YCD.ClaimID <> ''
		JOIN	Plandata_Prod.dbo.EnrollKeys EK
			ON	C.EnrollID = EK.EnrollID
		LEFT JOIN	Plandata_Prod.dbo.ContractInfo CI
			ON C.affiliationid = CI.affiliationid
			AND EK.programid = CI.programid
			AND C.contractnetworkid = CI.networkid
			AND C.contractid= CI.contractid
			AND C.startdate BETWEEN CI.effdate AND CI.termdate
		WHERE	YCD.Par_Ind = ''
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		IF OBJECT_ID('TEMPDB..#Denial_Language_Ind') IS NOT NULL
		DROP TABLE #Denial_Language_Ind

		CREATE TABLE #Denial_Language_Ind
		(
			[ClaimID] VARCHAR(15),
			[ClaimLine] INT		
		)

		INSERT INTO #Denial_Language_Ind
		SELECT DISTINCT EC.ClaimID,
						CASE WHEN CE.ClaimLine = 0 THEN 0
								ELSE CD.ClaimLine END AS ClaimLine
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals_ClaimDetail EC
		JOIN	Plandata_Prod.dbo.Claim C
			ON	EC.ClaimID = C.ClaimID
			AND C.[status] <> 'REVERSED'
			AND	EC.[Source] = 'CL'
			AND EC.ClaimID <> ''
		JOIN	Plandata_Prod.[dbo].[claimdetail] CD
			ON	C.[claimid] = CD.[claimid]
		JOIN	Plandata_Prod.[dbo].[claimedit] CE
			ON	CD.[claimid] = CE.[claimid]
			AND ( CD.[claimline] = CE.[claimline] OR CE.ClaimLine = 0 )
		JOIN QNXT_Custom.EOB.[EOB_IDN_DenialLanguage] DL
			ON (CE.[reason] = DL.MessageID AND EC.Par_Ind = 'P' AND DL.[PAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
				 OR (CE.[reason] = DL.MessageID AND EC.Par_Ind = 'N' AND DL.[NONPAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
				 OR (CE.[eobid] = DL.MessageID AND EC.Par_Ind = 'P' AND DL.[PAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
				 OR (CE.[eobid] = DL.MessageID AND EC.Par_Ind = 'N' AND DL.[NONPAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		INSERT INTO #Denial_Language_Ind
		SELECT DISTINCT EC.ClaimID,
						CASE WHEN CE.ClaimLine = 0 THEN 0
								ELSE CD.ClaimLine END AS ClaimLine
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals_ClaimDetail EC
		JOIN	Plandata_Prod.dbo.Claim C
			ON	EC.ClaimID = C.ClaimID
			AND C.[status] <> 'REVERSED'
			AND	EC.[Source] = 'CL'
			AND EC.ClaimID <> ''
		JOIN	Plandata_Prod.[dbo].[claimdetail] CD
			ON	C.[claimid] = CD.[claimid]
		JOIN	Plandata_Prod.[dbo].[claimedit] CE
			ON	CD.[claimid] = CE.[claimid]
			AND ( CD.[claimline] = CE.[claimline] OR CE.ClaimLine = 0 )
		JOIN	Plandata_Prod.[dbo].[claimeditmessage] CEM
			ON	CE.[claimid] = CEM.[claimid]
			AND CE.[claimline] = CEM.[claimline]
			AND CE.[ruleid] = CEM.[ruleid]
		JOIN QNXT_Custom.EOB.[EOB_IDN_DenialLanguage] DL
			ON (CEM.MessageID = DL.MessageID AND EC.Par_Ind = 'P' AND DL.[PAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
				 OR (CEM.MessageID = DL.MessageID AND EC.Par_Ind = 'N' AND DL.[NONPAR] = 'Y' AND CE.[status] = DL.[status] AND ( CD.[status] = DL.[status] OR ( CE.ClaimLine = 0 AND C.[Status] = 'DENIED' ) ) )
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		CREATE CLUSTERED INDEX Idx_Denial_Language_Ind ON #Denial_Language_Ind ( ClaimID ASC, ClaimLine ASC )

		UPDATE	ECD
			SET	ECD.[IDN_Denied_Charge] = CD.ClaimAmt		
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals_ClaimDetail ECD
		JOIN	#Denial_Language_Ind DL
			ON	ECD.ClaimID = DL.ClaimID
			AND	(ECD.ClaimLine = DL.ClaimLine OR DL.ClaimLine = 0)
			AND ECD.ClaimID <> ''
		JOIN	Plandata_Prod.dbo.ClaimDetail CD
			ON	ECD.ClaimID = CD.ClaimID
			AND	ECD.ClaimLine = CD.ClaimLine
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		INSERT INTO QNXT_Custom.EOB.EOB_YearlyTotals ( ProcessHeaderID, MemberID, IncurredYear, ContractCode, PBPCode, Total_Charge, Discount, Deductible, CoPay, 
														CoInsurance, Other_Amount3, Other_Amount4, Flex_Med_Annual, [Source] )
		SELECT		@ProcessHeaderID AS ProcessHeaderID,
					CD.MemberID,
					@RunYear AS IncurredYear,
					CD.ContractCode,
					CD.PBPCode,
					CONVERT(NUMERIC(15, 2), SUM(ISNULL(CD.ClaimAmt, 0.00))) AS Total_Charge,
					CONVERT(NUMERIC(15, 2), SUM(ISNULL(CD.Eligible, 0.00))) AS Discount,
					CONVERT(NUMERIC(15, 2), SUM(ISNULL(CD.BeneDeduct, 0.00))) AS Deductible,
					CONVERT(NUMERIC(15, 2), SUM(ISNULL(CD.CoPay, 0.00) + ISNULL(CD.copayperdiemamt, 0.00))) AS CoPay,
					CONVERT(NUMERIC(15, 2), SUM(ISNULL(CD.CoInsuranceAmt, 0.00))) AS CoInsurance,					
					CONVERT(NUMERIC(15, 2), SUM(ISNULL(CD.AmountPaid, 0.00) + ISNULL(CD.SubmitDiscount, 0.00) + ISNULL(CD.PayDiscount, 0.00))) AS Other_Amount3,
					CONVERT(NUMERIC(15, 2), SUM(ISNULL(CD.AmountPaid, 0.00))) AS Other_Amount4,
					CONVERT(NUMERIC(15, 2), SUM(CASE WHEN ISNULL(CD.IDN_Denied_Charge, 0.00) > 0.00 THEN ISNULL(CD.IDN_Denied_Charge, 0.00)
														ELSE ISNULL(CD.BeneDeduct, 0.00) + ISNULL(CD.CoPay, 0.00) + ISNULL(CD.copayperdiemamt, 0.00) + ISNULL(CD.CoInsuranceAmt, 0.00) END)) AS Flex_Med_Annual,
					'CL' AS [Source]
		FROM		QNXT_Custom.EOB.EOB_YearlyTotals_ClaimDetail CD
		GROUP BY CD.MemberID, CD.ContractCode, CD.PBPCode
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		INSERT INTO QNXT_Custom.EOB.EOB_YearlyTotals ( ProcessHeaderID, MemberID, IncurredYear, ContractCode, PBPCode, Total_Charge, Discount, Deductible, CoPay, 
														CoInsurance, Other_Amount3, Other_Amount4, Flex_Med_Annual, [Source] )
		SELECT
				@ProcessHeaderID AS ProcessHeaderID,
				MPY.MemberID AS MemberID,
				@RunYear AS IncurredYear,
				MPY.ContractCode,
				MPY.PBPCode,
				CONVERT(NUMERIC(15, 2), SUM(ISNULL(RX.BilledAmount, 0.00))) AS Total_Charge,
				CONVERT(NUMERIC(15, 2), SUM(ISNULL(RX.ApprovedAmount, 0.00) + ISNULL(RX.CopayAmount, 0.00) + ISNULL(RX.CoinsuranceAmount, 0.00) + ISNULL(RX.DeductibleAmount, 0.00))) AS Discount,
				CONVERT(NUMERIC(15, 2), SUM(ISNULL(RX.DeductibleAmount, 0.00))) AS Deductible,
				CONVERT(NUMERIC(15, 2), SUM(ISNULL(RX.CopayAmount, 0.00))) AS CoPay,
				CONVERT(NUMERIC(15, 2), SUM(ISNULL(RX.CoinsuranceAmount, 0.00))) AS CoInsurance,				
				CONVERT(NUMERIC(15, 2), SUM(ISNULL(RX.ApprovedAmount, 0.00))) AS Other_Amount3,
				CONVERT(NUMERIC(15, 2), SUM(ISNULL(RX.ApprovedAmount, 0.00))) AS Other_Amount4,
				CONVERT(NUMERIC(15, 2), SUM(ISNULL(RX.CopayAmount, 0.00) + ISNULL(RX.CoinsuranceAmount, 0.00) + ISNULL(RX.DeductibleAmount, 0.00))) AS Flex_Med_Annual, 			 
				'RX' AS [Source]		
		FROM		#MemberPlanYears MPY
		LEFT JOIN	QNXT_Custom.EOB.EOB_PartBPharmacy_Archive RX 				
				ON	MPY.MemberID = CASE WHEN LTRIM(RTRIM(LEN(RX.MemberID))) > 10  AND LEFT(LTRIM(RTRIM(RX.MemberID)), 1) <> 'U' THEN CAST(STUFF(LTRIM(RTRIM(RX.MemberID)), LEN(LTRIM(RTRIM(RX.MemberID))) - 1, 0, '*') AS VARCHAR(20))
							ELSE CAST(LTRIM(RTRIM(RX.MemberID)) AS VARCHAR(20)) END
				AND MPY.IncurredYear = LEFT(RX.BeginServiceDate, 4)
				AND MPY.ContractCode = RX.ContractCode
				AND MPY.PBPCode = RX.PBPCode		
				AND RX.PaidDate <= CONVERT(VARCHAR(10), @EndDate, 112)
		GROUP BY MPY.MemberID, MPY.ContractCode, MPY.PBPCode
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_YearlyTotals REBUILD

		--Reset member plan on YT to be the member's most recent plan
		UPDATE	YT
			SET	YT.ContractCode = MPY.ContractCode,
				YT.PBPCode = MPY.PBPCode
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals YT
		JOIN	#MemberPlanYears MPY
			ON	YT.MemberID = MPY.MemberID

		IF OBJECT_ID('TEMPDB..#YealyTotals_Updates') IS NOT NULL
		DROP TABLE #YealyTotals_Updates

		SELECT DISTINCT
				YT.MemberID,
				YT.IncurredYear,
				YT.ContractCode,
				YT.PBPCode,
				CONVERT(NUMERIC(15, 2), MAX(ISNULL(EM.InDeductPaid, 0.00)) + MAX(ISNULL(EM.OutDeductPaid, 0.00))) AS OOP_Deductible,
				CASE WHEN MAX(ISNULL(EP.ServiceCategoryDeduct, 0.00)) <> 0.00 THEN MAX(ISNULL(EP.ServiceCategoryDeduct, 0.00))
						WHEN MAX(ISNULL(EP.PlanType, '')) = 'PPO' AND MAX(ISNULL(EM.OutNetworkDeductible, 0.00)) <> 0.00 THEN CONVERT(NUMERIC(15, 2), MAX(ISNULL(EM.OutNetworkDeductible, 0.00)))
						WHEN MAX(ISNULL(EP.PlanType, 'PPO')) <> 'PPO' AND MAX(ISNULL(EM.InNetworkDeductible, 0.00)) <> 0.00 THEN CONVERT(NUMERIC(15, 2), MAX(ISNULL(EM.InNetworkDeductible, 0.00)))
						ELSE '0.00' END AS Open_Field6,
				0.00 AS Open_Field7,
				MAX(ISNULL(EP.ServiceCategory, 0)) AS Flex_Med_YTD_Contributions
		INTO	#YealyTotals_Updates
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals YT
		JOIN	#MemberPlanYears MPY
			ON	YT.MemberID = MPY.MemberID
			AND	YT.IncurredYear = MPY.IncurredYear
			AND YT.ContractCode = MPY.ContractCode
			AND YT.PBPCode = MPY.PBPCode
		LEFT JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	YT.IncurredYear = EP.PlanYear
			AND	YT.ContractCode = EP.ContractCode
			AND	YT.PBPCode = EP.PBPCode
			AND (EP.GroupPlanID = '' OR MPY.QNXTPlanID = EP.GroupPlanID)
			AND EP.Active = 1			
		LEFT JOIN	QNXT_Custom.EOB.EOB_MOOP EM
			ON	YT.MemberID = EM.MemberID
			AND	YT.ContractCode + YT.PBPCode = EM.UPID
			AND	LEFT(EM.MinMemberEffectiveDate, 4) = YT.IncurredYear		
		GROUP BY YT.MemberID, YT.IncurredYear, YT.ContractCode, YT.PBPCode

		UPDATE	YT 
			SET	YT.OOP_Deductible = YTU.OOP_Deductible,
				YT.Open_Field6 = YTU.Open_Field6,
				YT.Open_Field7 = YTU.Open_Field7,
				YT.Flex_Med_YTD_Contributions = YTU.Flex_Med_YTD_Contributions
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals YT
		JOIN	#YealyTotals_Updates YTU
			ON	YT.MemberID = YTU.MemberID
			AND	YT.IncurredYear = YTU.IncurredYear
			AND	YT.ContractCode = YTU.ContractCode
			AND	YT.PBPCode = YTU.PBPCode	
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		UPDATE	YT
			SET	YT.Flex_Med_YTD_Contributions = 0
		FROM	QNXT_Custom.EOB.EOB_YearlyTotals YT
		WHERE	YT.Flex_Med_YTD_Contributions IS NULL 
			OR	YT.Flex_Med_YTD_Contributions = ''
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO