CREATE PROCEDURE [EOB].[Update_EOB_PartBPharmacy_Archive] AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON
/*
####################################################################################
-- Name:			Update_EOB_PartBPharmacy_Archive_Table.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Updates the EOB_PartBPharmacy_Archive table.
-- 
-- Called by:		N/A
####################################################################################
-- Parameters
--     N/A
####################################################################################
-- Ver  User		Date				US#		Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
####################################################################################
*/

BEGIN TRY
	BEGIN TRANSACTION

		UPDATE RX SET
			RX.ClaimID = US.ClaimID,
			RX.MemberID = US.MemberID,
			RX.ClaimStatus = US.ClaimStatus,
			RX.CurrentEligibiltyStatus = US.CurrentEligibiltyStatus,
			RX.PaidDate = US.PaidDate,
			RX.BeginServiceDate = US.BeginServiceDate,
			RX.EndServiceDate = US.EndServiceDate,
			RX.NDC = US.NDC,
			RX.NDCDesc = US.NDCDesc,
			RX.ProviderName = US.ProviderName,
			RX.ProviderID = US.ProviderID,
			RX.BilledAmount = US.BilledAmount,
			RX.DeductibleAmount = US.DeductibleAmount,
			RX.CopayAmount = US.CopayAmount,
			RX.CoinsuranceAmount = US.CoinsuranceAmount,
			RX.TDC = US.TDC,
			RX.PatientPay = US.PatientPay,
			RX.OtherPay = US.OtherPay,
			RX.ApprovedAmount = US.ApprovedAmount,
			RX.Active = US.Active,
			RX.LoadDate = US.LoadDate,
			RX.LastUpdateKey = US.LastUpdateKey,
			RX.SourceDataKey = US.SourceDataKey,
			RX.ContractCode = US.ContractCode,
			RX.PBPCode = US.PBPCode,
			RX.Tier = US.Tier
		FROM QNXT_Custom.EOB.EOB_PartBPharmacy_Archive RX WITH (NOLOCK)
		JOIN QNXT_Custom.EOB.EOB_PartBPharmacy_UpdateStaging US WITH (NOLOCK)
			ON RX.ClaimID = US.ClaimID
			AND RX.MemberID = US.MemberID

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
