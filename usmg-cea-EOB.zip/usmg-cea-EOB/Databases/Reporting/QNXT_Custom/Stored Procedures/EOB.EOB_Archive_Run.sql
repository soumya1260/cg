CREATE PROCEDURE [EOB].[EOB_Archive_Run] (@VerboseLogging INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON
/*
##################################################################################################################################################
-- Name:			EOB_Archive_Run.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Archives the previous run of EOB data
-- 
-- Called by:		N/A
##################################################################################################################################################
-- Parameters
--     N/A
##################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
##################################################################################################################################################
*/
BEGIN TRY
IF @VerboseLogging = 1
	BEGIN
		BEGIN TRAN
			
			INSERT INTO QNXT_Custom.EOB.EOB_Claim_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_Claim WITH (NOLOCK)

			INSERT INTO QNXT_Custom.EOB.EOB_ClaimDetail_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_ClaimDetail WITH (NOLOCK)

			INSERT INTO QNXT_Custom.EOB.EOB_YearlyTotals_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_YearlyTotals WITH (NOLOCK)

			INSERT INTO QNXT_Custom.EOB.EOB_0001MasterDeliv_Archive
			SELECT	* 
			FROM	QNXT_Custom.EOB.EOB_0001MasterDeliv WITH (NOLOCK)

			INSERT INTO QNXT_Custom.EOB.EOB_0002EOB_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_0002EOB WITH (NOLOCK)

			INSERT INTO QNXT_Custom.EOB.EOB_0003ServiceLine_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_0003ServiceLine WITH (NOLOCK)

			INSERT INTO QNXT_Custom.EOB.EOB_0004TotalLine_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_0004TotalLine WITH (NOLOCK)

			INSERT INTO QNXT_Custom.EOB.EOB_0004ZZSegment_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_0004ZZSegment WITH (NOLOCK)

			INSERT INTO QNXT_Custom.EOB.EOB_0005Comments_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_0005Comments WITH (NOLOCK)

			INSERT INTO QNXT_Custom.EOB.EOB_0008Accumulator_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_0008Accumulator WITH (NOLOCK)

			;WITH CTE AS
			(
				SELECT	EF.ClaimType, EF.ClaimID, EF.MemberID, EF.ReasonID, EF.[Source], ROW_NUMBER() OVER ( PARTITION BY EF.ClaimID, EF.[Source] ORDER BY EF.ReasonID DESC ) AS RowNum
				FROM	QNXT_Custom.EOB.EOB_Fallout EF WITH (NOLOCK)
				JOIN	(
							SELECT	ClaimID, [Source]			
							FROM	QNXT_Custom.EOB.EOB_Fallout WITH (NOLOCK)
							GROUP BY ClaimId, [Source]
							HAVING COUNT(1) > 1
						) DUP
					ON	EF.ClaimID = DUP.ClaimId
					AND EF.[Source] = DUP.[Source]
			)
			DELETE	EF			
			FROM	QNXT_Custom.EOB.EOB_Fallout EF
			JOIN	CTE
				ON	EF.ClaimType = CTE.ClaimType
				AND	EF.ClaimId = CTE.ClaimId
				AND	EF.MemberID = CTE.MemberID
				AND	EF.ReasonID = CTE.ReasonID
				AND EF.[Source] = CTE.[Source]
			WHERE	CTE.RowNum > 1

			INSERT INTO QNXT_Custom.EOB.EOB_Fallout_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_Fallout WITH (NOLOCK)

			INSERT INTO QNXT_Custom.EOB.EOB_Output_Archive
			SELECT	*
			FROM	QNXT_Custom.EOB.EOB_Output WITH (NOLOCK)

		COMMIT TRAN
	END

END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION
	
	;THROW
END CATCH
GO
