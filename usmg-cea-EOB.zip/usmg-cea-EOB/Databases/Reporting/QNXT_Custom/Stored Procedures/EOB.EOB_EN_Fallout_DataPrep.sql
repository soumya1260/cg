CREATE PROCEDURE [EOB].[EOB_EN_Fallout_DataPrep] AS
SET XACT_ABORT, NOCOUNT ON
/*
####################################################################################
-- Name:			EOB_EN_Fallout_DataPrep.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
####################################################################################
-- Parameters
--     N/A
####################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
####################################################################################
*/
BEGIN TRY	
		
		IF OBJECT_ID('TEMPDB..#EN_Fallout') IS NOT NULL
		DROP TABLE #EN_Fallout

		CREATE TABLE #EN_Fallout 
		(	
			ClaimID VARCHAR(20),
			MemberID VARCHAR(16),
			[Source] VARCHAR(60),
			LoadDate DATETIME,
			PaidMonth INT,
			BeginServiceDate DATE,
			ReasonID INT DEFAULT 0,
			[Status] VARCHAR(10) 
		)

		INSERT #EN_Fallout ( ClaimID, MemberID, [Source], LoadDate, PaidMonth, BeginServiceDate, ReasonID, [Status] )
		SELECT DISTINCT ERS.ClaimID,
						ERS.MemberID,
						ERS.[Source],
						'1/1/1980' AS LoadDate,
						'0' AS PaidMonth,
						'1/1/1980' AS BeginServiceDate,
						0 AS ReasonID,
						'' AS [Status]
		FROM	QNXT_Custom.EOB.EOB_Run_Staging ERS WITH (NOLOCK)
		LEFT OUTER JOIN QNXT_Custom.EOB.EOB_Recon ER WITH (NOLOCK)
			ON	ERS.ClaimID = ER.ClaimID
			AND ERS.[Source] = ER.[Source]
		WHERE	ER.ClaimID IS NULL
		  AND	ERS.[Source] NOT IN ( 'CL', 'RX' )

		SELECT
			ClaimID, 
			MemberID, 
			[Source], 
			LoadDate,
			PaidMonth, 
			BeginServiceDate, 
			ReasonID, 
			[Status]
		FROM	#EN_Fallout

END TRY

BEGIN CATCH
THROW;
END CATCH

GO
