CREATE PROCEDURE [EOB].[EOB_Reset_Start_End_Dates] AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Reset_Start_End_Dates.sql
-- Date:			09.17.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Stage Yearly Totals for CL and RX claims
-- 
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KB          09.17.2018			203876		Initial release
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	
	SELECT
		MIN(BeginDate) AS BeginDate,
		MIN(EndDate) AS EndDate
	FROM QNXT_Custom.EOB.EOB_Run_Master WITH (NOLOCK)
	WHERE CAST(RunDate AS DATE) = CAST(GETDATE() AS DATE)
	AND ProcessHeaderID IN ('', 0)
	AND [Status] = 'READY'

END TRY

BEGIN CATCH
	;THROW
END CATCH

GO
