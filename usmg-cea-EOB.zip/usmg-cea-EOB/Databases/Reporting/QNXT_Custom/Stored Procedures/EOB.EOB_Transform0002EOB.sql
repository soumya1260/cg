CREATE PROCEDURE [EOB].[EOB_Transform0002EOB] (@BeginDate DATE, @EndDate DATE, @ProcessHeaderID INT, @RunYear INT) AS

/*
###########################################################################################################################################################
-- Name:			EOB_Transform0002EOB.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			07.17.2018			215695		Updated the join to be inner instead of left on EOB.EOB_MOOP table (CM20020172)
-- 1.3  KB			08.13.2018			215695		Updated logic to set the FormLetter_ID as the first 3 characters of EOB.EOB_Plans.PlanType (CM20025799)
-- 1.4	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
-- 1.5	KB			08.01.2019						CM20097013 - Using member's latest enrollment in QNXT; WYMBB changes
###########################################################################################################################################################
*/

TRUNCATE TABLE EOB.EOB_0002EOB

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		INSERT INTO QNXT_Custom.EOB.EOB_0002EOB (ProcessHeaderID, Insured_PolicyNumber, Claim_Number, Open_Field3, Paid_Date, Group_Name1, Copy_Number, FormLetter_Provider_Name, FormLetter_ID, Check_Amount,
													Open_Field1, Open_Field2, Open_Field4, Open_Field5, Open_Field6, Open_Field9, Open_Field11, Open_Field12, Open_Field13, Open_Field14, Open_Field15, Open_Field16, 
													Open_Field21, Open_Field22, Open_Field24, Open_Field25, IncurredYear, MemberPlan, ServiceCategory, [Source])
		SELECT DISTINCT
					@ProcessHeaderID AS ProcessHeaderID,
					EC.MemberID AS Insured_PolicyNumber,
					EC.ClaimID AS Claim_Number,
					EC.ClaimType AS Open_Field3,
					CONVERT(VARCHAR(8), EC.PaidDate, 112) AS Paid_Date,
					'Cigna-HealthSpring' AS Group_Name1,
					'01' AS Copy_Number,
					LEFT(LTRIM(RTRIM(EC.ProviderName)), 40) AS FormLetter_Provider_Name,
					'' AS FormLetter_ID,
					EC.PaidAmount AS Check_Amount,
					ISNULL(EM.InMOOPPaid, 0.00) AS Open_Field1,
					ISNULL(EM.InMOOPPaid, 0.00) + ISNULL(EM.OutMOOPPaid, 0.00) AS Open_Field2,
					EC.Par_Ind AS Open_Field4,
					CASE WHEN ML.[Description] LIKE '%SPANISH%' THEN CONVERT(VARCHAR, DATEADD(MONTH, DATEDIFF(MONTH, 0, EC.PaidDate), 0), 103)
							ELSE CONVERT(VARCHAR, DATEADD(MONTH, DATEDIFF(MONTH, 0, EC.PaidDate), 0), 101) END AS Open_Field5,
					CASE WHEN ML.[Description] LIKE '%SPANISH%' THEN CONVERT(VARCHAR, DATEADD(MONTH, DATEDIFF(MONTH, -1, EC.PaidDate), -1), 103)
							ELSE CONVERT(VARCHAR, DATEADD(MONTH, DATEDIFF(MONTH, -1, EC.PaidDate), -1), 101) END AS Open_Field6,
					CASE WHEN ML.LanguageID IS NOT NULL THEN LEFT(LTRIM(RTRIM(ML.[Description])), 50)
							ELSE 'ENGLISH' END AS Open_Field9,
					'Bravo Health' AS Open_Field11,
					'Claims Department' AS Open_Field12,
					'PO Box 4432' AS Open_Field13,
					'Baltimore MD 21223' AS Open_Field14,
					'' AS Open_Field15,
					'' AS Open_Field16,
					ISNULL(EM.InNetworkMOOP, 0.00) AS Open_Field21,
					'' AS Open_Field22,
					IIF(ISNULL(EM.InNetworkMOOP, 0.00) > ISNULL(EM.OutNetworkMOOP, 0.00), ISNULL(EM.InNetworkMOOP, 0.00), ISNULL(EM.OutNetworkMOOP, 0.00)) AS Open_Field24,
					LTRIM(RTRIM(EC.ProviderName)) AS Open_Field25,
					YEAR(EC.BeginServiceDate) AS IncurredYear,
					LTRIM(RTRIM(EC.ContractCode)) + LTRIM(RTRIM(EC.PBPCode)) AS MemberPlan,
					0 AS ServiceCategory,
					EC.[Source]		
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	Plandata_Prod.dbo.Member M
			ON	EC.MemberID = M.SecondaryID			
		LEFT JOIN	QNXT_Custom.EOB.EOB_MOOP EM
			ON	LTRIM(RTRIM(EC.MemberID)) = LTRIM(RTRIM(EM.MemberID))
			AND	LTRIM(RTRIM(EC.ContractCode)) + LTRIM(RTRIM(EC.PBPCode)) = LTRIM(RTRIM(EM.UPID))
			AND CAST(CONVERT(VARCHAR(8), EC.BeginServiceDate, 112) AS INT) BETWEEN EM.MinMemberEffectiveDate AND EM.MaxMemberEffectiveDate
		LEFT JOIN	QNXT_Custom.EOB.EOB_MemberLanguageXref ML
			ON M.PrimaryLanguage = ML.LanguageID
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_0002EOB REBUILD

		--Update retro-termed claims
		UPDATE	E02
			SET E02.Open_Field1 = EM.InMOOPPaid,
				E02.Open_Field2 = EM.OutMOOPPaid,	
				E02.Open_Field21 = EM.InNetworkMOOP,
				E02.Open_Field24 = EM.OutNetworkMOOP,
				E02.MemberPlan = EM.UPID		
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	Plandata_Prod.dbo.Claim C
			ON	E02.Claim_Number = C.ClaimID
		JOIN	Plandata_Prod.dbo.EnrollKeys EK
			ON	C.EnrollID = EK.EnrollID
			AND C.PaidDate > EK.TermDate
		JOIN	Plandata_Prod.dbo.BenefitPlan BP
			ON	EK.PlanID = BP.PlanID
		JOIN	QNXT_Custom.EOB.EOB_MOOP EM
			ON	E02.Insured_PolicyNumber = EM.MemberID 
			AND BP.UPID = EM.UPID
			AND YEAR(C.StartDate) = LEFT(EM.MinMemberEffectiveDate, 4)
		WHERE	C.EnrollID <> ''			
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		DELETE	E02
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02 
		WHERE	E02.MemberPlan IS NULL
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		IF OBJECT_ID('TEMPDB..#MemberPlanYears') IS NOT NULL
		DROP TABLE #MemberPlanYears

		;WITH CTE AS
		(
			SELECT	EC.MemberID,					
					CASE	WHEN EK.EnrollID IS NULL OR LEN(LTRIM(RTRIM(BP.UPID))) NOT IN (9, 8) THEN EC.ContractCode
							ELSE LEFT(LTRIM(RTRIM(BP.UPID)), 5) 
					END AS ContractCode,
					CASE	WHEN EK.EnrollID IS NULL OR LEN(LTRIM(RTRIM(BP.UPID))) NOT IN (9, 8) THEN EC.PBPCode
							WHEN EK.EnrollID IS NOT NULL AND LEN(LTRIM(RTRIM(BP.UPID))) = 9 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 4)
							WHEN EK.EnrollID IS NOT NULL AND LEN(LTRIM(RTRIM(BP.UPID))) = 8 THEN RIGHT(LTRIM(RTRIM(BP.UPID)), 3) 
					END AS PBPCode,
					EC.QNXTPlanID,
					EC.Is_PartD,
					CASE	WHEN EP.PlanType LIKE '%HMO%' THEN 'HMO'
							ELSE LTRIM(RTRIM(EP.PlanType)) 
					END AS FormLetter_ID,					
					CASE	WHEN BP.PlanID IS NOT NULL AND CAST(BP.[longdescription] AS VARCHAR(4000)) <> '' AND CAST(BP.[longdescription] AS VARCHAR(4000)) NOT LIKE '%*%' THEN LEFT(LTRIM(RTRIM(CAST(BP.[longdescription] AS VARCHAR(4000)))), 80)
							WHEN BP.PlanID IS NOT NULL AND BP.[Description] LIKE '%(%' THEN LEFT(LTRIM(RTRIM(SUBSTRING(BP.[Description], 0, CHARINDEX('(', BP.[Description])))) + ' (' + LTRIM(RTRIM(EP.PlanType)) + ')', 80) 
							WHEN BP.PlanID IS NOT NULL AND BP.[Description] NOT LIKE '%(%' THEN LEFT(LTRIM(RTRIM(BP.[Description])) + ' (' + LTRIM(RTRIM(EP.PlanType)) + ')', 80) 
							WHEN CAST(BPN.[longdescription] AS VARCHAR(4000)) <> '' AND CAST(BPN.[longdescription] AS VARCHAR(4000)) NOT LIKE '%*%' THEN LEFT(LTRIM(RTRIM(CAST(BPN.[longdescription] AS VARCHAR(4000)))), 80)
							WHEN BPN.[Description] LIKE '%(%' THEN LEFT(LTRIM(RTRIM(SUBSTRING(BPN.[Description], 0, CHARINDEX('(', BPN.[Description])))) + ' (' + LTRIM(RTRIM(EP.PlanType)) + ')', 80) 
							WHEN BPN.[Description] NOT LIKE '%(%' THEN LEFT(LTRIM(RTRIM(BPN.[Description])) + ' (' + LTRIM(RTRIM(EP.PlanType)) + ')', 80) 
							ELSE '' 
					END AS Open_Field16,
					CASE	WHEN ML.[Description] LIKE '%SPANISH%' AND EP.Copay = 'Y' AND EP.CoInsurance <> 'Y' AND EP.Deductible <> 'Y' 
								THEN ' y copagos'
							WHEN EP.Copay = 'Y' AND EP.CoInsurance <> 'Y' AND EP.Deductible <> 'Y'
								THEN ' and copays'
							WHEN ML.[Description] LIKE '%SPANISH%' AND EP.Copay = 'Y' AND EP.CoInsurance = 'Y' AND EP.Deductible <> 'Y' 
								THEN ', copagos y coseguro'
							WHEN EP.Copay = 'Y' AND EP.CoInsurance = 'Y' AND EP.Deductible <> 'Y'
								THEN ', copays and coinsurance'
							WHEN ML.[Description] LIKE '%SPANISH%' AND EP.Copay = 'Y' AND EP.CoInsurance <> 'Y' AND EP.Deductible = 'Y' 
								THEN ', copagos y su deducible'
							WHEN EP.Copay = 'Y' AND EP.CoInsurance <> 'Y' AND EP.Deductible = 'Y' 
								THEN ', copays and your deductible'
							WHEN ML.[Description] LIKE '%SPANISH%' AND EP.Copay = 'Y' AND EP.CoInsurance = 'Y' AND EP.Deductible = 'Y' 
								THEN ', copagos, coseguro y su deducible'
							WHEN EP.Copay = 'Y' AND EP.CoInsurance = 'Y' AND EP.Deductible = 'Y' 
								THEN ', copays, coinsurance and your deductible'
							WHEN ML.[Description] LIKE '%SPANISH%' AND EP.Copay <> 'Y' AND EP.CoInsurance = 'Y' AND EP.Deductible = 'Y' 
								THEN ', coseguro y su deducible'
							WHEN EP.Copay <> 'Y' AND EP.CoInsurance = 'Y' AND EP.Deductible = 'Y' 
								THEN ', coinsurance and your deductible'
							WHEN ML.[Description] LIKE '%SPANISH%' AND EP.Copay <> 'Y' AND EP.CoInsurance = 'Y' AND EP.Deductible <> 'Y' 
								THEN ' y coseguro'
							WHEN EP.Copay <> 'Y' AND EP.CoInsurance = 'Y' AND EP.Deductible <> 'Y' 
								THEN ' and coinsurance'
							WHEN ML.[Description] LIKE '%SPANISH%' AND EP.Copay <> 'Y' AND EP.CoInsurance <> 'Y' AND EP.Deductible = 'Y' 
								THEN ' y su deducible'
							WHEN EP.Copay <> 'Y' AND EP.CoInsurance <> 'Y' AND EP.Deductible = 'Y' 
								THEN ' and your deductible'
							ELSE ' ' END AS Open_Field22,
					EP.ServiceCategory AS ServiceCategory,
					ROW_NUMBER() OVER ( PARTITION BY EC.MemberID ORDER BY EK.EffDate DESC, EK.TermDate DESC ) AS RowNum
			FROM	QNXT_Custom.EOB.EOB_Claim EC
			JOIN	Plandata_Prod.dbo.Member M
				ON	EC.MemberID = M.SecondaryID							
			JOIN	QNXT_Custom.EOB.EOB_Plans EP
				ON	EC.ContractCode = EP.ContractCode
				AND EC.PBPCode = EP.PBPCode
				AND YEAR(EC.BeginServiceDate) = EP.PlanYear
				AND (EP.GroupPlanID = '' OR EC.QNXTPlanID = EP.GroupPlanID)
				AND EP.Active = 1
			JOIN	Plandata_Prod.dbo.BenefitPlan BPN
				ON	EC.QNXTPlanID = BPN.PlanID
			LEFT JOIN	QNXT_Custom.EOB.EOB_MemberLanguageXref ML
				ON M.PrimaryLanguage = ML.LanguageID
			LEFT JOIN	Plandata_Prod.dbo.EnrollKeys EK
				ON	M.MemID = EK.MemID
				AND EK.SegType = 'INT'
			LEFT JOIN	Plandata_Prod.dbo.BenefitPlan BP
				ON	EK.PlanID = BP.PlanID
		)
		SELECT	DISTINCT CTE.MemberID,
							@RunYear AS IncurredYear,
							CTE.ContractCode,
							CTE.PBPCode,
							CTE.QNXTPlanID,
							CTE.Is_PartD,
							CTE.FormLetter_ID,
							CTE.Open_Field16,
							CTE.Open_Field22,
							CTE.ServiceCategory
		INTO	#MemberPlanYears
		FROM	CTE
		WHERE	CTE.RowNum = 1

		CREATE CLUSTERED INDEX IDX_MemberPlanYears ON #MemberPlanYears ( MemberID ASC, IncurredYear ASC, ContractCode ASC, PBPCode ASC, QNXTPlanID ASC, Is_PartD ASC, FormLetter_ID ASC, Open_Field16 ASC, Open_Field22 ASC )

		--CHC use the first 02 record to pull the PlanType, PartD indicator and Plan description
		UPDATE	E02
			SET	E02.FormLetter_ID = MPY.FormLetter_ID,
				E02.Open_Field15 = MPY.Is_PartD,
				E02.Open_Field16 = MPY.Open_Field16,
				E02.Open_Field22 = MPY.Open_Field22,
				E02.ServiceCategory = MPY.ServiceCategory
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	#MemberPlanYears MPY
			ON	E02.Insured_PolicyNumber = MPY.MemberID		
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
IF @@TRANCOUNT > 0
	ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO