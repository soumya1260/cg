CREATE PROCEDURE [EOB].[EOB_Calc_MOOP] (@BeginDate DATETIME, @EndDate DATETIME, @ENMinDOS DATETIME) AS
SET XACT_ABORT, NOCOUNT ON

/*
#####################################################################################################################################################
-- Name:			EOB_Calc_MOOP.sql
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Stored Procedure to run MOOP
--
-- Called by:		NA
#####################################################################################################################################################
-- Parameters
--     
#####################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2  KB			09.04.2018			215695		Update to add MOOP for members that switched plans in the same year (CM20029812)
-- 1.3  KB			09.11.2018			215695		Added clustered index on #BaseMembers (CM20031271)
#####################################################################################################################################################
*/ 

DECLARE @YearBegin DATETIME
DECLARE @MinPlanEffDate DATE
DECLARE @MinClaimDOS DATETIME

ALTER INDEX ALL ON QNXT_Custom.EOB.EOB_MOOP DISABLE
TRUNCATE TABLE QNXT_Custom.EOB.EOB_MOOP

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRAN	

		SELECT	@MinPlanEffDate = MIN(EP.effdate)
		FROM	QNXT_Custom.EOB.EOB_Plans EP
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		SELECT	@MinClaimDOS = MIN(C.startdate)
		FROM	Plandata_Prod.dbo.claim C
		WHERE	C.PaidDate BETWEEN @BeginDate AND @EndDate
			AND	C.Status IN ( 'PAID', 'DENIED', 'REVERSED' )
			AND C.startdate >= @MinPlanEffDate
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		IF @MinClaimDOS <= @ENMinDOS
			BEGIN
				SELECT @YearBegin = @MinClaimDOS
			END
		ELSE
			BEGIN
				SELECT @YearBegin = @ENMinDOS
			END

		SELECT @YearBegin = DATEADD(YY, DATEDIFF(YY, 0, @YearBegin), 0)

		IF OBJECT_ID('tempdb.dbo.#BaseMembers') IS NOT NULL
		DROP TABLE #BaseMembers

		SELECT DISTINCT MemberID AS SecondaryID
		INTO #BaseMembers
		FROM	QNXT_Custom.EOB.EOB_Run_Staging
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		CREATE CLUSTERED INDEX IDX_C_BaseMembers 
		ON #BaseMembers (SecondaryID ASC)

		--Rolling up the accumulations for members who are not enrolled in Group plans
		;WITH Reg_Plan AS
		(
		SELECT DISTINCT EK.EnrollID AS EnrollID,
						BM.SecondaryID AS MemberID,
						ISNULL(BP.upid, '') AS UPID,
						CAST(CONVERT(VARCHAR(10), MIN(EK.effdate) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, EK.enrollid ORDER BY EK.effdate ASC), 112) AS INT) AS MinMemberEffectiveDate,
						CAST(CONVERT(VARCHAR(10), MAX(EK.termdate) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, EK.enrollid ORDER BY EK.effdate ASC), 112) AS INT) AS MaxMemberEffectiveDate,
						EP.InDeduct AS InNetworkDeductible,
						EP.INMOOP AS InNetworkMOOP,
						EP.OONDeduct AS OutNetworkDeductible,
						EP.OONMOOP AS OutNetworkMOOP,
						CASE WHEN Q_MOOP.accum_type = 'In' THEN SUM(ISNULL(Q_MOOP.benededuct, 0.00)) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid) 
								ELSE '0.00' END AS InDeductPaid,
						CASE WHEN Q_MOOP.accum_type = 'In' AND FRX_MOOP.accum_type IS NULL
													THEN SUM(ISNULL(Q_MOOP.copay, 0.00) + 
																ISNULL(Q_MOOP.benededuct, 0.00) + 
																ISNULL(Q_MOOP.coinsuranceamt, 0.00) + 
																ISNULL(Q_MOOP.copayperdiemamt, 0.00))  OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid)
								WHEN Q_MOOP.accum_type IS NULL AND FRX_MOOP.accum_type = 'In'
													THEN MAX(FRX_MOOP.accumvalue) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, FRX_MOOP.accumid, EK.enrollid)
								WHEN Q_MOOP.accum_type = 'In' AND FRX_MOOP.accum_type = 'In' AND Q_MOOP.enrollid = FRX_MOOP.enrollid 
													THEN SUM(ISNULL(Q_MOOP.copay, 0.00) + 
																ISNULL(Q_MOOP.benededuct, 0.00) + 
																ISNULL(Q_MOOP.coinsuranceamt, 0.00) + 
																ISNULL(Q_MOOP.copayperdiemamt, 0.00))  OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid) +								
																MAX(FRX_MOOP.accumvalue) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, FRX_MOOP.accumid, EK.enrollid)						
								ELSE '0.00' END AS InMOOPPaid,
						CASE WHEN Q_MOOP.accum_type = 'Out' THEN SUM(ISNULL(Q_MOOP.benededuct, 0.00)) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid) 
								ELSE '0.00' END AS OutDeductPaid,
						CASE WHEN Q_MOOP.accum_type = 'Out' AND FRX_MOOP.accum_type IS NULL
													THEN SUM(ISNULL(Q_MOOP.copay, 0.00) + 
																ISNULL(Q_MOOP.benededuct, 0.00) + 
																ISNULL(Q_MOOP.coinsuranceamt, 0.00) + 
																ISNULL(Q_MOOP.copayperdiemamt, 0.00))  OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid)
								WHEN Q_MOOP.accum_type IS NULL AND FRX_MOOP.accum_type = 'Out'
													THEN MAX(FRX_MOOP.accumvalue) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, FRX_MOOP.accumid, EK.enrollid)
								WHEN Q_MOOP.accum_type = 'Out' AND FRX_MOOP.accum_type = 'Out' AND Q_MOOP.enrollid = FRX_MOOP.enrollid 
													THEN SUM(ISNULL(Q_MOOP.copay, 0.00) + 
																ISNULL(Q_MOOP.benededuct, 0.00) + 
																ISNULL(Q_MOOP.coinsuranceamt, 0.00) + 
																ISNULL(Q_MOOP.copayperdiemamt, 0.00))  OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid) +								
																MAX(FRX_MOOP.accumvalue) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, FRX_MOOP.accumid, EK.enrollid)
								ELSE '0.00' END AS OutMOOPPaid,
						CONVERT(DATE, GETDATE()) AS LoadDate,
						@yearBegin AS RunBeginPeriod,
						@EndDate AS RunEndPeriod		
		FROM #BaseMembers BM
		INNER JOIN Plandata_Prod.dbo.member M
						ON BM.SecondaryID = M.secondaryid
		INNER JOIN Plandata_Prod.dbo.enrollkeys EK
						ON M.memid = EK.memid
						AND EK.Segtype <> 'EXT'
						AND EK.EffDate BETWEEN @YearBegin AND @EndDate
		INNER JOIN Plandata_Prod.dbo.benefitplan BP
						ON EK.planid = BP.planid
		INNER JOIN QNXT_Custom.EOB.EOB_Plans AS EP
						ON LEFT(LTRIM(RTRIM(BP.upid)), 5) = EP.ContractCode
							AND RIGHT(LTRIM(RTRIM(BP.upid)), 3) = EP.PBPCode
							AND EP.[Group] = ''
							AND EP.GroupPlanID = ''
							AND EK.effdate BETWEEN EP.EffDate AND EP.TermDate			
		LEFT OUTER JOIN 
						(	
							SELECT DISTINCT C.claimid,
											C.memid,
											C.enrollid,
											C.startdate,
											CD.claimline,
											CD.copay,
											CD.benededuct,
											CD.coinsuranceamt,
											CD.copayperdiemamt,
											B.maxoutaccumid AS accumid,
											EIOA.accum_type
							FROM Plandata_Prod.dbo.claim C
							INNER JOIN Plandata_Prod.dbo.claimdetail CD
									ON C.claimid = CD.claimid
									AND CD.[status] IN ( 'OKAY', 'WARN' )
									AND C.[status] IN ('PAID', 'REVERSED')
									AND C.startdate BETWEEN  @YearBegin AND @EndDate									
							INNER JOIN Plandata_Prod.dbo.benefit B
										ON CD.planid = B.planid
											AND CD.benefitid = B.benefitid
											AND B.appdeduct = 1
							INNER JOIN QNXT_Custom.EOB.EOB_In_Out_Accumulator EIOA
										ON B.maxoutaccumid = EIOA.accumid							
						) Q_MOOP
							ON EK.memid = Q_MOOP.memid
							AND EK.enrollid = Q_MOOP.enrollid
							AND Q_MOOP.startdate BETWEEN EP.EffDate AND EP.TermDate
		LEFT OUTER JOIN (
							SELECT DISTINCT EA.enrollid,
											EA.accumid,
											ISNULL(EA.accumvalue, 0.00) AS accumvalue,
											EIOA.accum_type
							FROM Plandata_Prod.dbo.EnrollAccumulator EA
							INNER JOIN QNXT_Custom.EOB.EOB_In_Out_Accumulator EIOA
										ON EA.accumid = EIOA.accumid
						) FRX_MOOP
							ON EK.enrollid = FRX_MOOP.enrollid
		WHERE EP.Active = 1
				AND EP.PlanYear BETWEEN YEAR(@yearBegin) AND YEAR(@EndDate)				
		)
		INSERT INTO QNXT_Custom.EOB.EOB_MOOP ( EnrollID, MemberID, UPID, MinMemberEffectiveDate, MaxMemberEffectiveDate, InNetworkDeductible, InNetworkMOOP, OutNetworkDeductible, 
											OutNetworkMOOP, InDeductPaid, InMOOPPaid, OutDeductPaid, OutMOOPPaid, LoadDate, RunBeginPeriod, RunEndPeriod )
		SELECT  Reg_Plan.EnrollID,
				Reg_Plan.MemberID, 
				Reg_Plan.UPID, 
				Reg_Plan.MinMemberEffectiveDate, 
				Reg_Plan.MaxMemberEffectiveDate, 
				Reg_Plan.InNetworkDeductible, 
				Reg_Plan.InNetworkMOOP, 
				Reg_Plan.OutNetworkDeductible, 
				Reg_Plan.OutNetworkMOOP,
				MAX(Reg_Plan.InDeductPaid) AS InDeductPaid, 
				MAX(Reg_Plan.InMOOPPaid) AS InMOOPPaid, 
				MAX(Reg_Plan.OutDeductPaid) AS OutDeductPaid, 
				MAX(Reg_Plan.OutMOOPPaid) AS OutMOOPPaid, 
				Reg_Plan.LoadDate, 
				Reg_Plan.RunBeginPeriod, 
				Reg_Plan.RunEndPeriod
		FROM Reg_Plan
		GROUP BY Reg_Plan.EnrollID,
					Reg_Plan.MemberID, 
					Reg_Plan.UPID, 
					Reg_Plan.MinMemberEffectiveDate, 
					Reg_Plan.MaxMemberEffectiveDate, 
					Reg_Plan.InNetworkDeductible, 
					Reg_Plan.InNetworkMOOP, 
					Reg_Plan.OutNetworkDeductible, 
					Reg_Plan.OutNetworkMOOP, 
					Reg_Plan.LoadDate, 
					Reg_Plan.RunBeginPeriod, 
					Reg_Plan.RunEndPeriod
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--Rolling up the accumulations for members who are enrolled in Group plans
		;WITH Group_Plan AS
		(
		SELECT DISTINCT EK.EnrollID AS EnrollID,
						BM.SecondaryID AS MemberID,
						ISNULL(BP.upid, '') AS UPID,
						CAST(CONVERT(VARCHAR(10), MIN(EK.effdate) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, EK.enrollid ORDER BY EK.effdate ASC), 112) AS INT) AS MinMemberEffectiveDate,
						CAST(CONVERT(VARCHAR(10), MAX(EK.termdate) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, EK.enrollid ORDER BY EK.effdate ASC), 112) AS INT) AS MaxMemberEffectiveDate,
						EP.InDeduct AS InNetworkDeductible,
						EP.INMOOP AS InNetworkMOOP,
						EP.OONDeduct AS OutNetworkDeductible,
						EP.OONMOOP AS OutNetworkMOOP,
						CASE WHEN Q_MOOP.accum_type = 'In' THEN SUM(ISNULL(Q_MOOP.benededuct, 0.00)) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid) 
								ELSE '0.00' END AS InDeductPaid,
						CASE WHEN Q_MOOP.accum_type = 'In' AND FRX_MOOP.accum_type IS NULL
													THEN SUM(ISNULL(Q_MOOP.copay, 0.00) + 
																ISNULL(Q_MOOP.benededuct, 0.00) + 
																ISNULL(Q_MOOP.coinsuranceamt, 0.00) + 
																ISNULL(Q_MOOP.copayperdiemamt, 0.00))  OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid)
								WHEN Q_MOOP.accum_type IS NULL AND FRX_MOOP.accum_type = 'In'
													THEN MAX(FRX_MOOP.accumvalue) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, FRX_MOOP.accumid, EK.enrollid)
								WHEN Q_MOOP.accum_type = 'In' AND FRX_MOOP.accum_type = 'In' AND Q_MOOP.enrollid = FRX_MOOP.enrollid 
													THEN SUM(ISNULL(Q_MOOP.copay, 0.00) + 
																ISNULL(Q_MOOP.benededuct, 0.00) + 
																ISNULL(Q_MOOP.coinsuranceamt, 0.00) + 
																ISNULL(Q_MOOP.copayperdiemamt, 0.00))  OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid) +								
																MAX(FRX_MOOP.accumvalue) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, FRX_MOOP.accumid, EK.enrollid)						
								ELSE '0.00' END AS InMOOPPaid,
						CASE WHEN Q_MOOP.accum_type = 'Out' THEN SUM(ISNULL(Q_MOOP.benededuct, 0.00)) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid) 
								ELSE '0.00' END AS OutDeductPaid,
						CASE WHEN Q_MOOP.accum_type = 'Out' AND FRX_MOOP.accum_type IS NULL
													THEN SUM(ISNULL(Q_MOOP.copay, 0.00) + 
																ISNULL(Q_MOOP.benededuct, 0.00) + 
																ISNULL(Q_MOOP.coinsuranceamt, 0.00) + 
																ISNULL(Q_MOOP.copayperdiemamt, 0.00))  OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid)
								WHEN Q_MOOP.accum_type IS NULL AND FRX_MOOP.accum_type = 'Out'
													THEN MAX(FRX_MOOP.accumvalue) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, FRX_MOOP.accumid, EK.enrollid)
								WHEN Q_MOOP.accum_type = 'Out' AND FRX_MOOP.accum_type = 'Out' AND Q_MOOP.enrollid = FRX_MOOP.enrollid 
													THEN SUM(ISNULL(Q_MOOP.copay, 0.00) + 
																ISNULL(Q_MOOP.benededuct, 0.00) + 
																ISNULL(Q_MOOP.coinsuranceamt, 0.00) + 
																ISNULL(Q_MOOP.copayperdiemamt, 0.00))  OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, Q_MOOP.accumid, EK.enrollid) +								
																MAX(FRX_MOOP.accumvalue) OVER (PARTITION BY M.memid, BP.upid, EP.GroupPlanId, EP.PlanYear, FRX_MOOP.accumid, EK.enrollid)
								ELSE '0.00' END AS OutMOOPPaid,
						CONVERT(DATE, GETDATE()) AS LoadDate,
						@yearBegin AS RunBeginPeriod,
						@EndDate AS RunEndPeriod		
		FROM #BaseMembers BM
		INNER JOIN Plandata_Prod.dbo.member M
						ON BM.SecondaryID = M.secondaryid
		INNER JOIN Plandata_Prod.dbo.enrollkeys EK
						ON M.memid = EK.memid
						AND EK.Segtype <> 'EXT'
						AND EK.EffDate BETWEEN @YearBegin AND @EndDate
		INNER JOIN Plandata_Prod.dbo.benefitplan BP
						ON EK.planid = BP.planid
		INNER JOIN QNXT_Custom.EOB.EOB_Plans AS EP
						ON LEFT(LTRIM(RTRIM(BP.upid)), 5) = EP.ContractCode
							AND RIGHT(LTRIM(RTRIM(BP.upid)), 3) = EP.PBPCode
							AND EP.[Group] <> ''
							AND EP.GroupPlanID <> ''
							AND EP.GroupPlanID = BP.PlanID
							AND EK.effdate BETWEEN EP.EffDate AND EP.TermDate			
		LEFT OUTER JOIN 
						(	
							SELECT DISTINCT C.claimid,
											C.memid,
											C.enrollid,
											C.startdate,
											CD.claimline,
											CD.copay,
											CD.benededuct,
											CD.coinsuranceamt,
											CD.copayperdiemamt,
											B.maxoutaccumid AS accumid,
											EIOA.accum_type
							FROM Plandata_Prod.dbo.claim C
							INNER JOIN Plandata_Prod.dbo.claimdetail CD
									ON C.claimid = CD.claimid
									AND CD.status IN ( 'OKAY', 'WARN' )
									AND C.status IN ('PAID', 'REVERSED')
									AND C.startdate BETWEEN @YearBegin AND @EndDate									
							INNER JOIN Plandata_Prod.dbo.benefit B
										ON CD.planid = B.planid
											AND CD.benefitid = B.benefitid
											AND B.appdeduct = 1
							INNER JOIN QNXT_Custom.EOB.EOB_In_Out_Accumulator EIOA
										ON B.maxoutaccumid = EIOA.accumid
						) Q_MOOP
							ON EK.memid = Q_MOOP.memid
							AND EK.enrollid = Q_MOOP.enrollid
							AND Q_MOOP.startdate BETWEEN EP.EffDate AND EP.TermDate
		LEFT OUTER JOIN (
							SELECT DISTINCT EA.enrollid,
											EA.accumid,
											ISNULL(EA.accumvalue, 0.00) AS accumvalue,
											EIOA.accum_type
							FROM Plandata_Prod.dbo.EnrollAccumulator EA
							INNER JOIN QNXT_Custom.EOB.EOB_In_Out_Accumulator EIOA
										ON EA.accumid = EIOA.accumid
						) FRX_MOOP
							ON EK.enrollid = FRX_MOOP.enrollid
		WHERE EP.Active = 1
				AND EP.PlanYear BETWEEN YEAR(@yearBegin) AND YEAR(@EndDate)
		)
		INSERT INTO QNXT_Custom.EOB.EOB_MOOP ( EnrollID, MemberID, UPID, MinMemberEffectiveDate, MaxMemberEffectiveDate, InNetworkDeductible, InNetworkMOOP, OutNetworkDeductible, 
											OutNetworkMOOP, InDeductPaid, InMOOPPaid, OutDeductPaid, OutMOOPPaid, LoadDate, RunBeginPeriod, RunEndPeriod )
		SELECT  Group_Plan.EnrollID,
				Group_Plan.MemberID, 
				Group_Plan.UPID, 
				Group_Plan.MinMemberEffectiveDate, 
				Group_Plan.MaxMemberEffectiveDate, 
				Group_Plan.InNetworkDeductible, 
				Group_Plan.InNetworkMOOP, 
				Group_Plan.OutNetworkDeductible, 
				Group_Plan.OutNetworkMOOP,
				MAX(Group_Plan.InDeductPaid) AS InDeductPaid, 
				MAX(Group_Plan.InMOOPPaid) AS InMOOPPaid, 
				MAX(Group_Plan.OutDeductPaid) AS OutDeductPaid, 
				MAX(Group_Plan.OutMOOPPaid) AS OutMOOPPaid, 
				Group_Plan.LoadDate, 
				Group_Plan.RunBeginPeriod, 
				Group_Plan.RunEndPeriod
		FROM Group_Plan
		GROUP BY Group_Plan.EnrollID,
					Group_Plan.MemberID, 
					Group_Plan.UPID, 
					Group_Plan.MinMemberEffectiveDate, 
					Group_Plan.MaxMemberEffectiveDate, 
					Group_Plan.InNetworkDeductible, 
					Group_Plan.InNetworkMOOP, 
					Group_Plan.OutNetworkDeductible, 
					Group_Plan.OutNetworkMOOP, 
					Group_Plan.LoadDate, 
					Group_Plan.RunBeginPeriod, 
					Group_Plan.RunEndPeriod
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--**Identify and delete overlapping MOOP rows for the same Plan**
		;WITH CTE AS (
		SELECT
			MemberID,
			PlanYear = LEFT(MinMemberEffectiveDate, 4),
			MaxInDeductPaid = SUM(InDeductPaid), 
			MaxInMOOPPaid =	SUM(InMOOPPaid), 
			MaxOutDeductPaid = SUM(OutDeductPaid), 
			MaxOutMOOPPaid = SUM(OutMOOPPaid)
		FROM  QNXT_Custom.EOB.EOB_MOOP
		GROUP BY MemberID, LEFT(MinMemberEffectiveDate, 4) )		
		
		UPDATE A SET
			InDeductPaid	= MaxInDeductPaid, 
			InMOOPPaid		= MaxInMOOPPaid, 
			OutDeductPaid	= MaxOutDeductPaid, 
			OutMOOPPaid		= MaxOutMOOPPaid
		FROM  QNXT_Custom.EOB.EOB_MOOP A
		INNER JOIN CTE B
			ON A.MemberID = B.MemberID			
			AND LEFT(A.MinMemberEffectiveDate, 4) = B.PlanYear
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		DELETE A
		FROM	QNXT_Custom.EOB.EOB_MOOP A
		INNER JOIN QNXT_Custom.EOB.EOB_MOOP B
			ON A.MemberID = B.MemberID
			AND A.UPID = B.UPID
			AND A.MaxMemberEffectiveDate BETWEEN B.MinMemberEffectiveDate AND B.MaxMemberEffectiveDate
			AND A.RowNumber <> B.Rownumber
			AND A.MinMemberEffectiveDate = A.MaxMemberEffectiveDate
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		DELETE A
		FROM	QNXT_Custom.EOB.EOB_MOOP A 
		INNER JOIN QNXT_Custom.EOB.EOB_MOOP B
			ON A.MemberID = B.MemberID
			--AND EAY.UPID = b.UPID
			AND A.MaxMemberEffectiveDate BETWEEN B.MinMemberEffectiveDate AND B.MaxMemberEffectiveDate
			AND A.RowNumber <> b.Rownumber
			AND A.MinMemberEffectiveDate = A.MaxMemberEffectiveDate
			AND A.InDeductPaid = 0.00
			AND A.InMOOPPaid = 0.00
			AND A.OutDeductPaid = 0.00
			AND A.OutMOOPPaid = 0.00		
		INNER JOIN Plandata_Prod.dbo.enrollkeys EK
			ON A.EnrollID = EK.EnrollID
			AND EK.Segtype = 'DEL'
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	COMMIT TRAN
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	THROW;
END CATCH

ALTER INDEX ALL ON QNXT_Custom.EOB.EOB_MOOP REBUILD
GO
