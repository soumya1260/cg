CREATE procedure [EOB].[spEOB_PartBPharmacy_Archive] (
	@claimid varchar(18) = null
	,@memberid varchar(20) = null
	,@paiddate date = null
	,@beginpaiddate date = null
	,@endpaiddate date = null
	,@beginservicedate date = null
	,@endservicedate date = null
	,@contractcode varchar(5) = null
	,@pbpcode varchar(5) = null
) as
/*
 * Object:       EOB.spEOB_PartBPharmacy_Archive  
 * Create date:  05/08/2018
 * Description:  Search Part B Pharmacy claim archive
 *
 * Exec Example:
 *	exec EOB.spEOB_PartBPharmacy_Archive
 *		@claimid = null
 *		,@memberid = null
 *		,@paiddate = null
 *		,@beginpaiddate = null
 *		,@endpaiddate = null
 *		,@beginservicedate = null
 *		,@endservicedate = null
 *		,@contractcode = null
 *		,@pbpcode = null
 *
 * History:
 * CM20006296   2018.05.08   Dave Golightly       Initial creation
 */
begin
	declare
		@paidint int =
			case when @paiddate is not null
				then year(convert(date, @paiddate)) * 10000 + month(convert(date, @paiddate)) * 100 + day(convert(date, @paiddate))
				else null
			end
		,@beginpaidint int =
			case when @beginpaiddate is not null
				then year(convert(date, @beginpaiddate)) * 10000 + month(convert(date, @beginpaiddate)) * 100 + day(convert(date, @beginpaiddate))
				else null
			end
		,@endpaidint int =
			case when @endpaiddate is not null
				then year(convert(date, @endpaiddate)) * 10000 + month(convert(date, @endpaiddate)) * 100 + day(convert(date, @endpaiddate))
				else null
			end
		,@beginserviceint int =
			case when @beginservicedate is not null
				then year(convert(date, @beginservicedate)) * 10000 + month(convert(date, @beginservicedate)) * 100 + day(convert(date, @beginservicedate))
				else null
			end
		,@endserviceint int =
			case when @endservicedate is not null
				then year(convert(date, @endservicedate)) * 10000 + month(convert(date, @endservicedate)) * 100 + day(convert(date, @endservicedate))
				else null
			end;

	select
		rx.ClaimID
		,case
			when len(rx.[MemberID]) > 10
				and left(rx.MemberID, 1) <> 'U'
				and isnull(charindex('*', rx.MemberID, 1), 0) = 0 
			then stuff(rx.[MemberID], len(rx.[MemberID]) - 1, 0, '*')
			else rx.[MemberID]
		end as [MemberID]
		,rx.ClaimStatus
		,rx.CurrentEligibiltyStatus
		,rx.PaidDate
		,rx.BeginServiceDate
		,rx.EndServiceDate
		,rx.NDC
		,rx.NDCDesc
		,rx.ProviderName
		,rx.ProviderID
		,rx.BilledAmount
		,rx.DeductibleAmount
		,rx.CopayAmount
		,rx.CoinsuranceAmount
		,rx.TDC
		,rx.PatientPay
		,rx.OtherPay
		,rx.ApprovedAmount
		,rx.ContractCode
		,rx.PBPCode
	from
		QNXT_Custom.EOB.EOB_PartBPharmacy_Archive rx (nolock)
	where
		(@claimid is null or rx.ClaimID = @claimid)
		and (@memberid is null or rx.MemberID = @memberid)
		and (@paidint is null or rx.PaidDate = @paidint)
		and (@beginpaidint is null or rx.PaidDate >= @beginpaidint)
		and (@endpaidint is null or rx.PaidDate <= @endpaidint)
		and (@beginserviceint is null or rx.BeginServiceDate >= @beginserviceint)
		and (@endserviceint is null or rx.EndServiceDate <= @endserviceint)
		and (@contractcode is null or rx.ContractCode = @contractcode)
		and (@pbpcode is null or rx.PBPCode = @pbpcode);
end;
GO
