CREATE PROCEDURE eob.rptEOBFallout (@IsValid as varchar(1), @Source as varchar(3), @FDRParm as varchar(20))
	 AS

/*************************************************************************************************************
  TITLE:			rptEOBFallout.sql			--Fallout_SSRS_Report
  BUSINESS OWNER:	QNXT Development
  CREATED BY:		Sandie Nantz
  CREATE DATE:		04/01/2019

  DESCRIPTION:		Requested by Kieran

  Modification History: 
  SDE #:        Developer:              Date:                   Desc:
  CM20069439	Sandie Nantz			04/01/2019              User Story 290361: EOB 2.0 - Fallout report request
**************************************************************************************************************/
	BEGIN 
		DECLARE @ProcessHeaderID AS varchar(15)

		SET @ProcessHeaderID = (SELECT ProcessHeaderID FROM QNXT_Custom.eob.EOBFalloutParms)

		--Populate a table/grid with the following data
		--Allow sorting on all column headers on the table/grid
			

		BEGIN
			;WITH Fallout_CTE AS
			(
				SELECT	EF.ClaimID, EF.MemberID, EF.[Source], EF.ReasonID, EFR.[Description], EFR.Is_Valid, EF.ProcessHeaderID
				FROM	QNXT_Custom.EOB.EOB_Fallout EF WITH (NOLOCK)
				JOIN	QNXT_Custom.EOB.EOB_Fallout_Reason EFR WITH (NOLOCK)
							ON	EF.ClaimType = EFR.ClaimType AND EF.ReasonID = EFR.ReasonID
				WHERE 
					EF.ProcessHeaderID = @ProcessHeaderID
					AND EFR.IS_VALID = (CASE when @IsValid <> 'A'
									THEN @IsValid 
									ELSE EFR.IS_VALID 
									END) 
					AND EF.SOURCE = (CASE when @SOURCE <> 'All'
									THEN @SOURCE 
									ELSE EF.SOURCE 
									END)
					

				UNION
				SELECT	EF.ClaimID, EF.MemberID, EF.[Source], EF.ReasonID, EFR.[Description], EFR.Is_Valid, EF.ProcessHeaderID
				FROM	QNXT_Custom.EOB.EOB_Fallout_Archive EF WITH (NOLOCK)
				JOIN	QNXT_Custom.EOB.EOB_Fallout_Reason EFR WITH (NOLOCK)
					ON	EF.ClaimType = EFR.ClaimType
					AND EF.ReasonID = EFR.ReasonID
					AND EF.ProcessHeaderID = @ProcessHeaderID
					AND EFR.IS_VALID = (CASE when @IsValid <> 'A'
									THEN @IsValid 
									ELSE EFR.IS_VALID 
									END) 
					AND EF.SOURCE = (CASE when @SOURCE <> 'All' 
									THEN @SOURCE 
									ELSE EF.SOURCE 
									END) 
			)
			SELECT	DISTINCT
						Fallout_CTE.ClaimID,
						Fallout_CTE.MemberID,
						Fallout_CTE.[Source],
						Fallout_CTE.ReasonID,
						Fallout_CTE.[Description],
						Fallout_CTE.Is_Valid, 
						Fallout_CTE.ProcessHeaderID
			FROM	Fallout_CTE
			ORDER BY Fallout_CTE.ClaimID, Fallout_CTE.MemberID, Fallout_CTE.[Source]
		END
	END 
GO