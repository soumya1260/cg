CREATE PROCEDURE eob.rptEOBFalloutStats (@ProcessHeaderID varchar(15) = '468', @LateSubmission as varchar(1) = '', @Regeneration varchar(1)= '', @RunDate as smalldatetime = Null)
	 AS

/*************************************************************************************************************
  TITLE:			rptEOBFalloutStats.sql			--Fallout_SSRS_Report
  BUSINESS OWNER:	QNXT Development
  CREATED BY:		Sandie Nantz
  CREATE DATE:		04/01/2019

  DESCRIPTION:		Requested by Kieran

  Modification History: 
  SDE #:        Developer:              Date:                   Desc:
  CM20069439	Sandie Nantz			04/01/2019              User Story 290361: EOB 2.0 - Fallout report request
**************************************************************************************************************/
	BEGIN 
	--declare @LateSubmision as varchar(1), @Regeneration as varchar(1), @RunDate as smalldatetime
		If EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'eob.EOBFalloutParms') AND type IN (N'u', N'P', N'PC' ) ) 
				DROP TABLE QNXT_Custom.eob.EOBFalloutParms

		CREATE TABLE QNXT_Custom.eob.EOBFalloutParms(ProcessHeaderID varchar(15))
		DECLARE @stats table (description varchar(50),intCt varchar(8))
		DECLARE @thiscount as INT
			

		IF (isnumeric(@ProcessHeaderID) <> 1 )
			BEGIN
				SELECT @thiscount = count(*) 
									FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
									WHERE  	RM.status = 'COMPLETED' and 
											RM.Is_LateSubmission = (CASE when @LateSubmission <> 'A'
													THEN @LateSubmission 
													ELSE RM.Is_LateSubmission 
													END) AND 
											Is_Regen = (CASE when @Regeneration <> 'A'  
												THEN @Regeneration 
												ELSE RM.Is_Regen 
												END) and 
											RunDate = (CASE when isdate(@RunDate) =1
												THEN @rundate 
												ELSE rm.rUNDATE
												END)

				print @thiscount
	
				IF (@thiscount <> 1)
				BEGIN 
					if @thiscount = 0 
						INSERT into @stats (description, intCt)	
						values  ('******** No Results ********','0')
					Else
						begin 
							INSERT into @stats (description, intCt)	
							values  ('******** More than 1 result ********','0'),
								('****** Please Limit Parameters ******:','0'),
								('These Process Logs were selected:',@thiscount)
			
							INSERT INTO @stats
							SELECT ProcessHeaderID,'0'
							FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
							WHERE  	RM.status = 'COMPLETED' and 
									Is_LateSubmission = (CASE when @LateSubmission <> 'A'
														THEN @LateSubmission 
														ELSE RM.Is_LateSubmission 
														END) AND 
									Is_Regen = (CASE when @Regeneration <> 'A' 
													THEN @Regeneration 
													ELSE RM.Is_Regen 
													END) and 
									RunDate = (CASE when @RunDate > 0  
													THEN @RunDate 
													ELSE RM.RunDate 
													END) 
						End
					SELECT  * from @stats
					RETURN
				END 
			IF (isnumeric(@ProcessHeaderID) <> 1 )				
				SET @ProcessHeaderID = (SELECT  ProcessHeaderID	
								FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
								WHERE  	RM.status = 'COMPLETED' and 
										Is_LateSubmission = (CASE when @LateSubmission <> 'A'  
													THEN @LateSubmission 
													ELSE RM.Is_LateSubmission 
													END) AND 
										Is_Regen = (CASE when @Regeneration <> 'A'  
												THEN @Regeneration 
												ELSE RM.Is_Regen 
												END) and 
										RunDate = (CASE when @RunDate > 0  
												THEN @RunDate 
												ELSE RM.RunDate 
												END))

			END

		insert into @stats	
		select  'QNXT Processed Claims ', CAST(RM.CL_Processed_Claims AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID 

		insert into @stats	
		select  'QNXT Processed Members ', CAST(RM.CL_Processed_Members AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'FDR Processed Claims ', CAST(RM.EN_Processed_Claims AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'FDR Processed Members ', CAST(RM.EN_Processed_Members AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'RX Processed Claims ', CAST(RM.RX_Processed_Claims AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'RX Processed Members ', CAST(RM.RX_Processed_Members AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'Total Processed Members ', CAST(RM.Total_Processed_Members AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'QNXT Sent Claims ', CAST(RM.CL_Sent_Claims AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'QNXT Sent Members ', CAST(RM.CL_Sent_Members AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'FDR Sent Claims ', CAST(RM.EN_Sent_Claims AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'FDR Sent Members ', CAST(RM.EN_Sent_Members AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'RX Sent Claims ', CAST(RM.RX_Sent_Claims AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'RX Sent Members ', CAST(RM.RX_Sent_Members AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		insert into @stats	
		select  'Total Sent Members ', CAST(RM.Total_Sent_Members AS VARCHAR)
		FROM QNXT_Custom.EOB.EOB_Run_Master RM (NOLOCK)
		WHERE RM.ProcessHeaderID = @ProcessHeaderID

		select  * from @stats


		INSERT INTO QNXT_Custom.eob.EOBFalloutParms(ProcessHeaderID)
			SELECT @ProcessHeaderID
	
		END

--Errored: 
--	print 'error ' + @ProcessHeaderID
Go
