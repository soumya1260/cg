CREATE PROCEDURE [EOB].[EOB_UpdateFTP] (	@EOBFiles VARCHAR(MAX) ) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_UpdateFTP.sql
-- Date:			12.30.2018
-- Author:			Subash (subash.chandrasekaram@healthspring.com)
--
-- Purpose:			Update FTP Upload Date
--
-- Called by:		N/A
###########################################################################################################################################################

###########################################################################################################################################################
-- Ver  User		Date				US#			Change
-- 1.0  Subash      12.30.2018					Initial release
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		DECLARE	@FileNames_Xml XML

		IF OBJECT_ID('tempdb.dbo.#FTPComplete_Files') IS NOT NULL
		DROP TABLE #FTPComplete_Files

		CREATE TABLE #FTPComplete_Files
		(
			[FileName] VARCHAR(MAX)
		)

		SET @FileNames_Xml = N'<t>' + REPLACE(@EOBFiles, '|', '</t><t>') + '</t>'

		INSERT	INTO #FTPComplete_Files
		SELECT  F.value('.','varchar(MAX)') AS [FileName]
		FROM	@FileNames_Xml.nodes('/t') AS FileNames(F)

		UPDATE	ER
			SET ER.[FTP_Complete] = 'Y'
		FROM	EOB.EOB_Recon ER
		JOIN	#FTPComplete_Files FF
			ON	ER.[FileName] = FF.[FileName]
		
	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
