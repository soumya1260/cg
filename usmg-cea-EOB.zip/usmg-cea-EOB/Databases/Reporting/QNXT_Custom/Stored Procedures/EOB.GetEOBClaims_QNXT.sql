CREATE PROCEDURE [EOB].[GetEOBClaims_QNXT] @LastRunDate VARCHAR(30) AS
SET NOCOUNT ON
/*
##################################################################################################################################################
-- Name					:     dbo.spGetEOBClaims
-- Date					:     10.27.2017
-- Author				:     Kiran Bhaskara (kiran.bhaskara@healthspring.com)
-- Purpose				:     
-- Called by			:     -
##################################################################################################################################################
-- Parameters
-- None
##################################################################################################################################################
-- Ver  User				Date					Change  
-- 1.0  Kiran Bhaskara      10.27.2017				Initial (Prj. 7508)
##################################################################################################################################################
*/
BEGIN TRY

	SELECT DISTINCT 
			'EOB' AS [RecordType],
			ISNULL(ProcessHeaderID, 0) AS ProcessHeaderID,
			LTRIM(RTRIM(ER.MemberID)) AS MemberID,
			LTRIM(RTRIM(ER.ClaimID)) AS ClaimID,
			CONVERT(VARCHAR(8), ER.CreateDate, 112) AS FileGenerationDate, 
			ER.EOBFileName AS [FileName],
			LTRIM(RTRIM(ER.[Source])) AS [Source],
			'Med C' AS [Group],
			CAST(NULL AS DATETIME) AS MailDate,
			'' AS [MailDateFileName],
			CAST(NULL AS DATETIME) AS CHCImportDate,
			GETDATE() AS createdate,
			'CHC_Maildate_Recon' AS createid,
			GETDATE() AS lastupdate,
			'CHC_Maildate_Recon' AS updateid,
			0 AS IsReceived
	FROM QNXT_Custom.EOB.EOB_Recon ER WITH (NOLOCK)
	WHERE ER.CreateDate > CAST(@LastRunDate AS DATETIME)
	ORDER BY LTRIM(RTRIM(ER.ClaimID)), LTRIM(RTRIM(ER.MemberID)), LTRIM(RTRIM(ER.[Source]))

END TRY

BEGIN CATCH	
	;THROW
END CATCH
GO
