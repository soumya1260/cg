CREATE PROCEDURE [EOB].[GetEOBRecon] AS
SET NOCOUNT ON
/*
##################################################################################################################################################
-- Name					:     [dbo].[spGetEOBRecon]
-- Date					:     10.27.2017
-- Author				:     Kiran Bhaskara (kiran.bhaskara@healthspring.com)
-- Purpose				:     
-- Called by			:     -
##################################################################################################################################################
-- Parameters
-- None
##################################################################################################################################################
-- Ver  User				Date					Change  
-- 1.0  Kiran Bhaskara      10.27.2017				Initial (Prj. 7508)
##################################################################################################################################################
*/
BEGIN TRY

	SELECT DISTINCT 
			ProcessHeaderID,
			MemberID,
			ClaimID,
			EOBFileName,
			MailDate,
			[Source]
	FROM QNXT_Custom.EOB.EOB_Recon WITH (NOLOCK)
	ORDER BY ClaimID, MemberID, [Source], EOBFileName, ProcessHeaderID

END TRY

BEGIN CATCH
	;THROW
END CATCH
GO
