CREATE PROCEDURE [EOB].[EOB_RollingCounter] AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON
/*
####################################################################################
-- Name:			EOB_RollingCounter.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Rolling counter for EOB File Names
--
-- Called by:		N/A
####################################################################################
-- Parameters
--     N/A
####################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
####################################################################################
*/
BEGIN TRY
	
	DECLARE @MaxCounter INT

	SELECT	@MaxCounter = ISNULL(MAX(DISTINCT SUBSTRING([EOBFileName], 6, 3)), 0) + 1
	FROM	QNXT_Custom.EOB.EOB_Recon WITH (NOLOCK)
	WHERE	CAST(CreateDate AS DATE) = CAST(GETDATE() AS DATE)

	SELECT FORMAT(@MaxCounter, '00#')

END TRY

BEGIN CATCH
	;THROW
END CATCH
GO
