CREATE PROCEDURE [EOB].[EOB_Set_CKey] AS
SET XACT_ABORT, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Set_CKey.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION

	DECLARE @OrgFirstKey INT
	DECLARE @FirstKey INT
	DECLARE @MaxFirstKey INT
	DECLARE @SecondKey INT
	
	SELECT @MaxFirstKey = 91
	SELECT @SecondKey = 65

	IF NOT EXISTS (SELECT 1 FROM QNXT_Custom.EOB.EOB_CKey)
	BEGIN

		SELECT @OrgFirstKey = 83

	END
	ELSE
	BEGIN
	
		SELECT @OrgFirstKey = ASCII(LEFT(CKey_FileSeqID, 1))
		FROM QNXT_Custom.EOB.EOB_CKey CK

		SELECT @SecondKey = ASCII(RIGHT(CKey_FileSeqID, 1))
		FROM QNXT_Custom.EOB.EOB_CKey CK		

		IF @OrgFirstKey = 90 AND @SecondKey = 57
		BEGIN
		
			SELECT @OrgFirstKey = 83
			SELECT @SecondKey = 65

		END
		ELSE IF @SecondKey = 90
		BEGIN
			
			SELECT @SecondKey = 49

		END
		ELSE IF @SecondKey = 57
		BEGIN
			
			SELECT @SecondKey = 65
			SELECT @OrgFirstKey = @OrgFirstKey + 1

			IF @OrgFirstKey = @MaxFirstKey
			SET @OrgFirstKey = @OrgFirstKey

		END
		ELSE
		BEGIN
			
			SELECT @SecondKey = @SecondKey + 1

		END

	END

	TRUNCATE TABLE QNXT_Custom.EOB.EOB_CKey

	INSERT INTO QNXT_Custom.EOB.EOB_CKey (IncurredYear, CKey_FileSeqID) 
	SELECT DISTINCT YEAR(GETDATE()) AS IncurredYear,
					'' AS CKey_FileSeqID

	SELECT @FirstKey = @OrgFirstKey
	
	IF @FirstKey = @MaxFirstKey
	SET @FirstKey = @OrgFirstKey

	IF @OrgFirstKey = 90 AND @SecondKey = 57
	BEGIN
		
		SELECT @FirstKey = 83
		SELECT @SecondKey = 65

	END

	UPDATE CK
	SET CK.CKey_FileSeqID = CHAR(@FirstKey) + CHAR(@SecondKey)
	FROM QNXT_Custom.EOB.EOB_CKey CK
    
	COMMIT TRANSACTION
END TRY

BEGIN CATCH	
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
