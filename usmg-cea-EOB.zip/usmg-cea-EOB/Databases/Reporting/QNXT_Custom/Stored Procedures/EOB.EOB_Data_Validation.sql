CREATE PROCEDURE [EOB].[EOB_Data_Validation] (@ProcessHeaderID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON
/*
###########################################################################################################################################################
-- Name:			EOB_Data_Validation.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			08.13.2018			215695		Updated logic to delete claims that dont have a valid serv or rev code (CM20025799)
-- 1.2	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
-- 1.3	KB			08.01.2019						CM20097013 - WYMBB mapping
###########################################################################################################################################################
*/
BEGIN TRY
	BEGIN TRANSACTION
		IF OBJECT_ID('tempdb.dbo.#Del_Claims') IS NOT NULL
		DROP TABLE #Del_Claims

		IF OBJECT_ID('tempdb.dbo.#Del_Members') IS NOT NULL
		DROP TABLE #Del_Members

		CREATE TABLE #Del_Claims 
		(
			Claim_Number VARCHAR(100),
			[Source] VARCHAR(60)
		)

		CREATE TABLE #Del_Members 
		(
			Insured_PolicyNumber VARCHAR(100)
		)

		--Deleting all member 01 records where name is blank or null
		INSERT #Del_Members
		SELECT DISTINCT 
				E01.Insured_PolicyNumber
		FROM QNXT_Custom.EOB.EOB_0001MasterDeliv E01
		WHERE LTRIM(RTRIM(E01.[Name] + E01.Name2)) = ''
				OR LTRIM(RTRIM(E01.[Name] + E01.Name2)) IS NULL

		--Deleting all member records that do not have a corresponding claim 02 record
		INSERT #Del_Members
		SELECT DISTINCT
				E01.Insured_PolicyNumber
		FROM		QNXT_Custom.EOB.EOB_0001MasterDeliv E01
		LEFT JOIN	QNXT_Custom.EOB.EOB_0002EOB E02
				ON	E01.Insured_PolicyNumber = E02.Insured_PolicyNumber
		WHERE	E02.Insured_PolicyNumber IS NULL

		--Deleting all member records that do not have a corresponding ZZ record
		INSERT #Del_Members
		SELECT DISTINCT
				E01.Insured_PolicyNumber
		FROM		QNXT_Custom.EOB.EOB_0001MasterDeliv E01
		LEFT JOIN	QNXT_Custom.EOB.EOB_0004ZZSegment E04Z
				ON	E01.Insured_PolicyNumber = E04Z.Insured_PolicyNumber
		WHERE	E04Z.Insured_PolicyNumber IS NULL

		--Deleting all member records that have a ZZ but do not have an 01
		INSERT #Del_Members
		SELECT DISTINCT
				E04Z.Insured_PolicyNumber
		FROM		QNXT_Custom.EOB.EOB_0004ZZSegment E04Z
		LEFT JOIN	QNXT_Custom.EOB.EOB_0001MasterDeliv E01
				ON	E04Z.Insured_PolicyNumber = E01.Insured_PolicyNumber
		WHERE	E01.Insured_PolicyNumber IS NULL

		--Deleting all claim records that do not have a corresponding 03 record
		INSERT #Del_Claims
		SELECT DISTINCT
				E02.Claim_Number,
				E02.[Source]
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		LEFT OUTER JOIN QNXT_Custom.EOB.EOB_0003ServiceLine E03
			ON	E02.Claim_Number = E03.Claim_Number
			AND	E02.[Source] = E03.[Source]
		WHERE E03.Claim_Number IS NULL

		--Deleting all claim records that do not have a corresponding 04 record
		INSERT #Del_Claims
		SELECT DISTINCT
				E02.Claim_Number,
				E02.[Source]
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		LEFT OUTER JOIN QNXT_Custom.EOB.EOB_0004TotalLine E04
			ON	E02.Claim_Number = E04.Claim_Number
			AND	E02.[Source] = E04.[Source]
		WHERE E04.Claim_Number IS NULL

		--Deleting all claim records that do not have a corresponding 02 record
		INSERT #Del_Claims
		SELECT DISTINCT
				E03.Claim_Number,
				E03.[Source]
		FROM	QNXT_Custom.EOB.EOB_0003ServiceLine E03
		LEFT OUTER JOIN QNXT_Custom.EOB.EOB_0002EOB E02
			ON	E03.Claim_Number = E02.Claim_Number
			AND	E03.[Source] = E02.[Source]
		WHERE E02.Claim_Number IS NULL

		--Deleting all claim records that do not have a corresponding 02 record
		INSERT #Del_Claims
		SELECT DISTINCT
				E04.Claim_Number,
				E04.[Source]
		FROM	QNXT_Custom.EOB.EOB_0004TotalLine E04
		LEFT OUTER JOIN QNXT_Custom.EOB.EOB_0002EOB E02
			ON	E04.Claim_Number = E02.Claim_Number
			AND	E04.[Source] = E02.[Source]
		WHERE E02.Claim_Number IS NULL

		--Deleting all claim records from EOB tables where claim has multiple 02 entries
		INSERT #Del_Claims
		SELECT DISTINCT
				E02.Claim_Number,
				E02.[Source]
		FROM QNXT_Custom.EOB.EOB_0002EOB E02
		GROUP BY E02.Claim_Number, E02.Insured_PolicyNumber, E02.[Source]
		HAVING COUNT(E02.Claim_Number) > 1

		--Deleting all claim records from EOB tables where claim doesn't have a valid service or rev code
		INSERT #Del_Claims
		SELECT DISTINCT
				E03.Claim_Number,
				E03.[Source]
		FROM	QNXT_Custom.EOB.EOB_0003ServiceLine E03
		WHERE	E03.Open_Field3 = ''
			OR	E03.Open_Field6 = ''
		
		--Deleting all claims where the corresponding members are marked for delete
		INSERT #Del_Claims
		SELECT DISTINCT
				E02.Claim_Number,
				E02.[Source]
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	#Del_Members DM
			ON	E02.Insured_PolicyNumber = DM.Insured_PolicyNumber
		
		INSERT INTO QNXT_Custom.EOB.EOB_Fallout (ClaimType, ClaimID, MemberID, ReasonID, [Source], ProcessHeaderID)
		SELECT DISTINCT	CASE WHEN E02.[Source] IN ('CL', 'RX') THEN E02.[Source]
								ELSE 'EN' END AS ClaimType,
						DC.Claim_Number AS ClaimID,
						E02.Insured_PolicyNumber AS MemberID,
						CASE WHEN E02.[Source] = 'CL' THEN 14 
								WHEN E02.[Source] = 'RX' THEN 15
								ELSE 21 END AS ReasonID,
						E02.[Source] AS [Source],
						@ProcessHeaderID AS ProcessHeaderID
		FROM	#Del_Claims DC
		JOIN	QNXT_Custom.EOB.EOB_0002EOB E02
			ON	DC.Claim_Number = E02.Claim_Number

		DELETE	E01			
		FROM	QNXT_Custom.EOB.EOB_0001MasterDeliv E01
		JOIN	#Del_Members DM
			ON	E01.Insured_PolicyNumber = DM.Insured_PolicyNumber

		DELETE	E02 
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	#Del_Claims DC
			ON	E02.Claim_Number = DC.Claim_Number
			AND	E02.[Source] = DC.[Source]

		DELETE	E02
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	#Del_Members DM
			ON	E02.Insured_PolicyNumber = DM.Insured_PolicyNumber

		DELETE	E03 
		FROM	QNXT_Custom.EOB.EOB_0003ServiceLine E03
		JOIN	#Del_Claims DC
			ON	E03.Claim_Number = DC.Claim_Number
			AND	E03.[Source] = DC.[Source]
		
		DELETE	E03 
		FROM	QNXT_Custom.EOB.EOB_0003ServiceLine E03
		JOIN	#Del_Members DM
			ON	E03.Insured_PolicyNumber = DM.Insured_PolicyNumber

		DELETE	E04 
		FROM	QNXT_Custom.EOB.EOB_0004TotalLine E04
		JOIN	#Del_Claims DC
			ON	E04.Claim_Number = DC.Claim_Number
			AND	E04.[Source] = DC.[Source]

		DELETE	E04 
		FROM	QNXT_Custom.EOB.EOB_0004TotalLine E04
		JOIN	#Del_Members DM
			ON	E04.Insured_PolicyNumber = DM.Insured_PolicyNumber
		
		DELETE	E04Z		
		FROM	QNXT_Custom.EOB.EOB_0004ZZSegment E04Z
		JOIN	#Del_Members DM
			ON	E04Z.Insured_PolicyNumber = DM.Insured_PolicyNumber

		DELETE	E05 
		FROM	QNXT_Custom.EOB.EOB_0005Comments E05
		JOIN	#Del_Claims DC
			ON	E05.Claim_Number = DC.Claim_Number
			AND	E05.[Source] = DC.[Source]
		
		DELETE	E05 
		FROM	QNXT_Custom.EOB.EOB_0005Comments E05
		JOIN	#Del_Members DM
			ON	E05.Insured_PolicyNumber = DM.Insured_PolicyNumber

		DELETE	E08		
		FROM	QNXT_Custom.EOB.EOB_0008Accumulator E08
		JOIN	#Del_Members DM
			ON	E08.Insured_PolicyNumber = DM.Insured_PolicyNumber

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION

	;THROW
END CATCH
GO