CREATE PROCEDURE [EOB].[EOB_Get_Run_Detail] AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON
/*
###########################################################################################################################################################
-- Name:			EOB_Get_Run_Detail.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Pulls the current run configuration from the EOB_Run_Master table.
-- 
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
###########################################################################################################################################################
*/

BEGIN TRY

	SELECT
		RunRequestID,
		BeginDate,
		EndDate,
		Is_LateSubmission,
		Is_Regen,
		DisplayBeginDate,
		DisplayEndDate,
		RunYear
	FROM QNXT_Custom.EOB.EOB_Run_Master WITH (NOLOCK)
	WHERE CAST(RunDate AS DATE) = CAST(GETDATE() AS DATE)
	AND ProcessHeaderID IN ('', 0)
	AND [Status] = 'READY'
	ORDER BY RunRequestID ASC

END TRY

BEGIN CATCH
	;THROW
END CATCH
GO
