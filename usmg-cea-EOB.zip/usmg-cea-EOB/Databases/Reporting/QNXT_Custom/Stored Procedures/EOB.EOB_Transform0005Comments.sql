CREATE PROCEDURE [EOB].[EOB_Transform0005Comments] (@BeginDate DATE, @EndDate DATE, @ProcessHeaderID INT, @DisplayBeginDate DATE, @DisplayEndDate DATE) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Transform0005Comments.sql
-- Date:			01.26.2018
-- Author:			Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Transform all the notes into EOB.EOB_0005Comments
--
-- Called by:		NA
###########################################################################################################################################################
-- Parameters
--     
###########################################################################################################################################################
-- Ver  User		Date				US#			Change
-- 1.0	KB			10.22.2018			203876		Changes to accomodate EOB template and non-template redesign project
-- 1.1	KB			09.09.2019						Change to accomodate Note H for misdirected claims
###########################################################################################################################################################
*/

TRUNCATE TABLE EOB.EOB_0005Comments

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		IF OBJECT_ID('TEMPDB..#ClaimNotes') IS NOT NULL
		DROP TABLE #ClaimNotes

		CREATE TABLE #ClaimNotes
		(
			ClaimId VARCHAR(30),
			ClaimLine INT,
			MemberId VARCHAR(25),
			[Source] VARCHAR(60),
			NoteID VARCHAR(20),
			GroupType VARCHAR(20)
		)

		--0005 Requirement 1 - QNXT - Bundled Services Claim Edit
		--0005 Requirement 12 - QNXT - Duplicate Claims -- Claim Edit
		--H - We have forwarded this claim to the appropriate Vendor or Payor. This claim/service is processed by our vendor or payor - Claim Edit
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					ECD.[Source],
					EBC.NoteID,
					EBC.GroupType
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID
			AND EC.[Source] = 'CL'
			AND	ECD.[Source] = 'CL'
			AND EC.[Source] = ECD.[Source]
			AND ECD.ClaimLineStatus = 'D'
		JOIN	Plandata_Prod.dbo.ClaimEdit CED
			ON	ECD.ClaimID = CED.ClaimID
			AND	CED.[Status] = 'DENY'
			AND (ECD.ClaimLine = CED.ClaimLine OR CED.ClaimLine = 0)			
		JOIN	QNXT_Custom.EOB.EOB_0005Codes EBC
			ON	EBC.[Source] = 'QNXT'
			AND EBC.NoteID IN ('1', 'F', 'H')
			AND	((EBC.CodeId = CED.Reason AND EBC.CodeType = 'REMIT')
					OR	(EBC.CodeId = CED.EOBID AND EBC.CodeType = 'EOB'))
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--0005 Requirement 1 - QNXT - Bundled Services Claim Edit Message
		--0005 Requirement 12 - QNXT - Duplicate Claims -- Claim Edit Message
		--H - We have forwarded this claim to the appropriate Vendor or Payor. This claim/service is processed by our vendor or payor - Claim Edit Message
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					ECD.[Source],
					EBC.NoteID,
					EBC.GroupType
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID
			AND EC.[Source] = 'CL'
			AND	ECD.[Source] = 'CL'	
			AND EC.[Source] = ECD.[Source]
			AND ECD.ClaimLineStatus = 'D'
		JOIN	Plandata_Prod.dbo.ClaimEditMessage CEM
			ON	ECD.ClaimID = CEM.ClaimID
			AND (ECD.ClaimLine = CEM.ClaimLine OR CEM.ClaimLine = 0)
		JOIN	QNXT_Custom.EOB.EOB_0005Codes EBC
			ON	EBC.[Source] = 'QNXT'
			AND EBC.NoteID IN ('1', 'F', 'H')
			AND EBC.CodeType = CEM.MessageType 
			AND	EBC.CodeId = CEM.MessageID
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		--0005 Requirement 1 - FDR - Bundled Services
		--0005 Requirement 4 - FDR - Appeals and overturns
		--0005 Requirement 12 - FDR - Duplicate Claims		
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					ECD.[Source],
					EBC.NoteID,
					EBC.GroupType
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID			
			AND EC.[Source] NOT IN ('CL', 'RX')
			AND	ECD.[Source] NOT IN ('CL', 'RX')
			AND EC.[Source] = ECD.[Source]
		JOIN	QNXT_Custom.EOB.EOB_0005Codes EBC
			ON	EBC.[Source] = 'FDR'
			AND EBC.NoteID IN ('1', 'C', 'F')
			AND	((ECD.ClaimAdjustmentReason = EBC.CodeId)
				OR (ECD.ClaimAdjustmentReason2 = EBC.CodeId)
				OR (ECD.ClaimAdjustmentReason3 = EBC.CodeId)
				OR (ECD.ClaimAdjustmentReason4 = EBC.CodeId)
				OR (ECD.ClaimAdjustmentReason5 = EBC.CodeId)
				OR (ECD.ClaimAdjustmentReason6 = EBC.CodeId))
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--0005 Requirement 4 - QNXT - Appeals and overturns
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					EC.[Source],
					'C' AS NoteID,
					'NOTE RQ4' AS GroupType
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID
			AND EC.[Source] = 'CL'
			AND	ECD.[Source] = 'CL'	
			AND EC.[Source] = ECD.[Source]
		JOIN	Plandata_Prod.dbo.ClaimAttribute CA
			ON	EC.ClaimID = CA.ClaimID			
			AND CA.AttributeID IN ('C55529213', 'C55529219')
		WHERE	EC.ClaimID NOT LIKE '%R%'
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		--0005 Requirement 13 - QNXT - Capitated Claims
		--0005 Requirement 13 - FDR - Capitated Claims
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					ECD.[Source],
					'11' AS NoteID,
					'NOTE RQ13' AS GroupType
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID
			AND EC.[Source] <> 'RX'
			AND	ECD.[Source] <> 'RX'	
			AND EC.[Source] = ECD.[Source]
			AND ECD.Is_Capitated = 'Y'
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		--0005 Requirement Non-Template 26 - QNXT - Adjustment Claims
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					EC.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					EC.[Source],
					'7' AS NoteID,
					'NOTE RQ26' AS GroupType
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	QNXT_Custom.EOB.EOB_ClaimDetail ECD
			ON	EC.ClaimID = ECD.ClaimID
		WHERE	EC.[Source] = 'CL'
			AND (EC.ClaimID LIKE '%A%'
					OR EC.ClaimID LIKE '%R%')
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		--0005 Requirement Non-Template 26 - FDR - Adjustment Claims
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					ECD.[Source],
					EBC.NoteID,
					EBC.GroupType
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID			
			AND EC.[Source] NOT IN ('CL', 'RX')
			AND	ECD.[Source] NOT IN ('CL', 'RX')
			AND EC.[Source] = ECD.[Source]
		JOIN	QNXT_Custom.EOB.EOB_0005Codes EBC
			ON	EBC.[Source] = 'FDR'
			AND EBC.NoteID IN ('7')
			AND	ECD.FreqencyCode = EBC.CodeId
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
			
		--0005 Requirement 3 - Preventive Services - Without Diag Codes
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					ECD.[Source],
					'4' AS NoteID,
					'NOTE RQ3' AS GroupType
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID			
			AND EC.[Source] <> 'RX'
			AND	ECD.[Source] <> 'RX'
			AND EC.[Source] = ECD.[Source]			
		JOIN	QNXT_Custom.EOB.EOB_PreventiveProcedureCode EPC
			ON	ECD.Procedure_Code = EPC.CodeId
			AND	EPC.Is_ICD = 'N'
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		--0005 Requirement 3 - Preventive Services - With Diag Codes
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					ECD.[Source],
					'4' AS NoteID,
					'NOTE RQ3' AS GroupType
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID			
			AND EC.[Source] <> 'RX'
			AND	ECD.[Source] <> 'RX'
			AND EC.[Source] = ECD.[Source]			
		JOIN	QNXT_Custom.EOB.EOB_PreventiveProcedureCode EPC
			ON	ECD.Procedure_Code = EPC.CodeId
			AND	EPC.Is_ICD = 'Y'
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD
			ON	ECD.PrinDiag = EPD.CodeId			
			AND	EPC.GroupId = EPD.GroupId
			AND ECD.PrinDiag_ICDVersion = 0
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD1
			ON	ECD.Diag1 = EPD1.CodeId			
			AND	EPC.GroupId = EPD1.GroupId
			AND ECD.Diag1_ICDVersion = 0
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD2
			ON	ECD.Diag2 = EPD2.CodeId			
			AND	EPC.GroupId = EPD2.GroupId
			AND ECD.Diag2_ICDVersion = 0
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD3
			ON	ECD.Diag3 = EPD3.CodeId			
			AND	EPC.GroupId = EPD3.GroupId
			AND ECD.Diag3_ICDVersion = 0
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD4
			ON	ECD.Diag4 = EPD4.CodeId			
			AND	EPC.GroupId = EPD4.GroupId
			AND ECD.Diag4_ICDVersion = 0
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD5
			ON	ECD.Diag5 = EPD5.CodeId			
			AND	EPC.GroupId = EPD5.GroupId
			AND ECD.Diag5_ICDVersion = 0
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD6
			ON	ECD.Diag6 = EPD6.CodeId			
			AND	EPC.GroupId = EPD6.GroupId
			AND ECD.Diag6_ICDVersion = 0
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD7
			ON	ECD.Diag7 = EPD7.CodeId			
			AND	EPC.GroupId = EPD7.GroupId
			AND ECD.Diag7_ICDVersion = 0
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD8
			ON	ECD.Diag8 = EPD8.CodeId			
			AND	EPC.GroupId = EPD8.GroupId
			AND ECD.Diag8_ICDVersion = 0
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD9
			ON	ECD.Diag9 = EPD9.CodeId			
			AND	EPC.GroupId = EPD9.GroupId
			AND ECD.Diag9_ICDVersion = 0
		LEFT JOIN	QNXT_Custom.EOB.EOB_PreventiveDiagCode EPD10
			ON	ECD.Diag10 = EPD10.CodeId			
			AND	EPC.GroupId = EPD10.GroupId
			AND ECD.Diag10_ICDVersion = 0
		WHERE	EPD.CodeId IS NOT NULL
			OR	EPD1.CodeId IS NOT NULL
			OR	EPD2.CodeId IS NOT NULL
			OR	EPD3.CodeId IS NOT NULL
			OR	EPD4.CodeId IS NOT NULL
			OR	EPD5.CodeId IS NOT NULL
			OR	EPD6.CodeId IS NOT NULL
			OR	EPD7.CodeId IS NOT NULL
			OR	EPD8.CodeId IS NOT NULL
			OR	EPD9.CodeId IS NOT NULL
			OR	EPD10.CodeId IS NOT NULL
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		/*  I didn't code these... the last I knew we weren't going to do notes for these because there would be 10-15 different ones per EOB if the $ or %'s differed between benefits
			--2	-	You pay <%> of the total amount [for services from an <in-network/out-of-network> provider]
			--3	- 	You pay $<copay> [for services from an <in-network/out-of-network> provider]		
		*/
		
		--6	-	This claim was processed in a prior month but was not included on an earlier Explanation of Benefits
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					ECD.[Source],
					'6' AS NoteID,
					'NOTE RQ21' AS GroupType
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID
			AND EC.[Source] = ECD.[Source]
		WHERE	MONTH(EC.PaidDate) + YEAR(EC.PaidDate) < MONTH(@DisplayBeginDate) + YEAR(@DisplayEndDate)
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		--A	-	When we deny part or all of a claim, we send you a letter (“Notice of Denial of Payment”) explaining why the service or item is not covered. This letter also tells you what to do if you want to appeal our decision and have us reconsider.    IMPORTANT: If you do not/did not receive this letter, call Customer Service at 1-800-668-3813 (TTY 711), 8 am - 8 pm, 7 days a week. If you have questions or need help with your appeal, you can call:    ·          Customer Service at 1-800-668-3813 (TTY 711), 8 am - 8 pm, 7 days a week.  ·         1-800-MEDICARE (1-800-633-4227), 24 hours a day, 7 days a week. (TTY users should call 1-877-486-2048.)
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					ECD.[Source],
					'A' AS NoteID,
					'NOTE RQ21' AS GroupType
		FROM	QNXT_Custom.EOB.EOB_ClaimDetail ECD
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	ECD.ClaimID = EC.ClaimID
			AND EC.[Source] = ECD.[Source]
		WHERE	ECD.IDN_Denied_Charge > 0.00
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		--B	-	We have denied all or part of this claim. However, you are not responsible for paying the billed amount. If you receive a bill for this claim, you can call:  ·         Customer Service at 1-800-668-3813 (TTY 711), 8 am - 8 pm, 7 days a week.  ·         1-800-MEDICARE (1-800-633-4227), 24 hours a day, 7 days a week. (TTY users should call 1-877-486-2048.)] 
		--Suppress note B when the claim line already has notes A and H
		INSERT INTO #ClaimNotes ( ClaimId, ClaimLine, MemberId, [Source], NoteID, GroupType )
		SELECT	DISTINCT	
					ECD.ClaimID,
					ECD.ClaimLine,
					EC.MemberID,
					ECD.[Source],
					'B' AS NoteID,
					'NOTE RQ21' AS GroupType
		FROM	QNXT_Custom.EOB.EOB_Claim EC
		JOIN	QNXT_Custom.EOB.EOB_ClaimDetail ECD
			ON	EC.ClaimID = ECD.ClaimID
		LEFT JOIN	#ClaimNotes CN
			ON	ECD.ClaimID = CN.ClaimID
			AND	ECD.ClaimLine = CN.ClaimLine
			AND	EC.MemberID = CN.MemberID
			AND	ECD.[Source] = CN.[Source]
			AND CN.NoteID IN ( 'A', 'H' )
		WHERE	ECD.ClaimLineStatus = 'D'
			AND	CN.ClaimId IS NULL
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		INSERT INTO QNXT_Custom.EOB.EOB_0005Comments ( ProcessHeaderID, Insured_PolicyNumber, [Source], ClaimType, Claim_Number, Line_Number, Notes_Code, IncurredYear, Open_Field1 )
		SELECT DISTINCT
			@ProcessHeaderID AS ProcessHeaderID,
			C.MemberID AS Insured_PolicyNumber,
			C.[Source] AS [Source],
			EC.ClaimType,
			C.ClaimID AS Claim_Number,
			FORMAT(C.ClaimLine, '00#') AS Line_Number,
			NL.SortKey AS Notes_Code,
			YEAR(EC.BeginServiceDate) AS IncurredYear,
			C.NoteID AS Open_Field1
		FROM	#ClaimNotes C
		JOIN	QNXT_Custom.EOB.EOB_Claim EC
			ON	C.ClaimId = EC.ClaimID
		JOIN	EOB.EOB_NoteList NL
			ON	C.NoteID = NL.NoteID
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_0005Comments REBUILD;

		--Concatenate the 0005 records now, by claimline, and make them comma separated, and place them into 0003 Provider_Address1,2,3 fields 
		--(Don't think it's possible to need #2 or #3 fields yet -- max chars should be 34 per line w/ 17 notes)
		;WITH CTE AS ( 
		SELECT DISTINCT
			E03.Claim_Number,
			E03.Line_Number,
			E03.[Source],
			E03.EncounterType,
			Notes = STUFF((SELECT ',' + E05.Open_Field1 + '' 
							FROM	QNXT_Custom.EOB.EOB_0005Comments E05 
							WHERE	E05.Claim_Number = E03.Claim_Number
								AND	E05.[Source] = E03.[Source]
								AND E05.Line_Number = E03.Line_Number
								AND E05.Insured_PolicyNumber = E03.Insured_PolicyNumber							
							ORDER BY CAST(E05.Notes_Code AS INT)
							FOR XML PATH('')) , 1 , LEN(',') , '')
		FROM	QNXT_Custom.EOB.EOB_0003ServiceLine E03 )

		UPDATE E03 SET
			E03.Provider_Address1 = ISNULL(X.Notes, '')
		FROM	CTE X
		JOIN	QNXT_Custom.EOB.EOB_0003ServiceLine E03
			ON	X.Claim_Number = E03.Claim_Number
			AND X.Line_Number = E03.Line_Number
			AND X.EncounterType = E03.EncounterType
			AND X.[Source] = E03.[Source]
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO