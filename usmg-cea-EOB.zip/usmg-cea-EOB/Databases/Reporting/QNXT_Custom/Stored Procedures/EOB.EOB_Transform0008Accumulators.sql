CREATE PROCEDURE [EOB].[EOB_Transform0008Accumulators] (@BeginDate DATE, @EndDate DATE, @ProcessHeaderID INT, @RunYear INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Transform0008Accumulators.sql
-- Date:			10.22.2018
-- Author:			Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Transform all the notes into EOB.EOB_0008Accumulator
--
-- Called by:		NA
###########################################################################################################################################################
-- Parameters
--     
###########################################################################################################################################################
-- Ver  User		Date				US#			Change
-- 1.0	KB			10.22.2018			203876		Changes to accomodate EOB template and non-template redesign project
###########################################################################################################################################################
*/

TRUNCATE TABLE EOB.EOB_0008Accumulator

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		IF OBJECT_ID('TEMPDB..#MemberPlanYears') IS NOT NULL
		DROP TABLE #MemberPlanYears

		;WITH CTE AS
		(
			SELECT	EC.MemberID,
					YEAR(EC.BeginServiceDate) AS IncurredYear,
					EC.ContractCode,
					EC.PBPCode,
					EC.QNXTPlanID,
					ROW_NUMBER() OVER (PARTITION BY EC.MemberID, YEAR(EC.BeginServiceDate) ORDER BY EC.BeginServiceDate DESC) AS RowNum
			FROM	QNXT_Custom.EOB.EOB_Claim EC
			WHERE	YEAR(EC.BeginServiceDate) < @RunYear
		)
		SELECT	DISTINCT 
				CTE.MemberID,
				CTE.IncurredYear,
				CTE.ContractCode,
				CTE.PBPCode,
				CTE.QNXTPlanID
		INTO	#MemberPlanYears
		FROM	CTE
		WHERE	CTE.RowNum = 1
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		INSERT INTO QNXT_Custom.EOB.EOB_0008Accumulator ( ProcessHeaderID, Insured_PolicyNumber, IncurredYear, Open_Field1, Open_Field2, Open_Field3, Open_Field4, Open_Field5, Open_Field6, Open_Field7, Open_Field8 )
		SELECT DISTINCT
			@ProcessHeaderID AS ProcessHeaderID,
			EM.MemberID AS Insured_PolicyNumber,
			E02.IncurredYear AS IncurredYear,			
			MAX(ISNULL(EM.InDeductPaid, 0.00)) + MAX(ISNULL(EM.OutDeductPaid, 0.00)) AS Open_Field1,
			E02.IncurredYear AS Open_Field2,
			CASE WHEN MAX(EP.ServiceCategoryDeduct) <> '0.00' THEN MAX(EP.ServiceCategoryDeduct)
					ELSE IIF(MAX(ISNULL(EM.InNetworkDeductible, 0.00)) > MAX(ISNULL(EM.OutNetworkDeductible, 0.00)), MAX(ISNULL(EM.InNetworkDeductible, 0.00)), MAX(ISNULL(EM.OutNetworkDeductible, 0.00))) END AS Open_Field3,
			MAX(ISNULL(EM.InMOOPPaid, 0.00)) AS Open_Field4,
			MAX(ISNULL(EM.InNetworkMOOP, 0.00)) AS Open_Field5,
			CASE WHEN MAX(EP.PlanType) = 'PPO' THEN 'Y'
					ELSE 'N' END AS Open_Field6,
			CASE WHEN MAX(EP.PlanType) = 'PPO' THEN MAX(ISNULL(EM.InMOOPPaid, 0.00)) + MAX(ISNULL(EM.OutMOOPPaid, 0.00))
					ELSE '0.00' END AS Open_Field7,
			CASE WHEN MAX(EP.PlanType) = 'PPO' THEN IIF(MAX(ISNULL(EM.InNetworkMOOP, 0.00)) > MAX(ISNULL(EM.OutNetworkMOOP, 0.00)), MAX(ISNULL(EM.InNetworkMOOP, 0.00)), MAX(ISNULL(EM.OutNetworkMOOP, 0.00))) 
					ELSE '0.00' END AS Open_Field8		
		FROM	QNXT_Custom.EOB.EOB_0002EOB E02
		JOIN	#MemberPlanYears MPY
			ON	E02.Insured_PolicyNumber = MPY.MemberID
			AND E02.IncurredYear = MPY.IncurredYear
			AND	LTRIM(RTRIM(E02.MemberPlan)) = LTRIM(RTRIM(MPY.ContractCode)) + LTRIM(RTRIM(MPY.PBPCode))
		JOIN	QNXT_Custom.EOB.EOB_MOOP EM
			ON	E02.Insured_PolicyNumber = EM.MemberID
			AND E02.MemberPlan = EM.UPID
			AND E02.IncurredYear = LEFT(EM.MinMemberEffectiveDate, 4)		
		JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	E02.IncurredYear = EP.PlanYear
			AND	LTRIM(RTRIM(E02.MemberPlan)) = LTRIM(RTRIM(EP.ContractCode)) + LTRIM(RTRIM(EP.PBPCode))				
			AND (EP.GroupPlanID = '' OR MPY.QNXTPlanID = EP.GroupPlanID)
			AND EP.Active = 1		
		GROUP BY EM.MemberID, E02.IncurredYear
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
