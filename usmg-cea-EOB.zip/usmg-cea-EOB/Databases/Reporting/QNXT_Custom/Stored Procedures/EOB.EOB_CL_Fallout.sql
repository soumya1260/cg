CREATE PROCEDURE [EOB].[EOB_CL_Fallout] (@ProcessHeaderID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_CL_Fallout.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Data Prep for EOB Runs
--
-- Called by:		N/A
###########################################################################################################################################################
-- Parameters
--     N/A
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1  KB			07.12.2018			215695		Setting transaction isolation level to read committed and removing nolocks (CM20019357)
-- 1.2	KB			08.01.2019						CM20097013 - Change to not insert dups
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
	BEGIN TRANSACTION
		
		IF OBJECT_ID('TEMPDB..#CL_Fallout') IS NOT NULL
		DROP TABLE #CL_Fallout

		CREATE TABLE #CL_Fallout 
		(	
			ClaimID VARCHAR(20),
			MemberID VARCHAR(16),
			[Source] VARCHAR(60),
			ReasonID INT DEFAULT 0,
			[Status] VARCHAR(10) 
		)

		INSERT INTO #CL_Fallout (ClaimID, MemberID, [Source], ReasonID, [Status] )
		SELECT DISTINCT ERS.ClaimID, 
						ERS.MemberID,
						ERS.[Source],
						0 AS ReasonID,
						C.[Status]
		FROM	QNXT_Custom.EOB.EOB_Run_Staging ERS
		JOIN	Plandata_Prod.dbo.Claim C
			ON	ERS.ClaimID = C.ClaimID
			AND	ERS.[Source] = 'CL'
		LEFT JOIN QNXT_Custom.EOB.EOB_Recon ER
			ON	C.ClaimID = ER.ClaimID
			AND	ER.[Source] = 'CL'
			AND ER.ProcessHeaderID = @ProcessHeaderID
		LEFT JOIN QNXT_Custom.EOB.EOB_Fallout EF
			ON	ERS.ClaimID = EF.ClaimID
			AND	ERS.[Source] = 'CL'
		WHERE	ER.ClaimID IS NULL
			AND	EF.ClaimID IS NULL
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		CREATE CLUSTERED INDEX IDX_CL_Fallout ON #CL_Fallout ( ClaimID ASC, MemberID ASC, [Source] ASC, [Status] ASC )

		UPDATE	CLF 
		SET		CLF.ReasonID = CASE	WHEN CD.ClaimID IS NULL AND CLF.ReasonID = 0 THEN 3
											WHEN BP.UPID IN ('TX001','TX002','TX003','IL001','IL002','IL003','H6751001','H8423001') AND CLF.ReasonID = 0 THEN 4
											WHEN LEFT(BP.UPID, 5) IN ('S1566', 'S5578', 'S5617', 'S5822', 'S5932', 'S5998') AND CLF.ReasonID = 0 THEN 5
											WHEN BP.plantype IN ('Pharmacy', 'Comprehensive', 'Comp Dental') AND CLF.ReasonID = 0 THEN 6
											WHEN C.EnrollID = '' AND CLF.ReasonID = 0 THEN 7
											WHEN CLF.MemberID IN ('00000001', '') AND CLF.ReasonID = 0 THEN 8
											WHEN C.EnrollID <> '' AND EK.LastUpdate > C.PaidDate AND C.PaidDate > EK.TermDate AND CLF.ReasonID = 0 THEN 9
											WHEN EP.ContractCode IS NULL AND CLF.ReasonID = 0 THEN 10
											WHEN E.EntID IS NULL AND CLF.ReasonID = 0 THEN 11
											WHEN EP.Copay = '' AND EP.CoInsurance = '' AND EP.Deductible = '' THEN 13
											ELSE 0 END
		FROM	#CL_Fallout CLF
		JOIN	Plandata_Prod.dbo.Claim C
			ON	CLF.ClaimID = C.ClaimID
		JOIN	Plandata_Prod.dbo.EnrollKeys EK
			ON	C.EnrollID = EK.EnrollID
		JOIN	Plandata_Prod.dbo.BenefitPlan BP
			ON	EK.PlanID = BP.PlanID
		LEFT JOIN	Plandata_Prod.dbo.Member M
			ON	C.MemID = M.MemID
		LEFT JOIN	Plandata_Prod.dbo.Entity E
			ON	M.EntityID = E.EntID
			AND	E.Addr1 <> ''
			AND E.city <> ''
			AND	E.[State] <> ''
			AND	LEN(LTRIM(RTRIM(E.[State]))) = 2
			AND E.zip <> ''
			AND	LEN(LEFT(LTRIM(RTRIM(ISNULL(E.zip, ''))), 5)) = 5
		LEFT JOIN	Plandata_Prod.dbo.ClaimDetail CD
			ON	CLF.ClaimID = CD.ClaimID
		LEFT JOIN	QNXT_Custom.EOB.EOB_Plans EP
			ON	LEFT(BP.UPID, 5) = EP.ContractCode
			AND RIGHT(RTRIM(BP.UPID), 3) = EP.PBPCode
			AND YEAR(C.StartDate) = EP.PlanYear
			AND (EP.GroupPlanID = '' OR EK.planid = EP.GroupPlanID)
			AND EP.Active = 1			
		WHERE	CLF.ReasonID = 0
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))
		
		UPDATE	CLF 
		SET		CLF.ReasonID = 12
		FROM	#CL_Fallout CLF		
		JOIN	Plandata_Prod.dbo.ClaimEdit CE
			ON	CLF.ClaimID = CE.ClaimID
		JOIN	QNXT_Custom.EOB.EOB_ExcludedDenialRemits EDR
			ON  EDR.Active = 1
			AND ((CE.Reason = EDR.ReasonID)
				OR (CE.EobID = EDR.ReasonID))
		WHERE	CLF.ReasonID = 0
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		UPDATE	CLF 
		SET		CLF.ReasonID = 12
		FROM	#CL_Fallout CLF	
		JOIN	Plandata_Prod.dbo.ClaimEditMessage CEM
			ON	CLF.ClaimID = CEM.ClaimID								
		JOIN	QNXT_Custom.EOB.EOB_ExcludedDenialRemits EDR
			ON  EDR.Active = 1
			AND CEM.MessageID = EDR.ReasonID
		WHERE	CLF.ReasonID = 0
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		INSERT INTO QNXT_Custom.EOB.EOB_Fallout ( ClaimType, ClaimID, MemberID, ReasonID, [Source], ProcessHeaderID )
		SELECT DISTINCT	'CL' AS ClaimType,
						CLF.ClaimID,
						CLF.MemberID,
						CLF.ReasonID,
						CLF.[Source] AS [Source],
						@ProcessHeaderID AS ProcessHeaderID
		FROM		#CL_Fallout CLF
		OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

		ALTER INDEX ALL ON EOB.EOB_Fallout REBUILD

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
