CREATE PROCEDURE [EOB].[EOB_Update_Run_Master] (@ProcessHeaderID INT) AS
SET ANSI_WARNINGS, ANSI_PADDING, ANSI_NULLS, ARITHABORT, QUOTED_IDENTIFIER, XACT_ABORT, ANSI_NULL_DFLT_ON, CONCAT_NULL_YIELDS_NULL, NOCOUNT ON

/*
###########################################################################################################################################################
-- Name:			EOB_Update_Run_Master.sql
-- Date:			01.26.2018
-- Author:			Kaleb Osgood (kaleb.osgood@healthspring.com)
--					Ryan Brimmer (Ryan.Brimmer@healthspring.com)
--					Kiran Bhaskara (Kiran.Bhaskara@healthspring.com)
-- Purpose:			Update Run Master table by RunRequestID
--
-- Called by:		NA
###########################################################################################################################################################
-- Parameters
--     
###########################################################################################################################################################
-- Ver  User		Date				US#			Change  
-- 1.0  KCO         01.26.2018			107386		Initial release (CM0303204)
-- 1.1	KB			09.17.2018			203876		Changes to accomodate EOB template and non-template redesign projects
###########################################################################################################################################################
*/

SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRY
BEGIN TRANSACTION
	
	UPDATE ERM SET
		ERM.[Status] = 'COMPLETED',
		ERM.ProcessHeaderID = @ProcessHeaderID,
		ERM.UpdateID = SUSER_NAME(),
		ERM.LastUpdate = GETDATE(),
		ERM.CL_Processed_Claims = ISNULL(CL.CL_Processed_Claims, 0),
		ERM.CL_Processed_Members = ISNULL(CL.CL_Processed_Members, 0),
		ERM.RX_Processed_Claims = ISNULL(RX.RX_Processed_Claims, 0),
		ERM.RX_Processed_Members = ISNULL(RX.RX_Processed_Members, 0),
		ERM.EN_Processed_Claims = ISNULL(EN.EN_Processed_Claims, 0),
		ERM.EN_Processed_Members = ISNULL(EN.EN_Processed_Members, 0),
		ERM.Total_Processed_Members = ISNULL(Total.Total_Processed_Members, 0),
		ERM.CL_Sent_Claims = ISNULL(CL_Sent.CL_Sent_Claims, 0),
		ERM.CL_Sent_Members = ISNULL(CL_Sent.CL_Sent_Members, 0),
		ERM.RX_Sent_Claims = ISNULL(RX_Sent.RX_Sent_Claims, 0),
		ERM.RX_Sent_Members = ISNULL(RX_Sent.RX_Sent_Members, 0),
		ERM.EN_Sent_Claims = ISNULL(EN_Sent.EN_Sent_Claims, 0),
		ERM.EN_Sent_Members = ISNULL(EN_Sent.EN_Sent_Members, 0),
		ERM.Total_Sent_Members = ISNULL(Total_Sent.Total_Sent_Members, 0)
	FROM	QNXT_Custom.EOB.EOB_Run_Master ERM
	LEFT JOIN	(	
					SELECT	ERS.RunRequestID,
						COUNT(ERS.ClaimID) AS CL_Processed_Claims,
						COUNT(DISTINCT ERS.MemberID) AS CL_Processed_Members
					FROM	QNXT_Custom.EOB.EOB_Run_Staging ERS
					WHERE	ERS.[Source] = 'CL'
					GROUP BY ERS.RunRequestID ) AS CL
		ON	ERM.RunRequestID = CL.RunRequestID		
	LEFT JOIN	(	SELECT	ERS.RunRequestID,
						COUNT(ERS.ClaimID) AS RX_Processed_Claims,
						COUNT(DISTINCT ERS.MemberID) AS RX_Processed_Members
					FROM	QNXT_Custom.EOB.EOB_Run_Staging ERS
					WHERE	ERS.[Source] = 'RX'
					GROUP BY ERS.RunRequestID ) AS RX
		ON	ERM.RunRequestID = RX.RunRequestID		
	LEFT JOIN	(	SELECT	ERS.RunRequestID,
						COUNT(ERS.ClaimID) AS EN_Processed_Claims,
						COUNT(DISTINCT ERS.MemberID) AS EN_Processed_Members
					FROM	QNXT_Custom.EOB.EOB_Run_Staging ERS
					WHERE	ERS.[Source] NOT IN ( 'CL', 'RX' )
					GROUP BY ERS.RunRequestID ) AS EN
		ON	ERM.RunRequestID = EN.RunRequestID		
	LEFT JOIN	(	SELECT	ERS.RunRequestID,
						COUNT(DISTINCT ERS.MemberID) AS Total_Processed_Members
					FROM	QNXT_Custom.EOB.EOB_Run_Staging ERS
					GROUP BY ERS.RunRequestID ) AS Total
		ON	ERM.RunRequestID = Total.RunRequestID
	LEFT JOIN	(	SELECT	COUNT(ER.ClaimID) AS CL_Sent_Claims,
							COUNT(DISTINCT ER.MemberID) AS CL_Sent_Members
					FROM	QNXT_Custom.EOB.EOB_Recon ER
					WHERE	ER.[Source] = 'CL'
						AND	ER.ProcessHeaderID = @ProcessHeaderID ) AS CL_Sent
		ON	1=1
	LEFT JOIN	(	SELECT	COUNT(ER.ClaimID) AS RX_Sent_Claims,
							COUNT(DISTINCT ER.MemberID) AS RX_Sent_Members
					FROM	QNXT_Custom.EOB.EOB_Recon ER
					WHERE	ER.[Source] = 'RX'
						AND	ER.ProcessHeaderID = @ProcessHeaderID ) AS RX_Sent
		ON	1=1
	LEFT JOIN	(	SELECT	COUNT(ER.ClaimID) AS EN_Sent_Claims,
							COUNT(DISTINCT ER.MemberID) AS EN_Sent_Members
					FROM	QNXT_Custom.EOB.EOB_Recon ER
					WHERE	ER.[Source] NOT IN ('CL', 'RX')
						AND	ER.ProcessHeaderID = @ProcessHeaderID ) AS EN_Sent
		ON	1=1
	LEFT JOIN	(	SELECT	COUNT(DISTINCT ER.MemberID) AS Total_Sent_Members
					FROM	QNXT_Custom.EOB.EOB_Recon ER
					WHERE	ER.ProcessHeaderID = @ProcessHeaderID ) AS Total_Sent
		ON	1=1
	WHERE	ERM.[Status] = 'READY'
		AND ERM.CreateDate >= DATEADD(DAY, -2, GETDATE())

COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	;THROW
END CATCH
GO
