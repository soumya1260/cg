﻿MERGE EOB.rptEOBDRList AS T
USING (
    SELECT
        FDRDesc=('A2C'),    ('ACCESS2CARE'),    ('ADVOCATE'),       ('AdvocateBar'), 
        ('ASH_SF'),         ('Aspire'),         ('BLK'),            ('BlockVision'), 
        ('BP'),             ('CHSProf'),        ('COM'),            ('DAV'), 
        ('Delta'),          ('DELTADENTAL'),    ('DENTAQUEST'),     ('DQ'), 
        ('DRYER'),          ('GA_FOODS'),       ('HCSOL'),          ('Kelsey'), 
        ('LIF'),            ('MED3000'),        ('MedSolutions'),   ('MHN'), 
        ('MYNEXUS'),        ('NAMM'),           ('NP'),             ('NXT'), 
        ('OPT'),            ('PROSPECT'),       ('PsychCare'),      ('PWL'), 
        ('QST'),            ('SD'),             ('SeniorCarePartners'), 
        ('SILVERSNEAKERS'), ('SuperiorVision'), ('Swedish'),        ('UBH'), 
        ('UNIV_CHI'),       ('WELLMED') 
	) AS S
ON T.FDRDesc = S.FDRDesc
WHEN NOT MATCHED THEN 
	INSERT (FDRDesc) VALUES (S.FDRDesc);