$sourcepath = "$ENV:Build_SourcesDirectory\" # Source Control.  Run From here
$destpath = "$ENV:Build_BinariesDirectory\" # relative path ".\output" for the final nuget package
$configuration = "$ENV:build_target_configuration" # configuration used in build "debug"

$rdl = get-childitem -Path $sourcepath -Include *.rdl -Recurse -File
$rdl = $rdl | 
	# Only process rdls that are in a bin\$configuration folder
	Where-Object {$(Split-Path $_.Fullname -Parent) -like "*bin\$configuration"} | 

	# Loop through the list of items
	ForEach-Object {
		# Get the filename for joining back later
		$filename = Split-Path $_.FullName -Leaf

		# Get the path with out the two parent directories (GreatGrandParent)
		# first Split-Path gets current item directory
		# It takes two more calls to Split-Path to get the correct GreatGrandParent directory
		$RelPath = Split-Path -Path (Split-Path -Path (Split-Path -Path $_.FullName -Parent) -Parent) |
			#Make it a relative path to our current directory
			Resolve-Path -Relative

		# Join the specified destination folder with the relative path to get the path for this RDL
		$destinationfolder = Join-Path -Path $destpath -ChildPath $RelPath

		# join the filename to the destination folder
		$destinationfile = Join-Path -Path $destinationfolder -ChildPath $filename

		# Check if the destination folder exists
		If(!(test-path $destinationfolder)) {
				# Create the destination folder
				 New-Item -ItemType Directory -Force -Path $destinationfolder | Out-Null
			}

		# Tell what file is being moved to where
		Write-Host "moving $($_.FullName) to $destinationfile" 
		#Copy this RDL to the destination
		Copy-Item -Path $_.FullName -Destination $destinationfile

		}
