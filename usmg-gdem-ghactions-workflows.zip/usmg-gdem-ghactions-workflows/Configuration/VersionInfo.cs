using System.Reflection;
//can handle semantic version as well 1.0.0.0 final .0 will become the GITHUB_RUN_NUMBER
[assembly: AssemblyVersion("2024.2.3.0")]
[assembly: AssemblyFileVersion("2024.2.3.0")]
//the year will be replaced by GitHub Actions on Build
[assembly: AssemblyCopyright("Copyright © Cigna 2024")]