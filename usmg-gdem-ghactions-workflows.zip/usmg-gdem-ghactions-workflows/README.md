# USMG-GDem-GHActions-Workflows

A series of reusable workflows and actions

## Description

A series of reusable workflows and actions. This will abstract the CI/CD pipeline for
delivery of code. These workflows can be added to the delivery team workflows
for CI/CD and linting.  The actions will be referenced in the workflows.


## Tag and Release Automation is based on the shared-github-actions repo
- [shared-github-actions](https://github.com/zilvertonz/shared-github-actions/blob/main/version/github-release-create/README.md)