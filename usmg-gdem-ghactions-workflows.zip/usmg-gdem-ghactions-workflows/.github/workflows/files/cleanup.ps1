function Initialize-Cleanup() {
    $repos = "cmu-precomparison", "cmu-ui"
    foreach($repo in $repos){
        aws ecr delete-repository --repository-name $repo --force
    }
}

function Get-Print() {
    Write-Host "Hello AWS!"
}


Get-Print