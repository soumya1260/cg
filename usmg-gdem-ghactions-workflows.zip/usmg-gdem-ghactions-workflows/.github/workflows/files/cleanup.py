repos = ["cmu-precomparison", "cmu-ui"]
for x in repos:
    print(x)