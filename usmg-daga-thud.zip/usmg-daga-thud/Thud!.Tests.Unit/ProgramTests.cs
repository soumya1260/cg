﻿using System.Linq;
using NUnit.Framework;

namespace Cigna.DigitalApplications.Thud.Tests.Unit
{
    [TestFixture]
    public class ProgramTests
    {
        [Test]
        public void InitializeListsFromConfigurationManager_CreatesExpectedLists()
        {
            bool result = Program.InitializeListsFromConfigurationManager();
            Assert.That(result, Is.True);
            Assert.That(Program.Databases.Any, Is.True);
            Assert.That(Program.Databases.Count, Is.EqualTo(2));
            Assert.That(Program.Databases.Contains("PORTAL"), Is.True, "Could not find 'PORTAL' in the list of databases");
            Assert.That(Program.Databases.Contains("WAFFLES"), Is.True, "Could not find 'WAFFLES' in the list of databases");

            Assert.That(Program.Environments.Any, Is.True);
            Assert.That(Program.Environments.Count, Is.EqualTo(5));
        }

        [Test]
        public void ParseEnvironmentOption_SetsErrorMessageWhenBadEnvironmentIsSupplied()
        {
            bool result = Program.InitializeListsFromConfigurationManager();
            Assert.That(result, Is.True);

            var settings = new UpdateSettings();
            Program.ParseEnvironmentOption(new[] { "-env", "doodoo" }, 0, settings);
            Assert.That(settings.ArgumentsParsedSuccessfully, Is.False);
            Assert.That(settings.ErrorMessage, Is.Not.Empty);
        }

        [Test]
        public void ParseDatabaseOption_SetsErrorMessageWhenBadEnvironmentIsSupplied()
        {
            bool result = Program.InitializeListsFromConfigurationManager();
            Assert.That(result, Is.True);

            var settings = new UpdateSettings();
            int position = 0;
            Program.ParseDatabaseOption(new[] { "-db", "doodoo" }, settings, ref position, false);
            Assert.That(settings.ArgumentsParsedSuccessfully, Is.False);
            Assert.That(settings.ErrorMessage, Is.Not.Empty);
        }
    }
}