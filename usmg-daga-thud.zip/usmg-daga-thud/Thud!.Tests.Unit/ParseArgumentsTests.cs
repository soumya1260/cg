﻿using NUnit.Framework;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Cigna.DigitalApplications.Thud;

namespace Thud.Tests.Unit
{
    [TestFixture, ExcludeFromCodeCoverage, Category("Unit")]
    public class ParseArgumentsTests
    {
        [Test]
        public void ParseArguments_AllArgumentsParsedCorrectlyWhenConnectionDirectionAndWaitAreSubmitted()
        {
            string[] args = { "-Environment", "DEV", "-Rollout", "9", "-Wait" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(settings.ArgumentsParsedSuccessfully, settings.ErrorMessage);
            Assert.AreEqual("DEV", settings.Environment);
            Assert.AreEqual(UpdateDirections.Rollout, settings.UpdateDirection);
            Assert.That(settings.Wait, "settings.Wait");
        }

        [Test]
        public void ParseArguments_EnvironmentOptionReturnsErrorIfNoValueIsSubmitted()
        {
            string[] args = { "-Environment" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_EnvironmentReturnsErrorIfFollowedByOptionInsteadOfConnectionValue()
        {
            string[] args = { "-Environment", "-Wait" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_EnvironmentSubmittedAfterDatabaseReturnsError()
        {
            string[] args = { "-Database", "TestDB", "-Environment", "DEV" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_EnvironmentSubmittedAfterScriptReturnsError()
        {
            string[] args = { "-WriteScripts", "-Environment", "DEV" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_EnvironmentSubmittedTwiceReturnsError()
        {
            string[] args = { "-Environment", "DEV", "-Environment", "QA" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_DatabaseSubmittedAfterConnectionReturnsError()
        {
            string[] args = { "-Environment", "DEV", "-Database", "TestDB" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_DatabaseSubmittedTwiceReturnsError()
        {
            string[] args = { "-Database", "test", "-Database", "another" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_DatabaseWithParametersSetsDatabaseToSuppliedValue()
        {
            string[] args = { "-Database", "Waffles" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual("Waffles".ToUpperInvariant(), settings.DatabaseName);
        }

        [Test]
        public void ParseArguments_DirectionArgumentIsCaseInsensitive()
        {
            string[] args = { "-rOlLbAcK" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual(UpdateDirections.Rollback, settings.UpdateDirection);
        }

        [Test]
        public void ParseArguments_DoesNotFailWhenScriptIsSelectedAndBothRollbackAndRolloutAreSpecified()
        {
            string[] args = { "-WriteScripts", "test", "-Rollback", "8", "-Rollout", "15" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_FailsIfScriptIsSelectedAndRollbackIsNotSpecified()
        {
            string[] args = { "-WriteScripts", "test", "-Rollback", "8" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        //
        // Special case: If -WriteScripts is selected, -Rollout and -Rollback are required.
        //
        [Test]
        public void ParseArguments_FailsIfScriptIsSelectedAndRolloutIsNotSpecified()
        {
            string[] args = { "-WriteScripts", "test", "-Rollout", "8" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_ReturnRolloutIfDirectionIsNotSupplied()
        {
            string[] args = { };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(settings.ArgumentsParsedSuccessfully);
            Assert.AreEqual(UpdateDirections.Rollout, settings.UpdateDirection);
        }

        [Test]
        public void ParseArguments_ReturnsdefaultEnvironmentIfNotSupplied()
        {
            string[] args = { };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(settings.ArgumentsParsedSuccessfully);
            Assert.AreEqual(ConfigurationManager.AppSettings["defaultEnvironment"], settings.Environment);
        }

        [Test]
        public void ParseArguments_ReturnsErrorIfEnvironmentPrefixCantBeFoundInConnectionsList()
        {
            string[] args = { "-Environment", "buffalo" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_ReturnsErrorIfNonIntegerIsSubmitted()
        {
            string[] args = { "-rollout", "3.141592675" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_ReturnsErrorIfUnrecognizedDirectionIsSubmitted()
        {
            string[] args = { "-rollover" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_ReturnsNullIfNoVersionIsSupplied()
        {
            string[] args = { };
            var settings = Program.ParseArguments(args);
            Assert.That(settings.ArgumentsParsedSuccessfully);
            Assert.AreEqual(null, settings.RolloutToVersion);
        }

        [Test]
        public void ParseArguments_ReturnsNullVersionIfNotSubmitted()
        {
            string[] args = { "-rollout" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual(null, settings.RolloutToVersion);
        }

        [Test]
        public void ParseArguments_ReturnsRollbackIfSupplied()
        {
            string[] args = { "-rollback" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual(UpdateDirections.Rollback, settings.UpdateDirection);
        }

        [Test]
        public void ParseArguments_ReturnsSuppliedConnection()
        {
            string[] args = { "-Environment", "QA" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(settings.ArgumentsParsedSuccessfully);
            Assert.AreEqual("QA", settings.Environment);
        }

        [Test]
        public void ParseArguments_ReturnsVersionAsIntegerIfSubmitted()
        {
            string[] args = { "-rollout", "7" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual(7, settings.RolloutToVersion);
        }

        [Test]
        public void ParseArguments_RollbackSubmittedAfterRolloutReturnsErrorIfScriptNotSelected()
        {
            string[] args = { "-Rollback", "8", "-Rollout" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_RollbackSubmittedTwiceReturnsError()
        {
            string[] args = { "-Rollback", "9", "-Rollback", "7" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_RolloutArgumentValueIsRecognized()
        {
            string[] args = { "-ROLLOUT" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual(UpdateDirections.Rollout, settings.UpdateDirection);
        }

        [Test]
        public void ParseArguments_RolloutSubmittedAfterRollbackReturnsErrorIfScriptNotSelected()
        {
            string[] args = { "-Rollout", "-Rollback", "456" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_RolloutSubmittedTwiceReturnsError()
        {
            string[] args = { "-Rollout", "-Rollout", "7" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_ScriptedDatabaseNameIsNullIfNotSuppliedAndScriptOptionIsNotSelected()
        {
            string[] args = { };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual(null, settings.OutputFilePrefix);
        }

        [Test]
        public void ParseArguments_ScriptedDatabaseNameMatchesDefaultIfNotSuppliedAndWriteScriptOptionIsSelected()
        {
            string[] args = { "-WriteScripts", "sample" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual(ConfigurationManager.AppSettings["defaultDatabase"], settings.DatabaseName);
        }

        [Test]
        public void ParseArguments_ScriptOptionSetsScriptSetting()
        {
            string[] args = { "-WriteScripts" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(settings.WriteScript);
        }

        [Test]
        public void ParseArguments_ScriptSubmittedAfterConnectionReturnsError()
        {
            string[] args = { "-Environment", "DEV", "-WriteScripts" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_ScriptSubmittedTwiceReturnsError()
        {
            string[] args = { "-WriteScripts", "stuff", "-WriteScripts", "more_stuff" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_ScriptWithoutParameterSetsScriptPathToNull()
        {
            string[] args = { "-WriteScripts" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.IsNull(settings.OutputFilePrefix);
        }

        [Test]
        public void ParseArguments_ScriptWithParameterSetsScriptPathToSuppliedValue()
        {
            string[] args = { "-WriteScripts", "ReleaseXXX" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual("ReleaseXXX", settings.OutputFilePrefix);
        }

        [Test]
        public void ParseArguments_SetsRolloutToNullIfLatestIsSubmittedAsAParameter()
        {
            string[] args = { "-rollout", "latest" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(settings.ArgumentsParsedSuccessfully);
            Assert.AreEqual(null, settings.RolloutToVersion);
        }

        [Test]
        public void ParseArguments_SourceFolderSetsSqlFolderToSuppliedValue()
        {
            const string sqlTestScripts = @"..\..\SqlTestScripts";
            Program.InitializeListsFromConfigurationManager();
            string[] args = { "-SourceFolder", sqlTestScripts };
            var settings = Program.ParseArguments(args);
            Assert.AreEqual(sqlTestScripts, settings.SourceFolder);
        }

        [Test]
        public void ParseArguments_SqlFolderMatchesDefaultIfNotSupplied()
        {
            string[] args = { };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual(ConfigurationManager.AppSettings["defaultSourceFolder"], settings.SourceFolder);
        }

        [Test]
        public void ParseArguments_DatabaseMatchesDefaultIfNotSupplied()
        {
            string[] args = { };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.AreEqual(ConfigurationManager.AppSettings["defaultDatabase"], settings.DatabaseName);
        }

        [Test]
        public void ParseArguments_WaitIsFalseIfNotSupplied()
        {
            string[] args = { };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.Wait);
        }

        [Test]
        public void ParseArguments_WaitOptionIsTrueIfSubmitted()
        {
            string[] args = { "-Wait" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(settings.Wait);
        }

        [Test]
        public void ParseArguments_WaitSubmittedTwiceReturnsError()
        {
            string[] args = { "-Wait", "-Rollout", "-Wait" };
            Program.InitializeListsFromConfigurationManager();
            var settings = Program.ParseArguments(args);
            Assert.That(!settings.ArgumentsParsedSuccessfully);
        }

        [Test]
        public void ParseArguments_WriteScriptsWithEnvironmentSucceeds()
        {
            string[] args = { "-ws", "test", "-env", "DEV" };
            Program.InitializeListsFromConfigurationManager();
            UpdateSettings settings = Program.ParseArguments(args);
            Assert.That(settings.ArgumentsParsedSuccessfully, Is.True);
            Assert.That(settings.DatabaseName, Is.EqualTo(ConfigurationManager.AppSettings["defaultDatabase"]));
            Assert.That(settings.RolloutToVersion, Is.Null);
            Assert.That(settings.Environment, Is.EqualTo("DEV"));
        }

        [TestCase(1, new[] { "-GetVersions", "-env", "DEV" }, null, "DEV")]
        [TestCase(2, new[] { "-gv", "-env", "DEV", "-db", "Portal" }, null, "DEV", "Portal")]
        [TestCase(3, new[] { "-gv", "-env", "QA", "-db", "Portal" }, null, "QA", "Portal")]
        [TestCase(4, new[] { "-gv", "-env", "DEV" }, null, "DEV")]
        [TestCase(5, new[] { "-gv" }, null, "DEV", "PORTAL")]
        [TestCase(6, new[] { "-gv", "-env", "QA", "-db", "WAFFLES" }, null, "QA", "WAFFLES")]
        [TestCase(7, new[] { "-gv", "-env", "QA", "-db", "WAFFLES", "-sf", "pancakes" }, null, "QA", "WAFFLES", "pancakes")]
        [TestCase(8, new[] { "-gv", "-ro", "latest" }, null, "DEV", "PORTAL")]
        [TestCase(9, new[] { "-gv", "-ro", "71" }, 71L, "DEV", "PORTAL")]
        public void ParseArguments_GetVersionsOptionSucceeds(
            int testCaseNumber,
            string[] args,
            long? expectedRollout,
            string expectedEnvironment,
            string expectedDatabase = null,
            string expectedSourceFolder = null)
        {
            expectedDatabase = expectedDatabase ?? ConfigurationManager.AppSettings["defaultDatabase"];
            expectedSourceFolder = expectedSourceFolder ?? ConfigurationManager.AppSettings["defaultSourceFolder"];

            Program.InitializeListsFromConfigurationManager();
            UpdateSettings settings = Program.ParseArguments(args);

            Assert.That(settings.ArgumentsParsedSuccessfully, Is.True, "Arguments were not parsed successfully.");

            Assert.That(settings.DatabaseName.ToUpperInvariant(), Is.EqualTo(expectedDatabase.ToUpperInvariant()),
                $"Database name should have been {expectedDatabase}, but was {settings.DatabaseName}");

            Assert.That(settings.SourceFolder, Is.EqualTo(expectedSourceFolder));

            Assert.That(settings.RolloutToVersion, Is.EqualTo(expectedRollout), $"Expected rollout to be {expectedRollout}, but was {settings.RolloutToVersion}");
            Assert.That(settings.Environment, Is.EqualTo(expectedEnvironment));
        }

        [TestCase(1, new[] { "-GetVersions", "-env", "DEV" }, true)]
        [TestCase(2, new[] { "-gv", "-env", "DEV", "-db", "Portal" }, true)]
        [TestCase(3, new[] { "-gv", "-env", "QA", "-db", "Portal" }, true)]
        [TestCase(4, new[] { "-gv", "-env", "DEV" }, true)]
        [TestCase(5, new[] { "-gv" }, true)]
        [TestCase(6, new[] { "-gv", "-env", "QA", "-db", "WAFFLES" }, true)]
        [TestCase(7, new[] { "-gv", "-env", "QA", "-db", "WAFFLES", "-sf", "pancakes" }, true)]
        [TestCase(8, new[] { "-gv", "-ro", "latest" }, true)]
        [TestCase(9, new[] { "-gv", "-ro", "71" }, true)]
        [TestCase(10, new[] { "-gv", "-rb", "71" }, false)]  // Can't use -rb with -gv
        [TestCase(11, new[] { "-gv", "-ws", "crepes" }, false)] // Can't use -ws with -gv
        public void SanityCheckArguments_SucceedsForGetVersionsCalls(int caseNumber, string[] args, bool expectedResult)
        {
            Program.InitializeListsFromConfigurationManager();
            UpdateSettings settings = Program.ParseArguments(args);

            ArgumentStatus argumentStatus = new ArgumentStatus
            {
                GetVersionsUsed = args.Contains("-GetVersions") || args.Contains("-gv"),
                EnvironmentUsed = args.Contains("-Environment") || args.Contains("-env"),
                DatabaseUsed = args.Contains("-Database") || args.Contains("-db"),
                RolloutUsed = args.Contains("-Rollout") || args.Contains("-ro"),
                SourceFolderUsed = args.Contains("-SourceFolder") || args.Contains("-sf"),
                ScriptUsed = args.Contains("-WriteScripts") || args.Contains("-ws"),
                RollbackUsed = args.Contains("-Rollback") || args.Contains("-rb")
            };

            Program.SanityCheckArguments(settings, argumentStatus);
            Assert.That(settings.ArgumentsParsedSuccessfully, Is.EqualTo(expectedResult));
        }
    }
}