﻿using System.Collections.Generic;
using NUnit.Framework;

namespace Cigna.DigitalApplications.Thud.Tests.Unit
{
    [TestFixture]
    public class ExtensionsTests
    {
        private SortedList<long, string> _list;

        [SetUp]
        public void SetUp()
        {
            _list = new SortedList<long, string>
            {
                { 1, "First"},
                { 10, "tenth"},
                { 22, "twenty-second"},
                { 25, "twenty-fifth"},
                { 31, "thirty-first" },
                { 42, "the answer to the question of life, the universe and everything" },
                { 47, "forty-seventh" }
            };
        }

        [TestCase(42, 47)]
        [TestCase(47, -1)]
        [TestCase(1, 10)]
        [TestCase(0, 1)]
        public void Next_YieldsExpectedResults(long current, long expected)
        {
            long result = _list.Next(current).Key;
            Assert.That(result, Is.EqualTo(expected));
        }

        [TestCase(47, 42)]
        [TestCase(10, 1)]
        [TestCase(1, 0)]
        [TestCase(0, 0)]
        public void Previous_YieldsExpectedResults(long current, long expected)
        {
            long result = _list.Previous(current).Key;
            Assert.That(result, Is.EqualTo(expected));
        }
    }
}