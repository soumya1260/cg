﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using NUnit.Framework;

namespace Cigna.DigitalApplications.Thud.Tests.Unit
{
    [TestFixture, ExcludeFromCodeCoverage, Category("Unit")]
    public class DatabaseUpdaterTests
    {
        private static UpdateSettings DefaultTestSettings()
        {
            var settings = new UpdateSettings
            {
                ArgumentsParsedSuccessfully = true,
                OutputFilePrefix = null,
                ErrorMessage = null,
                WriteScript = false,
                UpdateDirection = UpdateDirections.Rollout,
                SourceFolder = null,
                Wait = false,
                Environment = null,
                RolloutToVersion = null,
                DatabaseName = "DatabaseUpdaterSandbox"
            };
            return settings;
        }

        [Test]
        public void ValidateScriptLists_ReturnsFalseIfListsAreNotTheSameSize()
        {
            var rolloutScripts = new List<string>
            {
                "a-00001-rollout.sql",
                "a-00002-rollout.sql",
            };
            var rollbackScripts = new List<string>
            {
                "a-00001-rollback.sql",
                "a-00002-rollback.sql",
                "a-00003-rollback.sql"
            };

            var settings = DefaultTestSettings();

            var updater = new DatabaseUpdater(settings);

            Assert.That(updater.ValidateScriptLists(rolloutScripts, rollbackScripts, out List<string> mismatchedScripts), Is.False);
            Assert.That(mismatchedScripts.Count, Is.EqualTo(1));
            Assert.That(mismatchedScripts[0], Is.EqualTo("a-00003-rollback.sql"));
        }

        [Test]
        public void ValidateScriptLists_ReturnsFalseIfListsDoNotLineUp()
        {
            var rolloutScripts = new List<string>
            {
                "a-00001-rollout.sql",
                "a-00002-rollout.sql",
                "a-00003-rollout.sql"
            };
            var rollbackScripts = new List<string>
            {
                "a-00001-rollback.sql",
                "a-00002-rollback.sql",
                "a-00007-rollback.sql"
            };

            var settings = DefaultTestSettings();

            var updater = new DatabaseUpdater(settings);

            Assert.That(updater.ValidateScriptLists(rolloutScripts, rollbackScripts, out List<string> mismatchedScripts), Is.False);
            Assert.That(mismatchedScripts.Count, Is.EqualTo(2));
            Assert.That(mismatchedScripts.Contains("a-00003-rollout.sql"), Is.True);
            Assert.That(mismatchedScripts.Contains("a-00007-rollback.sql"), Is.True);
        }

        [Test]
        public void ValidateScriptLists_ReturnsTrueIfListsLineUp()
        {
            var rolloutScripts = new List<string>
            {
                "a-00001-rollout.sql",
                "a-00002-rollout.sql",
                "a-00003-rollout.sql"
            };
            var rollbackScripts = new List<string>
            {
                "a-00001-rollback.sql",
                "a-00002-rollback.sql",
                "a-00003-rollback.sql"
            };

            var settings = DefaultTestSettings();

            var updater = new DatabaseUpdater(settings);

            Assert.That(updater.ValidateScriptLists(rolloutScripts, rollbackScripts, out List<string> mismatchedScripts), Is.True);
            Assert.That(mismatchedScripts, Is.Empty);
        }
    }
}