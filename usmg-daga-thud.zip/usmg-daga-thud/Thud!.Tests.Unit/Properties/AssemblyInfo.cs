﻿using System.Runtime.InteropServices;

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.

[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("c8adf41e-5954-4294-b310-12e46f796a26")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// NOTE: Version information is being set in the VersionInfo.cs file
// To include it, just add VersionInfo.cs as a Linked file to each project
// 1. Add existing Item
// 2. Select VersionInfo.cs from the solution root
// 3. Change the "Add" dropdown to "Add as link"
