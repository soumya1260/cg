# THUD! UTILITY
## USER’S GUIDE
### PURPOSE
THUD! provides an automated solution for applying schema and data updates to databases using programmer-created scripts.
Three basic workflows are supported:
-	Roll-out to a connected database
-	Roll-back to a connected database
-	Scripted roll-out/roll-back for submission to a production DBA

### SOURCE SCRIPTS
The scripts are stored in a common folder and must follow the naming convention:
`databaseName sequence [rollout|rollback].sql`

For example:
-	`Portal-000001-rollout.sql`
-	`Portal-000001-rollback.sql`

Scripts are created in pairs.  For every roll-out script, there must be a roll-back script that restores the database to the 
condition it was in prior to the rollout.  The utility checks to see if the source scripts are properly paired before applying
updates or generating scripts and will exit with an error if they are not.

The scripts should not include a “USING _databasename_” at the beginning, but it is not an error to do so.

By default, scripts are expected to be found in the folder designated in the configuration file by the key 
“defaultSourceFolder”.  This can be over-ridden on the command line using the `–SourceFolder` option.

### ROLLING OUT TO A CONNECTED DATABASE
Rolling out to a connected database will upgrade that database to the latest script (or to a specified sequence number).  The 
utility uses a version number in the database to determine which scripts need to be applied.  If the utility determines that 
the database is already up-to-date, it will take no action.

If the utility is run on a database that has not been versioned yet, a version table will be created and the database version 
will be set to zero.

Updates are applied sequentially and the database version number is updated after each successful increment.  If any increment
fails, the utility will report the error, run the associated roll-back script and stop.  This allows the error condition to be
corrected and the roll-out can be run again, picking up from the point of failure.

#### COMMAND LINE OPTIONS
Roll-out supports the following command line options, which can be supplied in any order:
-	`–Rollout [ _version_ | latest ]`  – if version is not supplied, “latest” is assumed.  This option can be abbreviated as `–ro`.
-	`-Environment _environment_` – this specifies the environment to be updated and corresponds to the environment portion of the
   connection string name.  (See “Connection Strings” below.)    If not supplied, this option defaults to the configuration
   value defaultEnvironment.  The abbreviation for this command is `–env`.
-	`–SourceFolder _path_` – This tells the utility where to find the roll-out scripts.  If not supplied, this option defaults to 
  the configuration value defaultSourceFolder.  The abbreviation for this command is `–sf`.
-	`–Database _database_` – This defines the database to be updated and corresponds to the databaseName portion of the connection
  string.  It also selects which set of update scripts will be used from the Source Folder.  If not supplied, this option 
  defaults to the configuration value defaultDatabase.  The abbreviation for this command is `–db`.

Examples:
-	`thud!.exe –Rollout latest –Database Portal –Environment DEV`
-	`thud! –ro –db Portal –env DEV`
-	`thud! –ro`
The last example will roll-out to the latest script in the default source folder using the default database and environment.

#### CONNECTION STRINGS
In order to roll-out to a connected database, a connection string for the database must be defined in the application’s 
configuration file.  The connection string name must follow the convention: `databaseName-environment.`

For example:
-	`Portal-DEV`
-	`Portal-QA`
 
### ROLLING BACK TO A CONNECTED DATABASE
Rolling out to a connected database will downgrade that database to the specified sequence number.  The utility uses a version
number in the database to determine which scripts need to be applied.  If the utility determines that the database is already
at the specified version or a prior one, it will leave the database unchanged.

If the utility is commanded to rollback to version zero, all scripts will be rolled-back and the version table will be removed.

Updates are applied sequentially and the database version number is updated after each successful increment.  If any increment 
fails, the utility will report the error, run the associated rollout and stop.  This allows the error condition to be corrected
and the roll-back can be run again, picking up from the point of failure.

It’s important to note that a roll-back is to a specific version.  For example, if a database is currently at version 10 and the 
user requests a roll-back to version six, the utility will apply the roll-back scripts for versions 10, 9, 8 and 7.   Roll-back
script 7 restores the database to where it was when roll-out script 6 was originally applied, so it is the last script run.

#### COMMAND LINE OPTIONS
Roll-back supports the following command line options, which can be supplied in any order:
-	`–Rollback _version_` – the version argument is required.  This option can be abbreviated as `–rb`.
-	`–Environment _environment_` – this specifies the environment to be updated and corresponds to the environment portion of the 
  connection string name.  (See “Connection Strings” in the previous section.)    If not supplied, this option defaults to the
  configuration value defaultEnvironment.  The abbreviation for this command is `–env`.
-	`–SourceFolder _path_` – This tells the utility where to find the roll-out scripts.  If not supplied, this option defaults to the
  configuration value `defaultSourceFolder`.  The abbreviation for this command is `–sf`.
-	`–Database _database_` – This defines the database to be updated and corresponds to the databaseName portion of the connection 
	string.  It also selects which set of update scripts will be used from the Source Folder.  If not supplied, this option defaults
  to the configuration value defaultDatabase.  The abbreviation for this option is `–db`.

Examples:
-	`thud!.exe –Rollback 42 –Database Portal –Environment DEV`
-	`thud! –rb 42 –db Portal –env DEV`
-	`thud! –rb 42`
The last example will roll-back to version 42 using the default database, source folder and environment.
 
### SCRIPTED ROLL-OUT/ROLL-BACK
This option creates a pair of roll-out and roll-back scripts consolidating a range of source scripts.  The resultant scripts wrap the
entire update into a single transaction and ensure that the database version number is properly maintained.

It should be noted that the –Rollback value supplied is the current version of the production database to be updated.  The generated 
scripts contain updates after, but not including the rollback version number.  This is one of those things that makes sense if you
don’t try to over-think it.  Just state what version you would need to roll out to and what version you would need to roll back to if
there were a need to roll back and the correct scripts will be generated.

There are two “flavors” of this command.  The “disconnected” approach assumes you don’t have access to the target database, but you 
know what the correct rollout and roll-back values are.  The “connected” approach will query the target database to find out what the
roll-back value should be.

#### COMMAND LINE OPTIONS –  CONNECTED APPROACH
Scripted roll-out/roll-back supports the following command line options, which can be supplied in any order:
-	`–WriteScripts filenamestub` – This option signals that scripts should be generated instead of updating an attached database.  
  _filenamestub_ is the prefix that will be added to the names of the roll-out and roll-back files that are generated.  This option
  can be abbreviated as `–ws`.
-	`–Environment environment` – This argument is required for the connected version of WriteScripts.  The tool will contact the
  database in the specified environment and use its current version number as the rollback value.
-	`–Rollout [ version | latest ]` – if version is not supplied, “latest” is assumed.  This option can be abbreviated as `–ro`.  If 
  this option is omitted, `latest` is assumed.
-	`–SourceFolder path` – This tells the utility where to find the roll-out scripts.  If not supplied, this option defaults to the
  configuration value defaultSourceFolder.  The abbreviation for this command is –sf.
-	`–Database database` – This is the name of the database to be updated.  It will be used to generate the “USING” statement at the 
  start of the generated files and selects which set of update scripts will be used from the Source Folder.  
  
  If, for some reason, the database name in production does not match the database name used to prefix the SQL file names in the Source 
  Folder, then the USING statements in the generated files will need to be edited prior to their application.
  
  If not supplied, this option defaults to the configuration value defaultDatabase.  The abbreviation for this command is `–db`.

Example:
-	`thud! –ws Release6.1 –env Prod –db Portal`

This will generate two scripts named Release6.1-rollout.sql and Release6.1-rollback.sql.  The roll-out script will apply updates to 
bring the production database to the latest script version.  The roll-back script will apply roll-backs to restore the database to its
current version.

### COMMAND LINE OPTIONS – DISCONNECTED APPROACH
Scripted roll-out/roll-back supports the following command line options, which can be supplied in any order:
-	`–WriteScripts filenamestub` – This option signals that scripts should be generated instead of updating an attached database.
  _filenamestub_ is the prefix that will be added to the names of the roll-out and roll-back files that are generated.  This option 
  can be abbreviated as `–ws`.
-	`–Rollback version` – This option is required for the disconnected version of WriteScripts.  It can be abbreviated as `–rb`.
-	`–Rollout [ version | latest ]`  – if version is not supplied, “latest” is assumed.  This option can be abbreviated as `–ro`.  If
  this option is omitted, `latest` is assumed.
-	`–SourceFolder path` – This tells the utility where to find the roll-out scripts.  If not supplied, this option defaults to the
  configuration value `defaultSourceFolder`.  The abbreviation for this command is `–sf`.
-	`–Database database` – This is the name of the database to be updated.  It will be used to generate the “USING” statement at the
  start of the generated files and selects which set of update scripts will be used from the Source Folder.  

If, for some reason, the database name in production does not match the database name used to prefix the SQL file names in the Source 
Folder, then the USING statements in the generated files will need to be edited prior to their application.

If not supplied, this option defaults to the configuration value defaultDatabase.  The abbreviation for this command is –db.

Example:
-	`thud! –ws Release6.1 –ro 70 –rb 42 –db Portal`
 
This will generate two scripts named Release6.1-rollout.sql and Release6.1-rollback.sql.  The roll-out script will apply updates 43 
through 70.  The roll-back script will apply roll-backs 70 through 43, leaving the database in the condition it was in after update 42.
 
### MISCELLANEOUS COMMAND LINE OPTIONS
-	`–Help` – Displays a usage message in the console window.  This is equivalent to supplying no options.
-	`–Usage` – This is the same as `–Help`.
-	`–Wait` – Developer option.  This causes the application to wait for a key press before exiting.
-	`–ShowStackTrace` – Developer option.  Currently disabled.  Abbreviated as `–st`.
-	`–GetVersions` – This is a command developed for CHS DevOps.  It outputs a string with database and version information intended for 
  use in an email to the production DBAs.  The shortcut version of the command is `–gv`.
  
  ```
  C:\>thud! -gv -env prod
  providerdbportalgreen.healthspring.inside: Portal (apply scripts 204 through 215)
  ```
  
-	`–GetDatabaseVersion` – This command was also developed for CHS DevOps.  It simply outputs the current database version number to the
   console.  It can be abbreviated as `–gdv`.

  ```
  C:\>thud!.exe" -gdv -db portal -env uat
  215
  ```

### SAMPLE WEB.CONFIG
```xml
<?xml version="1.0" encoding="utf-8"?>

<configuration>
  <startup>
    <supportedRuntime version="v4.0" sku=".NETFramework,Version=v4.5" />
  </startup>
  <connectionStrings>
    <add name="Portal-DEV"
         connectionString="Data Source=HSTNSQLWEBDEV01;Initial Catalog=Portal;Integrated Security=SSPI;/>
    <add name="Portal-QA"
         connectionString="Data Source=HSTNSQLWEBQA01;Initial Catalog=Portal;Integrated Security=SSPI;/>
    <add name="Portal-UAT"
         connectionString="Data Source=HSTNSQLWEBUAT01;Initial Catalog=Portal;Integrated Security=SSPI;/>
    <add name="Portal-ITE"
         connectionString="Data Source=HSITESQLWEB01;Initial Catalog=Portal;Integrated Security=SSPI;/>
    <add name="SoftwareSolutionsADS-DEV"
         connectionString="Data Source=HSTNSQLWEBDEV01;Initial Catalog=SoftwareSolutionsADS;Integrated Security=SSPI;/>
    <add name="SoftwareSolutionsADS-QA"
         connectionString="Data Source=HSTNSQLWEBQA01;Initial Catalog=SoftwareSolutionsADS;Integrated Security=SSPI;/>
    <add name="SoftwareSolutionsADS-UAT"
         connectionString="Data Source=HSTNSQLWEBUAT01;Initial Catalog=SoftwareSolutionsADS;Integrated Security=SSPI;/>
    <add name="SoftwareSolutionsADS-ITE"
         connectionString="Data Source=HSITESQLWEB01;Initial Catalog=SoftwareSolutionsADS;Integrated Security=SSPI;/>
    <add name="ODSStaging-DEV"
         connectionString="Data Source=HSTNSQLWEBDEV01;Initial Catalog=ODSStaging;Integrated Security=SSPI;/>
    <add name="ODSStaging-QA"
         connectionString="Data Source=HSTNSQLWEBQA01;Initial Catalog=ODSStaging;Integrated Security=SSPI;/>
    <add name="ODSStaging-UAT"
         connectionString="Data Source=HSTNSQLWEBUAT01;Initial Catalog=ODSStaging;Integrated Security=SSPI;/>
    <add name="ODSStaging-ITE"
         connectionString="Data Source=HSITESQLWEB01;Initial Catalog=ODSStaging;Integrated Security=SSPI;/>
  </connectionStrings>
  <appSettings>
    <add key="defaultEnvironment" value="DEV" />
    <add key="defaultSourceFolder" value="..\..\..\..\SQL Scripts" />
    <add key="defaultDatabase" value="Portal" />
    <add key="commandTimeoutInSeconds" value="7200"/> <!-- 7200 seconds == 2 hours -->
  </appSettings>
</configuration>
```

Note that multiple databases can be supported from a single configuration file.  The example above supports “Portal”, 
“SoftwareSolutionsADS” and “ODSStaging”.
 
### INTEGRATION WITH OCTOPUS DEPLOY
#### OVERVIEW
In order to use THUD! with OctopusDeploy, you need to create a deployment package that includes the THUD! utility, its 
configuration file and a folder of numbered scripts.

The easiest way to do this is to create a new project that contains all three components.  You can then set up Octopus
Deploy to deploy the project and then run the utility in the deployment environment.  This article describes the steps 
you need to take to get your solution set up for this.

##### STEP 1: CREATE A NEW PROJECT
In order for your project to be deployable by Octopus Deploy, it needs to satisfy two conditions:
-	It needs to be buildable by Visual Studio or MSBuild;
-	It needs to support references so that NuGet can drop files into it.

When I first tried to do this, I had hoped I could leverage the Shared Project template because Shared Projects only 
contain code.  They don't get built directly, but their code gets included into any project that references them.  (This
is similar to how C/C++ uses #include.)  I wanted to use them in order to not have any dummy code in the project.
Unfortunately, you can't add NuGet references to a Shared Project.

So, this guide will use a Class Library project.
1.	Right-click on your solution and select Add | New Project... from the context menu.
2.	Select "Class Library (.NET Framework)"
3.	Set the Name: field to something like _YourSolution_-THUD!
4.	Be sure to select the correct framework for your project from the Framework: drop-down.
5.	Activate the [OK] button.
6.	Rename class1.cs to DoNotUse.cs

##### STEP 2: MOVE/CREATE SEQUENTIALLY-NUMBERED SQL SCRIPTS
1.	In this step, you will create a folder to contain your sequentially-numbered SQL scripts.
2.	Right-click on the project you just created in Step 1 and select Add | New Folder from the context menu.
3.	Rename the folder to Scripts.
4.	If you have existing THUD! scripts, move them into this Scripts folder from the solutions SQL Scripts folder.
5.	Delete the old SQL Scripts folder.

##### STEP 3: MOVE/CREATE THE THUD!.CONFIG FILE
Now you will need a configuration file for THUD! to set its connection strings and set up a few default values.

###### IF YOU ALREADY USE THUD! IN YOUR SOLUTION...
1.	Copy Thud!.exe.config from the solution's tools\Thud! folder to your new project and place it in the root folder
    of the project.  You can do this by dragging and dropping the file using Solution Explorer in Visual Studio.
3.	Edit the copied file and change the appSetting for defaultSourceFolder to "Scripts".
    ```xml
    <add key="defaultSourceFolder" value="Scripts" />
    ```
    This will match the new script folder you created in step 2.
    
###### IF YOU ARE SETTING UP THUD! FOR THE FIRST TIME...
1.	Right-click on  your THUD! project and select Add | New Item...
2.	In the dialog select XML File
3.	Set the name to Thud!.exe.config
4.	Activate the [[OK]] button.
5.	Replace the contents of the new file with the following XML:
    ```xml
    <?xml version="1.0" encoding="utf-8"?>
    <configuration>
      <startup>
        <supportedRuntime version="v4.0" sku=".NETFramework,Version=v4.5" />
      </startup>
      <connectionStrings>
        <add name="Sample-DEV" connectionString="Data Source=DEVSQL;Initial Catalog=Sample;Integrated Security=SSPI;" />
        <add name="Sample-QA" connectionString="Data Source=QASQL;Initial Catalog=Sample;Integrated Security=SSPI;" />
        <add name="Sample-UAT" connectionString="Data Source=UATSQL;Initial Catalog=Sample;Integrated Security=SSPI;" />
        <add name="Sample-ITE" connectionString="Data Source=ITESQL;Initial Catalog=Sample;Integrated Security=SSPI;" />
        <add name="Sample-Blue" connectionString="Data Source=BLUESQL;Initial Catalog=Sample;Integrated Security=SSPI;" />
        <add name="Sample-Green" connectionString="Data Source=GREENSQL;Initial Catalog=Sample;Integrated Security=SSPI;" />
      </connectionStrings>
      <appSettings>
        <add key="defaultEnvironment" value="DEV" />
        <add key="defaultSourceFolder" value="Scripts" />
        <add key="defaultDatabase" value="Sample" />
        <add key="commandTimeoutInSeconds" value="7200"/> <!-- 7200 seconds == 2 hours -->
      </appSettings>
    </configuration>
    ```
6.	You will need to edit the boilerplate to match your database(s) and environments.

##### STEP 4: ADD THUD! FROM NUGET
Now you will integrate the THUD! tool into your project.  You'll get the tool from NuGet from Cigna’s Artifactory store. 
You will need to make sure that Visual Studio's NuGet tool is configured to access the Artifactory store.

Assuming your VisualStudio is already configured to use the internal store, here's all you need to do:
1.	Right-click on your THUD! project and select Manage NuGet Packages...
2.	Select the internal store from the Package source: drop-down.
3.	Activate the Browse link
4.	In the search box, type: THUD!
5.	Activate the THUD! item
6.	Activate the [Install] button
    DO NOT CLOSE the NuGet window!
    
##### STEP 5: ADD OCTOPACK FROM NUGET
Now you will link OctoPack to your project so that the build server can generate a NuGet package using the .nuspec file
you'll create in Step 6.
1.	Change the Package source: to All.
2.	Activate the Browse link
3.	In the search box, type: OctoPack.
4.	Activate the OctoPack by Octopus Deploy item.
5.	Activate the [Install] button.
6.	Close the NuGet window.

##### STEP 6: CREATE THE .NUSPEC FILE
Your project is only missing one thing at this point: a .nuspec file.  This file tells OctoPack and NuGet how they should 
lay out the NuGet package that Octopus Deploy will eventually deploy.
1.	Right-click your THUD! project and select Add | New Item...
2.	In the dialog select XML File
3.	Set the name to _YourSolution_-THUD!.nuspec where _YourSolution_-THUD! matches the name of your .csproj file (without the .csproj)
4.	It is CRITICAL that the .nuspec and .csproj file names match.  MSBuild will ignore the .nuspec if the name is different.
5.	Activate the [OK] button.
6.	Replace the contents of the new file with the following XML:
    ```xml
    <?xml version="1.0"?>
    <!--
     .nuspec for SQL deployment projects using THUD!.exe and OctoPak -->
    <!--
      NOTES:
        While this is a .nuspec file, OctoPak follows different rules than
        a standard convention-based nuget pack/deploy.  So you should NOT
        be using the "content" or "lib" pseudo-folders when using OctoPak.

        $$ variables are not pre-filled from Properties\AssemblyInfo.cs.
        The $version$ variable WILL be pre-filled by the build server if
        the correct OctoPack option has been selected.

        Files marked with the build action "Content" will not be
        automatically added to your .nupkg.  Every file that you want to
        deploy must be called out explicitly or with a wildcard.

       ASSUMPTIONS:
        Your project must build to the bin folder not bin\Debug or
        bin\Release.  (See Project Properties => Build Tab => Output Path)
        OctoPak doesn't appear to support the $configuration$ variable
        when called from MSBuild.

       TO TEST YOUR OCTOPACK:
        Issue the following from a DOS or PowerShell command line in the
        root of your project folder:

           msbuild <project name>.csproj /t:Build /p:RunOctoPack=true

        Only change "<project name>" to your project's name.
    -->
    <package >
      <metadata>
        <!-- REQUIRED by OctoPak -->
        <id>YourSolution-THUD!</id>


        <!-- REQUIRED by OctoPak -->
        <authors>Cigna-HealthSpring</authors>


        <!-- REQUIRED by OctoPak -->
        <description>
           SQL Deployment package for YOUR SOLUTION
        </description>


        <!-- REQUIRED by OctoPak, but $version$ should be supplied by build server. -->
        <version>$version$</version>
          <!-- The remaining metadata elements are OPTIONAL for OctoPak-->
        <title>YOUR SOLUTION - THUD!</title>
        <owners>$owners$</owners>
        <requireLicenseAcceptance>false</requireLicenseAcceptance>
        <copyright>Copyright © 2018</copyright>
        <tags></tags>
      </metadata>
      <files>
        <file src="Scripts\*.sql" target="Scripts\" />
        <file src="THUD!.exe.config" target="." />
        <file src="THUD!.exe" target="." />
      </files>
    </package>
    ```
7.	Change the value within the <id> tag to match the name of your project. (Line 35)
8.	Change the value within the <description> tag to something meaningful to your project.  (Line 44)
9.	Change the value within the <title> element to something meaningful to your project.  (Line 51)
10.	Save the file.  It should require no other changes.

##### WHAT'S NEXT?
Once your updated solution is in source control, it will be ready to be built by TF Build and deployed by OD.  
  
Your Deployment Manager will need to know that you are using THUD! and the name of the project that contains it.
He will also need to know the specific command or commands that you want run.  (If you are updating multiple databases, 
OD will need to execute a separate command fore each.  Note that the scripts for all of your databases can be housed 
within a single project.)

The typical command that they would run looks like this:
`THUD! -ro latest -db Sample -env environment`
  
Where _Sample_ is the name of the database and _environment_ will be converted to an OctopusDeploy variable representing
the deployment environment.

