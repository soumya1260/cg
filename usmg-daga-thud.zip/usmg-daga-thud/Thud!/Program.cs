﻿using Cigna.DigitalApplications.Thud.Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

[assembly: InternalsVisibleTo("Thud!.Tests.Unit")]
#pragma warning disable S2228 // Writes to console are intentional and required for integration with Visual Studio

namespace Cigna.DigitalApplications.Thud
{
    // ReSharper disable once ClassNeverInstantiated.Global
    public static class Program
    {
        #region Public Methods

        /// <summary>
        ///     Parses out the command line arguments and returns an UpdateSettings object.
        /// </summary>
        /// <param name="args">argument list to be parsed</param>
        /// <returns>An UpdateSettings object with all the user input required to run the application.</returns>
        public static UpdateSettings ParseArguments(string[] args)
        {
            var settings = new UpdateSettings
            {
                Environment = null,
                UpdateDirection = UpdateDirections.Rollout,
                Wait = false,
                RolloutToVersion = null, // User supplied no value, so get latest.
                RollbackToVersion = null,
                WriteScript = false,
                SourceFolder = ConfigurationManager.AppSettings["defaultSourceFolder"],
                DatabaseName = ConfigurationManager.AppSettings["defaultDatabase"],
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                OutputFilePrefix = null,
                ShowStackTrace = false,
                ShowUsageMessageOnlyAndExit = false,
                GetVersions = false,
                GetDatabaseVersion = false
            };

            var argumentStatus = new ArgumentStatus();

            var argPosition = 0;

            while (argPosition < args.Length)
            {
                var argument = args[argPosition].ToUpperInvariant();
                if (argument[0] == '-')
                {
                    ParseOption(args, argument, ref argPosition, settings, ref argumentStatus);
                }
                else
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = Localizable.InvalidOptionFormatMessage;
                }

                if (!settings.ArgumentsParsedSuccessfully)
                {
                    break;
                }

                ++argPosition;
            }

            //
            // If we aren't writing scripts and the environment wasn't explicitly provided,
            // set the environment to the default.
            //
            if (!settings.WriteScript && string.IsNullOrEmpty(settings.Environment))
            {
                settings.Environment = ConfigurationManager.AppSettings["defaultEnvironment"];
            }
            
            if (settings.ArgumentsParsedSuccessfully)
            {
                //
                // Sanity checks that can only be performed after all the arguments have
                // been processed.
                //
                SanityCheckArguments(settings, argumentStatus);
            }

            return settings;
        }

        #endregion Public Methods

        #region Internal Methods

        /// <summary>
        /// Sanity checks the arguments.
        /// </summary>
        /// <param name="settings">The settings.</param>
        /// <param name="argumentStatus">The argument status.</param>
        internal static void SanityCheckArguments(
            UpdateSettings settings,
            ArgumentStatus argumentStatus)
        {
            SanityCheckGetVersions(settings, argumentStatus);
            if (argumentStatus.GetDatabaseVersionUsed)
            {
                if (argumentStatus.ScriptUsed)
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(
                        Localizable.Option0CannotBeUsedWithOption1ScriptsMessage,
                        OptionStrings.GetDatabaseVersion,
                        OptionStrings.WriteScripts);
                }
                else if (argumentStatus.RollbackUsed)
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(
                        Localizable.Option0CannotBeUsedWithOption1ScriptsMessage,
                        OptionStrings.GetDatabaseVersion,
                        OptionStrings.Rollback);
                }
                else if (argumentStatus.GetVersionsUsed)
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(
                        Localizable.Option0CannotBeUsedWithOption1ScriptsMessage,
                        OptionStrings.GetDatabaseVersion,
                        OptionStrings.GetVersions);
                }

                VerifyConnectionNameIsValid(settings);
            }
            else if (argumentStatus.ScriptUsed)
            {
                SanityCheckScriptUsedArguments(settings, argumentStatus);
            }
            else
            {
                if (argumentStatus.RolloutUsed && argumentStatus.RollbackUsed)
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage =
                        string.Format(Localizable.RolloutAndRollbackCantBeUsedHereMessage, OptionStrings.Rollout, OptionStrings.Rollback);
                }

                VerifyConnectionNameIsValid(settings);
            }
        }

        private static void SanityCheckGetVersions(UpdateSettings settings, ArgumentStatus argumentStatus)
        {
            if (argumentStatus.GetVersionsUsed)
            {
                if (argumentStatus.ScriptUsed)
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(
                        Localizable.Option0CannotBeUsedWithOption1ScriptsMessage,
                        OptionStrings.GetVersions,
                        OptionStrings.WriteScripts);
                }
                else if (argumentStatus.RollbackUsed)
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(
                        Localizable.Option0CannotBeUsedWithOption1ScriptsMessage,
                        OptionStrings.GetVersions,
                        OptionStrings.Rollback);
                }
                else if (argumentStatus.GetDatabaseVersionUsed)
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(
                        Localizable.Option0CannotBeUsedWithOption1ScriptsMessage,
                        OptionStrings.GetVersions,
                        OptionStrings.GetDatabaseVersion);
                }

                VerifyConnectionNameIsValid(settings);
            }
        }

        private static void SanityCheckScriptUsedArguments(UpdateSettings settings, ArgumentStatus argumentStatus)
        {
            if (!argumentStatus.EnvironmentUsed)
            {
                if (!(argumentStatus.RolloutUsed && argumentStatus.RollbackUsed))
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage =
                        string.Format(Localizable.RolloutAndRollbackAreRequiredMessage, OptionStrings.Rollout, OptionStrings.Rollback, Localizable.RolloutMustBeSuppliedForWriteScriptsMessage, OptionStrings.Environment);
                }
                else if (settings.RollbackToVersion == null)
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage =
                        string.Format(Localizable.RolloutMustBeSuppliedForWriteScriptsMessage, OptionStrings.Rollout, Localizable.RolloutMustBeSuppliedForWriteScriptsMessage);
                }
            }
            else
            {
                VerifyConnectionNameIsValid(settings);
            }
        }

        #endregion Internal Methods

        internal static readonly List<string> Environments = new List<string>();
        internal static readonly List<string> Databases = new List<string>();
        private static readonly Dictionary<string, List<string>> DatabaseEnvironments = new Dictionary<string, List<string>>();

        #region Private Methods

        private static int Main(string[] args)
        {
            int result = 0;

            if (!args.Any())
            {
                UsageMessage(new UpdateSettings());
                return 0;
            }

            if (!InitializeListsFromConfigurationManager())
            {
                return 400;
            }

            var settings = ParseArguments(args);
            if (!settings.ArgumentsParsedSuccessfully)
            {
                UsageMessage(settings);
            }
            else if (settings.ShowUsageMessageOnlyAndExit)
            {
                UsageMessage(settings);
            }
            else
            {
                var updater = new DatabaseUpdater(settings);
                int returnValue = updater.InitializeLists();
                if (returnValue != 0)
                {
                    CheckForWait(settings);
                    return returnValue;
                }

                if (settings.GetVersions)
                {
                    result = updater.GetVersions();
                }
                else if (settings.GetDatabaseVersion)
                {
                    result = updater.GetDatabaseVersion();
                }
                else
                {
                    result = updater.PerformUpdate();
                }
            }

            CheckForWait(settings);
            return result;
        }

        private static void CheckForWait(UpdateSettings settings)
        {
            if (settings.Wait)
            {
                Console.ReadKey();
            }
        }

        internal static bool InitializeListsFromConfigurationManager()
        {
            foreach (ConnectionStringSettings connectionStringSettings in ConfigurationManager.ConnectionStrings)
            {
                string name = connectionStringSettings.Name;
                if (name.Equals("LocalSqlServer", StringComparison.InvariantCultureIgnoreCase))
                {
                    continue;
                }

                try
                {
                    string databaseName = name.Substring(0, name.LastIndexOf('-')).ToUpperInvariant();
                    string environmentName = name.Substring(name.LastIndexOf('-') + 1).ToUpperInvariant();

                    if (!Environments.Contains(environmentName))
                    {
                        Environments.Add(environmentName);
                    }

                    if (!Databases.Contains(databaseName))
                    {
                        Databases.Add(databaseName);
                    }

                    if (!DatabaseEnvironments.ContainsKey(databaseName))
                    {
                        DatabaseEnvironments.Add(databaseName, new List<string>());
                    }

                    DatabaseEnvironments[databaseName].Add(environmentName);
                }
                catch (Exception)
                {
                    Console.WriteLine(Localizable.InvlalidConnectionStringNameMessage, name);
                    Console.WriteLine(Localizable.FixYourDatabaseConfigMessage);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        ///     Parses the -Environment command line argument.
        /// </summary>
        /// <param name="args">argument list</param>
        /// <param name="argPosition">current argument list position</param>
        /// <param name="settings">UpdateSettings object to be updated</param>
        /// <returns>the current argument list position.</returns>
        internal static int ParseEnvironmentOption(string[] args, int argPosition, UpdateSettings settings)
        {
            //
            // -Environment requires an argument, so make sure that an argument exists and that
            // it does not look like another option selector.
            //
            // This basically flags errors for argument lists that look like:
            //
            //     -Environment
            //     -Environment -Wait
            //
            // both of which would be in error.
            //
            if (argPosition + 1 >= args.Length || args[argPosition + 1][0] == '-')
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage = string.Format(Localizable.EnvironmentRequiresAValueMessage, OptionStrings.Environment);
            }
            else
            {
                string environment = args[++argPosition].ToUpperInvariant();
                if (Environments.Contains(environment))
                {
                    settings.Environment = environment;
                }
                else
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(Localizable.XxxIsNotAValidEnvironmentValueMessage, environment, string.Join(", ", Environments));
                }
            }
            return argPosition;
        }

        internal static void ParseDatabaseOption(
            string[] args,
            UpdateSettings settings,
            ref int argPosition,
            bool databaseUsed)
        {
            if (databaseUsed)
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage =
                    string.Format(Localizable.OptionCanOnlyBeSubmittedOnceMessage, OptionStrings.Database);
                return;
            }

            if (argPosition + 1 >= args.Length || args[argPosition + 1][0] == '-')
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage = string.Format(Localizable.ValueIsRequiredMessage, OptionStrings.Database);
            }
            else
            {
                string databaseName = args[++argPosition].ToUpperInvariant();
                if (Databases.Contains(databaseName))
                {
                    settings.DatabaseName = databaseName;
                }
                else
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(Localizable.InvalidDatabaseValueMessage, databaseName, string.Join(", ", Databases));
                }
            }
        }

        private static void ParseEnvironmentOption(
            string[] args,
            UpdateSettings settings,
            ref bool environmentUsed,
            ref int argPosition)
        {
            if (environmentUsed)
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage =
                    string.Format(Localizable.OptionCanOnlyBeSubmittedOnceMessage, OptionStrings.Environment);
            }
            else
            {
                environmentUsed = true;
                argPosition = ParseEnvironmentOption(args, argPosition, settings);
            }
        }

        private static void ParseGetVersionsOption(
            UpdateSettings settings,
            bool getVersionsUsed)
        {
            if (getVersionsUsed)
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage = string.Format(Localizable.OptionCanOnlyBeSubmittedOnceMessage, OptionStrings.GetVersions);
                return;
            }

            settings.GetVersions = true;
        }

        private static void ParseGetDatabaseVersionOption(
            UpdateSettings settings,
            bool getDatabaseVersionUsed)
        {
            if (getDatabaseVersionUsed)
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage = string.Format(Localizable.OptionCanOnlyBeSubmittedOnceMessage, OptionStrings.GetDatabaseVersion);
                return;
            }

            settings.GetDatabaseVersion = true;
        }

#pragma warning disable S1541 // Calculated complexity overstates actual complexity for this method.

        private static void ParseOption(
            string[] args,
            string argument,
            ref int argPosition,
            UpdateSettings settings,
            ref ArgumentStatus argumentStatus)
        {
            switch (argument)
            {
                case "-HELP":
                case "-USAGE":
                    settings.ShowUsageMessageOnlyAndExit = true;
                    break;

                case "-ENVIRONMENT":
                case "-ENV":
                    bool environmentUsed = argumentStatus.EnvironmentUsed;
                    ParseEnvironmentOption(args, settings, ref environmentUsed, ref argPosition);
                    argumentStatus.EnvironmentUsed = environmentUsed;
                    break;

                case "-ROLLOUT":
                case "-RO":
                    ParseRolloutOption(args, settings, ref argPosition, argumentStatus.RolloutUsed);
                    argumentStatus.RolloutUsed = true;
                    break;

                case "-ROLLBACK":
                case "-RB":
                    ParseRollbackOption(args, settings, ref argPosition, argumentStatus.RollbackUsed);
                    argumentStatus.RollbackUsed = true;
                    break;

                case "-WAIT":
                    ParseWaitOption(settings, argumentStatus.WaitUsed);
                    argumentStatus.WaitUsed = true;
                    break;

                // ReSharper disable once StringLiteralTypo
                case "-WRITESCRIPTS":
                case "-WS":
                    var scriptUsed = argumentStatus.ScriptUsed;
                    ParseWriteScriptsOption(args, settings, ref scriptUsed, ref argPosition, argumentStatus.DatabaseUsed);
                    argumentStatus.ScriptUsed = scriptUsed;
                    break;

                // ReSharper disable once StringLiteralTypo
                case "-SOURCEFOLDER":
                case "-SOURCE":
                case "-SF":
                    ParseSourceFolderOption(args, settings, ref argPosition, argumentStatus.SourceFolderUsed);
                    argumentStatus.SourceFolderUsed = true;
                    break;

                case "-DATABASE":
                case "-DB":
                    ParseDatabaseOption(args, settings, ref argPosition, argumentStatus.DatabaseUsed);
                    argumentStatus.DatabaseUsed = true;
                    break;

                // ReSharper disable once StringLiteralTypo
                case "-SHOWSTACKTRACE":
                case "-ST":
                    settings.ShowStackTrace = true;
                    break;

                // ReSharper disable once StringLiteralTypo
                case "-GETVERSIONS":
                case "-GV":
                    ParseGetVersionsOption(settings, argumentStatus.GetVersionsUsed);
                    argumentStatus.GetVersionsUsed = true;
                    break;

                // ReSharper disable once StringLiteralTypo
                case "-GETDATABASEVERSION":
                case "-GDV":
                    ParseGetDatabaseVersionOption(settings, argumentStatus.GetDatabaseVersionUsed);
                    argumentStatus.GetDatabaseVersionUsed = true;
                    break;

                default:
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(Localizable.InvalidOptionMessage, args[argPosition]);
                    break;
            }
        }

#pragma warning restore S1541

        private static void ParseRollbackOption(
            string[] args,
            UpdateSettings settings,
            ref int argPosition,
            bool rollbackUsed)
        {
            if (rollbackUsed)
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage = string.Format(Localizable.OptionCanOnlyBeSubmittedOnceMessage, OptionStrings.Rollback);
            }
            else
            {
                settings.UpdateDirection = UpdateDirections.Rollback;

                //
                // For -Rollback, the version parameter is required.
                //
                if (argPosition + 1 < args.Length && args[argPosition + 1][0] != '-')
                {
                    if (int.TryParse(args[++argPosition], out var version))
                    {
                        settings.RollbackToVersion = version;
                    }
                    else
                    {
                        settings.ArgumentsParsedSuccessfully = false;
                        settings.ErrorMessage = string.Format(Localizable.InvalidVersionNumberMessage, args[argPosition]);
                    }
                }
                else
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(Localizable.VersionNumberRequiredMessage, OptionStrings.Rollback);
                }
            }
        }

        private static void ParseRolloutOption(
            string[] args,
            UpdateSettings settings,
            ref int argPosition,
            bool rolloutUsed)
        {
            if (rolloutUsed)
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage =
                    string.Format(Localizable.OptionCanOnlyBeSubmittedOnceMessage, OptionStrings.Rollout);
            }
            else
            {
                settings.UpdateDirection = UpdateDirections.Rollout;

                //
                // For -Rollout, the version parameter is optional.
                //
                if (argPosition + 1 < args.Length && args[argPosition + 1][0] != '-')
                {
                    var versionString = args[++argPosition];
                    if (string.Equals(
                        versionString,
                        OptionStrings.LatestArgument,
                        StringComparison.InvariantCultureIgnoreCase))
                    {
                        settings.RolloutToVersion = null;
                    }
                    else
                    {
                        if (int.TryParse(versionString, out var version))
                        {
                            settings.RolloutToVersion = version;
                        }
                        else
                        {
                            settings.ArgumentsParsedSuccessfully = false;
                            settings.ErrorMessage =
                                string.Format(Localizable.InvalidVersionNumberMessage, args[argPosition]);
                        }
                    }
                }
                else
                {
                    settings.RolloutToVersion = null;
                }
            }
        }

        private static void ParseSourceFolderOption(
            string[] args,
            UpdateSettings settings,
            ref int argPosition,
            bool sourceFolderUsed)
        {
            if (sourceFolderUsed)
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage = string.Format(Localizable.OptionCanOnlyBeSubmittedOnceMessage, OptionStrings.SourceFolder);
            }
            else
            {
                if (argPosition + 1 < args.Length && args[argPosition + 1][0] != '-')
                {
                    settings.SourceFolder = args[++argPosition];
                }
                else
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(Localizable.FolderNameRequired, OptionStrings.SourceFolder);
                }
            }
        }

        private static void ParseWaitOption(UpdateSettings settings, bool waitUsed)
        {
            if (waitUsed)
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage = string.Format(Localizable.OptionCanOnlyBeSubmittedOnceMessage, OptionStrings.Wait);
            }
            else
            {
                settings.Wait = true;
            }
        }

        private static void ParseWriteScriptsOption(
            string[] args,
            UpdateSettings settings,
            ref bool scriptUsed,
            ref int argPosition,
            bool databaseUsed)
        {
            if (scriptUsed)
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage = string.Format(Localizable.OptionCanOnlyBeSubmittedOnceMessage, Localizable.RolloutMustBeSuppliedForWriteScriptsMessage);
            }
            else
            {
                settings.WriteScript = true;

                if (argPosition + 1 < args.Length && args[argPosition + 1][0] != '-')
                {
                    settings.OutputFilePrefix = args[++argPosition];
                    scriptUsed = true;

                    //
                    // If -Database hasn't been submitted yet, grab the default from the configuration file.
                    //
                    if (!databaseUsed)
                    {
                        settings.DatabaseName =
                            ConfigurationManager.AppSettings["defaultDatabase"];
                    }
                }
                else
                {
                    settings.ArgumentsParsedSuccessfully = false;
                    settings.ErrorMessage = string.Format(Localizable.FileNameStubRequiredMessage, Localizable.RolloutMustBeSuppliedForWriteScriptsMessage);
                }
            }
        }

        private static void UsageMessage(UpdateSettings settings)
        {
            if (settings.ErrorMessage != null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(Localizable.SimpleErrorMessage, settings.ErrorMessage);
                Console.WriteLine();
            }

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(Localizable.UsageMessageTitle);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(@"    {0}", Localizable.ApplicationName);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(Localizable.OptionsPlaceholder);

            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(Localizable.OptionsTitle);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(Localizable.OptionX, OptionStrings.Environment);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(Localizable.EnvironmentPlaceholder);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(Localizable.OptionX, OptionStrings.Rollout);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write(@" [{0} |", Localizable.VersionPlaceholder);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(@" {0}", OptionStrings.LatestArgument);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(@" ]");

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(Localizable.OptionX, OptionStrings.Rollback);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(Localizable.VersionPlaceholder);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(Localizable.OptionX, OptionStrings.WriteScripts);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(Localizable.FileNameStubPlaceholder);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(Localizable.OptionX, OptionStrings.SourceFolder);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(Localizable.FolderPlaceholder);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(Localizable.OptionX, OptionStrings.Database);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(Localizable.DatabasePlaceholder);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(Localizable.OptionX, OptionStrings.GetVersions);
            Console.ForegroundColor = ConsoleColor.Gray;

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(Localizable.OptionX, OptionStrings.GetDatabaseVersion);
            Console.ForegroundColor = ConsoleColor.Gray;

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(Localizable.OptionX, OptionStrings.Wait);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(Localizable.OptionX, OptionStrings.ShowStackTrace);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(Localizable.OptionX, OptionStrings.Help);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write(@" | ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(OptionStrings.Usage);

            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(Localizable.ExamplesTitle);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine($@"    {Localizable.ApplicationName} {OptionStrings.Environment} {Localizable.DevEnvironmentExample}");
            Console.WriteLine($@"    {Localizable.ApplicationName} {OptionStrings.Environment} {Localizable.DevEnvironmentExample} {OptionStrings.Rollout}");
            Console.WriteLine($@"    {Localizable.ApplicationName} {OptionStrings.Environment} {Localizable.DevEnvironmentExample} {OptionStrings.Rollout} {OptionStrings.LatestArgument}");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(Localizable.AllOfTheAboveDoTheSameThingMessage);

            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine($@"    {Localizable.ApplicationName} {OptionStrings.Environment} {Localizable.UatEnvironmentExample} {OptionStrings.Rollback} 372");
            Console.WriteLine($@"    {Localizable.ApplicationName} {OptionStrings.Environment} {Localizable.UatEnvironmentExample} {OptionStrings.Rollback} 372 {OptionStrings.Wait}");

            Console.ResetColor();
            Console.WriteLine();
            Console.WriteLine();
        }

        private static void VerifyConnectionNameIsValid(UpdateSettings settings)
        {
            //
            // Make sure the connection is defined in the configuration file.
            //
            var connectionStringName = settings.ConnectionStringName;
            if (ConfigurationManager.ConnectionStrings[connectionStringName] == null)
            {
                settings.ArgumentsParsedSuccessfully = false;
                settings.ErrorMessage =
                    $@"""{settings.Environment}"" is not a valid environment for database {settings.DatabaseName}.  ({connectionStringName} could not be found in the THUD! configuration file's <connectionStrings> section.)
Valid database/environment combinations are:
{GetValidConnections()}";
            }
        }

        private static string GetValidConnections()
        {
            var list = new StringBuilder();
            foreach (var databaseEnvironment in DatabaseEnvironments)
            {
                list.Append($"{databaseEnvironment.Key}: ");
                list.AppendLine(string.Join(", ", databaseEnvironment.Value));
            }

            return list.ToString();
        }

        #endregion Private Methods
    }
}