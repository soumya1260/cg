﻿using System.ComponentModel;

namespace Cigna.DigitalApplications.Thud
{
    public class UpdateSettings
    {
        public UpdateDirections UpdateDirection { get; set; }
        public string Environment { get; set; }
        public bool Wait { get; set; }
        public long? RolloutToVersion { get; set; }
        public long? RollbackToVersion { get; set; }
        public bool WriteScript { get; set; }
        public string OutputFilePrefix { get; set; }
        public string SourceFolder { get; set; }
        public string DatabaseName { get; set; }
        public bool ArgumentsParsedSuccessfully { get; set; }
        [Localizable(true)] public string ErrorMessage { get; set; }
        public bool ShowStackTrace { get; set; }
        public bool ShowUsageMessageOnlyAndExit { get; set; }
        public bool GetVersions { get; set; }
        public bool GetDatabaseVersion { get; set; }

        public string ConnectionStringName => $"{DatabaseName}-{Environment}";
    }
}