﻿namespace Cigna.DigitalApplications.Thud
{
    public enum UpdateDirections
    {
        Rollout,
        Rollback
    };
}