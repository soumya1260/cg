﻿# ![THUD! Icon](./thud.bmp "THUD!") THUD! NuGet package

## UpdateDatabase is now THUD!
It's been a very long time in coming, but we have now fully-updated
the identity of the update database utility to "THUD!".

Going forward, the executable name is "THUD!.exe" and the configuration file 
is "THUD!.exe.config".

## Why "THUD!"?
Well, we wanted something short and easy to remember.  The
old name, UpdatedDatabase, had the initials "UD", so we just kind of 
went from there.  Thud! doesn't stand for anything -- it's just a 
comic book onomatopoeia word.  It is the first of many applications
to be developed by Cigna GBS Digital Applications that will employ
monosyllabic onomatopoeia names.

## Steps for integration:

 1. Create a solution folder named "Build and Deployment" if it doesn't already exist.

 2. Add a new class library project to the "Build and Deployment" folder.  Recommended name
    pattern is "_ShortSolutionName_-THUD!"

 3. Rename Class1 and Class1.cs to DoNotUse and DoNotUse.cs, respectively.

 4. Use NuGet to import OctoPack into the project.

 5. Use Nuget to import THUD! (this package) into the project.

 6. Create a folder named "Scripts" in your project.  If you have existing numbered scripts,
    copy or move them into this folder.

 7. Rename EXAMPLE.nuspec to _ProjectName_.nuspec.  It much match the .csproj file name.

 8. Assuming you've followed these steps so far, the only edits needed in the .nuspec file are
    to replace all the EXAMPLE references with something reasonable for your solution.

 9. Finally, set up your THUD!.config.  You can either rename and edit the EXAMPLE file
    or erase that and copy your existing THUD!.exe.config.  If you copy an existing file, be sure to change the defaultSourceFolder to "Scripts".
