﻿namespace Cigna.DigitalApplications.Thud
{
    public class ArgumentStatus
    {
        #region Public Properties

        public bool DatabaseUsed { get; set; }
        public bool EnvironmentUsed { get; set; }
        public bool GetVersionsUsed { get; set; }
        public bool RollbackUsed { get; set; }
        public bool RolloutUsed { get; set; }
        public bool ScriptUsed { get; set; }
        public bool SourceFolderUsed { get; set; }
        public bool WaitUsed { get; set; }
        public bool GetDatabaseVersionUsed { get; set; }

        #endregion Public Properties
    }
}