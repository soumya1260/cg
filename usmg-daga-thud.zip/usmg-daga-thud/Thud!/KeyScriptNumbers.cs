﻿namespace Cigna.DigitalApplications.Thud
{
    public class KeyScriptNumbers
    {
        public long FirstUpdate { get; set; }
        public long? OriginalDatabaseVersion { get; set; }
        public long MostRecentVersion { get; set; }
    }
}