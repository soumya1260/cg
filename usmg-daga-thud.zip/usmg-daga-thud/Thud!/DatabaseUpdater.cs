﻿using Cigna.DigitalApplications.Thud.Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;

[assembly: InternalsVisibleTo("THUD!.Tests.Integration")]
#pragma warning disable S2228 // Writes to console are intentional and are required for integration with Visual Studio

namespace Cigna.DigitalApplications.Thud
{
    public class DatabaseUpdater
    {
        #region Private Fields

        /// <summary>
        ///     Regular expression for replacing "GO" commands.
        ///     This expression looks for a newline followed immediately by the word "GO"
        ///     followed by optional whitespace and another newline.
        /// </summary>
        private static readonly Regex FindGoCommandsRegex =
            new Regex(@"\r{0,1}\n^GO\s*$", RegexOptions.Compiled | RegexOptions.Multiline | RegexOptions.IgnoreCase);

        /// <summary>
        ///     Regular expression for extracting script numbers from a formatted SQL filename.
        ///     Expected format is prefix-zero_filled_sequence_number-rollout/rollback.sql
        ///     E.G.: HSCProvider-00495-rollout.sql or HSCProvider-00495-ROLLBACK.SQL
        /// </summary>
        private static readonly Regex ScriptNumberRegex =
            new Regex(@"\w+-(?<sequence>\d+)-roll(?:out|back)\.sql$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

        private readonly string _connectionStringName;
        private readonly string _database;
        private readonly string _environment;
        private readonly string _outputFilePrefix;
        private readonly bool _showStackTrace;
        private readonly string _sqlFolder;
        private readonly UpdateDirections _updateDirection;
        private readonly bool _writeScript;
        private long? _rollbackToVersion;
        private long? _rolloutToVersion;
        private SortedList<long, string> _rolloutScripts;
        private SortedList<long, string> _rollbackScripts;

        #endregion Private Fields

        #region Public Constructors

        /// <summary>
        ///     DatabaseUpdater constructor.  Builds out the object using the supplied settings.
        /// </summary>
        /// <param name="settings"></param>
        public DatabaseUpdater(UpdateSettings settings)
        {
            _updateDirection = settings.UpdateDirection;
            _environment = settings.Environment;
            _rolloutToVersion = settings.RolloutToVersion;
            _rollbackToVersion = settings.RollbackToVersion;
            _writeScript = settings.WriteScript;
            _outputFilePrefix = settings.OutputFilePrefix;
            _sqlFolder = settings.SourceFolder;
            _showStackTrace = settings.ShowStackTrace;
            _database = settings.DatabaseName;
            _connectionStringName = settings.ConnectionStringName;
        }

        #endregion Public Constructors

        #region Public Methods

        public int InitializeLists()
        {
            List<string> rolloutList = new List<string>();
            List<string> rollbackList = new List<string>();

            GetFiles(rolloutList, rollbackList);
            if (!rolloutList.Any())
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(Localizable.NoMatchingScriptsErrorMessage, _database, _sqlFolder);
                Console.ResetColor();
                return 100;
            }

            if (!ValidateScriptLists(rolloutList, rollbackList, out List<string> mismatchedScripts))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(Localizable.UnmatchedScriptsError, _sqlFolder);
                foreach (var fileName in mismatchedScripts)
                {
                    Console.WriteLine(Path.GetFileName(fileName));
                }
                Console.ResetColor();
                return 100;
            }

            _rolloutScripts = MakeSortedList(rolloutList);
            _rollbackScripts = MakeSortedList(rollbackList);

            return 0;
        }

        /// <summary>
        ///     Applies a single update to either the selected database or script file.
        /// </summary>
        /// <param name="updateNumber">The sequence/version number assigned to the update.</param>
        /// <param name="filename">The name of the SQL file containing the update increment.</param>
        /// <param name="textWriter">Stream to write script increment to if writing scripts.</param>
        /// <param name="isRollback">This is a rollback script.</param>
        /// <param name="isReversal">This is a reversal from a SQL exception.</param>
        /// <returns>true if the update succeeds; false otherwise.</returns>
        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "No user input is included in the SQL command text.")]
#pragma warning disable S3649
        public bool ApplyUpdate(long updateNumber, string filename, TextWriter textWriter, bool isRollback = false, bool isReversal = false)
        {
            bool updateSucceeded = true;

            //
            // Read in the update increment file.
            //
            StringBuilder scriptTextStringBuilder = new StringBuilder();
            using (StreamReader streamReader = new StreamReader(filename))
            {
                scriptTextStringBuilder.Append(streamReader.ReadToEnd());
            }

            //
            // If we are updating the database, update the version information.
            //
            if (!_writeScript)
            {
                scriptTextStringBuilder.AppendLine();
                scriptTextStringBuilder.AppendLine("GO");
                scriptTextStringBuilder.AppendFormat(
                    SqlStrings.ThudVersion,
                    isRollback ? PreviousScript(updateNumber) : updateNumber);
            }

            string scriptText = scriptTextStringBuilder.ToString();

            //
            // Attempt to update the database.
            //
            if (_writeScript)
            {
                WriteScriptIncrement(filename, textWriter, scriptText);
            }
            else
            {
                using (
                    SqlConnection connection =
                        new SqlConnection(
                            ConfigurationManager.ConnectionStrings[_connectionStringName].ConnectionString)
                )
                {
                    try
                    {
                        ApplyIncrementToDatabase(connection, scriptText);
                    }
                    catch (Exception exception)
                    {
                        updateSucceeded = ReverseChangesAndNotifyUserOfError(
                            updateNumber,
                            filename,
                            textWriter,
                            isRollback,
                            isReversal,
                            exception);
                    }
                }
            }

            return updateSucceeded;
        }

        private bool ReverseChangesAndNotifyUserOfError(long updateNumber, string filename, TextWriter textWriter,
            bool isRollback, bool isReversal, Exception exception)
        {
            if (isReversal)
            {
                return true;  // Return value is normally ignored in this case.
            }

            //
            // Reverse the update increment on failure.  This necessary if there was
            // more than one "GO" batch in the file.
            //
            string reversalFileName = Regex.Replace(
                filename,
                isRollback ? "-rollback" : "-rollout",
                isRollback ? "-rollout" : "-rollback");

            ApplyUpdate(updateNumber, reversalFileName, textWriter, !isRollback, true);

            //
            // Notify the console.
            //
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(Localizable.DatabaseUpdater_ApplyUpdate_FailedToApplyUpdate, filename);
            Console.WriteLine(exception.Message);
            if (_showStackTrace)
            {
                Console.WriteLine(exception.StackTrace);
            }

            Console.ResetColor();
            return false;
        }

#pragma warning restore S3649

        /// <summary>
        ///     Gets the current database version if it is available.
        /// </summary>
        /// <returns>null if the database version table does not exist; the current version otherwise.</returns>
        /// <remarks>
        ///     Error handling is intentionally not in place.  Since this is a developer utility, we kind of want
        ///     it to blow chunks with a stack trace if there's a failure.
        /// </remarks>
        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "No user input is included in the SQL command text.")]
#pragma warning disable S3649
        public long? CurrentDatabaseVersion()
        {
            long version = 0;
            bool versionTableExists = false;

            string connectionString = ConfigurationManager.ConnectionStrings[_connectionStringName].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string commandString = SqlStrings.DatabaseVersion;
                using (SqlCommand command = new SqlCommand(commandString, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        //
                        // On the off-chance that the table has been created but no rows exist...
                        //
                        if (!reader.HasRows)
                        {
                            version = 0;
                        }
                        else if (reader.Read()) // We only care about the first row.
                        {
                            versionTableExists = (int)reader.GetValue(0) != 0;
                            version = versionTableExists ? (long)reader.GetValue(1) : 0;
                        }
                    }
                }
            }

            if (!versionTableExists)
            {
                return null;
            }

            return version;
        }

#pragma warning restore S3649

        /// <summary>
        ///     Returns two lists of rollout/rollback files conforming to the expected naming convention.
        /// </summary>
        /// <param name="rolloutList">List placeholder to contain the rollout file names</param>
        /// <param name="rollbackList">List placeholder to contain the rollback file names</param>
        /// <returns>true if successful; false otherwise.</returns>
        public bool GetFiles(List<string> rolloutList, List<string> rollbackList)
        {
            bool successful = true;

            try
            {
                rolloutList.AddRange(Directory.GetFiles(_sqlFolder, _database + @"-*-rollout.sql").ToList());
                rollbackList.AddRange(Directory.GetFiles(_sqlFolder, _database + @"-*-rollback.sql").ToList());
            }
            catch (IOException ex)
            {
                Console.WriteLine(Localizable.DatabaseUpdater_GetFiles_IOExceptionEncounteredWhileReadingFromFolder, _sqlFolder);
                Console.WriteLine(ex.Message);
                if (_showStackTrace)
                {
                    Console.WriteLine(ex.StackTrace);
                }

                successful = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(Localizable.DatabaseUpdater_GetFiles_ExceptionEncounteredWhileReadingFromFolder, _sqlFolder);
                Console.WriteLine(ex.Message);
                if (_showStackTrace)
                {
                    Console.WriteLine(ex.StackTrace);
                }

                successful = false;
            }

            return successful;
        }

        /// <summary>
        /// Returns a string indicating which scripts will be applied to a given database.  Used in composing the DevOps email to the DBAs for script review.
        /// </summary>
        /// <returns></returns>
        public int GetVersions()
        {
            string version = GetVersionString();
            if (string.IsNullOrEmpty(version))
            {
                return 0;
            }

            Console.WriteLine(GetVersionString());
            return 0;
        }

        /// <summary>
        /// Displays the database version on the console.
        /// </summary>
        /// <returns>Success as zero; any other value as a failure.</returns>
        public int GetDatabaseVersion()
        {
            long? version = CurrentDatabaseVersion();
            Console.WriteLine(version ?? 0);
            return 0;
        }

        /// <summary>
        ///     Performs an update as dictated by the Database Updater's settings.
        /// </summary>
        public int PerformUpdate()
        {
            //
            // If we are writing scripts, perform both rollout and roll-back.
            //
            if (_writeScript)
            {
                //
                // Make sure that we actually have scripts to write.
                //
                if (_rolloutToVersion <= _rollbackToVersion)
                {
                    return 100;
                }

                Rollout();
                Rollback();
                return 100;
            }

            //
            // Otherwise, pick the correct action based on the update direction.
            //
            return _updateDirection == UpdateDirections.Rollout ? Rollout() : Rollback();
        }

        /// <summary>
        ///     Performs a rollback, either directly to a specified database connection
        ///     or to a SQL script file.
        /// </summary>
        public int Rollback()
        {
            TextWriter sqlTextWriter = null;
            long? originalDatabaseVersion;

            try
            {
                //
                // Initial sanity check
                //
                if (!CanRollBack())
                {
                    return 0;
                }

                //
                // Get the most recent version number from the rollout list.
                //
                originalDatabaseVersion = _rollbackScripts.Last().Key;
                long mostRecentVersion = (long)originalDatabaseVersion;
                CheckRolloutToVersionForRollback(mostRecentVersion);

                long oldestVersion = _rollbackScripts.First().Key;

                //
                // Sanity checks.
                //
                bool requestIsSane = SanityCheckRollback(oldestVersion, mostRecentVersion, originalDatabaseVersion);
                if (!requestIsSane)
                {
                    return 0;
                }

                //
                // Get things set up.  This really only affects writing scripts.
                //
                sqlTextWriter = SetUpRollback();

                //
                // Apply the updates!
                //
                long lastSuccessfulUpdate = 0;
                foreach (
                    KeyValuePair<long, string> item in
                        _rollbackScripts.Where(
                            filename => filename.Key > _rollbackToVersion && filename.Key <= _rolloutToVersion)
                            .Reverse())
                {
                    if (!ApplyUpdate(item.Key, item.Value, sqlTextWriter, true))
                    {
                        return 100;
                    }
                    lastSuccessfulUpdate = item.Key;
                }

                //
                // Special case when rolling back to version zero.  Remove the DatabaseVersionInformation table.
                //
                CheckForRollbackToZero(lastSuccessfulUpdate, sqlTextWriter);

                if (_writeScript)
                {
                    WriteSqlClosing(sqlTextWriter, lastSuccessfulUpdate == 1
                        ? null
                        : (long?)PreviousScript(lastSuccessfulUpdate));
                }
            }
            finally
            {
                if (sqlTextWriter != null)
                {
                    sqlTextWriter.Flush();
                    sqlTextWriter.Close();
                }
            }

            DisplayRollbackRecap(originalDatabaseVersion);
            return 0;
        }

        private void CheckRolloutToVersionForRollback(long mostRecentVersion)
        {
            if (_rolloutToVersion == null)
            {
                _rolloutToVersion = mostRecentVersion;
            }
        }

        private void CheckForRollbackToZero(long lastSuccessfulUpdate, TextWriter sqlTextWriter)
        {
            if (lastSuccessfulUpdate == 1 && _rollbackToVersion == 0)
            {
                RollbackToVersionZero(sqlTextWriter);
            }
        }

        /// <summary>
        ///     Performs a rollout, either directly to a specified database connection
        ///     or to a SQL script file.
        /// </summary>
        public int Rollout()
        {
            TextWriter sqlTextWriter = null;
            KeyScriptNumbers keyScriptNumbers;

            try
            {
                keyScriptNumbers = DetermineKeyScriptNumbers();

                if (_rolloutToVersion == null)
                {
                    _rolloutToVersion = keyScriptNumbers.MostRecentVersion;
                }

                if (!UpdateIsNeeded(keyScriptNumbers))
                {
                    return 0;
                }
                SanityCheckRolloutToBoundary(keyScriptNumbers.MostRecentVersion);

                //
                // Get everything set up (for both direct to database and writing scripts)
                //
                sqlTextWriter = SetUpRollout(keyScriptNumbers);

                //
                // Apply the updates!
                //
                long lastAppliedUpdate = 0;
                foreach (
                    KeyValuePair<long, string> item in
                        _rolloutScripts.Where(
                            filename => filename.Key >= keyScriptNumbers.FirstUpdate && filename.Key <= _rolloutToVersion))
                {
                    bool updateSuccessful = ApplyUpdate(item.Key, item.Value, sqlTextWriter);
                    if (updateSuccessful)
                    {
                        lastAppliedUpdate = item.Key;
                    }
                    else
                    {
                        return 100;
                    }
                }

                if (_writeScript)
                {
                    WriteSqlClosing(sqlTextWriter, lastAppliedUpdate);
                }
            }
            finally
            {
                if (sqlTextWriter != null)
                {
                    sqlTextWriter.Flush();
                    sqlTextWriter.Close();
                }
            }

            DisplayRolloutRecap(keyScriptNumbers.OriginalDatabaseVersion);
            return 0;
        }

        private KeyScriptNumbers DetermineKeyScriptNumbers()
        {
            long firstUpdate;
            long? originalDatabaseVersion = null;
            long mostRecentVersion = _rolloutScripts.Last().Key;

            if (_writeScript)
            {
                //
                // If an environment is supplied, try to get the database version from the database.
                //
                if (_environment != null)
                {
                    _rollbackToVersion = originalDatabaseVersion = CurrentDatabaseVersion() ?? 0;
                }

                firstUpdate = _rollbackToVersion == null || _rollbackToVersion == 0
                    ? 0
                    : NextScript((long)_rollbackToVersion);

                if (originalDatabaseVersion == null)
                {
                    originalDatabaseVersion = firstUpdate > 0 ? PreviousScript(firstUpdate) : 0;
                }
            }
            else
            {
                originalDatabaseVersion = CurrentDatabaseVersion() ?? 0;
                firstUpdate = NextScript((long)originalDatabaseVersion);
            }

            return new KeyScriptNumbers
            {
                FirstUpdate = firstUpdate,
                OriginalDatabaseVersion = originalDatabaseVersion,
                MostRecentVersion = mostRecentVersion
            };
        }

        /// <summary>
        ///     Given two lists of file names in the expected format, this script makes sure that
        ///     the scripts line up -- that there is a 1:1 match between the sequence numbers in
        ///     each list.
        ///     It is presumed that the lists have already been filtered by prefix.
        /// </summary>
        /// <param name="rolloutScripts">A list of rollout script file names</param>
        /// <param name="rollbackScripts">A list of rollback script file names</param>
        /// <param name="mismatchedScripts">A list of any file names that don't have a corresponding pair in the other list</param>
        /// <returns>true if the lists line up; false otherwise.</returns>
        public bool ValidateScriptLists(
            List<string> rolloutScripts,
            List<string> rollbackScripts,
            out List<string> mismatchedScripts)
        {
            mismatchedScripts = new List<string>();

            //
            // Bail out if the lists are not the same size.
            //
            if (rolloutScripts.Count != rollbackScripts.Count)
            {
                mismatchedScripts = FindMismatchedScripts(rolloutScripts, rollbackScripts);
                return false;
            }

            //
            // Extract the sequence values from each list in preparation for comparing
            // them to make sure they line up.
            //
            List<string> rolloutSequenceList =
                rolloutScripts
                    .Select(filename => ScriptNumberRegex.Match(filename))
                    .Where(match => match.Success)
                    .Select(match => match.Groups["sequence"].Value)
                .ToList();

            List<string> rollbackSequenceList =
                rollbackScripts
                    .Select(filename => ScriptNumberRegex.Match(filename))
                    .Where(match => match.Success)
                    .Select(match => match.Groups["sequence"].Value)
                .ToList();

            //
            // Sanity checks to make sure that we still have equally-sized lists after
            // filtering the file names through the regular expression.
            //
            if (rolloutSequenceList.Count == 0 || rollbackSequenceList.Count == 0)
            {
                return false;
            }

            if (rolloutSequenceList.Count != rollbackSequenceList.Count)
            {
                mismatchedScripts = FindMismatchedScripts(rolloutScripts, rollbackScripts);
                return false;
            }

            //
            // Compare the lists and return.
            //
            bool result = rolloutSequenceList.All(sequenceNumber => rollbackSequenceList.Contains(sequenceNumber));
            if (!result)
            {
                mismatchedScripts = FindMismatchedScripts(rolloutScripts, rollbackScripts);
            }

            return result;
        }

        private List<string> FindMismatchedScripts(List<string> rolloutScripts, List<string> rollbackScripts)
        {
            var mismatched = rolloutScripts
                .Where(name => !rollbackScripts
                    .Contains(
                        name.Replace("-rollout.sql", "-rollback.sql", StringComparison.OrdinalIgnoreCase),
                        StringComparer.OrdinalIgnoreCase))
                .ToList();

            mismatched.AddRange(rollbackScripts
                .Where(name => !rolloutScripts
                    .Contains(
                        name.Replace("-rollback.sql", "-rollout.sql", StringComparison.OrdinalIgnoreCase),
                        StringComparer.OrdinalIgnoreCase)));

            return mismatched;
        }

        #endregion Public Methods

        #region Internal Methods

        /// <summary>
        /// Gets the version string.
        /// </summary>
        /// <returns></returns>
        internal string GetVersionString()
        {
            string connectionString = ConfigurationManager.ConnectionStrings[_connectionStringName].ConnectionString;
            if (!SetRolloutToVersion())
            {
                return string.Empty;
            }

            long firstRolloutScript = FirstRolloutScript();

            SqlConnectionStringBuilder connectionStringBuilder = new SqlConnectionStringBuilder(connectionString);
            string serverAndDatabase = $"{connectionStringBuilder.DataSource}: {connectionStringBuilder.InitialCatalog}";

            return firstRolloutScript <= _rolloutToVersion && -1 != firstRolloutScript
                ? $"{serverAndDatabase} (apply scripts {firstRolloutScript} through {_rolloutToVersion})"
                : $"{serverAndDatabase} (No database changes - database version is up-to-date)";
        }

        #endregion Internal Methods

        #region Private Methods

        /// <summary>
        /// Applies the database increment.
        /// </summary>
        /// <param name="connection">The connection.</param>
        /// <param name="scriptText">The script text.</param>
        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "No user input is included in the SQL command text.")]
#pragma warning disable S3649
        private static void ApplyIncrementToDatabase(SqlConnection connection, string scriptText)
        {
            connection.Open();
            using (TransactionScope transactionScope = new TransactionScope(TransactionScopeOption.Required, new TimeSpan(1, 0, 0)))
            {
                //
                // Break up the script into batches based on any GO commands found in the script.
                //
                foreach (
                    string batch in
                    FindGoCommandsRegex.Split(scriptText)
                        .Where(batch => !string.IsNullOrWhiteSpace(batch)))
                {
                    using (SqlCommand command = new SqlCommand(batch, connection))
                    {
                        const int defaultCommandTimeout = 2 * 60 * 60; // Two hours.
                        if (!int.TryParse(ConfigurationManager.AppSettings["commandTimeoutInSeconds"], out int commandTimeout))
                        {
                            commandTimeout = defaultCommandTimeout;
                        }

                        command.CommandTimeout = commandTimeout; // One hour.
                        command.ExecuteNonQuery();
                    }
                }

                transactionScope.Complete();
            }
        }

#pragma warning restore S3649

        /// <summary>
        /// Creates a sorted dictionary from the supplied file list.
        /// </summary>
        /// <param name="fileList">The file list.</param>
        /// <returns>Sorted version of fileList</returns>
        private static SortedList<long, string> MakeSortedList(List<string> fileList)
        {
            SortedList<long, string> sortedFileList = new SortedList<long, string>();
            foreach (string filename in fileList)
            {
                long.TryParse(ScriptNumberRegex.Match(filename).Groups["sequence"].Value, out long key);
                sortedFileList.Add(key, filename);
            }

            return sortedFileList;
        }

        /// <summary>
        /// Writes the script increment.
        /// </summary>
        /// <param name="filename">The filename.</param>
        /// <param name="textWriter">The text writer.</param>
        /// <param name="scriptText">The script text.</param>
        private static void WriteScriptIncrement(string filename, TextWriter textWriter, string scriptText)
        {
            Debug.Assert(textWriter != null);
            //
            // Write increment to script file.
            //
            textWriter.WriteLine(SqlStrings.BannerFormat, Path.GetFileName(filename));
            textWriter.WriteLine(scriptText);
            textWriter.WriteLine("GO");
            textWriter.WriteLine();
            textWriter.Flush();
        }

        /// <summary>
        /// Writes the SQL closing.
        /// </summary>
        /// <param name="sqlTextWriter">The SQL text writer.</param>
        /// <param name="version">The version.</param>
        private static void WriteSqlClosing(TextWriter sqlTextWriter, long? version)
        {
            Debug.Assert(sqlTextWriter != null);

            if (version != null)
            {
                sqlTextWriter.WriteLine(SqlStrings.ThudVersion, version);
                sqlTextWriter.WriteLine("GO");
                sqlTextWriter.WriteLine();
            }
            sqlTextWriter.WriteLine("COMMIT TRANSACTION");
            sqlTextWriter.WriteLine("GO");
        }

        /// <summary>
        ///     Creates a copy of the DatabaseVersionInformation table in the
        ///     default catalog (database) of the submitted connection string.
        /// </summary>
        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "No user input is included in the SQL command text.")]
#pragma warning disable S3649
        private void CreateDatabaseVersionTable()
        {
            string connectionString = ConfigurationManager.ConnectionStrings[_connectionStringName].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string commandString = SqlStrings.CreateDatabaseVersionTable;
                using (SqlCommand command = new SqlCommand(commandString, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

#pragma warning restore S3649

        /// <summary>
        /// Displays the rollback recap.
        /// </summary>
        /// <param name="originalDatabaseVersion">The original database version.</param>
        private void DisplayRollbackRecap(long? originalDatabaseVersion)
        {
            Console.WriteLine();
            if (_writeScript)
            {
                Console.WriteLine(
                    Localizable.DatabaseUpdater_DisplayRollbackRecap_RollbackScriptCreatedToDowngrade,
                    _rolloutToVersion,
                    _rollbackToVersion ?? 0);
            }
            else
            {
                Console.WriteLine(Localizable.DatabaseUpdater_DisplayRollbackRecap_RollbackCompleted);
                long? finalDatabaseVersion = CurrentDatabaseVersion();
                Console.WriteLine(Localizable.DatabaseUpdater_DisplayRollbackRecap_DatabaseVersionDowngraded, originalDatabaseVersion,
                    finalDatabaseVersion ?? 0);
                if ((finalDatabaseVersion ?? 0) != (_rollbackToVersion ?? 0))
                {
                    Console.WriteLine(
                        Localizable.DatabaseUpdater_DisplayRollbackRecap_UnableToRollBackToRequestedVersion,
                        _rollbackToVersion);
                }
            }
        }

        /// <summary>
        ///     Sends a recap of the rollout to the console.
        /// </summary>
        /// <param name="originalDatabaseVersion"></param>
        private void DisplayRolloutRecap(long? originalDatabaseVersion)
        {
            Console.WriteLine();
            if (_writeScript)
            {
                Console.WriteLine(
                    Localizable.DatabaseUpdater_DisplayRolloutRecap_RolloutScriptCreatedToUpgradeDatabase,
                    originalDatabaseVersion,
                    _rolloutToVersion);
            }
            else
            {
                Console.WriteLine(Localizable.DatabaseUpdater_DisplayRolloutRecap_RolloutCompleted);
                long? finalDatabaseVersion = CurrentDatabaseVersion();
                Console.WriteLine(Localizable.DatabaseUpdater_DisplayRolloutRecap_DatabaseVersionUpgraded, originalDatabaseVersion,
                    finalDatabaseVersion);
                if (finalDatabaseVersion != _rolloutToVersion)
                {
                    Console.WriteLine(
                        Localizable.DatabaseUpdater_DisplayRolloutRecap_UnableToRollOutToRequestedVersion,
                        _rolloutToVersion);
                }
            }
        }

        /// <summary>
        ///     Drops the DatabaseVersionInformation table from the default
        ///     catalog (database) of the submitted connection string.
        /// </summary>
        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "No user input is included in the SQL command text.")]
#pragma warning disable S3649
        private void DropDatabaseVersionTable()
        {
            string connectionString = ConfigurationManager.ConnectionStrings[_connectionStringName].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string commandString = SqlStrings.DropDatabaseVersionTable;
                using (SqlCommand command = new SqlCommand(commandString, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

#pragma warning restore S3649

        /// <summary>
        /// Determines the version number of the first rollout script to apply.
        /// </summary>
        /// <returns></returns>
        private long FirstRolloutScript() => NextScript(CurrentDatabaseVersion() ?? -1);

        /// <summary>
        /// Rolls back the database to version zero.
        /// </summary>
        /// <param name="sqlTextWriter">The SQL text writer.</param>
        private void RollbackToVersionZero(TextWriter sqlTextWriter)
        {
            if (_writeScript)
            {
                if (sqlTextWriter != null)
                {
                    sqlTextWriter.WriteLine(SqlStrings.BannerFormat, "N/A - Drop DatabaseVersionInformation table");
                    sqlTextWriter.WriteLine(SqlStrings.DropDatabaseVersionTable);
                    sqlTextWriter.WriteLine("GO");
                    sqlTextWriter.WriteLine();
                }
            }
            else
            {
                DropDatabaseVersionTable();
            }
        }

        /// <summary>
        /// Sanity checks the rollback.
        /// </summary>
        /// <param name="oldestVersion">The oldest version.</param>
        /// <param name="mostRecentVersion">The most recent version.</param>
        /// <param name="originalDatabaseVersion">The original database version.</param>
        /// <returns></returns>
        private bool SanityCheckRollback(
            long oldestVersion,
            long mostRecentVersion,
            long? originalDatabaseVersion)
        {
            SetRollbackToVersion();
            if (!CheckForInvalidRollback(oldestVersion, mostRecentVersion))
            {
                return false;
            }

            if (!CheckForNoRollbackRequired(originalDatabaseVersion))
            {
                return false;
            }

            if (_writeScript && _rollbackToVersion == _rolloutToVersion)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(Localizable.DatabaseUpdater_SanityCheckRollback_RolloutAndRollbackCannotBeTheSame);

                Console.ResetColor();

                return false;
            }

            return true;
        }

        private bool CheckForNoRollbackRequired(long? originalDatabaseVersion)
        {
            if (!_writeScript && _rollbackToVersion == originalDatabaseVersion)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(Localizable.DatabaseUpdater_SanityCheckRollback_NoRollBackIsRequired);
                Console.WriteLine(Localizable.DatabaseUpdater_SanityCheckRollback_RequestedRollbackVersion, _rollbackToVersion);
                if (_environment != null)
                {
                    Console.WriteLine(Localizable.DatabaseUpdater_SanityCheckRollback_CurrentDatabaseVersion,
                        originalDatabaseVersion);
                }

                Console.ResetColor();

                return false;
            }

            return true;
        }

        private bool CheckForInvalidRollback(long oldestVersion, long mostRecentVersion)
        {
            if (_rollbackToVersion != 0 &&
                (_rollbackToVersion < oldestVersion || _rollbackToVersion > mostRecentVersion))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(Localizable.DatabaseUpdater_SanityCheckRollback_ARollbackToVersionIsNotPossible,
                    _rollbackToVersion);
                Console.WriteLine(
                    Localizable.DatabaseUpdater_SanityCheckRollback_ValidValuesAre,
                    oldestVersion == 1 ? 0 : oldestVersion,
                    mostRecentVersion);
                Console.ResetColor();

                return false;
            }

            return true;
        }

        private void SetRollbackToVersion()
        {
            if (_writeScript && _environment != null && _rollbackToVersion == null)
            {
                _rollbackToVersion = CurrentDatabaseVersion() ?? 0;
            }
        }

        /// <summary>
        /// Sanity checks the "rollout to" boundary.
        /// </summary>
        /// <param name="mostRecentVersion">The most recent version.</param>
        private void SanityCheckRolloutToBoundary(long mostRecentVersion)
        {
            if ((_rolloutToVersion ?? 0) > mostRecentVersion)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(Localizable.DatabaseUpdater_SanityCheckRolloutToBoundary_WARNINGDatabaseCannotBeUpgraded, _rolloutToVersion);
                Console.WriteLine(Localizable.DatabaseUpdater_SanityCheckRolloutToBoundary_TheLatestAvailableVersionWillBeUsed);
                Console.ResetColor();

                _rolloutToVersion = mostRecentVersion;
            }
        }

        /// <summary>Sets the rollout to version.</summary>
        private bool SetRolloutToVersion()
        {
            //
            // Get the most recent version number from the rollout list.
            //
            long mostRecentVersion = _rolloutScripts.Last().Key;
            if (_rolloutToVersion == null)
            {
                _rolloutToVersion = mostRecentVersion;
            }

            _rolloutToVersion = Math.Min((long)_rolloutToVersion, mostRecentVersion);

            return true;
        }

        /// <summary>Sets up rollback.</summary>
        /// <returns></returns>
        private TextWriter SetUpRollback()
        {
            TextWriter sqlTextWriter = null;
            if (_writeScript)
            {
                FileStream sqlOutputFileStream =
                    new FileStream(_outputFilePrefix + "-Rollback.sql", FileMode.Create);
                sqlTextWriter = new StreamWriter(sqlOutputFileStream);

                WriteSqlPreamble(sqlTextWriter);
            }

            return sqlTextWriter;
        }

        private bool CanRollBack()
        {
            if (_writeScript) return _rollbackToVersion < _rolloutToVersion;

            var version = CurrentDatabaseVersion();
            if (version == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(
                    Localizable.DatabaseUpdater_SetUpRollback_ThisDatabaseCannotBeRolledBack);
                Console.ResetColor();
                return false;
            }

            return true;
        }


        /// <summary>
        /// Sets up rollout.
        /// </summary>
        /// <param name="keyScriptNumbers"></param>
        /// <returns></returns>
        private TextWriter SetUpRollout(KeyScriptNumbers keyScriptNumbers)
        {
            TextWriter sqlTextWriter = null;

            if (_writeScript)
            {
                FileStream sqlOutputFileStream = new FileStream(_outputFilePrefix + "-Rollout.sql", FileMode.Create);
                sqlTextWriter = new StreamWriter(sqlOutputFileStream);

                WriteSqlPreamble(sqlTextWriter);

                if (keyScriptNumbers.FirstUpdate == 0)
                {
                    sqlTextWriter.WriteLine(SqlStrings.BannerFormat, "N/A - Create DatabaseVersionInformation table");
                    sqlTextWriter.WriteLine(SqlStrings.CreateDatabaseVersionTable);
                    sqlTextWriter.WriteLine("GO");
                    sqlTextWriter.WriteLine();
                }
            }
            else
            {
                if (CurrentDatabaseVersion() == null)
                {
                    CreateDatabaseVersionTable();
                    keyScriptNumbers.OriginalDatabaseVersion = CurrentDatabaseVersion();
                }
            }

            return sqlTextWriter;
        }

        /// <summary>
        /// Determines if an update is needed.
        /// </summary>
        /// <param name="keyScriptNumbers"></param>
        /// <returns></returns>
        private bool UpdateIsNeeded(KeyScriptNumbers keyScriptNumbers)
        {
            if (-1 != keyScriptNumbers.FirstUpdate && keyScriptNumbers.FirstUpdate <= keyScriptNumbers.MostRecentVersion)
            {
                return true;
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(Localizable.DatabaseUpdater_UpdateIsNeeded_NoUpdateIsRequired);
            Console.WriteLine(Localizable.DatabaseUpdater_UpdateIsNeeded_LatestAvailableUpdate, keyScriptNumbers.MostRecentVersion);
            Console.WriteLine(Localizable.DatabaseUpdater_UpdateIsNeeded_RequestedUpdate, _rolloutToVersion);
            if (_environment != null)
            {
                Console.WriteLine(
                    Localizable.DatabaseUpdater_SanityCheckRollback_CurrentDatabaseVersion,
                    keyScriptNumbers.OriginalDatabaseVersion);
            }

            Console.ResetColor();

            return false;
        }

        /// <summary>
        /// Writes the SQL preamble.
        /// </summary>
        /// <param name="sqlTextWriter">The SQL text writer.</param>
        private void WriteSqlPreamble(TextWriter sqlTextWriter)
        {
            sqlTextWriter.WriteLine("USE {0}", _database);
            sqlTextWriter.WriteLine("GO");
            sqlTextWriter.WriteLine();
            sqlTextWriter.WriteLine("BEGIN TRANSACTION");
            sqlTextWriter.WriteLine("GO");
            sqlTextWriter.WriteLine();
        }

        private long NextScript(long scriptNumber) => _rolloutScripts.Next(scriptNumber).Key;

        private long PreviousScript(long scriptNumber) => _rolloutScripts.Previous(scriptNumber).Key;

        #endregion Private Methods
    }
}