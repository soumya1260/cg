[![Build Status](https://w2-jenkins.sys.cigna.com/buildStatus/icon?job=HEALTHSPRING/CHSDEVOPS/GBS-DigitalApps/THUDBuild)](https://w2-jenkins.sys.cigna.com/job/HEALTHSPRING/job/CHSDEVOPS/job/GBS-DigitalApps/job/THUDBuild/) [![Quality Gate Status](https://sonarqube.sys.cigna.com/api/project_badges/measure?project=com.cigna.CHS.InternalTools.UpdateDatabase&metric=alert_status)](https://sonarqube.sys.cigna.com/dashboard?id=com.cigna.CHS.InternalTools.UpdateDatabase)
# ![THUD! Icon](Thud!/thud.bmp "THUD!") THUD! The Simple Database Synchronization Tool
###### Deploying Changes with _Attitude_!

## What is THUD!?
Thud! is a tool for automatically applying database updates and 
rollbacks using numbered SQL scripts.

Using a command as simple as:

```batch
thud! -rollout latest
```
it is possible to push the latest DDL and DML changes to a database.

See the [documentation](UserGuide.md) for full details on how to use the tool.


## Why "THUD!"?
Well, we wanted something short and easy to remember.  The
old name, UpdatedDatabase, had the initials "UD", so we just kind of 
went from there.  Thud! doesn't stand for anything -- it's just a 
comic book onomatopoeia word.  It is the first of many applications
to be developed by Cigna GBS Digital Applications that will employ
monosyllabic onomatopoeia names.
