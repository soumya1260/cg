ALTER TABLE [dbo].[DeleteMe]
	DROP COLUMN IgnoreMeToo 
	