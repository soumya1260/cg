create procedure WhatTimeIsIt AS
BEGIN
	SELECT GETDATE()
END