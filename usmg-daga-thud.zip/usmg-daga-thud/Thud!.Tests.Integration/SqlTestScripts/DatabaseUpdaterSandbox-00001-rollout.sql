CREATE TABLE [dbo].[DELETEME] (
	ignoreme int not null
)