﻿CREATE TABLE DeleteMeAgain (deleteme INT NULL);
GO

INSERT INTO	dbo.DeleteMeAgain (deleteme) VALUES(0);
GO
