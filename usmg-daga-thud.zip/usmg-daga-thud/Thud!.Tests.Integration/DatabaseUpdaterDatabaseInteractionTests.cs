﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using Cigna.DigitalApplications.Thud;
using NUnit.Framework;

namespace Thud.Tests.Integration
{
    [TestFixture, ExcludeFromCodeCoverage, Category("Integration")]
    public class DatabaseUpdaterDatabaseInteractionTests
    {
        #region Set-up / Tear-down

        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "SQL Command is in a test fixture.")]
        [SetUp]
        public void Setup()
        {
            var settings = DatabaseUpdaterFileSystemTests.DefaultTestSettings();

            //
            // Special connection string for setup/teardown only.  This string has Portal as its default
            // catalog since the sandbox database may not exist.
            //
            var connectionString =
                ConfigurationManager.ConnectionStrings[settings.ConnectionStringName + "-Portal"].ConnectionString;

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                try
                {
                    //
                    // Make sure we don't have a test database left-over from a failed test run.
                    //
                    using (var command = new SqlCommand(SqlStrings.DropSandbox, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    //
                    // Swallow exception.  We normally expect the database to not exist.
                    //
                }

                //
                // Create the test database.
                //
                using (var command = new SqlCommand(SqlStrings.CreateSandbox, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "SQL Command is in a test fixture.")]
        [TearDown]
        public void Teardown()
        {
            var settings = DatabaseUpdaterFileSystemTests.DefaultTestSettings();

            //
            // Special connection string for setup/teardown only.  This string has Portal as its default
            // catalog since the sandbox database may not exist.
            //
            var connectionString =
                ConfigurationManager.ConnectionStrings[settings.ConnectionStringName + "-Portal"].ConnectionString;

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var commandString = SqlStrings.DropSandbox;
                try
                {
                    using (var command = new SqlCommand(commandString, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception)
                {
                    // Swallow exception.
                }
            }
        }

        #endregion Set-up / Tear-down

        #region Test helpers

        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "SQL Command is in a test fixture.")]
        private void DropWhatTimeIsItStoredProcedure(string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var commandString = SqlStrings.DropWhatTimeIsIt;
                using (var command = new SqlCommand(commandString, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "SQL Command is in a test fixture.")]
        private void CreateDatabaseVersionTable(string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var commandString = Cigna.DigitalApplications.Thud.Resources.SqlStrings.CreateDatabaseVersionTable;
                using (var command = new SqlCommand(commandString, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "SQL Command is in a test fixture.")]
        private static void DropDatabaseVersionTable(string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var commandString = Cigna.DigitalApplications.Thud.Resources.SqlStrings.DropDatabaseVersionTable;
                using (var command = new SqlCommand(commandString, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "SQL Command is in a test fixture.")]
        private static void DropDeleteMeTable(string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var commandString = SqlStrings.DropDeleteMeTable;
                using (var command = new SqlCommand(commandString, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        [SuppressMessage(
            "Microsoft.Security",
            "CA2100:Review SQL queries for security vulnerabilities",
            Justification = "SQL command text is in a test fixture.")]
        private bool DatabaseResult(string connectionString, string commandString)
        {
            var result = false;
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand(commandString, connection))
                {
                    var reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        result = (int)reader.GetValue(0) == 1;
                    }
                }
            }

            return result;
        }

        #endregion Test helpers

        #region Tests

        [Test]
        public void ApplyUpdate_SucceedsWithValidInputs()
        {
            var settings = DatabaseUpdaterFileSystemTests.DefaultTestSettings();
            var connectionString =
                ConfigurationManager.ConnectionStrings[settings.ConnectionStringName].ConnectionString;
            DropDatabaseVersionTable(connectionString);
            CreateDatabaseVersionTable(connectionString);
            var updater = new DatabaseUpdater(settings);
            var filename = Path.Combine(settings.SourceFolder, "DatabaseUpdaterSandbox-00001-rollout.sql");

            DropDeleteMeTable(connectionString);

            Assert.That(updater.ApplyUpdate(1, filename, null));
            Assert.AreEqual(1, updater.CurrentDatabaseVersion());

            DropDeleteMeTable(connectionString);
        }

        [Test]
        public void GetDatabaseVersion_ReturnsNullIfVersionTableDoesNotExist()
        {
            var settings = DatabaseUpdaterFileSystemTests.DefaultTestSettings();
            var connectionString =
                ConfigurationManager.ConnectionStrings[settings.ConnectionStringName].ConnectionString;

            DropDatabaseVersionTable(connectionString);
            var updater = new DatabaseUpdater(settings);
            Assert.That(updater.CurrentDatabaseVersion() == null);
        }

        [Test]
        public void GetDatabaseVersion_ReturnsZeroIfNewVersionTableCreated()
        {
            var settings = DatabaseUpdaterFileSystemTests.DefaultTestSettings();
            var connectionString =
                ConfigurationManager.ConnectionStrings[settings.ConnectionStringName].ConnectionString;

            DropDatabaseVersionTable(connectionString);
            CreateDatabaseVersionTable(connectionString);

            var updater = new DatabaseUpdater(settings);
            Assert.AreEqual((long?)0, updater.CurrentDatabaseVersion());
        }

        [Test]
        public void Rollback_SucceedsForFullRollback()
        {
            var settings = new UpdateSettings
            {
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                OutputFilePrefix = null,
                WriteScript = false,
                UpdateDirection = UpdateDirections.Rollout,
                Environment = ConfigurationManager.AppSettings["defaultEnvironment"],
                Wait = false,
                RollbackToVersion = null,
                SourceFolder = @"..\..\SqlTestScripts",
                RolloutToVersion = null,
                DatabaseName = "DatabaseUpdaterSandbox"
            };
            var connectionString =
                ConfigurationManager.ConnectionStrings[settings.ConnectionStringName].ConnectionString;
            DropDatabaseVersionTable(connectionString);
            DropDeleteMeTable(connectionString);
            DropWhatTimeIsItStoredProcedure(connectionString);

            var updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));

            updater.PerformUpdate();
            Assert.AreEqual(6, updater.CurrentDatabaseVersion());
            Assert.That(DatabaseResult(connectionString, SqlStrings.DeleteMeTableExists), "DeleteMe Table Exists");
            Assert.That(DatabaseResult(connectionString, SqlStrings.IgnoreMeTooColumnExists),
                "IgnoreMeToo Column Exists");
            Assert.That(DatabaseResult(connectionString, SqlStrings.OneRowInDeleteMeTable), "One row in DeleteMe table");
            Assert.That(DatabaseResult(connectionString, SqlStrings.WhatTimeIsItExists), "WhatTimeIsIt exists");
            Assert.That(DatabaseResult(connectionString, SqlStrings.DeleteMeIndexExists),
                "DeleteMe index (IX_IgnoreMe) exists");

            //
            // Okay, NOW do the rollback.
            //
            settings.RollbackToVersion = 0;
            settings.RolloutToVersion = null;
            settings.UpdateDirection = UpdateDirections.Rollback;

            updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));

            updater.PerformUpdate();

            Assert.That(!DatabaseResult(connectionString, SqlStrings.DeleteMeTableExists),
                "DeleteMe Table does not exist");
            Assert.That(!DatabaseResult(connectionString, SqlStrings.WhatTimeIsItExists), "WhatTimeIsIt does not exist");
            Assert.AreEqual(null, updater.CurrentDatabaseVersion());
        }

        [Test]
        public void Rollout_SucceedsForFullRolloutOnUnVersionedDatabase()
        {
            var settings = new UpdateSettings
            {
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                OutputFilePrefix = null,
                WriteScript = false,
                UpdateDirection = UpdateDirections.Rollout,
                Environment = ConfigurationManager.AppSettings["defaultEnvironment"],
                Wait = false,
                RollbackToVersion = null,
                SourceFolder = @"..\..\SqlTestScripts",
                RolloutToVersion = null,
                DatabaseName = "DatabaseUpdaterSandbox"
            };
            var connectionString =
                ConfigurationManager.ConnectionStrings[settings.ConnectionStringName].ConnectionString;
            DropDatabaseVersionTable(connectionString);
            DropDeleteMeTable(connectionString);
            DropWhatTimeIsItStoredProcedure(connectionString);

            var updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));

            updater.PerformUpdate();
            Assert.That(DatabaseResult(connectionString, SqlStrings.DeleteMeTableExists), "DeleteMe Table Exists");
            Assert.That(DatabaseResult(connectionString, SqlStrings.IgnoreMeTooColumnExists),
                "IgnoreMeToo Column Exists");
            Assert.That(DatabaseResult(connectionString, SqlStrings.OneRowInDeleteMeTable), "One row in DeleteMe table");
            Assert.That(DatabaseResult(connectionString, SqlStrings.WhatTimeIsItExists), "WhatTimeIsIt exists");
            Assert.That(DatabaseResult(connectionString, SqlStrings.DeleteMeIndexExists),
                "DeleteMe index (IX_IgnoreMe) exists");
        }

        [Test]
        public void Rollout_SucceedsForPartialUpdatesWithUnVersionedDatabase()
        {
            var settings = new UpdateSettings
            {
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                OutputFilePrefix = null,
                WriteScript = false,
                UpdateDirection = UpdateDirections.Rollout,
                Environment = ConfigurationManager.AppSettings["defaultEnvironment"],
                Wait = false,
                RollbackToVersion = null,
                SourceFolder = @"..\..\SqlTestScripts",
                RolloutToVersion = 3,
                DatabaseName = "DatabaseUpdaterSandbox"
            };
            var connectionString =
                ConfigurationManager.ConnectionStrings[settings.ConnectionStringName].ConnectionString;
            DropDatabaseVersionTable(connectionString);
            DropDeleteMeTable(connectionString);
            DropWhatTimeIsItStoredProcedure(connectionString);
            var updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));

            //
            // Only apply updates 1-3.
            //
            updater.PerformUpdate();
            Assert.That(updater.CurrentDatabaseVersion(), Is.EqualTo(3));
            Assert.That(DatabaseResult(connectionString, SqlStrings.DeleteMeTableExists), "DeleteMe Table Exists");
            Assert.That(DatabaseResult(connectionString, SqlStrings.IgnoreMeTooColumnExists),
                "IgnoreMeToo Column Exists");
            Assert.That(DatabaseResult(connectionString, SqlStrings.OneRowInDeleteMeTable), "One row in DeleteMe table");
            Assert.That(DatabaseResult(connectionString, SqlStrings.WhatTimeIsItExists), Is.False,
                "WhatTimeIsIt does not exist");
            Assert.That(DatabaseResult(connectionString, SqlStrings.DeleteMeIndexExists), Is.False,
                "DeleteMe index (IX_IgnoreMe) does not exist");

            //
            // Apply remaining updates
            //
            settings.RolloutToVersion = null;
            updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));
            updater.PerformUpdate();
            Assert.That(updater.CurrentDatabaseVersion(), Is.EqualTo(6));

            Assert.That(DatabaseResult(connectionString, SqlStrings.WhatTimeIsItExists), "WhatTimeIsIt exists");
            Assert.That(DatabaseResult(connectionString, SqlStrings.DeleteMeIndexExists),
                "DeleteMe index (IX_IgnoreMe) exists");
        }

        [Test]
        public void Rollout_SucceedsForPartialUpdatesWhenNextUpdateIsFinalUpdate()
        {
            var settings = new UpdateSettings
            {
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                OutputFilePrefix = null,
                WriteScript = false,
                UpdateDirection = UpdateDirections.Rollout,
                Environment = ConfigurationManager.AppSettings["defaultEnvironment"],
                Wait = false,
                RollbackToVersion = null,
                SourceFolder = @"..\..\SqlTestScripts",
                RolloutToVersion = 5,
                DatabaseName = "DatabaseUpdaterSandbox"
            };
            var connectionString =
                ConfigurationManager.ConnectionStrings[settings.ConnectionStringName].ConnectionString;
            DropDatabaseVersionTable(connectionString);
            DropDeleteMeTable(connectionString);
            DropWhatTimeIsItStoredProcedure(connectionString);
            var updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));

            //
            // Only apply updates 1-5.
            //
            updater.PerformUpdate();
            Assert.That(updater.CurrentDatabaseVersion(), Is.EqualTo(5));

            //
            // Apply remaining updates
            //
            settings.RolloutToVersion = null; // Latest version
            updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));
            updater.PerformUpdate();
            Assert.That(updater.CurrentDatabaseVersion(), Is.EqualTo(6));
        }

        [Test]
        public void GetVersions_ReturnsExpectedString()
        {
            var settings = new UpdateSettings
            {
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                OutputFilePrefix = null,
                WriteScript = false,
                UpdateDirection = UpdateDirections.Rollout,
                Environment = ConfigurationManager.AppSettings["defaultEnvironment"],
                Wait = false,
                RollbackToVersion = null,
                SourceFolder = @"..\..\SqlTestScripts",
                RolloutToVersion = 3,
                DatabaseName = "DatabaseUpdaterSandbox"
            };
            var connectionString =
                ConfigurationManager.ConnectionStrings[settings.ConnectionStringName].ConnectionString;
            DropDatabaseVersionTable(connectionString);
            DropDeleteMeTable(connectionString);
            DropWhatTimeIsItStoredProcedure(connectionString);
            var updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));

            //
            // Only apply updates 1-3.
            //
            updater.PerformUpdate();

            //
            // Set up for a -GetVersions run.
            //
            settings.RolloutToVersion = null;
            settings.GetVersions = true;
            updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));

            string output = updater.GetVersionString();

            // ReSharper disable StringLiteralTypo
            Assert.That(
                output,
                Is.EqualTo("HSTNSQLWEBDEV01.healthspring.inside: DatabaseUpdaterSandbox (apply scripts 4 through 6)"));
            // ReSharper restore StringLiteralTypo
        }

        [Test]
        public void Rollout_DoesNothingIfDatabaseVersionIsCurrent()
        {
            var settings = new UpdateSettings
            {
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                OutputFilePrefix = null,
                WriteScript = false,
                UpdateDirection = UpdateDirections.Rollout,
                Environment = ConfigurationManager.AppSettings["defaultEnvironment"],
                Wait = false,
                RollbackToVersion = null,
                SourceFolder = @"..\..\SqlTestScripts",
                RolloutToVersion = 6,
                DatabaseName = "DatabaseUpdaterSandbox"
            };

            var updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));
            updater.PerformUpdate();
            Assert.That(updater.CurrentDatabaseVersion(), Is.EqualTo(6), "Set-up conditions failed.  Stopping test.");

            //
            // Now run again with the same settings
            //
            updater.PerformUpdate();
            Assert.That(updater.CurrentDatabaseVersion(), Is.EqualTo(6));
        }

        #endregion Tests
    }
}