﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using Cigna.DigitalApplications.Thud;
using NUnit.Framework;

namespace Thud.Tests.Integration
{
    [TestFixture, ExcludeFromCodeCoverage, Category("Integration")]
    public class DatabaseUpdaterFileSystemTests
    {
        [Test]
        public void DatabaseUpdater_GetFileListReturnsExpectedLists()
        {
            var updater = new DatabaseUpdater(DefaultTestSettings());
            var rolloutList = new List<string>();
            var rollbackList = new List<string>();

            Assert.That(updater.GetFiles(rolloutList, rollbackList));
            Assert.That(rolloutList.Count == 6);
            Assert.That(rollbackList.Count == 6);
        }

        [Test]
        public void ApplyUpdates_GeneratesExpectedOutput()
        {
            var settings = new UpdateSettings
            {
                UpdateDirection = UpdateDirections.Rollout,
                Environment = null,
                RolloutToVersion = null,
                SourceFolder = @"..\..\SqlTestScripts",
                DatabaseName = "DatabaseUpdaterSandbox",
                WriteScript = true,
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                Wait = false,
                OutputFilePrefix = "test",
                RollbackToVersion = null,
                ShowStackTrace = false
            };

            var updater = new DatabaseUpdater(settings);
            var stream = new FileStream(settings.OutputFilePrefix + "-Rollout.sql", FileMode.Create);
            using (var writer = new StreamWriter(stream))
            {
                updater.ApplyUpdate(1, @"..\..\SqlTestScripts\DatabaseUpdaterSandbox-00001-rollout.sql", writer);
            }

            string scriptFileContents;
            using (var streamReader = new StreamReader(settings.OutputFilePrefix + "-Rollout.sql"))
            {
                scriptFileContents = streamReader.ReadToEnd();
            }
            File.Delete(settings.OutputFilePrefix + "-Rollout.sql");

            Assert.AreEqual(SqlStrings.ApplyUpdateResult, scriptFileContents);
        }

        [Test]
        public void Rollout_GeneratesExpectedOutput()
        {
            var settings = new UpdateSettings
            {
                UpdateDirection = UpdateDirections.Rollout,
                Environment = null,
                RolloutToVersion = 5,
                SourceFolder = @"..\..\SqlTestScripts",
                DatabaseName = "DatabaseUpdaterSandbox",
                WriteScript = true,
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                Wait = false,
                OutputFilePrefix = "test",
                RollbackToVersion = null,
                ShowStackTrace = false
            };

            var updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));
            updater.Rollout();

            string scriptFileContents;
            using (var streamReader = new StreamReader(settings.OutputFilePrefix + "-Rollout.sql"))
            {
                scriptFileContents = streamReader.ReadToEnd();
            }

            File.Delete(settings.OutputFilePrefix + "-Rollout.sql");

            Assert.AreEqual(SqlStrings.ExpectedRolloutFileResult, scriptFileContents);
        }

        [Test]
        public void Rollback_GeneratesExpectedOutput()
        {
            var settings = new UpdateSettings
            {
                UpdateDirection = UpdateDirections.Rollout,
                Environment = null,
                RolloutToVersion = 5,
                RollbackToVersion = 0,
                SourceFolder = @"..\..\SqlTestScripts",
                DatabaseName = "DatabaseUpdaterSandbox",
                WriteScript = true,
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                Wait = false,
                OutputFilePrefix = "test",
                ShowStackTrace = false
            };

            var updater = new DatabaseUpdater(settings);
            Assert.That(updater.InitializeLists(), Is.EqualTo(0));
            updater.Rollback();

            string scriptFileContents;
            using (var streamReader = new StreamReader(settings.OutputFilePrefix + "-Rollback.sql"))
            {
                scriptFileContents = streamReader.ReadToEnd();
            }

            File.Delete(settings.OutputFilePrefix + "-Rollback.sql");

            Assert.AreEqual(SqlStrings.ExpectedRollbackFileResult, scriptFileContents);
        }

        public static UpdateSettings DefaultTestSettings()
        {
            var settings = new UpdateSettings
            {
                UpdateDirection = UpdateDirections.Rollout,
                Environment = "DEV",
                RolloutToVersion = null,
                SourceFolder = @"..\..\SqlTestScripts",
                DatabaseName = "DatabaseUpdaterSandbox",
                WriteScript = false,
                OutputFilePrefix = null,
                ArgumentsParsedSuccessfully = true,
                ErrorMessage = null,
                Wait = false
            };
            return settings;
        }
    }
}