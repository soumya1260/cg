﻿using System.Reflection;

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// NOTE: Version information is being set in the VersionInfo.cs file
// To include it, just add VersionInfo.cs as a Linked file to each project
// 1. Add existing Item
// 2. Select VersionInfo.cs from the solution root
// 3. Change the "Add" dropdown to "Add as link"
[assembly: AssemblyVersion("2023.1.0.0")]
[assembly: AssemblyFileVersion("2023.1.0.0")]
