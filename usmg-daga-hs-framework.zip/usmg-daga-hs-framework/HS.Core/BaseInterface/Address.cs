﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="Address.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
  

    /// <summary>
    /// This is a base address class for re-use across various objects
    /// </summary>
    [DataContract]
    public abstract class AddressInformation
    {
        /// <summary>
        /// Gets or sets the street address1.
        /// </summary>
        /// <value>The street address1.</value>
        [DataMember]
        public string StreetAddress1 { get; set; }

        /// <summary>
        /// Gets or sets the street address2.
        /// </summary>
        /// <value>The street address2.</value>
        [DataMember]
        public string StreetAddress2 { get; set; }

        /// <summary>
        /// Gets or sets the city.
        /// </summary>
        /// <value>The city.</value>
        [DataMember]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets the state.
        /// </summary>
        /// <value>The state.</value>
        [DataMember]
        public string State { get; set; }

        /// <summary>
        /// Gets or sets the postal code.
        /// </summary>
        /// <value>The postal code.</value>
        [DataMember]
        public string PostalCode { get; set; }

        /// <summary>
        /// Gets or sets the home phone.
        /// </summary>
        /// <value>The home phone.</value>
        [DataMember]
        public string HomePhone { get; set; }

        /// <summary>
        /// Gets or sets the cell phone.
        /// </summary>
        /// <value>The cell phone.</value>
        [DataMember]
        public string CellPhone { get; set; }

        /// <summary>
        /// Gets or sets the work phone.
        /// </summary>
        /// <value>The work phone.</value>
        [DataMember]
        public string WorkPhone { get; set; }

        /// <summary>
        /// Gets or sets the fax.
        /// </summary>
        /// <value>The fax.</value>
        [DataMember]
        public string Fax { get; set; }

        /// <summary>
        /// Gets or sets the decimal mail address.
        /// </summary>
        /// <value>The decimal mail address.</value>
        [DataMember]
        public string EMailAddress { get; set; }

        /// <summary>
        /// Gets or sets the decimal mail address2.
        /// </summary>
        /// <value>The decimal mail address2.</value>
        [DataMember]
        public string EMailAddress2 { get; set; }
    }
}
