﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="ServiceResponse.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{



    /// <summary>
    /// The base class for a response object that needs to be
    /// propogated across a WCF service interface
    /// </summary>
    [DataContract]
    public class ServiceResponse
    {

        /// <summary>
        /// The response result (Error, Failure or Warning)
        /// </summary>
        /// <value>The result.</value>
        [DataMember]
        public ResponseResult Result { get; set; }

        /// <summary>
        /// Used to send free text message back to the requesting system
        /// </summary>
        /// <value>The messages.</value>
        [DataMember]
        public List<string> Messages { get; set; }

        #region Errors

        /// <summary>
        /// The _errors
        /// </summary>
        private List<ServiceFault> _errors;

        /// <summary>
        /// Contains any errors that were encountered in processing
        /// the request
        /// </summary>
        /// <value>The errors.</value>
        [DataMember]
        public List<ServiceFault> Errors
        {
            get
            {

                if (_errors == null)
                    _errors = new List<ServiceFault>();

                return _errors;

            }
            set
            {
                _errors = value;
            }
        }

        #endregion

        #region Warnings

        /// <summary>
        /// The _warnings
        /// </summary>
        private List<ServiceFault> _warnings;

        /// <summary>
        /// Contains any warnings that were encountered in processing
        /// the request
        /// </summary>
        /// <value>The warnings.</value>
        [DataMember]
        public List<ServiceFault> Warnings
        {
            get
            {

                if (_warnings == null)
                    _warnings = new List<ServiceFault>();

                return _warnings;

            }
            set
            {
                _warnings = value;
            }
        }

        #endregion

        #region Error

        /// <summary>
        /// Adds an error to the <see cref="Errors" /> collection
        /// and fails the context. If <see cref="AssertOptions" />
        /// is set to <see cref="AssertOptions.ErrorsAsWarnings" />,
        /// they will be added to the <see cref="Warnings" />
        /// collection instead and the context will not be failed.
        /// </summary>
        /// <param name="fault">The fault.</param>
        public void Error(ServiceFault fault)
        {

            if ((this.AssertOption & AssertOption.ErrorsAsWarnings) == AssertOption.ErrorsAsWarnings)
            {
                Warnings.Add(fault);
            }
            else
            {
                Errors.Add(fault);
                Result = ResponseResult.Error;
            }

        }

        /// <summary>
        /// Adds an error to the <see cref="Errors" /> collection
        /// and fails the context. If <see cref="AssertOptions" />
        /// is set to <see cref="AssertOptions.ErrorsAsWarnings" />,
        /// they will be added to the <see cref="Warnings" />
        /// collection instead and the context will not be failed.
        /// </summary>
        /// <param name="ex">The executable.</param>
        public void Error(Exception ex)
        {

            Result = ResponseResult.Exception;

            Errors.Add(new ServiceFault()
            {
                Source = ex.Source,
                Message = ex.ToString(),
                FaultCode = ServiceFault.UnexpectedError,
                IsLocalized = false
            });

        }

        /// <summary>
        /// Adds an error to the <see cref="Errors" /> collection
        /// and fails the context. If <see cref="AssertOptions" />
        /// is set to <see cref="AssertOptions.ErrorsAsWarnings" />,
        /// they will be added to the <see cref="Warnings" />
        /// collection instead and the context will not be failed.
        /// </summary>
        /// <param name="faults">The faults.</param>
        public void Error(IEnumerable<ServiceFault> faults)
        {
            foreach (ServiceFault fault in faults)
            {
                Error(fault);
            }
        }

        #endregion

        #region Warning

        /// <summary>
        /// Adds an error to the <see cref="Warnings" /> collection.
        /// </summary>
        /// <param name="fault">The fault.</param>
        public void Warning(ServiceFault fault)
        {
            Warnings.Add(fault);
        }

        /// <summary>
        /// Adds an error to the <see cref="Warnings" /> collection.
        /// </summary>
        /// <param name="ex">The executable.</param>
        public void Warning(Exception ex)
        {

            Result = ResponseResult.Error;

            Errors.Add(new ServiceFault()
            {
                Source = ex.Source,
                Message = ex.ToString(),
                FaultCode = ServiceFault.UnexpectedError,
                IsLocalized = false
            });

        }

        /// <summary>
        /// Adds an error to the <see cref="Warnings" /> collection.
        /// </summary>
        /// <param name="faults">The faults.</param>
        public void Warning(IEnumerable<ServiceFault> faults)
        {
            foreach (ServiceFault fault in faults)
            {
                Warning(fault);
            }
        }

        #endregion

        #region Assert

        /// <summary>
        /// Used this flag to tell a <see cref="HSServiceContext" />
        /// to treat errors as warnings. Exceptions will still be
        /// treated as Errors.
        /// </summary>
        /// <value>The assert option.</value>
        public AssertOption AssertOption { get; set; }

        /// <summary>
        /// Checks a condition. If it's true nothing happens. If it's
        /// false, a <see cref="GenericWorkflowFault" /> will be added to the
        /// <see cref="Errors" /> collection and the response will be
        /// failed.
        /// </summary>
        /// <param name="condition">The condition to test</param>
        /// <param name="message">The error message</param>
        /// <param name="source">The error source</param>
        /// <param name="faultCode">The fault code.</param>
        /// <returns>True if <paramref name="condition" /> is true, otherwise false</returns>
        public bool Assert(bool condition, string message, string source, decimal faultCode)
        {

            if (!condition)
            {
                Error(new ServiceFault() { Message = message, Source = source, FaultCode = faultCode });
            }

            return condition;

        }

        /// <summary>
        /// Checks a condition. If it's true nothing happens. If it's
        /// false, a <see cref="GenericWorkflowFault" /> will be added to the
        /// <see cref="Warnings" /> collection.
        /// </summary>
        /// <param name="condition">The condition to test</param>
        /// <param name="message">The error message</param>
        /// <param name="source">The error source</param>
        /// <param name="faultCode">The fault code.</param>
        /// <returns>True if <paramref name="condition" /> is true, otherwise false</returns>
        public bool AssertWarning(bool condition, string message, string source, decimal faultCode)
        {

            if (!condition)
            {
                Warning(new ServiceFault() { Message = message, Source = source, FaultCode = faultCode });
            }

            return condition;

        }

        /// <summary>
        /// Checks a condition. If it's true nothing happens. If it's
        /// false, a <see cref="WorkflowFault" /> will be added to the
        /// <see cref="Errors" /> collection and the response will be
        /// failed.
        /// </summary>
        /// <param name="test">The test.</param>
        /// <returns>True if <paramref name="condition" /> is true, otherwise false</returns>
        public bool Assert(Assertion test)
        {

            if (!test.Test)
            {

                Error(new ServiceFault()
                {
                    Source = test.Source,
                    Message = test.Message,
                    IsLocalized = test.IsLocalized,
                    FaultCode = test.FaultCode
                });

            }

            return test.Test;

        }

        /// <summary>
        /// Checks a condition. If it's true nothing happens. If it's
        /// false, a <see cref="WorkflowFault" /> will be added to the
        /// <see cref="Warnings" /> collection.
        /// </summary>
        /// <param name="test">The test.</param>
        /// <returns>True if <paramref name="condition" /> is true, otherwise false</returns>
        public bool AssertWarning(Assertion test)
        {

            if (!test.Test)
            {
                Warning(new ServiceFault()
                {
                    Source = test.Source,
                    Message = test.Message,
                    IsLocalized = test.IsLocalized,
                    FaultCode = test.FaultCode
                });
            }

            return test.Test;

        }

        /// <summary>
        /// Checks to see if the specified <see cref="WorkflowActionResponse" />
        /// has been denied for any reason. If so, its reasons will
        /// be added to the <see cref="Errors" /> collection and the
        /// response will be failed.
        /// </summary>
        /// <param name="response">The response.</param>
        /// <param name="actions">The actions to check for denial</param>
        /// <returns>True if none of the actions were denied, otherwise false.</returns>
        public bool Assert(WorkflowActionResponse response, params string[] actions)
        {

            bool value = true;

            List<string> actionList = new List<string>(actions);

            if (actionList.Count == 0)
                actionList = new List<string>(response.Actions.Keys);

            foreach (string action in actionList)
            {
                if (response.Actions[action].Status == ActionStatus.Deny)
                {

                    value = false;

                    foreach (ServiceFault error in response.Actions[action].Reasons)
                        Error(error);

                }
            }

            return value;

        }

        /// <summary>
        /// Checks to see if the specified <see cref="WorkflowActionResponse" />
        /// has been denied for any reason. If so, its reasons will
        /// be added to the <see cref="Warnings" /> collection.
        /// </summary>
        /// <param name="response">The response.</param>
        /// <param name="actions">The actions to check for denial</param>
        /// <returns>True if none of the actions were denied, otherwise false.</returns>
        public bool AssertWarning(WorkflowActionResponse response, params string[] actions)
        {

            bool value = true;

            List<string> actionList = new List<string>(actions);

            if (actionList.Count == 0)
                actionList = new List<string>(response.Actions.Keys);

            foreach (string action in actionList)
            {
                if (response.Actions[action].Status == ActionStatus.Deny)
                {

                    value = false;

                    Warning(response.Actions[action].Reasons);

                }
            }

            return value;

        }

        #endregion

        /// <summary>
        /// True if the response is in the failure or error state
        /// </summary>
        /// <value><c>true</c> if this instance has failed; otherwise, <c>false</c>.</value>
        public bool HasFailed
        {
            get
            {
                return this.Result == ResponseResult.Exception ||
                       this.Result == ResponseResult.Error ||
                       this.Result == ResponseResult.SecurityViolation;
            }
        }

        /// <summary>
        /// Default constructor initializes all child members
        /// </summary>
        public ServiceResponse()
        {
            Errors = new List<ServiceFault>();
            Warnings = new List<ServiceFault>();
            Messages = new List<string>();
        }

    }

    /// <summary>
    /// The base class for a response that returns a single item
    /// </summary>
    /// <typeparam name="ItemType">The type of the item type.</typeparam>
    [DataContract]
    public class ServiceResponse<ItemType> : ServiceResponse
    {
        /// <summary>
        /// Gets or sets the item.
        /// </summary>
        /// <value>The item.</value>
        [DataMember]
        public ItemType Item { get; set; }
    }
}
