﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="ValidationResponse.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Base response for any request that checks the database
    /// for the existence of some piece of data
    /// </summary>
    [DataContract]
    public class ValidationResponse : ServiceResponse
    {

        /// <summary>
        /// Whether or not the key was valid
        /// </summary>
        /// <value><c>true</c> if this instance is valid; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool IsValid { get; set; }

        /// <summary>
        /// The (localized) reason the data was invalid
        /// </summary>
        /// <value>The error message.</value>
        [DataMember]
        public string ErrorMessage { get; set; }

    }
}
