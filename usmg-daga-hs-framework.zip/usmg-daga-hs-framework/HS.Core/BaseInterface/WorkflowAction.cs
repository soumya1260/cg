﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="WorkflowAction.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Represents an action that a user could take on an object.
    /// For example, "Edit", "Save" or "Print"
    /// </summary>
    [DataContract]
    public class WorkflowAction
    {

        /// <summary>
        /// The action name. For example, "Edit", "Save" or "Print".
        /// </summary>
        /// <value>The name.</value>
        [DataMember]
        public string Name { get; set; }

        /// <summary>
        /// Represents whether the action is currently allowed or
        /// denied based on the state of the object
        /// </summary>
        /// <value>The status.</value>
        [DataMember]
        public ActionStatus Status { get; set; }

        #region Reasons

        /// <summary>
        /// The _reasons
        /// </summary>
        private List<ServiceFault> _reasons;

        /// <summary>
        /// Contains the list of reasons that an action is
        /// currently denied.
        /// </summary>
        /// <value>The reasons.</value>
        [DataMember]
        public List<ServiceFault> Reasons
        {
            get
            {

                if (_reasons == null)
                    _reasons = new List<ServiceFault>();

                return _reasons;

            }
            set
            {
                _reasons = value;
            }
        }

        #endregion

        /// <summary>
        /// Changes the action to the denied state and adds the
        /// specified reason for the denial.
        /// </summary>
        /// <param name="reason">The reason.</param>
        public void Deny(ServiceFault reason)
        {

            if (Reasons == null)
                Reasons = new List<ServiceFault>();

            Reasons.Add(reason);

            Status = ActionStatus.Deny;

        }

        /// <summary>
        /// Changes the action to the denied state and adds the
        /// specified reason for the denial.
        /// </summary>
        /// <param name="reasons">The reasons.</param>
        public void Deny(IEnumerable<ServiceFault> reasons)
        {

            if (Reasons == null)
                Reasons = new List<ServiceFault>();

            if (reasons != null)
                Reasons.AddRange(reasons);

            Status = ActionStatus.Deny;

        }

        /// <summary>
        /// Changes the current action to the allowed state, and
        /// clears the reason list
        /// </summary>
        public void Allow()
        {
            Reasons = new List<ServiceFault>();
            Status = ActionStatus.Allow;
        }

        /// <summary>
        /// Changes the current action to the allowed state, if
        /// and only if it has not already been denied for some
        /// other reason.
        /// </summary>
        public void AllowIfNoReasons()
        {
            if (Reasons == null || Reasons.Count == 0)
                Status = ActionStatus.Allow;
        }

        /// <summary>
        /// Denies the action if the specified test returns false.
        /// </summary>
        /// <param name="test">The test.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool Assert(Assertion test)
        {

            if (!test.Test)
            {
                Deny(new ServiceFault()
                {
                    Source = test.Source,
                    Message = test.Message,
                    IsLocalized = test.IsLocalized,
                    FaultCode = test.FaultCode
                });
            }

            return test.Test;

        }

        /// <summary>
        /// Denies the action if the specified test returns false.
        /// </summary>
        /// <param name="test">if set to <c>true</c> [test].</param>
        /// <param name="faultCode">The fault code.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool Assert(bool test, decimal faultCode)
        {

            if (!test)
            {
                Deny(new ServiceFault()
                {
                    Source = string.Empty,
                    Message = string.Empty,
                    IsLocalized = false,
                    FaultCode = faultCode
                });
            }

            return test;

        }

        /// <summary>
        /// Checks the action to see if it has been denied for the
        /// requested reason
        /// </summary>
        /// <param name="reason">The reason.</param>
        /// <returns><c>true</c> if the specified reason has reason; otherwise, <c>false</c>.</returns>
        public bool HasReason(ServiceFault reason)
        {

            if (Reasons == null) return false;

            return (Reasons.Exists(f =>
                f.GetType() == reason.GetType()));

        }

    }

    /// <summary>
    /// A list of workflow actions that can be accessed by name
    /// or index
    /// </summary>
    public class ActionList : Dictionary<string, WorkflowAction>
    {

        /// <summary>
        /// Adds the specified action to the list
        /// </summary>
        /// <param name="name">The name of the action to add</param>
        /// <returns>The newly created <see cref="WorkflowAction" /></returns>
        public WorkflowAction Add(string name)
        {
            WorkflowAction action = new WorkflowAction() { Name = name };
            Add(name, action);
            return action;
        }

        /// <summary>
        /// Adds a range of actions to the list
        /// </summary>
        /// <param name="names">The names of the actions to add</param>
        public void AddRange(IEnumerable<string> names)
        {
            if (names == null) return;
            foreach (string name in names)
                Add(name);
        }

        /// <summary>
        /// Changes the state of all actions in the list to denied
        /// and applied the specified reason
        /// </summary>
        /// <param name="reason">The reason the action is denied</param>
        public void Deny(ServiceFault reason)
        {
            foreach (WorkflowAction action in this.Values)
                action.Deny(reason);
        }

        /// <summary>
        /// Changes the state of all actions in the list to denied
        /// and applied the specified reasons
        /// </summary>
        /// <param name="reasons">The reasons the action is denied</param>
        public void Deny(IEnumerable<ServiceFault> reasons)
        {
            foreach (WorkflowAction action in this.Values)
                action.Deny(reasons);
        }

        /// <summary>
        /// Changes the state of all actions in the list to allowed,
        /// regardless of whether they are currently denied
        /// </summary>
        public void Allow()
        {
            foreach (WorkflowAction action in this.Values)
                action.Allow();
        }

        /// <summary>
        /// Changes the state of all actions in the list to allowed,
        /// if and only if they have not previously been denied for
        /// some reason
        /// </summary>
        public void AllowIfNoReasons()
        {
            foreach (WorkflowAction action in this.Values)
                action.AllowIfNoReasons();
        }

        /// <summary>
        /// Changes the state of the specified actions to denied
        /// </summary>
        /// <param name="reason">The reason the actions are being denied</param>
        /// <param name="actions">The names of the actions to deny</param>
        public void Deny(ServiceFault reason, params string[] actions)
        {
            foreach (string action in actions)
            {
                if (this.ContainsKey(action))
                    this[action].Deny(reason);
            }
        }

        /// <summary>
        /// Changes the state of the specified actions to denied
        /// </summary>
        /// <param name="reasons">The reasons the actions are being denied</param>
        /// <param name="actions">The names of the actions to deny</param>
        public void Deny(IEnumerable<ServiceFault> reasons, params string[] actions)
        {
            foreach (string action in actions)
            {
                if (this.ContainsKey(action))
                    this[action].Deny(reasons);
            }
        }

        /// <summary>
        /// Changes the state of the specified actions to allowed,
        /// regardless of whether they are currently denied.
        /// </summary>
        /// <param name="actions">The names of the actions to allow</param>
        public void Allow(params string[] actions)
        {
            foreach (string action in actions)
            {
                if (this.ContainsKey(action))
                    this[action].Allow();
            }
        }

        /// <summary>
        /// Changes the state of the specified actions to allowed,
        /// if and only if they have not been denied for some reason.
        /// </summary>
        /// <param name="actions">The names of the actions to allow</param>
        public void AllowIfNoReasons(params string[] actions)
        {
            foreach (string action in actions)
            {
                if (this.ContainsKey(action))
                    this[action].AllowIfNoReasons();
            }
        }

        /// <summary>
        /// Denies the action if the specified test returns false.
        /// </summary>
        /// <param name="test">The test.</param>
        /// <param name="actions">The actions.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool Assert(Assertion test, params string[] actions)
        {

            if (!test.Test)
            {

                foreach (string action in actions)
                {
                    if (this.ContainsKey(action))
                    {
                        this[action].Deny(new ServiceFault()
                        {
                            Source = test.Source,
                            Message = test.Message,
                            IsLocalized = test.IsLocalized,
                            FaultCode = test.FaultCode
                        });
                    }
                }

            }

            return test.Test;

        }

        /// <summary>
        /// Denies the action if the specified test returns false.
        /// </summary>
        /// <param name="test">if set to <c>true</c> [test].</param>
        /// <param name="faultCode">The fault code.</param>
        /// <param name="actions">The actions.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool Assert(bool test, decimal faultCode, params string[] actions)
        {

            if (!test)
            {

                foreach (string action in actions)
                {
                    if (this.ContainsKey(action))
                    {
                        this[action].Deny(new ServiceFault()
                        {
                            Source = string.Empty,
                            Message = string.Empty,
                            IsLocalized = false,
                            FaultCode = faultCode
                        });
                    }
                }

            }

            return test;

        }

        /// <summary>
        /// Returns true if the requested action is currently allowed
        /// </summary>
        /// <param name="action">The name of the action to check</param>
        /// <returns>True if the action is currently allowed,
        /// otherwise false.</returns>
        public bool IsAllowed(string action)
        {
            if (!this.ContainsKey(action)) return false;
            return this[action].Status == ActionStatus.Allow;
        }

        /// <summary>
        /// Returns true if the requested action is currently denied
        /// </summary>
        /// <param name="action">The name of the action to check</param>
        /// <returns>True if the action is currently denied,
        /// otherwise false.</returns>
        public bool IsDenied(string action)
        {
            if (!this.ContainsKey(action)) return true;
            return this[action].Status == ActionStatus.Deny;
        }

        /// <summary>
        /// Checks the list to see if it contains any of the actions
        /// in another list.
        /// </summary>
        /// <param name="actions">The list of actions to search for</param>
        /// <returns>True if any one of the items is found</returns>
        public bool ContainsAnyKey(params string[] actions)
        {

            foreach (string action in actions)
            {
                if (this.ContainsKey(action)) return true;
            }

            return false;

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ActionList"/> class.
        /// </summary>
        public ActionList() { }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:System.Collections.Generic.Dictionary`2" /> class that is empty, has the specified initial capacity, and uses the default equality comparer for the key type.
        /// </summary>
        /// <param name="capacity">The initial number of elements that the <see cref="T:System.Collections.Generic.Dictionary`2" /> can contain.</param>
        public ActionList(int capacity) : base(capacity) { }

        /// <summary>
        /// Initializes a new instance of the <see cref="ActionList"/> class.
        /// </summary>
        /// <param name="dictionary">The dictionary.</param>
        public ActionList(IDictionary<string, WorkflowAction> dictionary) : base(dictionary) { }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:System.Collections.Generic.Dictionary`2" /> class with serialized data.
        /// </summary>
        /// <param name="info">A <see cref="T:System.Runtime.Serialization.SerializationInfo" /> object containing the information required to serialize the <see cref="T:System.Collections.Generic.Dictionary`2" />.</param>
        /// <param name="context">A <see cref="T:System.Runtime.Serialization.StreamingContext" /> structure containing the source and destination of the serialized stream associated with the <see cref="T:System.Collections.Generic.Dictionary`2" />.</param>
        public ActionList(SerializationInfo info, StreamingContext context) : base(info, context) { }

    }

    /// <summary>
    /// Enum ActionStatus
    /// </summary>
    [DataContract]
    public enum ActionStatus
    {

        /// <summary>
        /// The deny
        /// </summary>
        [EnumMember]
        Deny = 0,

        /// <summary>
        /// The allow
        /// </summary>
        [EnumMember]
        Allow = 1

    }
}
