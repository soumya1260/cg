﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="Assertion.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Enum AssertOption
    /// </summary>
    public enum AssertOption
    {
        /// <summary>
        /// The inherit
        /// </summary>
        Inherit = 0,
        /// <summary>
        /// The errors asynchronous warnings
        /// </summary>
        ErrorsAsWarnings = 1
    }

    /// <summary>
    /// Describes a test that is used for request validation.
    /// Used in conjunction with <see cref="HSServiceContext.Assert" />
    /// </summary>
    public class Assertion
    {

        /// <summary>
        /// The condition to test
        /// </summary>
        /// <value><c>true</c> if test; otherwise, <c>false</c>.</value>
        public bool Test { get; set; }

        /// <summary>
        /// The source of the error
        /// </summary>
        /// <value>The source.</value>
        public string Source { get; set; }

        /// <summary>
        /// The error message to use if the test fails
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; set; }

        /// <summary>
        /// The fault code to use if the test fails
        /// </summary>
        /// <value>The fault code.</value>
        public decimal FaultCode { get; set; }

        /// <summary>
        /// The _is localized
        /// </summary>
        private bool _isLocalized = true;

        /// <summary>
        /// Whether the error message has been localized or not.
        /// </summary>
        /// <value><c>true</c> if this instance is localized; otherwise, <c>false</c>.</value>
        public bool IsLocalized
        {
            get
            {
                return _isLocalized;
            }
            set
            {
                _isLocalized = value;
            }
        }

    }
}
