﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : todd.merritt
// Created          : 12-15-2014
//
// Last Modified By : todd.merritt
// Last Modified On : 12-15-2014
// ***********************************************************************
// <copyright file="GeoCoordinate.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// This is a base GeoCoordinate class for re-use across various objects
    /// </summary>
    [DataContract]
    public class GeoCoordinate
    {

        /// <summary>
        /// Gets or sets the Latitude.
        /// </summary>
        /// <value>The Latitude of the GeoCoordinate.</value>
        [DataMember]
        public double Latitude { get; set; }

        /// <summary>
        /// Gets or sets the Longitude.
        /// </summary>
        /// <value>The Longitude of the GeoCoordinate.</value>
        [DataMember]
        public double Longitude { get; set; }
    }
}
