﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="ServiceRequest.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;


/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{


    /// <summary>
    /// Interface IHSRequest
    /// </summary>
    public interface IHSRequest
    {

        /// <summary>
        /// The ID of the user posting the request to the WCF service.
        /// Used for security and logging puposes.
        /// </summary>
        /// <value>The user unique identifier.</value>
       
        string UserID { get; set; }

        /// <summary>
        /// Bool that indicates if the request or assoiated response
        /// contains
        /// </summary>
        /// <value><c>true</c> if [contains npi i_ physical i_ data]; otherwise, <c>false</c>.</value>
       
        bool ContainsNPII_PHI_Data { get; set; }

        /// <summary>
        /// A string representing the guid or token of the requesting authority
        /// (Either a server or user or other entitiy)
        /// that can be used to authoritatively identify the sender)
        /// </summary>
        /// <value>The requesting authority unique identifier.</value>
        
        string RequestingAuthorityID { get; set; }
    }

    /// <summary>
    /// The base class for a request object that needs to be
    /// propogated across a WCF service interface
    /// </summary>
    [DataContract]
    public class ServiceRequest: IHSRequest
    {
        /// <summary>
        /// The ID of the user posting the request to the WCF service.
        /// Used for security and logging puposes.
        /// </summary>
        /// <value>The user unique identifier.</value>
        [DataMember]
        public string UserID { get; set; }

        /// <summary>
        /// Bool that indicates if the request or assoiated response
        /// contains
        /// </summary>
        /// <value><c>true</c> if [contains npi i_ physical i_ data]; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool ContainsNPII_PHI_Data { get; set; }

        /// <summary>
        /// A string representing the guid or token of the requesting authority
        /// (Either a server or user or other entitiy)
        /// that can be used to authoritatively identify the sender)
        /// </summary>
        /// <value>The requesting authority unique identifier.</value>
        [DataMember]
        public string RequestingAuthorityID { get; set; }
    }

    /// <summary>
    /// A <see cref="ServiceRequest" /> that is only responsible for
    /// transporting one business object across the service layer.
    /// </summary>
    /// <typeparam name="ItemType">The type of the item type.</typeparam>
    [DataContract]
    public class ServiceRequest<ItemType> : ServiceRequest
    {
        /// <summary>
        /// Gets or sets the item.
        /// </summary>
        /// <value>The item.</value>
        [DataMember]
        public ItemType Item { get; set; }
    }

}
