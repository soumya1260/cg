﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="WorkflowActionRequest.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{

    /// <summary>
    /// Used to request the list of workflow actions that are
    /// currently valid for an object.
    /// </summary>
    [DataContract]
    public class WorkflowActionRequest : ServiceRequest
    {

        /// <summary>
        /// The (optional) list of actions to report on. If no
        /// actions are specified, then a list of every action
        /// that is currently valid for the object should be
        /// returned.
        /// </summary>
        /// <value>The actions automatic refresh.</value>
        [DataMember]
        public List<string> ActionsToRefresh { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowActionRequest"/> class.
        /// </summary>
        public WorkflowActionRequest()
        {
            ActionsToRefresh = new List<string>();
        }

    }

    /// <summary>
    /// Used to request the list of workflow actions that are
    /// currently valid for an object.
    /// </summary>
    /// <typeparam name="ItemType">The type of the item type.</typeparam>
    [DataContract]
    public class WorkflowActionRequest<ItemType> : ServiceRequest<ItemType>
    {

        /// <summary>
        /// The (optional) list of actions to report on. If no
        /// actions are specified, then a list of every action
        /// that is currently valid for the object should be
        /// returned.
        /// </summary>
        /// <value>The actions automatic refresh.</value>
        [DataMember]
        public List<string> ActionsToRefresh { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowActionRequest{ItemType}"/> class.
        /// </summary>
        public WorkflowActionRequest()
        {
            ActionsToRefresh = new List<string>();
        }
    }


}
