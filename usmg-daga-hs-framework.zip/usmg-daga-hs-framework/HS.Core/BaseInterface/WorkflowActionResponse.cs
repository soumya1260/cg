﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="WorkflowActionResponse.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Contains the list of workflow actions (Edit, Save, Copy, etc...)
    /// that are valid for the requested object based on its current state.
    /// </summary>
    [DataContract]
    public class WorkflowActionResponse : ServiceResponse
    {

        /// <summary>
        /// Gets or sets the actions.
        /// </summary>
        /// <value>The actions.</value>
        [DataMember]
        public ActionList Actions { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowActionResponse"/> class.
        /// </summary>
        public WorkflowActionResponse()
        {
            Actions = new ActionList();
        }

    }
}
