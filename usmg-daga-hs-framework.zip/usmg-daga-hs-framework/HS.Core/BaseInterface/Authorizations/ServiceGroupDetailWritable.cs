﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="ServiceGroupDetailWritable.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Runtime.Serialization;
using HS.Interfaces.SVC.Lookups;

/// <summary>
/// The Authorizations namespace.
/// </summary>
namespace HS.Interfaces.SVC.Authorizations
{
    /// <summary>
    /// Class ServiceGroupDetailWritable.
    /// </summary>
    [DataContract]
    public class ServiceGroupDetailWritable:ServiceGroupDetail
    {
        /// <summary>
        /// Gets or sets the modified configuration.
        /// </summary>
        /// <value>The modified configuration.</value>
        [DataMember]
        public DateTime ModifiedOn { get; set; }
        /// <summary>
        /// Gets or sets the modified by.
        /// </summary>
        /// <value>The modified by.</value>
        [DataMember]
        public string ModifiedBy { get; set; }
        /// <summary>
        /// Gets or sets the modified by display.
        /// </summary>
        /// <value>The modified by display.</value>
        [DataMember]
        public string ModifiedByDisplay { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is deleted.
        /// </summary>
        /// <value><c>true</c> if this instance is deleted; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool IsDeleted { get; set; }

    }
}
