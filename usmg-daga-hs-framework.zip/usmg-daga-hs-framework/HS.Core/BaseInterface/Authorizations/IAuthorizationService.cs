﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="IAuthorizationService.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.ServiceModel;

/// <summary>
/// The Authorizations namespace.
/// </summary>
namespace HS.Interfaces.SVC.Authorizations
{
    /// <summary>
    /// Interface IAuthorizationService
    /// </summary>
    [ServiceContract]
    public interface IAuthorizationService
    {
        /// <summary>
        /// Saves the service group detail.
        /// </summary>
        /// <param name="detail">The detail.</param>
        [OperationContract]
        void SaveServiceGroupDetail(HSRequest<ServiceGroupDetailWritable> detail);
    }
}
