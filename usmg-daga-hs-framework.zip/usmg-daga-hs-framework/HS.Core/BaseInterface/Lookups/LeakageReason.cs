﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="LeakageReason.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Class LeakageReason.
    /// </summary>
    [DataContract]
    public class LeakageReason
    {
        /// <summary>
        /// Gets or sets the leakage reason code.
        /// </summary>
        /// <value>The leakage reason code.</value>
        [DataMember]
        public string LeakageReasonCode { get; set; }
        /// <summary>
        /// Gets or sets the leakage reason description.
        /// </summary>
        /// <value>The leakage reason description.</value>
        [DataMember]
        public string LeakageReasonDesc { get; set; }
    }
}
