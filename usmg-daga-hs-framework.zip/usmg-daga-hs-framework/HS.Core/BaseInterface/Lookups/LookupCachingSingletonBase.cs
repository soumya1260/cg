﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="LookupCachingSingletonBase.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;

/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Class LookupCachingSingletonBase.
    /// </summary>
    public abstract class LookupCachingSingletonBase
    {


        /// <summary>
        /// The _ QNXT diagnosis codes
        /// </summary>
        private List<DiagnosisCode> _QNXTDiagnosisCodes;
        /// <summary>
        /// The _ bidw diagnosis codes
        /// </summary>
        private List<DiagnosisCode> _BIDWDiagnosisCodes;
        /// <summary>
        /// The _ QNXT specialty codes
        /// </summary>
        private List<SpecialtyCode> _QNXTSpecialtyCodes;
        /// <summary>
        /// The _ bidw specialty codes
        /// </summary>
        private List<SpecialtyCode> _BIDWSpecialtyCodes;
        /// <summary>
        /// The _ QNXT procedure codes
        /// </summary>
        private List<ProcedureCode> _QNXTProcedureCodes;
        /// <summary>
        /// The _ bidw procedure codes
        /// </summary>
        private List<ProcedureCode> _BIDWProcedureCodes;
        /// <summary>
        /// The _ leakage reasons
        /// </summary>
        private List<LeakageReason> _LeakageReasons;
        /// <summary>
        /// The _ place of service codes
        /// </summary>
        private List<ServiceCode> _PlaceOfServiceCodes;
        /// <summary>
        /// The _ service types
        /// </summary>
        private List<ServiceType> _ServiceTypes;
        /// <summary>
        /// The _ unit types
        /// </summary>
        private List<UnitType> _UnitTypes;


        /// <summary>
        /// The _func diagnosis codes
        /// </summary>
        protected Func<DiagnosisCodesEnum, List<DiagnosisCode>> _funcDiagnosisCodes;
        /// <summary>
        /// The _func specialty codes
        /// </summary>
        protected Func<SpecialtyCodesEnum, List<SpecialtyCode>> _funcSpecialtyCodes;
        /// <summary>
        /// The _func procedure codes
        /// </summary>
        protected Func<ProcedureCodesEnum, List<ProcedureCode>> _funcProcedureCodes;
        /// <summary>
        /// The _func leakage reasons
        /// </summary>
        protected Func<List<LeakageReason>> _funcLeakageReasons;
        /// <summary>
        /// The _func place of service codes
        /// </summary>
        protected Func<List<ServiceCode>> _funcPlaceOfServiceCodes;
        /// <summary>
        /// The _func service types
        /// </summary>
        protected Func<List<ServiceType>> _funcServiceTypes;
        /// <summary>
        /// The _func unit types
        /// </summary>
        protected Func<List<UnitType>> _funcUnitTypes;

        /// <summary>
        /// The _last refreshed
        /// </summary>
        private DateTime _lastRefreshed;

        /// <summary>
        /// Gets the QNXT diagnosis codes.
        /// </summary>
        /// <value>The QNXT diagnosis codes.</value>
        public List<DiagnosisCode> QNXTDiagnosisCodes
        {
            get
            {
                CheckRefresh();

                return _QNXTDiagnosisCodes;
            }
        }

        /// <summary>
        /// Gets the bidw diagnosis codes.
        /// </summary>
        /// <value>The bidw diagnosis codes.</value>
        public List<DiagnosisCode> BIDWDiagnosisCodes
        {
            get
            {
                CheckRefresh();

                return _BIDWDiagnosisCodes;
            }
        }

        /// <summary>
        /// Gets the QNXT specialty codes.
        /// </summary>
        /// <value>The QNXT specialty codes.</value>
        public List<SpecialtyCode> QNXTSpecialtyCodes
        {
            get
            {
                CheckRefresh();

                return _QNXTSpecialtyCodes;
            }
        }

        /// <summary>
        /// Gets the bidw specialty codes.
        /// </summary>
        /// <value>The bidw specialty codes.</value>
        public List<SpecialtyCode> BIDWSpecialtyCodes
        {
            get
            {
                CheckRefresh();

                return _BIDWSpecialtyCodes;
            }
        }

        /// <summary>
        /// Gets the QNXT procedure codes.
        /// </summary>
        /// <value>The QNXT procedure codes.</value>
        public List<ProcedureCode> QNXTProcedureCodes
        {
            get
            {
                CheckRefresh();

                return _QNXTProcedureCodes;
            }
        }

        /// <summary>
        /// Gets the bidw procedure codes.
        /// </summary>
        /// <value>The bidw procedure codes.</value>
        public List<ProcedureCode> BIDWProcedureCodes
        {
            get
            {
                CheckRefresh();

                return _BIDWProcedureCodes;
            }
        }

        /// <summary>
        /// Gets the leakage reasons.
        /// </summary>
        /// <value>The leakage reasons.</value>
        public List<LeakageReason> LeakageReasons
        {
            get
            {
                return _LeakageReasons;
            }
        }

        /// <summary>
        /// Gets the place of service codes.
        /// </summary>
        /// <value>The place of service codes.</value>
        public List<ServiceCode> PlaceOfServiceCodes 
        {
            get
            {
                return _PlaceOfServiceCodes;
            }
        }

        /// <summary>
        /// Gets the service types.
        /// </summary>
        /// <value>The service types.</value>
        public List<ServiceType> ServiceTypes {
            get
            {
                return _ServiceTypes;
            }
        
        }

        /// <summary>
        /// Gets the unit types.
        /// </summary>
        /// <value>The unit types.</value>
        public List<UnitType> UnitTypes {
            get
            {
                return _UnitTypes;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LookupCachingSingletonBase"/> class.
        /// </summary>
        protected LookupCachingSingletonBase()
        {
            InitializeClass();
        }

        /// <summary>
        /// Initializes the class.
        /// </summary>
        protected virtual void InitializeClass()
        {
            //Initialize the class
            _lastRefreshed = DateTime.MinValue;

            _QNXTDiagnosisCodes = new List<DiagnosisCode>();
            _BIDWDiagnosisCodes = new List<DiagnosisCode>();
            _QNXTSpecialtyCodes = new List<SpecialtyCode>();
            _BIDWSpecialtyCodes = new List<SpecialtyCode>();
            _QNXTProcedureCodes = new List<ProcedureCode>();
            _BIDWProcedureCodes = new List<ProcedureCode>();
            _LeakageReasons = new List<LeakageReason>();
            _PlaceOfServiceCodes = new List<ServiceCode>();
            _ServiceTypes = new List<ServiceType>();
            _UnitTypes = new List<UnitType>();


            CheckRefresh();
        }

        /// <summary>
        /// Occurs when [refreshing].
        /// </summary>
        protected event EventHandler<EventArgs> Refreshing;

        /// <summary>
        /// Checks the refresh.
        /// </summary>
        protected void CheckRefresh()
        {
            if (DateTime.Now.Subtract(_lastRefreshed) >= new TimeSpan(0, 24, 0, 0))
            {

                IAsyncResult qnxtProcCodeFuncPointer = _funcProcedureCodes.BeginInvoke(ProcedureCodesEnum.QNXT, null, null);

                IAsyncResult bidwProcCodeFuncPointer = _funcProcedureCodes.BeginInvoke(ProcedureCodesEnum.BIDW, null, null);

                IAsyncResult qnxtDiagCodeFuncPointer = _funcDiagnosisCodes.BeginInvoke(DiagnosisCodesEnum.QNXT, null, null);

                IAsyncResult bidwDiagCodeFuncPointer = _funcDiagnosisCodes.BeginInvoke(DiagnosisCodesEnum.BIDW, null, null);

                IAsyncResult qnxtSpecCodeFuncPointer = _funcSpecialtyCodes.BeginInvoke(SpecialtyCodesEnum.QNXT, null, null);

                IAsyncResult bidwSpecCodeFuncPointer = _funcSpecialtyCodes.BeginInvoke(SpecialtyCodesEnum.BIDW, null, null);

                IAsyncResult allLeakageReasonsFuncPointer = _funcLeakageReasons.BeginInvoke(null, null);

                IAsyncResult allPlacesOfServiceFuncPointer = _funcPlaceOfServiceCodes.BeginInvoke(null, null);

                IAsyncResult allServiceTypesFuncPointer = _funcServiceTypes.BeginInvoke(null, null);

                IAsyncResult allUnitTypesFuncPointer = _funcUnitTypes.BeginInvoke(null, null);

                _QNXTDiagnosisCodes = _funcDiagnosisCodes.EndInvoke(qnxtDiagCodeFuncPointer);

                _BIDWDiagnosisCodes = _funcDiagnosisCodes.EndInvoke(bidwDiagCodeFuncPointer);

                _QNXTSpecialtyCodes = _funcSpecialtyCodes.EndInvoke(qnxtSpecCodeFuncPointer);

                _BIDWSpecialtyCodes = _funcSpecialtyCodes.EndInvoke(bidwSpecCodeFuncPointer);

                _LeakageReasons = _funcLeakageReasons.EndInvoke(allLeakageReasonsFuncPointer);

                _PlaceOfServiceCodes = _funcPlaceOfServiceCodes.EndInvoke(allPlacesOfServiceFuncPointer);

                _ServiceTypes = _funcServiceTypes.EndInvoke(allServiceTypesFuncPointer);

                _UnitTypes = _funcUnitTypes.EndInvoke(allUnitTypesFuncPointer);

                _QNXTProcedureCodes = _funcProcedureCodes.EndInvoke(qnxtProcCodeFuncPointer);

                _BIDWProcedureCodes = _funcProcedureCodes.EndInvoke(bidwProcCodeFuncPointer);

                if (Refreshing != null)
                {
                    Refreshing(this, EventArgs.Empty);
                }

                _lastRefreshed = DateTime.Now;
            }

        }

        /// <summary>
        /// Invalidates this instance.
        /// </summary>
        public void Invalidate()
        {
            _lastRefreshed = DateTime.MinValue;
        }
    }
}
