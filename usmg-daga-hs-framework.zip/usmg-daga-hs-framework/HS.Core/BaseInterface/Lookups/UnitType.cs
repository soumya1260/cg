﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="UnitType.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Class UnitType.
    /// </summary>
    [DataContract]
    public class UnitType
    {
        /// <summary>
        /// Gets or sets the unit type code.
        /// </summary>
        /// <value>The unit type code.</value>
        [DataMember]
        public string UnitTypeCode { get; set; }
        /// <summary>
        /// Gets or sets the unit type description.
        /// </summary>
        /// <value>The unit type description.</value>
        [DataMember]
        public string UnitTypeDescription { get; set; }
    }
}
