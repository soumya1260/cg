﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="ServiceGroupDetail.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Class ServiceGroupDetail.
    /// </summary>
    [DataContract]
    public class ServiceGroupDetail
    {
        /// <summary>
        /// Gets or sets the service group detail unique identifier.
        /// </summary>
        /// <value>The service group detail unique identifier.</value>
        [DataMember]
        public int ServiceGroupDetailId { get; set; }
        /// <summary>
        /// Gets or sets the service group detail key.
        /// </summary>
        /// <value>The service group detail key.</value>
        [DataMember]
        public string ServiceGroupDetailKey { get; set; }
        /// <summary>
        /// Gets or sets the service group detail description.
        /// </summary>
        /// <value>The service group detail description.</value>
        [DataMember]
        public string ServiceGroupDetailDescription { get; set; }
    }
}
