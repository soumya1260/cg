﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="SpecialtyCodeEnum.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Enum SpecialtyCodesEnum
    /// </summary>
    [DataContract]
    public enum SpecialtyCodesEnum
    {
        /// <summary>
        /// The bidw
        /// </summary>
        [EnumMember]
        BIDW,
        /// <summary>
        /// The QNXT
        /// </summary>
        [EnumMember]
        QNXT
    }
}
