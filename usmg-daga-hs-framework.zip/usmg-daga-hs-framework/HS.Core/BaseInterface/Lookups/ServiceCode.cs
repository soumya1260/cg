﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="ServiceCode.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Class ServiceCode.
    /// </summary>
    [DataContract]
    public class ServiceCode
    {
        /// <summary>
        /// Gets or sets the place of service code.
        /// </summary>
        /// <value>The place of service code.</value>
        [DataMember]
        public string PlaceOfServiceCode { get; set; }
        /// <summary>
        /// Gets or sets the place of service description.
        /// </summary>
        /// <value>The place of service description.</value>
        [DataMember]
        public string PlaceOfServiceDescription { get; set; }
    }
}
