﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="SpecialtyCode.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Class SpecialtyCode.
    /// </summary>
    [DataContract]
    public class SpecialtyCode
    {
        /// <summary>
        /// Gets or sets the specialty code key.
        /// </summary>
        /// <value>The specialty code key.</value>
        [DataMember]
        public int SpecialtyCodeKey { get; set; }
        /// <summary>
        /// Gets or sets the specialty code value.
        /// </summary>
        /// <value>The specialty code value.</value>
        [DataMember]
        public string SpecialtyCodeValue { get; set; }
        /// <summary>
        /// Gets or sets the specialty code description.
        /// </summary>
        /// <value>The specialty code description.</value>
        [DataMember]
        public string SpecialtyCodeDescription { get; set; }
    }
}
