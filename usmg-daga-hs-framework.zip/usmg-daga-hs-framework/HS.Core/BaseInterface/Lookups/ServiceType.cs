﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="ServiceType.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Class ServiceType.
    /// </summary>
    [DataContract]
    public class ServiceType
    {
        /// <summary>
        /// Gets or sets the service type code.
        /// </summary>
        /// <value>The service type code.</value>
        [DataMember]
        public string ServiceTypeCode { get; set; }
        /// <summary>
        /// Gets or sets the service type description.
        /// </summary>
        /// <value>The service type description.</value>
        [DataMember]
        public string ServiceTypeDescription { get; set; }
    }
}
