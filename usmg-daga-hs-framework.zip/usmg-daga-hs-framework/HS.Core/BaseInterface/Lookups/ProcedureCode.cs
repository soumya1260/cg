﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="ProcedureCode.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Class ProcedureCode.
    /// </summary>
    [DataContract]
    public class ProcedureCode
    {
        /// <summary>
        /// Gets or sets the procedure code key.
        /// </summary>
        /// <value>The procedure code key.</value>
        [DataMember]
        public long ProcedureCodeKey { get; set; }
        /// <summary>
        /// Gets or sets the procedure code value.
        /// </summary>
        /// <value>The procedure code value.</value>
        [DataMember]
        public string ProcedureCodeValue { get; set; }
        /// <summary>
        /// Gets or sets the procedure code description.
        /// </summary>
        /// <value>The procedure code description.</value>
        [DataMember]
        public string ProcedureCodeDescription { get; set; }
    }
}
