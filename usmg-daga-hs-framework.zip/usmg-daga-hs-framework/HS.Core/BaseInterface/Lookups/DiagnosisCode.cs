﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="DiagnosisCode.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;


/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Class DiagnosisCode.
    /// </summary>
    [DataContract]
    public class DiagnosisCode
    {
        /// <summary>
        /// Gets or sets the diagnosis code key.
        /// </summary>
        /// <value>The diagnosis code key.</value>
        [DataMember]
        public long DiagnosisCodeKey { get; set; }
        /// <summary>
        /// Gets or sets the diagnosis code value.
        /// </summary>
        /// <value>The diagnosis code value.</value>
        [DataMember]
        public string DiagnosisCodeValue { get; set; }
        /// <summary>
        /// Gets or sets the diagnosis code description.
        /// </summary>
        /// <value>The diagnosis code description.</value>
        [DataMember]
        public string DiagnosisCodeDescription { get; set; }
    }
}
