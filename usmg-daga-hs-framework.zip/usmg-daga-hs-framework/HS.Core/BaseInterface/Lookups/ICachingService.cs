﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-05-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="ICachingService.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using System.ServiceModel;

/// <summary>
/// The Lookups namespace.
/// </summary>
namespace HS.Interfaces.SVC.Lookups
{
    /// <summary>
    /// Interface ICachingService
    /// </summary>
    [ServiceContract]
    public interface ICachingService
    {
        /// <summary>
        /// Gets all diagnosis codes.
        /// </summary>
        /// <param name="Source">The source.</param>
        /// <returns>List{DiagnosisCode}.</returns>
        [OperationContract]
        List<DiagnosisCode> GetAllDiagnosisCodes(DiagnosisCodesEnum Source);

        /// <summary>
        /// Gets all specialty codes.
        /// </summary>
        /// <param name="Source">The source.</param>
        /// <returns>List{SpecialtyCode}.</returns>
        [OperationContract]
        List<SpecialtyCode> GetAllSpecialtyCodes(SpecialtyCodesEnum Source);

        /// <summary>
        /// Gets all procedure codes.
        /// </summary>
        /// <param name="Source">The source.</param>
        /// <returns>List{ProcedureCode}.</returns>
        [OperationContract]
        List<ProcedureCode> GetAllProcedureCodes(ProcedureCodesEnum Source);

        /// <summary>
        /// Gets all leakage reasons.
        /// </summary>
        /// <returns>List{LeakageReason}.</returns>
        [OperationContract]
        List<LeakageReason> GetAllLeakageReasons();

        /// <summary>
        /// Gets all place of service codes.
        /// </summary>
        /// <returns>List{ServiceCode}.</returns>
        [OperationContract]
        List<ServiceCode> GetAllPlaceOfServiceCodes();

        /// <summary>
        /// Gets all service types.
        /// </summary>
        /// <returns>List{ServiceType}.</returns>
        [OperationContract]
        List<ServiceType> GetAllServiceTypes();

        /// <summary>
        /// Gets all unit types.
        /// </summary>
        /// <returns>List{UnitType}.</returns>
        [OperationContract]
        List<UnitType> GetAllUnitTypes();

        /// <summary>
        /// Gets all service group details.
        /// </summary>
        /// <returns>HSListResponse{ServiceGroupDetail}.</returns>
        [OperationContract]
        HSListResponse<ServiceGroupDetail> GetAllServiceGroupDetails();


    }
}
