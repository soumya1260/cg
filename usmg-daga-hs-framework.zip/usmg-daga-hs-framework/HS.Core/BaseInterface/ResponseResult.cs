﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="ResponseResult.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Enum ResponseResult
    /// </summary>
    [DataContract]
    public enum ResponseResult
    {
        /// <summary>
        /// The not set
        /// </summary>
        [EnumMember]
        NotSet = 0,

        /// <summary>
        /// The error
        /// </summary>
        [EnumMember]
        Error = 1,

        /// <summary>
        /// The exception
        /// </summary>
        [EnumMember]
        Exception = 2,

        /// <summary>
        /// The success
        /// </summary>
        [EnumMember]
        Success = 3,

        /// <summary>
        /// The security violation
        /// </summary>
        [EnumMember]
        SecurityViolation = 4,

        /// <summary>
        /// The failure
        /// </summary>
        [EnumMember]
        Failure = 5
    }
}
