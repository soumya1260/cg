﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="HSRequest.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    




    /// <summary>
    /// Base class for all requests in the the application
    /// </summary>
    [DataContract]
    public class HSRequest : ServiceRequest
    {

       



    }

    /// <summary>
    /// Base class for all requests in the  application
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [DataContract]
    public class HSRequest<T> : ServiceRequest<T>
    {

       

    }

    /// <summary>
    /// Base class for all requests in the  application
    /// </summary>
    [DataContract]
    public class HSValidationRequest : ValidationRequest
    {

       


    }

    /// <summary>
    /// Base class for all requests in the  application
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [DataContract]
    public class HSListRequest<T> : ListRequest<T>
        where T : class
    {

       


    }

    
}
