﻿namespace HS
{
    public interface ILogConfig
    {
        
    }
}
