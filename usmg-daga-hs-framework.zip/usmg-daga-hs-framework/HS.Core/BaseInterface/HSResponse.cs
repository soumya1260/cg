﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="HSResponse.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;


/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{

    /// <summary>
    /// Base class for all response objects in the HS application
    /// </summary>
    [DataContract]
    public class HSResponse : ServiceResponse
    {
        /// <summary>
        /// Bool that indicates if the request or assoiated response
        /// contains
        /// </summary>
        /// <value><c>true</c> if [contains npi i_ physical i_ data]; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool ContainsNPII_PHI_Data { get; set; }

    }

    /// <summary>
    /// Base class for all response objects in the HS application
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [DataContract]
    public class HSResponse<T> : ServiceResponse<T>
    {
        /// <summary>
        /// Bool that indicates if the request or assoiated response
        /// contains
        /// </summary>
        /// <value><c>true</c> if [contains npi i_ physical i_ data]; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool ContainsNPII_PHI_Data { get; set; }

    }

    /// <summary>
    /// Base class for all response objects in the HS application
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [DataContract]
    public class HSListResponse<T> : ListResponse<T>
    {
        /// <summary>
        /// Bool that indicates if the request or assoiated response
        /// contains
        /// </summary>
        /// <value><c>true</c> if [contains npi i_ physical i_ data]; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool ContainsNPII_PHI_Data { get; set; }

    }

    /// <summary>
    /// Base class for all response objects in the HS application
    /// </summary>
    [DataContract]
    public class HSValidationResponse : ValidationResponse
    {
        /// <summary>
        /// Bool that indicates if the request or assoiated response
        /// contains
        /// </summary>
        /// <value><c>true</c> if [contains npi i_ physical i_ data]; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool ContainsNPII_PHI_Data { get; set; }

    }

    /// <summary>
    /// Base class for all response objects in the HS application
    /// </summary>
    [DataContract]
    public class HSWorkflowActionResponse : WorkflowActionResponse
    {
        /// <summary>
        /// Bool that indicates if the request or assoiated response
        /// contains
        /// </summary>
        /// <value><c>true</c> if [contains npi i_ physical i_ data]; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool ContainsNPII_PHI_Data { get; set; }

    }

}
