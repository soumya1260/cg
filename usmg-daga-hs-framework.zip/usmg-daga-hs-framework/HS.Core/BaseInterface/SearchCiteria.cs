﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="SearchCiteria.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.Serialization;

using HS.Linq;


/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Class used to add filtering, paging and sorting to a
    /// list
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [DataContract]
    public class SearchCriteria<T> where T : class
    {

        /// <summary>
        /// The size of the page to return. Values less than or
        /// equal to zero will return all items.
        /// </summary>
        /// <value>The size of the page.</value>
        [DataMember]
        public int PageSize { get; set; }

        /// <summary>
        /// The page number to return.
        /// </summary>
        /// <value>The page number.</value>
        [DataMember]
        public int PageNumber { get; set; }

        /// <summary>
        /// The sort order (Ascending or descending)
        /// </summary>
        /// <value>The sort order.</value>
        [DataMember]
        public SortOrder SortOrder { get; set; }

        /// <summary>
        /// The field to sort by.
        /// </summary>
        /// <value>The sort expression.</value>
        /// <remarks><para>Use null or <seealso cref="String.Empty" /> to
        /// return the items unsorted.</para>
        ///   <para>The default implementation of <seealso cref="ApplySorting" />
        /// expects the SortExpression to be the name of a public field or
        /// property of type <typeparam name="T">T</typeparam>.</para></remarks>
        [DataMember]
        public string SortExpression { get; set; }

        /// <summary>
        /// The text for search for.
        /// </summary>
        /// <value>The filter text.</value>
        /// <remarks><para>Use null or <seealso cref="String.Empty" /> to
        /// return all items.</para>
        ///   <para>The default implementation of <seealso cref="ApplySearchText" />
        /// searches all public fields and properties of the object
        /// type <typeparam name="T">T</typeparam>.</para></remarks>
        [DataMember]
        public string FilterText { get; set; }

        /// <summary>
        /// The search conditions to apply
        /// </summary>
        /// <value>The search conditions.</value>
        [DataMember]
        public List<SearchCondition> SearchConditions { get; set; }

        /// <summary>
        /// Adds a clause to the specified query which sorts the
        /// results by the specified <see cref="SortExpression" />
        /// </summary>
        /// <param name="query">the query to append to</param>
        /// <returns>The modified query</returns>
        /// <remarks>Inheriting classes could overload this method
        /// if they are using the database to sort instead of
        /// using Linq.</remarks>
        public IQueryable<T> ApplySorting(IQueryable<T> query)
        {

            var tmp = query;

            if (!string.IsNullOrEmpty(SortExpression))
            {
                tmp = tmp.OrderBy(SortExpression, SortOrder);
            }

            return tmp;

        }

        /// <summary>
        /// Adds a clause to the specified query so that it
        /// returns only the current page
        /// </summary>
        /// <param name="query">The query to append to</param>
        /// <returns>The modified query</returns>
        /// <remarks>Inheriting classes could overload this method
        /// if they are using the database to page instead of
        /// using Linq.</remarks>
        public IQueryable<T> ApplyPaging(IQueryable<T> query)
        {

            var tmp = query;

            if (PageSize > 0)
            {
                tmp = tmp.Skip((PageNumber - 1) * PageSize).Take(PageSize);
            }

            return tmp;

        }

        /// <summary>
        /// Adds a clause to the speicifed query which searches the
        /// public fields and properties for the specified
        /// <see cref="SearchConditions" />.
        /// </summary>
        /// <param name="query">The query to append to</param>
        /// <returns>The modified query</returns>
        /// <remarks><para>Inheriting classes can override this
        /// method if they need to restrict the list of columns
        /// to search through.</para>
        ///   <para>Inheriting classes could overload this method
        /// if they are using the database to search instead of
        /// using Linq.</para></remarks>
        public virtual IQueryable<T> ApplyFilter(IQueryable<T> query)
        {

            var q = query;

            if (SearchConditions != null &&
                SearchConditions.Count > 0)
            {

                var q2 = query.Cast<object>();

                Expression<Func<object, bool>> filterExpression = GetFilterExpression();

                if (filterExpression != null)
                {
                    q2 = q2.Where(filterExpression.Compile()).AsQueryable();
                }

                q = q2.Cast<T>();

            }

            if (!string.IsNullOrEmpty(FilterText))
            {

                ParameterExpression parameterExpression = Expression.Parameter(typeof(T), "t");
                List<Expression> expressions = new List<Expression>();
                MethodInfo containsMethod = typeof(string).GetMethod("Contains", new Type[] { typeof(string) });
                MethodInfo toStringMethod = typeof(object).GetMethod("ToString");

                foreach (PropertyInfo property in typeof(T).GetProperties())
                {

                    expressions.Add
                    (
                        Expression.Call
                        (
                            Expression.Condition
                            (
                                Expression.Equal
                                (
                                    Expression.Convert
                                    (
                                        Expression.Property
                                        (
                                            parameterExpression,
                                            property.Name
                                        ),
                                        typeof(object)
                                    ),
                                    Expression.Constant(null)
                                ),
                                Expression.Constant(string.Empty),
                                Expression.Call
                                (
                                    Expression.Property
                                    (
                                        parameterExpression,
                                        property.Name
                                    ),
                                    toStringMethod
                                )
                            ),
                            containsMethod,
                            Expression.Constant(this.FilterText)
                        )
                    );

                }

                Expression orExpression = null;

                foreach (Expression e in expressions)
                {
                    if (orExpression == null)
                        orExpression = e;
                    else
                        orExpression = Expression.OrElse(orExpression, e);
                }

                if (orExpression != null)
                {

                    Expression<Func<T, bool>> lambda =
                        Expression.Lambda<Func<T, bool>>(
                            orExpression, parameterExpression);

                    Func<T, bool> func = lambda.Compile();

                    q = q.Where(func).AsQueryable();

                }

            }

            return q;

        }

        /// <summary>
        /// Parses the requested parameters and returns a corresponding
        /// LINQ expression
        /// </summary>
        /// <param name="field">The field to search</param>
        /// <param name="op">The operation to apply to the field and value</param>
        /// <param name="value">The value to search for</param>
        /// <param name="not">Whether to negate the expression</param>
        /// <param name="type">The type.</param>
        /// <param name="paramEx">The parameter that serves as input to the expression</param>
        /// <returns>The requested LINQ expression</returns>
        protected Expression GetFilterExpression(string field, Operator op, string value, bool not, DbType type, ParameterExpression paramEx)
        {

            // If the user didn't enter anything, return a null expression
            if (string.IsNullOrEmpty(value)) return null;

            DbType expressionType = type;

            // If the operation is "Contains", or if the column is generated
            // by a Lambda expression, treat the compare value like a string
            if (op == Operator.Contains ||
                op == Operator.StartsWith ||
                type == DbType.String ||
                type == DbType.StringFixedLength ||
                type == DbType.AnsiString ||
                type == DbType.AnsiStringFixedLength ||
                type == DbType.Guid ||
                type == DbType.Object ||
                type == DbType.Xml)
                expressionType = DbType.String;

            // This contains the expression which returns the value of the
            // specified column from the current row in the data source
            Expression valueEx = null;

            #region Create the expression which returns the current value from the current row

            #region Create the function to query the property value

            //Note that because this is used in the lambda expressions
            //down below, it stays in scope as long as they do.
            PropertyInfo pi = typeof(T).GetProperty(field);

            // Create a function to return the current value of the 
            // requested column of the current row. Unfortunately, 
            // late binding isn't allowed in LINQ expressions so we 
            // have to get the value using Reflection and manually
            // cast it to the correct data type. If it's a string
            // (or it's being treated as one) the conversion takes
            // place after the value has been retrieved (see the
            // end of this switch block)
            switch (expressionType)
            {
                case DbType.String:
                    {
                        Expression<Func<object, object>> func = ((object o) => pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Boolean:
                    {
                        Expression<Func<object, bool>> func = ((object o) => (bool)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Byte:
                case DbType.SByte:
                    {
                        Expression<Func<object, byte>> func = ((object o) => (byte)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Currency:
                case DbType.Decimal:
                    {
                        Expression<Func<object, decimal>> func = ((object o) => (decimal)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Date:
                    {
                        Expression<Func<object, DateTime>> func = ((object o) => ((DateTime)pi.GetValue(o, null)).Date);
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.DateTime:
                case DbType.DateTime2:
                    {
                        Expression<Func<object, DateTime>> func = ((object o) => (DateTime)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Time:
                    {
                        Expression<Func<object, long>> func = ((object o) => ((DateTime)pi.GetValue(o, null)).TimeOfDay.Ticks);
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.DateTimeOffset:
                    {
                        Expression<Func<object, TimeSpan>> func = ((object o) => (TimeSpan)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Double:
                case DbType.VarNumeric:
                    {
                        Expression<Func<object, double>> func = ((object o) => (double)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Int16:
                    {
                        Expression<Func<object, short>> func = ((object o) => (short)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Int32:
                    {
                        Expression<Func<object, int>> func = ((object o) => (int)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Int64:
                    {
                        Expression<Func<object, long>> func = ((object o) => (long)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.Single:
                    {
                        Expression<Func<object, float>> func = ((object o) => (float)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.UInt16:
                    {
                        Expression<Func<object, ushort>> func = ((object o) => (ushort)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.UInt32:
                    {
                        Expression<Func<object, uint>> func = ((object o) => (uint)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
                case DbType.UInt64:
                    {
                        Expression<Func<object, ulong>> func = ((object o) => (ulong)pi.GetValue(o, null));
                        valueEx = func.Body.ReplaceParameters(paramEx);
                        break;
                    }
            }

            #endregion

            // If the expression returns a string - or if we're forcing it
            // to return one - add a "ToString" to it.
            if (expressionType == DbType.String)
            {
                valueEx =
                    Expression.Call(
                        Expression.Call(valueEx, "ToString", null, null),
                            "ToUpper", null, null);
            }

            #endregion

            // This expression contains the value were searching for
            ConstantExpression valueToCompareEx = null;

            #region Create the expression which returns the value to search for (and validate it's datatype)

            // Create a ConstantExpression which contains the value to
            // search for. Since the comparison is type checked, we 
            // also have to cast it to the correct type. If the user
            // entered an invalid value for that type, though, we
            // show an error here and bail out
            //
            // TODO: We may want to change this so that instead of throwing
            // we force the expression to a string comparison. This might
            // be a little more user friendly
            switch (expressionType)
            {
                case DbType.String:
                    {
                        valueToCompareEx = Expression.Constant(value.ToUpper());
                        break;
                    }
                case DbType.Boolean:
                    {

                        bool x = bool.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.Byte:
                case DbType.SByte:
                    {

                        byte x = byte.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.Currency:
                case DbType.Decimal:
                    {

                        decimal x = decimal.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.Date:
                    {

                        DateTime x = DateTime.Parse(value);

                        valueToCompareEx = Expression.Constant(x.Date);

                        break;

                    }
                case DbType.DateTime:
                case DbType.DateTime2:
                    {

                        DateTime x = DateTime.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.Time:
                    {

                        DateTime x = DateTime.Parse(value);

                        valueToCompareEx = Expression.Constant(x.TimeOfDay.Ticks);

                        break;

                    }
                case DbType.DateTimeOffset:
                    {

                        TimeSpan x = TimeSpan.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.Double:
                case DbType.VarNumeric:
                    {

                        double x = double.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.Int16:
                    {

                        short x = short.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.Int32:
                    {

                        int x = int.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.Int64:
                    {

                        long x = long.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.Single:
                    {

                        float x = float.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.UInt16:
                    {

                        ushort x = ushort.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.UInt32:
                    {

                        uint x = uint.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
                case DbType.UInt64:
                    {

                        ulong x = ulong.Parse(value);

                        valueToCompareEx = Expression.Constant(x);

                        break;

                    }
            }

            #endregion

            // This expression contains the comparison between the first
            // and second expressions
            Expression compareEx = null;

            #region Create the comparison operation

            // Combine the two expressions using the requested operation.
            // Note that strings have to be handled differently because 
            // the built in GreaterThan/LessThan operators only operate
            // on numeric (and date) data types.
            switch (op)
            {
                case Operator.Contains:
                    compareEx = Expression.Call(valueEx, "Contains", null, valueToCompareEx);
                    break;
                case Operator.StartsWith:
                    compareEx = Expression.Call(valueEx, "StartsWith", null, valueToCompareEx);
                    break;
                case Operator.Equals:
                    compareEx = Expression.Equal(valueEx, valueToCompareEx);
                    break;
                case Operator.GreaterThan:
                    if (expressionType == DbType.String)
                    {
                        compareEx = Expression.Call(valueEx,
                            typeof(string).GetMethod("CompareTo", new Type[] { typeof(string) }),
                                valueToCompareEx);
                        compareEx = Expression.GreaterThan(compareEx, Expression.Constant(0));
                    }
                    else
                    {
                        compareEx = Expression.GreaterThan(valueEx, valueToCompareEx);
                    }
                    break;
                case Operator.LessThan:
                    if (expressionType == DbType.String)
                    {
                        compareEx = Expression.Call(valueEx,
                            typeof(string).GetMethod("CompareTo", new Type[] { typeof(string) }),
                                valueToCompareEx);
                        compareEx = Expression.LessThan(compareEx, Expression.Constant(0));
                    }
                    else
                    {
                        compareEx = Expression.LessThan(valueEx, valueToCompareEx);
                    }
                    break;
                case Operator.GreaterThanOrEqualTo:
                    if (expressionType == DbType.String)
                    {
                        compareEx = Expression.Call(valueEx,
                            typeof(string).GetMethod("CompareTo", new Type[] { typeof(string) }),
                                valueToCompareEx);
                        compareEx = Expression.GreaterThanOrEqual(compareEx, Expression.Constant(0));
                    }
                    else
                    {
                        compareEx = Expression.GreaterThanOrEqual(valueEx, valueToCompareEx);
                    }
                    break;
                case Operator.LessThanOrEqualTo:
                    if (expressionType == DbType.String)
                    {
                        compareEx = Expression.Call(valueEx,
                            typeof(string).GetMethod("CompareTo", new Type[] { typeof(string) }),
                                valueToCompareEx);
                        compareEx = Expression.LessThanOrEqual(compareEx, Expression.Constant(0));
                    }
                    else
                    {
                        compareEx = Expression.LessThanOrEqual(valueEx, valueToCompareEx);
                    }
                    break;
            }

            #endregion

            // Negate the expression if requested
            if (not)
                compareEx = Expression.Not(compareEx);

            return compareEx;

        }

        /// <summary>
        /// Combines two expressions using the requested operation
        /// </summary>
        /// <param name="ex1">The ex1.</param>
        /// <param name="ex2">The ex2.</param>
        /// <param name="op">The property.</param>
        /// <returns>Expression.</returns>
        protected Expression CombineFilters(Expression ex1, Expression ex2, JoinOperator op)
        {

            if (ex1 == null) return ex2;
            if (ex2 == null) return ex1;

            if (op == JoinOperator.Default || op == JoinOperator.And)
                return Expression.AndAlso(ex1, ex2);
            else
                return Expression.OrElse(ex1, ex2);

        }

        /// <summary>
        /// Creates a LINQ Expression that represents the users filter
        /// </summary>
        /// <returns>Expression{Func{System.ObjectSystem.Boolean}}.</returns>
        protected Expression<Func<object, bool>> GetFilterExpression()
        {

            // Create a single parameter that all generated expressions will
            // take as input. This represents a row in the data source
            ParameterExpression paramEx = Expression.Parameter(typeof(object), "o");

            Expression<Func<object, bool>> lambda = null;

            Expression mainExpression = null;

            foreach (SearchCondition condition in SearchConditions)
            {

                Expression ex = GetFilterExpression(condition.SearchField,
                    condition.Operator, condition.SearchValue,
                    condition.Not, condition.DataType, paramEx);

                if (ex == null) continue;

                if (mainExpression == null)
                {
                    mainExpression = ex;
                }
                else
                {
                    mainExpression = CombineFilters(mainExpression, ex, condition.JoinOperator);
                }

            }

            // Convert the LINQ expression to a Lambda expression
            if (mainExpression != null)
                lambda = Expression.Lambda<Func<object, bool>>(mainExpression, paramEx);

            return lambda;

        }

        /// <summary>
        /// Applies filtering, sorting and paging to the
        /// specified query
        /// </summary>
        /// <param name="query">The query to append to</param>
        /// <returns>The modified query</returns>
        public IQueryable<T> ApplyFilterPagingAndSorting(IQueryable<T> query)
        {
            IQueryable<T> tmp = query;
            tmp = ApplyFilter(tmp);
            tmp = ApplySorting(tmp);
            tmp = ApplyPaging(tmp);
            return tmp;
        }

    }

    /// <summary>
    /// Enum Operator
    /// </summary>
    [DataContract]
    public enum Operator
    {

        /// <summary>
        /// The contains
        /// </summary>
        [EnumMember]
        Contains = 0,

        /// <summary>
        /// The equals
        /// </summary>
        [EnumMember]
        Equals = 1,

        /// <summary>
        /// The greater than
        /// </summary>
        [EnumMember]
        GreaterThan = 2,

        /// <summary>
        /// The less than
        /// </summary>
        [EnumMember]
        LessThan = 3,

        /// <summary>
        /// The greater than original equal automatic
        /// </summary>
        [EnumMember]
        GreaterThanOrEqualTo = 4,

        /// <summary>
        /// The less than original equal automatic
        /// </summary>
        [EnumMember]
        LessThanOrEqualTo = 5,

        /// <summary>
        /// The starts with
        /// </summary>
        [EnumMember]
        StartsWith = 6

    }

    /// <summary>
    /// Enum JoinOperator
    /// </summary>
    [DataContract]
    public enum JoinOperator
    {

        /// <summary>
        /// The default
        /// </summary>
        [EnumMember]
        Default = 0,

        /// <summary>
        /// The and
        /// </summary>
        [EnumMember]
        And = 0,

        /// <summary>
        /// The original
        /// </summary>
        [EnumMember]
        Or = 1

    }

    /// <summary>
    /// Specified one test to perform against every item in the
    /// original list. Items that don't pass will be filtered
    /// out.
    /// </summary>
    [DataContract]
    public class SearchCondition
    {

        /// <summary>
        /// The operator used to join this condition to the previous
        /// condition (AND or OR)
        /// </summary>
        /// <value>The join operator.</value>
        [DataMember]
        public JoinOperator JoinOperator { get; set; }

        /// <summary>
        /// Whether to negate this condition
        /// </summary>
        /// <value><c>true</c> if not; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool Not { get; set; }

        /// <summary>
        /// The field (property) name to search
        /// </summary>
        /// <value>The search field.</value>
        [DataMember]
        public string SearchField { get; set; }

        /// <summary>
        /// The operator to apply to the search field and
        /// search value (for example, "Equals" or "GreaterThan")
        /// </summary>
        /// <value>The operator.</value>
        [DataMember]
        public Operator Operator { get; set; }

        /// <summary>
        /// The value to search for
        /// </summary>
        /// <value>The search value.</value>
        [DataMember]
        public string SearchValue { get; set; }

        /// <summary>
        /// The data type of the condition
        /// </summary>
        /// <value>The type of the data.</value>
        [DataMember]
        public DbType DataType { get; set; }

    }
}
