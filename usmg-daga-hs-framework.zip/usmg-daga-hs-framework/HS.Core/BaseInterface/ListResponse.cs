﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="ListResponse.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// The base class for a response that returns a list
    /// of items
    /// </summary>
    /// <typeparam name="ItemType">The type of the item in the list</typeparam>
    [DataContract]
    public class ListResponse<ItemType> : ServiceResponse
    {

        /// <summary>
        /// The list of items that were returned
        /// </summary>
        /// <value>The items.</value>
        [DataMember]
        public List<ItemType> Items { get; set; }

        /// <summary>
        /// The total number of items in the list before paging was applied
        /// </summary>
        /// <value>The total items.</value>
        [DataMember]
        public int TotalItems { get; set; }

        public ListResponse()
        {
            Items = new List<ItemType>();
        }

    }

    
}
