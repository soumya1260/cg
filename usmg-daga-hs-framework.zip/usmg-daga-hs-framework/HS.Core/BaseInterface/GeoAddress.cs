﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : todd.merritt
// Created          : 12-15-2014
//
// Last Modified By : todd.merritt
// Last Modified On : 12-15-2014
// ***********************************************************************
// <copyright file="GeoAddress.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{

    /// <summary>
    /// This is a base GeoAddress class for re-use across various objects
    /// </summary>
    [DataContract]
    public class GeoAddress
    {
        /// <summary>
        /// Gets or sets the AddressLine of the GeoAddress.
        /// </summary>
        /// <value>The AddressLine of the GeoAddress.</value>
        [DataMember]
        public string AddressLine { get; set; }

        /// <summary>
        /// Gets or sets the AdminDistrict of the GeoAddress.
        /// </summary>
        /// <value>The AdminDistrict of the GeoAddress.</value>
        [DataMember]
        public string AdminDistrict { get; set; }

        /// <summary>
        /// Gets or sets the AdminDistrict2 of the GeoAddress.
        /// </summary>
        /// <value>The AdminDistrict2 of the GeoAddress.</value>
        [DataMember]
        public string AdminDistrict2 { get; set; }

        /// <summary>
        /// Gets or sets the CountryRegion of the GeoAddress.
        /// </summary>
        /// <value>The CountryRegion of the GeoAddress.</value>
        [DataMember]
        public string CountryRegion { get; set; }

        /// <summary>
        /// Gets or sets the FormattedAddress of the GeoAddress.
        /// </summary>
        /// <value>The FormattedAddress of the GeoAddress.</value>
        [DataMember]
        public string FormattedAddress { get; set; }

        /// <summary>
        /// Gets or sets the Locality of the GeoAddress.
        /// </summary>
        /// <value>The Locality of the GeoAddress.</value>
        [DataMember]
        public string Locality { get; set; }

        /// <summary>
        /// Gets or sets the PostalCode of the GeoAddress.
        /// </summary>
        /// <value>The PostalCode of the GeoAddress.</value>
        [DataMember]
        public string PostalCode { get; set; }
    }
}
