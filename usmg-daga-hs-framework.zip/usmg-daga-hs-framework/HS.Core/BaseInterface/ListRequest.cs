﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="ListRequest.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{

    /// <summary>
    /// A request for a list of items. Provides basic support for
    /// filtering, sorting and paging.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [DataContract]
    public class ListRequest<T> : ServiceRequest where T : class
    {
/// <summary>
        /// The list of items that were returned
        /// </summary>
        /// <value>The items.</value>
        [DataMember]
        public List<T> Items { get; set; }

        /// <summary>
        /// The total number of items in the list before paging was applied
        /// </summary>
        /// <value>The total items.</value>
        [DataMember]
        public int TotalItems { get; set; }

        public ListRequest()
        {
            Items = new List<T>();
        }

        /// <summary>
        /// The filter, sorting and paging to apply to the list
        /// before it is returned
        /// </summary>
        /// <value>The search criteria.</value>
        [DataMember]
        public SearchCriteria<T> SearchCriteria { get; set; }

        /// <summary>
        /// Adds a clause to the specified query which filters the
        /// results by the specified <see cref="SearchCriteria" />
        /// </summary>
        /// <param name="query">the query to append to</param>
        /// <returns>The modified query</returns>
        /// <remarks>Inheriting classes could overload this method
        /// if they are using the database to filter instead of
        /// using Linq.</remarks>
        public IQueryable<T> ApplyFilter(IQueryable<T> query)
        {

            if (SearchCriteria == null) return query;

            return (SearchCriteria.ApplyFilter(query));

        }

        /// <summary>
        /// Adds a clause to the specified query which sorts the
        /// results by the specified <see cref="SearchCriteria" />
        /// </summary>
        /// <param name="query">the query to append to</param>
        /// <returns>The modified query</returns>
        /// <remarks>Inheriting classes could overload this method
        /// if they are using the database to sort instead of
        /// using Linq.</remarks>
        public IQueryable<T> ApplySorting(IQueryable<T> query)
        {

            if (SearchCriteria == null) return query;

            return (SearchCriteria.ApplySorting(query));

        }

        /// <summary>
        /// Adds a clause to the specified query so that it
        /// returns only the current page
        /// </summary>
        /// <param name="query">The query to append to</param>
        /// <returns>The modified query</returns>
        /// <remarks>Inheriting classes could overload this method
        /// if they are using the database to page instead of
        /// using Linq.</remarks>
        public IQueryable<T> ApplyPaging(IQueryable<T> query)
        {

            if (SearchCriteria == null) return query;

            return (SearchCriteria.ApplyPaging(query));

        }

        /// <summary>
        /// Applies filtering, sorting and paging to the
        /// specified query
        /// </summary>
        /// <param name="query">The query to append to</param>
        /// <returns>The modified query</returns>
        public IQueryable<T> ApplyFilterPagingAndSorting(IQueryable<T> query)
        {

            if (SearchCriteria == null) return query;

            return (SearchCriteria.ApplyFilterPagingAndSorting(query));

        }

        /// <summary>
        /// Applies filtering, sorting and paging to the
        /// specified list
        /// </summary>
        /// <param name="list">The list to append to</param>
        /// <param name="response">The response.</param>
        /// <returns>The modified list</returns>
        public void ApplyFilterPagingAndSorting(IList<T> list, ListResponse<T> response)
        {
            response.Items = ApplyFilterPagingAndSorting(list.AsQueryable()).ToList();
            response.TotalItems = list.Count;
        }

    }
}
