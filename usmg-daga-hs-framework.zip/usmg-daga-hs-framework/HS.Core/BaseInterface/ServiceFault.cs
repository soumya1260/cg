﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="ServiceFault.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Describes a failure in a WCF service method.
    /// </summary>
    [DataContract]
    public class ServiceFault
    {

        /// <summary>
        /// The null reference
        /// </summary>
        public const decimal NullReference = -0000.0010m;

        /// <summary>
        /// The string overflow
        /// </summary>
        public const decimal StringOverflow = -0000.0020m;

        /// <summary>
        /// The missing field
        /// </summary>
        public const decimal MissingField = -0000.0030m;

        /// <summary>
        /// The mismatched key
        /// </summary>
        public const decimal MismatchedKey = -0000.0040m;

        /// <summary>
        /// The field out of range
        /// </summary>
        public const decimal FieldOutOfRange = -0000.0050m;

        /// <summary>
        /// The data was updated since last read
        /// </summary>
        public const decimal DataWasUpdatedSinceLastRead = -0000.0060m;

        /// <summary>
        /// The action is disabled
        /// </summary>
        public const decimal ActionIsDisabled = -0000.0070m;

        /// <summary>
        /// The no selection
        /// </summary>
        public const decimal NoSelection = -0000.0080m;

        /// <summary>
        /// The invalid number
        /// </summary>
        public const decimal InvalidNumber = -0000.0090m;

        /// <summary>
        /// The invalid date
        /// </summary>
        public const decimal InvalidDate = -0000.0100m;

        /// <summary>
        /// The item does not exist
        /// </summary>
        public const decimal ItemDoesNotExist = -0000.0110m;

        /// <summary>
        /// The unexpected error
        /// </summary>
        public const decimal UnexpectedError = -0000.9999m;

        /// <summary>
        /// The validation error
        /// </summary>
        public const decimal ValidationError = -0000.0120m;

        /// <summary>
        /// The too many results found
        /// </summary>
        public const decimal TooManyResultsFound = -0000.0130m;

        /// <summary>
        /// (Optional) A description of the fault. If this is omitted,
        /// the failure type can be inferred from the type (class) of
        /// the inheriting
        /// </summary>
        /// <value>The message.</value>
        [DataMember]
        public string Message { get; set; }

        /// <summary>
        /// The source of the fault. This will generally contain a
        /// stack trace to the piece of data in the
        /// <see cref="ServiceRequest" /> object that caused the
        /// fault. For example, if the request contained an invalid
        /// customer id, the Source might be "Request.Item.Customer.ID"
        /// </summary>
        /// <value>The source.</value>
        [DataMember]
        public string Source { get; set; }

        /// <summary>
        /// The _is localized
        /// </summary>
        private bool _isLocalized = true;

        /// <summary>
        /// Whether the error message has been localized or not.
        /// </summary>
        /// <value><c>true</c> if this instance is localized; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool IsLocalized
        {
            get
            {
                return _isLocalized;
            }
            set
            {
                _isLocalized = value;
            }
        }

        /// <summary>
        /// A code that specifies the exact error that occurred
        /// </summary>
        /// <value>The fault code.</value>
        [DataMember]
        public decimal FaultCode { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceFault"/> class.
        /// </summary>
        public ServiceFault() { }

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceFault"/> class.
        /// </summary>
        /// <param name="faultCode">The fault code.</param>
        public ServiceFault(decimal faultCode) { this.FaultCode = faultCode; }

    }
}
