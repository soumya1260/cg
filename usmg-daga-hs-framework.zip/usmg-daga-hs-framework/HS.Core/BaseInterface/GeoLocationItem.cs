﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : todd.merritt
// Created          : 12-15-2014
//
// Last Modified By : todd.merritt
// Last Modified On : 12-15-2014
// ***********************************************************************
// <copyright file="GeoLocationItem.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// This is a base GeoLocationItem class for re-use across various objects.
    /// </summary>
    [DataContract]
    public class GeoLocationItem
    {
        /// <summary>
        /// Gets or sets the name of the GeoLocation.
        /// </summary>
        /// <value>The name of the GeoLocation.</value>
        [DataMember]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the EntityType of the GeoLocation.
        /// </summary>
        /// <value>The EntityType of the GeoLocation.</value>
        [DataMember]
        public string EntityType { get; set; }

        /// <summary>
        /// Gets or sets the Confidence Level of the GeoLocation.
        /// </summary>
        /// <value>The Confidence Level of the GeoLocation.</value>
        [DataMember]
        public string Confidence { get; set; }

        /// <summary>
        /// Gets or sets the GeoLocation Address.
        /// </summary>
        /// <value>The GeoLocation Address.</value>
        [DataMember]
        public GeoAddress Address { get; set; }

        /// <summary>
        /// Gets or sets the GeoLocation Lat/Long.
        /// </summary>
        /// <value>The GeoLocation Lat/Long.</value>
        [DataMember]
        public GeoCoordinate Coordinate { get; set; }

    }
}
