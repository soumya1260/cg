﻿using System.Text.RegularExpressions;

namespace HS
{
    public static class Helper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Password"></param>
        /// <returns></returns>
        public static bool CheckPasswordIsValid(string Password)
        {
            if (Password == null)
                return false;

            bool isValid = false;
            //
            isValid = Regex.Match(Password, "(^(?=.*[A-Z]+)(?=.*[a-z]+)(?=.*[0-9]+).*$)|(^(?=.*[A-Z]+)(?=.*[a-z]+)(?=.*\\W+).*$)").Success;
            if (Password.Length < 7 || Password.Length > 100)
            {
                return false;
            }
            return isValid;
        }
    }
}
