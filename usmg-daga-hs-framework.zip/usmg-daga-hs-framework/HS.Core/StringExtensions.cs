﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 04-23-2013
// ***********************************************************************
// <copyright file="StringExtensions.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************



using System;
/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// String extension class
    /// </summary>
    [Obsolete("These string extensions don't follow best practices, do not consider culture, do not allow for case ignorance and can confuse code analysis tools like Roslyn, SonarQube and Resharper.")]
    public static class StringExtensions
    {
        /// <summary>
        /// Returns true is strings are equal
        /// </summary>
        /// <param name="str1">The root string</param>
        /// <param name="str2">The string to compare</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public static bool HSEquals(this string str1, string str2)
        {

            if (string.IsNullOrEmpty(str1))
            {

                if (string.IsNullOrEmpty(str2))
                {
                    return true;
                }

                return false;

            }

            return string.Equals(str1, str2);

        }

    }
}
