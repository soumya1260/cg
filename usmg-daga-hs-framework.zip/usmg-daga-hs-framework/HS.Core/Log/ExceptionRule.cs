namespace HS.Data.ORM.Logging
{
    public class ExceptionRule
    {
        public bool CanISendEmail { get; set; }
        public int NumberOccurances { get; set; }
        public int WithinTimeSpan { get; set; }
        public bool IsRuleConfigured { get; set; }
    }
}
