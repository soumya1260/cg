﻿using System;
using System.Configuration;
using System.IO;
using System.Text;

namespace HS
{
    public class EmailFormatter
    {
        public static string FormatEmailBodyForException(WriteToLogRequest req, bool IncludeLink)
        {
            StringBuilder msg = new StringBuilder();

            switch (req.LogMessage.MessageType)
            {
                case MessageTypeEnum.Exception:
                    return FormatExceptionEmailBody(req, IncludeLink);

                case MessageTypeEnum.Informational:
                    return FormatInformationalEmailBody(req);

                case MessageTypeEnum.SecurityMessage:
                //TBD
                case MessageTypeEnum.Verbose:
                //TBD
                case MessageTypeEnum.Debug:
                //TBD
                //Assume a default of Exception
                default:
                    return FormatExceptionEmailBody(req, IncludeLink);
                    break;


            }

            return msg.ToString();
        }

        public static string FormatExceptionEmailBody(WriteToLogRequest req, bool IncludeLink )
        {
            StringWriter sw = new StringWriter();
            sw.WriteLine("<div style='font-family:calibri,tahoma,arial;'><table cellpadding='2'>");

            string formatString = "";

            formatString = "<tr><td><b>{0}</b>:</td><td style='color:#222222; font-size:0.9em;'>{1}</td></tr>";

            //sw.WriteLine(FormatEnvironmentInfo(req));
            sw.WriteLine(string.Format(formatString, "Log Entry ID", req.LogMessage.OriginalMessageID.ToString()));
            sw.WriteLine(string.Format(formatString, "Title", req.LogMessage.MessageTitle));
            sw.WriteLine(string.Format(formatString, "Application Name", req.LogMessage.SendingApplication));
            sw.WriteLine(string.Format(formatString, "Server", req.LogMessage.MessageSentFrom));
            sw.WriteLine(string.Format(formatString, "Exception Type", req.LogMessage.ExceptionType));
            sw.WriteLine(string.Format(formatString, "Message Type", req.LogMessage.MessageType.ToString()));
            sw.WriteLine(string.Format(formatString, "Promotion Environment", req.LogMessage.PromotionEnvironment));

            sw.WriteLine(string.Format(formatString, "Message", req.LogMessage.Message));
            if(req.LogMessage.ContainsException == true)
            {
                sw.WriteLine(string.Format(formatString, "Exception Message", req.LogMessage.ExceptionMessage));
            }
            sw.WriteLine(string.Format(formatString, "NOTES:", ""));

            if (req.LogMessage.AdditionalMessages != null && req.LogMessage.AdditionalMessages.Count > 0)
            {
                foreach (string note in req.LogMessage.AdditionalMessages)
                {
                    sw.WriteLine(string.Format(formatString, "Note", note));
                }
            }

        
            var url =  ConfigurationManager.AppSettings.Get("LoggerAdminURL");
            if (IncludeLink == true)
            {
                sw.WriteLine(string.Format(formatString, "Link", "Click <a href =\"http:\\\\" + url + "\\LogEntry.aspx?ID=" + req.LogMessage.OriginalMessageID + "\"Here</a> to view Log Entry"));
            }


            sw.WriteLine(string.Format(formatString, "Stack Trace", ""));
            if (req.LogMessage.ExceptionStackTrace != null)
            {
                sw.WriteLine(string.Format(formatString, "", req.LogMessage.ExceptionStackTrace.ToString()));
            }

            sw.WriteLine("See Database Exception Log for more details.....");

            sw.WriteLine(string.Format(formatString, "", ""));
            sw.WriteLine(string.Format(formatString, "This EMAIL Was Sent from the logging server :", Environment.MachineName.ToString()));
            

            sw.WriteLine("</table></div>");
            string retString = sw.ToString();
            return retString;
        }

        public static string FormatInformationalEmailBody(WriteToLogRequest req)
        {
            StringWriter sw = new StringWriter();
            sw.WriteLine("<div style='font-family:calibri,tahoma,arial;'><table cellpadding='2'>");

            string formatString = "";

            formatString = "<tr><td>{0}:</td><td style='color:#222222; font-size:0.9em;'>{1}</td></tr>";

            sw.WriteLine(string.Format(formatString, "Title", req.LogMessage.MessageTitle));
            sw.WriteLine(string.Format(formatString, "Exception Type", req.LogMessage.ExceptionType));
            sw.WriteLine(string.Format(formatString, "Application Name", req.LogMessage.SendingApplication));
            sw.WriteLine(string.Format(formatString, "Server", req.LogMessage.MessageSentFrom));
            sw.WriteLine(string.Format(formatString, "Message Type", req.LogMessage.MessageType.ToString()));
            sw.WriteLine(string.Format(formatString, "Promotion Environment", req.LogMessage.PromotionEnvironment));

            sw.WriteLine(string.Format(formatString, "Message", req.LogMessage.Message));

            sw.WriteLine(string.Format(formatString, "NOTES:", ""));

            if (req.LogMessage.AdditionalMessages == null && req.LogMessage.AdditionalMessages.Count > 0)
            {
                foreach (string note in req.LogMessage.AdditionalMessages)
                {
                    sw.WriteLine(string.Format(formatString, "Note", note));
                }
            }

            sw.WriteLine(string.Format(formatString, "Stack Strace:", ""));

            if (req.LogMessage.ExceptionStackTrace != null)
                    {
                        sw.WriteLine(string.Format(formatString, "Stack Trace", req.LogMessage.ExceptionStackTrace.ToString()));
                    }

            //sw.WriteLine("See Database Exception Log for more details.....");

            sw.WriteLine("</table></div>");
            string retString = sw.ToString();
            return retString;
        }
       
    }
}
