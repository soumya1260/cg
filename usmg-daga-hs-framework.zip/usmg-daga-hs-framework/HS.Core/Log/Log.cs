﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-03-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="Log.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using HS.HSEmailService;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.Remoting.Messaging;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Class Log.
    /// </summary>
    public static class Log
    {

        // delegate to represent the LogMessage method for async activity
        public delegate void AsyncLogMessageCaller(string Message, MessageTypeEnum MessageType);

        // delegate to represent the LogMessage method for async activity
        public delegate void AsyncLogExceptionCaller(Exception exception, List<string> AdditionalMessages, HSLoggingConfiguration config);

        public delegate void AsyncEmailSendCaller(Email MyEmail);

        #region Asynchronous Message Logging
        /// <summary>
        /// Logs the message.
        /// </summary>
        /// <param name="Message">The message.</param>
        /// <param name="traceLevel">The trace level.</param>
        public static void LogMessage(string Message, MessageTypeEnum MessageType)
        {
            // declare an object to represent the delegate
            AsyncLogMessageCaller caller = new AsyncLogMessageCaller(LogMessageAsync);
            // begin the async call, passing in the message and messagetype, and setting the callback
            Exception threadException;
            try
            {
                IAsyncResult result = caller.BeginInvoke(Message, MessageType, new AsyncCallback(LogMessageCallback), new object());
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        static void LogMessageCallback(IAsyncResult result)
        {
            // String to represent the state of the call.  For debugging only
            string resultText = result.IsCompleted.ToString();
            // declare a result that casts from the result interface
            AsyncResult arResult = (AsyncResult)result;
            // delare the caller based on the delegate property
            AsyncLogMessageCaller caller = (AsyncLogMessageCaller)arResult.AsyncDelegate;
            // call the EndInvoke to clean up all async activities and resources
            caller.EndInvoke(result);

        }

        private static void LogMessageAsync(string Message, MessageTypeEnum MessageType)
        {
            HSLoggingConfiguration config =
                        HSLoggingConfiguration.Current;

            //Just in case the logger Has not started yet or is asleep

            var tl = LogAgent.GetTraceLevelMessageTypeEnum(MessageType);

            var myApp = GetApplicationName();

            //Thread.Sleep(1000);

            if (config.WriteToDB == true)
            {
                LogAgent.WriteMessageToLogDB(Message,
                    myApp,
                    System.Environment.MachineName,
                    MessageType,
                    config.PromotionEnvironment);
            }
        }

        #endregion

        /// <summary>
        /// Logs the exception.  Logging method is called asynchronously and execution is immediately passed back
        /// to the calling method.
        /// </summary>
        /// <param name="exception">The exception.</param>
        public static void LogException(Exception exception)
        {
            LogException(exception, null);
        }

        /// <summary>
        /// Logs the exception.  Logging method is called asynchronously and execution is immediately passed back
        /// to the calling method.
        /// </summary>
        /// <param name="exception">The exception.</param>
        /// /// <param name="AdditionalMessages">List of additional messages to log with the exception</param>
        public static void LogException(Exception exception, List<string> AdditionalMessages)
        {
            HSLoggingConfiguration config =
                           HSLoggingConfiguration.Current;
            //Just in case the logger Has not started yet or is asleep


            var myApp = GetApplicationName();

            if (AdditionalMessages.IsNull())
            {
                AdditionalMessages = new List<string>();
            }

            AdditionalMessages = CleanMessages(AdditionalMessages);

            var ID = -1;
            if (config.WriteToDB == true)
            {
                ID = LogAgent.WriteExceptionToLogDB(exception, myApp, config.PromotionEnvironment, AdditionalMessages);
            }
            if (exception.InnerException != null)
            {
                LogInnerException(exception.InnerException, ID, myApp);
            }


            //// declare an object to represent the delegate
            //AsyncLogExceptionCaller caller = new AsyncLogExceptionCaller(LogExceptionAsync);
            //// begin the async call, passing in the exception and messages, and setting the callback

            //try
            //{
            //    IAsyncResult result = caller.BeginInvoke(exception, AdditionalMessages, config, new AsyncCallback(LogExceptionCallback), new Email());
            //    //  LogExceptionAsync(exception, AdditionalMessages);
            //}
            //catch (Exception ex)
            //{
            //    throw;
            //}
        }


        //COmmented out until we can fin problem with thread handler

        //static void LogExceptionCallback(IAsyncResult result)
        //{
        //    // String to represent the state of the call.  For debugging only
        //    string resultText = result.IsCompleted.ToString();
        //    // declare a result that casts from the result interface
        //    AsyncResult arResult = (AsyncResult)result;
        //    // delare the caller based on the delegate property
        //    AsyncLogExceptionCaller caller = (AsyncLogExceptionCaller)arResult.AsyncDelegate;
        //    // call the EndInvoke to clean up all async activities and resources
        //    caller.EndInvoke(result);

        //}

        /// <summary>
        /// Method that handles the actual logging.  This method runs synchronously on a new thread and does not block
        /// the main thread based on how it is called from the calling method.
        /// </summary>
        //private static void LogExceptionAsync(Exception exception, List<string> AdditionalMessages, HSLoggingConfiguration config)
        //{
        //    //HSLoggingConfiguration config =
        //    //            HSLoggingConfiguration.Current;
        //    //Just in case the logger Has not started yet or is asleep
        //    if (config.WriteToFile == true)
        //    {
        //        //SMD - 01/30/2014
        //        //For Future Use
        //        //MyLog.Start();
        //        //MyLog.WriteException(exception);
        //    }

        //    var myApp = GetApplicationName();

        //    if (AdditionalMessages.IsNull())
        //    {
        //        AdditionalMessages = new List<string>();
        //    }

        //    AdditionalMessages = CleanMessages(AdditionalMessages);

        //    var ID = -1;
        //    if (config.WriteToDB == true)
        //    {
        //        ID = LogAgent.WriteExceptionToLogDB(exception, myApp, config.PromotionEnvironment, AdditionalMessages);
        //    }
        //    if (exception.InnerException != null)
        //    {
        //        LogInnerException(exception.InnerException, ID, myApp);
        //    }
        //}

        /// <summary>
        /// Logs the inner exception.
        /// </summary>
        /// <param name="ex">The executable.</param>
        /// <param name="ParentID">The parent unique identifier.</param>
        /// <param name="AppName">Name of the application.</param>
        private static void LogInnerException(Exception ex, int ParentID, string AppName)
        {
            HSLoggingConfiguration config =
                        HSLoggingConfiguration.Current;


            if (config.WriteToDB == true)
            {
                LogAgent.WriteInnerExceptionToLogDB(ex, ParentID, AppName);
            }
            if (ex.InnerException != null)
            {
                LogInnerException(ex.InnerException, ParentID, AppName);
            }
        }


        public static void SendEmail(Email MyEmail)
        {
            // declare an object to represent the delegate
            AsyncEmailSendCaller caller = new AsyncEmailSendCaller(SendEmailAsync);
            // begin the async call, passing in the exception and messages, and setting the callback

            try
            {
                IAsyncResult result = caller.BeginInvoke(MyEmail, new AsyncCallback(SendEmailCallback), new object());

            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private static void SendEmailAsync(Email MyEmail)
        {
            var myApp = GetApplicationName();
            HSLoggingConfiguration config =
                       HSLoggingConfiguration.Current;
            try
            {
                //SMD - 04/16/2014
                //Added to allow DEV and QA to set a default to address for all emails
                if(config.UseDefaultToEmailForSendMail == true)
                {
                    MyEmail.To = config.DefaultToEmailForSendMail;
                }

                LogAgent.SendEmail(MyEmail);

            }
            catch (Exception ex)
            {
                LogAgent.WriteExceptionToLogDB(ex, myApp, config.PromotionEnvironment, new List<string>());
            }

        }
        static void SendEmailCallback(IAsyncResult result)
        {
            // String to represent the state of the call.  For debugging only
            string resultText = result.IsCompleted.ToString();
            // declare a result that casts from the result interface
            AsyncResult arResult = (AsyncResult)result;
            // delare the caller based on the delegate property
            AsyncEmailSendCaller caller = (AsyncEmailSendCaller)arResult.AsyncDelegate;
            // call the EndInvoke to clean up all async activities and resources
            caller.EndInvoke(result);

        }

        internal static string GetApplicationName()
        {
            var retval = "";
            try
            {
                // Check if App Name is Overridden
                bool isAppNameOverridden = HSLoggingConfiguration.Current.OverrideAppName;

                if (isAppNameOverridden)
                {
                    try
                    {
                        retval = HSLoggingConfiguration.Current.DefaultApplicationName;
                    }
                    catch
                    {
                        retval = "";
                    }
                }

                else
                {
                    var myApp = "";
                    try
                    {
                        //Try and get the app name from the current executable
                        bool isValidAppName = String.IsNullOrEmpty(System.AppDomain.CurrentDomain.FriendlyName);

                        if (isValidAppName)
                        {
                            //If it returns null or empty string then use the default app name from the config
                            myApp = HSLoggingConfiguration.Current.DefaultApplicationName;
                        }
                        else
                        {
                            //Use AppDomain Assemply as Application Name
                            myApp = System.AppDomain.CurrentDomain.FriendlyName.ToString();
                        }
                    }
                    catch
                    {
                        myApp = HSLoggingConfiguration.Current.DefaultApplicationName;
                    }

                    //If the app is website then return SiteName.
                    bool isWebsite = IsWebSite(myApp);

                    if (isWebsite)
                    {
                        retval = System.Web.Hosting.HostingEnvironment.ApplicationHost.GetSiteName();
                    }
                    else
                    {
                        retval = myApp;
                    }
                }
            }
            catch
            {
                retval = "";
            }

            return retval;
        }
        private static bool IsWebSite(string appName)
        {
            try
            {
                //Standardize appName
                appName = appName.ToUpper();

                //Check to see if AppName contains attributes of a website.
                bool isW3SVC = appName.Contains("W3SVC");
                bool isConfigFile = appName.EndsWith(".CONFIG");
                bool isMappedDrive = appName.Contains(@":\");

                if (isW3SVC)
                {
                    return true;
                }
                else if (isConfigFile)
                {
                    return true;
                }
                else if (isMappedDrive)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        private static List<String> CleanMessages(List<string> Msgs)
        {
            var ret = new List<string>();

            foreach (string s in Msgs)
            {
                var t = s.ToLower();
                //Checkl to mak sure the string does not contain a password from a connection string
                if (t.Contains("password=") || t.Contains("password ="))
                {
                    var sep = new string[1];
                    sep[0] = (";");
                    var tList = s.Split(sep, StringSplitOptions.RemoveEmptyEntries);
                    string newString = "";
                    foreach (string v in tList)
                    {
                        if (v.ToLower().Contains("password=") == false && v.ToLower().Contains("password =") == false)
                        {
                            newString += v + "; ";
                        }
                    }
                    ret.Add(newString);
                }
                else
                {
                    ret.Add(t);
                }

            }

            return ret;
        }


    }



    /// <summary>
    /// Class LogAgent.
    /// </summary>
    internal static class LogAgent
    {
        /// <summary>
        /// Gets the message type enum from trace level.
        /// </summary>
        /// <param name="tl">The control.</param>
        /// <returns>MessageTypeEnum.</returns>
        public static MessageTypeEnum GetMessageTypeEnumFromTraceLevel(TraceLevel tl)
        {
            switch (tl)
            {
                case System.Diagnostics.TraceLevel.Error:
                    return MessageTypeEnum.Exception;

                case System.Diagnostics.TraceLevel.Info:
                    return MessageTypeEnum.Informational;

                case System.Diagnostics.TraceLevel.Off:
                    return MessageTypeEnum.Informational;

                case System.Diagnostics.TraceLevel.Verbose:
                    return MessageTypeEnum.Verbose;

                case System.Diagnostics.TraceLevel.Warning:
                    return MessageTypeEnum.Exception;
                default:
                    return MessageTypeEnum.Debug;


            }
        }

        public static TraceLevel GetTraceLevelMessageTypeEnum(MessageTypeEnum mt)
        {
            switch (mt)
            {
                case MessageTypeEnum.Debug:
                    return System.Diagnostics.TraceLevel.Info; ;

                case MessageTypeEnum.Exception:
                    return System.Diagnostics.TraceLevel.Error;

                case MessageTypeEnum.Informational:
                    return System.Diagnostics.TraceLevel.Info;

                case MessageTypeEnum.SecurityMessage:
                    return System.Diagnostics.TraceLevel.Warning;

                case MessageTypeEnum.Verbose:
                    return System.Diagnostics.TraceLevel.Verbose;
                default:
                    return System.Diagnostics.TraceLevel.Error;


            }
        }

        internal static void SendEmail(Email MyEmail)
        {
            using (BaseAgent<ILogInterface> ba = new BaseAgent<ILogInterface>())
            {
                var lReq = new SendEmailRequest();
                ILogInterface li = ba.GetServiceChannel("NetTcpBinding_ILogInterface");

                try
                {


                    lReq.Item = MyEmail;
                    lReq.UserID = "LoggingUser";
                    lReq.RequestingAuthorityID = Environment.MachineName.ToString();

                    li.SendEmail(lReq);

                }
                catch (Exception ex)
                {

                    HandleLoggerException(ex);

                    MyEmail.Body.Insert(0, "<b/>PECIAL NOTE! The Logger was unable to send this email through the logger service.  This was sent through HSEmail directly.</b><br><br>");
                    HSEmailServiceFacade.SendEmail(MyEmail);
                }
                finally
                {
                    ba.Dispose();
                }
            }

        }

        /// <summary>
        /// Writes the message automatic log database.
        /// </summary>
        /// <param name="Message">The message.</param>
        /// <param name="SendingApplication">The sending application.</param>
        /// <param name="traceLevel">The trace level.</param>
        internal static void WriteMessageToLogDB(string Message,
            string SendingApplication,
            string ServerName,
            MessageTypeEnum messageType,
            string PromotionEnvironment)
        {
            using (BaseAgent<ILogInterface> ba = new BaseAgent<ILogInterface>())
            {
                WriteToLogRequest lReq = new WriteToLogRequest();
                ILogInterface li = ba.GetServiceChannel("NetTcpBinding_ILogInterface");

                try
                {
                    var le = new LogObject();
                    le.MessageTitle = String.Format("Message from {0} : {1}", SendingApplication, Message);
                    le.Message = Message;
                    le.MessageType = messageType;
                    le.SendingApplication = SendingApplication;
                    le.ExceptionMessage = "";
                    le.ExceptionSource = "";
                    le.ExceptionStackTrace = "";
                    le.ContainsException = false;
                    le.MessageSentFrom = Environment.MachineName.ToString();
                    le.PromotionEnvironment = PromotionEnvironment;


                    lReq.LogMessage = le;
                    lReq.UserID = "LoggingUser";
                    lReq.RequestingAuthorityID = Environment.MachineName.ToString();

                    var tmp = li.WriteMessageToLog(lReq).OriginalExceptionID;

                }
                catch (Exception ex)
                {
                    HandleLoggerException(ex);

                    // Something happened with the logging service.  Send the email directly to the email service

                    var MyEmail = PopulateEmailWithDefaultAddress();
                    MyEmail.Body = EmailFormatter.FormatEmailBodyForException(lReq, false);
                    HSEmailServiceFacade.SendEmail(MyEmail);
                }
                finally
                {
                    ba.Dispose();
                }
            }
        }
        /// <summary>
        /// Writes the exception automatic log database.
        /// </summary>
        /// <param name="ex">The executable.</param>
        /// <param name="SendingApplication">The sending application.</param>
        /// <returns>System.Int32.</returns>
        internal static int WriteExceptionToLogDB(Exception ex,
            string SendingApplication,
            string PromotionEnvironment,
            List<string> Messages)
        {
            using (BaseAgent<ILogInterface> ba = new BaseAgent<ILogInterface>())
            {
                var lReq = new WriteToLogRequest();
                ILogInterface li = ba.GetServiceChannel("NetTcpBinding_ILogInterface");
                try
                {
                    var le = new LogObject();
                    le.MessageTitle = "An Exception has occurred in Application " + SendingApplication;
                    le.MessageType = GetMessageTypeEnumFromTraceLevel(TraceLevel.Error);

                    if (ex != null) le.ExceptionType = ex.GetType().ToString();
                    if (SendingApplication != null) le.SendingApplication = SendingApplication;
                    if (ex.Message != null) le.ExceptionMessage = ex.Message;
                    if (ex.Source != null) le.ExceptionSource = ex.Source;
                    if (ex.StackTrace != null) le.ExceptionStackTrace = ex.StackTrace;
                    le.ContainsException = true;
                    if (Environment.MachineName != null) le.MessageSentFrom = Environment.MachineName.ToString();
                    if (PromotionEnvironment != null) le.PromotionEnvironment = PromotionEnvironment;
                    if (Messages != null && Messages.Count > 0)
                    {
                        le.AdditionalMessages = Messages;
                    }


                    lReq.LogMessage = le;
                    lReq.UserID = "LoggingUser";
                    lReq.RequestingAuthorityID = Environment.MachineName.ToString();

                    var tmp = li.WriteMessageToLog(lReq).OriginalExceptionID;

                    //var MyEmail = PopulateEmailWithDefaultAddress();
                    //MyEmail.Body = EmailFormatter.FormatEmailBodyForException(lReq);
                    //HSEmailServiceFacade.SendEmail(MyEmail);

                    return tmp;


                }
                catch (Exception exc)
                {
                    HandleLoggerException(exc);

                    var MyEmail = PopulateEmailWithDefaultAddress();
                    MyEmail.Body = EmailFormatter.FormatEmailBodyForException(lReq, false);
                    HSEmailServiceFacade.SendEmail(MyEmail);
                }
                finally
                {
                    ba.Dispose();
                }
            }
            return 0;
        }


        /// <summary>
        /// Writes the inner exception automatic log database.
        /// </summary>
        /// <param name="ex">The executable.</param>
        /// <param name="OriginalExceptionID">The original exception unique identifier.</param>
        /// <param name="SendingApplication">The sending application.</param>
        internal static void WriteInnerExceptionToLogDB(Exception ex, int OriginalExceptionID, string SendingApplication)
        {
            using (BaseAgent<ILogInterface> ba = new BaseAgent<ILogInterface>())
            {
                var lReq = new WriteToLogRequest();
                ILogInterface li = ba.GetServiceChannel("NetTcpBinding_ILogInterface");
                try
                {
                    var le = new LogObject();
                    le.OriginalMessageID = OriginalExceptionID;
                    le.MessageTitle = "An Exception has occurred in Application " + SendingApplication;
                    le.Message = ex.Message;
                    le.MessageType = GetMessageTypeEnumFromTraceLevel(TraceLevel.Error);
                    le.SendingApplication = SendingApplication;
                    le.ExceptionMessage = ex.Message;
                    le.ExceptionSource = ex.Source;
                    le.ExceptionStackTrace = ex.StackTrace;
                    le.ContainsException = true;
                    le.MessageSentFrom = Environment.MachineName.ToString();
                    le.ExceptionType = ex.GetType().ToString();


                    lReq.LogMessage = le;
                    lReq.UserID = "LoggingUser";
                    lReq.RequestingAuthorityID = Environment.MachineName.ToString();

                    var tmp = li.WriteMessageToLog(lReq).OriginalExceptionID;

                }
                catch (Exception exc)
                {
                    HandleLoggerException(exc);

                    var MyEmail = PopulateEmailWithDefaultAddress();
                    MyEmail.Body = EmailFormatter.FormatEmailBodyForException(lReq, false);
                    HSEmailServiceFacade.SendEmail(MyEmail);
                }
                finally
                {
                    ba.Dispose();
                }
            }

        }
        internal static Email PopulateEmailWithDefaultAddress()
        {
            string to = "";
            string from = "";
            string subject = "URGENT!!! An Exception has Occurred and was NOT logged to the database";

            try
            {

                HSLoggingConfiguration config =
                            HSLoggingConfiguration.Current;
                to = config.DefaultToEmail;
                from = config.DefaultFromEmail;
            }
            catch
            {
                to = "AutoWebExceptions@healthspring.com";
                from = "AutoWebExceptions@healthspring.com";

            }

            if (to == "" || from == "")
            {
                to = "AutoWebExceptions@healthspring.com";
                from = "AutoWebExceptions@healthspring.com";
            }
            var MyEmail = new Email()
           {
               To = to,
               From = from,
               Subject = subject
           };

            MyEmail.isHTML = true;
            return MyEmail;
        }
        internal static void HandleLoggerException(Exception ex)
        {
            System.Diagnostics.EventLog appLog =
                           new System.Diagnostics.EventLog();
            appLog.Source = "HS.Services.Logging";

            appLog.WriteEntry(String.Format("An Exception has occurred : {0} : {1}", ex.Message, ex.StackTrace), System.Diagnostics.EventLogEntryType.Error);
        }
    }
}
