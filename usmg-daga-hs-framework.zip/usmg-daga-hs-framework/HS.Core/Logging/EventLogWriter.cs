﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="EventLogWriter.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Diagnostics;

/// <summary>
/// The Logging namespace.
/// </summary>
namespace HS.Logging
{
    /// <summary>
    /// Writes entries to the event log
    /// </summary>
    public static class EventLogWriter
    {
        /// <summary>
        /// Event source
        /// </summary>
        private const string HSCoreLogging = "HS.Logging";

        /// <summary>
        /// Writes exception entries to the event log
        /// </summary>
        /// <param name="ex">Exception to log</param>
        public static void LogToEventViewer(this Exception ex)
        {
            try
            {
                EventLog.WriteEntry(HSCoreLogging, ex.ToString(), EventLogEntryType.Error);
            }
            catch
            {
                //do nothing the hs core logging will be added to the sources manually
            }
        }
    }
}
