﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 04-23-2013
// ***********************************************************************
// <copyright file="SortOrder.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Used to define sort order for return sets in Linq queries
    /// </summary>
    [DataContract]
    public enum SortOrder
    {
        /// <summary>
        /// Ascending order
        /// </summary>
        [EnumMember]
        Ascending = 0,

        /// <summary>
        /// Descending order
        /// </summary>
        [EnumMember]
        Descending = 1

    }
}
