﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 04-23-2013
// ***********************************************************************
// <copyright file="LinqExtensions.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Collections.Generic;
using System.Reflection;

/// <summary>
/// The Linq namespace.
/// </summary>
namespace HS.Linq
{
    /// <summary>
    /// Defines the enumeration direction
    /// </summary>
    public enum EnumeratorDirection
    {
        /// <summary>
        /// Next item
        /// </summary>
        Next,
        /// <summary>
        /// Previous item
        /// </summary>
        Previous,
        /// <summary>
        /// First item
        /// </summary>
        First,
        /// <summary>
        /// Last item
        /// </summary>
        Last
    }

    /// <summary>
    /// Allows the extension methods (below) to pass out a list of
    /// items that link each child in a hierarchy to its parent.
    /// </summary>
    /// <typeparam name="parent">The type of the parent</typeparam>
    /// <typeparam name="child">The type of the child</typeparam>
    public class ParentChild<parent, child>
    {
        /// <summary>
        /// Defines the parent
        /// </summary>
        /// <value>The parent.</value>
        public parent Parent { get; set; }
        /// <summary>
        /// Defines the child
        /// </summary>
        /// <value>The child.</value>
        public child Child { get; set; }
    }

    /// <summary>
    /// Adds Linq-style extensions to standard enumerable classes
    /// </summary>
    public static class LinqExtensions2
    {

        /// <summary>
        /// Searches for the first, next, previous or last occurence of
        /// an item in a list, relative to a specific occurence.
        /// </summary>
        /// <typeparam name="T">The datatype to search through</typeparam>
        /// <param name="list">The list to search</param>
        /// <param name="direction">The direction to search (First, Next, Previous or Last)</param>
        /// <param name="relativeTo">The item to search relative to (If direction = Next or Previous)</param>
        /// <param name="func">The searching function</param>
        /// <returns>The specified occurrence or null if one doesn't exist</returns>
        public static T FindNext<T>(this IList<T> list,
            EnumeratorDirection direction, T relativeTo, Predicate<T> func)
        {

            int startIndex = 0;

            switch (direction)
            {

                case EnumeratorDirection.Next:

                    if (relativeTo != null)
                        startIndex = list.IndexOf(relativeTo) + 1;

                    for (int i = startIndex; i < list.Count; i++)
                    {
                        T item = list[i];
                        if (func(item)) return item;
                    }

                    break;

                case EnumeratorDirection.Previous:

                    if (relativeTo == null) return default(T);

                    startIndex = list.IndexOf(relativeTo) - 1;

                    for (int i = startIndex; i >= 0; i--)
                    {
                        T item = list[i];
                        if (func(item)) return item;
                    }

                    break;

                case EnumeratorDirection.First:

                    foreach (T item in list)
                    {
                        if (func(item)) return item;
                    }

                    break;

                case EnumeratorDirection.Last:

                    for (int i = list.Count - 1; i >= 0; i--)
                    {
                        T item = list[i];
                        if (func(item)) return item;
                    }

                    break;

            }

            return default(T);

        }

        /// <summary>
        /// Returns a list that contains the union of all child elements
        /// of all elements of a list.
        /// </summary>
        /// <typeparam name="parent">The parent type</typeparam>
        /// <typeparam name="child">The child type</typeparam>
        /// <param name="list">The list to search through</param>
        /// <param name="func">A function that takes a parent and returns
        /// a list of its children</param>
        /// <returns>The list of children</returns>
        public static IEnumerable<child> Children<parent, child>(
            this IEnumerable<parent> list, Func<parent, IEnumerable<child>> func)
        {

            foreach (parent p in list)
            {
                foreach (child c in func(p))
                {
                    yield return c;
                }
            }

        }

        /// <summary>
        /// Returns a list that contains the combination of each item in
        /// the list with each of its child elements
        /// </summary>
        /// <typeparam name="parent">The parent type</typeparam>
        /// <typeparam name="child">The child type</typeparam>
        /// <param name="list">The list to search through</param>
        /// <param name="func">A function that takes a parent and returns
        /// a list of its children</param>
        /// <returns>The list of parent/child pairs</returns>
        public static IEnumerable<ParentChild<parent, child>> JoinChildren<parent, child>(
            this IEnumerable<parent> list, Func<parent, IEnumerable<child>> func)
        {

            foreach (parent p in list)
            {
                foreach (child c in func(p))
                {
                    yield return new ParentChild<parent, child>() { Parent = p, Child = c };
                }
            }

        }

        /// <summary>
        /// Searches a list for all of its items children that match a
        /// specific condition
        /// </summary>
        /// <typeparam name="parent">The parent type</typeparam>
        /// <typeparam name="child">The child type</typeparam>
        /// <param name="list">The list to search</param>
        /// <param name="func">A function that takes a parent and returns
        /// a list of its children</param>
        /// <param name="selector">A function that evaluates a parent
        /// and a child to see if they are a match</param>
        /// <returns>The list of children that match the selection
        /// criteria</returns>
        public static IEnumerable<child> FindChildren<parent, child>(
            this IEnumerable<parent> list, Func<parent, IEnumerable<child>> func,
            Func<parent, child, bool> selector)
        {

            foreach (parent p in list)
            {

                IEnumerable<child> children = func(p);

                if (children != null)
                {
                    foreach (child c in children)
                    {
                        if (selector(p, c))
                        {
                            yield return c;
                        }
                    }
                }

            }

        }

        /// <summary>
        /// Returns an Expression which is an exact copy of the specified
        /// Expression except that all copies of any ParameterExpression
        /// are replaced with another ParameterExpression.
        /// </summary>
        /// <param name="e">The expression to search</param>
        /// <param name="p">The parameter to insert</param>
        /// <returns>The updated expression</returns>
        /// <remarks>This is useful for combining Lambda expressions. By
        /// default, if you have two Lambda expressions and each takes
        /// one parameter, they will each refer to a different parameters.
        /// Therefore, when you try to combine them, the resulting expression
        /// will require TWO parameters and not one. To fix this, you can
        /// use this method to replace the parameter of one of the expressions
        /// with the parameter of the other, then combine the new expressions
        /// using an AND or OR operation. The resulting expression will
        /// compare both Lambdas to a single parameter.</remarks>
        public static Expression ReplaceParameters(this Expression e, ParameterExpression p)
        {

            // This method checks each possible expression type. If the
            // expression is a ParameterExpression, p is returned. If
            // not, a copy of the expression is returned with this
            // function run on each of its subexpressions. Unfortunately,
            // each expression type (all 46 of them) has a different
            // method of retrieving its subexpressions which is why
            // each one has to be checked separately.

            Expression tmp = e;

            if (tmp == null) return null;

            switch (tmp.NodeType)
            {

                case ExpressionType.Add:
                    tmp = Expression.Add(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.AddChecked:
                    tmp = Expression.AddChecked(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.And:
                    tmp = Expression.And(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.AndAlso:
                    tmp = Expression.AndAlso(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.ArrayIndex:
                    tmp = Expression.ArrayIndex(
                        ((MethodCallExpression)tmp).Object.ReplaceParameters(p),
                        (from a in ((MethodCallExpression)tmp).Arguments
                         select a.ReplaceParameters(p)).AsEnumerable<Expression>());
                    break;

                case ExpressionType.ArrayLength:
                    tmp = Expression.ArrayLength(
                        ((UnaryExpression)tmp).Operand.ReplaceParameters(p));
                    break;

                case ExpressionType.Call:
                    tmp = Expression.Call(
                        ((MethodCallExpression)tmp).Object.ReplaceParameters(p),
                        ((MethodCallExpression)tmp).Method,
                        (from a in ((MethodCallExpression)tmp).Arguments
                         select a.ReplaceParameters(p)).AsEnumerable<Expression>());
                    break;

                case ExpressionType.Coalesce:
                    tmp = Expression.Coalesce(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        (LambdaExpression)(((BinaryExpression)tmp).Conversion.ReplaceParameters(p)));
                    break;

                case ExpressionType.Conditional:
                    tmp = Expression.Condition(
                        ((ConditionalExpression)tmp).Test.ReplaceParameters(p),
                        ((ConditionalExpression)tmp).IfTrue.ReplaceParameters(p),
                        ((ConditionalExpression)tmp).IfFalse.ReplaceParameters(p));
                    break;

                case ExpressionType.Constant:
                    break;

                case ExpressionType.Convert:
                    tmp = Expression.Convert(
                        ((UnaryExpression)tmp).Operand.ReplaceParameters(p),
                        ((UnaryExpression)tmp).Type,
                        ((UnaryExpression)tmp).Method);
                    break;

                case ExpressionType.ConvertChecked:
                    tmp = Expression.ConvertChecked(
                        ((UnaryExpression)tmp).Operand.ReplaceParameters(p),
                        ((UnaryExpression)tmp).Type,
                        ((UnaryExpression)tmp).Method);
                    break;

                case ExpressionType.Divide:
                    tmp = Expression.Divide(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Equal:
                    tmp = Expression.Equal(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.ExclusiveOr:
                    tmp = Expression.ExclusiveOr(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.GreaterThan:
                    tmp = Expression.GreaterThan(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.GreaterThanOrEqual:
                    tmp = Expression.GreaterThanOrEqual(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Invoke:
                    tmp = Expression.Invoke(
                        ((InvocationExpression)tmp).Expression.ReplaceParameters(p),
                        (from a in ((InvocationExpression)tmp).Arguments
                         select a.ReplaceParameters(p)).AsEnumerable<Expression>());
                    break;

                case ExpressionType.Lambda:
                    tmp = Expression.Lambda(
                        ((LambdaExpression)tmp).Body.ReplaceParameters(p),
                        (from a in ((LambdaExpression)tmp).Parameters
                         select p).ToArray<ParameterExpression>());
                    break;

                case ExpressionType.LeftShift:
                    tmp = Expression.LeftShift(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.LessThan:
                    tmp = Expression.LessThan(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.LessThanOrEqual:
                    tmp = Expression.LessThanOrEqual(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.ListInit:
                    tmp = Expression.ListInit(
                        (NewExpression)((ListInitExpression)tmp).NewExpression.ReplaceParameters(p),
                        (from i in ((ListInitExpression)tmp).Initializers
                         select i.ReplaceParameters(p)));
                    break;

                case ExpressionType.MemberAccess:
                    tmp = Expression.MakeMemberAccess(
                        ((MemberExpression)tmp).Expression.ReplaceParameters(p),
                        ((MemberExpression)tmp).Member);
                    break;

                case ExpressionType.MemberInit:
                    tmp = Expression.MemberInit(
                        (NewExpression)((MemberInitExpression)tmp).NewExpression.ReplaceParameters(p),
                        (from b in ((MemberInitExpression)tmp).Bindings
                         select b.ReplaceParameters(p)));
                    break;

                case ExpressionType.Modulo:
                    tmp = Expression.Modulo(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Multiply:
                    tmp = Expression.Multiply(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.MultiplyChecked:
                    tmp = Expression.MultiplyChecked(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Negate:
                    tmp = Expression.Negate(
                        ((UnaryExpression)tmp).Operand.ReplaceParameters(p),
                        ((UnaryExpression)tmp).Method);
                    break;

                case ExpressionType.NegateChecked:
                    tmp = Expression.NegateChecked(
                        ((UnaryExpression)tmp).Operand.ReplaceParameters(p),
                        ((UnaryExpression)tmp).Method);
                    break;

                case ExpressionType.New:
                    tmp = Expression.New(
                        ((NewExpression)tmp).Constructor,
                        (from a in ((NewExpression)tmp).Arguments
                         select a.ReplaceParameters(p)),
                        ((NewExpression)tmp).Members);
                    break;

                case ExpressionType.NewArrayBounds:
                    tmp = Expression.NewArrayBounds(
                        ((NewArrayExpression)tmp).Type,
                        (from x in ((NewArrayExpression)tmp).Expressions
                         select x.ReplaceParameters(p)));
                    break;

                case ExpressionType.NewArrayInit:
                    tmp = Expression.NewArrayInit(
                        ((NewArrayExpression)tmp).Type,
                        (from x in ((NewArrayExpression)tmp).Expressions
                         select x.ReplaceParameters(p)));
                    break;

                case ExpressionType.Not:
                    tmp = Expression.Not(
                        ((UnaryExpression)tmp).Operand.ReplaceParameters(p),
                        ((UnaryExpression)tmp).Method);
                    break;

                case ExpressionType.NotEqual:
                    tmp = Expression.NotEqual(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Or:
                    tmp = Expression.Or(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.OrElse:
                    tmp = Expression.OrElse(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Parameter:
                    tmp = p;
                    break;

                case ExpressionType.Power:
                    tmp = Expression.Power(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Quote:
                    tmp = Expression.Quote(((UnaryExpression)tmp).Operand.ReplaceParameters(p));
                    break;

                case ExpressionType.RightShift:
                    tmp = Expression.RightShift(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Subtract:
                    tmp = Expression.Subtract(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.SubtractChecked:
                    tmp = Expression.SubtractChecked(
                        ((BinaryExpression)tmp).Left.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Right.ReplaceParameters(p),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.TypeAs:
                    tmp = Expression.TypeAs(
                        ((UnaryExpression)tmp).Operand.ReplaceParameters(p),
                        ((UnaryExpression)tmp).Type);
                    break;

                case ExpressionType.TypeIs:
                    tmp = Expression.TypeIs(
                        ((TypeBinaryExpression)tmp).Expression.ReplaceParameters(p),
                        ((TypeBinaryExpression)tmp).TypeOperand);
                    break;

                case ExpressionType.UnaryPlus:
                    tmp = Expression.UnaryPlus(
                        ((UnaryExpression)tmp).Operand.ReplaceParameters(p),
                        ((UnaryExpression)tmp).Method);
                    break;

            }

            return tmp;

        }

        /// <summary>
        /// Returns an Expression which is an exact copy of the specified
        /// Expression except that all copies of any ParameterExpression
        /// are replaced with another ParameterExpression.
        /// </summary>
        /// <param name="binding">The binding.</param>
        /// <param name="p">The parameter to insert</param>
        /// <returns>The updated expression</returns>
        /// <remarks>This is useful for combining Lambda expressions. By
        /// default, if you have two Lambda expressions and each takes
        /// one parameter, they will each refer to a different parameters.
        /// Therefore, when you try to combine them, the resulting expression
        /// will require TWO parameters and not one. To fix this, you can
        /// use this method to replace the parameter of one of the expressions
        /// with the parameter of the other, then combine the new expressions
        /// using an AND or OR operation. The resulting expression will
        /// compare both Lambdas to a single parameter.</remarks>
        public static MemberBinding ReplaceParameters(this MemberBinding binding, ParameterExpression p)
        {

            if (binding == null) return null;

            switch (binding.BindingType)
            {

                case MemberBindingType.Assignment:
                    return Expression.Bind(
                        ((MemberAssignment)binding).Member,
                        ((MemberAssignment)binding).Expression.ReplaceParameters(p));

                case MemberBindingType.ListBinding:
                    return Expression.ListBind(
                        ((MemberListBinding)binding).Member,
                        (from i in ((MemberListBinding)binding).Initializers
                         select i.ReplaceParameters(p)));

                case MemberBindingType.MemberBinding:
                    return Expression.MemberBind(
                        ((MemberMemberBinding)binding).Member,
                        (from b in ((MemberMemberBinding)binding).Bindings
                         select b.ReplaceParameters(p)));

            }

            return null;

        }

        /// <summary>
        /// Returns an Expression which is an exact copy of the specified
        /// Expression except that all copies of any ParameterExpression
        /// are replaced with another ParameterExpression.
        /// </summary>
        /// <param name="elementInit">The element initialize.</param>
        /// <param name="p">The parameter to insert</param>
        /// <returns>The updated expression</returns>
        /// <remarks>This is useful for combining Lambda expressions. By
        /// default, if you have two Lambda expressions and each takes
        /// one parameter, they will each refer to a different parameters.
        /// Therefore, when you try to combine them, the resulting expression
        /// will require TWO parameters and not one. To fix this, you can
        /// use this method to replace the parameter of one of the expressions
        /// with the parameter of the other, then combine the new expressions
        /// using an AND or OR operation. The resulting expression will
        /// compare both Lambdas to a single parameter.</remarks>
        public static ElementInit ReplaceParameters(this ElementInit elementInit, ParameterExpression p)
        {

            if (elementInit == null) return null;

            return Expression.ElementInit(elementInit.AddMethod,
                (from a in elementInit.Arguments
                 select a.ReplaceParameters(p)));

        }

        /// <summary>
        /// Returns an Expression which is an exact copy of the specified
        /// Expression except that all copies of any ParameterExpression
        /// are replaced with another ParameterExpression.
        /// </summary>
        /// <param name="e">The expression to search</param>
        /// <param name="transformExpression">The transform expression.</param>
        /// <returns>The updated expression</returns>
        /// <remarks>This is useful for combining Lambda expressions. By
        /// default, if you have two Lambda expressions and each takes
        /// one parameter, they will each refer to a different parameters.
        /// Therefore, when you try to combine them, the resulting expression
        /// will require TWO parameters and not one. To fix this, you can
        /// use this method to replace the parameter of one of the expressions
        /// with the parameter of the other, then combine the new expressions
        /// using an AND or OR operation. The resulting expression will
        /// compare both Lambdas to a single parameter.</remarks>
        public static Expression Transform(this Expression e,
            Func<Expression, Expression> transformExpression)
        {

            // This method checks each possible expression type. If the
            // expression is a ParameterExpression, p is returned. If
            // not, a copy of the expression is returned with this
            // function run on each of its subexpressions. Unfortunately,
            // each expression type (all 46 of them) has a different
            // method of retrieving its subexpressions which is why
            // each one has to be checked separately.

            Expression tmp = transformExpression(e);

            if (tmp == null) return null;

            switch (tmp.NodeType)
            {

                case ExpressionType.Add:
                    tmp = Expression.Add(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.AddChecked:
                    tmp = Expression.AddChecked(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.And:
                    tmp = Expression.And(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.AndAlso:
                    tmp = Expression.AndAlso(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.ArrayIndex:
                    tmp = Expression.ArrayIndex(
                        ((MethodCallExpression)tmp).Object.Transform(transformExpression),
                        (from a in ((MethodCallExpression)tmp).Arguments
                         select a.Transform(transformExpression)).AsEnumerable<Expression>());
                    break;

                case ExpressionType.ArrayLength:
                    tmp = Expression.ArrayLength(
                        ((UnaryExpression)tmp).Operand.Transform(transformExpression));
                    break;

                case ExpressionType.Call:
                    tmp = Expression.Call(
                        ((MethodCallExpression)tmp).Object.Transform(transformExpression),
                        ((MethodCallExpression)tmp).Method,
                        (from a in ((MethodCallExpression)tmp).Arguments
                         select a.Transform(transformExpression)).AsEnumerable<Expression>());
                    break;

                case ExpressionType.Coalesce:
                    tmp = Expression.Coalesce(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        (LambdaExpression)(((BinaryExpression)tmp).Conversion.Transform(transformExpression)));
                    break;

                case ExpressionType.Conditional:
                    tmp = Expression.Condition(
                        ((ConditionalExpression)tmp).Test.Transform(transformExpression),
                        ((ConditionalExpression)tmp).IfTrue.Transform(transformExpression),
                        ((ConditionalExpression)tmp).IfFalse.Transform(transformExpression));
                    break;

                case ExpressionType.Constant:
                    break;

                case ExpressionType.Convert:
                    tmp = Expression.Convert(
                        ((UnaryExpression)tmp).Operand.Transform(transformExpression),
                        ((UnaryExpression)tmp).Type,
                        ((UnaryExpression)tmp).Method);
                    break;

                case ExpressionType.ConvertChecked:
                    tmp = Expression.ConvertChecked(
                        ((UnaryExpression)tmp).Operand.Transform(transformExpression),
                        ((UnaryExpression)tmp).Type,
                        ((UnaryExpression)tmp).Method);
                    break;

                case ExpressionType.Divide:
                    tmp = Expression.Divide(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Equal:
                    tmp = Expression.Equal(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.ExclusiveOr:
                    tmp = Expression.ExclusiveOr(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.GreaterThan:
                    tmp = Expression.GreaterThan(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.GreaterThanOrEqual:
                    tmp = Expression.GreaterThanOrEqual(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Invoke:
                    tmp = Expression.Invoke(
                        ((InvocationExpression)tmp).Expression.Transform(transformExpression),
                        (from a in ((InvocationExpression)tmp).Arguments
                         select a.Transform(transformExpression)).AsEnumerable<Expression>());
                    break;

                case ExpressionType.Lambda:
                    tmp = Expression.Lambda(
                        ((LambdaExpression)tmp).Body.Transform(transformExpression),
                        (from a in ((LambdaExpression)tmp).Parameters
                         select (ParameterExpression)a.Transform(transformExpression)).ToArray<ParameterExpression>());
                    break;

                case ExpressionType.LeftShift:
                    tmp = Expression.LeftShift(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.LessThan:
                    tmp = Expression.LessThan(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.LessThanOrEqual:
                    tmp = Expression.LessThanOrEqual(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.ListInit:
                    tmp = Expression.ListInit(
                        (NewExpression)((ListInitExpression)tmp).NewExpression.Transform(transformExpression),
                        (from i in ((ListInitExpression)tmp).Initializers
                         select i.Transform(transformExpression)));
                    break;

                case ExpressionType.MemberAccess:
                    tmp = Expression.MakeMemberAccess(
                        ((MemberExpression)tmp).Expression.Transform(transformExpression),
                        ((MemberExpression)tmp).Member);
                    break;

                case ExpressionType.MemberInit:
                    tmp = Expression.MemberInit(
                        (NewExpression)((MemberInitExpression)tmp).NewExpression.Transform(transformExpression),
                        (from b in ((MemberInitExpression)tmp).Bindings
                         select b.Transform(transformExpression)));
                    break;

                case ExpressionType.Modulo:
                    tmp = Expression.Modulo(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Multiply:
                    tmp = Expression.Multiply(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.MultiplyChecked:
                    tmp = Expression.MultiplyChecked(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Negate:
                    tmp = Expression.Negate(
                        ((UnaryExpression)tmp).Operand.Transform(transformExpression),
                        ((UnaryExpression)tmp).Method);
                    break;

                case ExpressionType.NegateChecked:
                    tmp = Expression.NegateChecked(
                        ((UnaryExpression)tmp).Operand.Transform(transformExpression),
                        ((UnaryExpression)tmp).Method);
                    break;

                case ExpressionType.New:
                    tmp = Expression.New(
                        ((NewExpression)tmp).Constructor,
                        (from a in ((NewExpression)tmp).Arguments
                         select a.Transform(transformExpression)),
                        ((NewExpression)tmp).Members);
                    break;

                case ExpressionType.NewArrayBounds:
                    tmp = Expression.NewArrayBounds(
                        ((NewArrayExpression)tmp).Type,
                        (from x in ((NewArrayExpression)tmp).Expressions
                         select x.Transform(transformExpression)));
                    break;

                case ExpressionType.NewArrayInit:
                    tmp = Expression.NewArrayInit(
                        ((NewArrayExpression)tmp).Type,
                        (from x in ((NewArrayExpression)tmp).Expressions
                         select x.Transform(transformExpression)));
                    break;

                case ExpressionType.Not:
                    tmp = Expression.Not(
                        ((UnaryExpression)tmp).Operand.Transform(transformExpression),
                        ((UnaryExpression)tmp).Method);
                    break;

                case ExpressionType.NotEqual:
                    tmp = Expression.NotEqual(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).IsLiftedToNull,
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Or:
                    tmp = Expression.Or(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.OrElse:
                    tmp = Expression.OrElse(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Parameter:
                    break;

                case ExpressionType.Power:
                    tmp = Expression.Power(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Quote:
                    tmp = Expression.Quote(((UnaryExpression)tmp).Operand.Transform(transformExpression));
                    break;

                case ExpressionType.RightShift:
                    tmp = Expression.RightShift(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.Subtract:
                    tmp = Expression.Subtract(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.SubtractChecked:
                    tmp = Expression.SubtractChecked(
                        ((BinaryExpression)tmp).Left.Transform(transformExpression),
                        ((BinaryExpression)tmp).Right.Transform(transformExpression),
                        ((BinaryExpression)tmp).Method);
                    break;

                case ExpressionType.TypeAs:
                    tmp = Expression.TypeAs(
                        ((UnaryExpression)tmp).Operand.Transform(transformExpression),
                        ((UnaryExpression)tmp).Type);
                    break;

                case ExpressionType.TypeIs:
                    tmp = Expression.TypeIs(
                        ((TypeBinaryExpression)tmp).Expression.Transform(transformExpression),
                        ((TypeBinaryExpression)tmp).TypeOperand);
                    break;

                case ExpressionType.UnaryPlus:
                    tmp = Expression.UnaryPlus(
                        ((UnaryExpression)tmp).Operand.Transform(transformExpression),
                        ((UnaryExpression)tmp).Method);
                    break;

            }

            return tmp;

        }

        /// <summary>
        /// Returns an Expression which is an exact copy of the specified
        /// Expression except that all copies of any ParameterExpression
        /// are replaced with another ParameterExpression.
        /// </summary>
        /// <param name="binding">The binding.</param>
        /// <param name="transformExpression">The transform expression.</param>
        /// <returns>The updated expression</returns>
        /// <remarks>This is useful for combining Lambda expressions. By
        /// default, if you have two Lambda expressions and each takes
        /// one parameter, they will each refer to a different parameters.
        /// Therefore, when you try to combine them, the resulting expression
        /// will require TWO parameters and not one. To fix this, you can
        /// use this method to replace the parameter of one of the expressions
        /// with the parameter of the other, then combine the new expressions
        /// using an AND or OR operation. The resulting expression will
        /// compare both Lambdas to a single parameter.</remarks>
        public static MemberBinding Transform(this MemberBinding binding,
            Func<Expression, Expression> transformExpression)
        {

            if (binding == null) return null;

            switch (binding.BindingType)
            {

                case MemberBindingType.Assignment:
                    return Expression.Bind(
                        ((MemberAssignment)binding).Member,
                        ((MemberAssignment)binding).Expression.Transform(transformExpression));

                case MemberBindingType.ListBinding:
                    return Expression.ListBind(
                        ((MemberListBinding)binding).Member,
                        (from i in ((MemberListBinding)binding).Initializers
                         select i.Transform(transformExpression)));

                case MemberBindingType.MemberBinding:
                    return Expression.MemberBind(
                        ((MemberMemberBinding)binding).Member,
                        (from b in ((MemberMemberBinding)binding).Bindings
                         select b.Transform(transformExpression)));

            }

            return null;

        }

        /// <summary>
        /// Returns an Expression which is an exact copy of the specified
        /// Expression except that all copies of any ParameterExpression
        /// are replaced with another ParameterExpression.
        /// </summary>
        /// <param name="elementInit">The element initialize.</param>
        /// <param name="transformExpression">The transform expression.</param>
        /// <returns>The updated expression</returns>
        /// <remarks>This is useful for combining Lambda expressions. By
        /// default, if you have two Lambda expressions and each takes
        /// one parameter, they will each refer to a different parameters.
        /// Therefore, when you try to combine them, the resulting expression
        /// will require TWO parameters and not one. To fix this, you can
        /// use this method to replace the parameter of one of the expressions
        /// with the parameter of the other, then combine the new expressions
        /// using an AND or OR operation. The resulting expression will
        /// compare both Lambdas to a single parameter.</remarks>
        public static ElementInit Transform(this ElementInit elementInit,
            Func<Expression, Expression> transformExpression)
        {

            if (elementInit == null) return null;

            return Expression.ElementInit(elementInit.AddMethod,
                (from a in elementInit.Arguments
                 select a.Transform(transformExpression)));

        }

        /// <summary>
        /// Overloads the Linq Distinct&lt;T&gt; method to accept a lambda expression
        /// instead of an IEqualityComparer. See <see cref="IEnumerable[T].Distinct[T]" />
        /// for more information
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list">The list.</param>
        /// <param name="comparisonExpression">The comparison expression.</param>
        /// <returns>IEnumerable{``0}.</returns>
        public static IEnumerable<T> Distinct<T>(this IEnumerable<T> list, Func<T, T, bool> comparisonExpression)
        {
            return list.Distinct(new LambdaEqualityComparer<T>(comparisonExpression));
        }

        /// <summary>
        /// Runs a function against every item in a list. If they all return
        /// the same value, the value is returned. If not, default(TResult)
        /// is returned.
        /// </summary>
        /// <typeparam name="TItem">The type of the attribute item.</typeparam>
        /// <typeparam name="TResult">The type of the attribute result.</typeparam>
        /// <param name="list">The list.</param>
        /// <param name="selector">The selector.</param>
        /// <returns>``1.</returns>
        public static TResult Rollup<TItem, TResult>(this IEnumerable<TItem> list,
            Func<TItem, TResult> selector)
        {
            return list.Rollup(selector, default(TResult));
        }

        /// <summary>
        /// Runs a function against every item in a list. If they all return
        /// the same value, the value is returned. If not, conflictValue
        /// is returned.
        /// </summary>
        /// <typeparam name="TItem">The type of the attribute item.</typeparam>
        /// <typeparam name="TResult">The type of the attribute result.</typeparam>
        /// <param name="list">The list.</param>
        /// <param name="selector">The selector.</param>
        /// <param name="conflictValue">The conflict value.</param>
        /// <returns>``1.</returns>
        public static TResult Rollup<TItem, TResult>(this IEnumerable<TItem> list,
            Func<TItem, TResult> selector, TResult conflictValue)
        {

            if (list == null) return conflictValue;

            TItem first = list.FirstOrDefault();

            if (first == null) return conflictValue;

            TResult value = selector(first);

            if (value == null) return conflictValue;

            foreach (TItem item in list)
            {

                TResult otherValue = selector(item);

                if (!value.Equals(otherValue))
                    return conflictValue;

            }

            return value;

        }

        /// <summary>
        /// Orders the by.
        /// </summary>
        /// <typeparam name="TEntity">The type of the attribute entity.</typeparam>
        /// <param name="source">The source.</param>
        /// <param name="fieldName">Name of the field.</param>
        /// <param name="sortOrder">The sort order.</param>
        /// <returns>IOrderedQueryable{``0}.</returns>
        public static IOrderedQueryable<TEntity> OrderBy<TEntity>(this IQueryable<TEntity> source, string fieldName, SortOrder sortOrder) where TEntity : class
        {
            switch (sortOrder)
            {
                case SortOrder.Ascending:
                    return source.OrderUsingSortExpression(fieldName + " ASC");
                case SortOrder.Descending:
                    return source.OrderUsingSortExpression(fieldName + " DESC");
                default:
                    return source.OrderUsingSortExpression(fieldName);
            }
        }

    }
    /// <summary>
    /// Class LinqExtensions.
    /// </summary>
    public static class LinqExtensions
    {
        #region Private expression tree helpers

        /// <summary>
        /// Generates the selector.
        /// </summary>
        /// <typeparam name="TEntity">The type of the attribute entity.</typeparam>
        /// <param name="propertyName">Name of the property.</param>
        /// <param name="resultType">Type of the result.</param>
        /// <returns>LambdaExpression.</returns>
        private static LambdaExpression GenerateSelector<TEntity>(String propertyName, out Type resultType) where TEntity : class
        {
            // Create a parameter to pass into the Lambda expression (Entity => Entity.OrderByField).
            var parameter = Expression.Parameter(typeof(TEntity), "Entity");
            //  create the selector part, but support child properties
            PropertyInfo property;
            Expression propertyAccess;
            if (propertyName.Contains('.'))
            {
                // support to be sorted on child fields.
                String[] childProperties = propertyName.Split('.');
                property = typeof(TEntity).GetProperty(childProperties[0]);
                propertyAccess = Expression.MakeMemberAccess(parameter, property);
                for (int i = 1; i < childProperties.Length; i++)
                {
                    property = property.PropertyType.GetProperty(childProperties[i]);
                    propertyAccess = Expression.MakeMemberAccess(propertyAccess, property);
                }
            }
            else
            {
                property = typeof(TEntity).GetProperty(propertyName);
                propertyAccess = Expression.MakeMemberAccess(parameter, property);
            }
            resultType = property.PropertyType;
            // Create the order by expression.
            return Expression.Lambda(propertyAccess, parameter);
        }
        /// <summary>
        /// Generates the method call.
        /// </summary>
        /// <typeparam name="TEntity">The type of the attribute entity.</typeparam>
        /// <param name="source">The source.</param>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="fieldName">Name of the field.</param>
        /// <returns>MethodCallExpression.</returns>
        private static MethodCallExpression GenerateMethodCall<TEntity>(IQueryable<TEntity> source, string methodName, String fieldName) where TEntity : class
        {
            Type type = typeof(TEntity);
            Type selectorResultType;
            LambdaExpression selector = GenerateSelector<TEntity>(fieldName, out selectorResultType);
            MethodCallExpression resultExp = Expression.Call(typeof(Queryable), methodName,
                            new Type[] { type, selectorResultType },
                            source.Expression, Expression.Quote(selector));
            return resultExp;
        }
        #endregion
        /// <summary>
        /// Orders the by.
        /// </summary>
        /// <typeparam name="TEntity">The type of the attribute entity.</typeparam>
        /// <param name="source">The source.</param>
        /// <param name="fieldName">Name of the field.</param>
        /// <returns>IOrderedQueryable{``0}.</returns>
        public static IOrderedQueryable<TEntity> OrderBy<TEntity>(this IQueryable<TEntity> source, string fieldName) where TEntity : class
        {
            MethodCallExpression resultExp = GenerateMethodCall<TEntity>(source, "OrderBy", fieldName);
            return source.Provider.CreateQuery<TEntity>(resultExp) as IOrderedQueryable<TEntity>;
        }

        /// <summary>
        /// Orders the by descending.
        /// </summary>
        /// <typeparam name="TEntity">The type of the attribute entity.</typeparam>
        /// <param name="source">The source.</param>
        /// <param name="fieldName">Name of the field.</param>
        /// <returns>IOrderedQueryable{``0}.</returns>
        public static IOrderedQueryable<TEntity> OrderByDescending<TEntity>(this IQueryable<TEntity> source, string fieldName) where TEntity : class
        {
            MethodCallExpression resultExp = GenerateMethodCall<TEntity>(source, "OrderByDescending", fieldName);
            return source.Provider.CreateQuery<TEntity>(resultExp) as IOrderedQueryable<TEntity>;
        }
        /// <summary>
        /// Thens the by.
        /// </summary>
        /// <typeparam name="TEntity">The type of the attribute entity.</typeparam>
        /// <param name="source">The source.</param>
        /// <param name="fieldName">Name of the field.</param>
        /// <returns>IOrderedQueryable{``0}.</returns>
        public static IOrderedQueryable<TEntity> ThenBy<TEntity>(this IOrderedQueryable<TEntity> source, string fieldName) where TEntity : class
        {
            MethodCallExpression resultExp = GenerateMethodCall<TEntity>(source, "ThenBy", fieldName);
            return source.Provider.CreateQuery<TEntity>(resultExp) as IOrderedQueryable<TEntity>;
        }
        /// <summary>
        /// Thens the by descending.
        /// </summary>
        /// <typeparam name="TEntity">The type of the attribute entity.</typeparam>
        /// <param name="source">The source.</param>
        /// <param name="fieldName">Name of the field.</param>
        /// <returns>IOrderedQueryable{``0}.</returns>
        public static IOrderedQueryable<TEntity> ThenByDescending<TEntity>(this IOrderedQueryable<TEntity> source, string fieldName) where TEntity : class
        {
            MethodCallExpression resultExp = GenerateMethodCall<TEntity>(source, "ThenByDescending", fieldName);
            return source.Provider.CreateQuery<TEntity>(resultExp) as IOrderedQueryable<TEntity>;
        }
        /// <summary>
        /// Orders the using sort expression.
        /// </summary>
        /// <typeparam name="TEntity">The type of the attribute entity.</typeparam>
        /// <param name="source">The source.</param>
        /// <param name="sortExpression">The sort expression.</param>
        /// <returns>IOrderedQueryable{``0}.</returns>
        public static IOrderedQueryable<TEntity> OrderUsingSortExpression<TEntity>(this IQueryable<TEntity> source, string sortExpression) where TEntity : class
        {
            String[] orderFields = sortExpression.Split(',');
            IOrderedQueryable<TEntity> result = null;
            for (int currentFieldIndex = 0; currentFieldIndex < orderFields.Length; currentFieldIndex++)
            {
                String[] expressionPart = orderFields[currentFieldIndex].Trim().Split(' ');
                String sortField = expressionPart[0];
                Boolean sortDescending = (expressionPart.Length == 2) && (expressionPart[1].Equals("DESC", StringComparison.OrdinalIgnoreCase));
                if (sortDescending)
                {
                    result = currentFieldIndex == 0 ? source.OrderByDescending(sortField) : result.ThenByDescending(sortField);
                }
                else
                {
                    result = currentFieldIndex == 0 ? source.OrderBy(sortField) : result.ThenBy(sortField);
                }
            }
            return result;
        }
    }
    /// <summary>
    /// Used to convert a Lambda expression to an IEqualityComparer
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class LambdaEqualityComparer<T> : IEqualityComparer<T>
    {

        /// <summary>
        /// Gets or sets the comparison expression.
        /// </summary>
        /// <value>The comparison expression.</value>
        public Func<T, T, bool> ComparisonExpression { get; set; }

        #region IEqualityComparer<T> Members

        /// <summary>
        /// Determines whether the specified objects are equal.
        /// </summary>
        /// <param name="x">The first object of type <paramref name="T" /> to compare.</param>
        /// <param name="y">The second object of type <paramref name="T" /> to compare.</param>
        /// <returns>true if the specified objects are equal; otherwise, false.</returns>
        public bool Equals(T x, T y)
        {
            return ComparisonExpression(x, y);
        }

        /// <summary>
        /// Returns a hash code for this instance.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object" /> for which a hash code is to be returned.</param>
        /// <returns>A hash code for this instance, suitable for use in hashing algorithms and data structures like a hash table.</returns>
        public int GetHashCode(T obj)
        {
            return obj.GetHashCode();
        }

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="LambdaEqualityComparer{T}"/> class.
        /// </summary>
        /// <param name="comparisonExpression">The comparison expression.</param>
        public LambdaEqualityComparer(Func<T, T, bool> comparisonExpression)
        {
            ComparisonExpression = comparisonExpression;
        }

    }

}


