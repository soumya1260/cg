﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 04-23-2013
// ***********************************************************************
// <copyright file="HsSpecificExtensionMethods.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Text.RegularExpressions;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Class HsSpecificExtensionMethods.
    /// </summary>
    public static class HsSpecificExtensionMethods
    {
        /// <summary>
        /// Parses the code.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>System.String.</returns>
        public static string ParseCode(this string source)
        {
            var regex = new Regex(@"\[[^\]]*\]");

            Match matches = regex.Match(source);

            if (matches.Success)
            {
                string code = matches.Value.Replace("[", "");
                code = code.Replace("]", "");
                return code;
            }

            return source;
        }

        /// <summary>
        /// Parses the description.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>System.String.</returns>
        public static string ParseDesc(this string source)
        {
            string result = source;

            var regex =
                new Regex(@"\[[^\]]*\]");

            Match matches = regex.Match(source);

            if (matches.Success)
            {
                result = source.Substring(matches.Value.Length).Trim();
            }
            else
            {
                return "";
            }

            return result;
        }

        /// <summary>
        /// Parses the provider description.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>System.String.</returns>
        public static string ParseProviderDesc(this string source)
        {
            string result = source;

            var regex =
                new Regex(@"\[[^\]]*\]");

            Match matches = regex.Match(source);

            if (matches.Success)
            {
                result = source.Substring(matches.Value.Length).Trim();
            }
            else
            {
                return source;
            }

            return result;
        }

        /// <summary>
        /// Formats the code description.
        /// </summary>
        /// <param name="code">The code.</param>
        /// <param name="desc">The description.</param>
        /// <returns>System.String.</returns>
        public static string FormatCodeDesc(this string code, string desc)
        {
            if (desc.IsNotNullOrEmpty())
            {
            return string.Format("[{0}] {1}", code, desc);
        }
            else
            {
                return string.Format("{0}", code);
            }
        }

        /// <summary>
        /// Cleans the phone number.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>System.String.</returns>
        public static string CleanPhoneNumber(this string source)
        {
            if (source.IsNotNullOrEmpty())
            {
                return source.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "").Replace(" ", "");
            }
            else
            {
                return "";
            }
        }

        /// <summary>
        /// Cleans the string.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>System.String.</returns>
        public static string CleanString(this string source)
        {
            if (source.IsNotNullOrEmpty())
            {
                return source.Replace(",", "").Replace(".", "");
            }
            else
            {
                return "";
            }
        }

        /// <summary>
        /// Formats the phone number.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>System.String.</returns>
        public static string FormatPhoneNumber(this string source)
        {
            if (source.IsNotNullOrEmpty() )
            {
                if (source.Length == 10)
                {
                    return "(" + source.Substring(0, 3) + ") " + source.Substring(3, 3) + "-" + source.Right(4);
                }
                else
                {
                    return source;
                }
            }
            else
            {
                return "";
            }
        }
    }
}