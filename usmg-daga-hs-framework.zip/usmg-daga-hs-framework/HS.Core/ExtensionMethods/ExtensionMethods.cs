﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 04-23-2013
// ***********************************************************************
// <copyright file="ExtensionMethods.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Text;
using System.Data.SqlTypes;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Generic collection of extension methods.
    /// </summary>
    [Obsolete("These extension methods generally confuse code analysis tools (Roslyn, SonarQube, ReSharper) and should not be used.", false)]
	public static class ExtensionMethods
    {
        /// <summary>
        /// Spans a method on a seperate thread with a default callback to end invoke
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="action">The action.</param>
        /// <param name="item">The item.</param>
        public static void ToAsync<T>(this Action<T> action, T item)
        {
            Task task = Task.Factory.StartNew(
                () =>
                {
                    action(item);
                });
        }

        /// <summary>
        /// Automatics the asynchronous.
        /// </summary>
        /// <param name="action">The action.</param>
        public static void ToAsync(this Action action)
        {
            Task.Factory.StartNew(action);
        }

        #region try extensions

        /// <summary>
        /// Tries the specified target.
        /// </summary>
        /// <typeparam name="TTarget">The type of the attribute target.</typeparam>
        /// <typeparam name="TResult">The type of the attribute result.</typeparam>
        /// <param name="target">The target.</param>
        /// <param name="func">The function.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns>``1.</returns>
        public static TResult Try<TTarget, TResult>(this TTarget target, Func<TTarget, TResult> func, TResult defaultValue)
        {
            if (object.ReferenceEquals(target, null) || object.ReferenceEquals(target, DBNull.Value))
            {
                return defaultValue;
            }
            return func(target);
        }

        /// <summary>
        /// If the TTarget target isnull, the result of default(TResult) is returned.
        /// Else, the method will execute the lambda expression, Func&lt;TTarget, TResult&gt; func, against TTarget target
        /// and return the result of type TResult.
        /// </summary>
        /// <typeparam name="TTarget">The System.Type of the Target object</typeparam>
        /// <typeparam name="TResult">The System.Type of the return value</typeparam>
        /// <param name="target">The reference to the Target object</param>
        /// <param name="func">The Lambda Expression to be executed against the Target</param>
        /// <returns>TResult</returns>
        public static TResult Try<TTarget, TResult>(this TTarget target, Func<TTarget, TResult> func)
        {
            if (object.ReferenceEquals(target, null) || object.ReferenceEquals(target, DBNull.Value))
            {
                return default(TResult);
            }
            return func(target);
        }

        /// <summary>
        /// Tries the specified target.
        /// </summary>
        /// <typeparam name="TTarget">The type of the attribute target.</typeparam>
        /// <param name="target">The target.</param>
        /// <param name="func">The function.</param>
        public static void Try<TTarget>(this TTarget target, Action<TTarget> func)
        {
            if (!(object.ReferenceEquals(target, null) || object.ReferenceEquals(target, DBNull.Value)))
            {
                func(target);
            }
        }

        /// <summary>
        /// Tries the specified target.
        /// </summary>
        /// <typeparam name="TTarget">The type of the attribute target.</typeparam>
        /// <param name="target">The target.</param>
        /// <param name="notNullFunc">The not null function.</param>
        /// <param name="nullFunc">The null function.</param>
        public static void Try<TTarget>(this TTarget target, Action<TTarget> notNullFunc, Action nullFunc)
        {
            if (!(object.ReferenceEquals(target, null) || object.ReferenceEquals(target, DBNull.Value)))
            {
                notNullFunc(target);
            }
            else
            {
                nullFunc();
            }
        }

        /// <summary>
        /// Tries the specified target.
        /// </summary>
        /// <typeparam name="TTarget">The type of the attribute target.</typeparam>
        /// <typeparam name="TResult">The type of the attribute result.</typeparam>
        /// <param name="target">The target.</param>
        /// <param name="notNullFunc">The not null function.</param>
        /// <param name="nullFunc">The null function.</param>
        /// <returns>``1.</returns>
        public static TResult Try<TTarget, TResult>(this TTarget target, Func<TTarget, TResult> notNullFunc, Func<TTarget, TResult> nullFunc)
        {
            if (!object.ReferenceEquals(target, null) && !object.ReferenceEquals(target, DBNull.Value)) return notNullFunc(target);
            return nullFunc(target);
        }

        #endregion

        #region conditionals

        /// <summary>
        /// IF the conditional applied to the TTarget target is true, return trueValue, else return falseValue
        /// </summary>
        /// <typeparam name="TTarget">the target Type</typeparam>
        /// <typeparam name="TResult">the result Type</typeparam>
        /// <param name="target">the target object</param>
        /// <param name="conditional">the conditional statement to check</param>
        /// <param name="trueValue">the value to return if the conditional evaluates to true</param>
        /// <param name="falseValue">the value to return if the conditional evaluates to false</param>
        /// <returns>``1.</returns>
        public static TResult IIF<TTarget, TResult>(this TTarget target, Func<TTarget, bool> conditional, TResult trueValue, TResult falseValue)
        {
            if (target == null) return default(TResult);
            return conditional(target) ? trueValue : falseValue;
        }

        /// <summary>
        /// IF the conditional applied to the TTarget target is true, return the result of trueFunc, else return the value of falseFunc
        /// </summary>
        /// <typeparam name="TTarget">the target Type</typeparam>
        /// <typeparam name="TResult">the result Type</typeparam>
        /// <param name="target">the target object</param>
        /// <param name="conditional">the conditional statement to check</param>
        /// <param name="trueFunc">the function to execute if the conditional evaluates to true</param>
        /// <param name="falseFunc">the function to execute if the conditional evaluates to false</param>
        /// <returns>``1.</returns>
        public static TResult IIF<TTarget, TResult>(this TTarget target, Func<TTarget, bool> conditional, Func<TTarget, TResult> trueFunc, Func<TTarget, TResult> falseFunc)
        {
            if (target == null) return default(TResult);
            return conditional(target) ? trueFunc(target) : falseFunc(target);
        }

        /// <summary>
        /// IF the conditional applied to the TTarget target is true, execute the trueAction, else execute the falseAction
        /// </summary>
        /// <typeparam name="TTarget">the target Type</typeparam>
        /// <param name="target">the target object</param>
        /// <param name="conditional">the conditional statement to check</param>
        /// <param name="trueAction">the action to execute if the conditional evaluates to true</param>
        /// <param name="falseAction">the action to execute if the conditional evaluates to false</param>
        /// <exception cref="System.ArgumentNullException">target</exception>
        public static void IIF<TTarget>(this TTarget target, Func<TTarget, bool> conditional, Action<TTarget> trueAction, Action<TTarget> falseAction)
        {
            if (target == null) throw new ArgumentNullException("target");
            if(conditional(target))
            {
                trueAction(target);
            }
            else
            {
                falseAction(target);
            }
            return;
        }

        #endregion

        #region enumeration

        /// <summary>
        /// Adds the range uniquely.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TKey">The type of the attribute key.</typeparam>
        /// <param name="target">The target.</param>
        /// <param name="source">The source.</param>
        /// <param name="keySelector">The key selector.</param>
        /// <exception cref="System.NullReferenceException">target</exception>
        public static void AddRangeUniquely<T, TKey>(this IList<T> target, IList<T> source, Func<T, TKey> keySelector)
        {
            if (target == null) throw new NullReferenceException("target");
            Dictionary<TKey, T> targetDict = target.ToDictionary<T, TKey>(keySelector);

            source.ForEach(f =>
            {
                if (!targetDict.ContainsKey(keySelector(f)))
                {
                    target.Add(f);
                }
            });

        }

        /// <summary>
        /// Fors the each.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="target">The target.</param>
        /// <param name="func">The function.</param>
        public static void ForEach<T>(this IEnumerable<T> target, Action<T> func)
        {
            if (target == null) return;
            foreach (T item in target)
            {
                func(item);
            }
        }

        /// <summary>
        /// Tries the get.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="target">The target.</param>
        /// <param name="index">The index.</param>
        /// <returns>``0.</returns>
        public static T TryGet<T>(this IList<T> target, int index)
        {
            return target.Try(t =>
            {
                if (t.Count() > index)
                {
                    return (T)target[index];
                }
                return default(T);
            });
        }

        /// <summary>
        /// Automatics the SQL information list.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="target">The target.</param>
        /// <param name="valueSelector">The value selector.</param>
        /// <returns>System.String.</returns>
        /// <exception cref="System.ArgumentNullException">target</exception>
        public static string ToSQLInList<T>(this IEnumerable<T> target, Func<T, string> valueSelector)
        {
            if (target == null) throw new ArgumentNullException("target");
            string result = "(";

            target.ForEach(i =>
            {
                if (result != "(") result = string.Concat(result, ",");
                result = string.Concat(result, "'", valueSelector(i), "'");
            });
            result = string.Concat(result, ")");

            return result;
        }


        #endregion

        #region date extensions

        /// <summary>
        /// Gets the first day of year.
        /// </summary>
        /// <param name="target">The target.</param>
        /// <returns>DateTime.</returns>
        /// <exception cref="System.ArgumentNullException">target</exception>
        public static DateTime GetFirstDayOfYear(this DateTime target)
        {
            if (target == null) throw new ArgumentNullException("target");
            return new DateTime(target.Year, 1, 1);
        }

        /// <summary>
        /// Gets the last day of month.
        /// </summary>
        /// <param name="target">The target.</param>
        /// <returns>DateTime.</returns>
        /// <exception cref="System.ArgumentNullException">target</exception>
        public static DateTime GetLastDayOfMonth(this DateTime target)
        {
            if (target == null) throw new ArgumentNullException("target");
            return new DateTime(target.Year, target.Month, DateTime.DaysInMonth(target.Year, target.Month));
        }

        /// <summary>
        /// Gets the age.
        /// </summary>
        /// <param name="target">The target.</param>
        /// <returns>System.Int32.</returns>
        /// <exception cref="System.ArgumentNullException">target</exception>
        public static int GetAge(this DateTime target)
        {
            if (target == null) throw new ArgumentNullException("target");
            DateTime now = DateTime.Now;
            int age = now.Year - target.Year;
            if (now.Month < target.Month || (now.Month == target.Month && now.Day < target.Day))
            {
                age--;
            }
            return age;
        }
        /// <summary>
        /// Gets the months since.
        /// </summary>
        /// <param name="target">The target.</param>
        /// <param name="beginning">The beginning.</param>
        /// <returns>System.Int32.</returns>
        /// <exception cref="System.ArgumentNullException">target</exception>
        public static int GetMonthsSince(this DateTime target, DateTime beginning)
        {
            if (target == null) throw new ArgumentNullException("target");
            int years = target.Year - beginning.Year;
            if (beginning.Month > target.Month)
            {
                years--;
            }
            return years * 12 + (target.Month - beginning.Month);
        }

        /// <summary>
        /// Gets the valid SQL server date time display.
        /// </summary>
        /// <param name="target">The target.</param>
        /// <returns>System.String.</returns>
        /// <exception cref="System.ArgumentNullException">target</exception>
        public static string GetValidSQLServerDateTimeDisplay(this DateTime target)
        {
            if (target == null) throw new ArgumentNullException("target");
            string result;
            if (target <= SqlDateTime.MinValue.Value || target >= SqlDateTime.MaxValue.Value)
            {
                result = string.Empty;
            }
            else
            {
                result = target.ToString("MM/dd/yyyy hh:mm tt");
            }
            return result;
        }

        /// <summary>
        /// Gets the valid SQL server date display.
        /// </summary>
        /// <param name="target">The target.</param>
        /// <returns>System.String.</returns>
        /// <exception cref="System.ArgumentNullException">target</exception>
        public static string GetValidSQLServerDateDisplay(this DateTime target)
        {
            if (target == null) throw new ArgumentNullException("target");
            string result;
            if (target <= SqlDateTime.MinValue.Value || target >= SqlDateTime.MaxValue.Value)
            {
                result = string.Empty;
            }
            else
            {
                result = target.ToShortDateString();
            }
            return result;
        }

        /// <summary>
        /// Gets the valid SQL server date display.
        /// </summary>
        /// <param name="target">The target.</param>
        /// <returns>System.String.</returns>
        /// <exception cref="System.ArgumentNullException">target</exception>
        public static string GetValidSQLServerDateDisplay(this DateTime? target)
        {
            if (target == null) throw new ArgumentNullException("target");
            bool hasValue = false;
            if (target.HasValue)
            {
                DateTime arg_1A_0 = target.Value;
                hasValue = true;
            }
            else
            {
                hasValue = false;
            }
            string result;
            if (!hasValue)
            {
                result = string.Empty;
            }
            else
            {
                if (target.Value <= SqlDateTime.MinValue.Value || target.Value >= SqlDateTime.MaxValue.Value)
                {
                    result = string.Empty;
                }
                else
                {
                    result = target.Value.ToShortDateString();
                }
            }
            return result;
        }

        #endregion

        /// <summary>
        /// Gets the file extension.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>System.String.</returns>
        public static string getFileExtension(this string fileName)
        {
            string extension = "";
            char[] arr = fileName.ToCharArray();
            int index = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == '.')
                {
                    index = i-1;
                }
            }
            for (int x = index + 1; x < arr.Length; x++)
            {
                extension = extension + arr[x];
            }
            return extension;
        }
        /// <summary>
        /// Attempts to open the WCF Client
        /// Retries removed.
        /// </summary>
        /// <typeparam name="TChannel">The type of the attribute channel.</typeparam>
        /// <param name="source">The source.</param>
        
        public static void Open<TChannel>
            (this ClientBase<TChannel> source)
            where TChannel : class
        {
          
            source.Open();
        }

        /// <summary>
        /// Coalesces the empty.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="value">The value.</param>
        /// <returns>System.String.</returns>
		public static string CoalesceEmpty(this string source, string value)
		{
			if (string.IsNullOrEmpty(source)) return value;
			return source;
		}

        /// <summary>
        /// Returns the value or null if the value is DBNull.Value.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value">The value.</param>
        /// <returns>``0.</returns>
		[DebuggerStepThrough]
		public static T SqlCoalesce<T>(this object value)
		{
			if (value is DBNull) return default(T);
			try
			{
				if (value.IsNotNull())
				{
                    T result;

                    Type resultType = typeof(T);
                    bool resultIsNullable = resultType.IsGenericType && resultType.GetGenericTypeDefinition() == typeof(Nullable<>);

                    if (resultIsNullable)
                    {
                        Type innerResultType = resultType.GetGenericArguments().FirstOrDefault();
                        result = (T)Convert.ChangeType(value, innerResultType);
                    }
                    else
                    {
                        result = (T)value;
                    }

					return result;
				}

				return default(T);
			}
			catch (Exception e)
			{
				e.Data.Add("value", value);
				e.ToDebug();

				throw;
			}
		}

        /// <summary>
        /// Wrapper for the Type specific SqlCoalesce.  Added for access to functionality
        /// with Reflection
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>Object</returns>
        /// <objectparam name="value"></objectparam>
		//[DebuggerStepThrough]
		public static object SqlCoalesce(this object value)
		{
			try
			{
				switch (value.GetType().ToString())
				{
					case "System.String":
						return value.SqlCoalesce<String>();
					case "System.Double":
						return value.SqlCoalesce<Double>();
					case "System.Int32":
						return value.SqlCoalesce<Int32>();
					case "System.Int16":
						return value.SqlCoalesce<Int16>();
					case "System.Int64":
						return value.SqlCoalesce<Int64>();
					case "System.Boolean":
						return value.SqlCoalesce<Boolean>();
					case "System.DateTime":
						return value.SqlCoalesce<DateTime>();
					case "System.Decimal":
						return value.SqlCoalesce<Decimal>();
                    case "System.Single":
				        return value.SqlCoalesce<Single>();

                    //case "System.Nullable":
                    //    Type nullableType = value.GetType();   
                    //    Type underlyingType = Nullable.GetUnderlyingType(nullableType);

                    //    switch (underlyingType.ToString())
                    //    {
                    //        case "System.Int32":
                    //            return value.SqlCoalesce<Int32>();
                    //        case "System.DateTime":
                    //            return value.SqlCoalesce<DateTime>();
                    //        case "System.Decimal":
                    //            return value.SqlCoalesce<Decimal>();

                    //            //Add remaining case statements here


                    //        default:
                    //            return null;
							  
                    //    }
					default:
						return null;
				}
				
			}
			catch (Exception e)
			{
				e.Data.Add("value", value);
				e.ToDebug();

				throw;
			}
		}

        /// <summary>
        /// Build typed list from passed data table and type param
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="DT">The dt.</param>
        /// <returns>Object</returns>
        /// <objectparam name="value"></objectparam>
		public static List<T> BuildList<T>(this DataTable DT)
		{
			Type DTType = typeof(T);
			
			List<T> returnList = new List<T>();
			//Pull an array of PropertyInf for the object
			PropertyInfo[] arrPropertyInfo = typeof(T).GetProperties();
			//Loop through the datatable
			DataView dv = DT.DefaultView;
			for (int j = 0; j < dv.Count; j++)
			{
				DataRowView dr = dv[j];
				T listItem = (T)Activator.CreateInstance(typeof(T));
				//Loop through, finding the corresponding value from the 
				//Current data row and setting the value
				foreach (PropertyInfo mPropertyInfo in arrPropertyInfo)
				{
					//Make sure its writeable, too, for error checking in case of collections as properties, etc
					if (mPropertyInfo.CanWrite && DT.Columns.Contains(mPropertyInfo.Name))
					{
						//Make sure we have an item to match the property
						if ((dr[mPropertyInfo.Name] != null))
						{
							mPropertyInfo.SetValue(listItem, dr[mPropertyInfo.Name].SqlCoalesce(), null);
						}
					}
				}
				returnList.Add(listItem);
			}
			return returnList;
		}

        /// <summary>
        /// Build Dataset from typed list for use with MERGE statement
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <returns>Object</returns>
        /// <exception cref="System.InvalidOperationException">
        /// </exception>
        /// <objectparam name="value"></objectparam>
		public static DataSet BuildDataSet<T>(this IList<T> source)
		{
			DataColumn c = null;
			DataTable t = new DataTable();
			DataRow r = null;
			DataSet ds = new DataSet();

			PropertyInfo[] arrPropertyInfo = typeof(T).GetProperties();

			foreach (PropertyInfo mPropertyInfo in arrPropertyInfo)
			{
				// Limiting to CanWrite properties only, as readonly 
				// properties do not need to written to the DB
				if (mPropertyInfo.CanWrite == true)
				{
					if (mPropertyInfo.PropertyType.ToString().Contains("System.Nullable"))
					{
						c = new DataColumn(mPropertyInfo.Name, System.Nullable.GetUnderlyingType(mPropertyInfo.PropertyType));
						t.Columns.Add(c);
					}
					else
					{
						c = new DataColumn(mPropertyInfo.Name, mPropertyInfo.PropertyType);
						t.Columns.Add(c);
					}
				}
			}
			
			foreach (T mObject in source)
			{
				r = t.NewRow();
				foreach (PropertyInfo mPropertyInfo in arrPropertyInfo)
				{
					try
					{
						//  CanRead for avoiding errors, and CanWrite to include only values
						// that can be changed by the application
						if (mPropertyInfo.CanRead && mPropertyInfo.CanWrite)
						{
							r[mPropertyInfo.Name] = mPropertyInfo.GetValue(mObject, null);
						}
					}
                    catch (ArgumentException ae)
                    {
                        //added by KHH 07/18/11 to handle nullable base types.  Could be re-evaluated.  Added as new Catch so as not to affect existing code.
                        if (Nullable.GetUnderlyingType(mPropertyInfo.PropertyType) != null && mPropertyInfo.GetValue(mObject, null) == null)
                        {
                            try
                            {
                                r[mPropertyInfo.Name] = DBNull.Value;
                            }
                            catch (Exception ex2)
                            {
                                throw new InvalidOperationException(ae.Message + "\n" + ex2.Message);
                            }
                        }
                        else
                        {
                            throw new InvalidOperationException(ae.Message);
                        }
                    }
					catch (Exception ex)
					{
						throw new InvalidOperationException(ex.Message);
					}

				}
				t.Rows.Add(r);
			}

			ds.Tables.Add(t);
			return ds;
		}

        /// <summary>
        /// Build DataTable from typed list for use with MERGE statement
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <returns>Object</returns>
        /// <exception cref="System.InvalidOperationException"></exception>
        /// <objectparam name="value"></objectparam>
		public static DataTable BuildDataTable<T>(this IList<T> source)
		{
			DataColumn c = null;
			DataTable t = new DataTable();
			DataRow r = null;

			PropertyInfo[] arrPropertyInfo = typeof(T).GetProperties();

			foreach (PropertyInfo mPropertyInfo in arrPropertyInfo)
			{
				// Limiting to CanWrite properties only, as readonly 
				// properties do not need to written to the DB
				if (mPropertyInfo.CanWrite == true)
				{
					if (mPropertyInfo.PropertyType.ToString().Contains("System.Nullable"))
					{
						c = new DataColumn(mPropertyInfo.Name, System.Nullable.GetUnderlyingType(mPropertyInfo.PropertyType));
						t.Columns.Add(c);
					}
					else
					{
						c = new DataColumn(mPropertyInfo.Name, mPropertyInfo.PropertyType);
						t.Columns.Add(c);
					}
				}
			}

			foreach (T mObject in source)
			{
				r = t.NewRow();
				foreach (PropertyInfo mPropertyInfo in arrPropertyInfo)
				{
					try
					{
						//  CanRead for avoiding errors, and CanWrite to include only values
						// that can be changed by the application
						if (mPropertyInfo.CanRead && mPropertyInfo.CanWrite)
						{
							r[mPropertyInfo.Name] = mPropertyInfo.GetValue(mObject, null);
						}
					}
					catch (Exception ex)
					{
						throw new InvalidOperationException(ex.Message);
					}
				}

				t.Rows.Add(r);
			}

			return t;
		}

        /// <summary>
        /// Linqs the automatic data table.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="varList">The variable list.</param>
        /// <returns>DataTable.</returns>
		public static DataTable LINQToDataTable<T>(this IEnumerable<T> varList)
		{
			DataTable dtRetVal = new DataTable();

			try
			{
				// column names
				PropertyInfo[] oProps = null;

				if (varList == null) return dtRetVal;

				foreach (T rec in varList)
				{
					// Use reflection to get property names, to create table, Only first time, others will follow
					if (oProps == null)
					{
						oProps = ((Type)rec.GetType()).GetProperties();

						foreach (PropertyInfo pi in oProps)
						{
							Type colType = pi.PropertyType;

							if ((colType.IsGenericType) && (colType.GetGenericTypeDefinition() == typeof(Nullable<>)))
							{
								colType = colType.GetGenericArguments()[0];
							}

							dtRetVal.Columns.Add(new DataColumn(pi.Name, colType));
						}
					}

					DataRow dr = dtRetVal.NewRow();

					foreach (PropertyInfo pi in oProps)
					{
						dr[pi.Name] = pi.GetValue(rec, null) == null ? DBNull.Value : pi.GetValue(rec, null);
					}

					dtRetVal.Rows.Add(dr);
				}
			}
			catch (Exception)
			{
				throw;
			}

			return dtRetVal;
		}

        /// <summary>
        /// Sets the Value property of the source parameter with the
        /// specified value, OR with DBNull.Value if the specified
        /// value is null.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        /// <param name="value">The value.</param>
        /// <exception cref="System.ArgumentNullException">parameter;The parameter cannot be null.</exception>
		[DebuggerStepThrough]
		public static void SetParameterValue(this SqlParameter parameter, object value)
		{
			if (parameter == null)
				throw new ArgumentNullException("parameter",
												"The parameter cannot be null.");

			// ReSharper disable ConditionIsAlwaysTrueOrFalse
			// ReSharper disable ConvertIfStatementToNullCoalescingExpression
			if (value == null) parameter.Value = DBNull.Value;
				// ReSharper restore ConvertIfStatementToNullCoalescingExpression
				// ReSharper restore ConditionIsAlwaysTrueOrFalse
			else parameter.Value = value;
		}

        /// <summary>
        /// Sets the Value property of the source parameter with the
        /// specified value, OR with DBNull.Value if the specified
        /// value is null.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        /// <param name="value">The value.</param>
        /// <exception cref="System.ArgumentNullException">parameter;The parameter cannot be null.</exception>
		[DebuggerStepThrough]
		public static void SetParameterValue(this SqlParameter parameter, string value)
		{
			if (parameter == null)
				throw new ArgumentNullException("parameter",
												"The parameter cannot be null.");

			if (string.IsNullOrEmpty(value)) parameter.Value = DBNull.Value;
			else parameter.Value = value;
		}

        /// <summary>
        /// Creates a nullable Int32 from the
        /// specified string.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Nullable{System.Int32}.</returns>
		[DebuggerStepThrough]
		public static int? ToNullableInt(this string value)
		{
			int? result = null;
			if (!string.IsNullOrEmpty(value))
			{
				int temp = Convert.ToInt32(value);
				result = new int?(temp);
			}

			return result;
		}

        /// <summary>
        /// Creates a nullable DateTime from the
        /// specified string.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Nullable{DateTime}.</returns>
		[DebuggerStepThrough]
		public static DateTime? ToNullableDateTime(this string value)
		{
			DateTime? result = null;
			if (!string.IsNullOrEmpty(value))
			{
				DateTime temp;
                if (DateTime.TryParse(value, out temp))
				result = new DateTime?(temp);
			}

			return result;
		}

        /// <summary>
        /// Tests the exclude items.
        /// </summary>
		public static void TestExcludeItems()
		{
			var list1 = new List<int?> {1, 2, 3};
			var list2 = new List<int?> {2};

			var result = list1.ExcludeItems(list2, x => x.Value);

			result.ToDebug();
		}

        /// <summary>
        /// Excludes the items.
        /// </summary>
        /// <typeparam name="TList">The type of the attribute list.</typeparam>
        /// <typeparam name="TKey">The type of the attribute key.</typeparam>
        /// <param name="sourceList">The source list.</param>
        /// <param name="excludeList">The exclude list.</param>
        /// <param name="selector">The selector.</param>
        /// <returns>IList{``0}.</returns>
		public static IList<TList> ExcludeItems<TList, TKey>(
			this IList<TList> sourceList,
			IList<TList> excludeList,
			Func<TList, TKey> selector)
		{
			var result = sourceList.ToList();

			foreach(var item in excludeList)
			{
				var found =
					(from i in result
					 where selector(i).Equals(selector(item))
					 select i).FirstOrDefault();

				if (found != null)
				{
					result.Remove(found);
				}
			}

			return result;
		}

		//[DebuggerStepThrough]
        /// <summary>
        /// Determines if the list contains an item with the specified value
        /// for the specified property selector.
        /// </summary>
        /// <typeparam name="TList">The type of the attribute list.</typeparam>
        /// <typeparam name="TKey">The type of the attribute key.</typeparam>
        /// <param name="list">The list.</param>
        /// <param name="selector">The selector.</param>
        /// <param name="item">The item.</param>
        /// <returns><c>true</c> if the specified list contains item; otherwise, <c>false</c>.</returns>
        /// <example>
        ///   <code>
        /// var contains = list.ContainsItem(x =&gt; x.Property, target.Property);
        ///   </code>
        ///   </example>
		public static bool ContainsItem<TList, TKey>(
			this IList<TList> list,
			Func<TList, TKey> selector,
			TList item)
		{
			var results =
				(from x in list
				 where selector(x).Equals(selector(item))
				 select x).ToList();

			return results.IsNotNullOrEmpty<TList>();
		}

        /// <summary>
        /// Maximums the specified list.
        /// </summary>
        /// <typeparam name="TList">The type of the attribute list.</typeparam>
        /// <typeparam name="TKey">The type of the attribute key.</typeparam>
        /// <param name="list">The list.</param>
        /// <param name="selector">The selector.</param>
        /// <returns>System.Decimal.</returns>
		[DebuggerStepThrough]
		public static decimal Max<TList, TKey>(
			this IList<TList> list,
			Func<TList, TKey> selector)
			where TKey : struct
		{
			decimal result = 0;

			foreach(TList item in list)
			{
				TKey value = selector(item);
#pragma warning disable 183
				if(value is TKey?)
#pragma warning restore 183
				{
					TKey v = ((TKey?) value).Value;
					result = Math.Max(result, Convert.ToDecimal(v));
				}
				else
				{
					result = Math.Max(result, Convert.ToDecimal(value));
				}
			}

			return result;
		}


        /// <summary>
        /// Sums the values of the list for the
        /// specified property.
        /// </summary>
        /// <typeparam name="TList">The type of the attribute list.</typeparam>
        /// <typeparam name="TKey">The type of the attribute key.</typeparam>
        /// <param name="list">The list.</param>
        /// <param name="selector">The selector.</param>
        /// <returns>System.Decimal.</returns>
		[DebuggerStepThrough]
		public static decimal SumList<TList, TKey>(
			this IList<TList> list,
			Func<TList, TKey> selector)
			where TKey : struct
		{
			decimal result = 0;

			foreach (TList item in list)
			{
				TKey value = selector(item);
#pragma warning disable 183
				if (value is TKey?)
#pragma warning restore 183
				{
					TKey v = ((TKey?) value).Value;
					result += Convert.ToDecimal(v);
				}
				else
				{
					result += Convert.ToDecimal(value);
				}
			}

			return result;
		}

        /// <summary>
        /// Distincts the by field.
        /// </summary>
        /// <typeparam name="TList">The type of the attribute list.</typeparam>
        /// <typeparam name="TKey">The type of the attribute key.</typeparam>
        /// <param name="list">The list.</param>
        /// <param name="selector">The selector.</param>
        /// <returns>IEnumerable{``0}.</returns>
		[DebuggerStepThrough]
		public static IEnumerable<TList> DistinctByField<TList, TKey>(
			this IEnumerable<TList> list,
			Func<TList, TKey> selector)
		{
			var results = new Dictionary<TKey, TList>();
			foreach(var item in list)
			{
				if(!results.ContainsKey(selector(item)))
				{
					results.Add(selector(item), item);
				}
			}
			return results.Values;
		}

        /// <summary>
        /// Returns a subset of a larger set starting
        /// at the specified index and returning the specified
        /// count of records.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list">The list.</param>
        /// <param name="start">The start.</param>
        /// <param name="count">The count.</param>
        /// <returns>IList{``0}.</returns>
        /// <exception cref="System.ArgumentNullException">list;Must supply an instance of the list.</exception>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// start;Start must be a positive number.
        /// or
        /// start;Start must be less than the length of the list.
        /// or
        /// count;Count must be a positive number.
        /// </exception>
		[DebuggerStepThrough]
		public static IList<T> Subset<T>(this IList<T> list, int start, int count)
		{
			if (list == null)
				throw new ArgumentNullException("list",
												"Must supply an instance of the list.");
			if (start < 0)
				throw new ArgumentOutOfRangeException("start",
													  "Start must be a positive number.");
			if (start >= list.Count)
				throw new ArgumentOutOfRangeException("start",
													  "Start must be less than the length of the list.");
			if (count < 0)
				throw new ArgumentOutOfRangeException("count",
													  "Count must be a positive number.");

			var result = new List<T>(count);

			for (int i = start; i < start + count && i < list.Count; i++)
			{
				result.Add(list[i]);
			}

			return result;
		}

        /// <summary>
        /// Returns a subset of a larger set starting
        /// at the specified index to the end of the set.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list">The list.</param>
        /// <param name="start">The start.</param>
        /// <returns>IList{``0}.</returns>
        /// <exception cref="System.ArgumentNullException">list;Must supply an instance of the list.</exception>
        /// <exception cref="System.ArgumentOutOfRangeException">
        /// start;Start must be a positive number.
        /// or
        /// start;Start must be less than the length of the list.
        /// </exception>
		[DebuggerStepThrough]
		public static IList<T> Subset<T>(this IList<T> list, int start)
		{
			if (list == null)
				throw new ArgumentNullException("list",
												"Must supply an instance of the list.");
			if (start < 0)
				throw new ArgumentOutOfRangeException("start",
													  "Start must be a positive number.");
			if (start >= list.Count)
				throw new ArgumentOutOfRangeException("start",
													  "Start must be less than the length of the list.");

			return list.Subset(start, list.Count - start);
		}

        /// <summary>
        /// Determines if the source is in the collection of strings.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="target">The target.</param>
        /// <returns><c>true</c> if the specified source is information; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsIn(this string source, ICollection<string> target)
		{
			string result =
				(
					from item in target
					where source == item
					select item
				).FirstOrDefault();

			return !string.IsNullOrEmpty(result);
		}

        /// <summary>
        /// Sorts the source list on the property name specified and
        /// the direction specified.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataSource">The data source.</param>
        /// <param name="propertyName">Name of the property.</param>
        /// <param name="sortDirection">The sort direction.</param>
        /// <returns>List{``0}.</returns>
		public static List<T> SortList<T>(this List<T> dataSource, string propertyName,
									   SortDirectionValue sortDirection)
		{
			PropertyInfo propInfo = typeof (T).GetProperty(propertyName);
			Comparison<T> compare = delegate(T a, T b)
										{
											bool asc = sortDirection ==
													   SortDirectionValue.Ascending;
											object valueA = asc
																? propInfo.GetValue(a,
																					null)
																: propInfo.GetValue(b,
																					null);
											object valueB = asc
																? propInfo.GetValue(b,
																					null)
																: propInfo.GetValue(a,
																					null);

											return valueA is IComparable
													   ? ((IComparable) valueA).CompareTo(
															 valueB)
													   : 0;
										};
			dataSource.Sort(compare);

			return dataSource;
		}

        /// <summary>
        /// Creates a SqlParameter and sets its value from the
        /// source object.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="name">The name.</param>
        /// <param name="type">The type.</param>
        /// <param name="size">The size.</param>
        /// <returns>SqlParameter.</returns>
		[DebuggerStepThrough]
		public static SqlParameter MakeParameter(this object value, string name,
												 SqlDbType type,
												 int size)
		{
			var p = new SqlParameter(name, type, size);
			p.SetParameterValue(value);
			return p;
		}

        /// <summary>
        /// Makes the parameter.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="name">The name.</param>
        /// <param name="type">The type.</param>
        /// <returns>SqlParameter.</returns>
		public static SqlParameter MakeParameter(this object value, string name,
										 SqlDbType type)
		{
			var p = new SqlParameter(name, type);
			p.SetParameterValue(value);
			return p;
		}

        /// <summary>
        /// Makes the parameter.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="name">The name.</param>
        /// <param name="type">The type.</param>
        /// <param name="size">The size.</param>
        /// <param name="direction">The direction.</param>
        /// <returns>SqlParameter.</returns>
		public static SqlParameter MakeParameter(this object value, string name,
												 SqlDbType type,
												 int size,
												 ParameterDirection direction)
		{
			var p = new SqlParameter(name, type, size);
			p.Direction = direction;
			p.SetParameterValue(value);
			return p;
		}

        /// <summary>
        /// Automatics the phone number.
        /// </summary>
        /// <param name="target">The target.</param>
        /// <returns>System.String.</returns>
        public static string ToPhoneNumber(this string target)
        {
            return Regex.Replace(target.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", ""), "(\\d{3})(\\d{3})(\\d{4})", "($1) $2-$3");
        }

        /// <summary>
        /// Generates a report that walks the list of inner exceptions
        /// and provides a readable format.  It includes the contents of the
        /// Data object for each exception in the stack.
        /// </summary>
        /// <param name="exception">The exception.</param>
        /// <param name="depth">The depth.</param>
        /// <returns>System.String.</returns>
		public static string ToFormatedString(this Exception exception, int depth)
		{
			var builder = new StringBuilder();
			var tabs = new string('\t', depth);
			int depthOffset = (depth + 1)*4;

			builder.Append(tabs);
			builder.Append('-', 78 - depthOffset);
			builder.AppendLine();

			builder.AppendFormat("{1}Handled {0} with the following data:\n",
								 exception.GetType().Name, tabs);

			if (exception.InnerException != null)
			{
				builder.AppendFormat("{0}Begin Inner Exception:\n", tabs);
				builder.Append(exception.InnerException.ToFormatedString(depth + 1));
				builder.AppendLine();
				builder.Append(tabs + '\t');
				builder.Append('-', 60 - depthOffset);
				builder.AppendLine();
				builder.AppendFormat("{0}End Inner Exception:\n", tabs);
			}

			if (exception.Data.Keys.Count > 0)
			{
				builder.AppendLine(tabs + "Exception Data:");
				foreach (object key in exception.Data.Keys)
				{
					builder.AppendFormat("{2}\t{0}={1}\n", key, exception.Data[key], tabs);
				}
			}

			builder.Append(tabs + '\t');
			builder.Append('-', 60 - depthOffset);
			builder.AppendLine();

			builder.AppendFormat("{2}{0}: {1}\n", exception.GetType().FullName,
								 exception.Message, tabs);

			if (exception.StackTrace != null)
			{
				IEnumerable<string> stackLines =
					from line in exception.StackTrace.Split('\n')
					select tabs + line;

				foreach (string line in stackLines)
				{
					builder.AppendLine(line);
				}
			}

			return builder.ToString();
		}

        /// <summary>
        /// Formats raw string object to conform to the designated format type
        /// </summary>
        /// <param name="rawString">The raw string.</param>
        /// <param name="formatType">Type of the format.</param>
        /// <returns>String.</returns>
		public static String HSStringFormatter(this String rawString, String formatType)
		{
			String retVal = String.Empty;

			switch (formatType.Trim().ToLower())
			{
				case "memberid":

					switch (rawString.Trim().Length)
					{
						case 9:
							retVal = String.Format("{0}*01", rawString.Trim());
							break;
						case 11:
							retVal = String.Format("{0}*{1}", rawString.Trim().Substring(0, 9), rawString.Trim().Substring(9, 2));
							break;
						default:
							retVal = rawString.Trim();
							break;
					}

					break;

				default:

					retVal = rawString.Trim();
					break;
			}

			return retVal;
		}

        /// <summary>
        /// Gets the SQL parameter string.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns>System.String.</returns>
        public static string getSqlParameterString(this SqlParameter[] parameters)
        {
            StringBuilder sb = new StringBuilder();

            foreach (SqlParameter parameter in parameters)
            {
                sb.Append("DECLARE " + parameter.ParameterName + " " + parameter.DbType.ToString() + Environment.NewLine);
                sb.Append("SET " + parameter.ParameterName + " = " + parameter.Value + Environment.NewLine);
            }
            return sb.ToString();
        }

        /// <summary>
        /// Gets the SQL parameter string.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns>System.String.</returns>
        public static string getSqlParameterString(this SqlParameterCollection parameters)
        {
            StringBuilder sb = new StringBuilder();

            foreach (SqlParameter parameter in parameters)
            {
                sb.Append("DECLARE " + parameter.ParameterName + " " + parameter.SqlDbType.ToString() + Environment.NewLine);
                sb.Append("SET " + parameter.ParameterName + " = '" + parameter.Value +"'" + Environment.NewLine);
            }
            return sb.ToString();
        }

        /// <summary>
        /// Gets the SQL parameter string.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns>System.String.</returns>
        public static string getSqlParameterString(this List<SqlParameter> parameters)
        {
            StringBuilder sb = new StringBuilder();

            foreach (SqlParameter parameter in parameters)
            {
                sb.Append("DECLARE " + parameter.ParameterName + " " + parameter.SqlDbType.ToString() + Environment.NewLine);
                sb.Append("SET " + parameter.ParameterName + " = '" + parameter.Value + "'" + Environment.NewLine);
            }
            return sb.ToString();
        }

        /// <summary>
        /// Copies the parameters.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>List{SqlParameter}.</returns>
        public static List<SqlParameter> CopyParameters(this List<SqlParameter> source)
        {
            List<SqlParameter> selectParams = new List<SqlParameter>();

            foreach (SqlParameter param in source)
            {
                SqlParameter paramToAdd = new SqlParameter();
                param.CopyInto<SqlParameter>(paramToAdd);
                selectParams.Add(paramToAdd);
            }

            return selectParams;
        }

        // converts SqlParameterCollection to List<SqlParameter> for use in Data Access
        /// <summary>
        /// Automatics the parameter list.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>List{SqlParameter}.</returns>
        public static List<SqlParameter> ToParameterList(this System.Data.SqlClient.SqlParameterCollection source)
        {
            List<SqlParameter> returnList = new List<SqlParameter>();

            foreach (SqlParameter param in source)
            {
                returnList.Add(param);
            }

            return returnList;
        }

        /// <summary>
        /// Performs a safe copying of like properties from the source
        /// object to the target object.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <param name="target">The target.</param>
        /// <returns>``0.</returns>
		public static T CopyInto<T>(this object source, T target)
		{
			foreach (PropertyInfo pi in
				source.GetType().GetProperties(
					BindingFlags.Public | BindingFlags.Instance))
			{
				PropertyInfo vpi = target.GetType().GetProperty(pi.Name,
																BindingFlags.Public |
																BindingFlags.Instance);

				if (vpi != null && vpi.CanWrite)// && vpi.PropertyType == pi.PropertyType)
				{
					var emptyObjectArray = new object[0];
					object value = null;
					try
					{
						value = pi.GetValue(source, emptyObjectArray);
						vpi.SetValue(target, value, emptyObjectArray);
					}
					catch (Exception e)
					{
						if (source is System.Runtime.Serialization.ISerializable) e.Data.Add("source", source);
						if (target is System.Runtime.Serialization.ISerializable) e.Data.Add("target", target);
						if (value is System.Runtime.Serialization.ISerializable) e.Data.Add("value", value);

						e.Data.Add("vpi", vpi);
						e.Data.Add("pi", pi);

						throw;
					}
				}
			}

			return target;
		}

        /// <summary>
        /// Performs a safe copying of like properties from the source
        /// object to the target object from cache, continuing after errors
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <param name="sourceInterface">The source interface.</param>
        /// <param name="target">The target.</param>
        /// <returns>``0.</returns>
		public static T CopyIntoFromCache<T>(this object source, Type sourceInterface, T target)
		{
			foreach (PropertyInfo pi in
				source.GetType().GetInterface(sourceInterface.Name).GetProperties(
					BindingFlags.Public | BindingFlags.Instance))
			{
				PropertyInfo vpi = target.GetType().GetProperty(pi.Name,
																BindingFlags.Public |
																BindingFlags.Instance);

				if (vpi != null && vpi.CanWrite)// && vpi.PropertyType == pi.PropertyType)
				{
					var emptyObjectArray = new object[0];
					object value = null;
					try
					{
						value = pi.GetValue(source, emptyObjectArray);
						vpi.SetValue(target, value, emptyObjectArray);
					}
					catch (Exception e)
					{
						if (source is System.Runtime.Serialization.ISerializable) e.Data.Add("source", source);
						if (target is System.Runtime.Serialization.ISerializable) e.Data.Add("target", target);
						if (value is System.Runtime.Serialization.ISerializable) e.Data.Add("value", value);

						e.Data.Add("vpi", vpi);
						e.Data.Add("pi", pi);
					}
				}
			}

			return target;
		}


        /// <summary>
        /// Copies the into type safe.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <param name="target">The target.</param>
        /// <returns>``0.</returns>
		public static T CopyIntoTypeSafe<T>(this object source, T target)
		{
			foreach (PropertyInfo pi in
				source.GetType().GetProperties(
					BindingFlags.Public | BindingFlags.Instance))
			{
				PropertyInfo vpi = target.GetType().GetProperty(pi.Name,
																BindingFlags.Public |
																BindingFlags.Instance);

				if (vpi != null && vpi.CanWrite && vpi.PropertyType == pi.PropertyType)
				{
					var emptyObjectArray = new object[0];
					object value = null;
					try
					{
						value = pi.GetValue(source, emptyObjectArray);
						vpi.SetValue(target, value, emptyObjectArray);
					}
					catch (Exception e)
					{
						if (source is System.Runtime.Serialization.ISerializable) e.Data.Add("source", source);
						if (target is System.Runtime.Serialization.ISerializable) e.Data.Add("target", target);
						if (value is System.Runtime.Serialization.ISerializable) e.Data.Add("value", value);

						e.Data.Add("vpi", vpi);
						e.Data.Add("pi", pi);

						throw;
					}
				}
			}

			return target;
		}

        /// <summary>
        /// Safes the trim.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>System.String.</returns>
        public static string SafeTrim(this string source)
        {
            if (source == null)
                return null;

            return source.Trim();
        }


        /// <summary>
        /// Wrapper for string.Format so that it can be used as an
        /// extension method.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="data">The data.</param>
        /// <returns>System.String.</returns>
		[DebuggerStepThrough]
		public static string FormatString(this string source, params object[] data)
		{
			return string.Format(source, data);
		}

        /// <summary>
        /// Formats the phone.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>System.String.</returns>
        public static string FormatPhone(this string source)
        {
            string strReturn = null;
            string strTemp = null;

            //Check for null
            if (string.IsNullOrEmpty(source))
            {
                strReturn = " ";
            }
            else
            {
                //Ive got something to work with, clean it.
                strTemp = source.Replace(" ", "");
                strTemp = strTemp.Replace("-", "");
                strTemp = strTemp.Replace("(", "");
                strTemp = strTemp.Replace(")", "");
                //I need a length
                int intLength = 0;
                intLength = strTemp.Length;
                
                if (intLength == 7)
                {
                    strReturn = Left(strTemp, 3) + "-" + Right(strTemp, 4);
                }
                else if (intLength == 10)
                {
                    strReturn = "(" + Left(strTemp, 3) + ") " + strTemp.Substring(3, 3) + "-" + Right(strTemp, 4);
                }

            }

            return strReturn;
        }

        /// <summary>
        /// Throws an ArgumentNullException if the specified source value is null.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="message">The message.</param>
        /// <exception cref="System.ArgumentNullException"></exception>
		[DebuggerStepThrough]
		public static void AssertParameterNotNull<T>(this T source, string parameterName,
													 string message)
			where T : class
		{
			if (source == null) throw new ArgumentNullException(parameterName, message);
		}

        /// <summary>
        /// Determines if the supplied string is a valid DateTime.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if [is valid date] [the specified source]; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsValidDate(this string source)
		{
			bool isValid = false;
			try
			{
				Convert.ToDateTime(source);
				isValid = true;
			}
// ReSharper disable EmptyGeneralCatchClause
			catch
// ReSharper restore EmptyGeneralCatchClause
			{
				//failed to convert to date
			}
			return isValid;
		}

		#region ToFixedLength Permutations

        /// <summary>
        /// Takes the number of specified characters from the start of the string.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="charsToTake">The chars automatic take.</param>
        /// <returns>System.String.</returns>
		[DebuggerStepThrough]
		public static string Left(this string source, int charsToTake)
		{
			if (source.IsNull() || source.Length < charsToTake) return source;

			return source.Substring(0, charsToTake);
		}

        /// <summary>
        /// Takes the number of specified characters from the end of the string.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="charsToTake">The chars automatic take.</param>
        /// <returns>System.String.</returns>
		[DebuggerStepThrough]
		public static string Right(this string source, int charsToTake)
		{
			if(source.IsNull() || source.Length < charsToTake) return source;

			return source.Substring(source.Length - charsToTake);
		}

        /// <summary>
        /// Creates a string array from a source string where each element
        /// is a specified width.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="width">The width.</param>
        /// <returns>System.String[][].</returns>
		[DebuggerStepThrough]
		public static string[] SplitOnWidth(this string source, int width)
		{
			if(source.Length < width || source.IsNull()) return new [] { source };
			
			int i;
			var strings = new List<string>(source.Length / width + 1);
			for(i=0; i + width<=source.Length; i+=width)
			{
				strings.Add(source.Substring(i, width));
			}
			strings.Add(source.Substring(i));

			return strings.ToArray();
		}

        /// <summary>
        /// Creates a string which has the specified width from the
        /// source object and is justified as specified.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="width">The width.</param>
        /// <param name="justification">The justification.</param>
        /// <returns>System.String.</returns>
		[DebuggerStepThrough]
		public static string ToFixedLength(
			this object source
			, int width
			, FixedLengthJustification justification)
		{
			return source.ToFixedLength("{0}", width, justification);
		}

        /// <summary>
        /// Creates a string which has the specified width from the
        /// source object and is justified as specified.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="format">The format.</param>
        /// <param name="width">The width.</param>
        /// <param name="justification">The justification.</param>
        /// <returns>System.String.</returns>
		[DebuggerStepThrough]
		public static string ToFixedLength(
			this object source
			, string format
			, int width
			, FixedLengthJustification justification)
		{
			var result = new string(' ', width);

			if (source.IsNotNull())
			{
				string part = format.FormatString(source);

				if (part.Length > width)
				{
					if (justification == FixedLengthJustification.Left)
						result = part.Substring(0, width);
					else if (justification == FixedLengthJustification.Right)
						result = part.Substring(part.Length - width);
					else
						result = part.Substring((part.Length - width)/2, width);
				}
				else if (part.Length == width)
				{
					result = part;
				}
				else
				{
					if (justification == FixedLengthJustification.Left)
						result = (part + result).Substring(0, width);
					else if (justification == FixedLengthJustification.Right)
						result = (result + part).Substring((result + part).Length - width);
					else
						result =
							(new string(' ', (width - part.Length)/2) + part +
							 new string(' ', (width - part.Length)/2 + 1)).Substring(0,
																					 width);
				}
			}

			return result;
		}

		#endregion ToFixedLength Permutations

		#region ToDebug Permutations

        /// <summary>
        /// Writes the string to the Debug context.
        /// </summary>
        /// <param name="source">The source.</param>
		[DebuggerStepThrough]
		public static void ToDebug(this string source)
		{
			Debug.Write(source);
		}

        /// <summary>
        /// Formats and writes the string to the Debug context.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="data">The data.</param>
		[DebuggerStepThrough]
		public static void ToDebug(this string source, params object[] data)
		{
			Debug.Write(string.Format(source, data));
		}

        /// <summary>
        /// Writes the string as a line to the Debug context.
        /// </summary>
        /// <param name="source">The source.</param>
		[DebuggerStepThrough]
		public static void ToDebugLine(this string source)
		{
			Debug.WriteLine(source);
		}

        /// <summary>
        /// Formats and writes the string as a line to the debug context.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="data">The data.</param>
		[DebuggerStepThrough]
		public static void ToDebugLine(this string source, params object[] data)
		{
			Debug.WriteLine(string.Format(source, data));
		}

        /// <summary>
        /// Writes the formatted string of the exception to the
        /// Debug context.
        /// </summary>
        /// <param name="source">The source.</param>
		[DebuggerStepThrough]
		public static void ToDebug(this Exception source)
		{
			Debug.WriteLine(source.ToFormatedString(0));
		}

        /// <summary>
        /// Writes the formatted string of the exception to the
        /// Debug context with a specific message.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="message">The message.</param>
		[DebuggerStepThrough]
		public static void ToDebug(this Exception source, string message)
		{
			Debug.WriteLine(message);
			source.ToDebug();
		}

        /// <summary>
        /// Writes the formatted string of the exception to the
        /// Debug context with a specific formatted message.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="message">The message.</param>
        /// <param name="data">The data.</param>
		[DebuggerStepThrough]
		public static void ToDebug(this Exception source, string message,
								   params object[] data)
		{
			Debug.WriteLine(message.FormatString(data));
			source.ToDebug();
		}

        /// <summary>
        /// Writes each member of a collection to a line in the
        /// Debug context.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
		[DebuggerStepThrough]
		public static void ToDebug<T>(this ICollection<T> source)
			
		{
			int l = source.GetType().FullName.Length;
			source.GetType().FullName.ToDebugLine();
			new string('-', l).ToDebugLine();

			Debug.Indent();
			foreach (var item in source)
			{
				if (item is IConvertible)
				{
					Convert.ToString(item).ToDebugLine();
				}
				else
				{
					item.ToString().ToDebugLine();
				}
			}
			Debug.Unindent();

			new string('-', l).ToDebugLine();
		}

		#endregion ToDebug Permutations

		#region Null or Empty Permutations

        /// <summary>
        /// Tests that the specified type is null.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if the specified source is null; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsNull<T>(this T source)
			where T : class
		{
			return source == null;
		}

        /// <summary>
        /// Tests that the specified type is not null.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if [is not null] [the specified source]; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsNotNull<T>(this T source)
			where T : class
		{
			return source != null;
		}

        /// <summary>
        /// Tests that the specified string is either
        /// null or empty.  Does NOT perform a trim.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if [is null original empty] [the specified source]; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsNullOrEmpty(this string source)
		{
// ReSharper disable ReplaceWithStringIsNullOrEmpty
			return source == null || (source.Length == 0);
// ReSharper restore ReplaceWithStringIsNullOrEmpty
		}

        /// <summary>
        /// Tests that the specified string is NOT either
        /// null or empty.  Does NOT perform a trim.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if [is not null original empty] [the specified source]; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsNotNullOrEmpty(this string source)
		{
// ReSharper disable ReplaceWithStringIsNullOrEmpty
			return source != null && source.Length > 0;
// ReSharper restore ReplaceWithStringIsNullOrEmpty
		}

        /// <summary>
        /// Tests if the collection is null or empty.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if [is null original empty] [the specified source]; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsNullOrEmpty(this ICollection source)
		{
			return source == null || source.Count == 0;
		}

        /// <summary>
        /// Tests if the collection is not null or empty.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if [is not null original empty] [the specified source]; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsNotNullOrEmpty(this ICollection source)
		{
			return source != null && source.Count > 0;
		}

        /// <summary>
        /// Tests if the collection is null or empty.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if [is null original empty] [the specified source]; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsNullOrEmpty<T>(this ICollection<T> source)
		{
			return source == null || source.Count == 0;
		}

        /// <summary>
        /// Tests if the collection is not null or empty.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if [is not null original empty] [the specified source]; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsNotNullOrEmpty<T>(this ICollection<T> source)
		{
			return source != null && source.Count > 0;
		}

        /// <summary>
        /// Tests if the dictionary is null or empty.
        /// </summary>
        /// <typeparam name="TKey">The type of the attribute key.</typeparam>
        /// <typeparam name="TValue">The type of the attribute value.</typeparam>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if [is null original empty] [the specified source]; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsNullOrEmpty<TKey, TValue>(
			this IDictionary<TKey, TValue> source)
		{
			return source == null || source.Count == 0;
		}

        /// <summary>
        /// Tests if the dictionary is not null or empty.
        /// </summary>
        /// <typeparam name="TKey">The type of the attribute key.</typeparam>
        /// <typeparam name="TValue">The type of the attribute value.</typeparam>
        /// <param name="source">The source.</param>
        /// <returns><c>true</c> if [is not null original empty] [the specified source]; otherwise, <c>false</c>.</returns>
		[DebuggerStepThrough]
		public static bool IsNotNullOrEmpty<TKey, TValue>(
			this IDictionary<TKey, TValue> source)
		{
			return source != null && source.Count > 0;
		}

		#endregion Null or Empty Permutations
        /// <summary>
        /// Compares two strings ignoring case.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="target">The target.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
		[DebuggerStepThrough]
		public static bool EqualsIgnoreCase(this string source, string target)
		{
			return source.ToLower().Equals(target.ToLower());
		}

        /// <summary>
        /// Adds a collection of KeyValuePairs to the
        /// source dictionary.
        /// </summary>
        /// <typeparam name="TKey">The type of the attribute key.</typeparam>
        /// <typeparam name="TValue">The type of the attribute value.</typeparam>
        /// <param name="source">The source.</param>
        /// <param name="values">The values.</param>
		public static void AddRange<TKey, TValue>(
			this IDictionary<TKey, TValue> source, 
			IEnumerable<KeyValuePair<TKey, TValue>> values)
		{
			foreach(var item in values)
			{
				source.Add(item);
			}
		}

        /// <summary>
        /// Converts a value to the specified Enum type.
        /// </summary>
        /// <typeparam name="TEnum">The type of the attribute enum.</typeparam>
        /// <param name="source">The source.</param>
        /// <returns>``0.</returns>
		public static TEnum ToEnum<TEnum>(this object source)
		{
			//source.AssertParameterNotNull("source", "Cannot convert a null value to an Enum.");

			if (source != null)
			{
				var value = source.ToString();

				return (TEnum)Enum.Parse(typeof(TEnum), value);
			}

			return default(TEnum);
		}
        
	}

    /// <summary>
    /// Direction to sort values using
    /// the SortList extension method.
    /// </summary>
	[Serializable]
	public enum SortDirectionValue
	{
        /// <summary>
        /// The ascending
        /// </summary>
		Ascending,
        /// <summary>
        /// The descending
        /// </summary>
		Descending
	}

    /// <summary>
    /// Justification of the string for
    /// the ToFixedLength extension method.
    /// </summary>
	[Serializable]
	public enum FixedLengthJustification
	{
        /// <summary>
        /// The left
        /// </summary>
		Left,
        /// <summary>
        /// The right
        /// </summary>
		Right,
        /// <summary>
        /// The center
        /// </summary>
		Center
	}

    

    
}