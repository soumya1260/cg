﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 04-23-2013
// ***********************************************************************
// <copyright file="EnumExtensions.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Extension class for enumerations
    /// </summary>
    public static class EnumExtensions
    {
        /// <summary>
        /// Gets the enumeration description
        /// </summary>
        /// <param name="enumValue">Value to be described</param>
        /// <returns>return the enum value's description</returns>
        public static string Description(this Enum enumValue)
        {
            var enumType = enumValue.GetType();
            var field = enumType.GetField(enumValue.ToString());
            var attributes = field.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return attributes.Length == 0
                ? enumValue.ToString()
                : ((DescriptionAttribute)attributes[0]).Text;
        }

    }

}
