﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 04-23-2013
// ***********************************************************************
// <copyright file="GenericConfigurationElementConfiguration.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Configuration;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Base class for configuration element collections
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class GenericConfigurationElementConfiguration<T> : ConfigurationElementCollection where T : ConfigurationElement, new()
    {
        /// <summary>
        /// Returns the collection type (Add, remove and clear)
        /// </summary>
        /// <value>The type of the collection.</value>
        /// <returns>The <see cref="T:System.Configuration.ConfigurationElementCollectionType" /> of this collection.</returns>
        public override ConfigurationElementCollectionType CollectionType
        {
            get
            {
                return ConfigurationElementCollectionType.AddRemoveClearMap;
            }
        }

        /// <summary>
        /// Throws a not implememented exception
        /// </summary>
        /// <returns>Not implemented exception</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        protected override ConfigurationElement CreateNewElement() { throw new NotImplementedException(); }

        /// <summary>
        /// Throws a not implememented exception
        /// </summary>
        /// <param name="elementName">The element name to create</param>
        /// <returns>Not implemented exception</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        protected override ConfigurationElement CreateNewElement(string elementName) { throw new NotImplementedException(); }

        /// <summary>
        /// Throws a not implememented exception
        /// </summary>
        /// <param name="element">The configuration element to get by element key</param>
        /// <returns>Not implemented exception</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        protected override object GetElementKey(ConfigurationElement element) { throw new NotImplementedException(); }

        /// <summary>
        /// Get thes add element name
        /// </summary>
        /// <value>The name of the add element.</value>
        /// <returns>The name of the element.</returns>
        public new string AddElementName
        {
            get
            { return base.AddElementName; }

            set
            { base.AddElementName = value; }

        }

        /// <summary>
        /// The clear element name
        /// </summary>
        /// <value>The name of the clear element.</value>
        /// <returns>The name of the element.</returns>
        public new string ClearElementName
        {
            get
            { return base.ClearElementName; }

            set
            { base.AddElementName = value; }

        }

        /// <summary>
        /// The remove element name
        /// </summary>
        /// <value>The name of the remove element.</value>
        /// <returns>The name of the element.</returns>
        public new string RemoveElementName
        {
            get
            { return base.RemoveElementName; }
        }

        /// <summary>
        /// The element count in the collection
        /// </summary>
        /// <value>The count.</value>
        /// <returns>The number of elements in the collection.</returns>
        public new int Count
        {
            get { return base.Count; }
        }

        /// <summary>
        /// Gets a configuration element at the index specified
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>Returns the element of type T</returns>
        public T this[int index]
        {
            get
            {
                return (T)BaseGet(index);
            }
            set
            {
                if (BaseGet(index) != null)
                {
                    BaseRemoveAt(index);
                }
                BaseAdd(index, value);
            }
        }

        /// <summary>
        /// Gets a configuration element by name
        /// </summary>
        /// <param name="Name">The name.</param>
        /// <returns>Return the element of type T</returns>
        public new T this[string Name]
        {
            get
            {
                return (T)BaseGet(Name);
            }
        }

        /// <summary>
        /// Gets the element in the collection of type T
        /// </summary>
        /// <param name="item">The item of type T</param>
        /// <returns>The element of the item</returns>
        public int IndexOf(T item)
        {
            return BaseIndexOf(item);
        }

        /// <summary>
        /// Adds an element of type T
        /// </summary>
        /// <param name="item">The item to add of type T</param>
        public void Add(T item)
        {
            BaseAdd(item);
            // Add custom code here.
        }

        /// <summary>
        /// Adds an element of base type <see cref="System.Configuration.ConfigurationElement" />
        /// </summary>
        /// <param name="element">The configuration element to add</param>
        protected override void BaseAdd(ConfigurationElement element)
        {
            BaseAdd(element, false);
            // Add custom code here.
        }

        /// <summary>
        /// Removes the element of type T
        /// </summary>
        /// <param name="item">The item.</param>
        public abstract void Remove(T item);

        /// <summary>
        /// Removes the element at the requested index
        /// </summary>
        /// <param name="index">The index.</param>
        public void RemoveAt(int index)
        {
            BaseRemoveAt(index);
        }

        /// <summary>
        /// Removes the element by name
        /// </summary>
        /// <param name="name">The name.</param>
        public void Remove(string name)
        {
            BaseRemove(name);
        }

        /// <summary>
        /// Clears the collection
        /// </summary>
        public void Clear()
        {
            BaseClear();
            // Add custom code here.
        }
    }
}
