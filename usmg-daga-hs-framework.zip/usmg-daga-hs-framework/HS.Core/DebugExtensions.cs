﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 04-23-2013
// ***********************************************************************
// <copyright file="DebugExtensions.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Diagnostics;

/// <summary>
/// The Debugging namespace.
/// </summary>
namespace HS.Debugging
{
    /// <summary>
    /// Debugging extension class
    /// </summary>
    public static class DebugExtensions
    {

        #region ToDebug Permutations

        /// <summary>
        /// Writes the string to the Debug context.
        /// </summary>
        /// <param name="source">The source.</param>
        [DebuggerStepThrough]
        public static void ToDebug(this string source)
        {
            Debug.Write(source);
        }

        /// <summary>
        /// Formats and writes the string to the Debug context.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="data">The data.</param>
        [DebuggerStepThrough]
        public static void ToDebug(this string source, params object[] data)
        {
            Debug.Write(string.Format(source, data));
        }

        /// <summary>
        /// Writes the string as a line to the Debug context.
        /// </summary>
        /// <param name="source">The source.</param>
        [DebuggerStepThrough]
        public static void ToDebugLine(this string source)
        {
            Debug.WriteLine(source);
        }

        /// <summary>
        /// Formats and writes the string as a line to the debug context.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="data">The data.</param>
        [DebuggerStepThrough]
        public static void ToDebugLine(this string source, params object[] data)
        {
            Debug.WriteLine(string.Format(source, data));
        }

        /// <summary>
        /// Writes the formatted string of the exception to the
        /// Debug context.
        /// </summary>
        /// <param name="source">The source.</param>
        [DebuggerStepThrough]
        public static void ToDebug(this Exception source)
        {
            Debug.WriteLine(source.ToFormatedString(0));
        }

        /// <summary>
        /// Writes the formatted string of the exception to the
        /// Debug context with a specific message.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="message">The message.</param>
        [DebuggerStepThrough]
        public static void ToDebug(this Exception source, string message)
        {
            Debug.WriteLine(message);
            source.ToDebug();
        }

        /// <summary>
        /// Writes the formatted string of the exception to the
        /// Debug context with a specific formatted message.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="message">The message.</param>
        /// <param name="data">The data.</param>
        [DebuggerStepThrough]
        public static void ToDebug(this Exception source, string message,
                                   params object[] data)
        {
            Debug.WriteLine(message.FormatString(data));
            source.ToDebug();
        }

        /// <summary>
        /// Writes each member of a collection to a line in the
        /// Debug context.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source">The source.</param>
        [DebuggerStepThrough]
        public static void ToDebug<T>(this ICollection<T> source)
        {
            int l = source.GetType().FullName.Length;
            source.GetType().FullName.ToDebugLine();
            new string('-', l).ToDebugLine();

            Debug.Indent();
            foreach (var item in source)
            {
                if (item is IConvertible)
                {
                    Convert.ToString(item).ToDebugLine();
                }
                else
                {
                    item.ToString().ToDebugLine();
                }
            }
            Debug.Unindent();

            new string('-', l).ToDebugLine();
        }

        #endregion ToDebug Permutations




        /// <summary>
        /// Wrapper for string.Format so that it can be used as an
        /// extension method.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="data">The data.</param>
        /// <returns>System.String.</returns>
        [DebuggerStepThrough]
        public static string FormatString(this string source, params object[] data)
        {
            return string.Format(source, data);
        }
    }
}
