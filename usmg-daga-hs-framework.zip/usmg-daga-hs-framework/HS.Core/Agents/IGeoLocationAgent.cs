﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : todd.merritt
// Created          : 12-15-2014
//
// Last Modified By : todd.merritt
// Last Modified On : 12-15-2014
// ***********************************************************************
// <copyright file="SvcBindingType.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Creates a IGeoLocationAgent to interact with the HS.Services.GeoLocationService WCF Service.
    /// </summary>
    /// <typeparam name="IGeoLocationInterface">The interface for the HS.Services.GeolocationService.</typeparam>
    public class IGeoLocationAgent : BaseWCFAgent<IGeoLocationInterface>
    {

         /// <summary>
        /// Returns a service channel to be used by the agent with the proper client credentials
        /// </summary>
        /// <returns>A IGeoLocationInterface object which can call the service</returns>
        public override IGeoLocationInterface GetServiceChannel()
        {
            // This is  overriding an abstract function so that we  force developers to use the 
            // same standard function for getting a new Service Channel.
      
            HSGeoLocationClientConfiguration config = HSGeoLocationClientConfiguration.Current;

            var binding = GetBinding(config.SvcBindingType);

            return GetServiceChannel(binding, config.SvcEndpointURI);
        }


    }
}
