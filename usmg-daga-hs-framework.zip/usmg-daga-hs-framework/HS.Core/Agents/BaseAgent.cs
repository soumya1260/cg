﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-03-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-03-2013
// ***********************************************************************
// <copyright file="BaseAgent.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Diagnostics;
using System.ServiceModel;


/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Creates a base agent to interact with
    /// WCF services
    /// </summary>
    /// <typeparam name="ServiceInterface">The service type to create for communication</typeparam>
    public class BaseAgent<ServiceInterface> :  IDisposable
    {

        #region Member variables
        /// <summary>
        /// The channel factory for service interfaces
        /// </summary>
        protected ChannelFactory<ServiceInterface> _channelFactory;
        #endregion

        #region Public methods

        /// <summary>
        /// Returns a service channel to be used by the agent with the proper client credentials
        /// </summary>
        /// <param name="endpointName">The string identifying the endpoint to use from the Web.config file</param>
        /// <returns>A ServiceInterface object which can call the service</returns>
        public ServiceInterface GetServiceChannel(string endpointName)
        {
            _channelFactory = new ChannelFactory<ServiceInterface>(endpointName);
            _channelFactory.Faulted += new EventHandler(_channelFactory_Faulted);
            return _channelFactory.CreateChannel();
        }

        /// <summary>
        /// Event notification for faulted channel factories
        /// </summary>
        /// <param name="sender">The sender</param>
        /// <param name="e">The eventArgs</param>
        void _channelFactory_Faulted(object sender, EventArgs e)
        {
            Abort();
        }

        /// <summary>
        /// Aborts the call
        /// </summary>
        public void Abort()
        {

            _channelFactory.Abort();
            _channelFactory = null;
        }


        #endregion

        #region IDisposable Members
        /// <summary>
        /// Disposes the object
        /// </summary>
        public void Dispose()
        {
            try
            {
                if (_channelFactory != null)
                {

                    Trace.WriteLine(_channelFactory.State);

                    if (_channelFactory.State == CommunicationState.Faulted)
                        _channelFactory.Abort();

                    try
                    {
                        if (_channelFactory.State == CommunicationState.Opened)
                            _channelFactory.Close();
                    }
                    catch
                    {
                        _channelFactory.Abort();
                    }

                    _channelFactory = null;
                }

            }
            catch (Exception ex)
            {


                Trace.TraceError(ex.ToString());

                Log.LogException(ex);

                throw ex;
            }
        }

        #endregion

    }
}
