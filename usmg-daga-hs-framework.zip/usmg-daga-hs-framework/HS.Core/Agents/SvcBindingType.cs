﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : todd.merritt
// Created          : 12-15-2014
//
// Last Modified By : todd.merritt
// Last Modified On : 12-15-2014
// ***********************************************************************
// <copyright file="SvcBindingType.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************


/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// List of Supported Service Bindings
    /// </summary>
    public enum SvcBindingType
    {
        /// <summary>
        /// The HTTP
        /// </summary>
        Http = 0,
        /// <summary>
        /// The HTTPS
        /// </summary>
        Https = 1,
        /// <summary>
        /// The net TCP
        /// </summary>
        NetTcp = 2
    }

}
