﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : todd.merritt
// Created          : 12-15-2014
//
// Last Modified By : todd.merritt
// Last Modified On : 12-15-2014
// ***********************************************************************
// <copyright file="BaseWCFAgent.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.ServiceModel;
using System.ServiceModel.Security;
using System.ServiceModel.Channels;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{ /// <summary>
    /// Creates a base WCF agent to interact with WCF Services
    /// </summary>
    /// <typeparam name="T">The type off object to create for communication</typeparam>
    public abstract class BaseWCFAgent<T> : IDisposable
    {
        #region Member variables
        /// <summary>
        /// The channel factory for service interfaces
        /// </summary>
        protected ChannelFactory<T> _channelFactory;
        #endregion

        
        /// <summary>
        /// Returns a service channel to be used by the agent with the proper client credentials
        /// 
        /// Note:  Implementors of this class are forced to define this method based on their needs.
        /// </summary>
        /// <returns>An object of type T which can call the service</returns>
        public abstract T GetServiceChannel();
        
        /// <summary>
        /// Returns a service channel to be used by the agent with the proper client credentials
         /// </summary>
        /// <param name="binding">The channel binding used to connect to the svcEndpointURI</param>
        /// <param name="svcEndpointURI">The string identifying the endpoint to use from the Web.config file</param>
        /// <returns>An object of type T which can call the service</returns>
   
        protected T GetServiceChannel(Binding binding, string svcEndpointURI)
        {
            Uri endPointAddress = new Uri(svcEndpointURI);
            _channelFactory = new ChannelFactory<T>(binding, endPointAddress.ToString());

            T client = _channelFactory.CreateChannel();

            _channelFactory.Faulted += new EventHandler(_channelFactory_Faulted);
            return client;
        }


        /// <summary>
        /// Returns a channel binding for connecting to a WCF service.
        /// </summary>
        /// <param name="bindingType">The string identifying a binding type.</param>
        /// <returns>System.ServiceModel.Channels.Binding</returns>
   
        protected static Binding GetBinding(SvcBindingType bindingType)
        {
            // Get Binding based on Binding Type
            switch (bindingType)
            {
                case SvcBindingType.NetTcp:
                    return GetNetTcpBinding();

                case SvcBindingType.Http:
                    return GetBasicHttpBinding();

                default:
                    return GetBasicHttpBinding();

            }
        }

        #region Public Methods

        /// <summary>
        /// Returns a Basic Http Binding object used to connect to a WCF service.
        /// </summary>
              /// <returns>System.ServiceModel.Channels.Binding</returns>
        private static Binding GetBasicHttpBinding()
        {
            BasicHttpBinding httpBinding = new BasicHttpBinding();
            httpBinding.Name = "BasicHttpBinding";
            httpBinding.CloseTimeout = TimeSpan.FromMinutes(1);
            httpBinding.OpenTimeout = TimeSpan.FromMinutes(1);
            httpBinding.ReceiveTimeout = TimeSpan.FromMinutes(10);
            httpBinding.SendTimeout = TimeSpan.FromMinutes(1);
            httpBinding.AllowCookies = false;
            httpBinding.BypassProxyOnLocal = false;
            httpBinding.HostNameComparisonMode = HostNameComparisonMode.StrongWildcard;
            httpBinding.MaxBufferSize = 65536;
            httpBinding.MaxBufferPoolSize = 524288;
            httpBinding.MaxReceivedMessageSize = 65536;
            httpBinding.MessageEncoding = WSMessageEncoding.Text;
            httpBinding.TextEncoding = System.Text.Encoding.UTF8;
            httpBinding.TransferMode = TransferMode.Buffered;
            httpBinding.UseDefaultWebProxy = true;
            httpBinding.Security.Mode = BasicHttpSecurityMode.None;
            httpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
            httpBinding.Security.Transport.ProxyCredentialType = HttpProxyCredentialType.None;
            httpBinding.Security.Transport.Realm = "";
            httpBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.UserName;
            httpBinding.Security.Message.AlgorithmSuite = SecurityAlgorithmSuite.Default;

            return httpBinding;
        }

        /// <summary>
        /// Returns a Basic NetTcp Binding object used to connect to a WCF service.
        /// </summary>
        /// <returns>System.ServiceModel.Channels.Binding</returns>
        private static Binding GetNetTcpBinding()
        {
            NetTcpBinding nettcpBind = new NetTcpBinding();
            nettcpBind.Name = "NetTcpBinding";
            nettcpBind.CloseTimeout = TimeSpan.FromMinutes(1);
            nettcpBind.OpenTimeout = TimeSpan.FromMinutes(1);
            nettcpBind.ReceiveTimeout = TimeSpan.FromMinutes(10);
            nettcpBind.SendTimeout = TimeSpan.FromMinutes(1);
            nettcpBind.HostNameComparisonMode = HostNameComparisonMode.StrongWildcard;
            nettcpBind.MaxBufferSize = 2147483647;
            nettcpBind.MaxBufferPoolSize = 52428;
            nettcpBind.MaxConnections = 10;
            nettcpBind.MaxReceivedMessageSize = 65536;
            nettcpBind.TransferMode = TransferMode.Buffered;
            nettcpBind.Security.Mode = SecurityMode.None;
            nettcpBind.TransactionFlow = false;
            nettcpBind.ListenBacklog = 10;

            return nettcpBind;
        }


        /// <summary>
        /// Event notification for faulted channel factories
        /// </summary>
        /// <param name="sender">The sender</param>
        /// <param name="e">The eventArgs</param>
        public void _channelFactory_Faulted(object sender, EventArgs e)
        {
            Abort();
        }

        /// <summary>
        /// Aborts the call
        /// </summary>
        public void Abort()
        {
            _channelFactory.Abort();
            _channelFactory = null;
        }

        #endregion

        #region IDisposable Members
        /// <summary>
        /// Disposes the object
        /// </summary>
        public void Dispose()
        {
            try
            {
                if (_channelFactory != null)
                {

                    if (_channelFactory.State == CommunicationState.Faulted)
                        _channelFactory.Abort();

                    try
                    {
                        if (_channelFactory.State == CommunicationState.Opened)
                            _channelFactory.Close();
                    }
                    catch
                    {
                        _channelFactory.Abort();
                    }

                    _channelFactory = null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

    }
}
