﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-03-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-03-2013
// ***********************************************************************
// <copyright file="HSLoggingConfiguration.cs" company="Cigna-Healthspring">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Configuration;
using System.Diagnostics;

/// <summary>
/// This is the Healthspring ROOT namespace namespace. HS
/// </summary>
namespace HS
{
    /// <summary>
    /// Class HSLoggingConfiguration.
    /// </summary>
    public class HSLoggingConfiguration : ConfigurationSection
    {

        /*
         * USAGE NOTE: The following section must be added to the configsections block of the app/webconfig+
         * 
         * <section name="HS.logging" type="HS.HSLoggingConfiguration, HS.Core"/>
         * 
         * In addition the section must be added for the logging config:
         *<HS.logging traceLevel="Verbose" 
              writeToDB="false" 
              promotionEnvironment="DEV"
         *    defaultApplicationName="HS.Core"
         *    defaultFromEmail = "do.not.reply@healthspring.com"
         *    defaultToEmail="autowebexceptions@healthspring.com>
        </HS.logging>
         * 
         * The TraceLevel sets the lowest level at which the logger will actually write to the file
         * Make sure the user account running the app has full read write priv to the directory where the logs files are to be written
         */





        /// <summary>
        /// Gets or sets a value indicating whether [write automatic file].
        /// </summary>
        /// <value><c>true</c> if [write automatic file]; otherwise, <c>false</c>.</value>
        [ConfigurationProperty(
           "writeToDB",
           DefaultValue = true,
           IsRequired = false)]
        public bool WriteToDB
        {
            get
            {
                return (bool)this["writeToDB"];
            }
            set
            {
                this["writeToDB"] = value;
            }
        }


        /// <summary>
        /// Gets or sets the trace level.
        /// </summary>
        /// <value>The trace level.</value>
        [ConfigurationProperty(
            "traceLevel",
            DefaultValue = System.Diagnostics.TraceLevel.Off,
            IsRequired = false)]
        public TraceLevel TraceLevel
        {
            get
            {
                return (TraceLevel)this["traceLevel"];
                
                
            }
            set
            {
                this["traceLevel"] = value;
            }
        }

       

        /// <summary>
        /// Gets or sets the default application name to use in the event the application fails to retrieve its own executable name.
        /// </summary>
        /// <value>the application name.</value>
        [ConfigurationProperty(
            "defaultApplicationName",
            DefaultValue = "",
            IsRequired = false)]
        public string DefaultApplicationName
        {
            get
            {
                return (string)this["defaultApplicationName"];
            }
            set
            {
                this["defaultApplicationName"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the default from email address in the event the DB cant be reached.
        /// </summary>
        /// <value>the application name.</value>
        [ConfigurationProperty(
            "defaultToEmailForSendMail",
            IsRequired = false)]
        public string DefaultToEmailForSendMail
        {
            get
            {
                return (string)this["defaultToEmailForSendMail"];
            }
            set
            {
                this["defaultToEmailForSendMail"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the default from email address in the event the DB cant be reached.
        /// </summary>
        /// <value>the application name.</value>
        [ConfigurationProperty(
            "useDefaultToEmailForSendMail",
            IsRequired = false)]
        public bool UseDefaultToEmailForSendMail
        {
            get
            {
                if (this["useDefaultToEmailForSendMail"] == null)
                    return false;
                else
                    return (bool)this["useDefaultToEmailForSendMail"];
            }
            set
            {
                this["useDefaultToEmailForSendMail"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the default from email address in the event the DB cant be reached.
        /// </summary>
        /// <value>the application name.</value>
        [ConfigurationProperty(
            "defaultFromEmail",
            DefaultValue = "do.not.reply@healthspring.com",
            IsRequired = false)]
        public string DefaultFromEmail
        {
            get
            {
                return (string)this["defaultFromEmail"];
            }
            set
            {
                this["defaultFromEmail"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the default To email address in the event the DB cant be reached.
        /// </summary>
        /// <value>the application name.</value>
        [ConfigurationProperty(
            "defaultToEmail",
            DefaultValue = "autowebexceptions@healthspring.com",
            IsRequired = false)]
        public string DefaultToEmail
        {
            get
            {
                return (string)this["defaultToEmail"];
            }
            set
            {
                this["defaultToEmail"] = value;
            }
        }

     

        [ConfigurationProperty(
            "promotionEnvironment",
            DefaultValue = "PROD",
            IsRequired = false)]
        public string PromotionEnvironment
        {
            get
            {
                return (string)this["promotionEnvironment"];
            }
            set
            {
                this["promotionEnvironment"] = value;
            }
        }



        // Created Private String Var to get overrideAppName from config because value of OverrideAppname 
        // may not be a valid bool string. This function is used to clean value prior to converting the 
        // data to a bool.
        [ConfigurationProperty("overrideAppName", DefaultValue = "false", IsRequired = false)]
        private string overrideAppNameString
        {
            get
            {
                return (string)this["overrideAppName"];
            }
            set
            {
                bool test;

                if (bool.TryParse(value, out test))
                {
                    this["overrideAppName"] = value;
                }
                else
                { 
                    this["overrideAppName"] = "False"; 
                }
            }
        }

        public bool OverrideAppName
        {
            get
            {
                return bool.Parse(overrideAppNameString);
            }
          
        }

        [ConfigurationProperty(
           "emailServiceEndpointAddress",
           IsRequired = false)]
        public string EmailServiceEndpointAddress
        {
            get
            {
                return (string)this["emailServiceEndpointAddress"];
            }
            set
            {
                this["emailServiceEndpointAddress"] = value;
            }
        }

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>The current.</value>
        public static HSLoggingConfiguration Current
        {
            get
            {

                HSLoggingConfiguration value = ConfigurationManager.GetSection(
                    "HS.logging") as HSLoggingConfiguration;

                if (value == null)
                {
                    value = new HSLoggingConfiguration();
                }

                return value;

            }
        }

    }

    /// <summary>
    /// Class DirectoryCollection.
    /// </summary>
    public class DirectoryCollection : ConfigurationElementCollection
    {

        /// <summary>
        /// Gets the type of the <see cref="T:System.Configuration.ConfigurationElementCollection" />.
        /// </summary>
        /// <value>The type of the collection.</value>
        /// <returns>The <see cref="T:System.Configuration.ConfigurationElementCollectionType" /> of this collection.</returns>
        public override
            ConfigurationElementCollectionType CollectionType
        {
            get
            {
                return

                    ConfigurationElementCollectionType.AddRemoveClearMap;
            }
        }

        /// <summary>
        /// When overridden in a derived class, creates a new <see cref="T:System.Configuration.ConfigurationElement" />.
        /// </summary>
        /// <returns>A new <see cref="T:System.Configuration.ConfigurationElement" />.</returns>
        protected override
            ConfigurationElement CreateNewElement()
        {
            return new DirectoryElement();
        }


        /// <summary>
        /// Creates the new element.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns>ConfigurationElement.</returns>
        protected override
            ConfigurationElement CreateNewElement(
            string name)
        {
            return new DirectoryElement() { Name = name };
        }

        /// <summary>
        /// Gets the element key for a specified configuration element when overridden in a derived class.
        /// </summary>
        /// <param name="element">The <see cref="T:System.Configuration.ConfigurationElement" /> to return the key for.</param>
        /// <returns>An <see cref="T:System.Object" /> that acts as the key for the specified <see cref="T:System.Configuration.ConfigurationElement" />.</returns>
        protected override Object
            GetElementKey(ConfigurationElement element)
        {
            return ((DirectoryElement)element).Name;
        }

        /// <summary>
        /// Gets or sets the name of the <see cref="T:System.Configuration.ConfigurationElement" /> to associate with the add operation in the <see cref="T:System.Configuration.ConfigurationElementCollection" /> when overridden in a derived class.
        /// </summary>
        /// <value>The name of the add element.</value>
        /// <returns>The name of the element.</returns>
        public new string AddElementName
        {
            get
            { return base.AddElementName; }

            set
            { base.AddElementName = value; }

        }

        /// <summary>
        /// Gets or sets the name for the <see cref="T:System.Configuration.ConfigurationElement" /> to associate with the clear operation in the <see cref="T:System.Configuration.ConfigurationElementCollection" /> when overridden in a derived class.
        /// </summary>
        /// <value>The name of the clear element.</value>
        /// <returns>The name of the element.</returns>
        public new string ClearElementName
        {
            get
            { return base.ClearElementName; }

            set
            { base.AddElementName = value; }

        }

        /// <summary>
        /// Gets or sets the name of the <see cref="T:System.Configuration.ConfigurationElement" /> to associate with the remove operation in the <see cref="T:System.Configuration.ConfigurationElementCollection" /> when overridden in a derived class.
        /// </summary>
        /// <value>The name of the remove element.</value>
        /// <returns>The name of the element.</returns>
        public new string RemoveElementName
        {
            get
            { return base.RemoveElementName; }
        }

        /// <summary>
        /// Gets the number of elements in the collection.
        /// </summary>
        /// <value>The count.</value>
        /// <returns>The number of elements in the collection.</returns>
        public new int Count
        {
            get { return base.Count; }
        }


        /// <summary>
        /// Gets or sets the <see cref="DirectoryElement"/> at the specified index.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>DirectoryElement.</returns>
        public DirectoryElement this[int index]
        {
            get
            {
                return (DirectoryElement)BaseGet(index);
            }
            set
            {
                if (BaseGet(index) != null)
                {
                    BaseRemoveAt(index);
                }
                BaseAdd(index, value);
            }
        }

        /// <summary>
        /// Gets the <see cref="DirectoryElement"/> with the specified name.
        /// </summary>
        /// <param name="Name">The name.</param>
        /// <returns>DirectoryElement.</returns>
        new public DirectoryElement this[string Name]
        {
            get
            {
                return (DirectoryElement)BaseGet(Name);
            }
        }

        /// <summary>
        /// Indexes the of.
        /// </summary>
        /// <param name="item">The item.</param>
        /// <returns>System.Int32.</returns>
        public int IndexOf(DirectoryElement item)
        {
            return BaseIndexOf(item);
        }

        /// <summary>
        /// Adds the specified item.
        /// </summary>
        /// <param name="item">The item.</param>
        public void Add(DirectoryElement item)
        {
            BaseAdd(item);
            // Add custom code here.
        }

        /// <summary>
        /// Adds a configuration element to the <see cref="T:System.Configuration.ConfigurationElementCollection" />.
        /// </summary>
        /// <param name="element">The <see cref="T:System.Configuration.ConfigurationElement" /> to add.</param>
        protected override void
            BaseAdd(ConfigurationElement element)
        {
            BaseAdd(element, false);
            // Add custom code here.
        }

        /// <summary>
        /// Removes the specified item.
        /// </summary>
        /// <param name="item">The item.</param>
        public void Remove(DirectoryElement item)
        {
            if (BaseIndexOf(item) >= 0)
                BaseRemove(item.Name);
        }

        /// <summary>
        /// Removes the attribute.
        /// </summary>
        /// <param name="index">The index.</param>
        public void RemoveAt(int index)
        {
            BaseRemoveAt(index);
        }

        /// <summary>
        /// Removes the specified name.
        /// </summary>
        /// <param name="name">The name.</param>
        public void Remove(string name)
        {
            BaseRemove(name);
        }

        /// <summary>
        /// Clears this instance.
        /// </summary>
        public void Clear()
        {
            BaseClear();
            // Add custom code here.
        }

    }

    /// <summary>
    /// Class DirectoryElement.
    /// </summary>
    public class DirectoryElement : ConfigurationElement
    {

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [ConfigurationProperty("name", IsKey = true,
            IsDefaultCollection = true)]
        public string Name
        {
            get
            {
                return (string)this["name"];
            }
            set
            {
                this["name"] = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="DirectoryElement"/> is enabled.
        /// </summary>
        /// <value><c>true</c> if enabled; otherwise, <c>false</c>.</value>
        [ConfigurationProperty("enabled", DefaultValue = "true",
            IsRequired = false)]
        public bool Enabled
        {
            get
            {
                return (bool)this["enabled"];
            }
            set
            {
                this["enabled"] = value;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DirectoryElement"/> class.
        /// </summary>
        public DirectoryElement() : base() { }

    }
}
