﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : todd.merritt
// Created          : 12-15-2014
//
// Last Modified By : todd.merritt
// Last Modified On : 12-23-2014
// ***********************************************************************
// <copyright file="HSGeoLocationServiceConfiguration.cs" company="Cigna-Healthspring">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

/// <summary>
/// This is the Healthspring ROOT namespace namespace. HS
/// </summary>
namespace HS
{
    /// <summary>
    /// Class HSGeoLocationServiceConfiguration.
    /// </summary>
    public class HSGeoLocationServiceConfiguration : ConfigurationSection
    {
        /*
        * USAGE NOTE: The following section must be added to the configsections block of the app/webconfig
        * 
        *      <section name="HS.GeoLocationService" type="HS.HSGeoLocationServiceConfiguration, HS.Core"/>
        * 
        * In addition the section must be added for the geolocation config, here is an example:
        * 
        *      <HS.GeoLocationService 
        *                bingMapsKey="AtD9eYRcYCQaSCyt0a7TwfLmIR31hmrUatyWemTk57GQmHgtYL96__4yB1Ni2tjM" 
                         bingURIFormat="http://dev.virtualearth.net/REST/v1/Locations/{0}?key={1}"
        *                countyAbbreviationRemovalListString="Co.,Par.,Bur.">
        *      </HS.GeoLocationService>
        */

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>The current.</value>
        public static HSGeoLocationServiceConfiguration Current
        {
            get
            {

                HSGeoLocationServiceConfiguration value = ConfigurationManager.GetSection("HS.GeoLocationService") as HSGeoLocationServiceConfiguration;

                if (value == null)
                {
                    value = new HSGeoLocationServiceConfiguration();
                }

                return value;

            }
        }

        /// <summary>
        /// Gets or sets the Bing Map API Key.
        /// </summary>
        /// <value>The Bing Map API Key.</value>
        [ConfigurationProperty(
            "bingMapsKey",
            DefaultValue = "",
            IsRequired = true)]
        public string BingMapsKey
        {
            get
            {
                return (string)this["bingMapsKey"];
            }
            set
            {
                this["bingMapsKey"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the Bing Map URI Format string.
        /// </summary>
        /// <value>The Bing Map URI Format string.</value>
        [ConfigurationProperty(
            "bingURIFormat",
            DefaultValue = "",
            IsRequired = true)]
        public string BingURIFormat
        {
            get
            {
                return (string)this["bingURIFormat"];
            }
            set
            {
                this["bingURIFormat"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the CountyAbbreviationRemovalListString which is a comma delimted string of county 
        /// abbrevations that are to be stripped out of a county nameprior to it being 
        /// returned to the client.
        /// 
        /// Examples: 
        ///             Co.  = County
        ///             Par. = Parrish
        ///             Bur. = Burough
        /// </summary>
        /// <value>the CountyAbbreviationRemovalListString.</value>
        [ConfigurationProperty(
            "countyAbbreviationRemovalListString",
            DefaultValue = "",
            IsRequired = true)]
        private string CountyAbbreviationRemovalListString
        {
            get
            {
                return (string)this["countyAbbreviationRemovalListString"];
            }
            set
            {
                this["countyAbbreviationRemovalListString"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the CountyAbbreviationRemovalList which is a list of county 
        /// abbrevations that are to be stripped out of a county name prior to it being 
        /// returned to the client.
        /// 
        /// Examples: 
        ///             Co.  = County
        ///             Par. = Parrish
        ///             Bur. = Burough
        /// </summary>
        /// <value>the CountyAbbreviationRemovalListString.</value>
        public  List<String> CountyAbbreviationRemovalList
        {
            get
            {
               return CountyAbbreviationRemovalListString.Split(',').ToList().FindAll(item => item.IsNullOrEmpty() == false);
            }
            set
            {
                CountyAbbreviationRemovalListString = String.Join(",", value.FindAll(item => item.IsNullOrEmpty() == false).ToArray());
            }
        }

    }
    

}
