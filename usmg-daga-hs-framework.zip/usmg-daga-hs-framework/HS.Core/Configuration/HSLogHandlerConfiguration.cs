﻿

//Depricated 9/4/2013

//namespace HS.Configuration
//{
//    /// <summary>
//    /// The top level configuration item for log handling
//    /// </summary>
//    public class HSLogHandlerConfiguration:ConfigurationSection
//    {
//        /// <summary>
//        /// Gets the from email address to send out emails
//        /// </summary>
//        [ConfigurationProperty("fromEmail", DefaultValue="do.not.reply@healthspring.com", IsRequired=false)]
//        public string FromEmail
//        {
//            get
//            {
//                return (string)this["fromEmail"];
//            }
//            set
//            {
//                this["fromEmail"] = value;
//            }
//        }

//        /// <summary>
//        /// Gets the current configuration
//        /// </summary>
//        public static HSLogHandlerConfiguration Current
//        {
//            get
//            {
//                return ConfigurationManager.GetSection("hs/log") as HSLogHandlerConfiguration;
//            }
//        }

//        /// <summary>
//        /// The missing configuration email collection
//        /// </summary>
//        [ConfigurationProperty("missingConfigEmail", IsDefaultCollection=false)]
//        public MissingConfigEmailElementCollection MissingConfigEmailAddresses
//        {
//            get
//            {
//                return (MissingConfigEmailElementCollection)this["missingConfigEmail"];
//            }
//            set
//            {
//                this["missingConfigEmail"] = value;
//            }
//        }
        
//        /// <summary>
//        /// Collection of default action email addresses
//        /// </summary>
//        [ConfigurationProperty("defaultActionEmail", IsDefaultCollection = false)]
//        public DefaultActionEmailElementCollection DefaultActionEmailAddresses
//        {
//            get
//            {
//                return (DefaultActionEmailElementCollection)this["defaultActionEmail"];
//            }
//            set
//            {
//                this["defaultActionEmail"] = value;
//            }
//        }
//    }

//    /// <summary>
//    /// Collection of email address to inform HS Log Handler admins a configuration is missing
//    /// </summary>
//    public class MissingConfigEmailElementCollection : GenericConfigurationElementConfiguration<MissingConfigEmailElement>
//    {
//        /// <summary>
//        /// Creates a new empty missing configuration email element
//        /// </summary>
//        /// <returns>An empty missing configuration email element</returns>
//        protected override ConfigurationElement CreateNewElement()
//        {
//            return new MissingConfigEmailElement();
//        }

//        /// <summary>
//        /// Creates a new missing configuration email element with the key from <paramref name="elementName"/> elementName
//        /// </summary>
//        /// <param name="elementName">The string to apply to the elementName</param>
//        /// <returns>A populated configuration element</returns>
//        protected override ConfigurationElement CreateNewElement(string elementName)
//        {
//            return new MissingConfigEmailElement { Value = elementName };
//        }

//        /// <summary>
//        /// Gets the element key from the configuration element parameter
//        /// </summary>
//        /// <param name="element">Element to get the key</param>
//        /// <returns>Returns the email address in the missing config email element</returns>
//        protected override object GetElementKey(ConfigurationElement element)
//        {
//            return ((MissingConfigEmailElement)element).Value;
//        }

//        /// <summary>
//        /// Removes the element from the collection
//        /// </summary>
//        /// <param name="item">Item to remove</param>
//        public override void Remove(MissingConfigEmailElement item)
//        {
//            if (BaseIndexOf(item) >= 0)
//                BaseRemove(item.Value);
//        }
//    }

//    /// <summary>
//    /// The collection of default action email addresses
//    /// </summary>
//    public class DefaultActionEmailElementCollection : GenericConfigurationElementConfiguration<DefaultActionEmailElement>
//    {
//        /// <summary>
//        /// Creates an empty default action email element 
//        /// </summary>
//        /// <returns>The empty configuration element</returns>
//        protected override ConfigurationElement CreateNewElement()
//        {
//            return new DefaultActionEmailElement();
//        }

//        /// <summary>
//        /// Creates a new element f
//        /// </summary>
//        /// <param name="elementName"></param>
//        /// <returns></returns>
//        protected override ConfigurationElement CreateNewElement(string elementName)
//        {
//            return new DefaultActionEmailElement { Value = elementName };
//        }

//        protected override object GetElementKey(ConfigurationElement element)
//        {
//            return ((DefaultActionEmailElement)element).Value;
//        }

//        public override void Remove(DefaultActionEmailElement item)
//        {
//            if (BaseIndexOf(item) >= 0)
//                BaseRemove(item.Value);
//        }
//    }

//    /// <summary>
//    /// Default action email address if there isn't a matching configuration in the database
//    /// </summary>
//    public class MissingConfigEmailElement : ConfigurationElement
//    {
//        [ConfigurationProperty("value", IsKey = true, IsDefaultCollection = true, IsRequired = true)]
//        public string Value
//        {
//            get
//            {
//                return (string)this["value"];
//            }
//            set
//            {
//                this["value"] = value;
//            }
//        }

//    }

//    /// <summary>
//    /// Default action email address if there isn't a matching configuration for the exception
//    /// </summary>
//    public class DefaultActionEmailElement : ConfigurationElement
//    {
//        /// <summary>
//        /// The email address to send to
//        /// </summary>
//        [ConfigurationProperty("value", IsKey = true, IsDefaultCollection = true, IsRequired = true)]
//        public string Value
//        {
//            get
//            {
//                return (string)this["value"];
//            }
//            set
//            {
//                this["value"] = value;
//            }
//        }

//    }

//}
