﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-03-2013
// ***********************************************************************
// <copyright file="HSServicesConfiguration.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Configuration;

/// <summary>
/// The Configuration namespace.
/// </summary>
namespace HS.Configuration
{
    /// <summary>
    /// HS Service configuration class
    /// </summary>
    public class HSServicesConfiguration : ConfigurationSection
    {
        /// <summary>
        /// Run as a service or in a console window
        /// </summary>
        /// <value><c>true</c> if [run asynchronous service]; otherwise, <c>false</c>.</value>
        [ConfigurationProperty("runAsService", DefaultValue = "false", IsRequired = false)]
        public bool RunAsService
        {
            get
            {
                return (bool)this["runAsService"];
            }
            set
            {
                this["runAsService"] = value;
            }
        }

        /// <summary>
        /// The service collection of ServiceElement
        /// </summary>
        /// <value>The services.</value>
        [ConfigurationProperty("services", IsDefaultCollection = false)]
        public ServicesCollection Services
        {
            get
            {
                return (ServicesCollection)this["services"];
            }
            set
            {
                this["services"] = value;
            }
        }

        /// <summary>
        /// The log depth successful entries are kept
        /// </summary>
        /// <value>The maximum success log depth.</value>
        [ConfigurationProperty("maxSuccessLogDepth", DefaultValue = "1", IsRequired = false)]
        public int MaxSuccessLogDepth
        {
            get
            {
                return (int)this["maxSuccessLogDepth"];
            }
            set
            {
                this["maxSuccessLogDepth"] = value;
            }
        }

        /// <summary>
        /// The log depth failed entries are kept
        /// </summary>
        /// <value>The maximum failure log depth.</value>
        [ConfigurationProperty("maxFailureLogDepth", DefaultValue = "40", IsRequired = false)]
        public int MaxFailureLogDepth
        {
            get
            {
                return (int)this["maxFailureLogDepth"];
            }
            set
            {
                this["maxFailureLogDepth"] = value;
            }
        }

        /// <summary>
        /// Should the log write the full name of the object
        /// </summary>
        /// <value><c>true</c> if [log object full name]; otherwise, <c>false</c>.</value>
        [ConfigurationProperty("logObjectFullName", DefaultValue = "false", IsRequired = false)]
        public bool LogObjectFullName
        {
            get
            {
                return (bool)this["logObjectFullName"];
            }
            set
            {
                this["logObjectFullName"] = value;
            }
        }

        /// <summary>
        /// Gets the services configuration
        /// </summary>
        /// <value>The current.</value>
        public static HSServicesConfiguration Current
        {
            get
            {
                return ConfigurationManager.GetSection("hs/services") as HSServicesConfiguration;
            }
        }

    }

    /// <summary>
    /// Returns a collection service configurations
    /// </summary>
    public class ServicesCollection : GenericConfigurationElementConfiguration<ServiceElement>
    {
        /// <summary>
        /// Creates a new service element
        /// </summary>
        /// <returns>Created service element</returns>
        protected override
            ConfigurationElement CreateNewElement()
        {
            return new ServiceElement();
        }

        /// <summary>
        /// Creates a new service element by service name
        /// </summary>
        /// <param name="serviceTypeName">Name of the service type.</param>
        /// <returns>ConfigurationElement.</returns>
        protected override
            ConfigurationElement CreateNewElement(
            string serviceTypeName)
        {
            return new ServiceElement() { ServiceTypeName = serviceTypeName };
        }

        /// <summary>
        /// Get the element key for the configured service element
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>Object.</returns>
        protected override Object
            GetElementKey(ConfigurationElement element)
        {
            return ((ServiceElement)element).ServiceTypeName;
        }

        /// <summary>
        /// Removes a service element
        /// </summary>
        /// <param name="item">The item.</param>
        public override void Remove(ServiceElement item)
        {

            if (BaseIndexOf(item) >= 0)
                BaseRemove(item.ServiceTypeName);
        }
    }

    /// <summary>
    /// The service element to configure a service element
    /// </summary>
    public class ServiceElement : ConfigurationElement
    {
        /// <summary>
        /// The service type name of the configuration element
        /// </summary>
        /// <value>The name of the service type.</value>
        [ConfigurationProperty("type", IsKey = true, IsDefaultCollection = true)]
        public string ServiceTypeName
        {
            get
            {
                return (string)this["type"];
            }
            set
            {
                this["type"] = value;
            }
        }

        /// <summary>
        /// Is the service enabled?
        /// </summary>
        /// <value><c>true</c> if enabled; otherwise, <c>false</c>.</value>
        [ConfigurationProperty("enabled", DefaultValue = "true", IsRequired = false)]
        public bool Enabled
        {
            get
            {
                return (bool)this["enabled"];
            }
            set
            {
                this["enabled"] = value;
            }
        }
                
    }
}
