﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : todd.merritt
// Created          : 12-15-2014
//
// Last Modified By : todd.merritt
// Last Modified On : 12-23-2014
// ***********************************************************************
// <copyright file="HSGeoLocationClientConfiguration.cs" company="Cigna-Healthspring">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Configuration;

/// <summary>
/// This is the Healthspring ROOT namespace namespace. HS
/// </summary>
namespace HS
{    /// <summary>
    /// Class HSGeoLocationClientConfiguration.
    /// </summary>
    public class HSGeoLocationClientConfiguration : ConfigurationSection
    {

        /*
         * USAGE NOTE: The following section must be added to the configsections block of the app/webconfig
         * 
         *      <section name="HS.GeoLocationClient" type="HS.HSGeoLocationClientConfiguration, HS.Core"/>
         * 
         * In addition the section must be added for the geolocation config, here is an example:
         *      <HS.GeoLocationClient
         *          svcEndpointURI="http://hstnsvcdev01/HS.Services.GeoLocation/GeoLocationService.svc"
         *          svcBindingTypeString="Http">
         *      </HS.GeoLocationClient>
         */


        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>The current.</value>
        public static HSGeoLocationClientConfiguration Current
        {
            get
            {

                HSGeoLocationClientConfiguration value = ConfigurationManager.GetSection("HS.GeoLocationClient") as HSGeoLocationClientConfiguration;

                if (value == null)
                {
                    value = new HSGeoLocationClientConfiguration();
                }

                return value;

            }
        }

        /// <summary>
        /// Gets or sets the Service Endpoint URI used to connect to WCF service.
        /// </summary>
        /// <value>string</value>
        [ConfigurationProperty(
            "svcEndpointURI",
            DefaultValue = "",
            IsRequired = true)]
        public string SvcEndpointURI
        {
            get
            {
                return (string)this["svcEndpointURI"];
            }
            set
            {
                this["svcEndpointURI"] = value;
            }
        }

        /// <summary>
        ///  Gets or sets the string used to determine the service binding type used to connect to WCF service. 
        /// </summary>
        /// <value>string</value>
        [ConfigurationProperty(
            "svcBindingTypeString",
            DefaultValue = "",
            IsRequired = true)]
        private string SvcBindingTypeString
        {
            get
            {
                return (string)this["svcBindingTypeString"];
            }
            set
            {
                this["svcBindingTypeString"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the service binding type used to connect to WCF service.
        /// </summary>
        /// <value>SvcBindingType</value>
        public SvcBindingType SvcBindingType
        {
            get
            {
                return (SvcBindingType)Enum.Parse(typeof(SvcBindingType), SvcBindingTypeString);
            }
            set
            {
                SvcBindingTypeString = value.ToString();
            }
        }

    }


}