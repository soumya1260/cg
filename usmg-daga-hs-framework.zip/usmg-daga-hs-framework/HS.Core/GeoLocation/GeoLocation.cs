﻿namespace HS
{
    public static class GeoLocation
    {
        /// <summary>
        /// Searches for Geo Locations based on address details in the form of a single search term. 
        /// Examples:
        ///  - Address
        ///  - City and/or State
        ///  - Zip Code
        ///  - GeoCodes(Lat and Long)
        /// </summary>
        /// <param name="searchTerm">The Search Term.</param>
        /// <returns>GeoLocationSearchResponse</returns>
        public static GeoLocationSearchResponse GeoLocationSearch(string searchTerm)
        {
            GeoLocationSearchResponse geoResponse = new GeoLocationSearchResponse();

            using (IGeoLocationAgent geoAgent = new IGeoLocationAgent())
            {
                GeoLocationSearchRequest geoRequest = new GeoLocationSearchRequest();

                IGeoLocationInterface geoLocation = geoAgent.GetServiceChannel();

                try
                {
                    geoRequest.Item = new GeoLocationSearchCriteria() { SearchTerm = searchTerm };

                    geoResponse = geoLocation.GeoLocationSearch(geoRequest);
                }
                finally
                {
                    geoAgent.Dispose();
                }
            }

            return geoResponse;
        }
    }
}
