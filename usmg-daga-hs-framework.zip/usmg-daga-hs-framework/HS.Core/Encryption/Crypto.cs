﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 04-23-2013
// ***********************************************************************
// <copyright file="Crypto.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// The Encryption namespace.
/// </summary>
namespace HS.Encryption
{
    /// <summary>
    /// Static cryptography helper class
    /// </summary>
    public static class Crypto
    {

        #region "Private Members"

        /// <summary>
        /// The _pass phrase
        /// </summary>
        private const string _passPhrase = "H0J70BKN1U50140370S4J06CHVQO6ED4YJ1VS36D7R8A8L6C28YB45Q70N13388O4";
        /// <summary>
        /// The _salt value
        /// </summary>
        private const string _saltValue = "B8u5h@nM@11k";
        /// <summary>
        /// The _iterations
        /// </summary>
        private const int _iterations = 2;
        /// <summary>
        /// The _iv
        /// </summary>
        private const string _iv = "@1B2c3D4e5F6g7H8"; //Must be 16 bytes
        /// <summary>
        /// The _key size
        /// </summary>
        private const int _keySize = 256; //Can be 128, 192 and 256
        /// <summary>
        /// The _enc type
        /// </summary>
        private const string _encType = "MD5"; //Can be MD5 / SHA1

        #endregion




        /// <summary>
        /// Encrypt text using MultiEncrypt.DLL reference.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns>System.String.</returns>
        public static string Encrypt(String text)
        {

            string encText = MultiCrypt.Encrypt(text, _passPhrase, _saltValue, _encType, _iterations, _iv, _keySize);
            return encText;
        }

        /// <summary>
        /// Ecrypt text using MultiEncrypt.DLL reference.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns>System.String.</returns>
        public static string DeCrypt(string text)
        {
            string encText = MultiCrypt.Decrypt(text, _passPhrase, _saltValue, _encType, _iterations, _iv, _keySize);
            return encText;
        }
    }

    /// <summary>
    /// Class MultiCrypt.
    /// </summary>
    class MultiCrypt
    {

        /// <summary>
        /// Enum EncryptionType
        /// </summary>
        public enum EncryptionType
        {
            /// <summary>
            /// The decimal S_3
            /// </summary>
            DES_3 = 0,
            /// <summary>
            /// The RSA
            /// </summary>
            RSA = 1,
            /// <summary>
            /// The description
            /// </summary>
            DES = 2,
            /// <summary>
            /// The rijandel
            /// </summary>
            RIJANDEL = 3
        }
        //The public key only
        /// <summary>
        /// The public key
        /// </summary>
        static string publicKey;
        /// <summary>
        /// The private key
        /// </summary>
        static string privateKey;
        //A combination of both the public and private keys  
        /// <summary>
        /// The XML keys
        /// </summary>
        static string xmlKeys;
        /// <summary>
        /// The key3 description
        /// </summary>
        byte[] key3DES = {
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12,
		13,
		14,
		15,
		16,
		17,
		18,
		19,
		20,
		21,
		22,
		23,
		24
	};
        /// <summary>
        /// The key
        /// </summary>
        byte[] key = {
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	};
        /// <summary>
        /// The iv
        /// </summary>
        byte[] iv = {
		65,
		110,
		68,
		26,
		69,
		178,
		200,
		219

	};

        //Dim cipherText As String
        //Dim passPhrase As String = "Pas5pr@se"
        //Dim saltValue As String = "s@1tValue"
        //Dim hashAlgorithm As String = "SHA1"
        //Dim passwordIterations As Integer = 2
        //Dim initVector As String = "@1B2c3D4e5F6g7H8"
        //Dim keySize As Integer = 192

        /// <summary>
        /// Initializes a new instance of the <see cref="MultiCrypt"/> class.
        /// </summary>
        public MultiCrypt()
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            xmlKeys = rsa.ToXmlString(true);
            publicKey = rsa.ToXmlString(false);
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="MultiCrypt"/> class.
        /// </summary>
        /// <param name="encType">Type of the enc.</param>
        public MultiCrypt(string encType)
        {
            switch (encType)
            {
                case "3DES":
                    break;
                case "RSA":
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Encrypts the specified plain text.
        /// </summary>
        /// <param name="plainText">The plain text.</param>
        /// <param name="encType">Type of the enc.</param>
        /// <returns>System.Byte[][].</returns>
        public byte[] Encrypt(string plainText, string encType)
        {
            // Declare a UTF8Encoding object so we may use the GetByte
            // method to transform the plainText into a Byte array.
            UTF8Encoding utf8encoder = new UTF8Encoding();
            byte[] inputInBytes = utf8encoder.GetBytes(plainText);

            // Create a new DES / TripleDES service provider
            //object tdesProvider = null;
            //object cryptoTransform = null;
            switch (encType)
            {
                case "DES":
                    using (DESCryptoServiceProvider tdesProvider = new DESCryptoServiceProvider())
                    {
                        // The ICryptTransform interface uses the TripleDES
                        // crypt provider along with encryption key and init vector
                        // information
                        ICryptoTransform cryptoTransform = tdesProvider.CreateEncryptor(this.key, this.iv);
                        // All cryptographic functions need a stream to output the
                        // encrypted information. Here we declare a memory stream
                        // for this purpose.
                        using (MemoryStream encryptedStream = new MemoryStream())
                        {
                            CryptoStream cryptStream = new CryptoStream(encryptedStream, cryptoTransform, CryptoStreamMode.Write);

                            // Write the encrypted information to the stream. Flush the information
                            // when done to ensure everything is out of the buffer.
                            cryptStream.Write(inputInBytes, 0, inputInBytes.Length);
                            cryptStream.FlushFinalBlock();
                            encryptedStream.Position = 0;

                            // Read the stream back into a Byte array and return it to the calling
                            // method.
                            byte[] result = new byte[encryptedStream.Length];
                            encryptedStream.Read(result, 0, (int)encryptedStream.Length);
                            cryptStream.Close();
                            return result;
                        }

                    }
                //break;
                case "3DES":
                    using (TripleDESCryptoServiceProvider tdesProvider = new TripleDESCryptoServiceProvider())
                    {
                        // The ICryptTransform interface uses the TripleDES
                        // crypt provider along with encryption key and init vector
                        // information
                        ICryptoTransform cryptoTransform = tdesProvider.CreateEncryptor(this.key3DES, this.iv);
                        using (MemoryStream encryptedStream = new MemoryStream())
                        {
                            CryptoStream cryptStream = new CryptoStream(encryptedStream, cryptoTransform, CryptoStreamMode.Write);

                            // Write the encrypted information to the stream. Flush the information
                            // when done to ensure everything is out of the buffer.
                            cryptStream.Write(inputInBytes, 0, inputInBytes.Length);
                            cryptStream.FlushFinalBlock();
                            encryptedStream.Position = 0;

                            // Read the stream back into a Byte array and return it to the calling
                            // method.
                            byte[] result = new byte[encryptedStream.Length];
                            encryptedStream.Read(result, 0, (int)encryptedStream.Length);
                            cryptStream.Close();
                            return result;
                        }
                    }
            }

            return new byte[0];


        }

        /// <summary>
        /// Decrypts the specified input information bytes.
        /// </summary>
        /// <param name="inputInBytes">The input information bytes.</param>
        /// <param name="decType">Type of the decimal.</param>
        /// <returns>System.String.</returns>
        public string Decrypt(byte[] inputInBytes, string decType)
        {
            // UTFEncoding is used to transform the decrypted Byte Array
            // information back into a string.
            UTF8Encoding utf8encoder = new UTF8Encoding();

            //object tdesProvider = null;
            //object cryptoTransform = null;
            switch (decType)
            {
                case "DES":
                    using (DESCryptoServiceProvider tdesProvider = new DESCryptoServiceProvider())
                    {

                        // As before we must provide the encryption/decryption key along with
                        // the init vector.
                        ICryptoTransform cryptoTransform = tdesProvider.CreateDecryptor(this.key, this.iv);
                        MemoryStream decryptedStream = new MemoryStream();
                        CryptoStream cryptStream = new CryptoStream(decryptedStream, cryptoTransform, CryptoStreamMode.Write);
                        cryptStream.Write(inputInBytes, 0, inputInBytes.Length);
                        //cryptStream.Flush()
                        cryptStream.FlushFinalBlock();
                        decryptedStream.Position = 0;

                        // Read the memory stream and convert it back into a string
                        byte[] result = new byte[decryptedStream.Length];
                        decryptedStream.Read(result, 0, (int)decryptedStream.Length);
                        cryptStream.Close();
                        UTF8Encoding myutf = new UTF8Encoding();
                        return myutf.GetString(result);
                    }
                case "3DES":
                    using (TripleDESCryptoServiceProvider tdesProvider = new TripleDESCryptoServiceProvider())
                    {

                        // As before we must provide the encryption/decryption key along with
                        // the init vector.
                        ICryptoTransform cryptoTransform = tdesProvider.CreateDecryptor(this.key3DES, this.iv);
                        MemoryStream decryptedStream = new MemoryStream();
                        CryptoStream cryptStream = new CryptoStream(decryptedStream, cryptoTransform, CryptoStreamMode.Write);
                        cryptStream.Write(inputInBytes, 0, inputInBytes.Length);
                        //cryptStream.Flush()
                        cryptStream.FlushFinalBlock();
                        decryptedStream.Position = 0;

                        // Read the memory stream and convert it back into a string
                        byte[] result = new byte[decryptedStream.Length];
                        decryptedStream.Read(result, 0, (int)decryptedStream.Length);
                        cryptStream.Close();
                        UTF8Encoding myutf = new UTF8Encoding();
                        return myutf.GetString(result);
                    }
            }

            return "";


            // Provide a memory stream to decrypt information into

        }

        /// <summary>
        /// Encrypts the RSA.
        /// </summary>
        /// <param name="plainText">The plain text.</param>
        /// <param name="key">The key.</param>
        /// <returns>ArrayList.</returns>
        public ArrayList EncryptRSA(string plainText, string key)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            RSACryptoServiceProvider.UseMachineKeyStore = true;
            byte[] EncryptedStrAsByt = null;
            ArrayList encrAl = new ArrayList();
            int maxLimit = 58;

            //get the public key so you can encrypt the message:
            rsa.FromXmlString(key);
            // MessageBox.Show("On Encryption: " & publicKey)

            if ((plainText.Length > maxLimit))
            {
                //Split the text into blocks of 58 characters
                string splitText = null;
                for (int counter = 0; counter <= plainText.Length; counter++)
                {
                    if ((plainText.Length - counter < maxLimit))
                    {
                        splitText = plainText.Substring(counter, plainText.Length - counter);
                    }
                    else
                    {
                        splitText = plainText.Substring(counter, maxLimit);
                    }
                    EncryptedStrAsByt = rsa.Encrypt(System.Text.Encoding.Unicode.GetBytes(splitText), false);
                    encrAl.Add(EncryptedStrAsByt);
                    counter = counter + (maxLimit - 1);
                }

            }
            else
            {
                EncryptedStrAsByt = rsa.Encrypt(System.Text.Encoding.Unicode.GetBytes(plainText), false);
                encrAl.Add(EncryptedStrAsByt);
            }

            return encrAl;
        }

        /// <summary>
        /// Decrypts the RSA.
        /// </summary>
        /// <param name="inputBytes">The input bytes.</param>
        /// <param name="key">The key.</param>
        /// <returns>System.Byte[][].</returns>
        public byte[] DecryptRSA(byte[] inputBytes, string key)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            RSACryptoServiceProvider.UseMachineKeyStore = true;

            //get the keys, thereby creating an RSA object that's identical
            // to the one used in the Form_Load event when the keys were first built
            rsa.FromXmlString(key);
            //MessageBox.Show("On Decryption: " & xmlKeys)
            byte[] DecryptedStrAsByte = rsa.Decrypt(inputBytes, false);
            publicKey = string.Empty;
            privateKey = string.Empty;
            return DecryptedStrAsByte;
            //Dim DecryptedStrAsString = System.Text.Encoding.Unicode.GetString(DecryptedStrAsByt)
        }


        /// <summary>
        /// Encrypts the specified plain text.
        /// </summary>
        /// <param name="plainText">The plain text.</param>
        /// <param name="passPhrase">The pass phrase.</param>
        /// <param name="saltValue">The salt value.</param>
        /// <param name="hashAlgorithm">The hash algorithm.</param>
        /// <param name="passwordIterations">The password iterations.</param>
        /// <param name="initVector">The initialize vector.</param>
        /// <param name="keySize">Size of the key.</param>
        /// <returns>System.String.</returns>
        public static string Encrypt(string plainText, string passPhrase, string saltValue, string hashAlgorithm, int passwordIterations, string initVector, int keySize)
        {
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);

            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);

            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations);

            byte[] keyBytes = password.GetBytes(keySize / 8);
            //Dim keyBytes As Byte() = {23, 39, 79, 67, 81, 92, 53, 62, 23, 53, 31, 125, 128, 43, 11, 23, 48, 97, 56, 11, 5, 1, 65, 132}

            // Create uninitialized Rijndael encryption object.
            RijndaelManaged symmetricKey = new RijndaelManaged();

            // It is reasonable to set encryption mode to Cipher Block Chaining
            // (CBC). Use default options for other symmetric key parameters.
            symmetricKey.Mode = CipherMode.CBC;
            symmetricKey.Padding = PaddingMode.PKCS7;

            // Generate encryptor from the existing key bytes and initialization 
            // vector. Key size will be defined based on the number of the key 
            // bytes.
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);

            // Define memory stream which will be used to hold encrypted data.
            MemoryStream memoryStream = new MemoryStream();

            // Define cryptographic stream (always use Write mode for encryption).
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            // Start encrypting.
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);

            // Finish encrypting.
            cryptoStream.FlushFinalBlock();

            // Convert our encrypted data from a memory stream into a byte array.
            byte[] cipherTextBytes = memoryStream.ToArray();

            // Close both streams.
            memoryStream.Close();
            cryptoStream.Close();

            // Convert encrypted data into a base64-encoded string.
            string cipherText = Convert.ToBase64String(cipherTextBytes);

            // Return encrypted string.
            return cipherText;
        }



        /// <summary>
        /// Decrypts the specified cipher text.
        /// </summary>
        /// <param name="cipherText">The cipher text.</param>
        /// <param name="passPhrase">The pass phrase.</param>
        /// <param name="saltValue">The salt value.</param>
        /// <param name="hashAlgorithm">The hash algorithm.</param>
        /// <param name="passwordIterations">The password iterations.</param>
        /// <param name="initVector">The initialize vector.</param>
        /// <param name="keySize">Size of the key.</param>
        /// <returns>System.String.</returns>
        public static string Decrypt(string cipherText, string passPhrase, string saltValue, string hashAlgorithm, int passwordIterations, string initVector, int keySize)
        {

            // Convert strings defining encryption key characteristics into byte
            // arrays. Let us assume that strings only contain ASCII codes.
            // If strings include Unicode characters, use Unicode, UTF7, or UTF8
            // encoding.
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);

            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);

            // Convert our ciphertext into a byte array.
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);

            // First, we must create a password, from which the key will be 
            // derived. This password will be generated from the specified 
            // passphrase and salt value. The password will be created using
            // the specified hash algorithm. Password creation can be done in
            // several iterations.
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations);

            // Use the password to generate pseudo-random bytes for the encryption
            // key. Specify the size of the key in bytes (instead of bits).
            byte[] keyBytes = password.GetBytes(keySize / 8);
            //Dim keyBytes As Byte() = {23, 39, 79, 67, 81, 92, 53, 62, 23, 53, 31, 125, 128, 43, 11, 23, 48, 97, 56, 11, 5, 1, 65, 132}

            // Create uninitialized Rijndael encryption object.
            RijndaelManaged symmetricKey = new RijndaelManaged();

            // It is reasonable to set encryption mode to Cipher Block Chaining
            // (CBC). Use default options for other symmetric key parameters.
            symmetricKey.Mode = CipherMode.CBC;
            symmetricKey.Padding = PaddingMode.PKCS7;

            // Generate decryptor from the existing key bytes and initialization 
            // vector. Key size will be defined based on the number of the key 
            // bytes.
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);

            // Define memory stream which will be used to hold encrypted data.
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);

            // Define memory stream which will be used to hold encrypted data.
            CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);

            // Since at this point we don't know what the size of decrypted data
            // will be, allocate the buffer long enough to hold ciphertext;
            // plaintext is never longer than ciphertext.
            byte[] plainTextBytes = null;
            plainTextBytes = new byte[cipherTextBytes.Length + 1];

            // Start decrypting.
            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);

            // Close both streams.
            memoryStream.Close();
            cryptoStream.Close();

            // Convert decrypted data into a string. 
            // Let us assume that the original plaintext string was UTF8-encoded.
            string plainText = Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);

            // Return decrypted string.
            return plainText;
        }

        //Public Function GetKeysForRSA(ByRef pubKey As String, ByRef priKey As String)
        //    pubKey = ""
        //    priKey = ""
        //    Try
        //        Dim rsa As New RSACryptoServiceProvider
        //        RSACryptoServiceProvider.UseMachineKeyStore = True
        //        pubKey = rsa.ToXmlString(False)
        //        priKey = rsa.ToXmlString(True)
        //        rsa = Nothing

        //    Catch ex As Exception
        //        Throw ex
        //    End Try


        //End Function

    }
}
