﻿using System.Runtime.Serialization;

namespace HS
{
    [DataContract]
    public class GeoLocationSearchRequest : HSRequest<GeoLocationSearchCriteria>
    {
    }
}
