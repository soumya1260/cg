﻿using System.Runtime.Serialization;

namespace HS
{
    [DataContract]
    public class SendEmailResponse : HSResponse
    {
    }
}
