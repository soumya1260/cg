﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : todd.merritt
// Created          : 11-13-2014
//
// Last Modified By : todd.merritt
// Last Modified On : 11-13-2014
// ***********************************************************************
// <copyright file="IGeoLocationInterface.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.ServiceModel;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Interface ILogInterface
    /// </summary>
    [ServiceContract]
   public interface IGeoLocationInterface
    {
        /// <summary>
        ///This allows the client to find a geographical location based on a Address, Zip, City/State, Lat/Long, or Place Name
        /// </summary>
        /// <param name="request">GeoLocationSearchRequest</param>
        /// <returns>GeoLocationSearchResponse.</returns>
        [OperationContract]
        GeoLocationSearchResponse GeoLocationSearch(GeoLocationSearchRequest request);

    }
}
