﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace HS
{
    [DataContract]
    public class EMailItem : HSEmailService.Email
    {
        [DataMember]
        public List<Attachment> Attachments { get; set; }
        [DataMember]
        public string Body { get; set; }
        [DataMember]
        public string CC { get; set; }
        [DataMember]
        public ExtensionDataObject ExtensionData { get; set; }
        [DataMember]
        public string From { get; set; }
        [DataMember]
        public bool isHTML { get; set; }
        [DataMember]
        public string Subject { get; set; }
        [DataMember]
        public string To { get; set; }

    }

    public class Attachment : IExtensibleDataObject
    {
        public Attachment()
        {

        }

        [DataMember]
        public byte[] Bytes { get; set; }
        [DataMember]
        public string ContentType { get; set; }
        [DataMember]
        public ExtensionDataObject ExtensionData { get; set; }
        [DataMember]
        public string Filename { get; set; }

        
    }

}
