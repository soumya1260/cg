﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-03-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="ILogInterface.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.ServiceModel;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
/// <summary>
/// Interface ILogInterface
/// </summary>
    [ServiceContract]
    public interface ILogInterface
    {
        /// <summary>
        /// Writes the message automatic log.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns>WriteMessageToLogResponse.</returns>
        [OperationContract]
        WriteMessageToLogResponse WriteMessageToLog(WriteToLogRequest request);


        /// <summary>
        /// This allows the client to send email messages using the HSMAil Service
        /// </summary>
        /// <param name="SendEmailRequest">The send email request.</param>
        /// <returns>SendEmailResponse.</returns>
        [OperationContract]
        SendEmailResponse SendEmail(SendEmailRequest request);
    }
}
