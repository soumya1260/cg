﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-03-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="WriteToLogRequest.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Class WriteToLogRequest.
    /// </summary>
    [DataContract]
    public class WriteToLogRequest : HSRequest
    {
        /// <summary>
        /// Gets or sets the log message.
        /// </summary>
        /// <value>The log message.</value>
        [DataMember]
        public LogObject LogMessage { get; set; }


    }

    /// <summary>
    /// Enum MessageTypeEnum
    /// </summary>
    [DataContract]
    public enum MessageTypeEnum
    {
        /// <summary>
        /// The informational
        /// </summary>
        [EnumMember]
        Informational = 1,
        /// <summary>
        /// debug
        /// </summary>
        [EnumMember]
        Debug=2,
        /// <summary>
        /// exception
        /// </summary>
        [EnumMember]
        Exception = 3,
        /// <summary>
        /// verbose
        /// </summary>
        [EnumMember]
        Verbose = 4,
        /// <summary>
        /// Security Messages
        /// </summary>
        [EnumMember]
        SecurityMessage = 5
    }

    
}
