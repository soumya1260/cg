﻿using System.Runtime.Serialization;
using HS.HSEmailService;

namespace HS
{
    [DataContract] public class SendEmailRequest:HSRequest<Email>
    {
    }
}
