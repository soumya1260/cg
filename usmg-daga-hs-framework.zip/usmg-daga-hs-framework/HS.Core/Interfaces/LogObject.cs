﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-05-2013
// ***********************************************************************
// <copyright file="LogObject.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Class LogObject.
    /// </summary>
    [DataContract]
    public class LogObject
    {
        /// <summary>
        /// Gets or sets the original message unique identifier.
        /// </summary>
        /// <value>The original message unique identifier.</value>
        [DataMember]
        public int OriginalMessageID { get; set; }

        /// <summary>
        /// The title of the exception message to log
        /// </summary>
        [DataMember]
        public string MessageTitle { get; set; }

        /// <summary>
        /// Gets or sets the sending application.
        /// </summary>
        /// <value>The sending application.</value>
        [DataMember]
        public string SendingApplication { get; set; }

        /// <summary>
        /// Gets or sets the type of the message.
        /// </summary>
        /// <value>The type of the message.</value>
        [DataMember]
        public MessageTypeEnum MessageType { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        [DataMember]
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the exception message.
        /// </summary>
        /// <value>The exception message.</value>
        [DataMember]
        public string ExceptionMessage { get; set; }

        /// <summary>
        /// Gets or sets the exception Type.
        /// </summary>
        /// <value>The exception Type.</value>
        [DataMember]
        public string ExceptionType { get; set; }

        /// <summary>
        /// Gets or sets the exception source.
        /// </summary>
        /// <value>The exception source.</value>
        [DataMember]
        public string ExceptionSource { get; set; }

        /// <summary>
        /// Gets or sets the exception stack trace.
        /// </summary>
        /// <value>The exception stack trace.</value>
        [DataMember]
        public string ExceptionStackTrace { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is inner exception.
        /// </summary>
        /// <value><c>true</c> if this instance is inner exception; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool IsInnerException { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [contains exception].
        /// </summary>
        /// <value><c>true</c> if [contains exception]; otherwise, <c>false</c>.</value>
        [DataMember]
        public bool ContainsException { get; set; }

        /// <summary>
        /// Gets or sets the message sent from.
        /// </summary>
        /// <value>The message sent from.</value>
        [DataMember]
        public string MessageSentFrom { get; set; }

        [DataMember]
        public string PromotionEnvironment { get; set; }

        /// <summary>
        /// A list of strings that allows the application to send additional information or meaages to be 
        /// logged with the exception
        /// </summary>
        /// <value>A generic List of Strings</value>
        [DataMember]
        public List<string> AdditionalMessages { get; set; }

        public LogObject()
        {
            AdditionalMessages = new List<string>();
            SendingApplication = "";
            Message = "";
            ExceptionType = "";
            MessageTitle = "";
            ExceptionMessage = "";
            ExceptionSource = "";
            ExceptionStackTrace = "";
            MessageSentFrom = "";
            PromotionEnvironment = "";



        }

    }
}
