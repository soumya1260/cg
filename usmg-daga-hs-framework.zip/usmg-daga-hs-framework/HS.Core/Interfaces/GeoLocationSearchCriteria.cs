﻿using System.Runtime.Serialization;

namespace HS
{
    [DataContract]
    public class GeoLocationSearchCriteria
    {
        [DataMember]
        public string SearchTerm { get; set; }
    }
}
