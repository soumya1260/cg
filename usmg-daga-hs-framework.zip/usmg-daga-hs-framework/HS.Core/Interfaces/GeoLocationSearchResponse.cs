﻿using System.Runtime.Serialization;

namespace HS
{
    [DataContract]
    public class GeoLocationSearchResponse : HSListResponse<GeoLocationItem>
    {
  
    }

}