﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 09-04-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-04-2013
// ***********************************************************************
// <copyright file="WriteMessageToLogResponse.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Runtime.Serialization;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Class WriteMessageToLogResponse.
    /// </summary>
    [DataContract]
    public class WriteMessageToLogResponse : HSResponse
    {
        /// <summary>
        /// Gets or sets the original exception unique identifier.
        /// </summary>
        /// <value>The original exception unique identifier.</value>
        [DataMember]
        public int OriginalExceptionID { get; set; }
    }
}
