﻿// ***********************************************************************
// Assembly         : HS.Core
// Author           : stephen.dornan
// Created          : 08-27-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 04-23-2013
// ***********************************************************************
// <copyright file="DescriptionAttribute.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;

/// <summary>
/// The HS namespace.
/// </summary>
namespace HS
{
    /// <summary>
    /// Used to describe enum values
    /// </summary>
    public class DescriptionAttribute : Attribute
    {
        /// <summary>
        /// The description text
        /// </summary>
        public string Text;

        /// <summary>
        /// The default constructor
        /// </summary>
        public DescriptionAttribute() { }

        /// <summary>
        /// The description constructor to populate the text field
        /// </summary>
        /// <param name="text">Description to apply to the text field</param>
        public DescriptionAttribute(string text)
        {
            Text = text;
        }
    }

}
