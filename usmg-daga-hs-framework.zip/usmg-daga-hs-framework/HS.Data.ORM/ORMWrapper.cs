﻿// ***********************************************************************
// Assembly         : HS.Data.ORM
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="DALORMWrapper.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OracleClient;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using System.Diagnostics;

/// <summary>
/// The ORM namespace.
/// </summary>
namespace HS.Data.ORM
{
    public class ParamItem
    {
        public string FriendlyName { get; set; }
        public object Value { get; set; }
        public ParamItem()
        {

        }
        public ParamItem(string friendlyName, object value)
        {
            FriendlyName = friendlyName;
            Value = value;
        }
        public override string ToString()
        {
            return string.Format("{0} [{1}]", FriendlyName, Value.ToString());
        }
    }



    /// <summary>
    /// This class is a wrapper class for ADO.Net that supports connection to
    /// OLEDB, SQLServer, ODBC, and Oracle using the .Net OPracle Client and exposes
    /// data to the consumere through a public interface of ORM methods.
    /// </summary>
    public class ORMWrapper : IDisposable, iORM
    {
        #region Private member variables used for the multiple database connections

        /// <summary>
        /// The connection name
        /// </summary>
        private string connectionName;
        /// <summary>
        /// The provider name
        /// </summary>
        private string providerName;
        /// <summary>
        /// The connection string
        /// </summary>
        private string connectionString;
        /// <summary>
        /// The section found
        /// </summary>
        private bool sectionFound = false;
        /// <summary>
        /// The use master transaction scope
        /// </summary>
        private bool useMasterTransactionScope = false;
        /// <summary>
        /// The trans
        /// </summary>
        private IDbTransaction trans = null;

        /// <summary>
        /// Struct DataConnections
        /// </summary>
        private struct DataConnections
        {
            /// <summary>
            /// The OLE command b1
            /// </summary>
            public System.Data.OleDb.OleDbConnection oleDB1;
            /// <summary>
            /// The OLE dr
            /// </summary>
            public System.Data.OleDb.OleDbDataReader oleDR;
            /// <summary>
            /// The OLE command
            /// </summary>
            public System.Data.OleDb.OleDbCommand oleCMD;

            /// <summary>
            /// The OLE ds
            /// </summary>
            public DataSet oleDS;

            /// <summary>
            /// The SQL command b1
            /// </summary>
            public System.Data.SqlClient.SqlConnection sqlDB1;
            /// <summary>
            /// The SQL dr
            /// </summary>
            public System.Data.SqlClient.SqlDataReader sqlDR;
            /// <summary>
            /// The SQL command
            /// </summary>
            public System.Data.SqlClient.SqlCommand sqlCMD;

            /// <summary>
            /// The SQL ds
            /// </summary>
            public DataSet sqlDS;

            /// <summary>
            /// The ODBC command b1
            /// </summary>
            public System.Data.Odbc.OdbcConnection odbcDB1;
            /// <summary>
            /// The ODBC dr
            /// </summary>
            public System.Data.Odbc.OdbcDataReader odbcDR;
            /// <summary>
            /// The ODBC command
            /// </summary>
            public System.Data.Odbc.OdbcCommand odbcCMD;

            /// <summary>
            /// The ODBC ds
            /// </summary>
            public DataSet odbcDS;

            /// <summary>
            /// The ora command b1
            /// </summary>
            public OracleConnection oraDB1;
            /// <summary>
            /// The ora command
            /// </summary>
            public OracleCommand oraCMD;
            /// <summary>
            /// The ora dr
            /// </summary>
            public OracleDataReader oraDR;
            /// <summary>
            /// The ora ds
            /// </summary>
            public DataSet oraDS;

        }

        /// <summary>
        /// Enum DataConnectType
        /// </summary>
        public enum DataConnectType
        {
            /// <summary>
            /// The oledb
            /// </summary>
            OLEDB = 0,
            /// <summary>
            /// The SQLDB
            /// </summary>
            SQLDB = 1,
            /// <summary>
            /// The ODBC
            /// </summary>
            ODBC = 2,
            /// <summary>
            /// The oracle
            /// </summary>
            ORACLE = 3,

        }

        /// <summary>
        /// My configuration string
        /// </summary>
        private string myConString;

        /// <summary>
        /// My type
        /// </summary>
        private DataConnectType myType;
        /// <summary>
        /// My constant
        /// </summary>
        private DataConnections myCons;

        #endregion

        #region "Public Interface"


        /// <summary>
        /// Public constructor takes the connection string name as an argument. Requires the use of the connectionStrings block
        /// in the App.config and the providername MUST be specified in the connectionStrings block
        /// </summary>
        /// <param name="ConnectionStringName">the name of the connection string to be used fromt he app.config file</param>
        /// <param name="StartTransactionScope">if set to <c>true</c> [start transaction scope].</param>
        /// <exception cref="System.Exception">The requested connection string could not be found in the application config.</exception>
        public ORMWrapper(string ConnectionStringName, bool StartTransactionScope)
        {
            useMasterTransactionScope = StartTransactionScope;
            ConnectionStringsSection cfg = (ConnectionStringsSection)ConfigurationManager.GetSection("connectionStrings");

            for (int i = 0; i < cfg.ConnectionStrings.Count; i++)
            {
                var css = cfg.ConnectionStrings[i];
                if (css.Name.ToUpper() == ConnectionStringName.ToUpper())
                {
                    connectionName = css.Name;
                    providerName = css.ProviderName;
                    connectionString = css.ConnectionString;
                    sectionFound = true;
                    break;
                }
            }
            if (sectionFound != true)
                throw new Exception("The requested connection string could not be found in the application config.");


            switch (providerName)
            {
                case "System.Data.SqlClient":
                    myType = DataConnectType.SQLDB;
                    break;
                case "System.Data.OracleClient":
                    myType = DataConnectType.ORACLE;
                    break;
                case "System.Data.Odbc":
                    myType = DataConnectType.ODBC;
                    break;
                case "System.Data.OleDb":
                    myType = DataConnectType.OLEDB;
                    break;
                default:
                    //Always default the provider to SQL if one is not provided in the config section
                    myType = DataConnectType.SQLDB;
                    break;
            }

            try
            {

                switch (myType)
                {
                    case DataConnectType.ODBC:
                        myCons.odbcDB1 = new OdbcConnection(connectionString);
                        myCons.odbcDB1.Open();
                        myCons.odbcCMD.Transaction = (OdbcTransaction)trans;
                        myCons.odbcCMD.Connection = myCons.odbcDB1;
                        if (useMasterTransactionScope)
                        {
                            trans = myCons.odbcDB1.BeginTransaction();

                            myCons.odbcCMD.Transaction = (OdbcTransaction)trans;
                        }
                        myCons.odbcCMD = new OdbcCommand();
                        break;
                    case DataConnectType.OLEDB:
                        myCons.oleDB1 = new OleDbConnection(connectionString);
                        myCons.oleDB1.Open();
                        myCons.oleCMD.Transaction = (OleDbTransaction)trans;
                        myCons.oleCMD.Connection = myCons.oleDB1;
                        if (useMasterTransactionScope)
                        {
                            trans = myCons.oleDB1.BeginTransaction();

                            myCons.oleCMD.Transaction = (OleDbTransaction)trans;
                        }
                        myCons.oleCMD = new OleDbCommand();
                        break;
                    case DataConnectType.ORACLE:
                        myCons.oraDB1 = new OracleConnection(connectionString);
                        myCons.oraDB1.Open();
                        myCons.oraCMD.Transaction = (OracleTransaction)trans;
                        myCons.oraCMD.Connection = myCons.oraDB1;
                        if (useMasterTransactionScope)
                        {
                            trans = myCons.oraDB1.BeginTransaction();

                            myCons.oraCMD.Transaction = (OracleTransaction)trans;
                        }
                        myCons.oraCMD = new OracleCommand();
                        break;
                    case DataConnectType.SQLDB:
                        myCons.sqlDB1 = new SqlConnection(connectionString);
                        myCons.sqlDB1.Open();
                        myCons.sqlCMD = new SqlCommand();
                        myCons.sqlCMD.Connection = myCons.sqlDB1;
                        if (useMasterTransactionScope)
                        {
                            trans = myCons.sqlDB1.BeginTransaction();

                            myCons.sqlCMD.Transaction = (SqlTransaction)trans;
                        }

                        break;
                }

            }
            catch (Exception ex)
            {

                throw ex;

            }

        }

        private void OpenConnection()
        {
            switch (myType)
            {
                case DataConnectType.ODBC:

                    myCons.odbcDB1.Open();

                    break;
                case DataConnectType.OLEDB:

                    myCons.oleDB1.Open();

                    break;
                case DataConnectType.ORACLE:

                    myCons.oraDB1.Open();

                    break;
                case DataConnectType.SQLDB:

                    myCons.sqlDB1.Open();

                    break;
            }
        }

        public string ViewConnectionString()
        {
            switch (myType)
            {
                case DataConnectType.ODBC:

                    return myCons.odbcDB1.ConnectionString;
                    break;
                case DataConnectType.OLEDB:
                    return myCons.oleDB1.ConnectionString;

                    break;
                case DataConnectType.ORACLE:
                    return myCons.oraDB1.ConnectionString;
                    break;
                case DataConnectType.SQLDB:
                    return myCons.sqlDB1.ConnectionString;
                    break;
                default:
                    return "";
                    break;
            }
        }
        private void SetCommandAndParams<T>(List<ParamItem> Params, string FriendlyProcName) where T : new()
        {
            List<StoredProcedureParameter> spp = new List<StoredProcedureParameter>();
            //            OpenConnection();
            var instance = ORMapper<T>.Instance;

            foreach (StoredProcedure sp in ORMapper<T>.Instance.StoredProcMap)
            {

                if (FriendlyProcName.ToUpper() == sp.Friendly.ToUpper())
                {

                    this.setCommandText = sp.Actual;

                    spp = sp.Parameters;
                    break;

                }

            }

            try
            {
                //Found the proc and params, now to map the params correctly
                foreach (ParamItem pi in Params)
                {
                    /*There MUST be a null check here, or there will be a null reference exception
                     * for any parameters not initialized in code, but which may be allowed to be null
                     * on the SQL side. */
                    if (pi != null)
                    {
                        //for each friendly param, find the matching param in the collection
                        foreach (StoredProcedureParameter parm in spp)
                        {

                            if (pi.FriendlyName.ToUpper() == parm.Friendly.ToUpper())
                            {
                                addParameter(parm.Actual, pi.Value, parm.Direction);
                                break;
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            this.setCommandType(CommandType.StoredProcedure);

        }

        /// <summary>
        /// This will write data to the database using the specific proc.
        /// </summary>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool InsertToDatabase<T>(List<ParamItem> Params, string FriendlyProcName) where T : new()
        {

            try
            {

                SetCommandAndParams<T>(Params, FriendlyProcName);

                var cmd = GetCommand();
                cmd.ExecuteNonQuery();

                return true;

            }
            catch (Exception ex)
            {
                TransactionRollBack();
                throw ex;
            }

        }

        /// <summary>
        /// Write data to the database using the specific proc.
        /// </summary>
        /// <param name="Params">List of parameters to pass to the stored procedure.</param>
        /// <param name="ProcName">The name of the stored procedure to run.</param>
        /// <returns>Number of updated rows.</returns>
        public int UpdateDatabase<T>(List<ParamItem> Params, string FriendlyProcName) where T : new()
        {

            try
            {

                SetCommandAndParams<T>(Params, FriendlyProcName);

                var cmd = GetCommand();
                int updatedRows = cmd.ExecuteNonQuery();

                return updatedRows;

            }
            catch (Exception ex)
            {

                TransactionRollBack();
                throw ex;

            }

        }

        /// <summary>
        /// Removes data from the database using the specific proc.
        /// </summary>
        /// <param name="Params">List of parameters to pass to the stored procedure.</param>
        /// <param name="ProcName">The name of the stored procedure to run.</param>
        /// <returns>Number of deleted rows.</returns>
        public int DeleteFromDatabase<T>(List<ParamItem> Params, string FriendlyProcName) where T : new()
        {

            return UpdateDatabase<T>(Params, FriendlyProcName);

        }

        /// <summary>
        /// This will create a data reader, based on the Stored Proc name specified, and map the results into
        /// a single object. If multiple results are erturned from the DB, only the first object will be returned
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>a single object of type T as specified</returns>
        public T MapObjectFromDataReader<T>(List<ParamItem> Params, string FriendlyProcName) where T : new()
        {

            try
            {

                SetCommandAndParams<T>(Params, FriendlyProcName);

                var cmd = GetCommand();
                var dr = executeReader();
                var x = new T();

                if (hasRows == true)
                {
                    dr.Read();
                    x = ORMapper<T>.Instance.Map(dr);
                    dr.Close();
                }

                return x;

            }
            catch (Exception ex)
            {
                TransactionRollBack();
                throw ex;
            }

            //return new T();

        }

        /// <summary>
        /// This will create a data reader, based on the Stored Proc name specified, and map the results into
        /// an IEnumerable List of objects.
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>an IEnumerable List of objects of type T as specified</returns>
        public List<T> MapListFromDataReader<T>(List<ParamItem> Params, string FriendlyProcName) where T : new()
        {


            //TODO: Re add try catch if this doesn work
            //It should though. a transaction rollback should not be required on a read
            SetCommandAndParams<T>(Params, FriendlyProcName);

            var cmd = GetCommand();
            var dr = executeReader();
            var x = new List<T>();

            if (hasRows == true)
            {
                x = ORMapper<T>.Instance.MapAll(dr);
            }

            dr.Close();

            return x;



            //return new List<T>();
        }

        /// <summary>
        /// This will create a DataSet, based on the Stored Proc name specified, and map the results into
        /// a single object. If mutiples are returned, only the first objecvt will be returned
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>a single object of type T as specified</returns>
        public T MapObjectFromDataSet<T>(List<ParamItem> Params, string FriendlyProcName) where T : new()
        {

            try
            {

                SetCommandAndParams<T>(Params, FriendlyProcName);

                var cmd = GetCommand();
                var DS = getDataSet();
                var x = Mapper.Map<T>(DS);
                //cmd.Connection.Close();

                return x;

            }
            catch (Exception ex)
            {
                TransactionRollBack();
                throw ex;
            }

            //return new T();
        }

        /// <summary>
        /// This will create a DataSet, based on the Stored Proc name specified, and map the results into
        /// a single object. If mutiples are returned, only the first objecvt will be returned
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>an IEnumerable List of objects of type T as specified</returns>
        public List<T> MapListFromDataSet<T>(List<ParamItem> Params, string FriendlyProcName) where T : new()
        {

            try
            {

                SetCommandAndParams<T>(Params, FriendlyProcName);

                var cmd = GetCommand();
                var DS = getDataSet();
                var x = Mapper.MapAll<T>(DS);
                //cmd.Connection.Close();

                return x;

            }
            catch (Exception ex)
            {
                TransactionRollBack();
                throw ex;
            }

            //return new List<T>();

        }

        /// <summary>
        /// This will create a DataSet, based on the Stored Proc name specified, and map the results into
        /// a single object. If mutiples are returned, only the first objecvt will be returned
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>a single object of type T as specified</returns>
        public T MapObjectFromDataTable<T>(List<ParamItem> Params, string FriendlyProcName) where T : new()
        {

            try
            {

                SetCommandAndParams<T>(Params, FriendlyProcName);

                var cmd = GetCommand();
                var DT = getDataTable();
                var x = Mapper.Map<T>(DT);
                //cmd.Connection.Close();

                return x;

            }
            catch (Exception ex)
            {
                TransactionRollBack();
                throw ex;
            }

            //return new T();

        }

        /// <summary>
        /// This will create a DataTable, based on the Stored Proc name specified, and map the results into
        /// a single object. If mutiples are returned, only the first objecvt will be returned
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>an IEnumerable List of objects of type T as specified</returns>
        public List<T> MapListFromDataTable<T>(List<ParamItem> Params, string FriendlyProcName) where T : new()
        {

            try
            {

                SetCommandAndParams<T>(Params, FriendlyProcName);

                var cmd = GetCommand();
                var DT = getDataTable();
                var x = Mapper.MapAll<T>(DT);
                //cmd.Connection.Close();

                return x;

            }
            catch (Exception ex)
            {
                TransactionRollBack();
                throw ex;
            }

            //return new List<T>();

        }

        /// <summary>
        /// DEPRICATED - DO NOTE USE
        /// This will create a data reader based on the InlineSQL passed in and map the retults into the object
        /// type specified. If multiple results are returned, only the first object will be returned
        /// </summary>
        /// <typeparam name="T">The type of object to be returned</typeparam>
        /// <param name="SqlToRun">The inline SQL to be run</param>
        /// <returns>a single object of type T as specified</returns>
        public T MapObjectFromInlineSQL<T>(string SqlToRun) where T : new()
        {

            try
            {

                this.setCommandText = SqlToRun;

                var cmd = GetCommand();
                var dr = cmd.ExecuteReader();
                var x = Mapper.Map<T>(dr);
                //cmd.Connection.Close();

                return x;

            }
            catch (Exception ex)
            {
                TransactionRollBack();
                throw ex;
            }

            //return new T();
        }

        /// <summary>
        /// DEPRICATED - DO NOTE USE
        /// This will create a data reader based on the InlineSQL passed in and map the retults into an
        /// iEnumerable list of objecst of the type specified
        /// </summary>
        /// <typeparam name="T">The type of object to be returned</typeparam>
        /// <param name="SqlToRun">The inline SQL to be run</param>
        /// <returns>an IEnumerable List of objects of type T as specified</returns>
        public List<T> MapListFromInlineSQL<T>(string SqlToRun) where T : new()
        {

            try
            {

                this.setCommandText = SqlToRun;

                var cmd = GetCommand();
                var dr = cmd.ExecuteReader();
                var x = Mapper.MapAll<T>(dr);
                //cmd.Connection.Close();

                return x;

            }
            catch (Exception ex)
            {
                TransactionRollBack();
                throw ex;
            }

            //return new List<T>();
        }

        /// <summary>
        /// If a transaction scope was started, this commits the current transaction to the DB
        /// </summary>
        public void TransactionCommit()
        {

            if (useMasterTransactionScope != true)
            {
                return;
            }

            switch (myType)
            {

                case DataConnectType.SQLDB:
                    if (myCons.sqlCMD.Transaction != null)
                    {
                        myCons.sqlCMD.Transaction.Commit();
                    }
                    break;
                case DataConnectType.ORACLE:
                    if (myCons.oraCMD.Transaction != null)
                    {
                        myCons.oraCMD.Transaction.Commit();
                    }
                    break;
                case DataConnectType.OLEDB:
                    if (myCons.oleCMD.Transaction != null)
                    {
                        myCons.oleCMD.Transaction.Commit();
                    }
                    break;
                case DataConnectType.ODBC:
                    if (myCons.odbcCMD.Transaction != null)
                    {
                        myCons.odbcCMD.Transaction.Commit();
                    }
                    break;

            }

        }

        /// <summary>
        /// If a transaction scope was started, thsi rolls back the current transaction
        /// </summary>
        public void TransactionRollBack()
        {

            if (useMasterTransactionScope != true)
            {
                return;
            }

            switch (myType)
            {

                case DataConnectType.SQLDB:
                    myCons.sqlCMD.Transaction.Rollback();
                    break;
                case DataConnectType.ORACLE:
                    myCons.oraCMD.Transaction.Rollback();
                    break;
                case DataConnectType.OLEDB:
                    myCons.oleCMD.Transaction.Rollback();
                    break;
                case DataConnectType.ODBC:
                    myCons.odbcCMD.Transaction.Rollback();
                    break;

            }

        }

        /// <summary>
        /// Finalizes this instance.
        /// </summary>
        public void Finalize()
        {
            Dispose();
        }

        /// <summary>
        /// Explicitly closes and destroys all open connections to the database to allow resources to be freed
        /// </summary>
        public void Dispose()
        {
            try
            {
                TransactionCommit();
                switch (myType)
                {
                    case DataConnectType.SQLDB:

                        myCons.sqlDB1.Close();
                        myCons.sqlDB1.Dispose();
                        break;
                    case DataConnectType.ORACLE:
                        myCons.oraDB1.Close();
                        myCons.oraDB1.Dispose();
                        break;
                    case DataConnectType.OLEDB:
                        myCons.oleDB1.Close();
                        myCons.oleDB1.Dispose();
                        break;
                    case DataConnectType.ODBC:
                        myCons.odbcDB1.Close();
                        myCons.odbcDB1.Dispose();
                        break;

                }
            }
            catch
            {
                //This is intentionally left blank, we dont want any exceptions rethrown as the object destroys
            }
        }

        #endregion

        #region "private methods for database communication used internal to class"

        /// <summary>
        /// Gets the command.
        /// </summary>
        /// <returns>IDbCommand.</returns>
        private IDbCommand GetCommand()
        {
            IDbCommand cmd = null;
            IDbConnection con = null;

            switch (myType)
            {

                case DataConnectType.ODBC:
                    cmd = myCons.odbcCMD;
                    con = myCons.odbcDB1;
                    break;
                case DataConnectType.OLEDB:
                    cmd = myCons.oleCMD;
                    con = myCons.oleDB1;
                    break;
                case DataConnectType.ORACLE:
                    cmd = myCons.oraCMD;
                    con = myCons.oraDB1;
                    break;
                case DataConnectType.SQLDB:
                    cmd = myCons.sqlCMD;
                    con = myCons.sqlDB1;
                    break;

            }

            if (cmd.Connection == null)
                cmd.Connection = con;

            if (cmd.Connection.State != ConnectionState.Open)
            {
                cmd.Connection.Open();
            }

            if (useMasterTransactionScope == true)
            {
                cmd.Transaction = trans;
            }

            return cmd;
            //default the return to sql command object
            //return myCons.sqlCMD;

        }

        /// <summary>
        /// Gets the parameters.
        /// </summary>
        /// <value>The parameters.</value>
        private ParameterStruct[] Parameters
        {
            get
            {
                switch (this.myType)
                {
                    case DataConnectType.SQLDB:
                        ParameterStruct[] RV = null;
                        RV = new ParameterStruct[-1 + 1];
                        int x = 0;

                        for (x = 0; x <= this.myCons.sqlCMD.Parameters.Count - 1; x++)
                        {

                            Array.Resize(ref RV, x + 1);
                            RV[x].Name = this.myCons.sqlCMD.Parameters[x].ToString();
                            RV[x].Value = this.myCons.sqlCMD.Parameters[x].Value.ToString();
                            RV[x].direction = this.myCons.sqlCMD.Parameters[x].Direction;

                        }

                        return RV;
                }

                return new ParameterStruct[0];
            }
        }

        /// <summary>
        /// Gets the data reader record count.
        /// </summary>
        /// <value>The data reader record count.</value>
        private int dataReaderRecordCount
        {
            get
            {

                try
                {

                    int x = 0;
                    switch (this.myType)
                    {
                        case DataConnectType.ODBC:
                            while (this.myCons.odbcDR.Read())
                            {
                                x += 1;
                            }

                            this.myCons.odbcDR.Close();
                            myCons.odbcDR = myCons.odbcCMD.ExecuteReader();

                            return x;

                        case DataConnectType.OLEDB:
                            while (this.myCons.oleDR.Read())
                            {
                                x += 1;
                            }

                            this.myCons.oleDR.Close();
                            myCons.oleDR = myCons.oleCMD.ExecuteReader();

                            return x;
                        //Case DataConnectType.ORACLE
                        //    Do While Me.myCons.oraDR.Read
                        //        x += 1
                        //    Loop
                        //    Me.myCons.oraDR.Close()
                        //    myCons.oraDR = myCons.oraCMD.ExecuteReader
                        //    Return x

                        case DataConnectType.SQLDB:
                            while (this.myCons.sqlDR.Read())
                            {
                                x += 1;
                            }

                            this.myCons.sqlDR.Close();
                            myCons.sqlDR = myCons.sqlCMD.ExecuteReader();

                            return x;

                    }
                }
                catch (Exception ex)
                {
                    return 0;
                }

                return 0;
            }
        }

        /// <summary>
        /// Gets the type of the what is my database connect.
        /// </summary>
        /// <value>The type of the what is my database connect.</value>
        private DataConnectType whatIsMyDBConnectType
        {
            get { return this.myType; }
        }

        /// <summary>
        /// Gets my connection string.
        /// </summary>
        /// <value>My connection string.</value>
        private string MyConnectionString
        {
            get
            {

                switch (this.myType)
                {

                    case DataConnectType.ODBC:
                        return this.myCons.odbcDB1.ConnectionString;
                    case DataConnectType.OLEDB:
                        return this.myCons.oleDB1.ConnectionString;
                    case DataConnectType.ORACLE:
                        return this.myCons.oraDB1.ConnectionString;
                    case DataConnectType.SQLDB:
                        return this.myCons.sqlDB1.ConnectionString;

                }

                return "";

            }

        }

        /// <summary>
        /// Sets the type of the command.
        /// </summary>
        /// <param name="inType">Type of the information.</param>
        private void setCommandType(CommandType inType)
        {

            switch (this.myType)
            {

                case DataConnectType.ODBC:
                    myCons.odbcCMD.CommandType = inType;
                    break;
                case DataConnectType.OLEDB:
                    myCons.oleCMD.CommandType = inType;
                    break;
                case DataConnectType.ORACLE:
                    myCons.oraCMD.CommandType = inType;
                    break;
                case DataConnectType.SQLDB:
                    myCons.sqlCMD.CommandType = inType;
                    break;

            }

        }

        /// <summary>
        /// Adds the parameter.
        /// </summary>
        /// <param name="parmName">Name of the parm.</param>
        /// <param name="parmVal">The parm value.</param>
        /// <param name="parmDir">The parm dir.</param>
        private void addParameter(string parmName, object parmVal, System.Data.ParameterDirection parmDir)
        {
            /*There MUST be a null check here, or there will be a null reference exception
            * for any parameters not initialized in code, but which may be allowed to be null
             * on the SQL side. */
            if (parmVal != null)
            {
                switch (this.myType)
                {

                    case DataConnectType.ODBC:
                        System.Data.SqlDbType x1 = default(System.Data.SqlDbType);
                        switch (parmVal.GetType().Name)
                        {

                            case "Int32":
                                x1 = SqlDbType.Int;
                                break;
                            case "Double":
                                x1 = SqlDbType.Float;
                                break;
                            case "String":
                                x1 = SqlDbType.VarChar;
                                break;
                            case "Byte[]":
                                x1 = SqlDbType.Image;
                                break;

                        }

                        myCons.odbcCMD.Parameters.Add(parmName);
                        myCons.odbcCMD.Parameters[parmName].Value = parmVal;
                        myCons.odbcCMD.Parameters[parmName].Direction = parmDir;
                        break;
                    case DataConnectType.OLEDB:
                        System.Data.OleDb.OleDbType x2 = default(System.Data.OleDb.OleDbType);
                        switch (parmVal.GetType().Name)
                        {

                            case "Int32":
                                x2 = System.Data.OleDb.OleDbType.Integer;
                                break;
                            case "Double":
                                x2 = System.Data.OleDb.OleDbType.Double;
                                break;
                            case "String":
                                x2 = System.Data.OleDb.OleDbType.VarChar;
                                break;
                            case "Byte[]":
                                x2 = System.Data.OleDb.OleDbType.Binary;
                                break;
                        }

                        myCons.oleCMD.Parameters.Add(parmName, x2);
                        myCons.oleCMD.Parameters[parmName].Value = parmVal;
                        myCons.oleCMD.Parameters[parmName].Direction = parmDir;
                        break;
                    case DataConnectType.ORACLE:
                        System.Data.OracleClient.OracleType x4 = default(System.Data.OracleClient.OracleType);

                        switch (parmVal.GetType().Name)
                        {

                            case "Int32":
                                x4 = System.Data.OracleClient.OracleType.Int16;
                                break;
                            case "Double":
                                x4 = System.Data.OracleClient.OracleType.Double;
                                break;
                            case "String":
                                x4 = System.Data.OracleClient.OracleType.VarChar;
                                break;
                            case "Byte[]":
                                x4 = System.Data.OracleClient.OracleType.Blob;
                                break;
                        }

                        myCons.oraCMD.Parameters.Add(parmName, x4);
                        myCons.oraCMD.Parameters[parmName].Value = parmVal;
                        myCons.oraCMD.Parameters[parmName].Direction = parmDir;
                        break;
                    case DataConnectType.SQLDB:
                        System.Data.SqlDbType x3 = default(System.Data.SqlDbType);
                        string dbcoltype = parmVal.GetType().Name;

                        switch (dbcoltype)
                        {
                            case "DateTime":
                                x3 = SqlDbType.DateTime;
                                break;
                            case "Boolean":
                                x3 = SqlDbType.Bit;
                                break;
                            case "Int32":
                                x3 = SqlDbType.Int;
                                break;
                            case "Double":
                                x3 = SqlDbType.Float;
                                break;
                            case "String":
                                x3 = SqlDbType.VarChar;
                                break;
                            case "Byte[]":
                                x3 = SqlDbType.Image;
                                break;

                        }

                        myCons.sqlCMD.Parameters.Add(parmName, x3);
                        myCons.sqlCMD.Parameters[parmName].Value = parmVal;
                        myCons.sqlCMD.Parameters[parmName].Direction = parmDir;
                        break;
                }
            }
        }

        /// <summary>
        /// Closes the connection.
        /// </summary>
        private void closeConnection()
        {

            switch (this.myType)
            {

                case DataConnectType.ODBC:
                    myCons.odbcDB1.Close();
                    break;
                case DataConnectType.OLEDB:
                    myCons.oleDB1.Close();
                    break;
                case DataConnectType.ORACLE:
                    myCons.oraDB1.Close();
                    break;
                case DataConnectType.SQLDB:
                    myCons.sqlDB1.Close();
                    break;

            }

        }

        /// <summary>
        /// Preferences the open connection.
        /// </summary>
        private void reOpenConnection()
        {

            switch (this.myType)
            {

                case DataConnectType.ODBC:
                    myCons.odbcDB1.Open();
                    break;
                case DataConnectType.OLEDB:
                    myCons.oleDB1.Open();
                    break;
                case DataConnectType.ORACLE:
                    myCons.oraDB1.Open();
                    break;
                case DataConnectType.SQLDB:
                    myCons.sqlDB1.Open();
                    break;

            }

        }

        /// <summary>
        /// Gets the column headers.
        /// </summary>
        /// <returns>mdbColumnHeaders[][].</returns>
        private mdbColumnHeaders[] getColumnHeaders()
        {
            mdbColumnHeaders[] retval = null;
            retval = new mdbColumnHeaders[-1 + 1];

            switch (myType)
            {
                case DataConnectType.ODBC:

                    for (int x = 0; x <= myCons.odbcDR.FieldCount - 1; x++)
                    {
                        Array.Resize(ref retval, x + 1);
                        retval[x].name = myCons.odbcDR.GetName(x);
                        retval[x].dbType = myCons.odbcDR.GetFieldType(x);
                    }

                    break;
                case DataConnectType.OLEDB:
                    for (int x1 = 0; x1 <= myCons.oleDR.FieldCount - 1; x1++)
                    {
                        Array.Resize(ref retval, x1 + 1);
                        retval[x1].name = myCons.oleDR.GetName(x1);
                        retval[x1].dbType = myCons.oleDR.GetFieldType(x1);
                    }

                    break;
                case DataConnectType.ORACLE:
                    for (int x3 = 0; x3 <= myCons.oleDR.FieldCount - 1; x3++)
                    {
                        Array.Resize(ref retval, x3 + 1);
                        retval[x3].name = myCons.oraDR.GetName(x3);
                        retval[x3].dbType = myCons.oraDR.GetFieldType(x3);
                    }
                    break;
                case DataConnectType.SQLDB:
                    for (int x2 = 0; x2 <= myCons.sqlDR.FieldCount - 1; x2++)
                    {
                        Array.Resize(ref retval, x2 + 1);
                        retval[x2].name = myCons.sqlDR.GetName(x2);
                        retval[x2].dbType = myCons.sqlDR.GetFieldType(x2);

                    }

                    break;



            }
            return retval;
        }

        /// <summary>
        /// Gives the memory data reader.
        /// </summary>
        /// <returns>System.Object.</returns>
        private object giveMeDataReader()
        {
            executeReader();
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR;
                case DataConnectType.OLEDB:
                    return myCons.oleDR;
                case DataConnectType.ORACLE:
                    return myCons.oraDR;
                case DataConnectType.SQLDB:
                    return myCons.sqlDR;


            }
            return null;
        }

        /// <summary>
        /// Gets the named.
        /// </summary>
        /// <param name="oridinalName">Name of the oridinal.</param>
        /// <returns>System.Object.</returns>
        private object getNamed(string oridinalName)
        {
            int x = 0;
            switch (myType)
            {
                case DataConnectType.ODBC:
                    x = myCons.odbcDR.GetOrdinal(oridinalName);
                    if (!myCons.odbcDR.IsDBNull(x))
                        return myCons.odbcDR[x];
                    else
                        return "";
                    break;
                case DataConnectType.OLEDB:
                    x = myCons.oleDR.GetOrdinal(oridinalName);
                    if (!myCons.oleDR.IsDBNull(x))
                        return myCons.oleDR[x];
                    else
                        return "";
                    break;
                case DataConnectType.ORACLE:
                    x = myCons.oraDR.GetOrdinal(oridinalName);
                    if (!myCons.oraDR.IsDBNull(x))
                        return myCons.oraDR[x];
                    else
                        return "";
                    break;

                case DataConnectType.SQLDB:
                    x = myCons.sqlDR.GetOrdinal(oridinalName);
                    if (!myCons.sqlDR.IsDBNull(x))
                        return myCons.sqlDR[x];
                    else
                        return "";

                    break;


            }
            return "";

        }

        /// <summary>
        /// Views the connect string.
        /// </summary>
        /// <returns>System.String.</returns>
        private string viewConnectString()
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDB1.ConnectionString;
                case DataConnectType.OLEDB:
                    return myCons.oleDB1.ConnectionString;
                case DataConnectType.ORACLE:
                    return myCons.oraDB1.ConnectionString;
                case DataConnectType.SQLDB:
                    return myCons.sqlDB1.ConnectionString;

            }
            return "";
        }

        /// <summary>
        /// Commands the text.
        /// </summary>
        /// <returns>System.String.</returns>
        private string commandText()
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcCMD.CommandText;
                case DataConnectType.OLEDB:
                    return myCons.oleCMD.CommandText;
                case DataConnectType.ORACLE:
                    return myCons.oraCMD.CommandText;
                case DataConnectType.SQLDB:
                    return myCons.sqlCMD.CommandText;


            }
            return "";
        }

        /// <summary>
        /// Drs the read.
        /// </summary>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool drRead()
        {
            //advances the syste.data.datareader to the next record
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.Read();
                    break;
                case DataConnectType.OLEDB:
                    return myCons.oleDR.Read();
                    break;
                case DataConnectType.ORACLE:
                    return myCons.oraDR.Read();
                    break;
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.Read();
                    break;


            }
            return false;
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="Timeout">The timeout.</param>
        /// <returns>System.Int32.</returns>
        private int executeNonQuery(int Timeout)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    myCons.odbcCMD.CommandTimeout = Timeout;
                    return myCons.odbcCMD.ExecuteNonQuery();
                case DataConnectType.OLEDB:
                    myCons.oleCMD.CommandTimeout = Timeout;
                    return myCons.oleCMD.ExecuteNonQuery();
                case DataConnectType.ORACLE:
                    return myCons.oraCMD.ExecuteNonQuery();
                case DataConnectType.SQLDB:
                    myCons.sqlCMD.CommandTimeout = Timeout;
                    return myCons.sqlCMD.ExecuteNonQuery();

            }
            return 0;
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <returns>System.Int32.</returns>
        private int executeNonQuery()
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcCMD.ExecuteNonQuery();
                case DataConnectType.OLEDB:
                    return myCons.oleCMD.ExecuteNonQuery();
                case DataConnectType.ORACLE:
                    return myCons.oraCMD.ExecuteNonQuery();
                case DataConnectType.SQLDB:
                    return myCons.sqlCMD.ExecuteNonQuery();

            }
            return 0;
        }

        /// <summary>
        /// Executes the reader.
        /// </summary>
        /// <returns>IDataReader.</returns>
        private IDataReader executeReader()
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    myCons.odbcDR = myCons.odbcCMD.ExecuteReader();
                    return myCons.odbcDR;
                    break;
                case DataConnectType.OLEDB:
                    myCons.oleDR = myCons.oleCMD.ExecuteReader();
                    return myCons.oleDR;
                    break;
                case DataConnectType.ORACLE:
                    myCons.oraDR = myCons.oraCMD.ExecuteReader();
                    return myCons.oraDR;
                    break;
                case DataConnectType.SQLDB:
                    myCons.sqlDR = myCons.sqlCMD.ExecuteReader();
                    return myCons.sqlDR;
                    break;
                default:
                    myCons.sqlDR = myCons.sqlCMD.ExecuteReader();
                    return myCons.sqlDR;

            }
        }

        /// <summary>
        /// Sets the set command text.
        /// </summary>
        /// <value>The set command text.</value>
        private string setCommandText
        {
            set
            {
                switch (myType)
                {
                    case DataConnectType.ODBC:
                        myCons.odbcCMD = new System.Data.Odbc.OdbcCommand();
                        myCons.odbcCMD.Connection = myCons.odbcDB1;
                        myCons.odbcCMD.CommandText = value;
                        break;
                    case DataConnectType.OLEDB:
                        myCons.oleCMD = new System.Data.OleDb.OleDbCommand();
                        myCons.oleCMD.Connection = myCons.oleDB1;
                        myCons.oleCMD.CommandText = value;
                        break;
                    case DataConnectType.ORACLE:
                        myCons.oraCMD = new OracleCommand();
                        myCons.oraCMD.Connection = myCons.oraDB1;
                        myCons.oraCMD.CommandText = value;
                        break;
                    case DataConnectType.SQLDB:
                        myCons.sqlCMD = new System.Data.SqlClient.SqlCommand();
                        myCons.sqlCMD.Connection = myCons.sqlDB1;
                        myCons.sqlCMD.CommandText = value;
                        break;

                }
            }
        }

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.Object.</returns>
        private object getValue(int index)
        {

            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetValue(index);
                case DataConnectType.OLEDB:

                    return myCons.oleDR.GetValue(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetValue(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetValue(index);

            }
            return new object();
        }

        /// <summary>
        /// Gets the string.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.String.</returns>
        private string getString(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetString(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetString(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetString(index);
                case DataConnectType.SQLDB:
                    if (myCons.sqlDR.IsDBNull(index))
                        return "";
                    else
                        return myCons.sqlDR.GetString(index);

            }
            return "";
        }

        /// <summary>
        /// Gets the date time.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.DateTime.</returns>
        private System.DateTime getDateTime(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetDateTime(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetDateTime(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetDateTime(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetDateTime(index);

            }
            return new System.DateTime();
        }

        /// <summary>
        /// Gets the name of the data type.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.String.</returns>
        private string getDataTypeName(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetDataTypeName(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetDataTypeName(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetDataTypeName(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetDataTypeName(index);

            }
            return "";
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.String.</returns>
        private string getName(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetName(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetName(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetName(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetName(index);

            }
            return "";
        }

        /// <summary>
        /// Gets the decimal.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.Decimal.</returns>
        private decimal getDecimal(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetDecimal(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetDecimal(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetDecimal(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetDecimal(index);

            }
            return 0;
        }

        /// <summary>
        /// Gets the double.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.Double.</returns>
        private double getDouble(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetDouble(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetDouble(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetDouble(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetDouble(index);

            }
            return 0;
        }

        /// <summary>
        /// Gets the float.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.Single.</returns>
        private float getFloat(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetFloat(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetFloat(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetFloat(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetFloat(index);

            }
            return 0;
        }

        /// <summary>
        /// Gets the long.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.Int64.</returns>
        private long getLong(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetInt64(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetInt64(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetInt64(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetInt64(index);

            }
            return 0;
        }

        /// <summary>
        /// Gets the integer.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.Int32.</returns>
        private int getInteger(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetInt32(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetInt32(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetInt32(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetInt32(index);

            }
            return 0;
        }

        /// <summary>
        /// Gets the short.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.Int16.</returns>
        private short getShort(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetInt16(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetInt16(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetInt16(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetInt16(index);

            }
            return 0;
        }

        /// <summary>
        /// Gets the unique identifier.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.Guid.</returns>
        private System.Guid getGuid(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetGuid(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetGuid(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetGuid(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetGuid(index);

            }
            return new System.Guid();
        }

        /// <summary>
        /// Gets the has code.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>System.Int32.</returns>
        private int getHasCode(int index)
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.GetHashCode();
                case DataConnectType.OLEDB:
                    return myCons.oleDR.GetHashCode();
                case DataConnectType.ORACLE:
                    return myCons.oraDR.GetHashCode();
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.GetHashCode();

            }
            return 0;
        }

        /// <summary>
        /// Gets a value indicating whether this instance has rows.
        /// </summary>
        /// <value><c>true</c> if this instance has rows; otherwise, <c>false</c>.</value>
        private bool hasRows
        {
            get
            {
                try
                {
                    switch (myType)
                    {
                        case DataConnectType.ODBC:
                            return myCons.odbcDR.HasRows;
                        case DataConnectType.OLEDB:
                            return myCons.oleDR.HasRows;
                        case DataConnectType.ORACLE:
                            return myCons.oraDR.HasRows;
                        case DataConnectType.SQLDB:
                            return myCons.sqlDR.HasRows;

                    }
                }
                catch (Exception ex)
                {
                    Trace.Write(ex.Message, "HS.Data.ORM");
                    Console.WriteLine(ex.Message);
                }
                return false;
            }

        }

        /// <summary>
        /// Gets the state.
        /// </summary>
        /// <value>The state.</value>
        private System.Data.ConnectionState State
        {
            get
            {
                switch (myType)
                {
                    case DataConnectType.ODBC:
                        return myCons.odbcDB1.State;
                    case DataConnectType.OLEDB:
                        return myCons.oleDB1.State;
                    case DataConnectType.ORACLE:
                        return myCons.oraDB1.State;
                    case DataConnectType.SQLDB:
                        return myCons.sqlDB1.State;

                }
                return ConnectionState.Broken;
            }
        }

        /// <summary>
        /// Closes the reader.
        /// </summary>
        private void closeReader()
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    myCons.odbcDR.Close();
                    break;
                case DataConnectType.OLEDB:
                    myCons.oleDR.Close();
                    break;
                case DataConnectType.ORACLE:
                    myCons.oraDR.Close();
                    break;
                case DataConnectType.SQLDB:
                    myCons.sqlDR.Close();
                    break;

            }
        }

        /// <summary>
        /// Gets the data set.
        /// </summary>
        /// <returns>System.Data.DataSet.</returns>
        private System.Data.DataSet getDataSet()
        {
            switch (myType)
            {
                case DataConnectType.ODBC:
                    System.Data.Odbc.OdbcDataAdapter DA1 = new System.Data.Odbc.OdbcDataAdapter();
                    DataSet DS1 = new DataSet();
                    DA1.SelectCommand = myCons.odbcCMD;
                    DA1.Fill(DS1);

                    return DS1;
                case DataConnectType.OLEDB:
                    System.Data.OleDb.OleDbDataAdapter DA2 = new System.Data.OleDb.OleDbDataAdapter();
                    DataSet DS2 = new DataSet();
                    DA2.SelectCommand = myCons.oleCMD;
                    DA2.Fill(DS2);
                    return DS2;
                case DataConnectType.ORACLE:
                    OracleDataAdapter DA4 = new OracleDataAdapter();
                    DataSet DS4 = new DataSet();
                    DA4.SelectCommand = myCons.oraCMD;
                    DA4.Fill(DS4);
                    return DS4;

                case DataConnectType.SQLDB:

                    System.Data.SqlClient.SqlDataAdapter DA3 = new System.Data.SqlClient.SqlDataAdapter();
                    DataSet DS3 = new DataSet();
                    DA3.SelectCommand = myCons.sqlCMD;
                    DA3.Fill(DS3);

                    return DS3;

            }
            return new DataSet();
        }

        /// <summary>
        /// Gets the data table.
        /// </summary>
        /// <returns>System.Data.DataTable.</returns>
        private System.Data.DataTable getDataTable()
        {
            DataTable retVal = new DataTable();
            System.Data.Odbc.OdbcDataAdapter odbcAD = new System.Data.Odbc.OdbcDataAdapter();
            System.Data.OleDb.OleDbDataAdapter oleAD = new System.Data.OleDb.OleDbDataAdapter();
            OracleDataAdapter oraAD = new System.Data.OracleClient.OracleDataAdapter();
            System.Data.SqlClient.SqlDataAdapter sqlAD = new System.Data.SqlClient.SqlDataAdapter();

            switch (myType)
            {
                case DataConnectType.ODBC:
                    odbcAD.SelectCommand = myCons.odbcCMD;
                    odbcAD.Fill(retVal);
                    break;
                case DataConnectType.OLEDB:
                    oleAD.SelectCommand = myCons.oleCMD;
                    oleAD.Fill(retVal);
                    break;
                case DataConnectType.ORACLE:
                    oraAD.SelectCommand = myCons.oraCMD;
                    oraAD.Fill(retVal);
                    break;
                case DataConnectType.SQLDB:
                    sqlAD.SelectCommand = myCons.sqlCMD;
                    sqlAD.Fill(retVal);
                    break;



            }
            return retVal;
        }

        /// <summary>
        /// Determines whether [is database null] [the specified index].
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns><c>true</c> if [is database null] [the specified index]; otherwise, <c>false</c>.</returns>
        private bool IsDBNull(int index)
        {

            switch (myType)
            {
                case DataConnectType.ODBC:
                    return myCons.odbcDR.IsDBNull(index);
                case DataConnectType.OLEDB:
                    return myCons.oleDR.IsDBNull(index);
                case DataConnectType.ORACLE:
                    return myCons.oraDR.IsDBNull(index);
                case DataConnectType.SQLDB:
                    return myCons.sqlDR.IsDBNull(index);

            }
            return false;
        }

        /// <summary>
        /// Determines whether [is database null] [the specified ordinal name].
        /// </summary>
        /// <param name="ordinalName">Name of the ordinal.</param>
        /// <returns><c>true</c> if [is database null] [the specified ordinal name]; otherwise, <c>false</c>.</returns>
        private bool IsDBNull(string ordinalName)
        {
            int x = 0;
            switch (myType)
            {
                case DataConnectType.ODBC:
                    x = myCons.odbcDR.GetOrdinal(ordinalName);
                    return myCons.odbcDR.IsDBNull(x);
                case DataConnectType.OLEDB:
                    x = myCons.oleDR.GetOrdinal(ordinalName);
                    return myCons.oleDR.IsDBNull(x);
                case DataConnectType.ORACLE:
                    x = myCons.oraDR.GetOrdinal(ordinalName);
                    return myCons.oraDR.IsDBNull(x);
                case DataConnectType.SQLDB:
                    x = myCons.sqlDR.GetOrdinal(ordinalName);
                    return myCons.sqlDR.IsDBNull(x);

            }
            return false;
        }

        /// <summary>
        /// Gets my parameters.
        /// </summary>
        /// <value>My parameters.</value>
        private ParameterStruct[] MyParameters
        {
            get
            {
                switch (this.myType)
                {
                    case DataConnectType.SQLDB:
                        ParameterStruct[] RV = null;
                        RV = new ParameterStruct[-1 + 1];
                        int x = 0;
                        for (x = 0; x <= this.myCons.sqlCMD.Parameters.Count - 1; x++)
                        {
                            Array.Resize(ref RV, x + 1);
                            RV[x].Name = this.myCons.sqlCMD.Parameters[x].ToString();
                            RV[x].Value = this.myCons.sqlCMD.Parameters[x].Value.ToString();
                            RV[x].direction = this.myCons.sqlCMD.Parameters[x].Direction;
                        }

                        return RV;
                }
                return new ParameterStruct[0];
            }
        }

        /// <summary>
        /// Struct ParameterStruct
        /// </summary>
        private struct ParameterStruct
        {
            /// <summary>
            /// The name
            /// </summary>
            public string Name;
            /// <summary>
            /// The value
            /// </summary>
            public string Value;
            /// <summary>
            /// The direction
            /// </summary>
            public System.Data.ParameterDirection direction;
        }

        /// <summary>
        /// Struct mdbColumnHeaders
        /// </summary>
        private struct mdbColumnHeaders
        {
            /// <summary>
            /// The name
            /// </summary>
            public string name;
            /// <summary>
            /// The database type
            /// </summary>
            public System.Type dbType;
        }

        #endregion
    }
}
