﻿// ***********************************************************************
// Assembly         : HS.Data.ORM
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="DALAttribute.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;

/// <summary>
/// The ORM namespace.
/// </summary>
namespace HS.Data.ORM
{
    /// <summary>
    /// Add this attribute to any class that implements
    /// <see cref="IDAL" /> if you would like it to support
    /// data mocking or use a default connection string.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public class DALAttribute : Attribute
    {

        /// <summary>
        /// If this is specified, then it will be set as the
        /// <see cref="DefaultConnectionStringName" /> of the
        /// <see cref="IDataContext" /> that created it.
        /// </summary>
        /// <value>The default name of the connection string.</value>
        public string DefaultConnectionStringName { get; set; }

    }
}
