﻿// ***********************************************************************
// Assembly         : HS.Data.ORM
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="iORM.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;

/// <summary>
/// The ORM namespace.
/// </summary>
namespace HS.Data.ORM
{

    /// <summary>
    /// Interface iORM
    /// </summary>
    public interface iORM
    {
        /// <summary>
        /// This will create a data reader, based on the Stored Proc name specified, and map the results into
        /// a single object. If multiple results are returned from the DB, only the first object will be returned
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>a single object of type T as specified</returns>
        T MapObjectFromDataReader<T>(List<ParamItem> Params, string ProcName) where T : new();


        /// <summary>
        /// This will create a data reader, based on the Stored Proc name specified, and map the results into
        /// an IEnumerable List of objects.
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>an IEnumerable List of objects of type T as specified</returns>
        List<T> MapListFromDataReader<T>(List<ParamItem> Params, string ProcName) where T : new();

        /// <summary>
        /// This will create a DataSet, based on the Stored Proc name specified, and map the results into
        /// a single object. If multiples are returned, only the first object will be returned
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>a single object of type T as specified</returns>
        T MapObjectFromDataSet<T>(List<ParamItem> Params, string ProcName) where T : new();


        /// <summary>
        /// This will create a DataSet, based on the Stored Proc name specified, and map the results into
        /// a single object. If multiples are returned, only the first object will be returned
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>an IEnumerable List of objects of type T as specified</returns>
        List<T> MapListFromDataSet<T>(List<ParamItem> Params, string ProcName) where T : new();

        /// <summary>
        /// This will create a DataSet, based on the Stored Proc name specified, and map the results into
        /// a single object. If multiples are returned, only the first object will be returned
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>a single object of type T as specified</returns>
        T MapObjectFromDataTable<T>(List<ParamItem> Params, string ProcName) where T : new();


        /// <summary>
        /// This will create a DataTable, based on the Stored Proc name specified, and map the results into
        /// a single object. If mutiples are returned, only the first object will be returned
        /// </summary>
        /// <typeparam name="T">The Type of the object to be returned</typeparam>
        /// <param name="Params">A list of parameters to pass to the stored procedure</param>
        /// <param name="ProcName">the name of the stored procedure to run</param>
        /// <returns>an IEnumerable List of objects of type T as specified</returns>
        List<T> MapListFromDataTable<T>(List<ParamItem> Params, string ProcName) where T : new();


        /// <summary>
        /// This will create a data reader based on the InlineSQL passed in and map the results into the object
        /// type specified. If multiple results are returned, only the first object will be returned
        /// </summary>
        /// <typeparam name="T">The type of object to be returned</typeparam>
        /// <param name="SqlToRun">The inline SQL to be run</param>
        /// <returns>a single object of type T as specified</returns>
        [Obsolete("Not used anymore", true)]
        T MapObjectFromInlineSQL<T>(string SqlToRun) where T : new();

        /// <summary>
        /// This will create a data reader based on the InlineSQL passed in and map the retults into an
        /// iEnumerable list of objecst of the type specified
        /// </summary>
        /// <typeparam name="T">The type of object to be returned</typeparam>
        /// <param name="SqlToRun">The inline SQL to be run</param>
        /// <returns>an IEnumerable List of objects of type T as specified</returns>
        [Obsolete("Not used anymore", true)]
        List<T> MapListFromInlineSQL<T>(string SqlToRun) where T : new();

        /// <summary>
        /// If a transaction scope was started, this commits the current transaction to the DB
        /// </summary>
        void TransactionCommit();


        /// <summary>
        /// If a transaction scope was started, thsi rolls back the current transaction
        /// </summary>
        void TransactionRollBack();

    }
}