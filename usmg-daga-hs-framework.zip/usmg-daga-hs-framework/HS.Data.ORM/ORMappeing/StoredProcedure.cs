﻿using System.Collections.Generic;

namespace HS.Data.ORM
{
    internal class StoredProcedure
    {
        /// <summary>
        /// User friendly name to reference stored procedure parameter.
        /// </summary>
        public string Friendly { get; set; }
        /// <summary>
        /// Actual name from stored procedure in the database.
        /// </summary>
        public string Actual { get; set; }
        /// <summary>
        /// List of parameters.
        /// </summary>
        public List<StoredProcedureParameter> Parameters { get; set; }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public StoredProcedure()
        {
        }
        /// <summary>
        /// Overloaded constructor
        /// </summary>
        /// <param name="friendly">User friendly name to reference stored procedure.</param>
        /// <param name="actual">Actual name of stored procedure in the database.</param>
        public StoredProcedure(string friendly, string actual)
        {
            Friendly = friendly;
            Actual = actual;
            Parameters = new List<StoredProcedureParameter>();
        }
        /// <summary>
        /// Overloaded constructor
        /// </summary>
        /// <param name="friendly">User friendly name to reference stored procedure.</param>
        /// <param name="actual">Actual name of stored procedure in the database.</param>
        /// <param name="parms">List of StoredProcedureParameters</param>
        public StoredProcedure(string friendly, string actual, List<StoredProcedureParameter> parms)
        {
            Friendly = friendly;
            Actual = actual;
            Parameters = parms;
        }

        /// <summary>
        /// Overridden
        /// </summary>
        /// <returns>Friendly name (Parameter count)</returns>
        public override string ToString()
        {
            return string.Format("{0} ({1})",
                                    Friendly,
                                    ((Parameters != null) ? Parameters.Count : 0)
                                    );
        }
    }

    internal class StoredProcedureParameter
    {
        /// <summary>
        /// User friendly name to reference stored procedure parameter.
        /// </summary>
        public string Friendly { get; set; }
        /// <summary>
        /// Actual name from stored procedure in the database.
        /// </summary>
        public string Actual { get; set; }
        /// <summary>
        /// Type of parameter within the stored procedure.
        /// </summary>
        public System.Data.ParameterDirection Direction { get; set; }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public StoredProcedureParameter()
        {
        }
        /// <summary>
        /// Overloaded constructor
        /// </summary>
        /// <param name="friendly">User friendly name to reference stored procedure parameter.</param>
        /// <param name="actual">Actual name from stored procedure in the database.</param>
        /// <param name="direction">Type of parameter within the stored procedure.</param>
        public StoredProcedureParameter(string friendly, string actual, System.Data.ParameterDirection direction)
        {
            Friendly = friendly;
            Actual = actual;
            Direction = direction;
        }

        /// <summary>
        /// Overridden
        /// </summary>
        /// <returns>Friendly name [Direction]</returns>
        public override string ToString()
        {
            return string.Format("{0} [{1}]",
                                    Friendly,
                                    Direction.ToString()
                                    );
        }
    }
}
