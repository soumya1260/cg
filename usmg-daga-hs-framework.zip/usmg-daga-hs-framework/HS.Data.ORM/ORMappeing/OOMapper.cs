﻿// ***********************************************************************
// Assembly         : HS.Data.ORM
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="OOMapper.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
using System.Xml.Linq;

/// <summary>
/// The ORM namespace.
/// </summary>
namespace HS.Data.ORM
{
    /// <summary>
    /// Class OOMapper.
    /// </summary>
    /// <typeparam name="SourceType">The type of the source type.</typeparam>
    /// <typeparam name="DestType">The type of the dest type.</typeparam>
    public class OOMapper<SourceType, DestType> where DestType : new()
    {
        #region Member Variables
        /// <summary>
        /// The _property map
        /// </summary>
        private Dictionary<PropertyInfo, PropertyInfo> _propertyMap;
        #endregion

        #region Contstructors
        //this constructor is private because this class is a singleton
        /// <summary>
        /// Prevents a default instance of the <see cref="OOMapper{SourceType, DestType}"/> class from being created.
        /// </summary>
        private OOMapper()
        {
            BuildPropertyMap();
        }

        //this constructor is private because this class is a singleton
        /// <summary>
        /// Initializes a new instance of the <see cref="OOMapper{SourceType, DestType}"/> class.
        /// </summary>
        /// <param name="mapFile">The map file.</param>
        private OOMapper(string mapFile)
        {
            //This Xlinq magic queries the xml file and builds the dictionary mapping
            //source object properties to destination object properties
            XDocument mappings = XDocument.Load(mapFile);
            XNamespace ns = mappings.Root.Name.Namespace;

            if (mappings.Descendants(ns + "oomap").Where(a => 
                (a.Attribute("source").Value == typeof(SourceType).FullName) &&
                (a.Attribute("destination").Value == typeof(DestType).FullName)).Count() > 0)
            {
                BuildPropertyMap(mappings);
            }
            else
            {
                BuildPropertyMap();
            }
        }
        #endregion

        #region Singleton implementation

        //This is only used for locking the instance
        /// <summary>
        /// The _instance lock
        /// </summary>
        private static object _instanceLock = new object();

        /// <summary>
        /// The _instance
        /// </summary>
        private static OOMapper<SourceType, DestType> _instance;

        /// <summary>
        /// Gets the instance.
        /// </summary>
        /// <value>The instance.</value>
        public static OOMapper<SourceType, DestType> Instance
        {
            get
            {
                lock (_instanceLock)
                {
                    if (_instance == null)
                    {
                        if (!String.IsNullOrEmpty(ConfigurationManager.AppSettings["MapperXml"]))
                        {
                            //create the mapper using an xml file
                            _instance = new OOMapper<SourceType, DestType>(ConfigurationManager.AppSettings["MapperXml"]);
                        }
                        else
                        {
                            //create the mapper using direct column-to-property
                            _instance = new OOMapper<SourceType, DestType>();
                        }
                    }
                    return _instance;
                }
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Maps an instance of SourceType to a new instance of DestType
        /// </summary>
        /// <param name="Source">The source object</param>
        /// <returns>A new destination object</returns>
        public DestType Map(SourceType Source)
        {
            DestType t = new DestType();

            foreach (PropertyInfo source_property in _propertyMap.Keys)
            {
                PropertyInfo dest_property = _propertyMap[source_property];
                object val = source_property.GetValue(Source, null);

                //if these are disparate types, use the built-in type converter
                if (source_property.PropertyType != dest_property.PropertyType)
                {
                    val = TypeDescriptor.GetConverter(source_property.PropertyType).ConvertTo(val, dest_property.PropertyType);
                }

                //if this is a reference type, a deep copy is needed
                else if (!source_property.PropertyType.IsValueType)
                {
                    //perform the deep copy by serializing the source property value
                    //and deserializing into destination value
                    //TODO:  See if this performs better or worse than a recursive deep copy
                    BinaryFormatter bf = new BinaryFormatter();
                    using (MemoryStream ms = new MemoryStream())
                    {
                        bf.Serialize(ms, val);
                        ms.Seek(0, SeekOrigin.Begin);
                        val = bf.Deserialize(ms);
                        ms.Close();
                    }
                }
                dest_property.SetValue(t, val, null);
            }

            return t;
        }

        /// <summary>
        /// Builds the property map.
        /// </summary>
        private void BuildPropertyMap()
        {
            //this LINQ code iterates through all source properties that have a matching
            //destination property, and converts it to a dictionary entry
            _propertyMap = (from prop in typeof(SourceType).GetProperties()
                            where typeof(DestType).GetProperty(prop.Name) != null
                            select new
                            {
                                SourceProperty = prop,
                                DestinationProperty = typeof(DestType).GetProperty(prop.Name)
                            }).ToDictionary(p => p.SourceProperty, p => p.DestinationProperty);

            VerifyTypes();
        }

        /// <summary>
        /// Builds the property map.
        /// </summary>
        /// <param name="mappings">The mappings.</param>
        private void BuildPropertyMap(XDocument mappings)
        {
            XNamespace ns = mappings.Root.Name.Namespace;

            /*Func<string, PropertyInfo> checkprop = delegate(string s)
            {
                string[] props = s.Split('.');
                if (props.Length > 1)
                {

                }
                else
                {

                }
            };*/

            _propertyMap = (from prop in mappings.Descendants(ns + "oomap").Elements(ns + "property")
                            where (prop.Parent.Attribute("source").Value == typeof(SourceType).FullName) &&
                                  (prop.Parent.Attribute("destination").Value == typeof(DestType).FullName)
                            select new
                            {
                                SourceProperty = typeof(SourceType).GetProperty(prop.Attribute("source").Value),
                                DestinationProperty = typeof(DestType).GetProperty(prop.Attribute("destination").Value)
                            }).ToDictionary((p => { if (p.SourceProperty != null) return p.SourceProperty; else throw new InvalidPropertyException(); }),
                                        (p => p.DestinationProperty));

            VerifyTypes();
        }

        /// <summary>
        /// Verifies the types.
        /// </summary>
        /// <exception cref="HS.Data.ORM.InvalidPropertyException">
        /// </exception>
        /// <exception cref="TypeMismatchException"></exception>
        private void VerifyTypes()
        {
            foreach (PropertyInfo source_property in _propertyMap.Keys)
            {
                if (source_property == null)
                    throw new InvalidPropertyException();
                
                PropertyInfo dest_property = _propertyMap[source_property];

                if (dest_property == null)
                    throw new InvalidPropertyException();

                if (source_property.PropertyType != dest_property.PropertyType)
                {
                    //check if this is a vaild conversion
                    if (!TypeDescriptor.GetConverter(source_property.PropertyType).CanConvertTo(dest_property.PropertyType))
                        throw new TypeMismatchException();
                }
            }
        }

        #endregion
    }
}
