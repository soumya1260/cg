﻿// ***********************************************************************
// Assembly         : HS.Data.ORM
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="Mapper.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.Collections.Generic;
using System.Data;

/// <summary>
/// The ORM namespace.
/// </summary>
namespace HS.Data.ORM
{

    /// <summary>
    /// Class Mapper.
    /// </summary>
    public class Mapper
    {

        /// <summary>
        /// Returns a collection of a T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ds">The ds.</param>
        /// <returns>List{``0}.</returns>
        public static List<T> MapAll<T>(DataSet ds) where T : new()
        {
            List<T> result = ORMapper<T>.Instance.Map(ds.Tables[0]);
            return result;
        }

        /// <summary>
        /// Returns an instance of a T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ds">The ds.</param>
        /// <returns>``0.</returns>
        public static T Map<T>(DataSet ds) where T : new()
        {
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                T result = ORMapper<T>.Instance.Map(ds.Tables[0].Rows[0]);
                return result;
            }
            else
                return default(T);
        }

        /// <summary>
        /// Returns a collection of a T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dt">The dt.</param>
        /// <returns>List{``0}.</returns>
        public static List<T> MapAll<T>(DataTable dt) where T : new()
        {
            List<T> result = ORMapper<T>.Instance.Map(dt);
            return result;
        }

        /// <summary>
        /// Returns a collection of a T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="rows">The rows.</param>
        /// <returns>List{``0}.</returns>
        public static List<T> MapAll<T>(IEnumerable<DataRow> rows) where T : new()
        {
            List<T> result = ORMapper<T>.Instance.Map(rows);
            return result;
        }

        /// <summary>
        /// Returns a collection of a T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dr">The dr.</param>
        /// <returns>List{``0}.</returns>
        public static List<T> MapAll<T>(IDataReader dr) where T : new()
        {
            List<T> result = ORMapper<T>.Instance.MapAll(dr);
            return result;
        }

        /// <summary>
        /// Returns an instance of a T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dt">The dt.</param>
        /// <returns>``0.</returns>
        public static T Map<T>(DataTable dt) where T : new()
        {
            if (dt.Rows.Count > 0)
            {
                T result = ORMapper<T>.Instance.Map(dt.Rows[0]);
                return result;
            }
            else
                return default(T);
        }

        /// <summary>
        /// Returns an instance of a T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dr">The dr.</param>
        /// <returns>``0.</returns>
        public static T Map<T>(DataRow dr) where T : new()
        {
            T result = ORMapper<T>.Instance.Map(dr);
            return result;
        }

        /// <summary>
        /// Returns an instance of a T.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dr">The dr.</param>
        /// <returns>``0.</returns>
        public static T Map<T>(IDataReader dr) where T : new()
        {
            T result = ORMapper<T>.Instance.Map(dr);
            return result;
        }

    }

}
