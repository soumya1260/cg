﻿// // ***********************************************************************
// Assembly         : HS.Data.ORM
// Author           : stephen.dornan
// Created          : 09-11-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-11-2013
// ***********************************************************************
// <copyright file="ORMapper.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Xml.Linq;

/// <summary>
/// The ORM namespace.
/// </summary>
namespace HS.Data.ORM
{

    /// <summary>
    /// Class ORMapper. This class cannot be inherited. 
    /// This class throws a MApNotFoundException if it cannot find a matching map for the 
    /// object sent in.
    /// </summary>
    /// <typeparam name="DestType">The type of the dest type.</typeparam>
    public sealed class ORMapper<DestType> where DestType : new()
    {

        #region Member variables
        /// <summary>
        /// The _property map
        /// </summary>
        private Dictionary<string, PropertyInfo> _propertyMap;
        /// <summary>
        /// The _embedded property map
        /// </summary>
        private Dictionary<PropertyInfo, Type> _embeddedPropertyMap;
        /// <summary>
        /// The _enum property map
        /// </summary>
        private Dictionary<KeyValuePair<string, PropertyInfo>, Dictionary<string, string>> _enumPropertyMap;

        /// <summary>
        /// The _stored proc map
        /// </summary>
        private List<StoredProcedure> _storedProcMap;

        internal List<StoredProcedure> StoredProcMap
        {
            get { return _storedProcMap; }
            set { _storedProcMap = value; }
        }

        /// <summary>
        /// My current map file
        /// </summary>
        private string MyCurrentMapFile;


        #endregion

        #region Constructors
        //This constructor is private because this is a singleton
        /// <summary>
        /// Prevents a default instance of the <see cref="ORMapper{DestType}" /> class from being created.
        /// </summary>
        private ORMapper()
        {

        }

        //Again, this constructor is private....mapFile will be discovered by the Instance property
        /// <summary>
        /// Initializes a new instance of the <see cref="ORMapper{DestType}" /> class.
        /// </summary>
        /// <param name="mapFile">The map file.</param>
        private ORMapper(string mapFile)
        {
            MyCurrentMapFile = mapFile;
            XDocument mappings = XDocument.Load(mapFile);
            XNamespace ns = mappings.Root.Name.Namespace;
            bool MapFound = false;

            //check if a mapping for this type exists in the XML file
            //If it doesn't, then the automatic mapping will occur
            if (mappings.Descendants(ns + "ormap").Attributes("destination").Where(a => a.Value == typeof(DestType).FullName).Count() > 0)
            {
                MapFound = true;
                //This Xlinq magic queries the xml file and builds the dictionary mapping
                //source table columns to destination object properties
                _propertyMap = (from prop in mappings.Descendants(ns + "ormap").Elements(ns + "property")
                                where (prop.Parent.Attribute("destination").Value == typeof(DestType).FullName)
                                select new
                                {
                                    SourceColumn = prop.Attribute("source").Value,
                                    DestinationProperty = typeof(DestType).GetProperty(prop.Attribute("destination").Value)
                                }).ToDictionary((p => p.SourceColumn), (p => p.DestinationProperty));

                _embeddedPropertyMap = (from prop in mappings.Descendants(ns + "ormap").Elements(ns + "object_property")
                                        where (prop.Parent.Attribute("destination").Value == typeof(DestType).FullName)
                                        select new
                                        {
                                            DestinationProperty = typeof(DestType).GetProperty(prop.Attribute("destination").Value),
                                        }).ToDictionary((p => p.DestinationProperty), (p => p.DestinationProperty.PropertyType));

                _enumPropertyMap = (from prop in mappings.Descendants(ns + "ormap").Elements(ns + "enum_property")
                                    where (prop.Parent.Attribute("destination").Value == typeof(DestType).FullName)
                                    select new
                                    {
                                        Mapping = new KeyValuePair<string, PropertyInfo>(
                                            prop.Attribute("source").Value,
                                            typeof(DestType).GetProperty(prop.Attribute("destination").Value)
                                        ),
                                        EnumMapping = (from mapping in mappings.Descendants(ns + "ormap").Elements(ns + "enummap")
                                                       where (mapping.Parent.Attribute("destination").Value == typeof(DestType).GetProperty(prop.Attribute("destination").Value).PropertyType.FullName)
                                                       select new
                                                       {
                                                           SourceValue = mapping.Attribute("source").Value,
                                                           DestinationValue = mapping.Attribute("destination").Value
                                                       }).ToDictionary((k => k.SourceValue), (v => v.DestinationValue))
                                    }).ToDictionary((p => p.Mapping), (p => p.EnumMapping));

            }
            if (MapFound != true)
            {
                throw new MApNotFoundException(typeof(DestType).FullName);
            }

            getStoredProcsFromCurrentMap();
        }
        #endregion

        #region Singleton implementation

        //This is only used for locking the instance
        /// <summary>
        /// The _instance lock
        /// </summary>
        private static object _instanceLock = new object();

        /// <summary>
        /// The _instance
        /// </summary>
        private static ORMapper<DestType> _instance;

        /// <summary>
        /// Gets the instance.
        /// </summary>
        /// <value>The instance.</value>
        public static ORMapper<DestType> Instance
        {
            get
            {
                lock (_instanceLock)
                {
                    if (_instance == null)
                    {

                        string mapFile = string.Empty;

                        HSORMDataConfigSection configSection = (HSORMDataConfigSection)
                            ConfigurationManager.GetSection("hs.data.orm");

                        if (configSection != null)
                        {

                            MapFileElement mapFileElement = (from e in configSection.MapFiles.Cast<MapFileElement>()
                                                             where typeof(DestType).Namespace == e.Namespace
                                                             select e).FirstOrDefault();

                            if (mapFileElement != null)
                                mapFile = mapFileElement.MapFile;

                        }

                        if (!String.IsNullOrEmpty(mapFile))
                        {
                            //create the mapper using an xml file
                            string relativePath = "";
                            if (System.Web.HttpContext.Current != null)
                            {
                                relativePath = System.Web.HttpContext.Current.Server.MapPath("~") + "/";
                                _instance = new ORMapper<DestType>(relativePath + mapFile);
                            }
                            else
                            {
                                _instance = new ORMapper<DestType>(mapFile);
                            }
                        }
                        else
                        {
                            //create the mapper using direct column-to-property
                            var path = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location) + @"\" + mapFile;
                            _instance = new ORMapper<DestType>(mapFile);
                        }

                    }

                    return _instance;

                }
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Creates objects of type DestType from the data in source
        /// </summary>
        /// <param name="source">The DataTable to populate the list from</param>
        /// <returns>A list of newly-created objects of type DestType</returns>
        public List<DestType> Map(DataTable source)
        {
            return Map(source.Rows.Cast<DataRow>());
        }

        /// <summary>
        /// Creates objects of type DestType from the data in source
        /// </summary>
        /// <param name="rows">The rows.</param>
        /// <returns>A list of newly-created objects of type DestType</returns>
        public List<DestType> Map(IEnumerable<DataRow> rows)
        {
            List<DestType> results = new List<DestType>();
            foreach (DataRow dr in rows)
            {
                results.Add(Map(dr));
            }
            return results;
        }

        /// <summary>
        /// Creates objects of type DestType from the data in source
        /// </summary>
        /// <param name="reader">The reader.</param>
        /// <returns>A list of newly-created objects of type DestType</returns>
        public List<DestType> MapAll(IDataReader reader)
        {
            List<DestType> results = new List<DestType>();
            while (reader.Read())
            {
                results.Add(Map(reader));
            }
            return results;
        }

        /// <summary>
        /// Creates a single object based on one row of data
        /// </summary>
        /// <param name="source">The DataRow containing the source data</param>
        /// <returns>A single instance of DestType</returns>
        /// <exception cref="InvalidColumnException">
        /// </exception>
        /// <exception cref="TypeMismatchException"></exception>
        /// <exception cref="HS.Data.ORM.InvalidColumnException"></exception>
        public DestType Map(DataRow source)
        {
            if (_propertyMap == null)
            {
                BuildPropertyMap(source.Table.Columns);
            }

            DestType t = new DestType();

            //Add values to desintaion object
            foreach (string dc in _propertyMap.Keys)
            {
                //column checking occurs here because we don't have columns to check
                //against until Map is called with a real DataTable source
                if (!source.Table.Columns.Contains(dc))
                    throw new InvalidColumnException(dc);

                PropertyInfo pi = _propertyMap[dc];
                if (pi != null)
                {
                    object source_val = source[dc];

                    if (source_val != DBNull.Value)
                    {

                        if (pi.PropertyType != source_val.GetType())
                        {

                            if (pi.PropertyType.IsGenericType &&
                                pi.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) &&
                                pi.PropertyType.GetGenericArguments()[0].IsAssignableFrom(source_val.GetType()))
                            {
                                // Don't convert the value if we're putting a non-nullable value
                                // into a nullable property
                            }
                            else
                            {
                                //type checking is done here, because we don't know the column type until
                                //Map is called with a real DataTable as a source
                                try
                                {
                                    source_val = Convert.ChangeType(source_val, pi.PropertyType);
                                }
                                catch
                                {
                                    throw new TypeMismatchException();
                                }
                            }

                        }

                        pi.SetValue(t, source_val, null);

                    }
                }
            }

            //Add embedded objects to destination object
            foreach (PropertyInfo pi in _embeddedPropertyMap.Keys)
            {
                //have to use fancy .NET generics reflection support
                Type dest = _embeddedPropertyMap[pi];
                Type mapper = typeof(ORMapper<>).MakeGenericType(dest);

                //get the static ORMapper<type>.Instance
                object instance = mapper.GetProperty("Instance").GetValue(null, null);

                //call Map passing in the source datarow
                object result = mapper.GetMethod("Map", new Type[] { typeof(DataRow) }).Invoke(instance, new object[] { source });
                pi.SetValue(t, result, null);
            }

            //Convert enumerated properties from their database value to
            //thier mapped enumeration value.
            foreach (KeyValuePair<string, PropertyInfo> mapping in _enumPropertyMap.Keys)
            {

                //Get the source column name and the destination property info
                string columnName = mapping.Key;

                //column checking occurs here because we don't have columns to check
                //against until Map is called with a real DataTable source
                if (!source.Table.Columns.Contains(columnName))
                    throw new InvalidColumnException(columnName);

                PropertyInfo pi = mapping.Value;
                Type destType = pi.PropertyType;

                //Get the column value from the current row
                object source_val = source[columnName];

                //Get the dictionary that maps source values to destination values
                Dictionary<string, string> enumMapping = _enumPropertyMap[mapping];

                //Don't convert nulls
                if (source_val != DBNull.Value)
                {

                    string destination_val = string.Empty;

                    //Look up the name of the mapped enum value
                    if (enumMapping.TryGetValue(source_val.ToString(), out destination_val))
                    {
                        //Convert the name to an enum object and set the value of the
                        //property on the target object
                        pi.SetValue(t, Enum.Parse(destType, destination_val), null);
                    }

                }

            }

            return t;
        }

        /// <summary>
        /// Creates a single object based on one row of data
        /// </summary>
        /// <param name="source">The DataReader containing the source data</param>
        /// <returns>A single instance of DestType</returns>
        /// <exception cref="TypeMismatchException"></exception>
        /// <exception cref="InvalidColumnException">
        /// </exception>
        /// <exception cref="HS.Data.ORM.InvalidColumnException"></exception>
        public DestType Map(IDataReader source)
        {
            //source.Read();
            if (_propertyMap == null)
            {
                BuildPropertyMap(source);
            }

            DestType t = new DestType();

            var mapFound = false;

            //Add values to desintaion object
            foreach (string dc in _propertyMap.Keys)
            {

                //column checking occurs here because we don't have columns to check
                //against until Map is called with a real DataTable source
                try
                {

                    PropertyInfo pi = _propertyMap[dc];
                    if (pi != null)
                    {
                        mapFound = true;
                        object source_val = null;
                        try
                        {
                            source_val = source[dc];
                        }
                        catch (Exception ex)
                        {
                            //TODO: What do we do if if finds a maping exception
                            string x = ex.Message;
                            //Console.WriteLine("EXCEPTION");
                            //Console.WriteLine(ex.Message);
                            continue;
                        }

                        //Console.WriteLine(pi.Name + " : " + source_val.ToString());

                        if (source_val != DBNull.Value)
                        {

                            if (pi.PropertyType.IsGenericType &&
                                pi.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) &&
                                pi.PropertyType.GetGenericArguments()[0].IsAssignableFrom(source_val.GetType()))
                            {
                                // Don't convert the value if we're putting a non-nullable value
                                // into a nullable property
                            }
                            else
                            {
                                //type checking is done here, because we don't know the column type until
                                //Map is called with a real DataTable as a source
                                try
                                {
                                    if (pi.PropertyType.IsEnum == true)
                                    {
                                        object pType = pi.PropertyType.UnderlyingSystemType;
                                        source_val = Enum.ToObject(pi.PropertyType.UnderlyingSystemType, source_val);

                                    }
                                    else
                                    {

                                        source_val = Convert.ChangeType(source_val, pi.PropertyType);


                                    }
                                }
                                catch
                                {
                                    throw new TypeMismatchException();
                                }
                            }

                            pi.SetValue(t, source_val, null);

                        }
                    }

                }
                catch (IndexOutOfRangeException ex)
                {
                    string s = ex.Message;
                    throw new InvalidColumnException(dc);
                }

            }

            //Add embedded objects to destination object
            foreach (PropertyInfo pi in _embeddedPropertyMap.Keys)
            {
                mapFound = true;
                //have to use fancy .NET generics reflection support
                Type dest = _embeddedPropertyMap[pi];
                Type mapper = typeof(ORMapper<>).MakeGenericType(dest);

                //get the static ORMapper<type>.Instance
                object instance = mapper.GetProperty("Instance").GetValue(null, null);

                //call Map passing in the source datarow
                object result = mapper.GetMethod("Map", new Type[] { typeof(IDataReader) }).Invoke(instance, new object[] { source });
                pi.SetValue(t, result, null);
            }

            //Convert enumerated properties from their database value to
            //thier mapped enumeration value.
            foreach (KeyValuePair<string, PropertyInfo> mapping in _enumPropertyMap.Keys)
            {
                mapFound = true;

                //Get the source column name and the destination property info
                string columnName = mapping.Key;
                PropertyInfo pi = mapping.Value;
                Type destType = pi.PropertyType;

                //Get the column value from the current row
                object source_val = null;

                //column checking occurs here because we don't have columns to check
                //against until Map is called with a real DataTable source
                try
                {
                    source_val = source[columnName];
                }
                catch (IndexOutOfRangeException ex)
                {
                    string s = ex.Message;
                    throw new InvalidColumnException(columnName);
                }

                //Get the dictionary that maps source values to destination values
                Dictionary<string, string> enumMapping = _enumPropertyMap[mapping];

                //Don't convert nulls
                if (source_val != DBNull.Value)
                {

                    string destination_val = string.Empty;

                    //Look up the name of the mapped enum value
                    if (enumMapping.TryGetValue(source_val.ToString(), out destination_val))
                    {
                        //Convert the name to an enum object and set the value of the
                        //property on the target object
                        pi.SetValue(t, Enum.Parse(destType, destination_val), null);
                    }

                }

            }

            //if(mapFound != true)
            //{
            //    throw new MApNotFoundException("Insert name of Map here");
            //}
            return t;
        }

        /// <summary>
        /// Updates a DataRow based on a source object
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="destination">The destination.</param>
        /// <exception cref="InvalidColumnException"></exception>
        /// <exception cref="HS.Data.ORM.InvalidColumnException"></exception>
        public void MapBack(DestType source, DataRow destination)
        {

            if (_propertyMap == null)
            {
                BuildPropertyMap(destination.Table.Columns);
            }

            //Add values to desintaion object
            foreach (string dc in _propertyMap.Keys)
            {
                //column checking occurs here because we don't have columns to check
                //against until Map is called with a real DataTable source
                if (!destination.Table.Columns.Contains(dc))
                    throw new InvalidColumnException(dc);

                PropertyInfo pi = _propertyMap[dc];

                if (pi != null)
                {
                    object value = pi.GetValue(source, null);
                    if (value == null)
                        destination[dc] = DBNull.Value;
                    else
                        destination[dc] = value;
                }
            }

            //Add embedded objects to destination object
            foreach (PropertyInfo pi in _embeddedPropertyMap.Keys)
            {
                //have to use fancy .NET generics reflection support
                Type src = _embeddedPropertyMap[pi];
                Type mapper = typeof(ORMapper<>).MakeGenericType(src);

                //get the static ORMapper<type>.Instance
                object instance = mapper.GetProperty("Instance").GetValue(null, null);

                object objectSource = pi.GetValue(source, null);

                if (objectSource != null)
                {
                    //call MapBack passing in the source datarow
                    mapper.GetMethod("MapBack", new Type[] { src, typeof(DataRow) }).Invoke(instance, new object[] { objectSource, destination });
                }

            }

            //Convert enumerated properties back to thier corresponding database values.
            foreach (KeyValuePair<string, PropertyInfo> mapping in _enumPropertyMap.Keys)
            {

                //Get the source column name and the destination property info
                string columnName = mapping.Key;
                PropertyInfo pi = mapping.Value;
                Type destType = pi.PropertyType;

                //Get the column value from the current row
                string source_val = pi.GetValue(source, null).ToString();

                //Get the dictionary that maps source values to destination values
                Dictionary<string, string> enumMapping = _enumPropertyMap[mapping];

                foreach (KeyValuePair<string, string> item in enumMapping)
                {
                    if (item.Value == source_val)
                    {
                        destination[columnName] = item.Key;
                        break;
                    }
                }

            }

        }

        /// <summary>
        /// Builds a map of data columns to object properties by matching column name to property name
        /// </summary>
        /// <param name="source_cols">The columns to map</param>
        private void BuildPropertyMap(DataColumnCollection source_cols)
        {
            _propertyMap = new Dictionary<string, PropertyInfo>();
            _embeddedPropertyMap = new Dictionary<PropertyInfo, Type>();
            _enumPropertyMap = new Dictionary<KeyValuePair<string, PropertyInfo>, Dictionary<string, string>>();
            foreach (PropertyInfo pi in typeof(DestType).GetProperties())
            {
                //if this is a built-in type (from System.*), do a straight conversion
                if (pi.PropertyType.FullName.StartsWith("System"))
                {
                    if (source_cols.Contains(pi.Name))
                        _propertyMap.Add(pi.Name, pi);
                }
                else
                {
                    //try mapping an embedded type
                    _embeddedPropertyMap.Add(pi, pi.PropertyType);
                }
            }
        }

        /// <summary>
        /// Builds a map of data columns to object properties by matching column name to property name
        /// </summary>
        /// <param name="reader">The reader.</param>
        private void BuildPropertyMap(IDataReader reader)
        {
            DataTable schemaTable = reader.GetSchemaTable();
            _propertyMap = new Dictionary<string, PropertyInfo>();
            _embeddedPropertyMap = new Dictionary<PropertyInfo, Type>();
            _enumPropertyMap = new Dictionary<KeyValuePair<string, PropertyInfo>, Dictionary<string, string>>();
            foreach (PropertyInfo pi in typeof(DestType).GetProperties())
            {
                //if this is a built-in type (from System.*), do a straight conversion
                if (pi.PropertyType.FullName.StartsWith("System"))
                {
                    if ((from dr in schemaTable.AsEnumerable()
                         where dr.Field<string>("ColumnName") == pi.Name
                         select dr).FirstOrDefault() != null)
                        _propertyMap.Add(pi.Name, pi);
                }
                else
                {
                    //try mapping an embedded type
                    _embeddedPropertyMap.Add(pi, pi.PropertyType);
                }
            }
        }

        #endregion

        #region Stored Procedure Methods

        /// <summary>
        /// Gets the stored procs from current map.
        /// </summary>
        private void getStoredProcsFromCurrentMap()
        {
            // Clear the local stored procedure list
            _storedProcMap = new List<StoredProcedure>();

            //Load the document based on the Document name found during
            //instantiation
            XmlDocument doc = new XmlDocument();
            doc.Load(MyCurrentMapFile);
            XmlElement root = doc.DocumentElement;

            //Now find the XML nodes for the stored procs
            XmlNodeList procs = root.GetElementsByTagName("storedprocedure");

            // TODO: What to do about the "connection" attribute?
            //      Do we need it?

            //Loop through the collection
            foreach (XmlNode node in procs)
            {

                StoredProcedure storedProc = new StoredProcedure(
                    node.Attributes["friendly"].Value,
                    node.Attributes["actual"].Value
                    );
                try
                {

                    // Do we have children?
                    if ((node.ChildNodes == null) || (node.ChildNodes[0] == null))
                        continue;

                    //get the pointer to the parameters collection
                    XmlNodeList parms = node.ChildNodes;

                    //get the "property" nodes in this parameters collection
                    XmlNodeList props = parms[0].ChildNodes;

                    //load the parameters collection
                    storedProc.Parameters = getStoredProcParameters(props);
                }
                catch
                {
                    //We swallow the exception here on purpose because if there are no chile nodes on the 
                    //stored proc in the XML it will throw an un needed exception
                    //SMD 09/19/13
                }
                _storedProcMap.Add(storedProc);

            }

        }

        /// <summary>
        /// Gets StoredProcedureParameters from XmlNodeList.
        /// </summary>
        /// <param name="props">XmlNodeList containing the parameters information.</param>
        /// <returns>List of StoredProcedureParameters.</returns>
        private List<StoredProcedureParameter> getStoredProcParameters(XmlNodeList props)
        {

            List<StoredProcedureParameter> parms = new List<StoredProcedureParameter>();

            //loop through the properties
            foreach (XmlNode p in props)
            {

                StoredProcedureParameter spp = new StoredProcedureParameter();

                var pfr = p.Attributes["friendly"].Value;
                var pac = p.Attributes["actual"].Value;
                var pdir = p.Attributes["direction"].Value;

                spp.Actual = pac;
                spp.Direction = getParameterDirectionFromString(pdir);
                spp.Friendly = pfr;

                parms.Add(spp);

            }

            return parms;

        }

        /// <summary>
        /// Gets the parameter direction from string.
        /// </summary>
        /// <param name="direction">The direction/type of parameter.</param>
        /// <returns>System.Data.ParameterDirection.</returns>
        private ParameterDirection getParameterDirectionFromString(string direction)
        {

            switch (direction.ToLower())
            {

                case "Input": return ParameterDirection.Input;
                case "Output": return ParameterDirection.Output;
                case "ReturnValue": return ParameterDirection.ReturnValue;
                case "InputOutput": return ParameterDirection.InputOutput;

                default: return ParameterDirection.Input;

            }

        }

        #endregion

    }

}
