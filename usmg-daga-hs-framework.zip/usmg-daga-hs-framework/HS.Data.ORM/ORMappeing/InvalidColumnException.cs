﻿// ***********************************************************************
// Assembly         : HS.Data.ORM
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="InvalidColumnException.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;

/// <summary>
/// The ORM namespace.
/// </summary>
namespace HS.Data.ORM
{
    /// <summary>
    /// Class InvalidColumnException.
    /// </summary>
    public class InvalidColumnException : Exception
    {
        /// <summary>
        /// The _column
        /// </summary>
        private string _column;

        /// <summary>
        /// Initializes a new instance of the <see cref="InvalidColumnException"/> class.
        /// </summary>
        /// <param name="column">The column.</param>
        public InvalidColumnException(string column)
        {
            _column = column;
        }

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        /// <value>The message.</value>
        /// <returns>The error message that explains the reason for the exception, or an empty string("").</returns>
        public override string Message
        {
            get
            {
                return String.Format("Column '{0}' does not exist in DataTable", _column);
            }
        }
    }
}