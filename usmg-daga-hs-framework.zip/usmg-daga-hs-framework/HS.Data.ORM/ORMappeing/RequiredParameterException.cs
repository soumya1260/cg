﻿using System;

namespace HS.Data.ORM
{
    /// <summary>
    /// Class RequiredParameterException.
    /// </summary>
    public class RequiredParameterException : Exception
    {
        private string _parameterName;

        public RequiredParameterException(string ParameterName)
        {
            _parameterName = ParameterName;
        }

        public RequiredParameterException(string message, Exception inner)
            : base(message, inner)
        {

        }

        public override string Message
        {
            get
            {
                return String.Format("NULL is an invalid value for this parameter. The following parameter is required by SQL, but was not passed to the ORM: {0}", _parameterName);
            }
        }



    }
}
