using System;

namespace HS.Data.ORM
{
    public class MApNotFoundException : Exception
    {

        private string _mapName;

        public MApNotFoundException(string MapName)
        {
            _mapName = MapName;
        }

        public MApNotFoundException(string message, Exception inner)
            : base(message, inner)
        {

        }

        public override string Message
        {
            get
            {
                return String.Format("HS.Data.ORM was unable to find a matching OR Map for {0}", _mapName);
            }
        }


    }
}
