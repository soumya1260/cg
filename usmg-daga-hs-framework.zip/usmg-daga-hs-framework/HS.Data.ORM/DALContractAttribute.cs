﻿// ***********************************************************************
// Assembly         : HS.Data.ORM
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="DALContractAttribute.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;

/// <summary>
/// The ORM namespace.
/// </summary>
namespace HS.Data.ORM
{
    /// <summary>
    /// This attribute needs to be added to the interface
    /// for any DAL class to tell the framework where the
    /// default implementation is.
    /// </summary>
    [AttributeUsage(AttributeTargets.Interface)]
    public class DALContractAttribute : Attribute
    {

        /// <summary>
        /// The class that provides the default implementation
        /// of the DAL interface.
        /// </summary>
        /// <value>The default type.</value>
        public Type DefaultType { get; set; }

        /// <summary>
        /// The class that provides the mock implementation
        /// of the DAL interface.
        /// </summary>
        /// <value>The type of the mock.</value>
        public Type MockType { get; set; }

    }
}
