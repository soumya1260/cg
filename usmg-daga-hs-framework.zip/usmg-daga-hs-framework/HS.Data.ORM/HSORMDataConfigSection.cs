﻿//**********************************************************************
// Assembly         : HS.Data.ORM
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="HSORMDataConfigSection.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.Configuration;

/// <summary>
/// The ORM namespace.
/// </summary>
namespace HS.Data.ORM
{
    /// <summary>
    /// Class HSORMDataConfigSection.
    /// </summary>
    public class HSORMDataConfigSection : ConfigurationSection
    {

        /// <summary>
        /// Gets or sets a value indicating whether [use mock data].
        /// </summary>
        /// <value><c>true</c> if [use mock data]; otherwise, <c>false</c>.</value>
        [ConfigurationProperty("useMockData", DefaultValue = "false", IsRequired = false)]
        public bool UseMockData
        {
            get
            {
                return (bool)this["useMockData"];
            }
            set
            {
                this["useMockData"] = value;
            }
        }

        /// <summary>
        /// Gets the map files.
        /// </summary>
        /// <value>The map files.</value>
        [ConfigurationProperty("dataMap")]
        public MapFileCollection MapFiles
        {
            get { return ((MapFileCollection)(base["dataMap"])); }
        }

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>The current.</value>
        public static HSORMDataConfigSection Current
        {
            get
            {
                return ConfigurationManager.GetSection("SMD.data") as HSORMDataConfigSection;
            }
        }

    }

    /// <summary>
    /// Class MapFileCollection.
    /// </summary>
    [ConfigurationCollection(typeof(MapFileElement))]
    public class MapFileCollection : ConfigurationElementCollection
    {

        /// <summary>
        /// When overridden in a derived class, creates a new <see cref="T:System.Configuration.ConfigurationElement" />.
        /// </summary>
        /// <returns>A new <see cref="T:System.Configuration.ConfigurationElement" />.</returns>
        protected override ConfigurationElement CreateNewElement()
        {
            return new MapFileElement();
        }

        /// <summary>
        /// Gets the element key for a specified configuration element when overridden in a derived class.
        /// </summary>
        /// <param name="element">The <see cref="T:System.Configuration.ConfigurationElement" /> to return the key for.</param>
        /// <returns>An <see cref="T:System.Object" /> that acts as the key for the specified <see cref="T:System.Configuration.ConfigurationElement" />.</returns>
        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((MapFileElement)element).Namespace;
        }

        /// <summary>
        /// Gets the <see cref="MapFileElement"/> at the specified index.
        /// </summary>
        /// <param name="index">The index.</param>
        /// <returns>MapFileElement.</returns>
        public MapFileElement this[int index]
        {
            get { return (MapFileElement)this.BaseGet(index); }
        }

    }


    /// <summary>
    /// Class MapFileElement.
    /// </summary>
    public class MapFileElement : ConfigurationElement
    {

        /// <summary>
        /// Gets or sets the namespace.
        /// </summary>
        /// <value>The namespace.</value>
        [ConfigurationProperty("namespace", IsKey = true, IsRequired = true)]
        public string Namespace
        {
            get { return (string)base["namespace"]; }
            set { base["namespace"] = value; }
        }

        /// <summary>
        /// Gets or sets the map file.
        /// </summary>
        /// <value>The map file.</value>
        [ConfigurationProperty("mapFile", IsKey = false, IsRequired = true)]
        public string MapFile
        {
            get { return (string)base["mapFile"]; }
            set { base["mapFile"] = value; }
        }

    }

}
