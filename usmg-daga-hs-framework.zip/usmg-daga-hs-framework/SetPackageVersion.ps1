﻿#
# Extract the proposed version number from VersionInfo.cs
#
$build = $ENV:BUILD_ID;
$version = (Select-String -Path VersionInfo.cs 'AssemblyVersion\("(\d+\.\d+\.\d+)' -AllMatches | ForEach-Object {$_.Matches} | ForEach-Object {$_.Groups[1].Value})
$version = "$version.$build";

#
# Update the version fields in each project file
# 
Get-ChildItem -Recurse -Path . -Filter *.csproj | ForEach-Object {
    $fileName = $_.FullName;
    (Get-Content $fileName) -replace "<PackageVersion>.*</PackageVersion>", "<PackageVersion>$version</PackageVersion>" | Out-File $fileName;
    (Get-Content $fileName) -replace "<AssemblyVersion>.*</AssemblyVersion>", "<AssemblyVersion>$version</AssemblyVersion>" | Out-File $fileName;
    (Get-Content $fileName) -replace "<FileVersion>.*</FileVersion>", "<FileVersion>$version</FileVersion>" | Out-File $fileName;
}

#
# Update the VersionInfo file itself in the root folder.
#
Get-ChildItem -Path . -Filter VersionInfo.cs | ForEach-Object {
    $fileName = $_.FullName;
    (Get-Content $fileName) -replace "AssemblyVersion\(.*\)", "AssemblyVersion($version)" | Out-File $fileName;
    (Get-Content $fileName) -replace "AssemblyFileVersion\(.*\)", "AssemblyFileVersion($version)" | Out-File $fileName;
}
