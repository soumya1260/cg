﻿using System;
using System.Collections.Generic;
using System.IO;

namespace HS.Data.ORM.Logging
{

    public static class LoggingData
    {
        public static LoggingRule GetApplicationRule(int ApplicationID, int ExceptionType)
        {
            var ret = new LoggingRule();
            try
            {
                // Create new Exception Rule object

                using (var dw = new ORMWrapper("LOGDB", true))
                {
                    try
                    {
                        // Store Params to pass to ORM
                        var param = new List<ParamItem>();

                        param.Add(new ParamItem("AppID", ApplicationID));
                        param.Add(new ParamItem("ExceptionTypeID", ExceptionType));

                        // Map DB results to ExceptionRule object
                        List<LoggingRule> tmp = (List<LoggingRule>)dw.MapListFromDataReader<LoggingRule>(param,
                                "GetAppRule");
                        ret = tmp[0];

                        return ret;
                    }
                    finally
                    {
                        dw.Dispose();
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            return ret;
        }


        public static int WriteLogMessageToDB(LogObject LogMessage, int ApplicationID)
        {
            int response = -1;
            try
            {
                using (var dw = new ORMWrapper("LOGDB", true))
                {
                    try
                    {
                        // Store Params to pass to ORM
                        var param = new List<ParamItem>();
                        var Inner = -1;
                        var except = -1;
                        if (LogMessage.IsInnerException == true)
                        {
                            Inner = 1;
                        }
                        else
                        {
                            Inner = 0;
                        }
                        if (LogMessage.ContainsException == true)
                        {
                            except = 1;
                        }
                        else
                        {
                            except = 0;
                        }

                        //Get the application Name if it exists, if it fdoes not...add it and send new application registration email



                        param.Add(new ParamItem("LogID", LogMessage.OriginalMessageID));
                        param.Add(new ParamItem("IsInner", Inner));
                        param.Add(new ParamItem("SenderApp", ApplicationID));
                        param.Add(new ParamItem("MessageType", (int)LogMessage.MessageType));
                        param.Add(new ParamItem("Message", LogMessage.Message));
                        param.Add(new ParamItem("Title", LogMessage.MessageTitle));
                        param.Add(new ParamItem("ExceptionMsg", LogMessage.ExceptionMessage));
                        param.Add(new ParamItem("ExceptionSource", LogMessage.ExceptionSource));
                        param.Add(new ParamItem("StackTrace", LogMessage.ExceptionStackTrace));
                        param.Add(new ParamItem("IsException", except));
                        param.Add(new ParamItem("From", LogMessage.MessageSentFrom));
                        param.Add(new ParamItem("PromotionEnvironment", LogMessage.PromotionEnvironment));
                        param.Add(new ParamItem("ExceptionType", LogMessage.ExceptionType));
                        var currentDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);

                        // Store Exception to DB
                        List<LogEntryID> tmp = (List<LogEntryID>)dw.MapListFromDataReader<LogEntryID>(param,
                            "WriteExceptionToDB");
                        response = tmp[0].ID;

                        // If Addtional Messages exist then store them in DB
                        if (LogMessage.AdditionalMessages.Count > 0)
                        {

                            foreach (string s in LogMessage.AdditionalMessages)
                            {
                                // Store Params to pass to ORM
                                var mParm = new List<ParamItem>();
                                mParm.Add(new ParamItem("LogID", tmp[0].ID));
                                mParm.Add(new ParamItem("Message", s));

                                // Store Addtional Massages for this Exception in DB
                                dw.InsertToDatabase<LogEntryID>(mParm, "WriteMessages");
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        dw.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return response;
        }


        public static LogObjectEmailAddress PopulateDefaultEmailAddressInfo()
        {
            LogObjectEmailAddress ret = new LogObjectEmailAddress();


            //The default email addresses can be configured in the
            //Logger config block for when the DB cant be reached.
            //If they have not been set and the DB still cant be reached,
            //the config will return the default values coded in the
            //HSLoggingConfiguration in HS.Core

            //First - attemtp to get the "New Application Not Configured Defaults" from the database

            var sei = GetSystemEmailInfo("New Application Not Configured Defaults");

            if (sei != null)
            {
                ret.DestinationEmail = sei.SendMessageTo;
                ret.FromEmail = sei.SendMessageFrom;
                ret.SubjectLine = sei.MessageTitle;
            }
            else
            {
                HSLoggingConfiguration config =
                   HSLoggingConfiguration.Current;
                ret.DestinationEmail = config.DefaultToEmail;
                ret.FromEmail = config.DefaultFromEmail;
                ret.SubjectLine = "Exception Occurred : ";
            }
            return ret;
        }

        public static ExceptionType GetExceptionType(string ExceptionTypeName)
        {

            try
            {
                // Create new Exception Rule object
                ExceptionType ret = new ExceptionType();
                using (var dw = new ORMWrapper("LOGDB", true))
                {
                    try
                    {
                        // Store Params to pass to ORM
                        var param = new List<ParamItem>();

                        param.Add(new ParamItem("TypeName", ExceptionTypeName));

                        // Map DB results to ExceptionRule object
                        List<ExceptionType> tmp = (List<ExceptionType>)dw.MapListFromDataReader<ExceptionType>(param,
                                "GetExceptionType");
                        ret = tmp[0];

                        return ret;
                    }
                    finally
                    {
                        dw.Dispose();
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static RegisteredApplication GetApplication(string ApplicationName)
        {

            try
            {
                // Create new Exception Rule object
                RegisteredApplication ret = new RegisteredApplication();
                using (var dw = new ORMWrapper("LOGDB", true))
                {
                    try
                    {
                        // Store Params to pass to ORM
                        var param = new List<ParamItem>();

                        param.Add(new ParamItem("AppName", ApplicationName));

                        // Map DB results to ExceptionRule object
                        List<RegisteredApplication> tmp = (List<RegisteredApplication>)dw.MapListFromDataReader<RegisteredApplication>(param,
                                "GetAppID");
                        ret = tmp[0];

                        return ret;
                    }
                    finally
                    {
                        dw.Dispose();
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static SystemEmail GetSystemEmailInfo(string SystemEmailType)
        {

            try
            {
                // Create new Exception Rule object
                SystemEmail ret = new SystemEmail();
                using (var dw = new ORMWrapper("LOGDB", true))
                {
                    try
                    {
                        // Store Params to pass to ORM
                        var param = new List<ParamItem>();

                        param.Add(new ParamItem("SystemMessageType", SystemEmailType));

                        // Map DB results to ExceptionRule object
                        List<SystemEmail> tmp = (List<SystemEmail>)dw.MapListFromDataReader<SystemEmail>(param,
                                "GetSystemEmail");
                        ret = tmp[0];
                        return ret;


                    }
                    finally
                    {
                        dw.Dispose();
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

    }

    public class RegisteredApplication
    {
        public int ApplicationID { get; set; }
        public string ApplicationName { get; set; }
        public bool IgnoreAll { get; set; }
        public bool ContainsRules { get; set; }
        public bool RunOnlyMainRule { get; set; }
        public bool IsConfigured { get; set; }
        public string FromEmailAddress { get; set; }
        public string ToEmailAddress { get; set; }
        public string MessageSubject { get; set; }
        public string InsertedBy { get; set; }
        public DateTime InsertedOn { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedOn { get; set; }
        public bool IsNew { get; set; }
        public bool SendMissingRules { get; set; }
        public string NonExceptionFrom { get; set; }
        public string NonExceptionTo { get; set; }
        public string NonExceptionSubject { get; set; }
        public bool SendNonExceptionEmails { get; set; }

        public List<LoggingRule> Rules { get; set; }

    }


    public class LogEntryID
    {
        public int ID { get; set; }
    }
    public class LogApplicationID
    {
        public int ID { get; set; }
        public int IsNew { get; set; }
    }
    public class LogObjectEmailAddress
    {
        public string DestinationEmail { get; set; }
        public string FromEmail { get; set; }
        public string SubjectLine { get; set; }
        public bool RetrievedFromDatabase { get; set; }
    }
    public class SystemEmail
    {
        public string MessageType { get; set; }
        public string SendMessageFrom { get; set; }
        public string SendMessageTo { get; set; }
        public string MessageTitle { get; set; }
        public string MessageBody { get; set; }

    }


    public class ExceptionType
    {
        public int ExceptionTypeID { get; set; }
        public string ExceptionTypeName { get; set; }
    }

    public class LoggingRule
    {
        public int RuleID { get; set; }
        public int ApplicationID { get; set; }
        public ExceptionType ExceptionType { get; set; }

        public bool LogAndIgnoreEmail { get; set; }
        public int ExceptionCountThreshold { get; set; }
        public int ExceptionTimeThreshold { get; set; } //In Minutes
        public bool SendInterimEmails { get; set; }
        public string InterimFrom { get; set; }
        public string InterimTo { get; set; }
        public string InterimSubject { get; set; }
        public string ThresholdFrom { get; set; }
        public string ThresholdTo { get; set; }
        public string TheresholdSubject { get; set; }

        public int CurrentCountWithinTimeFrame { get; set; }


    }
}

