﻿using System;
using System.Collections.Generic;
using HS.Data.ORM.Logging;
using HS.HSEmailService;
using System.Configuration;

namespace HS.Services.Logging
{
    public class LogService : ILogInterface
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public WriteMessageToLogResponse WriteMessageToLog(WriteToLogRequest request)
        {
            //Todo: This could be a good place to get Env and App Ids
            WriteMessageToLogResponse response = new WriteMessageToLogResponse();
            try
            {

                if (request.LogMessage.AdditionalMessages == null)
                {
                    request.LogMessage.AdditionalMessages = new List<string>();
                }

                //Get the App ID from the Database and determine if a new application registration email is required
                var App = LoggingData.GetApplication(request.LogMessage.SendingApplication);
                Console.WriteLine("Logging or Application " + App.ApplicationName);

                if (App.IsNew == true)
                {
                    Console.WriteLine("This is a new Appp");

                    //This is a new application. The prod support team needs to be notified. 
                    //Go get the correct System Email information fromt he database for a new app
                    var sysMail = LoggingData.GetSystemEmailInfo("New Application Registration");
                    SendEmailRequest r = new SendEmailRequest();
                    Email eMail = new Email();
                    eMail.isHTML = true;
                    eMail.From = sysMail.SendMessageFrom;
                    eMail.To = sysMail.SendMessageTo;

                    eMail.Subject = request.LogMessage.SendingApplication + " - " + sysMail.MessageTitle;
                    //Get the App ID


                    var url = ConfigurationManager.AppSettings.Get("LoggerAdminURL");
                    string tmp = "<br><br>Click <a href =\"http:\\\\" + url + "\\Application.aspx?ID=" + App.ApplicationID + "\"Here</a> to Register the Application";

                    eMail.Body = request.LogMessage.SendingApplication + " - " + sysMail.MessageBody + tmp; ;

                    EmailIntegration.SendEmailNotification(eMail);
                    Console.WriteLine("Sent new app registration email");
                    //So if this is a new applicaiton then we wont find rules for it. We need to just build the email 
                    //and send to the system defaults. The Process Log Message function should handle this

                }

                //Now...Write the message to the DB....
                Console.WriteLine("Getting ready to write exception to db");
                response.OriginalExceptionID = LoggingData.WriteLogMessageToDB(request.LogMessage, App.ApplicationID);

                request.LogMessage.OriginalMessageID = response.OriginalExceptionID;

                // Now process the log message via the rules engine - but ONLY for exceptions
                Console.WriteLine("Calling rules engine");

                if (request.LogMessage.MessageType == MessageTypeEnum.Exception)
                {
                    LogRulesEngine.ProcessLogMessage(request, App);
                }
                else
                {
                    ProcessNonExceptionMessage(request, App);
                }



                response.Result = ResponseResult.Success;
            }
            catch (Exception ex)
            {
                //Make sure the mail still gets sent
                LogRulesEngine.ProcessLogMessage(request, new RegisteredApplication());
                StaticHelperFunctions.HandleLoggerException(ex);

                response.Error(ex);
            }

            return response;
        }

        private void ProcessNonExceptionMessage(WriteToLogRequest req, RegisteredApplication App)
        {
            if (App.SendNonExceptionEmails == false)
            {
                return;
            }

            Email eMail = new Email();
            eMail.isHTML = true;


            eMail.From = App.NonExceptionFrom;
            eMail.To = App.NonExceptionTo;
            eMail.Subject = App.NonExceptionSubject;
            eMail.Body = EmailFormat.FormatInformationalEmailBody(req);

            EmailIntegration.SendEmailNotification(eMail);
        }


        /// <summary>
        /// Allows consumer to send an email
        /// </summary>
        /// <param name="request">SendEmailRequest - properly populatesd email request item</param>
        /// <returns></returns>
        public SendEmailResponse SendEmail(SendEmailRequest request)
        {
            SendEmailResponse response = new SendEmailResponse();
            try
            {
                // Send Email Through Email Service
                if (EmailIntegration.SendEmailNotification(request.Item).Result == ResponseResult.Success)
                {
                    response.Result = ResponseResult.Success;
                }
                else
                {
                    response.Result = ResponseResult.Failure;
                }
            }
            catch (Exception ex)
            {
                // Log Exception to Event Log
                StaticHelperFunctions.HandleLoggerException(ex);
                response.Error(ex);
            }

            return response;
        }

    }
}
