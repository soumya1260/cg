﻿using System;
using HS.HSEmailService;

namespace HS.Services.Logging
{
    public static class EmailIntegration
    {
        internal static HSResponse SendEmailNotification(Email item)
        {
            HSResponse response = new HSResponse();
            try
            {
                 //Send Exception or Log Message Email
                HSEmailServiceFacade.SendEmail(item);

            }
            catch (Exception ex)
            {

                // Write Exception to Event Log
                StaticHelperFunctions.HandleLoggerException(ex);
                response.Error(ex);
            }
            return response;
        }

        #region Depricated
        //public static string FormatEmailBodyForException(WriteToLogRequest req)
        //{
        //    StringBuilder msg = new StringBuilder();

        //    switch (req.LogMessage.MessageType)
        //    {
        //        case MessageTypeEnum.Exception:
        //            return FormatExceptionEmailBody(req);

        //        case MessageTypeEnum.Informational:
        //            return FormatInformationalEmailBody(req);

        //        case MessageTypeEnum.SecurityMessage:
        //        //TBD
        //        case MessageTypeEnum.Verbose:
        //        //TBD
        //        case MessageTypeEnum.Debug:
        //        //TBD
        //        //Assume a default of Exception
        //        default:
        //            return FormatExceptionEmailBody(req);
        //            break;


        //    }

        //    return msg.ToString();
        //}

        //public static string FormatExceptionEmailBody(WriteToLogRequest req)
        //{
        //    StringWriter sw = new StringWriter();
        //    sw.WriteLine("<div style='font-family:calibri,tahoma,arial;'><table cellpadding='2'>");

        //    string formatString = "";

        //    formatString = "<tr><td>{0}:</td><td style='color:#222222; font-size:0.9em;'>{1}</td></tr>";

        //    //sw.WriteLine(FormatEnvironmentInfo(req));
        //    sw.WriteLine(string.Format(formatString, "Application Name", req.LogMessage.SendingApplication));
        //    sw.WriteLine(string.Format(formatString, "Server", req.LogMessage.MessageSentFrom));
        //    sw.WriteLine(string.Format(formatString, "Message Type", req.LogMessage.MessageType.ToString()));
        //    sw.WriteLine(string.Format(formatString, "Promotion Environment", req.LogMessage.PromotionEnvironment));

        //    sw.WriteLine(string.Format(formatString, "Message", req.LogMessage.Message));

        //    sw.WriteLine(string.Format(formatString, "NOTES:", ""));

        //    if (req.LogMessage.AdditionalMessages == null && req.LogMessage.AdditionalMessages.Count > 0)
        //    {
        //        foreach (string note in req.LogMessage.AdditionalMessages)
        //        {
        //            sw.WriteLine(string.Format(formatString, "Exception", "Note", note));
        //        }
        //    }

        //    if (req.LogMessage.ExceptionStackTrace != null)
        //    {
        //        sw.WriteLine(string.Format(formatString, "Stack Trace", req.LogMessage.ExceptionStackTrace.ToString()));
        //    }
            

        //    sw.WriteLine("See Database Exception Log for more details.....");

        //    sw.WriteLine("</table></div>");
        //    string retString = sw.ToString();
        //    return retString;
        //}

        //public static string FormatInformationalEmailBody(WriteToLogRequest req)
        //{
        //    StringWriter sw = new StringWriter();
        //    sw.WriteLine("<div style='font-family:calibri,tahoma,arial;'><table cellpadding='2'>");

        //    string formatString = "";

        //    formatString = "<tr><td>{0}:</td><td style='color:#222222; font-size:0.9em;'>{1}</td></tr>";

        //    //sw.WriteLine(FormatEnvironmentInfo(req));
        //    sw.WriteLine(string.Format(formatString, "Application Name", req.LogMessage.SendingApplication));
        //    sw.WriteLine(string.Format(formatString, "Server", req.LogMessage.MessageSentFrom));
        //    sw.WriteLine(string.Format(formatString, "Message Type", req.LogMessage.MessageType.ToString()));
        //    sw.WriteLine(string.Format(formatString, "Promotion Environment", req.LogMessage.PromotionEnvironment));

        //    sw.WriteLine(string.Format(formatString, "Message", req.LogMessage.Message));

        //    sw.WriteLine(string.Format(formatString, "NOTES:", ""));

        //    if (req.LogMessage.AdditionalMessages == null && req.LogMessage.AdditionalMessages.Count > 0)
        //    {
        //        foreach (string note in req.LogMessage.AdditionalMessages)
        //        {
        //            sw.WriteLine(string.Format(formatString, "Note", note));
        //        }
        //    }

        //    //sw.WriteLine("See Database Exception Log for more details.....");

        //    sw.WriteLine("</table></div>");
        //    string retString = sw.ToString();
        //    return retString;
        //}
        //private static string FormatEnvironmentInfo(WriteToLogRequest req)
        //{
        //    StringWriter sw = new StringWriter();

        //    string formatString = "";

        //    formatString = "<tr><td>{0}:</td><td style='color:#222222; font-size:0.9em;'>{1}</td></tr>"; 

        //    sw.WriteLine(string.Format(formatString, "Application Name", req.LogMessage.SendingApplication));
        //    sw.WriteLine(string.Format(formatString, "Server", req.LogMessage.MessageSentFrom));
        //    sw.WriteLine(string.Format(formatString, "Message Type", req.LogMessage.MessageType.ToString()));
        //    sw.WriteLine(string.Format(formatString, "Promotion Environment", req.LogMessage.PromotionEnvironment));


        //    return sw.ToString();
        //}
        #endregion
    }
   
}
