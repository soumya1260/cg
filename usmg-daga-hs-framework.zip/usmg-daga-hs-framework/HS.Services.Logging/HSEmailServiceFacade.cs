﻿using System;
using System.ServiceModel;
using System.Xml;
using HS.HSEmailService;

namespace HS.Services.Logging
{

    public class HSEmailServiceFacade
    {
        public static T UseEmailServiceClient<T>(Func<HSEmailServiceClient, T> callback)
        {
            HSEmailServiceClient client = null;
            try
            {
                string emailServiceAddress = HSLoggingConfiguration.Current.EmailServiceEndpointAddress;

                EndpointAddress endpointAddress = new EndpointAddress(emailServiceAddress);

                BasicHttpBinding binding = new BasicHttpBinding() { MaxBufferPoolSize = 52428800, MaxBufferSize = 6553600, MaxReceivedMessageSize = 6553600 };

                XmlDictionaryReaderQuotas mReaderQuotas = new XmlDictionaryReaderQuotas()
                {
                    MaxStringContentLength = 8192000,
                    MaxArrayLength = 16384,
                    MaxBytesPerRead = 4096,
                    MaxDepth = 32,
                    MaxNameTableCharCount = 16384
                };

                binding.ReaderQuotas = mReaderQuotas;

                client = new HSEmailServiceClient(binding, endpointAddress);
                //client.SetClientSecurity();
                return callback(client);
            }
            catch (Exception ex)
            {
                if (client != null)
                    client.Abort();
                throw;
            }
            finally
            {
                if (client != null)
                    client.Close();
            }
        }

        public static bool SendEmail(Email email)
        {
            bool mailSent = false;
            return UseEmailServiceClient(
                client =>
                {
                    try
                    {
                        client.Open();
                        mailSent = client.sendEmail(email);
                        return mailSent;
                    }
                    catch (Exception ex)
                    {
                        HS.Log.LogException(ex);
                        return false;
                    }

                });
        }
    }

}
