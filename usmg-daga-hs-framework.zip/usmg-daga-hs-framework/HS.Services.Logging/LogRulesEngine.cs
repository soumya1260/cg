﻿using System;
using System.Collections.Generic;
using HS.Data.ORM.Logging;
using HS.HSEmailService;
using HS.Data.ORM;

namespace HS.Services.Logging
{
    internal static class LogRulesEngine
    {

        internal static void SendMissingRulesNotification(string AppName, string ExceptionType, int LogEntryID)
        {
            var SysMail = LoggingData.GetSystemEmailInfo("Missing Rules Notification");
            SendEmailRequest r = new SendEmailRequest();
            Email se = new Email();
            se.isHTML = true;
            se.From = SysMail.SendMessageFrom;
            se.To = SysMail.SendMessageTo;

            se.Subject = SysMail.MessageTitle + " " + AppName;
            //se.Body = AppName + " : " + ExceptionType + " - " + SysMail.MessageBody;
            se.Body = EmailFormat.FormatMissingRulesEmail(AppName, ExceptionType, SysMail.MessageBody, LogEntryID);




            EmailIntegration.SendEmailNotification(se);
        }

        internal static void ProcessLogMessage(WriteToLogRequest req, RegisteredApplication App)
        {
            LogObjectEmailAddress loea = new LogObjectEmailAddress();
            SystemEmail SysMail = new SystemEmail();
            Email eMail = new Email();
            eMail.isHTML = true;

            if (req.LogMessage.AdditionalMessages == null)
            {
                req.LogMessage.AdditionalMessages = new List<string>();
            }

            try
            {

                var eType = LoggingData.GetExceptionType(req.LogMessage.ExceptionType);
                Console.WriteLine("Get Exception type of " + eType.ExceptionTypeID + " " + eType.ExceptionTypeName);



                //First, check and see if the app is configured... So go get the top level app rules

                if (App.IsNew == true || App.IsConfigured == false)
                {
                    Console.WriteLine("The app is new so send email to system defaults");
                    //The application is new or not configured so this means 
                    //send it to the system default email info which is in either the config, or if that not set,
                    //as defined in the attribute default in LoggingConfiguration as part of HS.Core
                    loea = LoggingData.PopulateDefaultEmailAddressInfo();
                    eMail.From = loea.FromEmail;
                    eMail.To = loea.DestinationEmail;
                    eMail.Subject = loea.SubjectLine;
                }

                if (App.IsNew == false && App.IsConfigured == false)
                {
                    Console.WriteLine("the ap is NOT new, but there are no rules configured so notify prod support");

                    //This is not a new app and it has not been configured. 
                    //send the missing rules esception to
                    //prod support.
                    //This is a new application. The prod support team needs to be notified. 

                    //Go get the correct System Email information from the database for Missing Rules
                    // SendMissingRulesNotification(App.ApplicationName, req.LogMessage.ExceptionType.ToString());



                    //Now use the system defaults for the email from to and subject
                    loea = LoggingData.PopulateDefaultEmailAddressInfo();
                    eMail.From = loea.FromEmail;
                    eMail.To = loea.DestinationEmail;
                    eMail.Subject = loea.SubjectLine;

                    //Now allow the rest of the email formatter to run

                }
                if (App.IsConfigured == true)
                {
                    Console.WriteLine("The app IS configured");
                    //Ok, so the app has been at least configured.

                    //Has it been set to globally ignore and not send emails
                    if (App.IgnoreAll == true)
                    {

                        Console.WriteLine("The app is set to ignore all emails");
                        //The app has been set to ignore all exceptions. We have already logged it in the database
                        //so no further action is required and no email will be sent. Return fromt his method
                        return;
                    }
                    if (App.RunOnlyMainRule == true || App.ContainsRules == false)
                    {//the app is set to only send messages to the top level rule
                        Console.WriteLine("The app has no detail rules or is configured to use the main rule only");
                        eMail.From = App.FromEmailAddress;
                        eMail.To = App.ToEmailAddress;
                        eMail.Subject = App.MessageSubject;

                    }

                    //now the tough one... detail rules
                    if (App.RunOnlyMainRule == false && App.ContainsRules == true)
                    {
                        Console.WriteLine("The app contains rules, and we are getting them form the DB");
                        LoggingRule ThisRule = new LoggingRule();
                        try
                        {
                            ThisRule = LoggingData.GetApplicationRule(App.ApplicationID, eType.ExceptionTypeID);
                        }
                        catch (Exception EX)
                        {
                            //Either the rule wasnt found for the exception type OR....
                            //their was an error..  Fall back to the default information for the app.


                            eMail.From = App.FromEmailAddress;// loea.FromEmail;
                            eMail.To = App.ToEmailAddress;// loea.DestinationEmail;
                            eMail.Subject = App.MessageSubject;// loea.SubjectLine;
                            ThisRule.ThresholdFrom = App.FromEmailAddress;
                            ThisRule.ThresholdTo = App.ToEmailAddress;
                            ThisRule.TheresholdSubject = App.MessageSubject;
                            //do no send missing rules emails if the app is marked not to do so

                            if (App.SendMissingRules == true)
                            {
                                SendMissingRulesNotification(App.ApplicationName, req.LogMessage.ExceptionType.ToString(), req.LogMessage.OriginalMessageID);
                            }

                        }
                        //First, is there an amaglamation rule on it? If the ExceptionThresholdTime is
                        //greater than zero then there is an amalgamation rule
                        if (ThisRule.ExceptionTimeThreshold <= 0)
                        {
                            Console.WriteLine("There are no amalgamation rules for this exception type");
                            //There is no amalgamation rule so always send the email
                            eMail.From = ThisRule.ThresholdFrom;
                            eMail.To = ThisRule.ThresholdTo;

                            eMail.Subject = String.Format("{0} {1}- Log Entry ID : {2}",
                                ThisRule.TheresholdSubject, req.LogMessage.SendingApplication,
                                req.LogMessage.OriginalMessageID);
                        }
                        else
                        {
                            //check and see if the time/count threshold was exceed

                            if (ThisRule.CurrentCountWithinTimeFrame > ThisRule.ExceptionCountThreshold)
                            {
                                Console.WriteLine("Amalgamation rule threshold reached");
                                //We have exceed the rule almagamation threshold... send the email
                                eMail.From = ThisRule.ThresholdFrom;
                                eMail.To = ThisRule.ThresholdTo;

                                eMail.Subject = String.Format("{0} {1}- Log Entry ID : {2}",
                                    ThisRule.TheresholdSubject, req.LogMessage.SendingApplication,
                                    req.LogMessage.OriginalMessageID);
                            }
                            else
                            {
                                Console.WriteLine("Sending interim email");
                                //We have not exceeded the rule amalgamation threshold

                                //Do they want interim emails to a different address?
                                if (ThisRule.SendInterimEmails == true)
                                {
                                    eMail.From = ThisRule.InterimFrom;
                                    eMail.To = ThisRule.InterimTo;

                                    eMail.Subject = String.Format("{0} {1}- Log Entry ID : {2}",
                                        ThisRule.InterimSubject, req.LogMessage.SendingApplication,
                                        req.LogMessage.OriginalMessageID);
                                }
                                else
                                {
                                    //We have not exceeded the configured threeshold and they dont want interim emails
                                    //so there is no email to send at this point, so return;

                                    return;
                                }
                            }

                            req.LogMessage.AdditionalMessages.Add(
                                "SPECIAL NOTE!! : This exception has occurred " + ThisRule.CurrentCountWithinTimeFrame +
                                " times in the last " + ThisRule.ExceptionTimeThreshold + " Minutes....");




                        }
                    }




                }

                //TODO:
                //Move email formatter to service code.
                eMail.Body = EmailFormat.FormatEmailBodyForException(req, true);

                #region Depricated



                #endregion
            }
            catch (MApNotFoundException mex)
            {


                HSLoggingConfiguration cfg =
                           HSLoggingConfiguration.Current;
                var tmp = LoggingData.GetSystemEmailInfo("Prod Support Generic Notification");


                // Start the email item
                Email MapMail = new Email();
                MapMail.isHTML = true;
                MapMail.From = tmp.SendMessageFrom;
                MapMail.To = tmp.SendMessageTo;

                // Create new Request based on the exception just thrown.
                WriteToLogRequest MapReq = new WriteToLogRequest();
                MapReq.LogMessage = new LogObject();
                MapReq.LogMessage.ExceptionMessage = mex.Message;
                MapReq.LogMessage.ExceptionSource = mex.Source;
                MapReq.LogMessage.ExceptionStackTrace = mex.StackTrace;
                MapReq.LogMessage.IsInnerException = false;
                MapReq.RequestingAuthorityID = Environment.MachineName.ToString();
                MapReq.LogMessage.MessageTitle = "An Exception has occurred on HS.Data.ORM.Logger";
                MapReq.LogMessage.MessageType = MessageTypeEnum.Exception;
                MapReq.LogMessage.PromotionEnvironment = cfg.PromotionEnvironment;
                MapReq.LogMessage.SendingApplication = "HS.Data.ORM.Logger";
                MapReq.LogMessage.ContainsException = true;

                MapMail.Body = EmailFormat.FormatEmailBodyForException(MapReq, true);

                // Log Exception
                var mexID = LoggingData.WriteLogMessageToDB(MapReq.LogMessage, App.ApplicationID);

                MapMail.Subject = "HS.Data.ORM.Logger Map Not Found Exception occurred - LogID :" + mexID.ToString();


                // Send Email  - The To and From Email address are defined in web.config
                EmailIntegration.SendEmailNotification(MapMail);
            }
            catch (Exception ex)
            {
                //Write Exception to Event Log
                StaticHelperFunctions.HandleLoggerException(ex);

            }

            //Now send the email
            var resp = EmailIntegration.SendEmailNotification(eMail);


        }


    }
}
