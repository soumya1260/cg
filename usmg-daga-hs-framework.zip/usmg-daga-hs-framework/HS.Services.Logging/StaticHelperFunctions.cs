﻿using System;

namespace HS.Services.Logging
{
    internal static class StaticHelperFunctions
    {
        /// <summary>
        /// Writes Exception to Event Log.
        /// 
        /// Note: An entry must be added for source "HS.Services.Logging" in order 
        /// for this function to write to Event Log.
        /// </summary>
        /// <param name="ex"></param>
        internal static void HandleLoggerException(Exception ex)
        {
            System.Diagnostics.EventLog appLog = new System.Diagnostics.EventLog();

            appLog.Source = "HS.Services.Logging";

            appLog.WriteEntry(String.Format("An Exception has occurred : {0} : {1}", ex.Message, ex.StackTrace), System.Diagnostics.EventLogEntryType.Error);
        }
    }
}
