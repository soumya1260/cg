﻿using System;
using System.ComponentModel;
using System.Configuration.Install;
using System.Reflection;
using System.Xml;


namespace SDX.Services.UFS
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : Installer
    {
        public ProjectInstaller()
        {

            InitializeComponent();
            ConfigureInstaller();
        }
        private void ConfigureInstaller()
        {

            // find the install configuration file
            string assemblyLocation = Assembly.GetExecutingAssembly().Location;
            string installConfigFile = assemblyLocation + ".InstallConfig.xml";


            // now load the file and parse it
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(installConfigFile);

            XmlNode serviceNameNode = xmlDoc.SelectSingleNode("InstallConfig/ServiceName");

            if (serviceNameNode != null)
            {
                Console.WriteLine("serviceNameNode = " + serviceNameNode);
                string serviceName = serviceNameNode.InnerText.Trim();
                this.serviceInstaller1.ServiceName = serviceName;
                this.serviceInstaller1.DisplayName = serviceName;



                Console.WriteLine("this.serviceInstaller1.ServiceName = " + this.serviceInstaller1.ServiceName);
            }

        }

    }
}
