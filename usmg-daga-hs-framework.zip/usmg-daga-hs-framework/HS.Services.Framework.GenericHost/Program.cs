﻿using System;
using System.ServiceProcess;
using HS.Configuration;

namespace HS.Services.Framework
{
    /// <summary>
    /// Class Program.
    /// </summary>
    class Program
    {

        static void Main(string[] args)
        {
            //Log.LogMessage("Staring Generic Host", System.Diagnostics.TraceLevel.Error);
            //try
            //{
            //    throw new Exception("This is a test Exception");
            //}
            //catch(Exception ex)
            //{
            //    Log.LogException(ex);
            //}
            Environment.CurrentDirectory = System.AppDomain.CurrentDomain.BaseDirectory;

            HSServicesConfiguration servicesSection = HSServicesConfiguration.Current;

            if (servicesSection.RunAsService)
            {
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[] { new HSGenericServiceHost() };
                ServiceBase.Run(ServicesToRun);
            }
            else
            {
                HSGenericServiceHost service = new HSGenericServiceHost();
                service.RunFromConsole();
                Console.ReadLine();
            }



        }

    }
}
