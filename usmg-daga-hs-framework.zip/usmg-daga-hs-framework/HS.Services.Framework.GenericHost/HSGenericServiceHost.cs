﻿using System;
using System.Reflection;
using System.Xml;

namespace HS.Services.Framework
{

    public class HSGenericServiceHost : HSServiceHost
    {

        protected override void InitializeComponent()
        {

            base.InitializeComponent();
            ConfigureInstaller();
        }
        private void ConfigureInstaller()
        {

            // find the install configuration file
            string assemblyLocation = Assembly.GetExecutingAssembly().Location;
            string installConfigFile = assemblyLocation + ".InstallConfig.xml";


            // now load the file and parse it
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(installConfigFile);

            XmlNode serviceNameNode = xmlDoc.SelectSingleNode("InstallConfig/ServiceName");

            if (serviceNameNode != null)
            {
                Console.WriteLine("serviceNameNode = " + serviceNameNode);
                string serviceName = serviceNameNode.InnerText.Trim();
                this.ServiceName = serviceName;

            }

        }

    }

}
