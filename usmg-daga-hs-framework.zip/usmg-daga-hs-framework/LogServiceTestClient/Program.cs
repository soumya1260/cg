﻿using System;
using System.Collections.Generic;
using System.Threading;
using HS;
using System.Configuration;

namespace LogServiceTestClient
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Sending logger entries");

                // Thread.Sleep(2000);
                // Log.LogMessage("YYYYYYYYCreate Verification record failed.", MessageTypeEnum.Informational);


                // Thread.Sleep(300000);
                // return;

                var foo = "stop here and wait for service to start...";
                Thread.Sleep(3000);
                foo = "Press enter when ready...";
                Console.ReadLine();


                for (int j = 1; j <= 1 ; j++)
                {
                    Console.WriteLine("Sending Exception Number " + j);

                    //First, send an informational message
                    HS.Log.LogMessage("this is an Informational test only", MessageTypeEnum.Informational);
                   
                    HS.Log.LogMessage("this is a Debug test only", MessageTypeEnum.Debug);

                    HS.Log.LogMessage("this is a Security Message test only", MessageTypeEnum.SecurityMessage);

                    HS.Log.LogMessage("this is a Verbose test only", MessageTypeEnum.Verbose);

                    #region Exceptions
                    try
                    {
                        throw new DuplicateWaitObjectException();
                    }
                    catch (Exception ex)
                    {
                        HS.Log.LogException(ex);
                    }
                    try
                    {
                        throw new System.IO.FileNotFoundException();
                    }
                    catch (Exception ex)
                    {
                        HS.Log.LogException(ex);
                    }
                    try
                    {
                        throw new System.DivideByZeroException("This is a simpler exception");
                    }
                    catch(Exception ex3)
                    {
                        var am = new List<string>();

                        ConnectionStringsSection cfg = (ConnectionStringsSection)ConfigurationManager.GetSection("connectionStrings");

                        for (int i = 0; i < cfg.ConnectionStrings.Count; i++)
                        {
                            var css = cfg.ConnectionStrings[i];
                            am.Add(css.ConnectionString);
                        }
                        HS.Log.LogException(ex3, am);
                    }

                    #endregion
                }

            }
            catch (Exception ex)
            {

            }
       }
    }
}
