﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace LogServiceTestWebClient.Controllers
{
    public class HomeController : Controller
    {

        public ActionResult Index()
        {

            try
            {
                throw new DuplicateWaitObjectException();//DllNotFoundException();

            }
            catch (Exception ex)
            {
                List<string> testMessages = new List<string>();
                testMessages.Add("test");
                testMessages.Add("test2");
                HS.Log.LogException(ex, testMessages);
            }


            return View();
        }

    }
}
