EXEC sp_addrolemember N'db_owner', N'LoggingApp'
GO
