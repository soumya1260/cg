EXEC sp_addrolemember N'db_datawriter', N'hnetnt\Arvind.Kumar'
GO
EXEC sp_addrolemember N'db_datawriter', N'hnetnt\Jonathan.Lauthern'
GO
EXEC sp_addrolemember N'db_datawriter', N'HNETNT\rahulkumar.singh'
GO
EXEC sp_addrolemember N'db_datawriter', N'HNETNT\TimB'
GO
EXEC sp_addrolemember N'db_datawriter', N'LoggingApp'
GO
