IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'HNETNT\Jonathan.Lauthern')
CREATE LOGIN [HNETNT\Jonathan.Lauthern] FROM WINDOWS
GO
CREATE USER [hnetnt\Jonathan.Lauthern] FOR LOGIN [HNETNT\Jonathan.Lauthern]
GO
