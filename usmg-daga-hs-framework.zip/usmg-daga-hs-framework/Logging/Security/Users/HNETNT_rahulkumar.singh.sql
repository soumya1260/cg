IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'HNETNT\rahulkumar.singh')
CREATE LOGIN [HNETNT\rahulkumar.singh] FROM WINDOWS
GO
CREATE USER [HNETNT\rahulkumar.singh] FOR LOGIN [HNETNT\rahulkumar.singh]
GO
