IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'HNETNT\Arvind.Kumar')
CREATE LOGIN [HNETNT\Arvind.Kumar] FROM WINDOWS
GO
CREATE USER [hnetnt\Arvind.Kumar] FOR LOGIN [HNETNT\Arvind.Kumar]
GO
