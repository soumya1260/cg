IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'LoggingApp')
CREATE LOGIN [LoggingApp] WITH PASSWORD = 'p@ssw0rd'
GO
CREATE USER [LoggingApp] FOR LOGIN [LoggingApp]
GO
