CREATE TABLE [dbo].[LogEntries]
(
[LogEntryID] [int] NOT NULL IDENTITY(1, 1),
[ApplicationId] [int] NULL,
[LogEntryTypeID] [int] NOT NULL,
[MessageTitle] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Message] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExceptionMessage] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MessageFromMachine] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LogDate] [datetime2] NULL,
[EnvironmentId] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[LogEntries] ADD CONSTRAINT [PK_LogEntries] PRIMARY KEY CLUSTERED  ([LogEntryID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[LogEntries] WITH NOCHECK ADD CONSTRAINT [FK_LogEntries_Applications] FOREIGN KEY ([ApplicationId]) REFERENCES [dbo].[Applications] ([ApplicationId])
GO
ALTER TABLE [dbo].[LogEntries] WITH NOCHECK ADD CONSTRAINT [FK_LogEntries_Environments] FOREIGN KEY ([EnvironmentId]) REFERENCES [dbo].[Environments] ([EnvironmentId])
GO
ALTER TABLE [dbo].[LogEntries] WITH NOCHECK ADD CONSTRAINT [FK_LogEntries_LogEntryTypes] FOREIGN KEY ([LogEntryTypeID]) REFERENCES [dbo].[LogEntryTypes] ([LogEntryTypeID])
GO
