CREATE TABLE [dbo].[LogExceptionDetails]
(
[EntryID] [int] NOT NULL IDENTITY(1, 1),
[LogEntryID] [int] NOT NULL,
[Message] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Source] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[StackTrace] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsInnerException] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[LogExceptionDetails] ADD CONSTRAINT [PK_LogExceptionDetails] PRIMARY KEY CLUSTERED  ([EntryID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[LogExceptionDetails] ADD CONSTRAINT [FK_LogExceptionDetails_LogEntries] FOREIGN KEY ([LogEntryID]) REFERENCES [dbo].[LogEntries] ([LogEntryID])
GO
