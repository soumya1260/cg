CREATE TABLE [dbo].[ExceptionRules]
(
[ExceptionRuleID] [int] NOT NULL IDENTITY(1, 1),
[ApplicationId] [int] NULL,
[EnvironmentId] [int] NULL,
[ExceptionMessage] [varchar] (2000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ExceptionCount] [int] NOT NULL,
[TimeSpan] [int] NOT NULL,
[IgnoreException] [int] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ExceptionRules] ADD CONSTRAINT [PK_ExceptionRules] PRIMARY KEY CLUSTERED  ([ExceptionRuleID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ExceptionRules] ADD CONSTRAINT [FK_ExceptionRules_Applications] FOREIGN KEY ([ApplicationId]) REFERENCES [dbo].[Applications] ([ApplicationId])
GO
ALTER TABLE [dbo].[ExceptionRules] ADD CONSTRAINT [FK_ExceptionRules_Environments] FOREIGN KEY ([EnvironmentId]) REFERENCES [dbo].[Environments] ([EnvironmentId])
GO
