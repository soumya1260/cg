CREATE TABLE [dbo].[LogEntryTypes]
(
[LogEntryTypeID] [int] NOT NULL IDENTITY(1, 1),
[LogEntryType] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[LogEntryTypes] ADD CONSTRAINT [PK_LogEntryTypes] PRIMARY KEY CLUSTERED  ([LogEntryTypeID]) ON [PRIMARY]
GO
