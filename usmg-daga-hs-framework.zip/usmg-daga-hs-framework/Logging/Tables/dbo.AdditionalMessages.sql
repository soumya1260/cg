CREATE TABLE [dbo].[AdditionalMessages]
(
[EntryID] [int] NOT NULL IDENTITY(1, 1),
[LogEntryID] [int] NOT NULL,
[AdditionalMessage] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[AdditionalMessages] ADD CONSTRAINT [PK_AdditionalMessages] PRIMARY KEY CLUSTERED  ([EntryID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AdditionalMessages] ADD CONSTRAINT [FK_AdditionalMessages_LogEntries] FOREIGN KEY ([LogEntryID]) REFERENCES [dbo].[LogEntries] ([LogEntryID])
GO
