CREATE TABLE [dbo].[Environments]
(
[EnvironmentId] [int] NOT NULL IDENTITY(1, 1),
[Environment] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Environments] ADD CONSTRAINT [PK_Environments] PRIMARY KEY CLUSTERED  ([EnvironmentId]) ON [PRIMARY]
GO
