CREATE TABLE [dbo].[ExceptionEmailAddresses]
(
[ExceptionEmailAddressesId] [int] NOT NULL IDENTITY(1, 1),
[EnvironmentId] [int] NOT NULL,
[ApplicationId] [int] NULL,
[LogEntryTypeId] [int] NOT NULL,
[DestinationEmail] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[FromEmail] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[MessageSubject] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ExceptionEmailAddresses] ADD CONSTRAINT [FK_ExceptionEmailAddresses_Applications] FOREIGN KEY ([ApplicationId]) REFERENCES [dbo].[Applications] ([ApplicationId])
GO
ALTER TABLE [dbo].[ExceptionEmailAddresses] ADD CONSTRAINT [FK_ExceptionEmailAddresses_Environments] FOREIGN KEY ([EnvironmentId]) REFERENCES [dbo].[Environments] ([EnvironmentId])
GO
ALTER TABLE [dbo].[ExceptionEmailAddresses] ADD CONSTRAINT [FK_ExceptionEmailAddresses_LogEntryTypes] FOREIGN KEY ([LogEntryTypeId]) REFERENCES [dbo].[LogEntryTypes] ([LogEntryTypeID])
GO
