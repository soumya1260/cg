SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE PROCEDURE [dbo].[GetExceptionEmailAddresses]
    
AS
    BEGIN

	select 
		x.ExceptionEmailAddressesId,
		a.Application,
		e.Environment,
		l.LogEntryType,
		x.DestinationEmail,
		x.FromEmail,
		x.MessageSubject
from 
	ExceptionEmailAddresses x
	inner join environments e on e.environmentid = x.environmentid
	inner join Applications a on a.ApplicationID = x.ApplicationID
	inner join LogEntryTypes l on l.LogEntryTypeID = x.LogEntryTypeID
	group by a.application, 
			 e.environment, 
			 l.logentrytype,
			 x.destinationemail,
			 x.fromemail,
			 x.messagesubject,
			 x.ExceptionEmailAddressesId

	
    END
GO
