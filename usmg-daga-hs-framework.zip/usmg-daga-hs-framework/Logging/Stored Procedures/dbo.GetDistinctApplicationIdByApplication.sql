SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE PROCEDURE [dbo].[GetDistinctApplicationIdByApplication]
    @Application VARCHAR(1000),
    @ApplicationId INT OUTPUT
AS
    BEGIN

        SET @Application = LTRIM(RTRIM(@Application))


        IF NOT EXISTS ( SELECT TOP 1
                            1
                        FROM
                            Applications
                        WHERE
                            lower([Application]) = lower(@Application) )
            BEGIN
                INSERT  INTO Applications
                        ( [Application] )
                VALUES
                        ( @Application )
              
            END
      
                SELECT TOP 1
                    @ApplicationId = ApplicationId
                FROM
                    Applications
                WHERE
                    [Application] = @Application

          
    END
GO
