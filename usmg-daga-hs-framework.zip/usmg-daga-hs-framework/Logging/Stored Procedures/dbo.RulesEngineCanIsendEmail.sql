SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- Batch submitted through debugger: SQLQuery7.sql|7|0|C:\Users\stephen.dornan\AppData\Local\Temp\~vs8BFE.sql
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

/*
exec [RulesEngineCanIsendEmail] 'LogServiceTestWebClient', 'Attempted to divide by zero.', 'Dev'
exec [RulesEngineCanIsendEmail] 'LogServiceTestClient.vshost.exe','Attempted to divide by zero.', 'QA'
*/

CREATE PROCEDURE [dbo].[RulesEngineCanIsendEmail]
    @ApplicationName VARCHAR(1000),
    @ExceptionMessage VARCHAR(1000),
    @Environment VARCHAR(10)
AS
    BEGIN

        DECLARE @EnvironmentId INT
        DECLARE @ApplicationId INT

        EXEC [dbo].[GetDistinctEnvironmentIdByEnvironment]
            @Environment,
            @EnvironmentId OUTPUT
        EXEC [dbo].[GetDistinctApplicationIdByApplication]
            @ApplicationName,
            @ApplicationId OUTPUT

        DECLARE @TimeInMinutes INT = -1;
        DECLARE @MaxCount INT = -1;
        DECLARE @retVal VARCHAR(10) = 'false';
        DECLARE @ExCount INT = -1;
        DECLARE @IgnoreExcept INT = -1;
	
	-- Make sure we have a rule.  If not, don't bother
        IF NOT EXISTS ( SELECT
                            IgnoreException
                        FROM
                            ExceptionRules
                        WHERE
                            ApplicationId = @ApplicationId
                            AND (
                                  EnvironmentId = @EnvironmentId
                                  OR EnvironmentId = 0
                                )
                            AND ExceptionMessage = @ExceptionMessage )
            BEGIN
                SELECT
                    @retVal = 'true';
                SELECT
                    @retVal AS 'CanISend',
                    1 AS 'ExceptionCount',
                    0 AS 'MaxTime',
                    0 AS 'IsRuleConfigured';	
                RETURN
            END

	--Check and see if the exception is marked as Ignore
        SELECT TOP 1
            @IgnoreExcept = IgnoreException
        FROM
            ExceptionRules
        WHERE
            ApplicationId = @ApplicationId
            AND (
                  EnvironmentId = @EnvironmentId
                  OR EnvironmentId = 0
                )
            AND ExceptionMessage = @ExceptionMessage
        ORDER BY
            EnvironmentId DESC
		
	--If it is marked as ignore then send back that they canot send email
        IF @IgnoreExcept = 1
            BEGIN
                SELECT
                    @retVal = 'false';
                SELECT
                    @retVal AS 'CanISend',
                    @ExCount AS 'ExceptionCount',
                    @TimeInMinutes AS 'MaxTime',
                    1 AS 'IsRuleConfigured';
            END;
        ELSE
            BEGIN
	--Get the max time span and max exception count for the exception
                SELECT TOP 1
                    @TimeInMinutes = TimeSpan,
                    @MaxCount = ExceptionCount
                FROM
                    ExceptionRules
                WHERE
                    ApplicationId = @ApplicationId
                    AND (
                          EnvironmentId = @EnvironmentId
                          OR EnvironmentId = 0
                        )
                    AND ExceptionMessage = @ExceptionMessage
                ORDER BY
                    EnvironmentId DESC
		
	--If a rule has not been set, return true, they CAN send an email
                IF @TimeInMinutes = -1
                    OR @TimeInMinutes = 0
                    BEGIN
                        SELECT
                            @retVal = 'true';
                        SELECT
                            @retVal AS 'CanISend',
                            0 AS 'ExceptionCount',
                            0 AS 'MaxTime', 
                            0 AS 'IsRuleConfigured';
                    END
                ELSE
                    BEGIN
			--There has been a rule set, dso get the count of exceptions that have occured within the 
			--specified time span for the specified environment
                        SELECT
                            @ExCount = COUNT(*)
                        FROM
                            dbo.LogEntries
                        WHERE
                            ApplicationId = @ApplicationId
                            AND ExceptionMessage = @ExceptionMessage
                            AND EnvironmentId = @EnvironmentId
                            AND LogDate > DATEADD(minute, -@TimeInMinutes,
                                                  GETDATE())
				
			--If the max exception count has been exceeded for 	
			
                        IF (
                             ( @ExCount >= @MaxCount )
                             OR @MaxCount IS NULL
                           )
                            BEGIN
                                SELECT
                                    @retVal = 'true';
                                SELECT
                                    @retVal AS 'CanISend',
                                    @ExCount AS 'ExceptionCount',
                                    @TimeInMinutes AS 'MaxTime',
                                    1 AS 'IsRuleConfigured';
                            END
                        ELSE
                            BEGIN
                                SELECT
                                    @retVal = 'false';
                                SELECT
                                    @retVal AS 'CanISend',
                                    @ExCount AS 'ExceptionCount',
                                    @TimeInMinutes AS 'MaxTime', 
                                    1 AS 'IsRuleConfigured';
                            END;
	
                    END;
            END;
    END
GO
GRANT EXECUTE ON  [dbo].[RulesEngineCanIsendEmail] TO [LoggingApp]
GO
