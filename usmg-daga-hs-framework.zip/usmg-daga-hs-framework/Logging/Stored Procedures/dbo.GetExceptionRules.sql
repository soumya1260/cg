SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE PROCEDURE [dbo].[GetExceptionRules]
    
AS
    BEGIN

	SELECT r.exceptionruleid, 
		   a.application, 
		   e.environment, 
		   r.exceptionmessage,
		   r.exceptioncount,
		   r.timespan, 
		   r.ignoreexception

	from ExceptionRules r
	inner join applications a on a.applicationid = r.applicationid
	inner join environments e on e.environmentid = r.environmentid
         
	group by a.application, 
			 e.environment, 
			 r.exceptionmessage, 
			 r.exceptioncount,
			 r.timespan,
			 r.ignoreexception, r.exceptionruleid
	order by a.application, e.environment
    END
GO
GRANT EXECUTE ON  [dbo].[GetExceptionRules] TO [LoggingApp]
GO
