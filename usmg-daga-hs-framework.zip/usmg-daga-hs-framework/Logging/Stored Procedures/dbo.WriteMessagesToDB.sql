SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- Batch submitted through debugger: SQLQuery7.sql|7|0|C:\Users\stephen.dornan\AppData\Local\Temp\~vs8BFE.sql
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[WriteMessagesToDB]
	@OriginalLogEntry INT,
	@AdditionalMessage VARCHAR(MAX)
	
	
AS
BEGIN

INSERT INTO dbo.AdditionalMessages
        ( LogEntryID, AdditionalMessage )
VALUES  ( @OriginalLogEntry,@AdditionalMessage )


END
GO
GRANT EXECUTE ON  [dbo].[WriteMessagesToDB] TO [LoggingApp]
GO
