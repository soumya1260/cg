
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

/*
exec [dbo].[GetEmaillAddressForLogMessage] null ,null,null
exec [dbo].[GetEmaillAddressForLogMessage] 1,'UAT','LogServiceTestClient.vshost.exe'
exec [dbo].[GetEmaillAddressForLogMessage] 2,'UAT','LogServiceTestClient.vshost.exe'
exec [dbo].[GetEmaillAddressForLogMessage] 3,'UAT','LogServiceTestClient.vshost.exe'
exec [dbo].[GetEmaillAddressForLogMessage] 4,'UAT','LogServiceTestClient.vshost.exe'


*/ 
 
CREATE PROCEDURE [dbo].[GetEmaillAddressForLogMessage]
    @LogEntryTypeId INT,
    @Environment VARCHAR(10),
    @ApplicationName VARCHAR(1000)
AS
    BEGIN

        DECLARE @EnvironmentId INT
        DECLARE @ApplicationId INT

        EXEC [dbo].[GetDistinctEnvironmentIdByEnvironment]
            @Environment,
            @EnvironmentId OUTPUT
        EXEC [dbo].[GetDistinctApplicationIdByApplication]
            @ApplicationName,
            @ApplicationId OUTPUT


        SELECT TOP 1
        DestinationEmail,
        FromEmail,
        MessageSubject
        FROM
            dbo.ExceptionEmailAddresses
        WHERE
            (
              LogEntryTypeId = @LogEntryTypeId
              OR LogEntryTypeId = 0
            )
            AND ApplicationId = @ApplicationId
            AND (
                  EnvironmentId = @EnvironmentId
                  OR EnvironmentId = 0
                )
        ORDER BY
            EnvironmentId DESC,
            LogEntryTypeId DESC

            
    END

GO

GRANT EXECUTE ON  [dbo].[GetEmaillAddressForLogMessage] TO [LoggingApp]
GO
