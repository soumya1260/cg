SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

/*
DECLARE @id int
EXEC [dbo].[GetDistinctEnvironmentIdByEnvironment] 'UAT', @id OUTPUT
Select * from Environments where EnvironmentId = @id
*/
CREATE PROCEDURE [dbo].[GetDistinctEnvironmentIdByEnvironment]
    @Environment VARCHAR(10) = 'Prod',
    @EnvironmentId INT OUTPUT
AS
    BEGIN

        SELECT TOP 1
            @EnvironmentId = EnvironmentId
        FROM
            Environments
        WHERE
            lower(Environment) = lower(@Environment)

		-- Invalid Enviroment Supplied, return Prod EnviromentId

        IF ( @EnvironmentId IS NULL )
            BEGIN
				/* Note: Using select to get EnvironmentId instead of returning hardcoded ID
					     because ID could be different in each database. */
            
                SELECT TOP 1
                    @EnvironmentId = EnvironmentId
                FROM
                    Environments
                WHERE
                    Environment = 'Prod'
                    
            END 
    END

GO
