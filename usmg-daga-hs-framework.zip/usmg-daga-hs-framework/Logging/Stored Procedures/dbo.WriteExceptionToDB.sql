SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- Batch submitted through debugger: SQLQuery7.sql|7|0|C:\Users\stephen.dornan\AppData\Local\Temp\~vs8BFE.sql
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[WriteExceptionToDB]
    @OriginalLogEntry INT,
    @IsInnerException INT,
    @ApplicationName VARCHAR(1000),
    @MessageType INT,
    @MessageTitle VARCHAR(MAX),
    @Message VARCHAR(MAX),
    @ExceptionMessage VARCHAR(MAX),
    @ExceptionSource VARCHAR(1000),
    @ExceptionStackTrace VARCHAR(MAX),
    @ContainsException INT,
    @MessageSentFrom VARCHAR(1000),
    @Environment VARCHAR(10)
AS
    BEGIN

        DECLARE @EnvironmentId INT
        DECLARE @ApplicationId INT

        EXEC [dbo].[GetDistinctEnvironmentIdByEnvironment]
            @Environment,
            @EnvironmentId OUTPUT
            
        EXEC [dbo].[GetDistinctApplicationIdByApplication]
            @ApplicationName,
            @ApplicationId OUTPUT


        DECLARE @ID INT = -1;

        IF @IsInnerException = 0
            BEGIN
		--this is a new exception
                BEGIN TRANSACTION
                INSERT  INTO LogEntries
                        (
                          ApplicationId,
                          LogEntryTypeID,
                          [Message],
                          ExceptionMessage,
                          MessageTitle,
                          MessageFromMachine,
                          LogDate,
                          EnvironmentId
                        )
                VALUES
                        (
                          @ApplicationId,
                          @MessageType,
                          @Message,
                          @ExceptionMessage,
                          @MessageTitle,
                          @MessageSentFrom,
                          GETDATE(),
                          @EnvironmentId
                        );
                COMMIT;
		
                SET @ID = SCOPE_IDENTITY()
			
            END;
		
        BEGIN TRANSACTION
    
        IF @ContainsException = 1
            BEGIN
                IF @IsInnerException = 1 
			-- this is na inner exception so use the LogEntry id that was passed in
                    SET @ID = @OriginalLogEntry;
			
			
                INSERT  INTO dbo.LogExceptionDetails
                        (
                          LogEntryID,
                          Message,
                          Source,
                          StackTrace,
                          IsInnerException
			            )
                VALUES
                        (
                          @ID,
                          @ExceptionMessage,
                          @ExceptionSource,
                          @ExceptionStackTrace,
                          @IsInnerException
			            );
		
            END
        COMMIT
        SELECT
            @ID AS 'NewLogEntryID';
    END
GO
GRANT EXECUTE ON  [dbo].[WriteExceptionToDB] TO [LoggingApp]
GO
