﻿// ***********************************************************************
// Assembly         : HS.Services
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="HSServiceBase.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************



/// <summary>
/// The Services namespace.
/// </summary>
namespace HS.Services
{
    /// <summary>
    /// The base for a service class
    /// </summary>
    public abstract class HSServiceBase
    {

        

     

    }
}
