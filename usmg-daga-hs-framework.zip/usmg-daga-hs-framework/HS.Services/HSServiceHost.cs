﻿// ***********************************************************************
// Assembly         : HS.Services
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="HSServiceHost.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.ServiceProcess;
using System.ServiceModel;
using HS.Configuration;


/// <summary>
/// The Services namespace.
/// </summary>
namespace HS.Services
{
    /// <summary>
    /// Class HSServiceHost.
    /// </summary>
    public class HSServiceHost : System.ServiceProcess.ServiceBase
    {

        #region "Private Members"

        /// <summary>
        /// The _hosts
        /// </summary>
        private List<ServiceHost> _hosts = null;

        #endregion

        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        public static void Main()
        {
            ServiceBase.Run(new HSServiceHost());
        }

        /// <summary>
        /// Start the Windows service.
        /// </summary>
        /// <param name="args">Data passed by the start command.</param>
        protected override void OnStart(string[] args)
        {

            //Logger.Start();

            _hosts = new List<ServiceHost>();

            HSServicesConfiguration servicesSection = HSServicesConfiguration.Current;

            foreach (HS.Configuration.ServiceElement serviceElement in servicesSection.Services)
            {
                if (serviceElement.Enabled == true)
                    _hosts.Add(new ServiceHost(Type.GetType(serviceElement.ServiceTypeName, true, true)));
            }

            //Open services
            OpenServiceHosts();

            Console.WriteLine("Service Hosts ready.");

        }

        /// <summary>
        /// Stop the Windows service.
        /// </summary>
        protected override void OnStop()
        {

            Console.WriteLine("Stopping Services.");

            foreach (ServiceHost host in _hosts)
            {
                host.Close();
            }

            //Logger.Stop();

        }


        /// <summary>
        /// Runs service from conosle
        /// </summary>
        public void RunFromConsole()
        {
            string[] args = new string[0];
            OnStart(args);
        }



        /// <summary>
        /// Opens each host in the list of hosts
        /// </summary>
        private void OpenServiceHosts()
        {

            foreach (ServiceHost host in _hosts)
            {

                if (host.BaseAddresses == null || host.BaseAddresses.Count == 0)
                {
                    Console.WriteLine(String.Format("Creating {0} host\r\n ",
                    host.Description.ServiceType.ToString()));
                    host.Faulted += new EventHandler(host_Faulted);
                    host.Open();
                }
                else
                {
                    Console.WriteLine(String.Format("Creating {0} host\r\n at {1}",
                         host.Description.ServiceType.ToString(),
                         host.BaseAddresses[0].ToString()));
                    host.Faulted += new EventHandler(host_Faulted);
                    host.Open();
                }
            }

        }

        /// <summary>
        /// Fires when a service host transitions into the Faulted state
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void host_Faulted(object sender, EventArgs e)
        {

            ServiceHost host = sender as ServiceHost;

            Console.WriteLine(String.Format("Serivce Host for {0} faulted!", host.Description.ServiceType));

        }

        /// <summary>
        /// Initializes the component.
        /// </summary>
        protected virtual void InitializeComponent()
        {

            // 
            // WindowsService
            // 
            this.ServiceName = "HS Application Service";

        }

    }
}
