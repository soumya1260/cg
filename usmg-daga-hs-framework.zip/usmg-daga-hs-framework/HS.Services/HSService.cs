﻿// ***********************************************************************
// Assembly         : HS.Services
// Author           : stephen.dornan
// Created          : 09-06-2013
//
// Last Modified By : stephen.dornan
// Last Modified On : 09-06-2013
// ***********************************************************************
// <copyright file="HSService.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

/// <summary>
/// The Services namespace.
/// </summary>
namespace HS.Services
{


    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public abstract class HSService : HSServiceBase
    {





    }
}
