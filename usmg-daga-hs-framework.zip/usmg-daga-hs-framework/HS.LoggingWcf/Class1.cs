﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HS;

namespace HS.LoggingWcf
{
    public class Class1
    {
    }
}
