# HealthSpring Legacy Framework
## Key Components
* HS.Core (4.x and later)
* HS.Services
* HS.Data.ORM
* HS.Data.ORM.Logging
* HS.Services.Framework.GenericHost
* HS.Services.GeoLocation (obsolete)
